/*
 *
 * Hamsam - Instant Messaging API
 *
 * Copyright (C) 2003 Mike Miller <mikemil@users.sourceforge.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 */

package hamsam.protocol.aim.command;

import java.io.IOException;
import java.io.OutputStream;
import hamsam.protocol.aim.flap.*;
import hamsam.protocol.aim.snac.*;
import hamsam.protocol.aim.util.*;

/**
 * @author mikem
 */
public class ClientReadyCmd extends Command {
    
    
    private static final byte[] FAMILY  = { 0x01, 0x13, 0x02, 0x03, 0x15, 0x04, 0x06, 0x09, 0x0a, 0x0b };
    private static final byte[] VERSION = { 0x03, 0x02, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01 };
    private static final byte[] DLLVERSION = { 0x01, 0x10, 0x04, 0x7b };
    
        
    /**
     * Constructor
     */
    public ClientReadyCmd() {
        flapHdr = new FlapHeader(FlapConstants.FLAP_CHANNEL_SNAC, 10);
        snacPacket = new SNACPacket(SNACConstants.SNAC_FAMILY_GENERIC_SERVICE_CONTROLS, SNACConstants.CLIENT_READY);
    }


    /* (non-Javadoc)
     * @see hamsam.protocol.aim.command.Command#writeCommandData(java.io.OutputStream)
     */
    public void writeCommandData(OutputStream os) throws IOException {
        for (int i = 0; i < FAMILY.length; i++) {
            os.write(ByteUtils.getUShort(FAMILY[i]));
            os.write(ByteUtils.getUShort(VERSION[i]));
            os.write(DLLVERSION);
        }
    }

}
