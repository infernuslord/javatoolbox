/*
 * Please see COPYING for license details
 *
 * Copyright (C) 2003 Raghu K, All rights reserved.
 */

package hamsam.protocol.msn;

import hamsam.net.Connection;
import hamsam.util.log.LogManager;

import java.io.IOException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * This thread sends outgoing commands to the server.
 */
class WriterThread extends Thread
{
	/**
	 * The MSN server associated with this writer thread.
	 */
	private MsnServer server;

	/**
	 * Connection to send the commands.
	 */
	private Connection conn;

	/**
	 * Buffer to read the transactions from.
	 */
	private Vector buff;

	/**
	 * Flag used to stop this thread.
	 */
	private volatile boolean stop;

	/**
	 * Current value of transaction ID. The value used by this implementation
	 * is always between 1 and 2147483647, inclusive.
	 */
	private int transactionID;

	/**
	 * Construct a writer thread that uses a specified connection.
	 * <code>buff</code> is a buffer that supplies the commands
	 * to be sent to the server.
	 *
	 * @param server the MSN server associated with this writer thread.
	 * @param conn the connection to send the commands.
	 * @param buff the buffer holding the transactions to be sent.
	 */
	public WriterThread(MsnServer server, Connection conn, Vector buff)
	{
		this.server = server;
		this.conn = conn;
		this.buff = buff;
		this.stop = false;
		this.transactionID = 1;
	}

	/**
	 * Runs this thread.
	 */
	public void run()
	{
		try
		{
			Logger logger = LogManager.getLogger();
			while(!stop)
			{
				AbstractCommand cmd;

				synchronized(buff)
				{
					if(buff.size() > 0)
						cmd = (AbstractCommand) buff.remove(0);
					else
					{
						buff.wait(500);
						continue;
					}
				}

				String msg = "Client: " + cmd.toString();
				if(!msg.endsWith("\n"))
					msg += '\n'; 
				logger.logp(Level.INFO, this.getClass().getName(), "run", msg);
				conn.write(cmd.toString().getBytes("UTF-8"));
				conn.flush();
			}
		}
		catch(IOException e)
		{
			server.writerExited();
		}
		catch(InterruptedException e)
		{
			server.writerExited();
		}
	}

	/**
	 * Stop this thread.
	 */
	public void stopThread()
	{
		stop = true;
	}
}
