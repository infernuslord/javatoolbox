/*
 * Sun Public License Notice The contents of this file are subject to the Sun
 * Public License Version 1.0 (the "License"). You may not use this file except
 * in compliance with the License. A copy of the License is available at
 * http://www.sun.com/ The Original Code is the Jemmy library. The Initial
 * Developer of the Original Code is Alexandre Iline. All Rights Reserved.
 * Contributor(s): Alexandre Iline. $Id: KeyDriver.java,v 1.4 2003/02/19
 * 04:07:09 jemmy Exp $ $Revision: 1.4 $ $Date: 2003/02/19 04:07:09 $
 */

package org.netbeans.jemmy.drivers;

import org.netbeans.jemmy.Timeout;
import org.netbeans.jemmy.operators.ComponentOperator;

/**
 * Defines how to simulate keyboard operations.
 */
public interface KeyDriver
{

    /**
     * Presses a key.
     * 
     * @param oper Component operator.
     * @param keyCode Key code (<code>KeyEvent.VK_*</code> value)
     * @param modifiers a combination of <code>InputEvent.*_MASK</code>
     *        fields.
     */
    public void pressKey(ComponentOperator oper, int keyCode, int modifiers);


    /**
     * Releases a key.
     * 
     * @param oper Component operator.
     * @param keyCode Key code (<code>KeyEvent.VK_*</code> value)
     * @param modifiers a combination of <code>InputEvent.*_MASK</code>
     *        fields.
     */
    public void releaseKey(ComponentOperator oper, int keyCode, int modifiers);


    /**
     * Pushes a key.
     * 
     * @param oper Component operator.
     * @param keyCode Key code (<code>KeyEvent.VK_*</code> value)
     * @param modifiers a combination of <code>InputEvent.*_MASK</code>
     *        fields.
     * @param pushTime Time between pressing and releasing.
     */
    public void pushKey(ComponentOperator oper, int keyCode, int modifiers,
        Timeout pushTime);


    /**
     * Types a symbol.
     * 
     * @param oper Component operator.
     * @param keyCode Key code (<code>KeyEvent.VK_*</code> value)
     * @param keyChar Symbol to be typed.
     * @param modifiers a combination of <code>InputEvent.*_MASK</code>
     *        fields.
     * @param pushTime Time between pressing and releasing.
     */
    public void typeKey(ComponentOperator oper, int keyCode, char keyChar,
        int modifiers, Timeout pushTime);
}