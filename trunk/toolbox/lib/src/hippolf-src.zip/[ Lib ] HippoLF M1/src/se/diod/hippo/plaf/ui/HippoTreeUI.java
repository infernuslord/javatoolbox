/*
 * 
 * Created on 2004-jul-25
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.ui;

import java.awt.Component;
import java.awt.Graphics;

import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicTreeUI;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-25
 *
 */
public class HippoTreeUI extends BasicTreeUI {
	private boolean linesEnabled = true;




	/**
	 * 
	 * 
	 */
	public static ComponentUI createUI(JComponent b) {
		return new HippoTreeUI();
	}






	// Installation ***********************************************************
	/**
	 * 
	 * 
	 */
	public void installUI(JComponent c) {
		super.installUI(c);
	}




	/**
	 * 
	 * 
	 */
	public void uninstallUI(JComponent c) {
		super.uninstallUI(c);
	}






	// Painting ***************************************************************
	/**
	 * 
	 * 
	 */
	protected void paintVerticalLine(Graphics g, JComponent c, int x, int top, int bottom) {
		if (linesEnabled) {
			drawDashedVerticalLine( g, x, top, bottom );
		}
	}




	/**
	 * 
	 * 
	 */
	protected void paintHorizontalLine(Graphics g, JComponent c, int y, int left, int right) {
		if (linesEnabled) {
			drawDashedHorizontalLine( g, y, left, right );
		}
	}




	/**
	 * 
	 * Draws the icon centered at (x,y)
	 * 
	 */
	protected void drawCentered(Component c, Graphics graphics, Icon icon, int x, int y) {
		icon.paintIcon( c, graphics, x - icon.getIconWidth()  / 2 - 1, y - icon.getIconHeight() / 2 );
	}
}
