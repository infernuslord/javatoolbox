package phelps.io;

import java.io.*;
import java.util.regex.*;
import java.util.Random;



/**
	Extensions to {@link java.io.File}.

	<ul>
	<li>{@link #getCanonicalFile(String)}, {@link #getFuzzyFile(File, String)}
	<li>{@link #isCompressed(String)}, {@link #isBackup(String)}
	<li>pretty printing: {@link #relative(File, File)}
	<li>{@link #copy(File, File)}, {@link #secureDelete(File)}
	</ul>

	@version $Revision: 1.2 $ $Date: 2003/08/07 03:25:57 $
*/
public class Files {
  private Files() {}


  /** Size a common current disk block size. */
  public static final int BUFSIZ = 32*1024;


  /** Like {@link java.io.File#File(String)} but also expands <code>~</code> to users home directory (as given by the <code>user.home</code> property). */
  public static File getFile(String path) {
	if (path.equals("~") || path.startsWith("~/") || path.startsWith("~\\")) path = System.getProperty("user.home") + path.substring(1);
	return new File(path);
  }

  /** Like {@link java.io.File#getCanonicalFile(String)} but also expands <code>~</code> to users home directory (as given by the <code>user.home</code> property). */
  public static File getCanonicalFile(String path) throws IOException {
	return getFile(path).getCanonicalFile();
  }

  /** 
	Returns existing file (not directory), looking around a little if necessary:
	<ul>
	<li>(UNIX) {@link #getCanonicalFile(String)}
	<li>(WWW) if points to directory, tries adding "index.html"
	<li>(compression) adding or removing a compression suffix
	</ul>
	If no existing file can be found, returns same as {@link #getCanoncialFile(String)}.
  */
  public static File getFuzzyFile(File base, String path) throws IOException {
	// absolute
	File f = new File(path); if (f.exists()) return f.getCanonicalFile();

	// UNIX
	if (path.equals("~") || path.startsWith("~/") || path.startsWith("~\\")) {
		path = System.getProperty("user.home") + path.substring(1);
		f = new File(path);
	}

	// relative
	if (base!=null && !f.isAbsolute()) f = new File(base, path);

	// www
	File fe;
	if (f.exists() && f.isDirectory()) {
		if ((fe = new File(path + "index.html")).exists()) f = fe;
		else if ((fe = new File(path + "index.htm")).exists()) f = fe;
		//else fail
	}

	// compression
	if (!f.exists()) {
		if (isCompressed(path)) {	// match file by dropping suffix?
			path = path.substring(0, path.lastIndexOf('.'));
			fe = new File(path);
			if (fe.exists()) f = fe;

		} else { // add suffix
			for (int i=0,imax=Z.length; i<imax; i++) {
				fe = new File(path  + Z);
				if (fe.exists()) { f  = fe; break; }
			}
		}
	}

	return f.getCanonicalFile();
  }

  /** Computes paths of <var>file</var> relative to <var>base</var> and relative to HOME directory, and returns the shorter. */
  public static String relative(File base, File file) throws IOException {
	final char dirch = File.separatorChar;

	file = getCanonicalFile(file.toString());
	String f = file.toString(); if (file.isDirectory()) f += dirch;	// directories in '/'
	String rel = f;

	if (base!=null) {
		base = getCanonicalFile(base.toString());
		String b = base.toString(); if (base.isDirectory()) b += dirch; 

		int i=0, blen=b.length(), flen=f.length(); for (int imax=Math.min(blen, flen); i<imax; i++) if (b.charAt(i)!=f.charAt(i)) break;	// match from front
//System.out.print("match |"+b.substring(0,i)+"| @"+i);
		/*if (!(new File(b.substring(0,i))).isDirectory()) {*/ i--; while (i>0 && f.charAt(i)!=dirch) i--; i++;//}	// back up to nearest dir
//System.out.println(" => |"+b.substring(0,i)+"| @ "+i);

		StringBuffer sb = new StringBuffer(flen);
		for (int j=i; j<blen; j++) if (b.charAt(j)==dirch) sb.append("..").append(dirch);
//System.out.println("i="+i+", flen="+flen);
		//if (sb.length()>0) sb.setLength(sb.length()-1);
//System.out.println(f+" @ "+i+" => |"+f.substring(i)+"|");
		sb.append(f.substring(i));
		rel = sb.toString();
	}

	// HOME-relative shorter?
	final String home = System.getProperty("user.home");
	if (f.startsWith(home)) {
		String rel2 = "~" + f.substring(home.length());
		if (rel2.length() < rel.length()) rel = rel2;
//System.out.println(rel+" vs "+home+" => "+rel2);
	}

	return rel;
  }

  private static final String[] Z = { ".gz", ".Z", ".z", ".bzip2", ".bz2" };	// compression types we can handle
  static final Matcher zregex_ = Pattern.compile("\\.(gz|Z|z|bzip2|bz2)$").matcher("");

  /**
	Returns true if <var>filename</var> has a compression suffix for a type we can handle,
	which are .Z/.z, .gz, .bzip2/.bz2.
  */
  public static boolean isCompressed(String filename) {
	zregex_.reset(filename);
	return zregex_.find();
  }

  //public static final String[] bkup = { "~", ".bak", ".bkup", ".backup" };
  static final Matcher zbkup_ = Pattern.compile("((?i)~|\\.bak|\\.bkup|\\.backup)(\\.(gz|Z|z|bzip2|bz2))?$").matcher("");   // also catches ...~5~
  /** Returns true if <var>filename</var> is a backup file (e.g., end with ".bkup", with possible additional compression suffix). */
  public static boolean isBackup(String filename) {
	zbkup_.reset(filename);
	return zbkup_.find();
  }


  public static byte[] toByteArray(File file) throws IOException {
	ByteArrayOutputStream bos = new ByteArrayOutputStream((int)file.length());
    Streams.copy(new FileInputStream(file), bos, true);
	return bos.toByteArray();
  }


  /**
	Copies <var>filein</var> to <var>fileout</var>, creating parent directories as needed.
  */
  public static void copy(File filein, File fileout) throws IOException {	// => NIO
	filein = filein.getAbsoluteFile(); fileout = fileout.getAbsoluteFile();
	if (!filein.exists()) throw new FileNotFoundException(filein.getPath());
	if (!filein.canRead()) throw new IOException(filein.getPath()+" not readable");
	if (filein.equals(fileout)) return;

	File outdir = fileout.getParentFile();
	//if (filein.equals(outdir)) continue;
	if (!outdir.exists()) fileout.mkdirs();

	Streams.copy(new FileInputStream(filein), new FileOutputStream(fileout), true);
  }


  /**
	Securely deletes a file by first overwriting it with random data several times.
	@return <code>true</code> iff successful
  */
  public static boolean secureDelete(File file) throws IOException {
	if (!file.canWrite()) return false;

	Random rand = new Random();
	byte[] buf = new byte[BUFSIZ];
	long length = file.length();
	RandomAccessFile raf = new RandomAccessFile(file, "rw");
	try {
		for (int i=0; i<10; i++) {
			for (long togo = length; togo > 0; togo -= buf.length) {
				rand.nextBytes(buf);
				raf.write(buf, 0, (int)Math.min(togo, buf.length));
			}
		}
	} finally { raf.close(); }

	return file.delete();
  }
}
