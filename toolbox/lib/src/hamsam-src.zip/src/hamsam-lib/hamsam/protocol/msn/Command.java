/*
 * Please see COPYING for license details
 *
 * Copyright (C) 2003 Raghu K, All rights reserved.
 */

package hamsam.protocol.msn;

class Command extends AbstractCommand
{
	/**
	 * Construct a command with the given type identifier.
	 *
	 * @param type type identifier for this command.
	 */
	Command(String type)
	{
		super(type);
	}

	/**
	 * Returns a string representation of this command. The returned string is
	 * composed by appending the following components separated by space character.
	 *
	 * <ul>
	 * 	<li>Command type.</li>
	 * 	<li>Transaction ID, if available.</li>
	 * 	<li>All the parameters separated by space characters.</li>
	 * </ul>
	 *
	 * The string is terminated by a CRLF.
	 *
	 * @return string representation of this command
	 */
	public String toString()
	{
		return super.toString() + "\r\n";
	}
}
