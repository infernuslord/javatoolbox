package tool.pdf;

import java.io.IOException;
import java.io.File;
import java.io.PrintStream;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

import multivalent.ParseException;
import multivalent.std.adaptor.pdf.*;
import static multivalent.std.adaptor.pdf.COS.*;

import phelps.io.FileList;
import phelps.lang.Integers;



/**
	Stamp and watermark pages from source PDF into destination PDF, creating new PDF.

	Copyright (c) 2003  Thomas A. Phelps
	@version $Revision: 1.1 $ $Date: 2003/10/01 14:01:23 $
*/
public class Stamp {
  static final boolean DEBUG = true && multivalent.Multivalent.DEVEL;

  public static final String VERSION = "1.0 of $Date: 2003/10/01 14:01:23 $";
  public static final String USAGE = "java tool.pdf.Stamp [-page <range>] [-password] <PDF-file>";

  private String range_;
  private String password_;
  private boolean fverbose_, fquiet_, fmonitor_;
  private PrintStream out_;

  public Stamp() {
	defaults();
  }

  public void defaults() {
	range_ = null;
	password_ = null;

	out_ = phelps.io.PrintStreams.DEVNULL;
	fverbose_ = fquiet_ = fmonitor_ = false;
  }

  public void setOut(PrintStream out) { out_ = out!=null? out: phelps.io.PrintStreams.DEVNULL; }
  public void setRange(String range) { range_ = range; }
  public void setPassword(String password) { password_ = password; }


  public void split(File file) throws IOException,ParseException {
	String path = file.getPath();
	String pathout = (path.toLowerCase().endsWith(".pdf")? path.substring(0, path.length()-4): path) + "-s.pdf";
	split(file, new File(pathout));
  }

  public void split(File in, File out) throws IOException,ParseException {
	if (!fquiet_) out_.println(in);

	PDFReader pdfr = new PDFReader(in);
	pdfr.setPassword(password_);
	PDFWriter pdfw = new PDFWriter(out, pdfr);
	pdfw.setPassword(password_);

	int[] range = Integers.parseRange(range_, 0,pdfr.getPageCnt());
	int pagecnt = pdfr.getPageCnt();

	// partial merge
	// splice into /Contents, inserting watermark after existing background

	//pdfw.resetPageTree(l);
	//pdfw.fault(); => done implicitly by refcntRemove()
	pdfw.refcntRemove();
	pdfw.liftPageTree();
	pdfw.writePDF();
	pdfw.close();
  }



  private int commandLine(String[] argv) {
	out_ = System.out;

	int argi = 0, argc = argv.length;
	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.startsWith("-page") || arg.startsWith("-range")) setRange(argv[++argi]);
		else if (arg.startsWith("-pass"/*"word"*/)) setPassword(argv[++argi]);

		else if (arg.startsWith("-verb")) { fverbose_ = true; fquiet_ = false; }
		else if (arg.startsWith("-mon"/*itor*/)) { fmonitor_ = fverbose_ = true; fquiet_ = false; }
		else if (arg.startsWith("-q"/*uiet*/)) { fquiet_ = true; fmonitor_ = fverbose_ = false; }
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.startsWith("-h"/*"elp"*/)) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	if (argi == argc) { System.err.println(USAGE); System.exit(0); }

	return argi;
  }

  public static void main(String[] argv) {
	Stamp split = new Stamp();
    int argi = split.commandLine(argv);

	// I suppose it could be useful to split off the same pages from lots of PDFs
	for (Iterator<File> i = new FileList(argv, argi, FILTER).iterator(); i.hasNext(); ) {
		File file = i.next();
		try {
			split.split(file);
		} catch (Exception ioe) {
			System.err.println(file+": "+ioe);
			if (DEBUG) ioe.printStackTrace();
			System.exit(1);
		}
	}
  }
}
