/*
 * Please see COPYING for license details
 *
 * Copyright (C) 2003 Raghu K, All rights reserved.
 */

package hamsam.protocol.yahoo;

import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.IOException;
import hamsam.net.Connection;
import hamsam.util.log.LogManager;

/**
 * A thread to send all outgoing packets to Yahoo.
 *
 * @author Raghu
 */
public class WriterThread extends Thread
{
	/**
	 * The connection used for writing.
	 */
	private Connection conn;

	/**
	 * The buffer from which to read.
	 */
	private Vector buffer;

	/**
	 * Flag to stop this thread.
	 */
	private boolean quit;

	/**
	 * The parent YahooProtocol thread that created this writer thread.
	 */
	private YahooProtocol protocol;

	/**
	 * Construct a new writer thread which reads from a specified buffer and
	 * writes to a specified connection.
	 *
	 * @param protocol the parent YahooProtocol thread that created this writer thread.
	 * @param conn the connection for writing.
	 * @param buffer the buffer from which to get the packets.
	 */
	public WriterThread(YahooProtocol protocol, Connection conn, Vector buffer)
	{
		this.protocol = protocol;
		this.conn = conn;
		this.buffer = buffer;
		this.quit = false;
		setName("hamsam.protocol.yahoo.WriterThread");
	}

	/**
	 * Change the connection object and start using a new one. This
	 * will close the old connection if it is not already closed.
	 *
	 * @param conn the new connection object.
	 */
	public void changeConnection(Connection conn)
	{
		synchronized(this.conn)
		{
			try
			{
				this.conn.close();
			}
			catch(IOException e)
			{
				/* we may get an exception because the connection is already closed */
			}

			this.conn = conn;
		}
	}

	/**
	 * The thread starts here.
	 */
	public void run()
	{
		Logger logger = LogManager.getLogger();
		while(!quit)
		{
			Packet pack = null;

			synchronized(buffer)
			{
				try
				{
					if(buffer.size() > 0)
						pack = (Packet) buffer.remove(0);
					else
						buffer.wait(15000);
				}
				catch(InterruptedException e)
				{
					/* nothing to do here */
				}
			}

			try
			{
				if(pack != null)
				{
					String msg = "Client: " + pack.toString();
					logger.logp(Level.INFO, this.getClass().getName(), "run", msg);
				
					conn.write(pack.toBytes());
				}
			}
			catch(IOException e)
			{
				protocol.shutdown(e);
				return;
			}
		}
	}

	/**
	 * Stop this thread safely.
	 */
	public void stopWriting()
	{
		quit = true;
		this.interrupt();
	}
}
