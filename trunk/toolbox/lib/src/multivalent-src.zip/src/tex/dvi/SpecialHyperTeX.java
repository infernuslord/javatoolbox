package tex.dvi;

import java.net.URI;
//import java.net.MalformedURLException;
import java.awt.Point;
import java.util.HashMap;
import java.util.Map;

import multivalent.*;
import multivalent.std.span.HyperlinkSpan;
import multivalent.std.ui.Multipage;



/**
	Media adaptor for <a href='http://xxx.lanl.gov/hypertex/'>HyperTeX</a>,
	which adds hyperlinks and images (PNG/JPG/GIF/...) to TeX DVI.

	@see tex.dvi.DVI

	@version $Revision: 1.7 $ $Date: 2003/06/01 07:44:53 $
*/
public class SpecialHyperTeX extends Behavior {
  URI curbase_ = null;
  Map<String,String> anchors_ = new HashMap<String,String>(100);    // all pages, not same as doc.getGlobal(Document.VAR_ANCHORS) which has current page only
  boolean fscanned_ = false;
  Layer scratchLayer_ = null; // should fetch fresh every time...

  private Span curspan_=null;     // save open waiting for close.  nesting not allowed


  public void restore(ESISNode n, Map<String,Object> attr, Layer layer) {
	super.restore(n,attr, layer);
	Document doc = getDocument();
	curbase_ = doc.getURI();
	scratchLayer_ = doc.getLayer(Layer.SCRATCH);
  }

  /** Get event from DVI parser. */
  public boolean semanticEventBefore(SemanticEvent se, String msg) {
	if (super.semanticEventBefore(se,msg)) return true;
	if (DVI.MSG_SPECIAL!=msg /*|| se.getOut()==null/*scanning*/) return false;
	Object arg = se.getArg();
//System.out.println("HyperTeX "+msg+" "+arg+", in="+se.getIn()+", out="+se.getOut());
	if (arg==null || !(arg instanceof String)) return false;
	String sarg = (String)arg;
	if (!sarg.startsWith("html:") || sarg.length()<4+1+1) return false;  // "html" + ":" + at least one character
	Point pt = (Point)se.getOut();
	Node lastn = null;
	String spage = null;
	if (pt!=null) lastn = (Node)se.getIn(); else spage=(String)se.getIn();

	String special = sarg.substring("html:".length()), scmp = special.toLowerCase();
//System.out.println(" => "+special);

	if (pt==null) { // scanning
		fscanned_ = true;
		if (scmp.startsWith("<a name=")) {   // \special{html:<a name="namestring">}
			String name = getHyperAttr(special);
			anchors_.put(name, spage);
//System.out.println("a name |"+name+"| = "+spage);
		}

	} else if (scmp.startsWith("<a href=")) {  // \special{html:<a href="hrefstring">}
//System.out.println(scmp+" @ "+lastn.getName()+"/"+lastn.getClass().getName()+", "+lastn.hashCode());
		String href = getHyperAttr(special);
		curspan_ = (Span)Behavior.getInstance("hyperlink","HyperlinkSpan", null, scratchLayer_);
		((HyperlinkSpan)curspan_).setTarget(href);
//System.out.println(scmp+" "+lastn);
		curspan_.open(lastn);   // ok if lastn is null
		// need to deal with intrapage references.  have to scan page by page? (then cache findings?)

	} else if (scmp.startsWith("<a name=")) {   // \special{html:<a name="namestring">}
//System.out.println(scmp+" @ "+lastn.getName());
		String name = getHyperAttr(special);
		//curspan_ = (Span)Behavior.getInstance("anchor","AnchorSpan", null, scratchLayer_);
		curspan_ = (Span)Behavior.getInstance("anchor","multivalent.Span", null, scratchLayer_);
		curspan_.putAttr("id", name); curspan_.removeAttr("name");  // canonicalize
		curspan_.open(lastn);
//System.out.println("name start = "+lastn.getName());

	} else if (scmp.startsWith("</a>")) {   // \special{html:</a>} -- ever cross pages?
		if (curspan_ != null) {
			if (lastn!=null) curspan_.close(lastn);     // <a name="page.1"></a> at start of page
//System.out.println(scmp+" @ "+lastn.getName()+", "+lastn.hashCode());
			curspan_=null;
		}

	} else if (scmp.startsWith("<img src=")) { // \special{html:<img src="hrefstring">}
		String src = getHyperAttr(special);
		// no problem!  need test data... anybody use it?
		//new FixedLeafImage("img",null, xxx, src)

	} else if (scmp.startsWith("<base href=")) {    // \special{html:<base href="hrefstring">}
		String href = getHyperAttr(special);
		try { curbase_ = curbase_.resolve(href); } catch (IllegalArgumentException ignore) {}

	} //else System.err.println("unrecognized HyperTeX: "+special); -- perhaps some other behavior will recognize

	return false;   // probably no other behavior interested, but maybe so
  }


  /** Handle internal hyperlink references. */
  public boolean semanticEventAfter(SemanticEvent se, String msg) {
	if (Document.MSG_OPEN==msg) {
		Browser br = getBrowser();
		Object arg = se.getArg();
//System.out.println("HyperTeX openDocument on "+arg);

		// internal ref?
		if (arg instanceof String && ((String)arg).startsWith("#")) {
			String ref = ((String)arg).substring(1);    // chop off '#'
//System.out.println("HyperTeX internal ref: "+ref);

			// already seen?
			String spage = anchors_.get(ref);

			// try full scan, if necessary, on demand
			if (spage==null && !fscanned_) {
				br.event(new SemanticEvent(br, DVI.MSG_SCAN, null));
				spage = anchors_.get(ref);
//System.out.println("after scan spage="+spage);
			}

			if (spage!=null) {
				br.eventq(Multipage.MSG_GOPAGE, spage);
				//br.eventq(IScrollPane.MSG_SCROLL_TO, ref);     // not available until buildAfter / "formatted" -- maybe tack onto GOPAGE?
//System.out.println("found at page "+spage);
			}

			return true;    // short-circuit as nobody else can figure it out
		}

	}

	return super.semanticEventAfter(se,msg);
  }


  /** Pluck attribute out of HyperTeX string. */
  String getHyperAttr(String from) {
	String attr=null;
	int eqinx=from.indexOf('='), len=from.length();
	if (eqinx!=-1) {
		int sinx = eqinx+1, einx=len;
		int gtinx = from.lastIndexOf(">"); if (gtinx!=-1) einx=gtinx;
		int qinx = from.indexOf('"', sinx);
		if (qinx!=-1) { // quoted
			sinx = qinx+1;
			int cqinx = from.indexOf('"', sinx);
			if (cqinx!=-1) einx=cqinx;
		} else { // else ends in a space
			int spinx = from.indexOf(' ',sinx);
			if (spinx!=-1) einx = spinx;
		}
		attr = from.substring(sinx, einx);
	}

	return attr;
  }
}
