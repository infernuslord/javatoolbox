// $Id: Name.java,v 1.1 2002/04/25 18:12:58 bill Exp $

package com.jclark.xsl.om;

/**
 * Names are the same if they have the same namespace, local part and
 * creator.
 */
public interface Name 
{
    static String XML_NAMESPACE = "http://www.w3.org/XML/1998/namespace";

    /**
     * get the URI reference that is the namespace
     */
    String getNamespace();

    /**
     * get the part of the name that has no prefix
     */
    String getLocalPart();

    /**
     * get the prefix
     */
    String getPrefix();

    /**
     * uhh, ... I dunno
     */
    Object getCreator();
}
