/**
 * L2FProd.com Common Components 0.1-dev License.
 *
 * Copyright 2004 L2FProd.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.l2fprod.common.swing.plaf.basic;

import com.l2fprod.common.swing.plaf.LookAndFeelAddons;

import java.awt.Color;
import java.awt.Font;
import java.awt.SystemColor;

import javax.swing.UIDefaults;
import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;

/**
 * Install simple pluggable UI. Usually not used directly, subclasses should be
 * preferred as this addon may not provide complete implementation of the
 * additionnal pluggable UIs.
 */
public class BasicLookAndFeelAddons extends LookAndFeelAddons {

  public void initialize() {
    super.initialize();

    Color menuBackground = new ColorUIResource(SystemColor.menu);

    Object[] defaults =
      {
        "FontChooserUI",
        BasicFontChooserUI.class.getName(),
        "ButtonBarUI",
        BasicButtonBarUI.class.getName(),
        "LinkButtonUI",
        BasicLinkButtonUI.class.getName(),
        "TaskPaneUI",
        BasicTaskPaneUI.class.getName(),
        "TaskPane.background",
        UIManager.getColor("List.background"),
        "TaskPaneGroupUI",
        BasicTaskPaneGroupUI.class.getName(),
        "TaskPaneGroup.font",
        new FontUIResource(
          UIManager.getFont("Label.font").deriveFont(Font.BOLD)),
        "TaskPaneGroup.background",
        UIManager.getColor("List.background"),
        "TaskPaneGroup.specialTitleBackground",
        new ColorUIResource(menuBackground.darker()),
        "TaskPaneGroup.titleBackgroundGradientStart",
        menuBackground,
        "TaskPaneGroup.titleBackgroundGradientEnd",
        menuBackground,
        "TaskPaneGroup.titleForeground",
        new ColorUIResource(SystemColor.menuText),
        "TaskPaneGroup.specialTitleForeground",
        new ColorUIResource(SystemColor.menuText).brighter(),
        "TaskPaneGroup.focusInputMap",
        new UIDefaults.LazyInputMap(
          new Object[] {
            "ENTER",
            "toggleExpanded",
            "SPACE",
            "toggleExpanded" }),
        };
    loadDefaults(defaults);
  }

}
