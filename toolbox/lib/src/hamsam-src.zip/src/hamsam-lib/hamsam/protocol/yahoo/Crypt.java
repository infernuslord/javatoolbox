/*
 * Please see COPYING for license details
 *
 * Copyright (C) 2003 Raghu K, All rights reserved.
 */

package hamsam.protocol.yahoo;

public class Crypt
{
	private static final char[] base64Digits = {
		'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
		'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T',
		'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd',
		'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
		'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x',
		'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7',
		'8', '9', '.', '_'
	};
	private String yahooId, password;
	char[] seed;

	public Crypt(String yahooId, String password, String seed, String sn)
				throws NullPointerException
	{
		if(seed == null)
			throw new NullPointerException("seed is null");
		if(yahooId == null)
			throw new NullPointerException("yahooId is null");
		this.yahooId = new String(yahooId);
		this.password = new String(password);
		this.seed = seed.toCharArray();
	}

	public String[] doEncrypt()
	{
		MD5 md5 = new MD5();

		md5.append(password);
		char[] result = md5.finish();
		char[] passwordHash = toBase64(result);
		
		md5 = new MD5();
		String cryptResult = crypt(password, "$1$_2S43d5f$");
		md5.append(cryptResult);
		result = md5.finish();
		char[] cryptHash = toBase64(result);

		int sv = seed[15] % 8;
		char checksum = 0;
		String hashStringP = null, hashStringC = null;
		switch(sv % 5)
		{
			case 0:
				checksum = (char)(seed[seed[7] % 16] & 0xff);
				hashStringP = String.valueOf(checksum) + new String(passwordHash) +
								yahooId + new String(seed);
				hashStringC = String.valueOf(checksum) + new String(cryptHash) +
								yahooId + new String(seed);
				break;
			case 1:
				checksum = (char)(seed[seed[9] % 16] & 0xff);
				hashStringP = String.valueOf(checksum) + yahooId + new String(seed) +
								new String(passwordHash);
				hashStringC = String.valueOf(checksum) + yahooId + new String(seed) +
								new String(cryptHash);
				break;
			case 2:
				checksum = (char)(seed[seed[15] % 16] & 0xff);
				hashStringP = String.valueOf(checksum) + new String(seed) +
								new String(passwordHash) + yahooId;
				hashStringC = String.valueOf(checksum) + new String(seed) +
								new String(cryptHash) + yahooId;
				break;
			case 3:
				checksum = (char)(seed[seed[1] % 16] & 0xff);
				hashStringP = String.valueOf(checksum) + yahooId +
								new String(passwordHash) + new String(seed);
				hashStringC = String.valueOf(checksum) + yahooId +
								new String(cryptHash) + new String(seed);
				break;
			case 4:
				checksum = (char)(seed[seed[3] % 16] & 0xff);
				hashStringP = String.valueOf(checksum) + new String(passwordHash) +
								new String(seed) + yahooId;
				hashStringC = String.valueOf(checksum) + new String(cryptHash) +
								new String(seed) + yahooId;
				break;
		}
		
		md5 = new MD5();
		md5.append(hashStringP);
		result = md5.finish();
		char[] result6 = toBase64(result);

		md5 = new MD5();
		md5.append(hashStringC);
		result = md5.finish();
		char[] result96 = toBase64(result);

		String ret[] = new String[2];
		ret[0] = new String(result6);
		ret[1] = new String(result96);
		return ret;
	}

	private char[] toBase64(char[] in)
	{
		int len = in.length;
		char[] out = new char[24];
		int index = 0;

		int i = 0;
		for(; len >= 3; len -= 3)
		{
			out[index++] = base64Digits[in[i] >>> 2];
			out[index++] = base64Digits[((in[i] << 4) & 0x30) | (in[i + 1] >>> 4)];
			out[index++] = base64Digits[((in[i + 1] << 2) & 0x3c) | (in[i + 2] >>> 6)];
			out[index++] = base64Digits[in[i + 2] & 0x3f];
			i += 3;
		}

		if(len > 0)
		{
			char fragment;

			out[index++] = base64Digits[in[i] >>> 2];
			fragment = (char)((in[i] << 4) & 0x30);
			if (len > 1)
				fragment |= in[i + 1] >>> 4;
			out[index++] = base64Digits[fragment];
			out[index++] = (len < 2) ? '-'
					: base64Digits[(in[i + 1] << 2) & 0x3c];
			out[index++] = '-';
		}

		return out;
	}

	private String crypt(String key, String salt)
	{
		String md5SaltPrefix = "$1$";
		String buffer = new String();
		int buflen = 3 + salt.length() + 1 + 26 + 1;

		char alt_result[];
		MD5 ctx, alt_ctx;
		int salt_len, key_len, cnt;
		String cp;

		/* Find beginning of salt string.  The prefix should normally always
		be present.  Just in case it is not. */
		if(salt.startsWith(md5SaltPrefix))
			/* Skip salt prefix.  */
			salt = salt.substring(md5SaltPrefix.length());

		salt_len = salt.indexOf('$');
		if(salt_len == -1)
			salt_len = salt.length();
		if(salt_len > 8)
			salt_len = 8;
		key_len = key.length();

		/* Prepare for the real work. */
		ctx = new MD5();

		/* Add the key string. */
		ctx.append(key);

		/* Because the SALT argument need not always have the salt prefix we
		add it separately.  */
		ctx.append(md5SaltPrefix);

		/* The last part is the salt string.  This must be at most 8
		characters and it ends at the first `$' character (for
		compatibility which existing solutions).  */
		ctx.append(salt, salt_len);

		/* Compute alternate MD5 sum with input KEY, SALT, and KEY.  The
		final result will be added to the first context.  */
		alt_ctx = new MD5();

		/* Add key.  */
		alt_ctx.append(key);

		/* Add salt.  */
		alt_ctx.append(salt, salt_len);

		/* Add key again.  */
		alt_ctx.append(key);

		/* Now get result of this (16 bytes) and add it to the other
	   	context.  */
		alt_result = alt_ctx.finish();

		/* Add for any character in the key one byte of the alternate sum.  */
		for(cnt = key.length(); cnt > 16; cnt -= 16)
			ctx.append(alt_result, 16);
		ctx.append(alt_result, cnt);

		/* For the following code we need a NUL byte.  */
		alt_result[0] = 0;

		/* The original implementation now does something weird: for every 1
		bit in the key the first 0 is added to the buffer, for every 0
		bit the first character of the key.  This does not seem to be
		what was intended but we have to follow this to be compatible.  */
		for(cnt = key.length(); cnt > 0; cnt >>= 1)
		{
			if((cnt & 1) != 0)
				ctx.append(alt_result, 1);
			else
				ctx.append(key, 1);
		}

		/* Create intermediate result.  */
		alt_result = ctx.finish();

		/* Now comes another weirdness.  In fear of password crackers here
		comes a quite long loop which just processes the output of the
		previous round again.  We cannot ignore this here.  */
		for(cnt = 0; cnt < 1000; ++cnt)
		{
			/* New context.  */
			ctx = new MD5();

			/* Add key or last result.  */
			if((cnt & 1) != 0)
				ctx.append(key);
			else
				ctx.append(alt_result, 16);

			/* Add salt for numbers not divisible by 3.  */
			if(cnt % 3 != 0)
				ctx.append(salt, salt_len);

			/* Add key for numbers not divisible by 7.  */
			if(cnt % 7 != 0)
				ctx.append(key);

			/* Add key or last result.  */
			if((cnt & 1) != 0)
				ctx.append(alt_result, 16);
			else
				ctx.append(key);

			/* Create intermediate result.  */
			alt_result = ctx.finish();
		}

		/* Now we can construct the result string.  It consists of three
		parts. */

		buffer += md5SaltPrefix + salt;

		buffer += b64From24Bit(alt_result[0], alt_result[6], alt_result[12], 4);
		buffer += b64From24Bit(alt_result[1], alt_result[7], alt_result[13], 4);
		buffer += b64From24Bit(alt_result[2], alt_result[8], alt_result[14], 4);
		buffer += b64From24Bit(alt_result[3], alt_result[9], alt_result[15], 4);
		buffer += b64From24Bit(alt_result[4], alt_result[10], alt_result[5], 4);
		buffer += b64From24Bit((char)0, (char)0, alt_result[11], 2);

		/* do we need this in Java? I dont think so
		 
		 *cp = '\0';	/* Terminate the string.  */

		/* Clear the buffer for the intermediate result so that people
		attaching to processes or reading core dumps cannot get any
		information.  We do it in this way to clear correct_words[]
		inside the MD5 implementation as well.  */
		
		/* do we need this in Java? I dont think so
		
		md5_init(&ctx);
		md5_finish(&ctx, alt_result);
		memset (&ctx, '\0', sizeof (ctx));
		memset (&alt_ctx, '\0', sizeof (alt_ctx)); */

		return buffer;
	}

	private String b64From24Bit(char b2, char b1, char b0, int count)
	{
		String b64t = "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
		String ret = new String();
		int w = (b2 << 16) | (b1 << 8) | b0;
		while(count-- > 0)
		{
			ret += b64t.charAt(w & 0x3f);
			w >>>= 6;
		}

		return ret;
	}
}
