/*
 * ====================================================================
 * 
 * L2FProd.com Common Components 0.1-dev License.
 * 
 * Copyright (c) 2004 L2FProd.com. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met: 1.
 * Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer. 2. Redistributions in
 * binary form must reproduce the above copyright notice, this list of
 * conditions and the following disclaimer in the documentation and/or other
 * materials provided with the distribution. 3. The end-user documentation
 * included with the redistribution, if any, must include the following
 * acknowlegement: "This product includes software developed by L2FProd.com
 * (http://www.L2FProd.com/)." Alternately, this acknowlegement may appear in
 * the software itself, if and wherever such third-party acknowlegements
 * normally appear. 4. The names "L2FProd.com Common Components", "l2fprod-common"
 * and "L2FProd.com" must not be used to endorse or promote products derived
 * from this software without prior written permission. For written permission,
 * please contact info@L2FProd.com. 5. Products derived from this software may
 * not be called "l2fprod-common" nor may "l2fprod-common" appear in
 * their names without prior written permission of L2FProd.com.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
 * L2FPROD.COM OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package com.l2fprod.common.swing;

import java.awt.Color;
import java.awt.Component;
import java.util.Hashtable;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.UIResource;

/**
 * StatusBar. <BR>A status bar is made of multiple zones. A zone can be any
 * JComponent.
 */
public class StatusBar extends JComponent {

  /**
   * The key used to identified the default zone
   */
  public final static String DEFAULT_ZONE = "default";

  private Hashtable idToZones;
  private Border zoneBorder;

  /**
   * Construct a new StatusBar
   *  
   */
  public StatusBar() {
    setLayout(LookAndFeelTweaks.createHorizontalPercentLayout());
    idToZones = new Hashtable();
    setZoneBorder(BorderFactory.createLineBorder(Color.gray));
  }

  public void setZoneBorder(Border border) {
    zoneBorder = border;
  }

  /**
   * Adds a new zone in the StatusBar
   * 
   * @param id
   * @param zone
   * @param constraints one of the constraint support by the
   *          {@link com.l2fprod.common.swing.PercentLayout}
   */
  public void addZone(String id, Component zone, String constraints) {
    // is there already a zone with this id?
    Component previousZone = getZone(id);
    if (previousZone != null) {
      remove(previousZone);
      idToZones.remove(id);
    }

    if (zone instanceof JComponent) {
      JComponent jc = (JComponent)zone;
      if (jc.getBorder() == null || jc.getBorder() instanceof UIResource) {
        if (jc instanceof JLabel) {
          jc.setBorder(
            new CompoundBorder(zoneBorder, new EmptyBorder(0, 2, 0, 2)));
          ((JLabel)jc).setText(" ");
        } else {
          jc.setBorder(zoneBorder);
        }
      }
    }

    add(zone, constraints);
    idToZones.put(id, zone);
  }

  public Component getZone(String id) {
    return (Component)idToZones.get(id);
  }

  /**
   * For example:
   * 
   * <pre>
   *  setZones(new String[]{"A","B"}, new String[]{"33%","*"}, new JComponent[]{new JLabel(), new JLabel()}) would construct a new status bar with two zones (two JLabels) named A and B, the first zone A will occupy 33 percents of the overall size of the status bar and B the left space.
   * </pre>
   * 
   * @param zones a value of type 'String[]'
   * @param sizes a value of type 'String[]'
   * @param components a value of type 'JComponent[]'
   */
  public void setZones(String[] ids, Component[] zones, String[] constraints) {
    removeAll();
    idToZones.clear();
    for (int i = 0, c = zones.length; i < c; i++) {
      addZone(ids[i], zones[i], constraints[i]);
    }
  }

}
