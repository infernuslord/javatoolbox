/**
 * A sample client for Hamsam, written mostly for debugging.
 *
 * @author Raghu
 */

import java.io.*;
import java.util.*;
import java.util.logging.*;
import hamsam.protocol.*;
import hamsam.api.*;
import hamsam.net.*;
import hamsam.util.log.LogManager;

public class TestClient
{
	private Protocol[] protocols;
	private Protocol prot;
	private Conference conf;

	public TestClient() throws Exception
	{
		Logger logger = LogManager.getLogger();
		Handler handler = new FileHandler("hamsam.log");
		handler.setFormatter(new SimpleFormatter());
		logger.addHandler(handler);

		BufferedReader rd = new BufferedReader(new InputStreamReader(System.in));
		protocols = ProtocolManager.getAvailableProtocols();
		prot = selectProtocol(protocols, rd);
		prot.setListener(new MyIMListener(this));

		String username = System.getProperty("hamsam.testclient.username");
		String password = System.getProperty("hamsam.testclient.password");

		if(username == null || password == null)
		{
			System.out.print("Username: ");
			username = rd.readLine();

			PasswordField passfield = new PasswordField();
			password = passfield.getPassword("Password: ");
		}

		String proxyType = System.getProperty("hamsam.testclient.proxyType");
		String proxyHost = System.getProperty("hamsam.testclient.proxyHost");
		String proxyPort = System.getProperty("hamsam.testclient.proxyPort");
		String proxyUsername = System.getProperty("hamsam.testclient.proxyUsername");
		String proxyPassword = System.getProperty("hamsam.testclient.proxyPassword");

		ProxyInfo info;
		if("SOCKS4".equals(proxyType))
			info = new ProxyInfo(ProxyInfo.SOCKS4, proxyHost, Integer.parseInt(proxyPort));
		else if("SOCKS5".equals(proxyType))
		{
			info = new ProxyInfo(ProxyInfo.SOCKS5, proxyHost, Integer.parseInt(proxyPort));
			info.setUsername(proxyUsername);
			info.setPassword(proxyPassword);
		}
		else if("HTTP".equals(proxyType))
		{
			info = new ProxyInfo(ProxyInfo.HTTP, proxyHost, Integer.parseInt(proxyPort));
			info.setUsername(proxyUsername);
			info.setPassword(proxyPassword);
		}
		else
			info = new ProxyInfo();

		prot.connect(username, password, info);
	}

	public static void main(String[] args) throws Exception
	{
		TestClient client = new TestClient();
		boolean done = false;

		while(!done)
		{
			String[] words = client.getCommand();
			done = client.processCommand(words);
		}
	}

	private Protocol selectProtocol(Protocol[] protocols, BufferedReader rd) throws IOException
	{
		System.out.println("Available protocols:");
		for(int i = 0; i < protocols.length; i++)
			System.out.println("" + (i + 1) + ". " + protocols[i].getProtocolName());
		System.out.println();
		System.out.print("Select your choice [1]: ");

		String line = rd.readLine();
		if(line.equals(""))
			line = "1";
		int choice = Integer.parseInt(line);
		System.out.println("Using " + protocols[choice - 1].getProtocolName() + " protocol");
		return protocols[choice - 1];
	}

	private String[] getCommand() throws IOException
	{
		BufferedReader rd = new BufferedReader(new InputStreamReader(System.in));
		String line = rd.readLine();

		StringTokenizer tok = new StringTokenizer(line);
		String[] ret = new String[tok.countTokens()];
		for(int i = 0; tok.hasMoreTokens(); i++)
			ret[i] = tok.nextToken();

		return ret;
	}

	private boolean processCommand(String[] words) throws Exception
	{
		if(words.length < 1)
			return false;

		if(words[0].equals("msg"))
		{
			if(words.length >= 3)
			{
				String msgText = new String();
				for(int i = 2; i < words.length; i++)
					msgText += words[i] + " ";

				Buddy buddy = new Buddy(prot, words[1]);
				Message msg = new Message();
				msg.addComponent(new TextComponent(msgText));

				prot.sendInstantMessage(buddy, msg);
			}
		}
		else if(words[0].equals("add"))
		{
			if(words.length == 2)
			{
				Buddy buddy = new Buddy(prot, words[1], "Friends");
				buddy.addToBuddyList();
			}
		}
		else if(words[0].equals("del"))
		{
			if(words.length == 2)
			{
				Buddy buddy = new Buddy(prot, words[1], "~");
				buddy.deleteFromBuddyList();
			}
		}
		else if(words[0].equals("ign"))
		{
			if(words.length == 2)
			{
				Buddy buddy = new Buddy(prot, words[1]);
				buddy.ignore();
			}
		}
		else if(words[0].equals("uign"))
		{
			if(words.length == 2)
			{
				Buddy buddy = new Buddy(prot, words[1]);
				buddy.unignore();
			}
		}
		else if(words[0].equals("cnf"))
		{
			if(words.length > 2)
			{
				Buddy myself = new Buddy(prot, words[1]);
				Buddy[] buddies = new Buddy[words.length - 1];
				for(int i = 0; i < buddies.length; i++)
					buddies[i] = new Buddy(prot, words[i + 1]);
				String message = "Friends, Romans, and Countrymen, lend me your IMs";
				conf = new Conference(prot, myself, buddies, message);
			}
		}
		else if(words[0].equals("cmsg"))
		{
			if(words.length == 2)
			{
				Message msg = new Message();
				msg.addComponent(new TextComponent(words[1]));

				conf.sendMessage(msg);
			}
		}
		else if(words[0].equals("cnfq"))
		{
			conf.quit();
		}
		else if(words[0].equals("off"))
		{
			prot.disconnect();
			return true;
		}

		return false;
	}

	public void setConference(Conference conf)
	{
		this.conf = conf;
	}
}
