package tool;

import java.io.IOException;
import java.io.File;
import java.io.PrintStream;
import java.io.FileFilter;
import java.util.Iterator;
import java.util.Observer;
import java.util.Observable;

import phelps.io.FileLog;
import phelps.io.FileLogRecord;
import phelps.io.Files;
import phelps.io.FileList;
import phelps.io.FileFilterPattern;
import phelps.util.Dates;
import phelps.util.Arrayss;



/**
	Log file system activity: new files, deleted, moved, duplicate, changed.

	@version $Revision: 1.1 $ $Date: 2004/01/23 08:17:19 $
*/
public class Log implements Observer {
  static final boolean DEBUG = true;

  public static final String VERSION = "1.0 of $Date: 2004/01/23 08:17:19 $";
  public static final String USAGE = "java tool.Log [options] <directory...>\n"
	+ "\t[-write <file>]\n"
	+ "\t[-filter <regex>]";
  static final int DATA_VERSION = 1;


  private File log_;
  private String[] paths_;
  private FileFilter ff_;
  private long now_;
  //private fnew_, fdeleted_; -- filter types before grep?

  private PrintStream out_;
  private boolean fverbose_, fquiet_, fmonitor_;


  public Log() {
	defaults();
  }

  public void defaults() {
	log_ = null;
	paths_ = null;
	ff_ = null;
	now_ = System.currentTimeMillis();

	fverbose_ = fquiet_ = fmonitor_ = false;
	out_ = phelps.io.PrintStreams.DEVNULL;
  }

  public void setLog(File file) { log_ = file; }


  public void log() throws IOException {
	//File home = new File(System.getProperty("user.home"));
	String[] normpaths = new String[paths_.length];
//System.out.println("canon="+new File(paths_[0]).getCanonicalFile()+", rel = "+Files.relative(null, new File(paths_[0]).getCanonicalFile()));
	for (int i=0,imax=paths_.length; i<imax; i++) normpaths[i] = Files.relative(null, new File(paths_[i]).getCanonicalFile());

	FileLog log = new FileLog(log_, normpaths, true, DATA_VERSION);

	log.update(this, ff_);

	if (log!=null) log.write();
  }


  public void update(Observable obs, Object arg) {
	Object[] oa = (Object[])arg;
	Object action = oa[0];
	FileLogRecord rec = (FileLogRecord)oa[1];
	FileLogRecord newrec = oa.length>=3? (FileLogRecord)oa[2]: null;
	File f = new File(rec.path);

	if (f.isDirectory()) {

	} else if (FileLog.ACTION_SAME == action) {
		// who cares

	} else if (FileLog.ACTION_NEW==action) {
		out_.println("NEW "+flm(rec));

	} else if (FileLog.ACTION_CHANGED==action) {
		if (!new File(rec.path).isDirectory()) out_.println("CHANGED "+flm(rec)+" => "+flm(newrec));

	} else if (FileLog.ACTION_DELETED==action) {
		out_.println("X "+flm(rec));

	} else if (FileLog.ACTION_MOVED==action) {
		out_.println("MOVED "+flm(rec)+" => "+flm(newrec));

	} else if (FileLog.ACTION_DUPLICATE==action) {
		//if (rec.length > 10) { out_.println("DUPLICATE "+flm(rec)); out_.println("      and "+flm(newrec)); }
		if (rec.length > 10) { out_.println("DUPLICATE "+flm(rec)+"  and  "+flm(newrec)); }	// for programmatic processing
	}
  }

  private String flm(FileLogRecord rec) {
	return Files.relative(null, new File(rec.path))+" / "+rec.length+" / "+Dates.relative(rec.mod, now_);
  }



  private int commandLine(String[] argv) {
	out_ = System.out;
	fverbose_ = true;

	int argi = 0, argc = argv.length;
	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.startsWith("-write")) setLog(new File(argv[++argi]));
		else if (arg.startsWith("-filter")) ff_ = new FileFilterPattern(argv[++argi]);
		//else if (arg.startsWith("-ignore")) *~, .DS_Store

		else if (arg.startsWith("-verb")) fverbose_ = true;
		//else if (arg.startsWith("-q"/*uiet*/)) fquiet = true;
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.startsWith("-h"/*"elp"*/)) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	if (argi == argc) { System.err.println(USAGE); System.exit(0); }
	paths_ = Arrayss.subset(argv, argi,argc-argi);

	return argi;
  }

  public static void main(String[] argv) {
	Log log = new Log();

	int argi = log.commandLine(argv);
	
	try {
		log.log();
	} catch (Exception e) {
		if (DEBUG) e.printStackTrace();
	}

	System.exit(0);
  }
}
