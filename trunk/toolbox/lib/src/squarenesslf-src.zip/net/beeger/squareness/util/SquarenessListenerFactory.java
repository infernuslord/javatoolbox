/*
  Copyright (C) 2003-2004 Robert F. Beeger (robert at beeger dot net)
  Licensed under the Academic Free License version 2.0
  OSI Certified Open Source Software

  Visit http://squareness.sourceforge.net/ for new releases of Squareness Look And Feel and other
  skins from the Squareness series.
*/
package net.beeger.squareness.util;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.AbstractButton;

import net.beeger.squareness.SquarenessConstants;

/**
 * SquarenessListenerFactory is a static factory that creates and manages all general purpose listeners used by
 * the Look And Feel such as the button rollover listener.
 */
public class SquarenessListenerFactory
{
  public static MouseListener getButtonRolloverMouseListener ()
  {
    if (_buttonRolloverMouseListener == null)
    {
      _buttonRolloverMouseListener = new ButtonRolloverMouseListener();
    }

    return _buttonRolloverMouseListener;
  }

  private static MouseListener _buttonRolloverMouseListener;

  private static class ButtonRolloverMouseListener extends MouseAdapter
  {
    /**
     * Invoked when the mouse enters a component.
     */
    public void mouseEntered (MouseEvent e)
    {
      AbstractButton button = ((AbstractButton) e.getSource());
      button.putClientProperty(SquarenessConstants.ROLLOVER_CLENT_PROPERTY_KEY, Boolean.TRUE);
      button.repaint();
    }

    /**
     * Invoked when the mouse exits a component.
     */
    public void mouseExited (MouseEvent e)
    {
      AbstractButton button = ((AbstractButton) e.getSource());
      button.putClientProperty(SquarenessConstants.ROLLOVER_CLENT_PROPERTY_KEY, Boolean.FALSE);
      button.repaint();
    }
  }
}

/*
  $Log: SquarenessListenerFactory.java,v $
  Revision 1.3  2004/02/14 19:14:48  rbeeger
  Updated copyright statement
  Added cvs log directive at the end of each file
  Optimized imports
  Reformated code

 */
