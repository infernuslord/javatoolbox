/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh.ext;

import java.awt.Color;
import java.awt.Component;

import javax.swing.UIManager;
import javax.swing.table.DefaultTableCellRenderer;

import com.shfarr.ui.GraphicsUtils;

public class FhTableCellRenderer extends DefaultTableCellRenderer implements javax.swing.plaf.UIResource{
	protected int crow = 0;
    protected boolean selected = false;

	public FhTableCellRenderer(){
		super();
	}

	public Color getBackground(){
	    if(crow % 2 != 0 && super.getBackground() != null) return new Color(GraphicsUtils.darker(super.getBackground().getRGB(), 0.02));
	    else return super.getBackground();
	}

    protected int getTextAlignment(Object value){
        if(value == null) return CENTER;
        else if(value instanceof Number) return RIGHT;
        else return LEFT;
    }
    
	public Component getTableCellRendererComponent(javax.swing.JTable table, Object value, boolean selected, boolean hasFocus, int row, int col){
        this.crow = row;
        this.selected = selected;
        
        Component c = super.getTableCellRendererComponent(table, value, selected, hasFocus, row, col);
        
        setHorizontalAlignment(getTextAlignment(value));
        
        if(c == this && value instanceof Boolean){
            setText(null);

            if(Boolean.TRUE.equals(value)) setIcon(UIManager.getIcon("CheckBox.selectedIcon"));
            else setIcon(UIManager.getIcon("CheckBox.unselectedIcon"));
        }
        else setIcon(null);
        
	    return c;
	}

    protected void setValue(Object value){
        setText((value == null) ? " ??? " : " " + value.toString() + " ");
    }
}