package com.thoughtworks.qdox.parser.structs;

public class LocatedDef {
	
	public int lineNumber;

}
