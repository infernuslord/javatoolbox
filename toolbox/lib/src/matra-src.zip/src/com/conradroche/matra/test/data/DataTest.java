/*
 *   The contents of this file are subject to the Mozilla Public License
 *   Version 1.1 (the "License"); you may not use this file except in
 *   compliance with the License. You may obtain a copy of the License at
 *   http://www.mozilla.org/MPL/
 *
 *   Software distributed under the License is distributed on an "AS IS"
 *   basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 *   License for the specific language governing rights and limitations
 *   under the License.
 *
 *   The Original Code is Matra - the DTD Parser.
 *
 *   The Initial Developer of the Original Code is Conrad S Roche.
 *   Portions created by Conrad S Roche are Copyright (C) Conrad 
 *   S Roche. All Rights Reserved.
 *
 *   Alternatively, the contents of this file may be used under the terms
 *   of the GNU GENERAL PUBLIC LICENSE Version 2 or any later version
 *   (the  "[GPL] License"), in which case the
 *   provisions of GPL License are applicable instead of those
 *   above.  If you wish to allow use of your version of this file only
 *   under the terms of the GPL License and not to allow others to use
 *   your version of this file under the MPL, indicate your decision by
 *   deleting  the provisions above and replace  them with the notice and
 *   other provisions required by the GPL License.  If you do not delete
 *   the provisions above, a recipient may use your version of this file
 *   under either the MPL or the GPL License."
 *
 *   [NOTE: The text of this Exhibit A may differ slightly from the text of
 *   the notices in the Source Code files of the Original Code. You should
 *   use the text of this Exhibit A rather than the text found in the
 *   Original Code Source Code for Your Modifications.]
 *
 * Created: Conrad S Roche <derupe at users.sourceforge.net>,  09-Aug-2003
 */
package com.conradroche.matra.test.data;

import com.conradroche.matra.data.Data;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * JUnit test case for the Data class.
 * 
 * @author Conrad Roche
 */
public class DataTest extends TestCase {

	/**
	 * The Data object being tested.
	 */
	protected Data data;
	
	/**
	 * The String that is being parsed for the test.
	 */
	protected String strData = "The \tcomplete \tstring \ncontaining the string to be parsed within \nit.";
	
	/**
	 * Constructor for DataTest.
	 * @param arg0
	 */
	public DataTest(String arg0) {
		super(arg0);
	}

	/**
	 * Setup the data for testing.
	 */
	protected void setUp() {

		data = new Data(strData);
	}

	/**
	 * Returns a test suite with DataTest.
	 * 
	 * @return
	 */
	public static Test suite() {

		TestSuite suite = new TestSuite();

		suite.addTestSuite(DataTest.class);

		return suite;
	}

	/**
	 * Test the Data::length() method.
	 */	
	public void testLength() {
		Assert.assertEquals(strData.length(), data.length());
	}
	
	/**
	 * Test the Data::checkNextChar(char) method.
	 */	
	public void testCheckNextChar() {
		
		for(int i = 0; i < data.length(); i++) {
			Assert.assertEquals(Data.FOUND_CHAR, data.checkNextChar(strData.charAt(i)));
			Assert.assertEquals(i + 1, data.getCurrentPosition());
		}
		//after End of Data
		Assert.assertEquals(Data.CHAR_NOT_FOUND, data.checkNextChar(' '));
		Assert.assertEquals(Data.CHAR_NOT_FOUND, data.checkNextChar(' '));
		Assert.assertEquals(Data.FOUND_CHAR, data.checkNextChar(Data.END_OF_DATA_CHAR));
		Assert.assertEquals(data.length(), data.getCurrentPosition());
	}
	
	/**
	 * Test the Data::endOfData() method.
	 */	
	public void testEndOfData() {
		
		for(int i = 0; i < data.length(); i++) {
			Assert.assertFalse(data.endOfData());
			data.getNextChar();
		}
		Assert.assertTrue(data.endOfData());
	}
	
	/**
	 * Test the Data::getNextChar() method.
	 */	
	public void testGetNextChar() {
		
		for(int i = 0; i < data.length(); i++) {
			Assert.assertEquals(strData.charAt(i), data.getNextChar());
		}
		
		//After End of Data
		Assert.assertEquals(Data.END_OF_DATA_CHAR, data.getNextChar());
		Assert.assertEquals(Data.END_OF_DATA_CHAR, data.getNextChar());
		Assert.assertEquals(data.length(), data.getCurrentPosition());
	}
	
	/**
	 * Test the Data::getPrevChar() method.
	 */	
	public void testGetPrevChar() {
		
		//before beginning of data
		Assert.assertEquals(Data.END_OF_DATA_CHAR, data.getPrevChar());

		for(int i = 0; i < data.length(); i++) {
			data.getNextChar();
			Assert.assertEquals(strData.charAt(i), data.getPrevChar());
		}
	}

	/**
	 * Test the Data::lookNextChar() method.
	 */	
	public void testLookNextChar() {
		
		for(int i = 0; i < data.length(); i++) {
			Assert.assertEquals(strData.charAt(i), data.lookNextChar());
			data.getNextChar();
		}
		
		//After End of Data
		Assert.assertEquals(Data.END_OF_DATA_CHAR, data.lookNextChar());
		Assert.assertEquals(Data.END_OF_DATA_CHAR, data.lookNextChar());
		Assert.assertEquals(data.length(), data.getCurrentPosition());
	}

	/**
	 * Perform checks to ensure that the cursor is 
	 * at the beginning of a non-null data.
	 */
	protected void checkIsDataBegin(Data theData) { 
		Assert.assertEquals(0, theData.getCurrentPosition());
		Assert.assertEquals(0, theData.getColumn());
		Assert.assertEquals(1, theData.getRow());
	}
	
	/**
	 * Test the Data::peekAhead(int) method.
	 */	
	public void testPeekAhead() {
		
		for(int i = 1; i <= data.length(); i++) {
			
			Assert.assertEquals(strData.charAt(i - 1), data.peekAhead(i));

			//peekAhead should not have an effect on position
			checkIsDataBegin(data);
		}
		
		//After End of Data
		Assert.assertEquals(Data.END_OF_DATA_CHAR, data.peekAhead(data.length() + 1));
		Assert.assertEquals(Data.END_OF_DATA_CHAR, data.peekAhead(data.length() + 2));
		checkIsDataBegin(data);

		//before begin of Data
		Assert.assertEquals(Data.END_OF_DATA_CHAR, data.peekAhead(-1));
		Assert.assertEquals(Data.END_OF_DATA_CHAR, data.peekAhead(0));
		
		data.getNextChar();
		data.getNextChar();
		
		for(int i = 0; i < data.length() - 2; i++) {
			Assert.assertEquals(strData.charAt(i + 1), data.peekAhead(i));
			Assert.assertEquals(2, data.getCurrentPosition());
		}
		
		//After End of Data
		Assert.assertEquals(Data.END_OF_DATA_CHAR, data.peekAhead(data.length() - 1));
		Assert.assertEquals(Data.END_OF_DATA_CHAR, data.peekAhead(data.length()));
		Assert.assertEquals(2, data.getCurrentPosition());
	}
	
	/**
	 * Test the Data::getRemaining() method.
	 */	
	public void testGetRemaining() {
		
		for(int i = 0; i < data.length(); i++) {
			Assert.assertEquals(strData.substring(i), data.getRemaining());
			Assert.assertEquals(i, data.getCurrentPosition());
			data.getNextChar();
		}
		
		//After End of Data
		Assert.assertNull(data.getRemaining());
		Assert.assertEquals(data.length(), data.getCurrentPosition());
	}

	/**
	 * Test the Data::toString() method.
	 */	
	public void testToString() {
		
		Assert.assertEquals(strData, data.toString());
		//toString() method should not effect location of cursor
		checkIsDataBegin(data);
	}
	
	/**
	 * Test the Data::reset() method.
	 */	
	public void testReset() {
		
		data.getNextChar();
		data.getNextChar();
		
		data.reset();
		checkEmptyData(data);
	}
	
	/**
	 * Test the Data::rewind() method.
	 */	
	public void testRewind() {
		
		data.getNextChar();
		data.getNextChar();
		data.rewind();
		
		checkIsDataBegin(data);
		Assert.assertEquals(strData, data.toString());
	}
	
	/**
	 * Test the Data::getRow() method.
	 */	
	public void testGetRow() {
		
		int enterLoc = strData.indexOf('\n');
		
		if(enterLoc != -1) {
			for(int i = 0; i <= enterLoc; i++) {
				data.getNextChar();
			}
			Assert.assertEquals(2, data.getRow());
		}
	}
	
	/**
	 * Test the Data::getColumn() method.
	 */	
	public void testGetColumn() {
		
		int enterLoc = strData.indexOf('\n');
		
		if(enterLoc == -1) enterLoc = strData.length();
		
		for(int i = 0; i <= enterLoc; i++) {
			Assert.assertEquals(i, data.getColumn());
			Assert.assertEquals(i, data.getCurrentPosition());
			data.getNextChar();
		}
		
		//column number reset after reading the '\n' 
		Assert.assertEquals(0, data.getColumn());
	}
	
	/**
	 * Test the Data::getCurrentPosition() method.
	 */	
	public void testGetCurrentPosition() {
		
		for(int i = 0; i <= data.length(); i++) {
			Assert.assertEquals(i, data.getCurrentPosition());
			data.getNextChar();
		}
	}
	
	/**
	 * Test the Data::Data(Data) copy constructor.
	 */	
	public void testDataData() {

		//move the cursor a bit, before creating the data object		
		for(int i = 0; i < 10; i++) {
			data.getNextChar();
		}
		
		Data newData = new Data(data);
		
		Assert.assertEquals(strData, newData.toString());
		Assert.assertEquals(data.getRow(), newData.getRow());
		Assert.assertEquals(data.getColumn(), newData.getColumn());
		Assert.assertEquals(data.getCurrentPosition(), newData.getCurrentPosition());
	}

	/**
	 * Check if the data passed follows the expected behaviour
	 * of a Data object containg null String.
	 * 
	 * @param nullData The Data to be checked.
	 */
	private void checkNullData(Data nullData) {
			
		Assert.assertTrue(nullData.endOfData());

		Assert.assertNull(nullData.getRemaining());
		Assert.assertNull(nullData.toString());

		Assert.assertEquals(0, nullData.getColumn());
		Assert.assertEquals(0, nullData.getCurrentPosition());
		Assert.assertEquals(0, nullData.getRow());
		Assert.assertEquals(0, nullData.length());

		Assert.assertEquals(Data.CHAR_NOT_FOUND, nullData.checkNextChar('\n'));
		
		Assert.assertEquals(Data.END_OF_DATA_CHAR, nullData.getNextChar());
		Assert.assertEquals(Data.END_OF_DATA_CHAR, nullData.getPrevChar());
		Assert.assertEquals(Data.END_OF_DATA_CHAR, nullData.lookNextChar());
		Assert.assertEquals(Data.END_OF_DATA_CHAR, nullData.peekAhead(1));
	}
	
	/**
	 * Check the behaviour of Data with null String.
	 */
	public void testNullData() {
		
		String str = null;
		Data nullData = new Data(str);
		checkNullData(nullData);

		//after a rewind		
		nullData.rewind();
		checkNullData(nullData);
		
		//Empty String
		nullData.reset();
		checkEmptyData(nullData);
	}
	
	/**
	 * Check if the data passed follows the expected behaviour
	 * of a Data object containg an empty String.
	 * 
	 * @param empty The Data to be checked.
	 */
	private void checkEmptyData(Data empty) {
		
		Assert.assertTrue(empty.endOfData());

		Assert.assertNull(empty.getRemaining());
		Assert.assertEquals("", empty.toString());

		checkIsDataBegin(data);

		Assert.assertEquals(0, empty.length());

		Assert.assertEquals(Data.CHAR_NOT_FOUND, empty.checkNextChar(' '));
		
		Assert.assertEquals(Data.END_OF_DATA_CHAR, empty.getNextChar());
		Assert.assertEquals(Data.END_OF_DATA_CHAR, empty.getPrevChar());
		Assert.assertEquals(Data.END_OF_DATA_CHAR, empty.lookNextChar());
		Assert.assertEquals(Data.END_OF_DATA_CHAR, empty.peekAhead(1));
	}
	
	/**
	 * Check the behaviour of Data with an empty String.
	 */
	public void testEmptyData() {
		
		Data empty = new Data("");
		checkEmptyData(empty);

		//after a rewind		
		empty.rewind();
		checkEmptyData(empty);
		
		//after a reset
		empty.reset();
		checkEmptyData(empty);
	}
}
