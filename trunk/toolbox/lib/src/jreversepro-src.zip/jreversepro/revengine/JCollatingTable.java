/**
  * @(#)JCollatingTable.java
  * JReversePro - Java Decompiler / Disassembler.
  * Copyright (C) 2000 2001 Karthik Kumar.
  * EMail: akkumar@users.sourceforge.net
  *
  * This program is free software; you can redistribute it and/or modify
  * it , under the terms of the GNU General Public License as published
  * by the Free Software Foundation; either version 2 of the License,
  * or (at your option) any later version.
  *
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  * See the GNU General Public License for more details.
  * You should have received a copy of the GNU General Public License
  * along with this program.If not, write to
  *  The Free Software Foundation, Inc.,
  *  59 Temple Place - Suite 330,
  *  Boston, MA 02111-1307, USA.
  **/

package jreversepro.revengine;

import java.util.List;
import java.util.Vector;
import java.util.Map;
import java.util.Collections;

import jreversepro.reflect.JInstruction;
import jreversepro.reflect.JException;
import jreversepro.common.KeyWords;
import jreversepro.runtime.JOperandStack;
import jreversepro.runtime.Operand;

/**
 * JBranchTable manages the objects of JGotoEntry and JBranchEntry.
 *
 * @author Karthik Kumar
 * @version 1.3
 **/
public class JCollatingTable implements BranchConstants,
                                        KeyWords {


    private List Branches;//Vector of JBranchEntry
    private JBranchEntry [] Entries;

    public JCollatingTable() {
        Branches = new Vector();
        Entries = null;
    }

    protected void finalize() {
        Branches  = null;
        if ( Entries  != null  ) Entries  = null;
    }

    public List getEffectiveBranches() {
        List listBranches  =  new Vector();
        for ( int i = 0 ; i < Entries.length ; i++ ) {
            if ( Entries[i].getType() != TYPE_INVALID ) {
                listBranches.add( Entries[i] );
            }
        }
        return listBranches;
   }


    public void addConditionalBranch(JInstruction ThisIns,
                        int StartPc, int Type,
                        String Opr1, String Opr2 ) {
        JBranchEntry thisent =
            new JBranchEntry(StartPc,
                ThisIns.index  + 3,
                ThisIns.getTargetPc(), Type,
                Opr1, Opr2, ThisIns.getConditionalOperator() );

        Branches.add( thisent );
    }


    public void sort() {
        Collections.sort(Branches,  new JBranchComparator() );
    }

    private int convertToObjects() {
        int Size = Branches.size();
        Entries  =  new JBranchEntry[Size];
        for( int i = 0; i < Size; i++ ) {
            Entries[i] = ( JBranchEntry) Branches.get(i);
        }
        return Size;
    }


    /**
       * This collates the information of the BranchTable to the
       * Java-compiler Readable branches.
       * <p>
       *        StartPc  TargetPc NextPc   in that order<br>
       *            x   y    z<br>
       *            z   y    p  Case1 <br><br>
       *
       *            x   y    z<br>
       *            z   p    q  Case2 <br>
       * </p>
      **/
    public void collate() {

        int NumBranches = convertToObjects();
        if( NumBranches == 0  ) {
            return;
            // No Branches at All. So return.
        }
        boolean IfBranch;
        for( int  i = NumBranches - 1 ; i > 0 ;) {
            IfBranch = collateSingle(i);
            int j =  i -1;
            for( j = i-1 ; j >= 0 ; j-- ) {
                if( Entries[j].getNextPc() !=
                            Entries[j+1].getStartPc() ) break;
                //End of a successive related branch.
                if( Entries[j].getType() == TYPE_GOTO ||
                    Entries[j].getType() == TYPE_JSR ) break;

                if( CheckCase1(j,i) ) {
                    writeCase1(IfBranch , j );
                }
                else if( CheckCase2(j,i) ) {
                    writeCase2(IfBranch ,j );
                }
                else break;
            }
            i =  j;//ReAssign i
        }
        //Collate the First entry.
        collateSingle(0);
    }

     /**
        * Collates a single statement , depending on if it is
        * a  IF / WHILE statement.
        * <p></p>
        * @return true , if the entry is a 'if' branch .
        *           false , otherwise.
        *
        */
    private boolean collateSingle( int i ){
        if( Entries[i].getType() == TYPE_GOTO ||
                    Entries[i].getType() == TYPE_JSR ) return true;
        if( Entries[i].getStartPc() < Entries[i].getTargetPc() ) {
//          Entries[i].setType(TYPE_IF);
            Entries[i].complementOperator();
            return true;
        }
        else {
        if ( Entries[i].getType() != TYPE_WHILE ) {
                Entries[i].setType(TYPE_DO_WHILE);
        }
            return false;
        }
    }

     /**
        * Checks for Case 1  type collate
        * <p><br><code>
        *   a:     x    y   z   <br>
        *   b:      y   p1  p2 <br>
        *  z:       <br><br></code>
        *  This means either a 'IF OR '  or 'WHILE AND' between the
        *  statements.</p>
        */
    private boolean CheckCase1( int a , int b ) {
        if( Entries[a].getType() == TYPE_GOTO ) return false;
        return ( Entries[a].getTargetPc() == Entries[b].getNextPc() );
    }


    /**
     * Writes a Case 1 statement onto the entry
        * <p><br><code>
        *   a:     x    y   z   <br>
        *   b:     y    p1  p2 <br>
        *  z:       <br><br></code>
        *  This means either a 'IF OR '  or and 'WHILE AND' between the
        *  statements.
        * <br>
        *  Now the row 'b'  is invalidated , and contents of a become
        * <code><br>a: x p1 p2 <br></code>
        * The Operands are also changed accordingly.
        * <br></p>
        */
    private void writeCase1(boolean IfStat, int a ) {
        int b  = a+1;

        Entries[a].setType( Entries[b].getType() );
        Entries[b].setType(TYPE_INVALID);
        //Invalidate Current Row of Branch Table

        Entries[a].setNextPc( Entries[b].getNextPc() );
        Entries[a].setTargetPc( Entries[b].getTargetPc() );

        if( IfStat ) {
            Entries[a].rewriteCondition(Entries[b],
                                    COND_OR, true);
        }
        else {
            Entries[a].rewriteCondition(Entries[b],
                                    COND_AND, false);
        }
    }


     /**
        * Checks for Case 2  type collate
        * <p><br><code>
        *   a:     x    y   z   <br>
        *   b:      y   p1  z  OR <br>
        *
        *   a:     x    y   z   <br>
        *   z:      .....       <br>
        *   b:      y   p1  p2 <br><br></code>
        *  This means either a 'IF AND'  or 'WHILE OR' between the
        *  statements.</p>
        */
    private boolean CheckCase2( int a , int b ) {
        if( Entries[a].getType() == TYPE_GOTO ) return false;
        if( Entries[a].getTargetPc() ==
                Entries[b].getTargetPc() ) return true;
        else {
            if( (b-a) > 1) {
                for(int k = b ; k > a ;k-- ){
                    if( Entries[a].getTargetPc() ==
                        Entries[k].getStartPc() ) return true;
                }
                return false;
            }
            else return false;
        }
    }

     /**
        * Writes a Case 2 statement onto the entry
        * <p><br><code>
        *   a:     x    y   z   <br>
        *   b:      y   p1  z  OR <br>
        *
        *   a:     x    y   z   <br>
        *   z:      .....       <br>
        *   b:      y   p1  p2 <br><br></code>
        *  This means either a 'IF AND'  or 'WHILE OR' between the
        *  statements.<br>+
        *  Now the row 'b'  is invalidated , and contents of a become
        * <code><br>a: x p1 p2 <br></code>
        * The Operands are also changed accordingly.
        * <br></p>
        */
    private void writeCase2(boolean IfStat, int a ) {
        int b  = a + 1;

        Entries[a].setType( Entries[b].getType() );
        Entries[b].setType(TYPE_INVALID);
        //Invalidate Current Row of Branch Table

        Entries[a].setNextPc( Entries[b].getNextPc() );
        Entries[a].setTargetPc( Entries[b].getTargetPc() );

        if( IfStat ) {
            Entries[a].rewriteCondition(Entries[b],
                                    COND_AND, false);
        }
        else {
            Entries[a].rewriteCondition(Entries[b],
                                    COND_OR, true);
        }
    }


    public void identifyWhileLoops(Map mapGotos) {
        for ( int i = 0 ; i < Branches.size() ; i++ ) {
            JBranchEntry ent = ( JBranchEntry ) Branches.get(i);
            if ( ent.getType() == TYPE_IF ) {
                int targetPc = ent.getTargetPc();
                int startPc = ent.getStartPc();
                Object obj = mapGotos.get( new Integer(targetPc-3) );
                if ( obj != null ) {
                    int gotoTarget = ( (Integer)obj).intValue();
                    if ( startPc == gotoTarget ) {
                        ent.convertToWhile();
                    }
                }
            }
        }
   }

    public String toString() {
        StringBuffer sb =  new StringBuffer("\n");
        sb.append( Branches + "\n" );
        return sb.append("\n").toString();
    }
}