package tool.pdf;

import java.io.File;
import java.io.IOException;
import java.util.*;

import multivalent.ParseException;
import multivalent.std.adaptor.pdf.*;

import phelps.io.RandomAccess;



/**
	Repair.

	@version $Revision: 1.2 $ $Date: 2003/06/21 00:02:18 $
*/
public class Repair {
  static final boolean DEBUG = true;

  public static final String VERSION = "1.0 of $Date: 2003/06/21 00:02:18 $";
  public static final String USAGE = "java tool.pdf.Repair [-uncompress] [-password <word>] <PDF-file>";


  private String password_;
  boolean funcompress;

  public Repair() {
	defaults();
  }

  public void defaults() {
	password_ = null;
	funcompress = false;
  }


  public void repair(File in) throws IOException, ParseException {
	String path = in.getPath();
	String pathout = (path.toLowerCase().endsWith(".pdf")? path.substring(0,path.length()-".pdf".length()): path) + "-repair.pdf";
	repair(in, new File(pathout));
  }

  public void repair(File filein, File fileout) throws IOException, ParseException {
	assert !filein.equals(fileout);

	PDFReader pdfr = new PDFReader(filein);
	pdfr.setPassword(password_);
	pdfr.setExact(true);	// write out as corrected by PDFReader, but otherwise no changes
	PDFWriter pdfw = new PDFWriter(fileout, pdfr);
	//if (funcompress) { pdfw.setCompress(false); pdfw.setCompact(false); }	// for subsequent hand repair

	pdfw.writePDF();	// all repair happens in reader
	pdfw.close();

	String msg;
	if (!pdfr.isModified()) msg = "no errors to repair";
	else if (pdfr.isRepaired()) msg = "REPAIRED ERRORS";
	else {
		// check for lack of high bits
		RandomAccess raf = pdfr.getRAF();
		int highcnt = 0;
		for (int c; (c = raf.read()) != -1; ) if (c>=0x80) highcnt++;
		msg = highcnt<20? "transferred over ASCII (not binary) channel -- unrepairable": "cannot repair";
	}
	System.out.println(msg);

	pdfr.close();
  }


  private int commandLine(String[] argv) {
	int argi=0, argc=argv.length;
	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.equals("-password")) password_ = argv[++argi];
		else if (arg.equals("-uncompress")) funcompress = true;

		else if (arg.startsWith("-v"/*ersion*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.startsWith("-h"/*elp"*/)) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	if (argi == argc) { System.err.println(USAGE); System.exit(0); }

	return argi;
  }

  public static void main(String[] argv) throws IOException {
	Repair repair = new Repair();


	int argi = repair.commandLine(argv);

	// exactly one file?
	File filein = new File(argv[argi]);
	try {
		repair.repair(filein);
	} catch (Exception ioe) {
		System.err.println(filein+": "+ioe);
		if (DEBUG) ioe.printStackTrace();
	}
  }
}
