/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.io;
import java.io.*;
import java.net.URL;
import java.util.Enumeration;
import java.util.PropertyResourceBundle;

import com.shfarr.beans.*;
import com.shfarr.DevUtils;

public class IOUtils{
	
    public static Object bytes2Object(byte[] src, boolean xml){
        return bytes2Object(src, null, xml);
    }
    
	public static Object bytes2Object(byte[] src, ObjectDecoder decoder, boolean xml){
	  Object loadedObj = null;
	
	  ObjectInputStream oStream = null;
	  ByteArrayInputStream bStream = new ByteArrayInputStream(src);
	
	  try{
		  if(!xml){
		     oStream = new ObjectInputStream(bStream);
		     loadedObj = oStream.readObject();
		     oStream.close();
		  }
		  else{
			   XMLDecoder xmlDecoder = new XMLDecoder(bStream, decoder);
			   loadedObj = xmlDecoder.readObject();
               xmlDecoder.close();
		  }
	  }
	  catch(Exception e){
			//if(DevUtils.debuging("io")) 
                e.printStackTrace();
	  }
	  finally{
			  try{
				  bStream.close();
			  }
			  catch(Exception e){
			  }
	  }
	
	  return loadedObj;
	}
	
	
	public static Object file2Object(String path){
	  return file2Object(path, null);
	}
	
	
	public static Object file2Object(String path, ObjectDecoder decoder){
	  Object loadedObj = null;
	
	  FileInputStream fis = null;
	
	  boolean xml = path.toLowerCase().endsWith(".xml");
      	  
	  try{
		  fis = new FileInputStream(path);
	
		  byte[] data = new byte[fis.available()];
		  fis.read(data, 0, data.length);
		  loadedObj = bytes2Object(data, decoder, xml);
	  }
	  catch(Exception e){
			if(DevUtils.debuging("io")) e.printStackTrace();
	  }
	  finally{
			  try{
				  fis.close();
			  }
			  catch(Exception e){
			  }
	  }
	
	  return loadedObj;
	}
	
    public static Object xml2Object(URL url, ObjectDecoder decoder) throws IOException{
      return bytes2Object(load(url), decoder, true);
    }
    
    public static void save(byte[] data, String path){
        try{
            FileOutputStream fos = new FileOutputStream(path);
            fos.write(data);
            fos.flush();
            fos.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public static byte[] load(URL url) throws IOException{
        if(url == null) return null;

        InputStream stream = url.openStream();
        
        return load(stream);
    }
    
    public static byte[] load(InputStream stream) throws IOException{
        byte[] buffer = new byte[0];

        int amount = -1;
        do{
            byte[] bytes = new byte[1024];
            amount = stream.read(bytes);
            
            if(amount != -1){
                byte[] newBuffer = new byte[buffer.length +amount];
                System.arraycopy(buffer, 0, newBuffer, newBuffer.length -amount -buffer.length, buffer.length);
                System.arraycopy(bytes, 0, newBuffer, newBuffer.length -amount, amount);
                buffer = newBuffer;
            }
        }
        while(amount != -1);
        
        stream.close();
        
        return buffer;
    }
    
    public static byte[] object2Bytes(Object obj, boolean xml){
        return object2Bytes(obj, null, xml);
    }
    
	public static byte[] object2Bytes(Object obj, ObjectEncoder encoder, boolean xml){
	  ObjectOutputStream oStream = null;
	  ByteArrayOutputStream bStream = null;
	
	  try{
		  bStream = new ByteArrayOutputStream();
	
		  if(!xml){
		     oStream = new ObjectOutputStream(bStream);
		     oStream.writeObject(obj);
		     oStream.close();
		  }
		  else{
			   XMLEncoder xmlEncoder = new XMLEncoder(bStream, encoder);
               xmlEncoder.writeObject(obj);
               xmlEncoder.close();
		  }
	  }
	  catch(Exception e){
			//if(DevUtils.debuging("io"))
            e.printStackTrace();
	  }
	  finally{
			  try{
				  if(oStream!=null) oStream.close();
				  bStream.close();
			  }
			  catch(Exception e){
			  }
	  }
	  
	  return bStream.toByteArray();
	}
	
	
	public static boolean object2File(Object obj, String path){
	  return object2File(obj, path, null);
	}
	
	
	public static boolean object2File(Object obj, String path, ObjectEncoder encoder){
	  boolean result = false;
	
	  FileOutputStream fos = null;
	
	  boolean xml = path.toLowerCase().endsWith(".xml");
	  
	  try{
		  if(path.indexOf("/")!=-1){
		     File dir = new File(path.substring(0, path.lastIndexOf("/")));
		     dir.mkdirs();
		  }
	
		  fos = new FileOutputStream(path);
		  fos.write(object2Bytes(obj, encoder, xml));
		  fos.flush();
	
		  result = true;
	  }
	  catch(Exception e){
			if(DevUtils.debuging("io")) e.printStackTrace();
	  }
	  finally{
			  try{
			      fos.close();
			  }
			  catch(Exception e){
			  }
	  }
	
	  return result;
	}
    
    public static void loadProperties(){
        PropertyResourceBundle properties = null;
		
        try{
			properties = new PropertyResourceBundle(new FileInputStream(System.getProperty("properties")));
		}
        catch(Exception e){
            System.err.println("Must provide valid -Dproperties=${property file} system property");
            System.exit(1);
		}

		for(Enumeration keys = properties.getKeys(); keys.hasMoreElements(); ){
            String key = (String)keys.nextElement();
            System.out.println(key + " = " + properties.getString(key));
            System.setProperty(key, properties.getString(key));
        }
    }
}
