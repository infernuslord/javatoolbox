/*
 * Created on Apr 17, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package com.shfarr.ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JToggleButton;

public class FhDatePicker2 extends JPanel implements ActionListener{
    private JPanel yearPanel = null;
    private JLabel yearLabel = null;
    private JPanel monthPanel = null;
    private JLabel monthLabel = null;
    private JPanel dayPanel = null;
    private JLabel dayLabel = null;
    public ButtonGroup buttonGroup = null;
    
    private GregorianCalendar calendar = null;

    public FhDatePicker2() {
        calendar = new GregorianCalendar();
        setLayout(new BorderLayout(4,4));
        
        add(getYearPanel(), "North");
        add(getMonthPanel(), "Center");
        add(getDayPanel(), "South");
    }

    protected JPanel getYearPanel(){
        
        if(yearPanel == null){
            ActionListener l = new ActionListener(){
                    public void actionPerformed(ActionEvent ae){
                        if(ae.getActionCommand().equals("Previous")) {
                            calendar.set(Calendar.YEAR, calendar.get(Calendar.YEAR) -1);
                        }

                        if(ae.getActionCommand().equals("Next")) {
                            calendar.set(Calendar.YEAR, calendar.get(Calendar.YEAR) +1);
                        }
                        
                        getYearLabel().setText("" + calendar.get(Calendar.YEAR));
                    }
                };
                
            JButton prevYear = (JButton)UIUtils.createButton("Previous", l);    
            JButton nextYear = (JButton)UIUtils.createButton("Next", l);

            yearPanel = new JPanel();
            yearPanel.add(prevYear, "West");
            yearPanel.add(getYearLabel(), "Center");
            yearPanel.add(nextYear, "East");
            //yearPanel.setPreferredSize(new Dimension(150, 70));
        }
        
        return yearPanel;
    }
    
    protected JLabel getYearLabel() {
        if(yearLabel == null) {
            yearLabel = new JLabel("" + calendar.get(Calendar.YEAR), JLabel.CENTER);
            yearLabel.setPreferredSize(new Dimension(100,120));
        }
        
        return yearLabel;
    }
    
    
    protected JPanel getMonthPanel() {
        
        if(monthPanel == null) {
            ActionListener al = new ActionListener() {
                public void actionPerformed(ActionEvent ae){
                    if(ae.getActionCommand().equals("Previous")) {
                        calendar.set(Calendar.MONTH, calendar.get(Calendar.MONTH)-1);
                        getYearLabel().setText("" + (calendar.get(Calendar.YEAR)));
                    }

                    if(ae.getActionCommand().equals("Next")) {
                        calendar.set(Calendar.MONTH, calendar.get(Calendar.MONTH)+1);
                        getYearLabel().setText("" + (calendar.get(Calendar.YEAR)));
                    }
                    
                    getMonthLabel().setText("" + monthFor(calendar.get(Calendar.MONTH)));
                    getDayLabel().setText("" + (calendar.get(Calendar.DAY_OF_MONTH)));
                    getYearLabel().setText("" + (calendar.get(Calendar.YEAR)));
                }
            };
            
            
            JButton prevMonth = (JButton)UIUtils.createButton("Previous", al);    
            JButton nextMonth = (JButton)UIUtils.createButton("Next", al);

            monthPanel = new JPanel();
            monthPanel.add(prevMonth , "West");
            monthPanel.add(getMonthLabel(), "Center");
            monthPanel.add(nextMonth , "East");
           // monthPanel.setPreferredSize(new Dimension(150, 70));    
        }
        return monthPanel;
    }
    
    protected String monthFor(int i) {
        switch(i) {
            case 0 : return "January";
            case 1 : return "February";
            case 2 : return "March";
            case 3 : return "April";
            case 4 : return "May";
            case 5 : return "June";
            case 6 : return "July";
            case 7 : return "August";
            case 8 : return "September";
            case 9 : return "October";
            case 10 : return "November";
            case 11 : return "December";
            default : throw new RuntimeException("no such month");
        }
    }

    protected JLabel getMonthLabel() {
        if(monthLabel == null) {
            monthLabel = new JLabel("" + monthFor(calendar.get(Calendar.MONTH)), JLabel.CENTER);
            monthLabel.setPreferredSize(new Dimension(100,120));
        }
        
        return monthLabel;
    }

    protected JPanel getDayPanel() {
        
        if(dayPanel == null) {
            ActionListener al = new ActionListener() {
                public void actionPerformed(ActionEvent ae){
                    if(ae.getActionCommand().equals("Previous")) {
                        calendar.set(Calendar.DAY_OF_MONTH, calendar.get(Calendar.DAY_OF_MONTH)-1);
                        getDayLabel().setText("" + (calendar.get(Calendar.DAY_OF_MONTH)));
                        getMonthLabel().setText("" + monthFor(calendar.get(Calendar.MONTH)));
                        getYearLabel().setText("" + (calendar.get(Calendar.YEAR)));
                    }

                    if(ae.getActionCommand().equals("Next")) {
                        calendar.set(Calendar.DAY_OF_MONTH, calendar.get(Calendar.DAY_OF_MONTH)+1);
                        getDayLabel().setText("" + (calendar.get(Calendar.DAY_OF_MONTH)));
                        getMonthLabel().setText("" + monthFor(calendar.get(Calendar.MONTH)));
                        getYearLabel().setText("" + (calendar.get(Calendar.YEAR)));
                    }
                    
                   }
            };
            
            
            JButton prevDay = (JButton)UIUtils.createButton("Previous", al);    
            JButton nextDay = (JButton)UIUtils.createButton("Next", al);

            dayPanel = new JPanel(new GridLayout(0,7));
            
                                   /* pane.setLayout(new GridLayout(0,2));
                                    pane.add(new JButton("Button 1"));
                                    pane.add(new JButton("Button 2"));
                                    pane.add(new JButton("Button 3"));
                                    pane.add(new JButton("Long-Named Button 4"));
                                    pane.add(new JButton("5"));*/

            
            buttonGroup = new ButtonGroup();
            for(int i=1; i<calendar.getActualMaximum(Calendar.DAY_OF_MONTH); i++) {
                JToggleButton button = new JToggleButton("" + i);
                button.addActionListener(this);
                buttonGroup.add(button);
                dayPanel.add(button);
            }
            
            
            
            //dayPanel.add(prevDay , "West");
            //dayPanel.add(getDayLabel(), "Center");
            //dayPanel.add(nextDay , "East");
            //dayPanel.setPreferredSize(new Dimension(150, 70));    
        }
        return dayPanel;
    }
    


    protected JLabel getDayLabel() {
        if(dayLabel == null) {
            dayLabel = new JLabel("" + calendar.get(Calendar.DAY_OF_MONTH), JLabel.CENTER);
        }
        
        return dayLabel;
    }

    
    public void actionPerformed(ActionEvent e){
        
    }

    
    
    
    public static void main(String[] args){
        JFrame frame = new JFrame();
        frame.setContentPane(new FhDatePicker2());
        frame.setSize(400,400);
        //frame.pack();
        frame.setVisible(true);    
    }
}
