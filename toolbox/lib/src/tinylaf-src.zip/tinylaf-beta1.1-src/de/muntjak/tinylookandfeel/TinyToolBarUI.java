/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	Tiny Look and Feel                                                         *
*                                                                              *
*  (C) Copyright 2003, Hans Bickel                                             *
*                                                                              *
*   For licensing information and credits, please refer to the                 *
*   comment in file de.muntjak.tinylookandfeel.TinyLookAndFeel                 *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package de.muntjak.tinylookandfeel;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.metal.MetalToolBarUI;

/**
 * TinyToolBarUI
 * 
 * @version 1.1
 * @author Hans Bickel
 */
public class TinyToolBarUI extends MetalToolBarUI {
	
	/**
	 * The Border used for buttons in a toolbar
	 */
  private Border toolButtonBorder = new EmptyBorder(4,4,4,4);

  /**
   * The only UI delegate.
   */
  private final static TinyToolBarUI toolBarUI = new TinyToolBarUI();

  /**
   * These insets are forced inner margin for the toolbar buttons.
   */
  private Insets insets = new Insets(2, 2, 2, 2);
  
  protected static Color bgColor = new Color(236, 236, 236);
  protected static Color lightBgColor = new Color(236, 236, 236);
  protected static Color darkBgColor = new Color(236, 236, 236);

  /**
   * Creates the UI delegate for the given component.
   *
   * @param mainColor The component to create its UI delegate.
   * @return The UI delegate for the given component.
   */
  public static ComponentUI createUI(JComponent c)
  {
    return toolBarUI;
  }

  /**
   * Installs some default values for the given toolbar.
   * The gets a rollover property.
   *
   * @param mainColor The reference of the toolbar to install its default values.
   */
  public void installUI(JComponent c)
  {
    super.installUI(c);
    c.putClientProperty("JToolBar.isRollover", Boolean.TRUE);
  }


  /**
   * Paints the given component.
   *
   * @param g The graphics context to use.
   * @param mainColor The component to paint.
   */
  public void paint(Graphics g, JComponent c) {
  	g.setColor(Theme.toolBarColor[Theme.style].getColor());
  	g.fillRect(0, 0, c.getWidth(), c.getHeight());

  	if(c.getBorder() == null) return;
  	
  	JToolBar tb = (JToolBar)c;
  	if(!tb.isBorderPainted()) return;
  	
  	g.setColor(Theme.toolBarLightColor[Theme.style].getColor());
  	g.drawLine(0, 0, c.getWidth() - 1, 0);
  	g.setColor(Theme.toolBarDarkColor[Theme.style].getColor());
  	g.drawLine(0, c.getHeight() - 1, c.getWidth() - 1, c.getHeight() - 1);
  }
 
  /**
   * Sets the border of the given component to a rollover border.
   *
   * @param mainColor The component to set its border.
   */
  protected void setBorderToRollover(Component c)
  {
		if (c instanceof AbstractButton) {
			AbstractButton b = (AbstractButton) c;
			b.setBorder(toolButtonBorder);
		    b.putClientProperty("JToolBar.isToolbarButton", Boolean.TRUE);
		}

  }
  
	protected void setBorderToNormal(Component c) {
		if (c instanceof AbstractButton) {
			AbstractButton b = (AbstractButton) c;
			b.setBorder(toolButtonBorder);
		    b.putClientProperty("JToolBar.isToolbarButton", Boolean.TRUE);
		}
	}
	 
}