/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.plaf.*;
import javax.swing.plaf.basic.BasicSliderUI;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;

import java.awt.Graphics2D;
import java.awt.Rectangle;

import com.shfarr.ui.plaf.fh.ext.*;
import com.shfarr.ui.plaf.fh.textures.*;
import com.shfarr.ui.plaf.fh.theme.*;


public class FhSliderUI extends BasicSliderUI{
    protected int previousLabel = -1;

	public FhSliderUI(JSlider js){
	  super(js);
	}

	public static ComponentUI createUI(JComponent c){
	  return new FhSliderUI((JSlider)c);
	}

    public void paintTrack(Graphics g){
      // draw track border
      Border trackBorder = UIManager.getDefaults().getBorder("Slider.trackBorder");
      Insets ins = trackBorder != null ? trackBorder.getBorderInsets(null) : new Insets(0, 0, 0, 0); 
      
      int textureRotation = 0,
          outsetX = 0,
          outsetY = 0;
          
      Dimension size = slider.getSize();
      
      if(slider.getOrientation() == JSlider.HORIZONTAL){
         textureRotation = Texture.ROTATE_0;
         outsetX = ins.left;
      }
      else{
           textureRotation = Texture.ROTATE_270;
           outsetY = ins.top;
      }

      Rectangle fullBounds = new Rectangle(trackRect.x, trackRect.y, trackRect.width, trackRect.height),
                strippedBounds = new Rectangle(fullBounds.x +ins.left, fullBounds.y +ins.top, fullBounds.width -ins.left -ins.right, fullBounds.height -ins.top -ins.right),
                fillRect = new Rectangle(fullBounds.x +ins.left,
                                         outsetY != 0 ? thumbRect.y : fullBounds.y +ins.top,
                                         outsetX != 0 ? thumbRect.x -fullBounds.x : fullBounds.width -ins.left -ins.right,
                                         outsetY != 0 ? fullBounds.y +fullBounds.height -thumbRect.y -ins.bottom : fullBounds.height -ins.top -ins.bottom);

      if(slider.isEnabled()) g.setColor(UIManager.getColor("EditableComponent.background"));
      else g.setColor(UIManager.getColor("EditableComponent.inactiveBackground"));
      
      // draw empty zone
      g.fillRect(fullBounds.x, fullBounds.y, fullBounds.width, fullBounds.height);

	  Texture trackTexture = (Texture)UIManager.getDefaults().get("Slider.trackTexture");
      Texture completedTexture = (Texture)UIManager.getDefaults().get("Slider.trackCompletedTexture");
	  
      // draw filled zone
      if(completedTexture != null && ThemeManager.instance().probeSmallTextures()){
         completedTexture.rotate(textureRotation);
         completedTexture.apply(strippedBounds, fillRect, (Graphics2D)g, slider);
         completedTexture.rotate(-textureRotation);
      }
      else{
          g.setColor((Color)UIManager.getDefaults().get("Slider.selectionBackground"));
          g.fillRect(fillRect.x, fillRect.y, fillRect.width, fillRect.height);
      }

	  // apply texture on entire track
      if(trackTexture != null && ThemeManager.instance().probeSmallTextures()){
         trackTexture.rotate(textureRotation);
         trackTexture.apply(strippedBounds, (Graphics2D)g, slider);
         trackTexture.rotate(-textureRotation);
      }

      trackBorder.paintBorder(slider, g, fullBounds.x, fullBounds.y, fullBounds.width, fullBounds.height);
    }
    

    public void paintFocus(Graphics g){        
    }
    

    protected void paintMinorTickForHorizSlider(Graphics g, Rectangle tickBounds, int x ){
      g.setColor((Color)UIManager.getDefaults().get("Slider.shadow"));
      g.drawLine( x, 3, x, tickRect.height -3 -1);
      
      g.setColor((Color)UIManager.getDefaults().get("Slider.highlight"));
      g.drawLine( x +1, 3, x +1, tickRect.height -3 -1);
    }


    protected void paintMajorTickForHorizSlider( Graphics g, Rectangle tickBounds, int x ){
      g.setColor((Color)UIManager.getDefaults().get("Slider.shadow"));
      g.drawLine(x, 1, x, tickRect.height -2);

      g.setColor((Color)UIManager.getDefaults().get("Slider.highlight"));
      g.drawLine(x +1, 1, x +1, tickRect.height -2);
    }


    protected void paintMinorTickForVertSlider( Graphics g, Rectangle tickBounds, int y ) {
      g.setColor((Color)UIManager.getDefaults().get("Slider.shadow"));
      g.drawLine(3, y, tickRect.width -3 -1, y);

      g.setColor((Color)UIManager.getDefaults().get("Slider.highlight"));
      g.drawLine(3, y +1, tickRect.width -3 -1, y +1);
    }


    protected void paintMajorTickForVertSlider( Graphics g, Rectangle tickBounds, int y ) {
      g.setColor((Color)UIManager.getDefaults().get("Slider.shadow"));
      g.drawLine(1, y,  tickRect.width -2, y);

      g.setColor((Color)UIManager.getDefaults().get("Slider.highlight"));
      g.drawLine(1, y +1,  tickRect.width -2, y +1);
    }


    public int getTickLength(){
      return 4;
    }

    
    public Dimension getThumbSize(){
        Border thumbBorder = UIManager.getDefaults().getBorder("Slider.thumbBorder");
        
        Insets ins = thumbBorder != null ? thumbBorder.getBorderInsets(null) : new Insets(0, 0, 0, 0);
        
        if(slider.getOrientation() == JSlider.HORIZONTAL) return new Dimension(6 +ins.left +ins.right, 13 +ins.top +ins.bottom);
        else return new Dimension(15 +ins.left +ins.right, 6 +ins.top +ins.bottom);
    }


    public void paintThumb(Graphics g){
        Border thumbBorder = UIManager.getDefaults().getBorder("Slider.thumbBorder");
        
        Insets ins = thumbBorder.getBorderInsets(null);
        
        g.translate(thumbRect.x, thumbRect.y);
        
        g.setColor(slider.getBackground());
        g.fillRect(ins.left, ins.top, thumbRect.width -(ins.left +ins.right), thumbRect.height -(ins.top +ins.bottom));
        
        thumbBorder.paintBorder(slider, g, 0, 0, thumbRect.width, thumbRect.height);
        
        if(slider.isEnabled()){
           FhDefaults.paintTouch(slider, g, ins.left +1, ins.top +1, thumbRect.width -(ins.left +ins.right +2), thumbRect.height -(ins.top +ins.bottom +2));
        }
        
        Texture thumbTexture = (Texture)UIManager.getDefaults().get("SysButton.texture");
        if(thumbTexture != null && ThemeManager.instance().probeSmallTextures()) thumbTexture.apply(new Rectangle(ins.left, ins.top, thumbRect.width -(ins.left +ins.right), thumbRect.height -(ins.top +ins.bottom)), (Graphics2D)g, slider);
        
        g.translate(-thumbRect.x, -thumbRect.y);
    }

    
    protected void calculateThumbLocation(){
        super.calculateThumbLocation();

        if(slider.getOrientation() == JSlider.HORIZONTAL) thumbRect.translate(0, -Math.min(4, thumbRect.y));
        else thumbRect.translate(-Math.min(5, thumbRect.x), 0);
    }

    
    protected void calculateTrackRect(){
      if(slider.getOrientation() == JSlider.HORIZONTAL){
         trackRect.setBounds(getThumbSize().width/2, getThumbSize().height/2 -4, slider.getSize().width -getThumbSize().width, 8);
         if(slider.getPaintTicks()) trackRect.translate(0, 5);
	  }
	  else{
           trackRect.setBounds(getThumbSize().width/2 -4, getThumbSize().height/2, 8, slider.getSize().height -getThumbSize().height);
           if(slider.getPaintTicks()) trackRect.translate(5, 0);
	  }
      
      Insets i = slider.getBorder() != null ? slider.getBorder().getBorderInsets(slider) : new Insets(0, 0, 0, 0);
      
      trackRect.setBounds(trackRect.x +i.left, trackRect.y +i.top, trackRect.width -i.left -i.right, trackRect.height -i.top -i.bottom);
    }
    
    
    protected void calculateTickRect(){
      if(slider.getOrientation() == JSlider.HORIZONTAL) tickRect.setBounds(trackRect.x +2, trackRect.y -5, trackRect.width -4, trackRect.height +10);
	  else tickRect.setBounds(trackRect.x -5, trackRect.y +2, trackRect.width +10, trackRect.height -4);
    }
    
    
    public void paint( Graphics g, JComponent c )   {
        ThemeManager.instance().probeAntialiasing(g);

        recalculateIfInsetsChanged();
	    recalculateIfOrientationChanged();
	    Rectangle clip = g.getClipBounds();
    
	    if(!clip.intersects(trackRect) && slider.getPaintTrack()) calculateGeometry();

        if(slider.getPaintTicks() && clip.intersects(tickRect)) paintTicks(g);
    	if(slider.getPaintTrack() && clip.intersects(trackRect)) paintTrack(g);
        if(slider.getPaintLabels() && clip.intersects(labelRect)) paintLabels(g);
	    if(slider.hasFocus() && clip.intersects(focusRect)) paintFocus(g);
	    if(clip.intersects(thumbRect)) paintThumb(g);
    }

}
