/*
 * Copyright (c) 2005, the JUNG Project and the Regents of the University 
 * of California
 * All rights reserved.
 *
 * This software is open-source under the BSD license; see either
 * "license.txt" or
 * http://jung.sourceforge.net/license.txt for a description.
 * Created on Mar 8, 2005
 *
 */
package edu.uci.ics.jung.visualization.control;

import java.awt.event.MouseWheelEvent;
import java.awt.geom.Point2D;

import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.transform.MutableTransformer;

/** 
 * CrossoverScalingGraphMousePlugin extends ScalingnGraphMousePlugin and
 * adds a crossover point. When the overall scale of the view and
 * model is less than the crossover point, the scaling is applied
 * to the view's transform and the graph nodes, labels, etc grow
 * smaller. This preserves the overall shape of the graph.
 * When the scale is larger than the crossover, the scaling is
 * applied to the graph layout. The graph spreads out, but the
 * vertices and labels grow no larger than their original size 
 * 
 * @author Tom Nelson
 */
public class CrossoverScalingGraphMousePlugin extends ScalingGraphMousePlugin {

    /**
     * point where scale crosses over from view to model
     */
    protected double crossover = 1.0;
    
	/**
	 * create an instance with default zoom in/out values
	 */
	public CrossoverScalingGraphMousePlugin() {
	    this(1.1f, 0.9f);
	}

	/**
	 * create an instance with passed zoom in/out values
	 * @param in zoom in value
	 * @param out zoom out value
	 */
	public CrossoverScalingGraphMousePlugin(float in, float out) {
	    super(0);
	    this.in = in;
	    this.out = out;
	}
	
    /**
     * setter for crossover
     * @param crossover
     */
	public void setCrossover(double crossover) {
	    this.crossover = crossover;
	}

	/**
	 * zoom the display in or out, depending on the direction of the
	 * mouse wheel motion.
	 */
	public void mouseWheelMoved(MouseWheelEvent e) {
	    boolean accepted = checkModifiers(e);
	    if(accepted == true) {
	        
	        VisualizationViewer vv = (VisualizationViewer) e.getSource();
	        int amount = e.getWheelRotation();
	        
	        MutableTransformer modelTransformer = vv.getLayoutTransformer();
	        MutableTransformer viewTransformer = vv.getViewTransformer();
	        double modelScale = modelTransformer.getScale();
	        double viewScale = viewTransformer.getScale();
	        double inverseModelScale = Math.sqrt(crossover)/modelScale;
	        double inverseViewScale = Math.sqrt(crossover)/viewScale;
	        double scale = modelScale * viewScale;
	        
	        Point2D mouse = e.getPoint();
	        Point2D center = vv.getCenter();
	        Point2D ivtmouse = vv.inverseViewTransform(mouse);
	        Point2D ivtcenter = vv.inverseViewTransform(center);
	        
	        if(zoomAtMouse) {
	            if(amount > 0) {
	                if(scale*in < crossover) {
	                    viewTransformer.scale(in, in, mouse);
	                    modelTransformer.scale(inverseModelScale, inverseModelScale, ivtmouse);
	                } else {
	                    modelTransformer.scale(in, in, ivtmouse);
	                    viewTransformer.scale(inverseViewScale, inverseViewScale, mouse);
	                }
	            } else if(amount < 0) {
	                
	                if(scale*out < crossover) {
	                    viewTransformer.scale(out, out, mouse);
	                    modelTransformer.scale(inverseModelScale, inverseModelScale, ivtmouse);
	                } else {
	                    modelTransformer.scale(out, out, ivtmouse);
	                    viewTransformer.scale(inverseViewScale, inverseViewScale, mouse);
	                }
	            }
	            
	        } else {
	            
	            if(amount > 0) {
	                
	                if(scale*in < crossover) {
	                    viewTransformer.scale(in, in, center);
	                    modelTransformer.scale(inverseModelScale, inverseModelScale, ivtcenter);
	                } else {
	                    modelTransformer.scale(in, in, ivtcenter);
	                    viewTransformer.scale(inverseViewScale, inverseViewScale, center);
	                }
	            } else if(amount < 0) {
	                if(scale*out < crossover) {
	                    viewTransformer.scale(out, out, center);
	                    modelTransformer.scale(inverseModelScale, inverseModelScale, ivtcenter);
	                    
	                } else {
	                    modelTransformer.scale(out, out, ivtcenter);
	                    viewTransformer.scale(inverseViewScale, inverseViewScale, center);
	                }
	            }
	        }
	        e.consume();
	        vv.repaint();
	    }
	}
}
