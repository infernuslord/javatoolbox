/*
 * 
 * Created on 2004-jul-25
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.ui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.Toolkit;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

//import javax.swing.ComboBoxEditor;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.plaf.metal.MetalComboBoxUI;
import javax.swing.plaf.metal.MetalScrollBarUI;

import se.diod.hippo.plaf.common.ComboBoxButton;
import se.diod.hippo.plaf.common.ComboBoxEditor;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-25
 *
 */
public class HippoComboBoxUI extends MetalComboBoxUI{




	/**
	 * 
	 * 
	 */
	public static ComponentUI createUI(JComponent b) {
		return new HippoComboBoxUI();
	}




	/**
	 * Creates the editor that is to be used in editable combo boxes. 
	 * This method only gets called if a custom editor has not already 
	 * been installed in the JComboBox.
	 */
	protected javax.swing.ComboBoxEditor createEditor() {
		return new ComboBoxEditor.UIResource();
	}




	/**
	 * 
	 * 
	 */
	protected JButton createArrowButton() {
		java.net.URL imageURL = this.getClass().getResource("/se/diod/hippo/images/comboicon.gif");
		javax.swing.ImageIcon ii = new javax.swing.ImageIcon( imageURL );

		//return new HippoComboBoxButton( comboBox, HippoIconFactory.getComboBoxButtonIcon(), comboBox.isEditable(), currentValuePane, listBox );
		return new ComboBoxButton( comboBox, ii, comboBox.isEditable(), currentValuePane, listBox );
	}




	/**
	 * Overriden to correct the combobox height.
	 */
	public Dimension getMinimumSize(JComponent c) {
		final int MIN_HEIGHT = 17;
		if (!isMinimumSizeDirty) return new Dimension( cachedMinimumSize );

		Dimension size = null;
        
		if( !comboBox.isEditable() && arrowButton != null && arrowButton instanceof ComboBoxButton ) {
			ComboBoxButton button = (ComboBoxButton) arrowButton;
			Insets buttonInsets = button.getInsets();
			Insets insets		= comboBox.getInsets();

			size = getDisplaySize();

			/*
			 * The next line will lead to good results if used with standard renderers;
			 * In case, a custom renderer is used, it may use a different height, 
			 * and we can't help much.
			 */
			size.width  += insets.left + insets.right;
			size.width  += buttonInsets.left  + buttonInsets.right;
			//size.width  += buttonInsets.right + button.getComboIcon().getIconWidth();
			size.width  += button.getComboIcon().getIconWidth();

			size.height += (Toolkit.getDefaultToolkit().getScreenResolution() < 120) ? 0 : 2;
			size.height += insets.top + insets.bottom;
			size.height += buttonInsets.top + buttonInsets.bottom;
		} else if( comboBox.isEditable() && arrowButton != null && editor != null ) {

			// Includes the text editor border and inner margin
			size = getDisplaySize();

			// Since the button is positioned besides the editor,
			// do not add the buttons margin to the height.
			Insets insets = comboBox.getInsets();
			size.height += insets.top + insets.bottom;
		} else {
			size = super.getMinimumSize( c );
		}

		cachedMinimumSize.setSize(size.width, size.height-2);	// TODO: HippoComboBoxUI::> -2 remove this and find the right place to subtract 2!
		isMinimumSizeDirty = false;

		if( cachedMinimumSize.height < MIN_HEIGHT )
			cachedMinimumSize.height = MIN_HEIGHT;

		return new Dimension(cachedMinimumSize);
	}




	// Required if we have a combobox button that does not extend MetalComboBoxButton
	public PropertyChangeListener createPropertyChangeListener() {
		return new HippoPropertyChangeListener();
	}






	/**
	 * 
	 * @author Robert Karlsson
	 * @created 2003-dec-01
	 *
	 * Overriden to use HippoComboBoxButton instead of a MetalComboBoxButton.
	 * Required if we have a combobox button that does not extend MetalComboBoxButton
	 * 
	 */
	private class HippoPropertyChangeListener extends BasicComboBoxUI.PropertyChangeHandler {
		/**
		 * 
		 * 
		 */
		public void propertyChange(PropertyChangeEvent e) {
			super.propertyChange(e);
			String propertyName = e.getPropertyName();

			if (propertyName.equals("editable")) {
				ComboBoxButton button = (ComboBoxButton) arrowButton;
				button.setIconOnly(comboBox.isEditable());
				comboBox.repaint();
			} else if (propertyName.equals("background")) {
				Color color = new Color( 198, 209, 223 );	// FIXED COLOR, BIG NONO!
				arrowButton.setBackground(color);
				listBox.setBackground( color );
			} else if (propertyName.equals( "foreground" )) {
				Color color = new Color( 0, 0, 0 );		// FIXED COLOR, BIG NONO!
				arrowButton.setForeground(color);
				listBox.setForeground(color);
			}
		}
	}







	/**
	 * 
	 * @author Robert Karlsson
	 * @created 2003-dec-01
	 *
	 */
	private class HippoComboPopup extends MetalComboPopup {
		/**
		 * 
		 * 
		 */
		private HippoComboPopup( JComboBox combo ) {
			super( combo );
		}




		/**
		 * Configures the list created by #createList().
		 */
		protected void configureList() {
			super.configureList();
			list.setForeground( new Color( 0, 0, 0, 255 ) );			// TODO FIXED COLOR, BIG NONO!
			list.setBackground( new Color( 245, 245, 245, 255 ) );		// TODO FIXED COLOR, BIG NONO!
		}




		/**
		 * Configures the JScrollPane created by #createScroller().
		 */
		protected void configureScroller() {
			super.configureScroller();
			scroller.getVerticalScrollBar().putClientProperty( MetalScrollBarUI.FREE_STANDING_PROP, Boolean.FALSE );
		}
	}
}
