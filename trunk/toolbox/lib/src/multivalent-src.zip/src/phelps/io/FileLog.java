package phelps.io;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Observer;



/**
	Maintain a list of files with associated client data and change notification.
	The cilent can store arbitrary data in the log, outside of the file itself.
	An observer client can notified of the status of files vis-a-vis database:
	same, moved, changed, new, duplicate, or deleted.

	<p>Some possible uses: 
	<ul>
	<li>see what you've been up to in your home directory
	<li>log changes in OS files to check for intrusions
	<li>obtain a list of changed files for incremental backup
	<li>cache an expensive computation derived from the file ({@link phelps.awt.font.NFontManager} does this with font names extracted from the many font files)
	<li>update links in web pages after a site reorganization
	<li>check for changes in some API's Javadoc
	</ul>

	@author Copyright (c) 2003  Thomas A. Phelps
	@version $Revision: 1.3 $ $Date: 2003/12/26 01:21:41 $
*/
public class FileLog {
  public static final String ACTION_SAME = "same";
  public static final String ACTION_NEW = "new";
  public static final String ACTION_MOVED = "moved";
  public static final String ACTION_DELETED = "deleted";
  public static final String ACTION_CHANGED = "changed";
  public static final String ACTION_DUPLICATE = "duplicate";

  /** Database file format version. */
  private static final String VERSION = "1";



  private File log_;
  private String[] path_;
  private boolean frecurse_;
  private boolean fhash_;
  private boolean fsecure_;
  private int dataversion_;

  private Map<String,FileLogRecord> db_;
  private Map<String,String> attr_ = new HashMap<String,String>(13);


  /**
	If the <var>log</var> file doesn't exist, creates a new file log for the files in the directories <var>paths</var>, and their subdirectories if <var>recurse</var> is <code>true</code>.
	If <var>log</var> exists, opens it and sets the new paths, overriding whatever was used before (usually <var>paths</var> and <var>recurse</var> are identical).
	If the stored data format version is less than <var>dataversion</var> then all data is throw out, and a subsequent {@link #update(Observer, FileFilter)} will report all new files.
	@param log  file to which to writ the log, <code>null</code> for no persistence
  */
  public FileLog(File log, String[] paths, boolean recurse,  int dataversion) throws IOException {
//System.out.println("new FileLog "+log+" "+paths[0]+"..., "+recurse);
	log_ = log;

	path_ = paths;
	frecurse_ = recurse;
	fhash_ = true;
	fsecure_ = false;
	dataversion_ = dataversion;

	read();

	//update(); -- on demand, and after options setting

	// if log is null or can't write, just keep in memory -- read from scratch and do not write out

	// read in existing and use previous path_, ...
	// ...
  }

  /** Sets file hashing, which computes a checksum on file contents.  Hashing takes time, but enables moved and duplicate reports.  Default: <code>true</code>. */
  public void setHash(boolean b) { fhash_ = b; }

  /** High security mode does not trust that if a file has the same modification time and length as before that it is necessarily unchanged.  Default: <code>false</code>. */
  public void setHighSecurity(boolean b) { fsecure_ = b; if (b) fhash_ = true; }


  private void read() throws IOException {
	db_ = new HashMap<String,FileLogRecord>(200);
	if (log_==null || !log_.canRead() || log_.length()<20) return;	// doesn't exist or don't have permissions or truncated
	
	BufferedReader r = new BufferedReader(new FileReader(log_));
	int version = 1, inx;
	for (String line; (line = r.readLine())!=null; ) {
		if (line.startsWith("path:")) {}	// associate recurse with each path?
		else if (line.startsWith("version: ")) try { version = Integer.parseInt(line.substring("version: ".length())); } catch (NumberFormatException nfe) {}
		else if (line.startsWith("dataversion: ")) {
			try {
				int v = Integer.parseInt(line.substring("dataversion: ".length()));
				if (v < dataversion_) { db_.clear(); break; }
			} catch (NumberFormatException nfe) {}
		//else if (line.startsWith("records:")) { count = Integer.parseInt()... }
		} else if ((inx=line.indexOf(" "))>0 && line.charAt(inx-1)==':') {	// predefined: "date"
			attr_.put(line.substring(0,inx-1), line.substring(inx+1));

		} else if (line.length() < 10) {}	// blank or otherwise not a record
		else {	// a record
			try {
				FileLogRecord rec = new FileLogRecord(line, version);
				db_.put(rec.path, rec);
			} catch (Exception e) {}
		}
	}
	r.close();
  }

  /**
	Writes database to log file, presumably after {@link #update(Observer,FileFilter)} or ad hoc changes.
  */
  public void write() throws IOException {
	if (log_==null) return;
	//if (moved_.size()==0 && changed_.size()==0 && newf_.size()==0 && deleted_.size()==0) return;
	BufferedWriter w = new BufferedWriter(new FileWriter(log_));
	w.write("version: "+VERSION); w.newLine();
	w.write("dataversion: "+dataversion_); w.newLine();
	for (String path: path_) { w.write("path: "+path); w.newLine(); }

	attr_.put(attr_.get("create")==null? "create": "update", new java.util.Date().toString());
	for (Iterator<Map.Entry<String,String>> i = attr_.entrySet().iterator(); i.hasNext(); ) {
		Map.Entry<String,String> e = i.next();
		w.write(e.getKey()+": "+e.getValue()); w.newLine();
	}

	for (Iterator<FileLogRecord> i = db_.values().iterator(); i.hasNext(); ) { w.write(i.next().toString()); w.newLine(); }
	w.close();
  }


  /**
	Rreport to <var>observer</var> the current state of each file in the directory paths vis-a-vis the database:
	same, new, changed, delted, moved, duplicate.
	Reports sent to the <var>observer</var>'s <code>update</code> method as an <code>Object[]</code> argument 
	with the action code and one or more {@link FileLogRecord}s.
	<ul>
	<li>Same.  The database reports [{@link #ACTION_SAME} old] to the observer.  Often observers ignore these reports.
	<li>New.  The database adds a basic record (without user data) and reports [{@link #ACTION_NEW} new] to the observer.  Often observers set the associated data at this time.
	<li>Changed.  The database updates the file metadata and reports [{@link #ACTION_CHANGED} old new] to the observer.
	<li>Deleted.  The database deletes the file and reports [{@link #ACTION_DELETED} old] to the observer.
	<li>Moved.  The database moves the record to the new position and reports [{@link #ACTION_MOVED} old new] to the observer.  This option is not available if hashing is turned off.
	<li>Duplicate.  The database reports [{@link #ACTION_DUPLICATE} existing new] to the observer.  This option is not available if hashing is turned off.
	</ul>

	<p>Upon receiving a change notice, the <var>observer</var> can update the database with new user data, 
	or reverse the default action, 
	or ignore certain classes of changes.
	Can change any data, even checksum; may want to normalize data and compute checksum on that.
	The <var>observer</var> can be <code>null</code> if no change reports are desired.

	<p>Ordinarily clients will {@link #write()} the results back to disk.
  */
  public void update(Observer observer, FileFilter filter) throws IOException {
	Map<String,FileLogRecord> unseen = (Map<String,FileLogRecord>)((HashMap)db_).clone();
	Map<Long,FileLogRecord> dupcheck;
	if (fhash_) {
		dupcheck = new HashMap<Long,FileLogRecord>(db_.size()*4/3);
		for (Iterator<FileLogRecord> i = db_.values().iterator(); i.hasNext(); ) {
			FileLogRecord rec = i.next();
			dupcheck.put(new Long(rec.hash), rec);
		}
	} else dupcheck = null;


	FileList fl = new FileList(path_, filter); fl.setRecurse(frecurse_);
	for (Iterator<File> i = fl.iterator(); i.hasNext(); ) {
		FileLogRecord now = new FileLogRecord(i.next());
		String key = now.path;
//System.out.println(key);

		FileLogRecord exist = db_.get(key);
		Object[] arg;
		if (exist==null) {	// new: brand-new or moved or duplicate
			db_.put(key, now);
			if (fhash_) now.computeHash();
			if (fhash_ && now.length > 1/*not trivially the same*/ && (exist = dupcheck.get(new Long(now.hash)))!=null) {
				if (new File(exist.path).exists()) arg = new Object[] { ACTION_DUPLICATE, exist, now };
				else {
					now.data = exist.data;
					db_.remove(exist.path); unseen.remove(exist.path);
					arg = new Object[] { ACTION_MOVED, exist, now };
				}
			} else {
				 if (fhash_) dupcheck.put(new Long(now.hash), now);
				arg = new Object[] { ACTION_NEW, now };
			}

		} else {	// exists: same or changed
			unseen.remove(key);
			if (fsecure_) now.computeHash(); else now.hash=exist.hash;
			if (exist.mod==now.mod && exist.length==now.length && exist.hash==now.hash) {
				arg = new Object[] { ACTION_SAME, exist };	// usual case
			} else {
				now.data = exist.data;
				db_.remove(exist); db_.put(key, now);
				//exist.length=now.length; exist.mod=now.mod; exist.hash=now.hash;	// update metadata
				arg = new Object[] { ACTION_CHANGED, exist, now };
			}
		}
		if (arg!=null && observer!=null) observer.update(null, arg);
	}

	if (observer!=null) for (Iterator<FileLogRecord> i = unseen.values().iterator(); i.hasNext(); ) {
		FileLogRecord rec = i.next();
		db_.remove(rec.path);
		observer.update(null, new Object[] { ACTION_DELETED, rec });
	}

	// X update() => usually want to, but up to client
  }


  public FileLogRecord getRecord(File file) {
	return db_.get(file.toString());
  }

  /** Presumably added file too. */
  public void addRecord(FileLogRecord rec) {
	db_.put(rec.path, rec);
  }

  /**
	Returns iterator over records in database.
	Records should not be directly added or removed from the database while iterating;
	however records can be mutated or remove <em>via the iterator</em>.
  */
  public Iterator iterator() {
	return db_.values().iterator();
  }

  /* Returns number of records in database.
  public int size() { return db_.size(); }
   */


  public String getAttr(String key) { return attr_.get(key); }
  public String putAttr(String key, String value) { return attr_.put(key, value); }
}
