/*
 * 
 * Created on 2004-jul-25
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.ui;

import javax.swing.JComponent;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicSplitPaneDivider;
import javax.swing.plaf.basic.BasicSplitPaneUI;

import se.diod.hippo.plaf.common.SplitPaneDivider;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-25
 *
 */
public class HippoSplitPaneUI extends BasicSplitPaneUI {




	/**
	 * 
	 * 
	 */
	public static ComponentUI createUI(JComponent x) {
		return new HippoSplitPaneUI();
	}




	/**
	 * 
	 * 
	 */
	public BasicSplitPaneDivider createDefaultDivider() {
		return new SplitPaneDivider( this );
	}
}
