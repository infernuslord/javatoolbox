/*
* Copyright (c) 2003, the JUNG Project and the Regents of the University
* of California
* All rights reserved.
*
* This software is open-source under the BSD license; see either
* "license.txt" or
* http://jung.sourceforge.net/license.txt for a description.
*/
package samples.graph;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import edu.uci.ics.jung.algorithms.cluster.ClusterSet;
import edu.uci.ics.jung.algorithms.cluster.EdgeBetweennessClusterer;
import edu.uci.ics.jung.graph.Edge;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.graph.decorators.EdgeColorFunction;
import edu.uci.ics.jung.graph.decorators.EdgeThicknessFunction;
import edu.uci.ics.jung.graph.decorators.VertexColorFunction;
import edu.uci.ics.jung.io.PajekNetReader;
import edu.uci.ics.jung.utils.UserData;
import edu.uci.ics.jung.visualization.FRLayout;
import edu.uci.ics.jung.visualization.GraphDraw;
import edu.uci.ics.jung.visualization.graphdraw.SettableRenderer;

/**
 * This simple app demonstrates how one can use our algorithms and visualization libraries in unison.
 * In this case, we generate use the Zachary karate club data set, widely known in the social networks literature, then
 * we cluster the vertices using an edge-betweenness clusterer, and finally we visualize the graph using
 * Fruchtermain-Rheingold layout and provide a slider so that the user can adjust the clustering granularity.
 * @author Scott White
 */
public class ClusteringDemo extends JApplet {

	private static final Object DEMOKEY = "DEMOKEY";

	public static final Color[] similarColors =
	{
		new Color(216, 134, 134),
		new Color(135, 137, 211),
		new Color(134, 206, 189),
		new Color(206, 176, 134),
		new Color(194, 204, 134),
		new Color(145, 214, 134),
		new Color(133, 178, 209),
		new Color(103, 148, 255),
		new Color(60, 220, 220),
		new Color(30, 250, 100)
	};

	static JLabel eastSize;

	public static void main(String[] args) throws IOException {
		File f = new File("samples/datasets/zachary.net");
		try {
			BufferedReader br = new BufferedReader(new FileReader(f));
			final GraphDraw gd = setUpGraphDraw(br);

			// Add a restart button so the graph can be redrawn to fit the size of the frame
			JFrame jf = new JFrame();
			jf.getContentPane().add(gd);

			jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			jf.pack();
			jf.show();
		} catch (FileNotFoundException fnfe) {
			System.out.println("Can't find file " + f );
		}
	}

	public void start() {
		System.out.println("Starting in applet mode.");
		InputStream is = this.getClass().getClassLoader().getResourceAsStream("samples/datasets/zachary.net");
		BufferedReader br = new BufferedReader( new InputStreamReader( is ));
        
		GraphDraw gd = null;
        try
        {
            gd = setUpGraphDraw(br);
        }
        catch (IOException e)
        {
            // TODO Auto-generated catch block
            System.out.println("Error in loading graph");
            e.printStackTrace();
        }
        getContentPane().add( gd );
	}

	private static GraphDraw setUpGraphDraw(BufferedReader br) throws IOException {
        PajekNetReader pnr = new PajekNetReader();
        final Graph graph = pnr.load(br);

		//Label the nodes with default integer labels
//		StringLabeller labeler = StringLabeller.getLabeller(graph);

		//Create a simple layout frame
		final GraphDraw gd = new GraphDraw(graph);
		gd.setBackground( Color.white );
		//specify the Fruchterman-Rheingold layout algorithm
		gd.setGraphLayout(new FRLayout(graph));
		//Tell the renderer to use our own customized color rendering
        SettableRenderer sr = (SettableRenderer)gd.getRender();
		sr.setVertexColorFunction(new VertexColorFunction() {
			public Color getBackColor(Vertex v) {
				Color k = (Color) v.getUserDatum(DEMOKEY);
				if (k != null)
					return k;
				return Color.white;
			}

			public Color getForeColor(Vertex v) {
				return Color.black;
			}
		});

		sr.setEdgeColorFunction(new EdgeColorFunction() {
			public Color getEdgeColor(Edge e) {
				Color k = (Color) e.getUserDatum(DEMOKEY);
				if (k != null)
					return k;
				return Color.blue;
			}
		});

        //TODO: my edge thickness addition: does it help distinguish edges?
        sr.setEdgeThicknessFunction(new EdgeThicknessFunction()
            {
                public float getEdgeThickness(Edge e)
                {
                    Color c = (Color)e.getUserDatum(DEMOKEY);
                    if (c == Color.LIGHT_GRAY)
                        return 1;
                    else 
                        return 2;
                }
            });

		//add restart button
		JButton scramble = new JButton("Restart");
		gd.add(scramble, BorderLayout.SOUTH);
		scramble.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				gd.restartLayout();
			}

		});

		//Create slider to adjust the number of edges to remove when clustering
		final JSlider edgeBetweennessSlider = new JSlider(JSlider.HORIZONTAL);
        edgeBetweennessSlider.setBackground(Color.WHITE);
		edgeBetweennessSlider.setPreferredSize(new Dimension(150, 50));
		edgeBetweennessSlider.setPaintTicks(true);
		edgeBetweennessSlider.setMaximum(graph.numEdges());
		edgeBetweennessSlider.setMinimum(0);
		edgeBetweennessSlider.setValue(0);
		edgeBetweennessSlider.setMajorTickSpacing(10);
		edgeBetweennessSlider.setPaintLabels(true);
		edgeBetweennessSlider.setPaintTicks(true);
		edgeBetweennessSlider.setBorder(BorderFactory.createLineBorder(Color.black));
		//TO DO: edgeBetweennessSlider.add(new JLabel("Node Size (PageRank With Priors):"));
		//I also want the slider value to appear
		final JPanel eastControls = new JPanel();
		eastControls.setOpaque(true);
		eastControls.setLayout(new BoxLayout(eastControls, BoxLayout.Y_AXIS));
		eastControls.add(Box.createVerticalGlue());
		eastControls.add(edgeBetweennessSlider);
		//		final String COMMANDSTRING = "Node Size (PageRank With Priors): ";
		final String COMMANDSTRING = "Edges removed for clusters: ";
		eastSize = new JLabel(COMMANDSTRING + edgeBetweennessSlider.getValue());
		eastControls.add(eastSize);
		eastControls.add(Box.createVerticalGlue());
		gd.add(eastControls, BorderLayout.EAST);
		clusterAndRecolor(graph, 0, similarColors);

		edgeBetweennessSlider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				JSlider source = (JSlider) e.getSource();
				if (!source.getValueIsAdjusting()) {
					int numEdgesToRemove = source.getValue();
					clusterAndRecolor(graph, numEdgesToRemove, similarColors);
					eastSize.setText(
						COMMANDSTRING + edgeBetweennessSlider.getValue());
					gd.validate();
					gd.repaint();
				}
			}
		});

		return gd;
	}

	public static void clusterAndRecolor(
		Graph g,
		int numEdgesToRemove,
		Color[] colors) {
		//Now cluster the vertices by removing the top 50 edges with highest betweenness
		//		if (numEdgesToRemove == 0) {
		//			colorCluster( g.getVertices(), colors[0] );
		//		} else {

		EdgeBetweennessClusterer clusterer =
			new EdgeBetweennessClusterer(numEdgesToRemove);
		ClusterSet clusterSet = clusterer.extract(g);
		List edges = clusterer.getEdgesRemoved();

		int i = 0;
		//Set the colors of each node so that each cluster's vertices have the same color
		for (Iterator cIt = clusterSet.iterator(); cIt.hasNext();) {

			Set vertices = (Set) cIt.next();
			Color c = colors[i % colors.length];

			colorCluster(vertices, c);
			i++;
		}
		for (Iterator it = g.getEdges().iterator(); it.hasNext();) {
			Edge e = (Edge) it.next();
			if (edges.contains(e)) {
				e.setUserDatum(DEMOKEY, Color.LIGHT_GRAY, UserData.REMOVE);
//				System.out.println("Removed edge " + e );
			} else {
				e.setUserDatum(DEMOKEY, Color.BLACK, UserData.REMOVE);
			}
		}

	}

	private static void colorCluster(Set vertices, Color c) {
		for (Iterator iter = vertices.iterator(); iter.hasNext();) {
			Vertex v = (Vertex) iter.next();
			v.setUserDatum(DEMOKEY, c, UserData.REMOVE);
		}
	}
}
