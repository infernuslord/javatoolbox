/**
 * L2FProd.com Common Components 0.1-dev License.
 *
 * Copyright 2004 L2FProd.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.l2fprod.common.demo;

import com.l2fprod.common.swing.JDirectoryChooser;

import java.io.File;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;

/**
 * ChooseDirectory. <br>
 * A simple example showing how to use the JDirectoryChooser.
 */
public class ChooseDirectory {

  public static void main(String[] args) throws Exception {
    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    
    JDirectoryChooser chooser = new JDirectoryChooser();
    if (args.length > 0) {
      chooser.setSelectedFile(new File(args[0]));
    }
    
    JTextArea accessory = new JTextArea(
      "Select directory. Use the 'Control' key"
        + " to select several directories");
    accessory.setLineWrap(true);
    accessory.setWrapStyleWord(true);
    accessory.setEditable(false);
    accessory.setOpaque(false);
    accessory.setFont(UIManager.getFont("Tree.font"));
    
    chooser.setAccessory(accessory);
    
    chooser.setMultiSelectionEnabled(true);
        
    int choice = chooser.showOpenDialog(null);
    if (choice == JDirectoryChooser.APPROVE_OPTION) {
      String message = "You selected:";
      File[] selectedFiles = chooser.getSelectedFiles();
      for (int i = 0, c = selectedFiles.length; i < c; i++) {
        message += "\n" + selectedFiles[i];
      }
      JOptionPane.showMessageDialog(null, message);
    } else {
      JOptionPane.showMessageDialog(null, "You clicked 'Cancel'");      
    }
    
    System.exit(0);
  }

}
