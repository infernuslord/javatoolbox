/*
 * Please see COPYING for license details
 *
 * Copyright (C) 2003 Raghu K, All rights reserved.
 */

package hamsam.exception;

/**
 * Signals that a method has been invoked at an illegal or inappropriate time.
 * In other words, the Hamsam API is not in an appropriate state for the requested
 * operation. 
 */
public class IllegalStateException extends HamsamException
{
	/**
	 * Constructs an <code>IllegalStateException<code> with no detailed message.
	 */
	public IllegalStateException()
	{
		super();
	}

	/**
	 * Constructs an <code>IllegalStateException</code> with the specified detail
	 * message.
	 *
	 * @param message the detail message. The detail message is saved for later
	 *                retrieval by the Throwable.getMessage() method.
	 */
	public IllegalStateException(String message)
	{
		super(message);
	}
}
