/*
 * 
 * Created on 2004-jul-25
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.ui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.Box;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.UIResource;
import javax.swing.plaf.basic.BasicOptionPaneUI;

import se.diod.hippo.plaf.common.Border;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-25
 *
 */
public class HippoOptionPaneUI extends BasicOptionPaneUI implements UIResource {

	private static String newline;


	static {
		java.security.AccessController.doPrivileged(
			new java.security.PrivilegedAction() {
				public Object run() {
			newline = System.getProperty("line.separator");
			if (newline == null) {
				newline = "\n";
			}
			return null;
				}
			}
		);
	}






	/////////////////////////////////////////////////
	//                   Create                    //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	public static ComponentUI createUI( JComponent c ) {
		return new HippoOptionPaneUI();
	}






	/////////////////////////////////////////////////
	//                  Install                    //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	public void installUI( JComponent c ) {
		super.installUI( c );
	}






	/////////////////////////////////////////////////
	//                 Uninstall                   //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	public void uninstallUI( JComponent c ) {
		super.uninstallUI( c );
	}






	/////////////////////////////////////////////////
	//                   Other                     //
	/////////////////////////////////////////////////
	protected void installComponents() {
		optionPane.setBorder( Border.getEmptyBorder() );
		optionPane.add( createMessageArea() );

		Container separator = createSeparator();
		if( separator != null ) {
			optionPane.add( separator );
		}

		optionPane.add( createButtonArea() );
		optionPane.applyComponentOrientation( optionPane.getComponentOrientation() );
	}




	/**
	 * 
	 * Messaged from installComponents to create a Container containing the
	 * body of the message. The icon is the created by calling
	 * <code>addIcon</code>.
	 * 
	 */
	protected Container createMessageArea() {
	    JPanel top = new JPanel();
	    top.setBorder(UIManager.getBorder("OptionPane.messageAreaBorder"));
	    top.setLayout(new BorderLayout());

	    /* Fill the body. */
	    Container          body = new JPanel() {};
	    Container          realBody = new JPanel() {};

	    realBody.setLayout(new BorderLayout());

	    if (getIcon() != null) {
	        Container sep = new JPanel() {
	            public Dimension getPreferredSize() {
	                return new Dimension(15, 1);
	            }
	        };
	        realBody.add(sep, BorderLayout.BEFORE_LINE_BEGINS);
	    }
	    realBody.add(body, BorderLayout.CENTER);

	    body.setLayout(new GridBagLayout());
	    GridBagConstraints cons = new GridBagConstraints();
	    cons.gridx = cons.gridy = 0;
	    cons.gridwidth = GridBagConstraints.REMAINDER;
	    cons.gridheight = 1;
	    cons.anchor = GridBagConstraints.LINE_START;
	    cons.insets = new Insets(0,0,3,0);

	    addMessageComponents(body, cons, getMessage(),
	            getMaxCharactersPerLineCount(), false);
	    top.add(realBody, BorderLayout.CENTER);
	    
	    addIcon(top);
	    return top;

	    
	    /*
	    JPanel iconPane = new JPanel();
		iconPane.setLayout( new BorderLayout() );

		JPanel parent = new JPanel();
		parent.setLayout( new BorderLayout() );

		JPanel top = new JPanel();
		top.setBorder(UIManager.getBorder("OptionPane.messageAreaBorder"));
		top.setLayout(new BorderLayout());

		// Fill the body.
		Container          body = new JPanel() {};
		Container          realBody = new JPanel() {};

		realBody.setLayout(new BorderLayout());

		if (getIcon() != null) {
			Container sep = new JPanel() {
				public Dimension getPreferredSize() {
					return new Dimension(15, 1);
				}
			};
			realBody.add(sep, BorderLayout.BEFORE_LINE_BEGINS);
		}
		realBody.add(body, BorderLayout.CENTER);

		body.setLayout(new GridBagLayout());
		GridBagConstraints cons = new GridBagConstraints();
		cons.gridx = cons.gridy = 0;
		cons.gridwidth = GridBagConstraints.REMAINDER;
		cons.gridheight = 1;
		cons.anchor = GridBagConstraints.LINE_START;
		cons.insets = new Insets(0,0,3,0);
	
		addMessageComponents(body, cons, getMessage(), getMaxCharactersPerLineCount(), false);
		top.add(realBody, BorderLayout.CENTER);
	
		//addIcon(top);
		addIcon(iconPane);

		parent.add( iconPane, BorderLayout.NORTH );
		parent.add( top, BorderLayout.CENTER );

		//return top;
		return parent;
		*/
	}




	/**
	 * Creates and adds a JLabel representing the icon returned from
	 * <code>getIcon</code> to <code>top</code>. This is messaged from
	 * <code>createMessageArea</code>
	 */
	protected void addIcon( Container top ) {

		/* Create the icon. */
	    /*
	    Icon                  sideIcon = getIcon();

		if (sideIcon != null) {
			JPanel jp = new JPanel();
			//jp.setBackground( new Color( 245, 245, 245 ) );
			//jp.setSize( 200, 200 );

			JLabel            iconLabel = new JLabel(sideIcon);

			//java.net.URL imageURL = se.diod.hippo.plaf.HippoLookAndFeel.class.getResource("icons/dialogicon.gif");
			JLabel            iconLabel2 = new JLabel( "Warning!"/*new ImageIcon( imageURL )*/// );
			/*
			iconLabel.setVerticalAlignment(SwingConstants.TOP);
			//top.add(iconLabel, BorderLayout.BEFORE_LINE_BEGINS);
			//top.add( iconLabel, BorderLayout.NORTH );
			jp.setLayout( new BorderLayout() );
			jp.add( iconLabel, BorderLayout.EAST );
			//jp.add( iconLabel2, BorderLayout.WEST );
			//jp.setBorder( Border.getDialogPanelBorder() );

			top.add( jp, BorderLayout.WEST );
		} else {
			// Create white area without icon, or?
		}*/
			
			/* Create the icon. */
			Icon                  sideIcon = getIcon();

			if (sideIcon != null) {
			    JLabel            iconLabel = new JLabel(sideIcon);

			    iconLabel.setVerticalAlignment(SwingConstants.TOP);
			    top.add(iconLabel, BorderLayout.BEFORE_LINE_BEGINS);
			}
	}




	/**
	 * Creates the appropriate object to represent <code>msg</code> and
	 * places it into <code>container</code>. If <code>msg</code> is an
	 * instance of Component, it is added directly, if it is an Icon,
	 * a JLabel is created to represent it, otherwise a JLabel is
	 * created for the string, if <code>d</code> is an Object[], this
	 * method will be recursively invoked for the children.
	 * <code>internallyCreated</code> is true if Objc is an instance
	 * of Component and was created internally by this method (this is
	 * used to correctly set hasCustomComponents only if !internallyCreated).
	 */
	protected void addMessageComponents(Container container,
					 GridBagConstraints cons,
					 Object msg, int maxll,
					 boolean internallyCreated) {
	if (msg == null) {
		return;
		}

	if (msg instanceof Component) {
			// To workaround problem where Gridbad will set child
			// to its minimum size if its preferred size will not fit
			// within allocated cells
			if (msg instanceof JScrollPane || msg instanceof JPanel) {
				cons.fill = GridBagConstraints.BOTH;
				cons.weighty = 1;
			} else {
			cons.fill = GridBagConstraints.HORIZONTAL;
			}
		cons.weightx = 1;

		container.add((Component) msg, cons);
		cons.weightx = 0;
			cons.weighty = 0;
		cons.fill = GridBagConstraints.NONE;
		cons.gridy++;
		if (!internallyCreated) {
		hasCustomComponents = true;
			}

	} else if (msg instanceof Object[]) {
		Object [] msgs = (Object[]) msg;
		for (int i = 0; i < msgs.length; i++) {
		addMessageComponents(container, cons, msgs[i], maxll, false);
			}

	} else if (msg instanceof Icon) {
		JLabel label = new JLabel( (Icon)msg, SwingConstants.CENTER );
			configureMessageLabel(label);
		addMessageComponents(container, cons, label, maxll, true);

	} else {
		String s = msg.toString();
		int len = s.length();
		if (len <= 0) {
		return;
			}
		int nl = -1;
		int nll = 0;

		if ((nl = s.indexOf(newline)) >= 0) {
		nll = newline.length();
		} else if ((nl = s.indexOf("\r\n")) >= 0) {
			nll = 2;
		} else if ((nl = s.indexOf('\n')) >= 0) {
			nll = 1;
		}
		if (nl >= 0) {
		// break up newlines
		if (nl == 0) {
			addMessageComponents(container, cons, new Component() {
				public Dimension getPreferredSize() {
				Font       f = getFont();
			    
				if (f != null) {
				return new Dimension(1, f.getSize() + 2);
							}
				return new Dimension(0, 0);
				}
			}, maxll, true);
		} else {
			addMessageComponents(container, cons, s.substring(0, nl),
					  maxll, false);
				}
		addMessageComponents(container, cons, s.substring(nl + nll), maxll,
				  false);

		} else if (len > maxll) {
		Container c = Box.createVerticalBox();
		burstStringInto(c, s, maxll);
		addMessageComponents(container, cons, c, maxll, true );

		} else {
			JLabel label;
		label = new JLabel( s, JLabel.LEADING );
		configureMessageLabel(label);
		addMessageComponents(container, cons, label, maxll, true);
		}
	}
	}




	/**
	 * Configures any necessary colors/fonts for the specified label
	 * used representing the message.
	 */
	private void configureMessageLabel(JLabel label) {
		label.setForeground(UIManager.getColor(
							"OptionPane.messageForeground"));
		Font messageFont = UIManager.getFont("OptionPane.messageFont");
		if (messageFont != null) {
			label.setFont( messageFont );
		}
	}
}
