package com.thoughtworks.qdox.model;

public interface JavaClassCache {
    public JavaClass getClassByName(String name);
}
