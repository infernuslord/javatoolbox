/*
 * 
 * Created on 2004-jul-22
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.common;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.io.Serializable;

import javax.swing.ButtonModel;
import javax.swing.Icon;
import javax.swing.JCheckBox;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComponent;
import javax.swing.JRadioButton;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.UIManager;




/**
 * @author Robert Karlsson
 * @created 2004-jul-22
 *
 */
public class IconFactory {
	// Cached Icons
	private static Icon checkBoxIcon;
	private static Icon radioButtonIcon;
	private static Icon radioButtonMenuItemIcon;
	private static Icon iFrameCloseIcon;
	private static Icon iFrameWindowIcon;
	private static Icon iFrameMaximizeIcon;
	private static Icon iFrameMinimizeIcon;
	private static Icon iFrameIconifyIcon;
	private static Icon treeExpandedIcon;
	private static Icon treeCollapsedIcon;
	private static Icon sliderHorizontalIcon;
	private static Icon sliderVerticalIcon;
	private static Icon transparentIcon;
	private static Icon comboBoxButtonIcon;




	/**
	 * 
	 * Answers an <code>Icon</code> used in <code>JCheckBox</code>es.
	 * 
	 */		
	public static Icon getCheckBoxIcon() {
		if( checkBoxIcon == null ) {
			checkBoxIcon = new CheckBoxIcon();
		}
		return checkBoxIcon;
	}




	/**
	 * 
	 * Answers an <code>Icon</code> used in <code>JCheckBox</code>es.
	 * 
	 */		
	public static Icon getRadioButtonIcon() {
		if( radioButtonIcon == null ) {
			radioButtonIcon = new RadioButtonIcon();
		}
		return radioButtonIcon;
	}




	/**
	 * 
	 * Answers an <code>Icon</code> used in <code>JCheckBox</code>es.
	 * 
	 */		
	public static Icon getRadioButtonMenuItemIcon() {
		if( radioButtonMenuItemIcon == null ) {
			radioButtonMenuItemIcon = new RadioButtonMenuItemIcon();
		}
		return radioButtonMenuItemIcon;
	}




	/**
	 * Answers an <code>Icon</code> used in <code>InternalFrame</code>s.
	 */		
	public static Icon getIFrameCloseIcon() {
		if( iFrameCloseIcon == null ) {
			iFrameCloseIcon = new IFrameCloseIcon();
		}
		return iFrameCloseIcon;
	}




	/**
	 * Answers an <code>Icon</code> used in <code>InternalFrame</code>s.
	 */		
/*	public static Icon getIFrameWindowIcon() {
		if( iFrameWindowIcon == null ) {
			iFrameWindowIcon = new IFrameWindowIcon();
		}
		return iFrameWindowIcon;
	}

*/


	/**
	 * Answers an <code>Icon</code> used in <code>InternalFrame</code>s.
	 */		
	public static Icon getIFrameMaximizeIcon() {
		if( iFrameMaximizeIcon == null ) {
			iFrameMaximizeIcon = new IFrameMaximizeIcon();
		}
		return iFrameMaximizeIcon;
	}




	/**
	 * Answers an <code>Icon</code> used in <code>InternalFrame</code>s.
	 */		
	public static Icon getIFrameMinimizeIcon() {
		if( iFrameMinimizeIcon == null ) {
			iFrameMinimizeIcon = new IFrameMinimizeIcon();
		}
		return iFrameMinimizeIcon;
	}




	/**
	 * Answers an <code>Icon</code> used in <code>InternalFrame</code>s.
	 */		
	public static Icon getIFrameIconifyIcon() {
		if( iFrameIconifyIcon == null ) {
			iFrameIconifyIcon = new IFrameIconifyIcon();
		}
		return iFrameIconifyIcon;
	}




	/**
	 * Answers an <code>Icon</code> used in <code>JTree</code>s.
	 */		
	public static Icon getExpandedTreeIcon() {
		if (treeExpandedIcon == null) {
			treeExpandedIcon = new TreeExpandedIcon();
		}
		return treeExpandedIcon;
	}




	/**
	 * Answers an <code>Icon</code> used in <code>JTree</code>s.
	 */		
	public static Icon getCollapsedTreeIcon() {
		if (treeCollapsedIcon == null) {
			treeCollapsedIcon = new TreeCollapsedIcon();
		}
		return treeCollapsedIcon;
	}




	/**
	 * Answers an <code>Icon</code> used in <code>Slider</code>s.
	 */		
	public static Icon getSliderHorizontalIcon() {
		if( sliderHorizontalIcon == null ) {
			sliderHorizontalIcon = new SliderHorizontalIcon();
		}
		return sliderHorizontalIcon;
	}
	
	
	

	/**
	 * Answers an <code>Icon</code> used in <code>Slider</code>s.
	 */		
	public static Icon getSliderVerticalIcon() {
		if( sliderVerticalIcon == null ) {
			sliderVerticalIcon = new SliderVerticalIcon();
		}
		return sliderVerticalIcon;
	}




	/**
	 * Answers an <code>Icon</code> used in <code>MenuItem</code>s.
	 */		
	public static Icon getTransparentIcon() {
		if( transparentIcon == null ) {
			transparentIcon = new TransparentIcon();
		}
		return transparentIcon;
	}




	/**
	 * Answers an <code>Icon</code> used in <code>ComboBoxButton</code>s.
	 */		
	public static Icon getComboBoxButtonIcon() {
		if( comboBoxButtonIcon == null ) {
			comboBoxButtonIcon = new ComboBoxButtonIcon();
		}
		return comboBoxButtonIcon;
	}






	/**
	 * 
	 * Icon used in <code>JCheckBoxMenuItem</code>.
	 * 
	 */
	private static class CheckBoxIcon implements Icon, Serializable {
		final static int CSIZE		= 9;
		final static int Y_OFFSET	= 0;
		final static int X_OFFSET	= -2;

		public void paintIcon( Component c, Graphics g, int x, int y ) {
			ButtonModel model		= null;
			if( c instanceof JCheckBoxMenuItem ) {
				JCheckBoxMenuItem cb	= (JCheckBoxMenuItem) c;
				model = cb.getModel();
			} else {
				JCheckBox cb	= (JCheckBox) c;
				model		= cb.getModel();
			}

			// Clear background..
			g.setColor( new java.awt.Color( 245, 245, 245 ) );
			g.fillRect(x + X_OFFSET, y + Y_OFFSET, CSIZE, CSIZE );

			if( model.isEnabled() ) {
				g.setColor( new java.awt.Color( 0, 0, 0 ) );
			} else {
				g.setColor( new java.awt.Color( 155, 155, 155, 255 ) );
			}

			// Draw square..
			g.drawRect(x + X_OFFSET, y + Y_OFFSET, CSIZE, CSIZE );

			// Draw selection..
			if( model.isSelected() ) {
				g.translate( x, y );
				g.fillRect( 2 + X_OFFSET, 2 + Y_OFFSET, CSIZE-3, CSIZE-3 );
				g.translate( -x, -y );
			}
		}

		public int getIconWidth()  { return CSIZE; }
		public int getIconHeight() { return CSIZE; }
	}




	/**
	 * 
	 * The arrow button used in comboboxes.
	 * 
	 */
	private static class RadioButtonIcon implements Icon, Serializable {
		private static final int CSIZE = 12;
		final static int Y_OFFSET	= 1;
		final static int X_OFFSET	= -2;

		public void paintIcon( Component c, Graphics g, int x, int y ) {
			JRadioButton b = ( JRadioButton )c;
			ButtonModel model = b.getModel();

			// Antialiasing fonts to get rid of the jaggies..
			java.awt.Graphics2D g2d = (java.awt.Graphics2D)g;
			g2d.addRenderingHints(new java.awt.RenderingHints( java.awt.RenderingHints.KEY_ANTIALIASING , java.awt.RenderingHints.VALUE_ANTIALIAS_ON ));

			g.translate( x + X_OFFSET, y + Y_OFFSET );

			g.setColor( new Color( 245, 245, 245 ) );
			g.fillOval( 0, 0, CSIZE-2, CSIZE-1 );

			if( c.isEnabled() )
				g.setColor( new Color( 0, 0, 0 ) );
			else
				g.setColor( new Color( 125, 125, 125 ) );
				
			g.drawOval( 0, 0, CSIZE-2, CSIZE-2 );

			if( model.isSelected() ) { drawDot( g, x, y ); }

			g.translate( -(x + X_OFFSET), -(y + Y_OFFSET) );
		}

		private void drawDot( Graphics g, int x, int y ) {
			g.setColor( new Color( 0, 0, 0 ) );
			g.fillOval( 3, 3, CSIZE-7, CSIZE-7 );
		}

		public int getIconWidth()	{ return CSIZE; }
		public int getIconHeight()	{ return CSIZE; }
	}




	/**
	 * 
	 * The arrow button used in comboboxes.
	 * 
	 */
	private static class RadioButtonMenuItemIcon implements Icon, Serializable {
		private static final int CSIZE	= 12;
		final static int Y_OFFSET		= 1;
		final static int X_OFFSET		= -2;
	
		public void paintIcon( Component c, Graphics g, int x, int y ) {
			JRadioButtonMenuItem b = ( JRadioButtonMenuItem )c;
	
			// Antialiasing fonts to get rid of the jaggies..
			java.awt.Graphics2D g2d = (java.awt.Graphics2D)g;
			g2d.addRenderingHints(new java.awt.RenderingHints( java.awt.RenderingHints.KEY_ANTIALIASING , java.awt.RenderingHints.VALUE_ANTIALIAS_ON ));
	
			g.translate( x + X_OFFSET, y + Y_OFFSET );
	
			g.setColor( new Color( 245, 245, 245 ) );
			g.fillOval( 0, 0, CSIZE-2, CSIZE-1 );
	
			g.setColor( new Color( 0, 0, 0 ) );
			g.drawOval( 0, 0, CSIZE-2, CSIZE-2 );
	
			if (b.isSelected()) { drawDot( g, x, y ); }
	
			g.translate( -(x + X_OFFSET), -(y + Y_OFFSET) );
		}
	 		
		private void drawDot( Graphics g, int x, int y ) {
			g.setColor( new Color( 0, 0, 0 ) );
			g.fillOval( 3, 3, CSIZE-7, CSIZE-7 );
		}
	
		public int getIconWidth()	{ return CSIZE; }
		public int getIconHeight()	{ return CSIZE; }
	}




	/**
	 * 
	 * The close button in InternalFrames.
	 * 
	 */
	private static class IFrameCloseIcon implements Icon, Serializable {
		public void paintIcon(Component c, Graphics g, int x, int y) {
			JComponent component = (JComponent)c;
			int iconWidth	= getIconWidth();
			int iconHeight	= getIconHeight();

			g.translate( x, y );

			// Set backgroundcolor..
			g.setColor( new Color( 178, 189, 203 ) );
			g.fillRect( 0, 0, iconWidth, iconHeight );

			// Draw icon..
			g.setColor( new java.awt.Color( 70, 70, 70 ) );
			g.drawLine( 3, 4, iconWidth - 6, iconHeight - 5 );
			g.drawLine( 4, 4, iconWidth - 5, iconHeight - 5 );

			g.drawLine( 3, iconHeight - 5, iconWidth - 6, 4 );
			g.drawLine( 4, iconHeight - 5, iconWidth - 5, 4 );

			// Draw icon border..
			g.setColor( new Color( 70, 70, 70 ) );
			g.drawRect( 0, 0, iconWidth-1, iconHeight-1 );

			g.translate( -x, -y );
		}

		public int getIconWidth()  { return 15; }
		public int getIconHeight() { return 15; }
	}




	/**
	 * 
	 * The window button in InternalFrames.
	 * 
	 */
	private static class IFrameWindowIcon implements Icon, Serializable {

		public void paintIcon(Component c, Graphics g, int x, int y) {
			int iconWidth	= getIconWidth();
			int iconHeight	= getIconHeight();

			g.translate( x, y );

			// Set backgroundcolor..
			g.setColor( new Color( 178, 189, 203 ) );
			g.fillRect( 0, 0, iconWidth, iconHeight );

			g.setColor( new java.awt.Color( 70, 70, 70, 255 ) );
			g.drawLine( 2, 2, iconWidth-2, 2 );								// Top Line
			g.drawLine( 2, 5, iconWidth-2, 5 );								// Middle Line
			g.drawLine( 2, iconHeight-3, iconWidth-2, iconHeight-3 );		// Bottom Line

			g.drawLine( 2, 2, 2, iconHeight-3 );							// Left Line
			g.drawLine( iconWidth-2, 2, iconWidth-2, iconHeight-3 );							// Right Line

			// Draw icon border..
			g.setColor( new Color( 70, 70, 70 ) );
			g.drawRect( 0, 0, iconWidth-1, iconHeight-1 );

			g.translate( -x, -y );
		}

		public int getIconWidth()  { return 15; }
		public int getIconHeight() { return 15; }
	}




	/**
	 * 
	 * The maximize button in InternalFrames.
	 * 
	 */
	private static class IFrameMaximizeIcon implements Icon, Serializable {

		public void paintIcon(Component c, Graphics g, int x, int y) {
			int iconWidth	= getIconWidth();
			int iconHeight	= getIconHeight();
		
			g.translate( x, y );

			// Set backgroundcolor..
			g.setColor( new Color( 178, 189, 203 ) );
			g.fillRect( 0, 0, iconWidth, iconHeight );

			g.setColor( new java.awt.Color( 70, 70, 70, 255 ) );


			// Draw top lines
			g.drawLine( 3, 3, iconWidth - 4, 3 );
			g.drawLine( 3, 4, iconWidth - 4, 4 );

			// Draw left line
			g.drawLine( 3, iconHeight - 5, 3, 5 );

			// Draw right line
			g.drawLine( iconWidth - 4, iconHeight - 5, iconWidth - 4, 5 );
			
			// Draw bottom line
			g.drawLine( 3, iconHeight - 5, iconWidth - 4, iconHeight - 5 );

			// Draw icon border..
			g.setColor( new Color( 70, 70, 70 ) );
			g.drawRect( 0, 0, iconWidth-1, iconHeight-1 );

			g.translate( -x, -y );
		}

		public int getIconWidth()  { return 15; }
		public int getIconHeight() { return 15; }
	}




	/**
	 * 
	 * The close button in InternalFrames.
	 * 
	 */
	private static class IFrameMinimizeIcon implements Icon, Serializable {

		public void paintIcon(Component c, Graphics g, int x, int y) {
			int iconWidth	= getIconWidth();
			int iconHeight	= getIconHeight();
		
			g.translate( x, y );

			// Set backgroundcolor..
			g.setColor( new Color( 178, 189, 203 ) );
			g.fillRect( 0, 0, iconWidth, iconHeight );

			g.setColor( new java.awt.Color( 70, 70, 70, 255 ) );

			// [DRAW BOTTOM WINDOW]
			// Draw top lines
			g.drawLine( 5, 3, iconWidth - 5, 3 );
			g.drawLine( 5, 4, iconWidth - 5, 4 );
			// Draw left line
			g.drawLine( 5, 4, 5, 5 );
			// Draw right line
			g.drawLine( iconWidth - 5, 8, iconWidth - 5, 4 );
			// Draw bottom line
			g.drawLine( iconWidth - 7, iconHeight - 7, iconWidth - 5, iconHeight - 7 );

			// [DRAW TOP WINDOW]
			// Draw top lines
			g.drawLine( 3, 6, iconWidth - 7, 6 );
			g.drawLine( 3, 7, iconWidth - 7, 7 );
			// Draw left line
			g.drawLine( 3, iconHeight - 5, 3, 7 );
			// Draw right line
			g.drawLine( iconWidth - 7, iconHeight - 5, iconWidth - 7, 7 );
			// Draw bottom line
			g.drawLine( 3, iconHeight - 5, iconWidth - 7, iconHeight - 5 );

			// Draw icon border..
			g.setColor( new Color( 70, 70, 70 ) );
			g.drawRect( 0, 0, iconWidth-1, iconHeight-1 );

			g.translate( -x, -y );
		}

		public int getIconWidth()  { return 15; }
		public int getIconHeight() { return 15; }
	}




	/**
	 * 
	 * The close button in InternalFrames.
	 * 
	 */
	private static class IFrameIconifyIcon implements Icon, Serializable {

		public void paintIcon(Component c, Graphics g, int x, int y) {
			int iconWidth	= getIconWidth();
			int iconHeight	= getIconHeight();
		
			g.translate( x, y );

			// Set backgroundcolor..
			g.setColor( new Color( 178, 189, 203 ) );
			g.fillRect( 0, 0, iconWidth, iconHeight );

			g.setColor( new java.awt.Color( 70, 70, 70, 255 ) );
			g.drawLine( 3, iconHeight - 5, iconWidth - 5, iconHeight - 5 );
			g.drawLine( 3, iconHeight - 6, iconWidth - 5, iconHeight - 6 );

			// Draw icon border..
			g.setColor( new Color( 70, 70, 70 ) );
			g.drawRect( 0, 0, iconWidth-1, iconHeight-1 );

			g.translate( -x, -y );
		}

		public int getIconWidth()  { return 15; }
		public int getIconHeight() { return 15; }
	}




	/**
	 * 
	 * The minus sign button icon used in trees
	 * 
	 */
	private static class TreeExpandedIcon implements Icon, Serializable {
    	
		protected static final int SIZE      = 9;
		protected static final int HALF_SIZE = 4;

		public void paintIcon(Component c, Graphics g, int x, int y) {
			Color backgroundColor = c.getBackground();

			g.setColor(backgroundColor != null ? backgroundColor : Color.white);
			g.fillRect(x, y, SIZE - 1, SIZE - 1);

			g.setColor( UIManager.getColor( "Tree.hash" ) );
			g.drawRect(x, y, SIZE - 1, SIZE - 1);

			g.setColor( Color.BLACK );
			g.drawLine(x + 2, y + HALF_SIZE, x + (SIZE - 3), y + HALF_SIZE);
		}
		
		public int getIconWidth()	{ return SIZE; }
		public int getIconHeight() { return SIZE; }
	}
    



	/**
	 * 
	 * The plus sign button icon used in trees.
	 * 
	 */
	private static class TreeCollapsedIcon extends TreeExpandedIcon {
		public void paintIcon(Component c, Graphics g, int x, int y) {
			super.paintIcon(c, g, x, y);

			g.setColor( Color.BLACK );
			g.drawLine(x + HALF_SIZE, y + 2, x + HALF_SIZE, y + (SIZE - 3));
		}
	}




	/**
	 * 
	 * Slider horizontal icon
	 * 
	 */
	private static class SliderHorizontalIcon implements Icon, Serializable {
		//protected static final int Y_SIZE      = 15;
		//protected static final int X_SIZE      = 15;
		protected static final int Y_SIZE      = 15;
		protected static final int X_SIZE      = 8;

		public void paintIcon( Component c, Graphics g, int x, int y ) {
			Color backgroundColor = c.getBackground();
	
			g.setColor( backgroundColor != null ? backgroundColor : Color.white );
			//g.setColor( Color.red );
			g.setColor( new Color( 198, 209, 223 ) );  // TODO FIXED COLOR, BIG NONO!
			g.fillRect(x, y, getIconWidth()-1, getIconHeight()-1);

			g.setColor( Color.gray );
			g.drawRect(x, y, getIconWidth()-1, getIconHeight()-1 );
			//g.drawRect(x, y, getIconWidth()-1, getIconHeight()-1);
		}

		public int getIconWidth()	{ return X_SIZE; }
		public int getIconHeight()	{ return Y_SIZE; }
	}




	/**
	 *
	 * Slider vertical icon
	 * 
	 */
	private static class SliderVerticalIcon implements Icon, Serializable {
		protected static final int Y_SIZE      = 8;
		protected static final int X_SIZE      = 15;
		//protected static final int X_SIZE      = 20;
		
		public void paintIcon( Component c, Graphics g, int x, int y ) {
			Color backgroundColor = c.getBackground();

			//g.setColor( backgroundColor != null ? backgroundColor : Color.white );
			g.setColor( new Color( 198, 209, 223 ) );  // TODO FIXED COLOR, BIG NONO!
			g.fillRect( x, y, getIconWidth()-1, getIconHeight()-1 );
			//g.fillRect( x, y, getIconWidth()-1, getIconHeight()-1 );

			g.setColor( Color.gray );
			//g.drawRect( x, y, getIconWidth()-6, getIconHeight()-1 );
			g.drawRect( x, y, getIconWidth()-1, getIconHeight()-1 );
		}

		//public int getIconWidth()	{ return X_SIZE+5; }
		public int getIconWidth()	{ return X_SIZE; }
		public int getIconHeight()	{ return Y_SIZE; }
	}




	/**
	 * 
	 * Transparent icon
	 * 
	 */
	private static class TransparentIcon implements Icon, Serializable {
		final static int HEIGHT	= 10;
		final static int WIDTH	= 17;

		public void paintIcon(Component c, Graphics g, int x, int y) {}
		public int getIconHeight() { return HEIGHT; }
		public int getIconWidth()  { return WIDTH; }
	}




	/**
	 * 
	 * The arrow button used in comboboxes.
	 * 
	 */
	private static class ComboBoxButtonIcon implements Icon, Serializable {
	
		public void paintIcon(Component c, Graphics g, int x, int y) {
			JComponent component = (JComponent)c;
			int width	= getIconWidth();
			int height	= getIconHeight();
			
			g.translate( x, y );
	
			//g.setColor( java.awt.Color.white );
			//g.drawLine( 5, 4, width, 4 );
			//g.drawLine( 5, 1, 5, c.getHeight() );

			g.setColor( java.awt.Color.black );
	
			int offset = 2;
			g.fillRect( width / 2 - offset-1, height / 2 - offset, offset*2, offset*2 );

			g.translate( -x, -y );
		}
	
		public int getIconWidth()  { return 30; }
		public int getIconHeight() { return 24; }
	}
}
