package tool.pdf;

import java.io.*;
import java.util.Iterator;

import multivalent.std.adaptor.pdf.*;
import multivalent.ParseException;
import static multivalent.std.adaptor.pdf.COS.*;
import static multivalent.std.adaptor.pdf.SecurityHandlerStandard.*;

import phelps.lang.Integers;
import phelps.io.FileList;
import phelps.Utility;



/**
	Encrypt, possibly adding restrictions on document use.

	Copyright (c) 2002 - 2003  Thomas A. Phelps
	@version $Revision: 1.16 $ $Date: 2003/10/01 13:16:27 $
*/
public class Encrypt {
  static final boolean DEBUG = true;

  public static final String VERSION = "1.0.1 of $Date: 2003/10/01 13:16:27 $";
  public static final String USAGE = "java tool.pdf.Encrypt [options] <PDF-file...>\n" 
	+ "\t[-user <password>] [-owner <password>] [-password <existing-owner>]\n"
	+ "\t[-rest[rictions] [pPcCmtfa]]   [-perm[issions] [pPcCmtfa]]\n"
	+ "\t[-inplace]";
	// [-compat[ible]] 
	// [-out <file>]

  static final String PERMS = "  Pmct  fCap";

  private String ownerpassword_, userpassword_;
  /** Password of source if already encrypted. */
  private String password_;
  private int permissions_;
  private int keylen_;
  private boolean finplace_;
  private boolean fverbose_, fquiet_;

  public Encrypt() {
	defaults();
  }

  public void defaults() {
	ownerpassword_ = userpassword_ = password_ = null;
	permissions_ = PERM_ALL;
	keylen_ = 128;

	finplace_ = false;
	fverbose_ = fquiet_ = false;
  }

  public void setOwnerPassword(String password) { ownerpassword_=password; }
  public void setUserPassword(String password) { userpassword_=password; }
  /** Sets <em>owner</em> password of <em>source</em> document. */
  public void setPassword(String password) { password_=password; }

  /** Sets permissions from bit mask as defined in PDF Reference. */
  public void setPermissions(int perms) { permissions_=perms; }
  /**
	Permits passed actions, where <var>act</var> is one or more of <code>pPcCmtfa</code>.
	Equal in capability to {@link #setRestictions(String)}.
  */
  public void setPermissions(String actions) {
	if (actions.startsWith("all")) permissions_ = PERM_ALL;
	else {
		permissions_ = PERM_NONE;
		for (int i=0,imax=actions.length(); i<imax; i++) {
			int ch = actions.charAt(i);
			int x = PERMS.indexOf(ch);
			if (x!=-1) permissions_ |= (1 << x);
			else Utility.error("invalid permission letter: "+ch+".  Valid: pPcCmtfa.");
		}
	}
  }
  /**
	Restricts passed actions, where <var>actions</var> is one or more of <code>pPcCmtfa</code>.
	Equal in capability to {@link #setPermissions(String)}.
  */
  public void setRestrictions(String actions) {
	if (actions.startsWith("all")) permissions_ = PERM_NONE;
	else {
		permissions_ = PERM_ALL;
		for (int i=0,imax=actions.length(); i<imax; i++) {
			int ch = actions.charAt(i);
			int x = PERMS.indexOf(ch);
			if (x!=-1) permissions_ &= ~(1 << x);
			else Utility.error("invalid permission letter: "+ch+".  Valid: pPcCmtfa.");
		}
	}
  }

  /**
	If 40 bits, uses settings compatible with older PDF viewers (V=1, R=2), else newer settings introduced in PDF 1.4.
  */
  public void setKeyLength(int multipleof8) {
	if (multipleof8>=40 && (multipleof8 % 8) == 0) keylen_ = multipleof8;
  }



  /** Compute output filename and invoke {@link #encrypt(File,File)}. */
  public void encrypt(File in) throws IOException,IllegalStateException,ParseException {
	String path = in.getPath();
	// (ffirst && pathout!=null)? pathout: 
	String pathout = finplace_? path: (path.toLowerCase().endsWith(".pdf")? path.substring(0, path.length()-4): path) + "-y.pdf";
	encrypt(in, new File(pathout));
  }

  /**
	Reads file <var>in</var> and writes encrypted version to file <var>out</var>.
	<var>in</var> can be encrypted with a different password or encryption filter, so long as the owner password is supplied with {@link #setPassword(String)}.
  */
  public void encrypt(File in, File out) throws IOException, ParseException {
	PDFReader pdfr = new PDFReader(in);
	//pdfr.setExact(true); => kills Compact
	if (pdfr.getTrailer().get("Encrypt")!=null) {
		SecurityHandler sh = pdfr.getEncrypt().getSecurityHandler();
		sh.authOwner(password_);
		if (!sh.isAuthorized()) sh.authOwner(ownerpassword_);	// if updating with same password
		if (!sh.isAuthorized()) throw new ParseException("existing owner password required");
	}

	pdfr.fault();	// handle bad vs handle infinite length

	PDFWriter pdfw = new PDFWriter(out, pdfr);
	if (fverbose_) pdfw.setMonitor(true);


	// fang new encrypt
	Dict trailer = pdfw.getTrailer();
	Object[] ID = (Object[])trailer.get("ID");
	StringBuffer ID0;
	if (ID==null) ID0 = (StringBuffer)ID[0];
	else { ID0 = COS.createID(in, pdfr.getInfo()); ID = new Object[] { ID0, ID0 }; trailer.put("ID", ID); }

	if (ownerpassword_==null) ownerpassword_ = userpassword_;	// no sense to make user stronger than owner
	int P = permissions_;
	int Length = keylen_;
	int V = Length==40? 1: 2;
	int R = V==1 /*&& P==SecurityHandlerStandard.PERM_ALL*/? 2: 3;
	//V=1; R=2; // works for 40-bit, not supposed to work for 128-bit
	//V=1; R=3;	// doesn't work for Adobe Reader 6/Mac
	//V=2; R=3;	// doesn't work with 40-bit, works with 128-bit

	Dict edict = new Dict(13);
	edict.put("Filter", "Standard");
	edict.put("V", Integers.getInteger(V));
	if (Length!=40) edict.put("Length", Integers.getInteger(Length));
	edict.put("R", Integers.getInteger(R));
	edict.put("P", Integers.getInteger(P));
	SecurityHandlerStandard sh = new SecurityHandlerStandard(ID0, R, P, Length, userpassword_, ownerpassword_);
	edict.put("U", sh.computeU(userpassword_));
	edict.put("O", sh.computeO(ownerpassword_, userpassword_));

//System.out.println("owner=|"+ownerpassword_+"|, user=|"+userpassword_+"| => "+edict);
//System.out.println("P = "+permissions_+" / "+Integer.toString(permissions_, 2));
//e.dump((StringBuffer)edict.get("O"), "O");
//e.dump((StringBuffer)edict.get("U"), "U");

	trailer.put("Encrypt", pdfw.addObject(edict));

	pdfw.setPassword(userpassword_);

	pdfw.writePDF();

	pdfw.close();
//System.out.println("mem use "+Runtime.getRuntime().totalMemory());
  }



  private int commandLine(String[] argv) {
	int argi=0, argc=argv.length;
	for ( ; argi < argc; argi++) {
		String arg = argv[argi]; if (!arg.startsWith("-")) break;
		if (arg.startsWith("-own"/*"er"*/)) setOwnerPassword(argv[++argi]);
		else if (arg.startsWith("-user")) setUserPassword(argv[++argi]);
		else if (arg.startsWith("-pass"/*word*/)) setPassword(argv[++argi]);
		else if (arg.startsWith("-rest"/*rictions*/)) setRestrictions(argv[++argi]);
		else if (arg.startsWith("-perm"/*"issions" or "it"*/)) setPermissions(argv[++argi]);
		//else if (arg.startsWith("-compat"/*ible*/)) setKeyLength(40); => global -compat flag
		else if (arg.startsWith("-keylen"/*ible*/)) {
			String numo = argv[++argi];
			try {
				int newlen = Integer.parseInt(numo);
				if (newlen<40 || newlen%8 != 0) Utility.error(newlen+ " must be >=40 and a multiple of 8");
				setKeyLength(newlen);
			} catch (NumberFormatException nfe) { Utility.error("Couldn't parse '"+numo+"' as a number"); }
		}

		else if (arg.equals("-inplace")) { finplace_=true; /*pathout=null;*/ }
		//else if (arg.startsWith("-out"/*file*/)) { pathout = argv[++argi]; finplace_=false; }

		else if (arg.startsWith("-verb")) fverbose_ = true;
		else if (arg.startsWith("-q"/*uiet*/)) fquiet_ = true;
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.startsWith("-h"/*"elp"*/)) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	if (argi == argc) { System.err.println(USAGE); System.exit(0); }

	return argi;
  }

  public static void main(String[] argv) {
	Encrypt e = new Encrypt();
    int argi = e.commandLine(argv);

	for (Iterator<File> i = new FileList(argv, argi, FILTER).iterator(); i.hasNext(); ) {
		File file = i.next();
		try {
			//if (fverbose_) System.out.println(file);
			e.encrypt(file);
		} catch (Exception ioe) {
			System.err.println(file+": "+ioe);
			if (DEBUG) ioe.printStackTrace();
		}
	}
  }
}
