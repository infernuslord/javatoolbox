package multivalent.std.adaptor.pdf;



/**
    PDF COS dictionary: keys are PDF names / Java Strings, values can be any PDF COS object.

	@version $Revision: 1.2 $ $Date: 2003/08/29 03:58:23 $
*/
public class Dict extends java.util.HashMap<Object,Object> {
  public Dict() { super(); }
  public Dict(int initialCapacity) { super(initialCapacity); }
  //public Dict(int initialCapacity, float loadFactor) { super(initialCapacity, loadFactor); }
  public Dict(Dict m) { super(m); }

  // in PostScript, any object can be a key, but strings are canonicalized to names
  // in PDF, al keys are names
  public Object put(Object key, Object value) { return super.put(key.getClass()==COS.CLASS_STRING? key.toString(): key, value); }
  public Object get(String key) { return super.get(key.getClass()==COS.CLASS_STRING? key.toString(): key); }
  public Object remove(String key) { return super.remove(key.getClass()==COS.CLASS_STRING? key.toString(): key); }
  public boolean containsKey(String key) { return super.containsKey(key.getClass()==COS.CLASS_STRING? key.toString(): key); }
}
