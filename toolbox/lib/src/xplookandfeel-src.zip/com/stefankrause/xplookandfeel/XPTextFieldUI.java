// Beta
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	XP Look and Feel                                                           *
*                                                                              *
*  (C) Copyright 2002, by Stefan Krause                                        *
*                                                                              *
*                                                                              *
*   This library is free software; you can redistribute it and/or modify it    *
*   under the terms of the GNU Lesser General Public License as published by   *
*   the Free Software Foundation; either version 2.1 of the License, or (at    *
*   your option) any later version.                                            *
*                                                                              *
*   This library is distributed in the hope that it will be useful,            *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of             *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                       *
*   See the GNU Lesser General Public License for more details.                *
*                                                                              *
*   You should have received a copy of the GNU General Public License along    *
*   with this program; if not, write to the Free Software Foundation, Inc.,    *
*   59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.                    *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */



package com.stefankrause.xplookandfeel;

import java.awt.Graphics;

import javax.swing.JComponent;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.metal.MetalTextFieldUI;
import javax.swing.text.JTextComponent;


public class XPTextFieldUI extends MetalTextFieldUI {
	
	JTextField textField;
	/**
	 * Method createUI.
	 * @param c
	 * @return ComponentUI
	 */
	public static ComponentUI createUI(JComponent c) {
		return new XPTextFieldUI();
	}

	/**
	 * @see javax.swing.plaf.basic.BasicTextFieldUI#installUI(javax.swing.JComponent)
	 */
	public void installUI(JComponent c) {
		super.installUI(c);
		textField=(JTextField)c;
	}

	protected void paintBackground(Graphics g) {			
		JTextComponent editor=getComponent();
		if (editor.isEnabled()) {
			g.setColor(editor.getBackground());
		} else {
			g.setColor(UIManager.getDefaults().getColor("TextField.disabledBackground"));
		}
		g.fillRect(0, 0, editor.getWidth(), editor.getHeight());
	}
}