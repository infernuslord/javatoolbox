/*
 * 
 * Created on 2004-jul-25
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.ui;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JScrollBar;
import javax.swing.UIManager;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.metal.MetalScrollBarUI;

import se.diod.hippo.plaf.common.ScrollButton;

/**
 * @author Robert
 * @created 2004-jul-25
 *
 */
public class HippoScrollBarUI extends MetalScrollBarUI {




	/**
	 * 
	 * 
	 */
	public static ComponentUI createUI( JComponent b ) {
		return new HippoScrollBarUI();
	}




	/**
	 * 
	 * 
	 */
	protected void installDefaults() {
		super.installDefaults();
	}




	/**
	 * 
	 * 
	 */
	protected JButton createDecreaseButton( int orientation ) {
		decreaseButton = new ScrollButton(orientation, scrollBarWidth, isFreeStanding);
		return decreaseButton;
	}




	/**
	 * 
	 * 
	 */
	protected JButton createIncreaseButton( int orientation ) {
		increaseButton = new ScrollButton(orientation, scrollBarWidth, isFreeStanding);
		return increaseButton;
	}




	/**
	 * 
	 * 
	 */
	protected void configureScrollBarColors() {
		super.configureScrollBarColors();
	} 




	/**
	 * 
	 * 
	 */
	protected void paintTrack( Graphics g, JComponent c, Rectangle trackBounds ) {
		Graphics g2 = g.create();
		g2.translate( trackBounds.x, trackBounds.y );

		boolean leftToRight = true;

		if( isFreeStanding ) {
			g2.setColor( scrollbar.getParent().getBackground() );
			g2.setColor( Color.white );  // TODO FIXED COLOR, BIG NONO!
			g2.fillRect( 0, 0, c.getWidth(), c.getHeight() );
		}
		
		if( !isFreeStanding ) {
			if (scrollbar.getOrientation() == JScrollBar.VERTICAL) {
				// Draw background line..
				g2.setColor( Color.lightGray );	// TODO FIXED COLOR, BIG NONO!
				g2.drawLine( trackBounds.width/2, 0, trackBounds.width/2, trackBounds.height );
			} else { // HORIZONTAL 
				// Draw background line..
				g2.setColor( Color.lightGray );	// TODO FIXED COLOR, BIG NONO!
				g2.drawLine( 0, trackBounds.height/2, trackBounds.width, trackBounds.height/2 );
			}
		} else {
			if (scrollbar.getOrientation() == JScrollBar.VERTICAL) {
				// Draw background line..
				g2.setColor( Color.lightGray );  // TODO FIXED COLOR, BIG NONO!
				g2.drawLine( 0, 0, 0, trackBounds.height );
				g2.drawLine( trackBounds.width-1, 0, trackBounds.width-1, trackBounds.height );
			} else { // HORIZONTAL 
				// Draw background line..
				g2.setColor( Color.lightGray );  // TODO FIXED COLOR, BIG NONO!
				g2.drawLine( 0, 0, trackBounds.width, 0 );
				g2.drawLine( 0, trackBounds.height-1, trackBounds.width, trackBounds.height-1 );
			}
		}

		g2.dispose();
	}	




	/**
	 * 
	 * 
	 */
	protected void paintThumb( Graphics g, JComponent c, Rectangle thumbBounds ) {
		Graphics g2 = g.create();
		if (!c.isEnabled()) {
			return;
		}

		boolean leftToRight = true;

		g2.translate(thumbBounds.x, thumbBounds.y);

		if (scrollbar.getOrientation() == JScrollBar.VERTICAL) {
			int offset	= 4; //(int)( thumbBounds.width * 0.30 );
			//int width	= (thumbBounds.width - 1) - offset-1;
			int width	= (thumbBounds.width - 1);
			int height	= thumbBounds.height - 1;

			// Fill thumb background..
			g2.setColor( UIManager.getColor( "ScrollBar.thumbBackground" ) );
			//g2.fillRect( 3, 0, width-1, height );
			g2.fillRect( 1, 0, width-1, height );

			// Draw thumb border..
			g2.setColor( UIManager.getColor( "ScrollBar.thumbBorderColor" ) );
			//g2.drawRect( 3, 0, width-1 , height );
			g2.drawRect( 0, 0, width , height );
		} else { // HORIZONTAL 
			int offset	= 4; //(int)( thumbBounds.width * 0.30 );
			int width	= (thumbBounds.width - 1);
			//int height	= thumbBounds.height - 1 - offset - 1;
			int height	= thumbBounds.height - 1;

			// Fill thumb background..
			g2.setColor( UIManager.getColor( "ScrollBar.thumbBackground" ) );
			//g2.fillRect( 0, 3, width, height-1 );
			g2.fillRect( 0, 1, width, height-1 );

			// Draw thumb border..
			g2.setColor( UIManager.getColor( "ScrollBar.thumbBorderColor" ) );
			//g2.drawRect( 0, 3, width , height-1 );
			g2.drawRect( 0, 0, width , height );
		}

		g2.dispose();
	}




	/**
	 * 
	 * 
	 */
	private void paintBumps( Graphics g, JComponent c, int x, int y, int width, int height ) {
	}






	///////////////////////////////////////////////////////
	//           Layout Manager Implementation           //
	///////////////////////////////////////////////////////
/*	public void addLayoutComponent(String name, Component child) {}
	public void removeLayoutComponent(Component child) {}

    


	/**
	 * 
	 * 
	 */
/*	public Dimension preferredLayoutSize(Container scrollbarContainer)  {
		return getPreferredSize((JComponent)scrollbarContainer);
	}
    



	/**
	 * 
	 * 
	 */
/*	public Dimension minimumLayoutSize(Container scrollbarContainer) {
		return getMinimumSize((JComponent)scrollbarContainer);
	}
    



	/**
	 * 
	 * 
	 */
/*	protected void layoutVScrollbar( JScrollBar sb ) {
		Dimension sbSize	= sb.getSize();
		Insets sbInsets		= sb.getInsets();

		// Width and left edge of the buttons and thumb.
		int itemW = sbSize.width - (sbInsets.left + sbInsets.right);
		int itemX = sbInsets.left;

		// Nominal locations of the buttons, assuming their preferred size will fit.
		int incrButtonH = incrButton.getPreferredSize().height;
		int incrButtonY = sbSize.height - (sbInsets.bottom + incrButtonH);
		int decrButtonH = decrButton.getPreferredSize().height;
		int decrButtonY = incrButtonY - decrButtonH; //sbInsets.top;

		// The thumb must fit within the height left over after we
		// subtract the preferredSize of the buttons and the insets.
		int sbInsetsH	= sbInsets.top + sbInsets.bottom;
		int sbButtonsH	= decrButtonH + incrButtonH;
		float trackH	= sbSize.height - (sbInsetsH + sbButtonsH);

		// Compute the height and origin of the thumb.   The case
		// where the thumb is at the bottom edge is handled specially 
		// to avoid numerical problems in computing thumbY.  Enforce
		// the thumbs min/max dimensions.  If the thumb doesn't
		// fit in the track (trackH) we'll hide it later.
		float min = sb.getMinimum();
		float extent = sb.getVisibleAmount();
		float range = sb.getMaximum() - min;
		float value = sb.getValue();

		int thumbH = (range <= 0) ? getMaximumThumbSize().height : (int)(trackH * (extent / range));
		thumbH = Math.max(thumbH, getMinimumThumbSize().height);
		thumbH = Math.min(thumbH, getMaximumThumbSize().height);

		int thumbY = incrButtonY - thumbH;  
		if (sb.getValue() < (sb.getMaximum() - sb.getVisibleAmount())) {
			float thumbRange = trackH - thumbH;
			thumbY = (int)(0.5f + (thumbRange * ((value - min) / (range - extent))));
			//thumbY +=  decrButtonY + decrButtonH;
		}

		// If the buttons don't fit, allocate half of the available 
		// space to each and move the lower one (incrButton) down.
		int sbAvailButtonH = (sbSize.height - sbInsetsH);
		if (sbAvailButtonH < sbButtonsH) {
			incrButtonH = decrButtonH = sbAvailButtonH / 2;
			incrButtonY = sbSize.height - (sbInsets.bottom + incrButtonH);
		}
		decrButton.setBounds( itemX, decrButtonY, itemW, decrButtonH );
		incrButton.setBounds( itemX, incrButtonY, itemW, incrButtonH );

		// Update the trackRect field.
		int itrackY = sbInsets.top; //decrButtonY + decrButtonH;
		int itrackH = sbSize.height - (decrButtonH + incrButtonH); //decrButtonY; //incrButtonY - itrackY;
		trackRect.setBounds(itemX, itrackY, itemW, itrackH);
	
		// If the thumb isn't going to fit, zero it's bounds.  Otherwise
		// make sure it fits between the buttons.  Note that setting the
		// thumbs bounds will cause a repaint.
		if( thumbH >= ( int )trackH ) {
			setThumbBounds(0, 0, 0, 0);
		} else {
			if ((thumbY + thumbH) > decrButtonY) {
				thumbY = decrButtonY - thumbH;
			}
			if (thumbY  < 0 ) {
				thumbY = 0;
			}
			setThumbBounds(itemX, thumbY, itemW, thumbH);
		}
	}
    



	/**
	 * 
	 * 
	 */
/*	protected void layoutHScrollbar(JScrollBar sb) {
		Dimension sbSize = sb.getSize();
		Insets sbInsets = sb.getInsets();
        
		// Height and top edge of the buttons and thumb.
		int itemH = sbSize.height - (sbInsets.top + sbInsets.bottom);
		int itemY = sbInsets.top;

		boolean ltr = sb.getComponentOrientation().isLeftToRight();

		// Nominal locations of the buttons, assuming their preferred
		// size will fit.
		int leftButtonW		= (ltr ? decrButton : incrButton).getPreferredSize().width; 
		int rightButtonW	= (ltr ? incrButton : decrButton).getPreferredSize().width;        
		int rightButtonX	= sbSize.width - (sbInsets.right + rightButtonW);
		int leftButtonX		= rightButtonX - leftButtonW; //sbInsets.left;        

		// The thumb must fit within the width left over after we
		// subtract the preferredSize of the buttons and the insets.
		int sbInsetsW		= sbInsets.left + sbInsets.right;
		int sbButtonsW		= leftButtonW + rightButtonW;
		float trackW		= sbSize.width - (sbInsetsW + sbButtonsW);
        
		// Compute the width and origin of the thumb.  Enforce
		// the thumbs min/max dimensions.  The case where the thumb 
		// is at the right edge is handled specially to avoid numerical 
		// problems in computing thumbX.  If the thumb doesn't
		// fit in the track (trackH) we'll hide it later.
		float min		= sb.getMinimum();
		float max		= sb.getMaximum();
		float extent	= sb.getVisibleAmount();
		float range		= max - min;
		float value		= sb.getValue();

		int thumbW = (range <= 0) ? getMaximumThumbSize().width : (int)(trackW * (extent / range));
		thumbW = Math.max(thumbW, getMinimumThumbSize().width);
		thumbW = Math.min(thumbW, getMaximumThumbSize().width);

		//int thumbX = ltr ? rightButtonX - thumbW : leftButtonX + leftButtonW;
		int thumbX = ltr ? 0 : 0;
		if (sb.getValue() < (max - sb.getVisibleAmount())) {
			float thumbRange = trackW - thumbW;
				if( ltr ) {
					thumbX = (int)(0.5f + (thumbRange * ((value - min) / (range - extent))));
				} else {
					thumbX = (int)(0.5f + (thumbRange * ((max - extent - value) / (range - extent))));
				}
			//thumbX +=  leftButtonX + leftButtonW;
		}

		// If the buttons don't fit, allocate half of the available 
		// space to each and move the right one over.
		int sbAvailButtonW = (sbSize.width - sbInsetsW);
		if (sbAvailButtonW < sbButtonsW) {
			rightButtonW = leftButtonW = sbAvailButtonW / 2;
			rightButtonX = sbSize.width - (sbInsets.right + rightButtonW);
		}
        
		(ltr ? decrButton : incrButton).setBounds(leftButtonX, itemY, leftButtonW, itemH);
		(ltr ? incrButton : decrButton).setBounds(rightButtonX, itemY, rightButtonW, itemH);

		// Update the trackRect field.
		int itrackX = 0; //leftButtonX + leftButtonW;
		int itrackW = sbSize.width - ( rightButtonW + leftButtonW ); //rightButtonX - itrackX;
		trackRect.setBounds(itrackX, itemY, itrackW, itemH);

		// Make sure the thumb fits between the buttons.  Note 
		// that setting the thumbs bounds causes a repaint.
		if( thumbW >= (int)trackW ) {
			setThumbBounds( 0, 0, 0, 0 );
		} else {
			if (thumbX + thumbW > leftButtonX) {
				thumbX = leftButtonX - thumbW;
			}
			if (thumbX  < 0 ) {
				thumbX = 0;
			}
			setThumbBounds(thumbX, itemY, thumbW, itemH);
		}
	}




	/**
	 * 
	 * 
	 */
/*	public void layoutContainer(Container scrollbarContainer) {
		// If the user is dragging the value, we'll assume that the 
		// scrollbars layout is OK modulo the thumb which is being 
		// handled by the dragging code.
		if (isDragging) { return; }

		JScrollBar scrollbar = (JScrollBar)scrollbarContainer;
		switch (scrollbar.getOrientation()) {
		case JScrollBar.VERTICAL:
			layoutVScrollbar(scrollbar);
			break;
            
		case JScrollBar.HORIZONTAL:
			layoutHScrollbar(scrollbar);
			break;
		}
	}*/
}
