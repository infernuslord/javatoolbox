// $Id: FollowingSiblingAxisExpr.java,v 1.1 2002/04/25 18:07:13 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

class FollowingSiblingAxisExpr extends AxisExpr 
{
    public NodeIterator eval(Node node, ExprContext context) {
        return node.getFollowingSiblings();
    }
    int getOptimizeFlags() {
        return SINGLE_LEVEL;
    }
}
