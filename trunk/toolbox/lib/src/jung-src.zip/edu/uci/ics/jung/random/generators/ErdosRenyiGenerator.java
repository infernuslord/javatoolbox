/*
* Copyright (c) 2003, the JUNG Project and the Regents of the University
* of California
* All rights reserved.
*
* This software is open-source under the BSD license; see either
* "license.txt" or
* http://jung.sourceforge.net/license.txt for a description.
*/
package edu.uci.ics.jung.random.generators;

import java.util.Random;

import edu.uci.ics.jung.graph.ArchetypeGraph;
import edu.uci.ics.jung.graph.UndirectedGraph;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.graph.decorators.Indexer;
import edu.uci.ics.jung.graph.impl.UndirectedSparseEdge;
import edu.uci.ics.jung.graph.impl.UndirectedSparseGraph;
import edu.uci.ics.jung.utils.GraphUtils;

/**
 * Random Generator of Erdos-Renyi "binomial model"
 *  @author William Giordano, Scott White
 */
public class ErdosRenyiGenerator implements GraphGenerator
{
    private int mNumVertices;
    private double mEdgeConnectionProbability;
    private Random mRandom;

    /**
     *
     * @param numVertices number of vertices graph should have
     * @param p Connection's probability between 2 vertices
     */
	public ErdosRenyiGenerator(int numVertices,double p)
    {
        if (numVertices <= 0) {
            throw new IllegalArgumentException("A positive # of vertices must be specified.");
        }
        mNumVertices = numVertices;
        if (p < 0 || p > 1) {
            throw new IllegalArgumentException("p must be between 0 and 1.");
        }
        mEdgeConnectionProbability = p;
        mRandom = new Random();
	}

	//Return the graph
	public ArchetypeGraph generateGraph() {
        UndirectedGraph g = new UndirectedSparseGraph();
        GraphUtils.addVertices(g,mNumVertices);
        Indexer id = Indexer.getIndexer(g);

		for (int i = 0; i < mNumVertices-1; i++)
		{
			for (int j = i+1; j < mNumVertices; j++)
			{
                Vertex v_i = (Vertex) id.getVertex(i);
                Vertex v_j = (Vertex) id.getVertex(j);

				if ((mRandom.nextDouble()<mEdgeConnectionProbability) && !v_i.isNeighborOf(v_j))
				{
					g.addEdge(new UndirectedSparseEdge(v_i, v_j));
				}
			}
		}
        return g;
    }

    public void setSeed(long seed) {
        mRandom.setSeed(seed);
    }
}











