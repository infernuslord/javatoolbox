package multivalent.std.ui;

import java.io.*;
import java.net.URI;
import javax.swing.JFileChooser;

import com.pt.io.Cache;
import com.pt.io.FileList;

import multivalent.*;
import multivalent.gui.VMenu;



/**
	Save current document to path chosen with a file chooser.

<!--
	Doesn't need to be page aware because Layer.save() is.
-->

	@version $Revision: 1.1 $ $Date: 2002/02/01 06:24:08 $
*/
public class SaveAs extends Behavior {
  /**
	Save current document to new file.
	<p><tt>"savePageAs"</tt>.
  */
  public static final String MSG_SAVE_AS = "savePageAs";


  static JFileChooser jc_ = null;	// static OK because modal means can only have one at a time



  /** Disabled if viewing directory. */
  public boolean semanticEventBefore(SemanticEvent se, String msg) {
	if (super.semanticEventBefore(se,msg)) return true;
	else if (VMenu.MSG_CREATE_FILE==msg) {
		Browser br = getBrowser();
		Document doc = br.getCurDocument();
		URI uri = doc.getURI();

		boolean fempty = (uri==null || ("file".equals(uri.getScheme()) && uri.getPath().endsWith("/")));  // can't save directory
		INode menu = (INode)se.getOut();
		createUI("button", "Save Document As...", "event "+MSG_SAVE_AS, menu, StandardFile.MENU_CATEGORY_SAVE, fempty);
	}
	return false;
  }


  /** On "saveAnnosAs" semantic event, pop up dialog and save. */
  public boolean semanticEventAfter(SemanticEvent se, String msg) {
	if (MSG_SAVE_AS==msg) {
		// LATER: arg gives default, else last opened file (getPreference("HOME") for first)
		/*
		String content = typein.getContent();
		File filein = (content.length()<=1? null: new File(content));
		if (filein==null) jc.setCurrentDirectory(null);
		else if (filein.exists()) jc.setCurrentDirectory(filein.isDirectory()? filein: filein.getParentFile());
		*/

		Browser br = getBrowser();	// Browser is a Component
		Document doc = br.getCurDocument();

		if (jc_==null) jc_ = new JFileChooser();
		jc_.setDialogType(JFileChooser.SAVE_DIALOG);
		jc_.setDialogTitle("Save Document to File");

		File dir = jc_.getCurrentDirectory();
		URI uri = doc.getURI();
		for (Node stop=getRoot(); uri==null && doc.getParentNode()!=stop; ) {    // inline Note => climb up until get base doc
			doc = doc.getParentNode().getDocument();
			uri = doc.getURI();
		}

		String file = computeFilename(uri);

		File newpath = new File(dir, file);
//System.out.println("select "+newpath+", file="+uri.getFile()+" => "+file);
		jc_.setSelectedFile(newpath);

		if (jc_.showSaveDialog(br) == JFileChooser.APPROVE_OPTION) {
			// map to cache
			Cache cache = getGlobal().getCache();
			File from = null;//FIX: cache.mapTo(uri, null, Cache.GENERAL);
//System.out.println("copy "+from+"\n\t=> "+newpath);

			// UNIX copy
			try {
				new FileList(from, null).copy(newpath);
				//Unix.cp(from, newpath, null);
			} catch (IOException ioe) {
				System.err.println("couldn't save: "+ioe);
				// alert box
			}
		}
		return true;
	 }
	 return super.semanticEventAfter(se,msg);
  }

  String computeFilename(URI uri) {
	String file = uri.getPath();
	int inx = file.lastIndexOf('/'); if (inx!=-1) file=file.substring(inx+1);   // chop tail file from path
	if (file.length()==0) {
		file="index.html";    // should set to site name
		String host = uri.getHost();
		if (host!=null) {
			file = host;
			inx = file.lastIndexOf('.'); if (inx!=-1) file=file.substring(0,inx);
			inx = file.lastIndexOf('.'); if (inx!=-1) file=file.substring(inx+1);
			file += ".html";
		}
	}
	//inx = file.lastIndexOf('.'); if (inx!=-1) file=file.substring(0,inx);   // strip suffix
	//file += ".mvd";
	return file;
  }
}
