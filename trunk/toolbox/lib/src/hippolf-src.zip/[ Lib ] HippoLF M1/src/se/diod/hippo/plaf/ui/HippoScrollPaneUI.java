/*
 * 
 * Created on 2004-jul-25
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.ui;

import javax.swing.JComponent;
import javax.swing.JScrollPane;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.metal.MetalScrollPaneUI;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-25
 *
 */
public class HippoScrollPaneUI extends MetalScrollPaneUI {




	/**
	 * 
	 * 
	 */
	public static ComponentUI createUI( JComponent c ) {
		//java.awt.Color col = javax.swing.UIManager.getColor( "ScrollPane.background" );
		java.awt.Color col = new java.awt.Color( 245, 245, 245 );	// TODO FIXED COLOR, BIG NONO!
		((JScrollPane)c).getViewport().setBackground( col );

		return new HippoScrollPaneUI();
	}




	/**
	 * 
	 * 
	 */
	public void installUI( JComponent c ) {
		//java.awt.Color col = javax.swing.UIManager.getColor( "ScrollPane.background" );
		//((JScrollPane)c).getViewport().setBackground( col );
		super.installUI( c );
	}
}
