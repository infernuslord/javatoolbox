/** ===================================================================
 *
 * L2FProd.com Common Components 0.1-dev License.
 *
 * Copyright (c) 2004 L2FProd.com.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by L2FProd.com
 *        (http://www.L2FProd.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "L2FProd.com Common Components", "l2fprod-common" and "L2FProd.com" must not
 *    be used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact info@L2FProd.com.
 *
 * 5. Products derived from this software may not be called "l2fprod-common"
 *    nor may "l2fprod-common" appear in their names without prior written
 *    permission of L2FProd.com.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL L2FPROD.COM OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package com.l2fprod.common.swing;

import com.l2fprod.common.swing.plaf.FontChooserUI;
import com.l2fprod.common.swing.plaf.LookAndFeelAddons;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dialog;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Window;

import javax.swing.JComponent;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * <code>JFontChooser</code> provides a pane of controls designed to allow a
 * user to manipulate and select a font.
 * 
 * @beaninfo
 *  attribute: isContainer false
 *  description: A component that supports selecting a Font.
 */
public class JFontChooser extends JComponent {

  // ensure at least the default ui is registered
  static {
    try {
      Class.forName(LookAndFeelAddons.class.getName());
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    }
  }

  public static final String SELECTED_FONT_CHANGED_KEY = "selectedFont";

  protected Font selectedFont;

  /**
   * Creates a font chooser with an initial default font
   *  
   */
  public JFontChooser() {
    super();
    selectedFont = getFont();
    updateUI();
  }

  /**
   * Notification from the <code>UIManager</code> that the L&F has changed.
   * Replaces the current UI object with the latest version from
   * the <code>UIManager</code>.
   * 
   * @see javax.swing.JComponent#updateUI
   */
  public void updateUI() {
    setUI(((FontChooserUI)UIManager.getUI(this)));
  }

  /**
   * Sets the L&F object that renders this component.
   * 
   * @param ui the <code>FontChooserUI</code> L&F object
   * @see javax.swing.UIDefaults#getUI
   * 
   * @beaninfo
   *  bound: true
   *  hidden: true
   *  description: The UI object that implements the font chooser's LookAndFeel.
   */
  public void setUI(FontChooserUI ui) {
    super.setUI(ui);
  }

  /**
   * Returns the name of the L&F class that renders this component.
   * 
   * @return the string "FontChooserUI"
   * @see javax.swing.JComponent#getUIClassID
   * @see javax.swing.UIDefaults#getUI
   */
  public String getUIClassID() {
    return "FontChooserUI";
  }

  /**
   * Sets the selected font of this JFontChooser. This will fire a <code>PropertyChangeEvent</code>
   * for the property named {@link #SELECTED_FONT_CHANGED_KEY}.
   * 
   * @param f the font to select
   * @see javax.swing.JComponent#addPropertyChangeListener
   * 
   * @beaninfo
   *  bound: true
   *  hidden: false
   *  description: The current font the chooser is to display
   */
  public void setSelectedFont(Font f) {
    Font oldFont = selectedFont;
    selectedFont = f;
    firePropertyChange(SELECTED_FONT_CHANGED_KEY, oldFont, selectedFont);
  }

  /**
   * Gets the current font value from the font chooser.
   * 
   * @return the current font value of the font chooser
   */
  public Font getSelectedFont() {
    return selectedFont;
  }

  /**
   * Shows a modal font-chooser dialog and blocks until the dialog is hidden.
   * If the user presses the "OK" button, then this method hides/disposes the
   * dialog and returns the selected color. If the user presses the "Cancel"
   * button or closes the dialog without pressing "OK", then this method
   * hides/disposes the dialog and returns <code>null</code>.
   * 
   * @param component the parent <code>Component</code> for the dialog
   * @param title the String containing the dialog's title
   * @param initialFont the initial Font set when the font-chooser is shown
   * @return the selected font or <code>null</code> if the user opted out
   * @exception HeadlessException if GraphicsEnvironment.isHeadless() returns
   *              true.
   * @see java.awt.GraphicsEnvironment#isHeadless
   */
  public static Font showDialog(
    Component parent,
    String title,
    Font initialFont) {
    BaseDialog dialog;
    Window window = SwingUtilities.windowForComponent(parent);
    if (window instanceof Frame) {
      dialog = new BaseDialog((Frame)window, title, true);
    } else {
      dialog = new BaseDialog((Dialog)window, title, true);
    }
    dialog.setDialogMode(BaseDialog.OK_CANCEL_DIALOG);
    dialog.getBanner().setVisible(false);

    JFontChooser chooser = new JFontChooser();
    chooser.setSelectedFont(initialFont);

    dialog.getContentPane().setLayout(new BorderLayout());
    dialog.getContentPane().add("Center", chooser);
    dialog.pack();
    dialog.setLocationRelativeTo(parent);

    if (dialog.ask()) {
      return chooser.getSelectedFont();
    } else {
      return null;
    }
  }

}
