package com.shfarr.ui.wizards;

import javax.swing.*;
import java.awt.*;

/**
 * Insert the type's description here.
 * Creation date: (7/13/2001 4:51:57 PM)
 * @author: Administrator
 */
public class _WizardLabel extends JPanel{
    protected String text = "Generic wizard";
    protected ImageIcon icon = null;

    /**
     * WizardLabel constructor comment.
     */
    public _WizardLabel(){
        super();
        this.icon = new ImageIcon(ClassLoader.getSystemResource("cres/genericWizard.png"));
        setFont(UIManager.getFont("OptionPane.font").deriveFont(Font.ITALIC, 30f));

        setForeground(new Color(240, 240, 240));
        setBackground(Color.black);
        setOpaque(true);
    }

    public Dimension getPreferredSize(){
        return new Dimension(Math.max(icon.getIconHeight(), SwingUtilities.computeStringWidth(getFontMetrics(getFont()), text) + 60), 
                             Math.max(icon.getIconHeight(), (int)(1.2 * (double)getFont().getSize())) +3);
    }

    public void paint(Graphics g){
        g.setColor(getBackground());
        Dimension d = getSize();
        g.fillRect(0, 0, d.width, d.height);

        ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.drawImage(icon.getImage(), 0, 0, null);
        g.setFont(getFont());

        g.setColor(Color.black);
        g.drawRect(0, 0, getSize().width - 1, getSize().height - 4);

        g.setColor(Color.darkGray);
        g.drawString(text, 46, icon.getIconHeight() - 17);

        g.setColor(getForeground());
        g.drawString(text, 45, icon.getIconHeight() - 18);
        
        g.setColor(UIManager.getColor("Component.background"));
        g.drawLine(0, getHeight() -3, getWidth() -1, getHeight() -3);
        g.setColor(UIManager.getColor("Component.deepShadow"));
        g.drawLine(0, getHeight() -2, getWidth() -1, getHeight() -2);
        g.setColor(UIManager.getColor("Component.absoluteHighlight"));
        g.drawLine(0, getHeight() -1, getWidth() -1, getHeight() -1);
    }

    /**
     * Sets the text.
     * 
     * @param text
     *            The text to set
     */
    public void setText(String text){
        this.text = text;
    }

    /**
     * Gets the text.
     * 
     * @return Returns a String
     */
    public String getText(){
        return text;
    }
}