/*
 *
 * Hamsam - Instant Messaging API
 *
 * Copyright (C) 2003 Mike Miller <mikemil@users.sourceforge.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 */

package hamsam.protocol.aim.snac;

import java.io.IOException;
import java.io.OutputStream;

import hamsam.protocol.aim.util.*;

/**
 * @author mikem
 */
public class SNACPacket {

    //~ Static fields/initializers -----------------------------------------------------------------

    private static byte DEFAULT_FLAG = 0x00;
    private static final String VERSION = "$Id: SNACPacket.java,v 1.2 2003/08/24 03:59:43 mikemil Exp $";
    public static final int SNACPACKET_LENGTH = 10;

    //~ Instance fields ----------------------------------------------------------------------------

    private short familyId;
    private short subTypeId;
    private byte flag1;
    private byte flag2;
    private int requestId;
    private byte[] snacData;

    //~ Constructors -------------------------------------------------------------------------------

    public SNACPacket(int family, int subtype) {
        this(family, subtype, DEFAULT_FLAG, DEFAULT_FLAG);
    }

    public SNACPacket(int family, int subtype, byte flag1, byte flag2) {
        familyId = (short)family;
        subTypeId = (short)subtype;
        this.flag1 = flag1;
        this.flag2 = flag2;
        requestId = 0;
    }

    public SNACPacket(byte[] data) {
        if (data == null || data.length < SNACPACKET_LENGTH) {
            throw new IllegalArgumentException("SNAC data too short");
        }
        
        familyId = (short)ByteUtils.getUShort(data, 0);
        subTypeId = (short)ByteUtils.getUShort(data, 2);
        flag1 = data[4];
        flag2 = data[5];
        requestId = (int)ByteUtils.getUInt(data, 6);
        
        // create byte[] for the snacData
        if (data.length > SNACPACKET_LENGTH) {
            //handle case when bit 8(or 7 counting from 0) is set
            // we need to strip out the 2 bytes for length 
            // and length bytes for the unknown data 
            if ( (flag1 & 0x80) != 0) {
                int unknownDataLen = ByteUtils.getUShort(data, SNACPACKET_LENGTH);
                int pos = unknownDataLen +2;
                snacData = new byte[ data.length - SNACPACKET_LENGTH - 2 - unknownDataLen ];
                System.arraycopy(data, SNACPACKET_LENGTH+pos, snacData, 0, snacData.length - 2 - unknownDataLen);
            } else {
                snacData = new byte[ data.length - SNACPACKET_LENGTH ];
                System.arraycopy(data, SNACPACKET_LENGTH, snacData, 0, snacData.length);
            }
        
            
        }
    }

    //~ Methods ------------------------------------------------------------------------------------
    
    // not currently used
//    /**
//     * Reads a SNACPacket from the network
//     * @param conn Connection used to read the flap header
//     * @return SNACPacket object
//     * @throws IOException when error encountered reading from the connection
//     * @throws IllegalStateException when invalid data read for the flap header,
//     *         for example, if the premable is not 0x2a.
//     */
//    public static SNACPacket getSNAC(Connection conn) throws IOException, IllegalStateException {
//
//        byte[] data = new byte[10];
//        int pos = 0;
//
//        try {
//
//            while (pos < data.length) {
//
//                final int count = conn.read(data, pos, data.length - pos);
//
//                // check the count to make sure we didn't hit EOF or lose connection
//                if (count == -1) {
//                    return null;
//                }
//
//                pos += count;
//            }
//        } catch (SocketException e) {
//
//            e.printStackTrace();
//            return null;
//        }
//
//        SNACPacket snac = null;
//
//        try {
//            snac = new SNACPacket(data);
//        } catch (IllegalArgumentException e) {
//            e.printStackTrace();
//        }
//
//        return snac;
//    }

    /** Returns the family id of the SNACPacket
     * @return the family id of the SNACPacket
     */
    public short getFamilyId() {
        return familyId;
    }

    /** Returns the first flag value
     * @return the first flag value
     */
    public byte getFlag1() {
        return flag1;
    }

    /** Returns the second flag value
     * @return the second flag value
     */
    public byte getFlag2() {
        return flag2;
    }

    /** Returns the request id of the SNACPacket
     * @return the request id of the SNACPacket
     */
    public int getRequestId() {
        return requestId;
    }

    /**Returns the sub type id of the SNACPacket
     * @return the sub type id of the SNACPacket
     */
    public short getSubTypeId() {
        return subTypeId;
    }

    public int getByteLength() {
        return 0;
    }
    
    public byte[] getSNACData() {
        return snacData;
    }
    
    public void setSNACData(byte[] data) {
        snacData = data;
    }
    

    public byte[] getBytes() {
        byte[] bytes = new byte[SNACPACKET_LENGTH];

        bytes[0] = (byte) ((familyId >> 8) & 0xff);
        bytes[1] = (byte) (familyId & 0xff);
        bytes[2] = (byte) ((subTypeId >> 8) & 0xff);
        bytes[3] = (byte) (subTypeId & 0xff);
        bytes[4] = flag1;
        bytes[5] = flag2;
        bytes[6] = (byte) ((requestId >> 24) & 0xff);
        bytes[7] = (byte) ((requestId >> 16) & 0xff);
        bytes[8] = (byte) ((requestId >> 8) & 0xff);
        bytes[9] = (byte) (requestId & 0xff);

        return bytes;
    }

    /* (non-Javadoc)
     * @see hamsam.protocol.aim.command.Command#writeCommandData(java.io.OutputStream)
     */
    public void write(OutputStream os) throws IOException {
        // write out the SNAC
        os.write(familyId);
        os.write(subTypeId);
        os.write(flag1);
        os.write(flag2);
        os.write(requestId);
    }

    /** Returns a string representation of the SNACPacket
     * @return a string representation of the SNACPacket
     */
    public String toString() {

        StringBuffer sb = new StringBuffer(50);
        sb.append("familyId=").append(Integer.toHexString(familyId)).append("\t");
        sb.append("subTypeId=").append(Integer.toHexString(subTypeId)).append("\t");
        sb.append("flag1=").append(flag1).append("\t");
        sb.append("flag2=").append(flag2).append("\t");
        sb.append("requestId=").append(requestId);
        return sb.toString();
    }
}
