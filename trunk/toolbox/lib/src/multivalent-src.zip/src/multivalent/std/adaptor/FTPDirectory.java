package multivalent.std.adaptor;

import java.io.*;
import java.util.regex.*;
import java.net.URI;

import multivalent.*;



/**
	Media adaptor that displays contents of a FTP directory
	with links to files and other directories.

	@version $Revision: 1.5 $ $Date: 2003/06/02 05:39:17 $
*/
public class FTPDirectory extends MediaAdaptorReader {
  /** Pattern for matching file line. */
  public static Pattern LINE_PATTERN = Pattern.compile("^[dl-].........\\s+\\d+\\s+\\d+\\s+(\\d+)\\s+(.+?)\\s+(\\S+( -> \\S+)?)$");

  static Pattern
	//DATE = Pattern.compile(""),
	//TOTAL = Pattern.compile("total\\s+(\\d+)"),
	README = Pattern.compile("(?i)^readme")
	;

  public Object parse(INode parent) throws Exception {
	//new LeafAscii("FTP directory",null, parent);
	return parseHelper(toHTML(), "HTML", getLayer(), parent);
  }

  public String toHTML() throws IOException {
	StringBuffer sb = new StringBuffer(20*1024);

	sb.append("<html>\n<head>\n");
	sb.append("<title>").append(docURI).append("</title>\n");
	sb.append("<base href='").append(docURI).append("' />\n");
	sb.append("</head>\n<body>\n");
	sb.append("<h3>Index of ").append(docURI).append("</h3>\n");    // redundant with URL type-in
	sb.append("<a href='../'><img src='systemresource:/sys/images/Open24.gif'>Up to a higher level directory</a>\n");

	int listi = sb.length();
	sb.append("<hr />\n");

	// parse URI with links on each
	// ...

	String readme = null;
	sb.append("<table width='80%'>");
	sb.append("<tr><th align='left'>Name<th align='right'>Size<th align='right'>Date\n");    // types are obvious but use for table sorting

	BufferedReader r = new BufferedReader(getReader());

	int cnt = 0;
	Matcher m = LINE_PATTERN.matcher(""), rm = README.matcher("");
	for (String line; (line = r.readLine()) != null; ) {
		if (line.length() <= 2) continue;   // blank
		if (line.startsWith("total")) continue; // ignore

		if (m.reset(line).find()) {
			cnt++;
			char type = line.charAt(0);
			// name
			sb.append("<tr><td>");
			String g3 = m.group(3);
			if (type=='d') {
				sb.append("<a href='").append(g3).append("/' >");
				sb.append("<img src='systemresource:/sys/images/Open24.gif'>");
				sb.append(g3).append("</a>");
				sb.append("<td>");  // suppress size

			} else if (type=='l') {
				int inx = line.lastIndexOf(' ');
				String ref = (inx>=0? line.substring(inx+1): line);
				sb.append("<a href='").append(ref).append("'><i>").append(g3).append("</i></a>");
				sb.append("<td>");  // suppress size

			} else {
				sb.append("<a href='").append(g3).append("'>").append(g3).append("</a>");
				if (readme==null && rm.reset(g3).find()) readme = g3;

				// size
				sb.append("<td align='right'>").append(m.group(1));

			}


			// date
			sb.append("<td align='right'>").append(m.group(2));

		} else assert false: "no match on "+line;

	}
	sb.append("</table>\n");
	sb.append("<hr />\n");

	if (cnt == 0) sb.setLength(listi);
	else if (readme!=null) {
		// automatically read and display "README"
		try {
			URI uri = docURI.resolve(readme);
			Cache cache = Multivalent.getInstance().getCache();
			BufferedReader rr = new BufferedReader(new InputStreamReader(cache.getInputStream(uri)));

			StringBuffer sbr = new StringBuffer(2*1024); sbr.append("\n<pre>\n");
			int linecnt = 1;
			for (String line; (line = rr.readLine()) != null; ) {
				if (linecnt <= 10) sbr.append(line).append("\n");
				else { sbr.append("[<a href='").append(readme).append("'>Read the rest</a>]\n"); break; }
				linecnt++;
			}

			sbr.append("\n</pre>\n");

			rr.close();

			sb.insert(listi, sbr.toString());
		} catch (Exception ignore) {}
	}


	closeReader();

	sb.append("</body>\n</html>");
	return sb.toString();
  }
}
