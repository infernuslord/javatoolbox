package tex.dvi;

import multivalent.*;

import phelps.Utility;



/**
	NOT IMPLEMENTED.
	Media adaptor for showing Encapsulated PostScript (EPS)
	images with bitmap preview as embedded as TeX specials.
	How common are bitmap previews?

	@see tex.dvi.DVI

	@version $Revision: 1.2 $ $Date: 2003/06/01 07:44:36 $
*/
public class SpecialEPS extends Behavior {
  /** Get event from DVI parser. */
  public boolean semanticEventBefore(SemanticEvent se, String msg) {
	if (super.semanticEventBefore(se,msg)) return true;
	if (DVI.MSG_SPECIAL!=msg || se.getOut()==null/*scanning*/) return false;
	Object arg = se.getArg();
	if (arg==null || !(arg instanceof String)) return false;
	String sarg = (String)arg;
	if (!sarg.startsWith("psfile=") || sarg.length()<7+1) return false;  // "html" + ":" + at least one character
	Node lastn = (Node)se.getIn(); //Point pt = (Point)se.getOut();

	String special = sarg.substring(7), scmp = special.toLowerCase();
//System.out.println("HyperTeX special: "+special);
	Browser br = getBrowser();

	return false;
  }
}
