/**
 * $ $ License.
 *
 * Copyright $ L2FProd.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.l2fprod.common.demo;

import com.l2fprod.common.beans.BaseBeanInfo;
import com.l2fprod.common.model.DefaultBeanInfoResolver;
import com.l2fprod.common.propertysheet.PropertySheet;
import com.l2fprod.common.propertysheet.PropertySheetPanel;
import com.l2fprod.common.swing.LookAndFeelTweaks;

import java.awt.Color;
import java.beans.BeanInfo;
import java.io.File;
import java.util.ListResourceBundle;

import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 * PropertySheetPage. <br>
 *  
 */
public class PropertySheetPage extends JPanel {

  public PropertySheetPage() {
    setLayout(LookAndFeelTweaks.createVerticalPercentLayout());

    JTextArea message = new JTextArea();
    message.setText(PropertySheetMain.RESOURCE.getString("Main.sheet1.message"));
    LookAndFeelTweaks.makeMultilineLabel(message);
    add(message);

    Bean data = new Bean();
    data.setName("John Smith");
    data.setText("Any text here");
    data.setColor(Color.green);
    data.setPath(new File("."));
    data.setVisible(true);
    data.setTime(System.currentTimeMillis());

    DefaultBeanInfoResolver resolver = new DefaultBeanInfoResolver();
    BeanInfo beanInfo = resolver.getBeanInfo(data);

    PropertySheetPanel sheet = new PropertySheetPanel();
    sheet.setMode(PropertySheet.VIEW_AS_CATEGORIES);
    sheet.setProperties(beanInfo.getPropertyDescriptors());
    sheet.readFromObject(data);
    add(sheet, "*");
  }

  public static class Bean {

    private String name;

    public String getName() {
      return name;
    }

    public void setName(String name) {
      this.name = name;
    }

    private String text;

    public String getText() {
      return text;
    }

    public void setText(String text) {
      this.text = text;
    }

    private long time;

    public long getTime() {
      return time;
    }

    public void setTime(long time) {
      this.time = time;
    }

    public String getVersion() {
      return "1.0";
    }

    private boolean visible;

    public boolean isVisible() {
      return visible;
    }

    public void setVisible(boolean visible) {
      this.visible = visible;
    }

    private int id;

    public int getId() {
      return id;
    }

    public void setId(int id) {
      this.id = id;
    }

    private File path;

    public File getPath() {
      return path;
    }

    public void setPath(File path) {
      this.path = path;
    }

    private Color color = Color.blue;

    public Color getColor() {
      return color;
    }

    public void setColor(Color color) {
      this.color = color;
    }

    private double doubleValue = 121210.4343543;

    public void setADouble(double d) {
      this.doubleValue = d;
    }

    public double getADouble() {
      return doubleValue;
    }

    public String toString() {
      return "[name=" + getName() + ",text=" + getText() + ",time=" + getTime()
          + ",version=" + getVersion() + ",visible=" + isVisible() + ",id="
          + getId() + ",path=" + getPath() + ",aDouble=" + getADouble() + "]";
    }
  }

  public static class BeanBeanInfo extends BaseBeanInfo {

    public BeanBeanInfo() {
      super(Bean.class);
      addProperty("id").setCategory("General");
      addProperty("name").setCategory("General");
      addProperty("text").setCategory("General");
      addProperty("visible").setCategory("General");
      
      // the File attribute will not be shown if running in Java Web
      // Start, otherwise it will lead to exception when rendering the
      // value
      if (System.getProperty("javawebstart.version") == null) {
        addProperty("path").setCategory("Details");
      }
      
      addProperty("time").setCategory("Details");
      addProperty("color").setCategory("Details");
      addProperty("aDouble").setCategory("Numbers");
      // a readonly property
      addProperty("version");
    }
  }

  public static class BeanRB extends ListResourceBundle {

    protected Object[][] getContents() {
      return new Object[][] { {"name", "Name"},
          {"name.shortDescription", "The name of this object"},
          {"text", "Text"}, {"time", "Time"}, {"color", "Background"},
          {"aDouble", "a double"}};
    }
  }

}
