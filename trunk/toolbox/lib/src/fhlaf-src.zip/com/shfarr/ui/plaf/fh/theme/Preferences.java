/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh.theme;

import java.awt.Color;
import java.io.Serializable;


public class Preferences implements Serializable{
    private Color customBaseColor = null;
    private String themeDirectory = "";
    private String currentTheme = null;
    private boolean manageButtonIcons = true;
    private boolean bordersDoubled = false;
    private boolean smallTexturesPainted = true;
    private boolean largeTexturesPainted = true;
    private boolean antialiasingTexts = true;
    private boolean strengthenFonts = false;
    private int fontSizeAdjustment = 100;
    private int contrast = 0;
    private int brightness = 0;
    private int saturation = 50; 
    private boolean licenseViewed = false;
    private boolean usingCustomBaseColor = false;

    /**
     * @return
     */
    public boolean isBordersDoubled() {
        return bordersDoubled;
    }

    /**
     * @param bordersDoubled
     */
    public void setBordersDoubled(boolean bordersDoubled) {
        this.bordersDoubled = bordersDoubled;
    }

    /**
     * @return
     */
    public int getBrightness() {
        return brightness;
    }

    /**
     * @param brightness
     */
    public void setBrightness(int brightness) {
        this.brightness = brightness;
    }

    /**
     * @return
     */
    public int getContrast() {
        return contrast;
    }

    /**
     * @param contrast
     */
    public void setContrast(int contrast) {
        this.contrast = contrast;
    }

    /**
     * @return
     */
    public int getFontSizeAdjustment() {
        return fontSizeAdjustment;
    }

    /**
     * @param fontSizeAdjustment
     */
    public void setFontSizeAdjustment(int fontSizeAdjustment) {
        this.fontSizeAdjustment = fontSizeAdjustment;
    }

    /**
     * @return
     */
    public boolean isManageButtonIcons() {
        return manageButtonIcons;
    }

    /**
     * @param manageButtonIcons
     */
    public void setManageButtonIcons(boolean manageButtonIcons) {
        this.manageButtonIcons = manageButtonIcons;
    }

    /**
     * @return
     */
    public int getSaturation() {
        return saturation;
    }

    /**
     * @param saturation
     */
    public void setSaturation(int saturation) {
        this.saturation = saturation;
    }

    /**
     * @return
     */
    public boolean isAntialiasingTexts() {
        return antialiasingTexts;
    }

    /**
     * @param antialiasingTexts
     */
    public void setAntialiasingTexts(boolean antialiasingTexts) {
        this.antialiasingTexts = antialiasingTexts;
    }

    /**
     * @return
     */
    public boolean isLargeTexturesPainted() {
        return largeTexturesPainted;
    }

    /**
     * @param largeTexturesPainted
     */
    public void setLargeTexturesPainted(boolean largeTexturesPainted) {
        this.largeTexturesPainted = largeTexturesPainted;
    }

    /**
     * @return
     */
    public boolean isSmallTexturesPainted() {
        return smallTexturesPainted;
    }

    /**
     * @param smallTexturesPainted
     */
    public void setSmallTexturesPainted(boolean smallTexturesPainted){
        this.smallTexturesPainted = smallTexturesPainted;
    }

    /**
     * @return
     */
    public String getCurrentTheme() {
        return currentTheme;
    }

    /**
     * @param currentTheme
     */
    public void setCurrentTheme(String currentTheme) {
        this.currentTheme = currentTheme;
    }

    public String getThemeDirectory() {
        return themeDirectory;
    }

    /**
     * @param themeDirectory
     */
    public void setThemeDirectory(String themeDirectory) {
        this.themeDirectory = themeDirectory;
    }

    /**
     * @return
     */
    public boolean isStrengthenFonts() {
        return strengthenFonts;
    }

    /**
     * @param strengthenFonts
     */
    public void setStrengthenFonts(boolean strengthenFonts) {
        this.strengthenFonts = strengthenFonts;
    }

    /**
     * @return
     */
    public boolean isLicenseViewed() {
        return licenseViewed;
    }

    /**
     * @param licenseViewed
     */
    public void setLicenseViewed(boolean licenseViewed) {
        this.licenseViewed = licenseViewed;
    }

    /**
     * @return
     */
    public Color getCustomBaseColor() {
        return customBaseColor;
    }

    /**
     * @param customBaseColor
     */
    public void setCustomBaseColor(Color customBaseColor) {
        this.customBaseColor = customBaseColor;
    }

    /**
     * @return
     */
    public boolean isUsingCustomBaseColor() {
        return usingCustomBaseColor;
    }

    /**
     * @param usingCustomBaseColor
     */
    public void setUsingCustomBaseColor(boolean usingCustomBaseColor) {
        this.usingCustomBaseColor = usingCustomBaseColor;
    }

}
