package tool.pdf;

import java.io.IOException;
import java.io.File;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.io.PrintStream;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.awt.FontFormatException;
import java.awt.Rectangle;
import java.awt.geom.Rectangle2D;

import multivalent.ParseException;
import multivalent.std.adaptor.pdf.*;
import static multivalent.std.adaptor.pdf.COS.*;

import phelps.io.FileList;
import phelps.io.Files;
import phelps.util.Units;
import phelps.awt.font.NFontType1;



/**
	Extract embedded files and stream objects into separate files.

	Copyright (c) 2003  Thomas A. Phelps
	@version $Revision: 1.3 $ $Date: 2003/12/10 00:46:47 $
*/
public class Extract {
  static final boolean DEBUG = true;

  static final byte[] EMPTY = new byte[0];

  public static final String VERSION = "1.0 of $Date: 2003/12/10 00:46:47 $";
  public static final String USAGE = "java tool.pdf.Extract [options] <PDF-file...>\n"
	+ "\t[-obj <range>] [-embed] [-font] [-image] [-stream]\n"
	+ "\t[-page <range>] [-min <size>]\n"
	+ "\t[-edit] [-share]\n"
	+ "\t[-cache <directory>]";

  //private boolean fembed_;
  private boolean fembed_, ffont_, fimage_, fstream_;
  private boolean fedit_, fshare_;
  private String range_, objrange_;
  private File cachepath_;
  private int min_;
  private String password_;
  private boolean fverbose_, fquiet_, fmonitor_;
  private PrintStream out_;

  private Map<Long,File> cache_ = new HashMap<Long,File>(100);


  public Extract() {
	defaults();
  }

  public void defaults() {
	fembed_ = ffont_ = fimage_ = fstream_ = false;
	fedit_ = fshare_ = false;
	range_ = objrange_ = null;
	cachepath_ = new File(".");
	min_ = 1;
	password_ = null;

	fverbose_ = fquiet_ = fmonitor_ = false;
	out_ = phelps.io.PrintStreams.DEVNULL;
  }

  //public void setObj(String range) => n/a, just read from PDFReader
  public void setEmbed(boolean b) { fembed_ = b; }
  public void setFont(boolean b) { ffont_ = b; }
  public void setImage(boolean b) { fimage_ = b; }
  public void setStream(boolean b) { fstream_ = b; }
  public void setRange(String range) { range_ = range; }
  public void setMin(int min) { min_ = min; }
  public void setEdit(boolean b) { fedit_ = b; }
  public void setShare(boolean b) { fshare_ = b; }
  public void setCache(File path) { cachepath_ = path; }



  public void extract(File file) throws IOException, ParseException {
	String path = file.getPath();
	String pathout = (path.toLowerCase().endsWith(".pdf")? path.substring(0, path.length()-4): path) + "-unem.pdf";
	extract(file, fedit_ || fshare_? new File(pathout): null);
  }

  public void extract(File filein, File fileout) throws IOException, ParseException {
	if (fverbose_) System.out.println(filein);
	assert filein!=null && filein.exists();

	PDFReader pdfr = new PDFReader(filein);
	PDFWriter pdfw = fedit_ || fshare_? new PDFWriter(fileout, pdfr): null;

	extract(pdfr, pdfw);

	//pdfw.setMonitor(true);
	if (pdfw!=null) { pdfw.writePDF(); pdfw.close(); }
	pdfr.close();
  }

  public void extract(PDFReader pdfr, PDFWriter pdfw) throws IOException, ParseException {
	pdfr.setPassword(password_); pdfr.setExact(true);
	if (pdfw!=null) pdfw.setPassword(password_);
//if (DEBUG) pdfw.setCompress(false);

	if (objrange_!=null) {
		int[] objrange = Units.parseRange(objrange_, 1,pdfr.getObjCnt());
		for (int num: objrange) {
			Object o = pdfr.getObject(num);
			if (objrange.length > 1) System.out.print(num+" = ");
			System.out.println(o);
			if (CLASS_DICTIONARY==o.getClass() && ((Dict)o).get(STREAM_DATA)!=null) {
//System.out.println("dump "+num+", "+((Dict)o).get(STREAM_DATA)+", class="+((Dict)o).get(STREAM_DATA).getClass());
				InputStream is = pdfr.getInputStream(new IRef(num,pdfr.getObjGen(num)), false);
				for (int c; (c = is.read())!=-1; ) System.out.write((char)c);	// not System.out.print !
				is.close();
				System.out.println();
			}
		} //else System.out.println(o);
	}


	if (range_!=null || objrange_==null) {
		loadCache();

		File f = pdfr.getFile(); String pfx = f!=null? f.getName(): "obj";
		int[] range = Units.parseRange(range_, 1,pdfr.getPageCnt());
		for (int i=0,imax=range.length; i<imax; i++) {
			int pg = range[i];
			Dict page = pdfr.getPage(pg);
			Dict res = (Dict)pdfr.getObject(page.get("Resources"));
			if (res!=null) for (Iterator<Object> ri=res.values().iterator(); ri.hasNext(); ) {	// res dicts
				Object o = pdfr.getObject(ri.next());
				if (CLASS_DICTIONARY == o.getClass()) for (Iterator<Object> subri=((Dict)o).values().iterator(); subri.hasNext(); ) {
					o = subri.next();
					if (CLASS_IREF == o.getClass()) extractObject(pfx, i, pdfr);
				}
			}
		}
	}
	// Catalog's EmbeddedFiles
	// ...
	
	//if (fembed_ && removed them all) pdfr.getCatalog().remove("EmbeddedFiles");
  }


  private File extractObject(String pfx, int i, PDFReader pdfr) throws IOException {
	Object o = pdfr.getObject(i);
	if (CLASS_DICTIONARY != o.getClass()) return null;
	Dict dict = (Dict)o;
	IRef iref = new IRef(i, pdfr.getObjGen(i));
	//o = pdfr.getObject(dict.get("Length")); if (o==null) return null;	// not stream or already extractded
	//if (((Number)o).intValue() < min_) return null;


	Object type = pdfr.getObject(dict.get("Type")), subtype = pdfr.getObject(dict.get("Subtype"));
	byte[] data = null;
	Dict stream = dict;
	String name = pfx + "#" + i, sfx = null;

	if ("Page".equals(type)) {
		// inherit attrs and rewrite MediaBox and CropBox to Rectangles
		//oa2Rect(page, "MediaBox", pdfr); oa2Rect(page, "CropBox", pdfr);
	}

	if (fembed_ && "Filespec".equals(type)) {
		// "EF", "RF"
	}

	if ("Font".equals(type) && (ffont_ || fstream_)) {
		name = (String)pdfr.getObject(dict.get("BaseFont"));
		Dict fdesc = (Dict)pdfr.getObject(dict.get("FontDescriptor"));
//System.out.println("unem "+name+": "+fdesc);
		if (fdesc==null) {	// not embedded
		} else if (name.indexOf('+')!=-1 /*or Multiple Master*/) {	// not complete: subsetted or instance
		} else if ((o=fdesc.get("FontFile"))!=null) {	// Type 1
			stream = (Dict)pdfr.getObject(o);
			if (stream.get("Length")!=null) try {
				data = NFontType1.toPFB(NFontType1.normalize(pdfr.getStreamData(o, false, false)/*, -1,-1*/));	// external form of fonts
				//data = pdfr.getStreamData(o, false, false);	// PDF external file
			} catch (FontFormatException dontextract) {}
			sfx = "pfb";

		} else if ((o=fdesc.get("FontFile2"))!=null) {	// TrueType
			stream = (Dict)pdfr.getObject(o);
			if (stream.get("Length")!=null) data = pdfr.getStreamData(o, false, false);
			sfx = "ttf"; // or ".cff" or ".pfb"

		} else if ((o=fdesc.get("FontFile3"))!=null) {	// CFF or Type 0
			stream = (Dict)pdfr.getObject(o);
			if (stream.get("Length")!=null) data = pdfr.getStreamData(o, false, false);
			sfx = "cff";
		}
		if (data!=null) { fdesc.remove("Filter"); fdesc.remove("DecodeParms"); }
	}

	if ("Image".equals(subtype) && (type==null || "XObject".equals(type)) && (fimage_ || fstream_) && stream.get("Length")!=null) {
		data = pdfr.getStreamData(iref, false, false);
		o = Images.getFilter(dict, pdfr); dict.remove("Filter"); if (o!=null) dict.put("FFilter",o);
		o = Images.getDecodeParms(dict, pdfr); dict.remove("DecodeParms"); if (o!=null) dict.put("FDecodeParms",o);
		sfx = ".jpg";
	}

	if (fstream_ && data==null/*not font or image*/ && stream.get("Length")!=null) {
		//data = pdfr.getStreamData(iref, false, false);
		dict.remove("Filter"); dict.remove("DecodeParms");
		sfx = ".raw";
	}

	if (data==null || data.length < min_) return null;


	File out = getCache(data);
	if (fverbose_) System.out.print("  extract object #"+i);
	if (out==null) {	// write out object to file
		out = new File(/*cachedir_,*/ name +"."+sfx);
		if (fverbose_) System.out.println(" to "+out);
		try { RandomAccessFile raf = new RandomAccessFile(out, "rw"); raf.write(data); raf.close(); } catch (IOException ioe) { System.err.println(ioe); }
		addCache(out, data);	// even if error don't try again
	} else {
		if (fverbose_) System.out.println(" -- same as "+out);
	}
	// zap from stream
	stream.put("F", new StringBuffer(out.toString()));
	stream.put(STREAM_DATA, EMPTY);
	stream.remove("Length");

	// zap from Catalog's EmbeddedFiles
	// ...

	return out;
  }

  private static void oa2Rect(Dict page, String attr, PDFReader pdfr) throws IOException {
	Object[] oa = (Object[])pdfr.getObject(page.get(attr));
	if (oa==null || oa.length!=4) return;
	int[] w = new int[4]; double[] d = new double[4];
	boolean fdub = false;
	for (int i=0; i<4; i++) {
		Object o = oa[i];
		if (CLASS_REAL==o.getClass()) fdub = true;
		w[i] = ((Number)o).intValue();
		d[i] = ((Number)o).doubleValue();
	}
	Rectangle2D r = fdub? (Rectangle2D)new Rectangle2D.Double(d[0],d[1],d[2],d[3]): new Rectangle(w[0],w[1],w[2],w[3]);
	page.put(attr, r);
  }


  private void loadCache() {
	if (cache_!=null) return;

	// recurse to pick up TEXMF
	for (Iterator<File> i = new FileList(cachepath_, null).iterator(); i.hasNext(); ) {
		File f = i.next();
		if (f.isFile()) try { addCache(f, Files.toByteArray(f)); } catch (IOException ignore) {}
	}
	// LATER: if slow, cache hash codes in file...
  }

  private void addCache(File file, byte[] data) {
	// normalize:
	// if .pfa/.pfb, unwrap and XXXX random bytes
	// ...
  }

  /** If <var>data</var> in cache (available as {@link java.io.File}), returns File; else returns <code>null</code>. */
  private File getCache(byte[] data) {
	// compute hash, examine cache_
	return null;
  }



  private int commandLine(String[] argv) throws UnsupportedOperationException, NumberFormatException {
	out_ = System.out;

	int argi = 0, argc = argv.length;
	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.startsWith("-obj")) objrange_ = argv[++argi];
		else if (arg.startsWith("-embed")) setEmbed(true);
		else if (arg.startsWith("-font")) setFont(true);
		else if (arg.startsWith("-image")) setImage(true);
		else if (arg.startsWith("-stream")) setStream(true);

		else if (arg.startsWith("-page") || arg.startsWith("-range")) setRange(argv[++argi]);
		else if (arg.startsWith("-min")) setMin(Integer.parseInt(argv[++argi]));

		else if (arg.startsWith("-edit")) {}
		else if (arg.startsWith("-share")) {}

		else if (arg.startsWith("-cache")) setCache(new File(argv[++argi]));

		else if (arg.startsWith("-pass"/*"word"*/)) password_ = argv[++argi];

		else if (arg.startsWith("-verb")) fverbose_ = true;
		//else if (arg.startsWith("-q"/*uiet*/)) fquiet = true;
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.startsWith("-h"/*"elp"*/)) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	if (!fembed_ && !ffont_ && !fimage_ && !fstream_) fembed_ = true;	// if no type, default to fembed_
	if (argi == argc) { System.err.println(USAGE); System.exit(0); }

	return argi;
  }

  public static void main(String[] argv) {
	Extract ex = new Extract();
	int argi = 0;
	try { argi = ex.commandLine(argv); } catch (Exception e) { System.err.println(e.getMessage()); System.exit(1); }

	for (Iterator<File> i = new FileList(argv, argi, FILTER).iterator(); i.hasNext(); ) {
		File file = i.next();
		try {
			//if (fquiet_) System.out.println(file);
			ex.extract(file);
		} catch (Exception e) {
			System.err.println(file+": "+e);
			if (DEBUG) e.printStackTrace();
		}
	}
	System.exit(0);
  }
}
