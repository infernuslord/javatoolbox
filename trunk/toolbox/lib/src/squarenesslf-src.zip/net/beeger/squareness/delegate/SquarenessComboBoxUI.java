/*
  Copyright (C) 2003-2004 Robert F. Beeger (robert at beeger dot net)
  Licensed under the Academic Free License version 2.0
  OSI Certified Open Source Software

  Visit http://squareness.sourceforge.net/ for new releases of Squareness Look And Feel and other
  skins from the Squareness series.
*/
package net.beeger.squareness.delegate;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.UIDefaults;
import javax.swing.UIManager;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicComboBoxUI;

import net.beeger.squareness.SquarenessConstants;
import net.beeger.squareness.util.SquarenessBorderFactory;

/**
 * The Squareness Combo Box UI delegate.
 */
public class SquarenessComboBoxUI extends BasicComboBoxUI
{
  /**
   * Create the UI delegate for the given component
   * 
   * @param component The component for which to create the ui delegate
   * @return The created ui delegate
   */
  public static ComponentUI createUI (JComponent component)
  {
    return new SquarenessComboBoxUI();
  }

  /**
   * Create the arrow button for the combo box.
   *
   * @return The created arrow button.
   */
  protected JButton createArrowButton ()
  {
    UIDefaults defaults = UIManager.getDefaults();
    JButton button = new JButton(defaults.getIcon(SquarenessConstants.SCROLL_ARROW_DOWN_KEY));
    button.setBorder(SquarenessBorderFactory.getNonSpacingControlBorderWithMargin());
    return button;
  }
}

/*
  $Log: SquarenessComboBoxUI.java,v $
  Revision 1.4  2004/03/08 15:12:26  rbeeger
  Added and enhanced comments.
  Simplified code.

  Revision 1.3  2004/03/03 20:02:38  rbeeger
  The combobox button now doesn't have a own parent color border. The margin of the combobox itself produces a 1 pixel border that will also suffice for the button.

  Revision 1.2  2004/02/14 19:12:34  rbeeger
  Updated copyright statement
  Added cvs log directive at the end of each file
  Optimized imports
  Reformated code

 */
