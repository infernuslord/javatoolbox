/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

import javax.swing.border.Border;
import javax.swing.plaf.*;
import javax.swing.plaf.basic.BasicScrollBarUI;

import com.shfarr.ui.*;
import com.shfarr.ui.plaf.fh.borders.FHMultiMatrixBorder;
import com.shfarr.ui.plaf.fh.ext.*;
import com.shfarr.ui.plaf.fh.textures.*;
import com.shfarr.ui.plaf.fh.theme.*;


public class FhScrollBarUI extends BasicScrollBarUI implements ResourceCandidate{
	protected int scrollBarWidth = 14;
	protected double mx = Double.POSITIVE_INFINITY;
    protected double my = Double.POSITIVE_INFINITY;

	public FhScrollBarUI(){
	  super();
	}

    protected void installDefaults(){
        super.installDefaults();
        
        scrollbar.addMouseListener(new MouseAdapter(){
                                            public void mouseEntered(MouseEvent me){
                                                if(scrollbar != null) scrollbar.repaint();
                                            }
                                            
                                            public void mouseExited(MouseEvent me){
                                                mx = Double.POSITIVE_INFINITY;
                                                my = Double.POSITIVE_INFINITY;

                                                if(scrollbar != null) scrollbar.repaint();
                                            }
                                         });
        
        scrollbar.addMouseMotionListener(new MouseMotionAdapter(){
                                            public void mouseMoved(MouseEvent me){
                                                mx = me.getX();
                                                my = me.getY();
                                                
                                                if(scrollbar != null) scrollbar.repaint();
                                                //TODO Oct 26, 2003: too many repaints
                                            }
                                         });
        
    }
	

	public ResourceApplicationForm getApplicationForm(){
	    return new ResourceApplicationForm(new Object[]{"highlight", Color.class,
	                                                    "thumbTexture", Texture.class
	                                                    });
	}
	
	
	protected javax.swing.JButton createDecreaseButton(int orientation)  {
	  FhSysButton sb = new FhSysButton(scrollbar.getOrientation()==JScrollBar.HORIZONTAL ? FhSysButton.ARROW_WEST : FhSysButton.ARROW_NORTH, 1);
	  sb.setForeground((Color)UIManager.getDefaults().get("ScrollBar.highlight"));
	  
	  return sb;
	}
	

	protected javax.swing.JButton createIncreaseButton(int orientation){
	  FhSysButton sb = new FhSysButton(scrollbar.getOrientation()==JScrollBar.HORIZONTAL ? FhSysButton.ARROW_EAST : FhSysButton.ARROW_SOUTH, 1);
	  sb.setForeground((Color)UIManager.getDefaults().get("ScrollBar.highlight"));
	  
	  return sb;
	}
	
	
	public static ComponentUI createUI(JComponent c){
	  return new FhScrollBarUI();
	}
	
	
	public Dimension getPreferredSize(JComponent c) {
	  return (scrollbar.getOrientation() == JScrollBar.VERTICAL) ? new Dimension(scrollBarWidth, 48) : new Dimension(48, scrollBarWidth);
	}
	
	
    protected void layoutHScrollbar(JScrollBar sb) {
        Dimension sbSize = sb.getSize();
        Insets sbInsets = sb.getInsets();

        int itemH = scrollBarWidth;
        int itemY = sbInsets.top;

        int decrButtonW = scrollBarWidth;
        int decrButtonX = sbInsets.left;

        int incrButtonW = scrollBarWidth;
        int incrButtonX = sbSize.width - (sbInsets.right + incrButtonW);

        int sbInsetsW = sbInsets.left + sbInsets.right;
        int sbButtonsW = decrButtonW + incrButtonW;
        float trackW = sbSize.width - (sbInsetsW + sbButtonsW);

        float min = sb.getMinimum();
        float extent = sb.getVisibleAmount();
        float range = sb.getMaximum() - min;
        float value = sb.getValue();

        int thumbW = (range <= 0) ? getMaximumThumbSize().width : (int) (trackW * (extent / range));
        thumbW = Math.max(thumbW, getMinimumThumbSize().width);
        thumbW = Math.min(thumbW, getMaximumThumbSize().width);

        int thumbX = incrButtonX - thumbW;
        if(sb.getValue() < (sb.getMaximum() - sb.getVisibleAmount())){
           float thumbRange = trackW - thumbW;
           thumbX = (int) (0.5f + (thumbRange * ((value - min) / (range - extent))));
           thumbX += decrButtonX + decrButtonW;
        }

        int sbAvailButtonW = (sbSize.width - sbInsetsW);
        if(sbAvailButtonW < sbButtonsW){
           incrButtonW = decrButtonW = sbAvailButtonW / 2;
           incrButtonX = sbSize.width - (sbInsets.right + incrButtonW);
        }

        decrButton.setBounds(decrButtonX, itemY, decrButtonW, itemH);
        incrButton.setBounds(incrButtonX, itemY, incrButtonW, itemH);

        int itrackX = decrButtonX + decrButtonW;
        int itrackW = incrButtonX - itrackX;
        trackRect.setBounds(itrackX, itemY, itrackW, itemH);

        if(thumbW >= (int) trackW)setThumbBounds(0, 0, 0, 0);
        else{
             if(thumbX + thumbW > incrButtonX) thumbX = incrButtonX - thumbW;
             if(thumbX < decrButtonX + decrButtonW) thumbX = decrButtonX + decrButtonW + 1;
            
             setThumbBounds(thumbX, itemY, thumbW, itemH);
        }
    }


    protected void layoutVScrollbar(JScrollBar sb) {
        Dimension sbSize = sb.getSize();
        Insets sbInsets = sb.getInsets();

        int itemW = scrollBarWidth;
        int itemX = sbInsets.left;

        int decrButtonH = scrollBarWidth;
        int decrButtonY = sbInsets.top;

        int incrButtonH = scrollBarWidth;
        int incrButtonY = sbSize.height - (sbInsets.bottom + incrButtonH);

        int sbInsetsH = sbInsets.top + sbInsets.bottom;
        int sbButtonsH = decrButtonH + incrButtonH;
        float trackH = sbSize.height - (sbInsetsH + sbButtonsH);

        float min = sb.getMinimum();
        float extent = sb.getVisibleAmount();
        float range = sb.getMaximum() - min;
        float value = sb.getValue();

        int thumbH = (range <= 0) ? getMaximumThumbSize().height : (int) (trackH * (extent / range));
        thumbH = Math.max(thumbH, getMinimumThumbSize().height);
        thumbH = Math.min(thumbH, getMaximumThumbSize().height);

        int thumbY = incrButtonY - thumbH;
        if (sb.getValue() < (sb.getMaximum() - sb.getVisibleAmount())) {
            float thumbRange = trackH - thumbH;
            thumbY = (int) (0.5f + (thumbRange * ((value - min) / (range - extent))));
            thumbY += decrButtonY + decrButtonH;
        }

        int sbAvailButtonH = (sbSize.height - sbInsetsH);
        if (sbAvailButtonH < sbButtonsH) {
            incrButtonH = decrButtonH = sbAvailButtonH / 2;
            incrButtonY = sbSize.height - (sbInsets.bottom + incrButtonH);
        }
        decrButton.setBounds(itemX, decrButtonY, itemW, decrButtonH);
        incrButton.setBounds(itemX, incrButtonY, itemW, incrButtonH);

        int itrackY = decrButtonY + decrButtonH;
        int itrackH = incrButtonY - itrackY;
        trackRect.setBounds(itemX, itrackY, itemW, itrackH);

        if(thumbH >= (int) trackH) setThumbBounds(0, 0, 0, 0);
        else{
             if((thumbY + thumbH) > incrButtonY) thumbY = incrButtonY - thumbH;
             if(thumbY < (decrButtonY + decrButtonH)) thumbY = decrButtonY + decrButtonH + 1;
            
             setThumbBounds(itemX, thumbY, itemW, thumbH);
        }
    }


	protected void paintDecreaseHighlight(java.awt.Graphics g){
	  java.awt.Insets insets = scrollbar.getInsets();
	  java.awt.Rectangle thumbR = getThumbBounds();
	  g.setColor(UIManager.getColor("Component.lightShadow"));
	
	  if(scrollbar.getOrientation() == javax.swing.JScrollBar.VERTICAL) {
		 int x = insets.left;
		 int y = decrButton.getY() + decrButton.getHeight();
		 int w = scrollbar.getWidth() - (insets.left + insets.right);
		 int h = thumbR.y - y;
		 
		 g.fillRect(x, y, w, h);
	  } 
	  else{
		   int x = decrButton.getX() + decrButton.getHeight();
		   int y = insets.top;
		   int w = thumbR.x - x;
		   int h = scrollbar.getHeight() - (insets.top + insets.bottom);
		   
		   g.fillRect(x, y, w, h);
	  }
	}


	protected void paintIncreaseHighlight(java.awt.Graphics g){
	  java.awt.Insets insets = scrollbar.getInsets();
	  java.awt.Rectangle thumbR = getThumbBounds();
	  g.setColor(UIManager.getColor("Component.lightShadow"));
	
	  if(scrollbar.getOrientation() == javax.swing.JScrollBar.VERTICAL) {
		 int x = insets.left;
		 int y = thumbR.y + thumbR.height;
		 int w = scrollbar.getWidth() - (insets.left + insets.right);
		 int h = incrButton.getY() - y;
		 
		 g.fillRect(x, y, w, h);
	  } 
	  else{
		   int x = thumbR.x + thumbR.width;
		   int y = insets.top;
		   int w = incrButton.getX() - x;
		   int h = scrollbar.getHeight() - (insets.top + insets.bottom);
		   
		   g.fillRect(x, y, w, h);
	  }
	}


	protected void paintThumb(java.awt.Graphics g, javax.swing.JComponent c, java.awt.Rectangle thumbBounds){
	  if(thumbBounds.isEmpty() || !scrollbar.isEnabled()) return;
	
	  int w = thumbBounds.width;
	  int h = thumbBounds.height;
	
	  g.translate(thumbBounds.x, thumbBounds.y);
	
	  g.setColor(UIManager.getColor("Component.background"));
	  g.fillRect(0, 0, w, h);

      Border thumbBorder = UIManager.getDefaults().getBorder("ScrollBar.thumbBorder"); 
	  
      if(thumbBorder instanceof FHMultiMatrixBorder){
          if(thumbBounds.contains(mx, my) || isDragging) ((FHMultiMatrixBorder) thumbBorder).selectMatrix("thumb.selected");
          else ((FHMultiMatrixBorder)thumbBorder).selectMatrix("thumb");
      }
      
      thumbBorder.paintBorder(c, g, 0, 0, w, h);
	  Texture thumbTexture = (Texture)UIManager.getDefaults().get("ScrollBar.thumbTexture");
	  
	  if(thumbTexture != null && ThemeManager.instance().probeSmallTextures()){
	     if(scrollbar.getOrientation()==JScrollBar.VERTICAL) thumbTexture.rotate(-Texture.ROTATE_90);
	     thumbTexture.apply(new Rectangle(2, 2, w -4, h -4), (Graphics2D)g, c);
	  }
	
	  g.setColor(UIManager.getColor("Component.background"));
	  if(scrollbar.getOrientation()==JScrollBar.HORIZONTAL){
		 g.fillRect(Math.max(3, w/2 -9), 3, Math.min(20, w -6), h -6);
		 for(int i=Math.max(3, w/2 -7); i < Math.min(w/2 +7, w -4); i+=3) FhDefaults.paintTouch(c, g, i, 3, 3, h -6);
	  }
	  else{
		   g.fillRect(3, Math.max(3, h/2 -9), w -6, Math.min(20, h -6));
		   for(int i=Math.max(3, h/2 -7); i < Math.min(h/2 +7, h -4); i+=3) FhDefaults.paintTouch(c, g, 3, i, w -6, 3);
	  }
	  
	  if(thumbTexture != null && ThemeManager.instance().probeSmallTextures() && scrollbar.getOrientation()==JScrollBar.VERTICAL) thumbTexture.rotate(Texture.ROTATE_90);
	  g.translate(-thumbBounds.x, -thumbBounds.y);
	}


	protected void paintTrack(java.awt.Graphics g, javax.swing.JComponent c, java.awt.Rectangle trackBounds){
	  g.setColor((Color)UIManager.getDefaults().get("Component.lightHighlight"));
	
	  g.fillRect(trackBounds.x, trackBounds.y, trackBounds.width, trackBounds.height);  
	
	  if(trackHighlight == DECREASE_HIGHLIGHT) paintDecreaseHighlight(g);
	  else if(trackHighlight == INCREASE_HIGHLIGHT) paintIncreaseHighlight(g);
	}
}
