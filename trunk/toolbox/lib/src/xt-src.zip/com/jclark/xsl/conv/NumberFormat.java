// $Id: NumberFormat.java,v 1.1 2002/04/25 18:02:51 bill Exp $

package com.jclark.xsl.conv;

/**
 * formats an integer into a String
 */
public interface NumberFormat
{
    String format(int n);
}
