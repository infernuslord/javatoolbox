// $Id: TrueExpr.java,v 1.1 2002/04/25 18:12:20 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

class TrueExpr extends ConvertibleBooleanExpr {
    public boolean eval(Node node, ExprContext context) {
        return true;
    }
}
