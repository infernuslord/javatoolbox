/*
 * Copyright (c) 2005, the JUNG Project and the Regents of the University of
 * California All rights reserved.
 *
 * This software is open-source under the BSD license; see either "license.txt"
 * or http://jung.sourceforge.net/license.txt for a description.
 *
 * Created on Aug 15, 2005
 */

package edu.uci.ics.jung.visualization.control;

import java.awt.event.MouseWheelEvent;
import java.awt.geom.Point2D;

import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.transform.MutableTransformer;

/**
 * MouseWheel events in the SatelliteView will cause the MasterView
 * to scale
 * @author Tom Nelson - RABA Technologies
 *
 */
public class SatelliteCrossoverScalingGraphMousePlugin extends
        CrossoverScalingGraphMousePlugin {

    public SatelliteCrossoverScalingGraphMousePlugin() {
        super();
    }

    public SatelliteCrossoverScalingGraphMousePlugin(float in, float out) {
        super(in, out);
    }
    /**
     * zoom the display in or out, depending on the direction of the
     * mouse wheel motion.
     */
    public void mouseWheelMoved(MouseWheelEvent e) {
        boolean accepted = checkModifiers(e);
        if(accepted == true) {
            
            VisualizationViewer vv = (VisualizationViewer) e.getSource();
            
            if(vv instanceof SatelliteVisualizationViewer) {
                VisualizationViewer vvMaster = 
                    ((SatelliteVisualizationViewer)vv).getMaster();
                
                MutableTransformer viewTransformerMaster = vvMaster.getViewTransformer();
                MutableTransformer modelTransformerMaster = vvMaster.getLayoutTransformer();
                int amount = e.getWheelRotation();
                
                double modelScale = modelTransformerMaster.getScale();
                double viewScale = viewTransformerMaster.getScale();
                double inverseModelScale = Math.sqrt(crossover)/modelScale;
                double inverseViewScale = Math.sqrt(crossover)/viewScale;
                double scale = modelScale * viewScale;
                
                Point2D center = vvMaster.getCenter();
                Point2D ivtcenter = vvMaster.inverseViewTransform(center);
                
                if(amount > 0) {
                    
                    if(scale*in < crossover) {
                        viewTransformerMaster.scale(in, in, center);
                        modelTransformerMaster.scale(inverseModelScale, inverseModelScale, ivtcenter);
                    } else {
                        modelTransformerMaster.scale(in, in, ivtcenter);
                        viewTransformerMaster.scale(inverseViewScale, inverseViewScale, center);
                    }
                } else if(amount < 0) {
                    if(scale*out < crossover) {
                        viewTransformerMaster.scale(out, out, center);
                        modelTransformerMaster.scale(inverseModelScale, inverseModelScale, ivtcenter);
                       
                    } else {
                        modelTransformerMaster.scale(out, out, ivtcenter);
                        viewTransformerMaster.scale(inverseViewScale, inverseViewScale, center);
                    }
                }
                e.consume();
                vv.repaint();
            }
        }
    }

}
