package com.thoughtworks.qdox.directorywalker;

import java.io.File;

public interface FileVisitor {

    void visitFile(File file);

}
