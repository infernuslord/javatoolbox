/*
 * 
 * Created on 2004-jul-25
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.common;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;

import javax.swing.CellRendererPane;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListCellRenderer;
import javax.swing.UIManager;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-25
 *
 */
public class ComboBoxButton extends JButton {
	private static final int LEFT_INSET  = 2;
	private static final int RIGHT_INSET = 3;

	private	final JList				listBox;
	private	final CellRendererPane	rendererPane;

	private	JComboBox	comboBox;
	private	Icon		comboIcon;

	protected boolean   iconOnly = false;




	/**
	 * 
	 * 
	 */
	public ComboBoxButton( JComboBox comboBox, Icon comboIcon, boolean iconOnly, CellRendererPane rendererPane, JList listBox) {
		super( "" );

		this.comboBox		= comboBox;
		this.comboIcon		= comboIcon;
		this.rendererPane	= rendererPane;
		this.listBox		= listBox;
		this.iconOnly		= iconOnly;

		//setMargin( new Insets( getMargin().top, LEFT_INSET, getMargin().bottom, RIGHT_INSET ) );
		setMargin( new Insets( 0, 0, 0, 0 )  );
		setEnabled( comboBox.isEnabled() );
		setRequestFocusEnabled( comboBox.isEnabled() );
	}




	/**
	 * 
	 * 
	 */
	public Icon getComboIcon() {
		return comboIcon;
	}




	/**
	 * 
	 * 
	 */
	public void setIconOnly(boolean b) {
		iconOnly = b;
	}




	/**
	 * 
	 * 
	 */
	public void paintComponent( Graphics g ) {
		super.paintComponent( g );

		Graphics g2 = g.create();

		boolean leftToRight = true;

		// Get insets, width(w), height(h)..
		Insets insets = getInsets();
		int w	= getWidth();
		int h	= getHeight();

		if (h <= 0 || w <= 0) { return; }

		// Fill background..
		g2.setColor( new java.awt.Color( 245, 245, 245 ) );  // TODO FIXED COLOR, BIG NONO!
		g2.fillRect( 0, 0, w-20, h );	// Fill arrow background

		// Fill disabled arrow button background..
		if( !isEnabled() ) {
			g2.setColor( getParent().getParent().getBackground() );
			g2.fillRect( w-20, 0, w-20, h );	// Fill arrow background
		}

		// Draw line left of arrow..
		g2.setColor( new Color( 155, 155, 155 ) );  // TODO FIXED COLOR, BIG NONO!
		g2.drawLine( w-20, 0, w-20, h );	// Draw left of arrow


		
		// Paint the icon
		int left   			= insets.left;
		int top    			= insets.top;
		int right  			= left + (w - 1);
		int iconWidth		= 0;
		int iconLeft 		= (leftToRight) ? right : left;

		if (comboIcon != null) {
			iconWidth 		= comboIcon.getIconWidth();
			int iconHeight	= comboIcon.getIconHeight();
			int iconTop;

			if (iconOnly) {
				iconLeft = (getWidth()  - iconWidth)  / 2;
				iconTop  = (getHeight() - iconHeight) / 2;
			} else {
				if (leftToRight) {
					//iconLeft = (left + (w - 1)) - iconWidth;
					iconLeft = ((w - 1)) - iconWidth - 2;
				} else {
					iconLeft = left;
				}
				iconTop = (getHeight() - iconHeight) / 2;
			}

			comboIcon.paintIcon( this, g, iconLeft, iconTop );
		}



		// Let the renderer paint
		if (!iconOnly && comboBox != null) {
			ListCellRenderer renderer = comboBox.getRenderer();
			boolean renderPressed = getModel().isPressed();
			Component c = renderer.getListCellRendererComponent( listBox, comboBox.getSelectedItem(), -1, renderPressed, false);
			c.setFont(rendererPane.getFont());

			if (model.isArmed() && model.isPressed()) {
				if (isOpaque()) {
					c.setBackground(UIManager.getColor("Button.select"));
				}
				c.setForeground(comboBox.getForeground());
			} else if (!comboBox.isEnabled()) {
				if (isOpaque()) {
					c.setBackground( UIManager.getColor("ComboBox.disabledBackground") );
				}
				c.setForeground( UIManager.getColor("ComboBox.disabledForeground") );
			} else {
				c.setForeground(comboBox.getForeground());
				c.setBackground(comboBox.getBackground());
			}

			int cWidth = w - (insets.right + iconWidth);

			// Fix for 4238829: should lay out the JPanel.
			boolean shouldValidate = c instanceof JPanel;
			int x = left;
			//int myHeight = getHeight() - LEFT_INSET - RIGHT_INSET -  2;
			int myHeight = getHeight();

			if (!(c instanceof JComponent)) {
				rendererPane.paintComponent( g, c, this, x, top + 1, cWidth, myHeight, shouldValidate);
			} else {
				JComponent component = ( JComponent )c;
				boolean hasBeenOpaque = component.isOpaque();
				component.setOpaque( false );
				rendererPane.paintComponent( g, c, this, x, top, cWidth, myHeight, shouldValidate );
				component.setOpaque( hasBeenOpaque );
			}
		}

		g2.dispose();
	}
}
