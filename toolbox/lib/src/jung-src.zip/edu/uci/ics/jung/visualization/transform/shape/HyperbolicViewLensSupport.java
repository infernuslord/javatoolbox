package edu.uci.ics.jung.visualization.transform.shape;

import java.awt.Dimension;

import edu.uci.ics.jung.visualization.PluggableRenderer;
import edu.uci.ics.jung.visualization.Renderer;
import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.transform.AbstractHyperbolicLensSupport;
import edu.uci.ics.jung.visualization.transform.HyperbolicLensSupport;

/**
 * Creates a HyperbolicShapeTransformer to use in the view
 * transform. This one will distort Vertex shapes.
 * 
 * @author Tom Nelson - RABA Technologies
 *
 *
 */
public class HyperbolicViewLensSupport extends AbstractHyperbolicLensSupport
    implements HyperbolicLensSupport {
    
    protected PluggableRenderer pluggableRenderer;
    protected TransformingPluggableRenderer transformingPluggableRenderer;
    protected Renderer renderer;
    
    public HyperbolicViewLensSupport(VisualizationViewer vv) {
        super(vv);
        this.renderer = vv.getRenderer();
        hyperbolicTransformer = new HyperbolicShapeTransformer(vv);
        Dimension d = vv.getSize();
        if(d.width == 0 || d.height == 0) {
            d = vv.getPreferredSize();
        }
        hyperbolicTransformer.setViewRadius(d.width/5);

        if(renderer instanceof PluggableRenderer) {
            this.pluggableRenderer = (PluggableRenderer)renderer;
        } else {
            this.pluggableRenderer = new PluggableRenderer();
        }
    }
    public void activate() {
        lens = new Lens(hyperbolicTransformer);
        vv.setViewTransformer(hyperbolicTransformer);
        if(transformingPluggableRenderer == null) {   
            transformingPluggableRenderer = 
            		new TransformingPluggableRenderer(pluggableRenderer);
        }
        transformingPluggableRenderer.setTransformer(hyperbolicTransformer);
        vv.setRenderer(transformingPluggableRenderer);
        vv.addPreRenderPaintable(lens);
        vv.setGraphMouse(hyperbolicGraphMouse);
        vv.setToolTipText(instructions);
        vv.repaint();
    }

    public void deactivate() {
        vv.setViewTransformer(savedViewTransformer);
        vv.removePreRenderPaintable(lens);
        vv.setRenderer(renderer);
        vv.setToolTipText(defaultToolTipText);
        vv.setGraphMouse(graphMouse);
        vv.repaint();
    }

}