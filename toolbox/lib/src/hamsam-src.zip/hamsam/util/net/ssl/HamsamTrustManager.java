/*
 * Hamsam - Instant Messaging API
 * Copyright (C) 2003 Raghu K
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package hamsam.util.net.ssl;

import java.security.GeneralSecurityException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.X509TrustManager;

/**
 * A TrustManager to validate all certificates that we receive. The default
 * TrustManager that comes with JDK is not aware of many CAs. That is why we
 * need something like this.
 *
 * @author Raghu
 */
class HamsamTrustManager implements X509TrustManager
{
	public X509Certificate[] getAcceptedIssuers()
	{
		return null;
	}

	public void checkClientTrusted(X509Certificate[] certs, String authType)
	{
	}

	public void checkServerTrusted(X509Certificate[] certs, String authType) throws CertificateException
	{
		for(int i = 0; i < certs.length; i++)
		{
			// See if the certificate has expired
			certs[i].checkValidity();

			try
			{
				if(i != certs.length - 1)
				{
					// Make sure that the digital signature is correct
					certs[i].verify(certs[i+1].getPublicKey());
				}
				else
				{
					// This is the CA's certificate. Check if we know this CA.
					TrustedCAs cas = TrustedCAs.getInstance();
					cas.validate(certs[i]);
				}
			}
			catch(CertificateException e)
			{
				throw e;
			}
			catch(GeneralSecurityException e)
			{
				e.printStackTrace(); // TODO do this via logging
			}
		}
	}
}