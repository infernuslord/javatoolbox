package multivalent.std.ui;

import java.net.URI;
import java.awt.AWTEvent;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.util.Map;

import multivalent.*;
import multivalent.gui.VMenu;
import multivalent.gui.VScrollbar;
import multivalent.gui.VEntry;

import phelps.lang.Integers;



/**
	Interface for paginated document types to choose page number (next, previous, first, last, enter number).
	Common code shared by multipage media adaptors ({@link berkeley.adaptor.Xdoc}, {@link tex.dvi.DVI}, {@link multivalent.std.adaptor.pdf.PDF}).
	Uses {@link Document#ATTR_PAGE} and {@link Document#ATTR_PAGECOUNT}.

<!--
	Should separate UI and rest of functionality, which largely do with SemanticUIs in a hub, except want to disable....
-->

	@see multivalent.std.adaptor.PersonalAnnos
	@see multivalent.MediaAdaptor

	@version $Revision: 1.8 $ $Date: 2002/03/07 00:56:23 $
*/
public class Multipage extends Behavior {
  /**
	Open a different page of a multipage document as given by the {@link multivalent.Document}'s {@link Document#ATTR_PAGE} attribute.
	<p><tt>"openDocumentPage"</tt>.
  */
  public static final String MSG_OPENPAGE = "openDocumentPage";

  /**
	Announce new page of document has been opened.
	<p><tt>"openedDocumentPage"</tt>: <tt>arg=</tt> <var>xxx</var>
  */
  public static final String MSG_OPENEDPAGE = "openedDocumentPage";

  /**
	Close current document page, giving other behaviors a chance to save state before moving to a new page or different document.
	<p><tt>"closePage"</tt>: <tt>arg=</tt> {@link java.lang.Integer} <var>current-page-number</var>
  */
  public static final String MSG_CLOSEPAGE = "closeDocumentPage";

  /**
	Opens same page.
	<p><tt>"reloadDocumentPage"</tt>.
  */
  public static final String MSG_RELOADPAGE = "reloadDocumentPage";


  /**
	Move to the next page of a multipage document.
	<p><tt>"nextPage"</tt>.
  */
  public static final String MSG_NEXTPAGE = "nextPage";

  /**
	Move to the previous page of a multipage document.
	<p><tt>"previousPage"</tt>.
  */
  public static final String MSG_PREVPAGE = "previousPage";

  /**
	Move to the first page of a multipage document.
	<p><tt>"firstDocumentPage"</tt>.
  */
  public static final String MSG_FIRSTPAGE = "firstDocumentPage";

  /**
	Move to the last page of a multipage document.
	<p><tt>"lastDocumentPage"</tt>.
  */
  public static final String MSG_LASTPAGE = "lastDocumentPage";

  /**
	Move to the given page of a multipage document.
	<p><tt>"goPageNum"</tt>: <tt>arg=</tt> {@link java.lang.String} or {@link java.lang.Integer} <var>new-page-number</var>
  */
  public static final String MSG_GOPAGE = "goPageNum";

  public static final int PAGECOUNT_UNKNOWN = Integer.MAX_VALUE;  // in Xdoc may not have metadata to know max page number
  public static final int PAGECOUNT_NOT_APPLICABLE = Integer.MIN_VALUE;   // game playing by Plucker: records, not sequential pages



  /** Defaults to 1, set by "?page=<i>num</i>" or by paginated media adaptor. */
  //int initialPage_ = 1;


  /** Appear in Go menu, doc popup, toolbar. */
  public boolean semanticEventBefore(SemanticEvent se, String msg) {
	if (super.semanticEventBefore(se,msg)) return true;

	Browser br = getBrowser();
	Document doc = br.getCurDocument();
	int pagenow = Integers.parseInt(doc.getAttr(Document.ATTR_PAGE), 1), pagecnt = Integers.parseInt(doc.getAttr(Document.ATTR_PAGECOUNT), PAGECOUNT_UNKNOWN); // if PAGECOUNT missing, bad news
	boolean fFirst = (pagenow<=1), fLast = (pagenow>=pagecnt);  // if only one page, then all UI disabled (maybe not show?)

	if (VMenu.MSG_CREATE_GO==msg || (DocumentPopup.MSG_CREATE_DOCPOPUP==msg && se.getIn()!=getBrowser().getSelectionSpan())) {
		String cat = (VMenu.MSG_CREATE_GO==msg? "Go": "NAVIGATE");
		INode menu = (INode)se.getOut();
		createUI("button", "Next Page", "event "+MSG_NEXTPAGE, menu, cat, fLast);
		createUI("button", "Previous Page", "event "+MSG_PREVPAGE, menu, cat, fFirst);
		createUI("button", "First Page", "event "+MSG_FIRSTPAGE, menu, cat, fFirst);
		createUI("button", "Last Page", "event "+MSG_LASTPAGE, menu, cat, fLast);

	} else if (Browser.MSG_CREATE_TOOLBAR==msg) {
		if (pagecnt!=PAGECOUNT_NOT_APPLICABLE) {
			INode p = (INode)se.getOut();
			createUI("button", "<img src='systemresource:/sys/images/StepBack16.gif'>", "event "+MSG_PREVPAGE, p, null, fFirst);
			createUI("button", "<img src='systemresource:/sys/images/StepForward16.gif'>", "event "+MSG_NEXTPAGE, p, null, fLast);

			String txt = ""+pagenow;
			VEntry e = (VEntry)createUI("entry", txt, "event "+MSG_GOPAGE+" $TEXT", p, null, false);
			e.setSizeChars(/*(pagenow <= 19? 1:*/ txt.length()/*)*/, 1);
			if (pagecnt!=PAGECOUNT_UNKNOWN) createUI("label", " of "+pagecnt, null, p, null, false);
		}

	} else if (Document.MSG_CLOSE==msg) {
//System.out.println("Multipage closeDocument in Before");
		br.event(new SemanticEvent(br, MSG_CLOSEPAGE, null));
	}

	return false;
  }


  /** Implement the following events: previosuPage, nextPage, fistPage, lastPage. */
  public boolean semanticEventAfter(SemanticEvent se, String msg) {
	Browser br = getBrowser();
	Document doc = br.getCurDocument();
	//Document doc = getDocument();

	boolean foD = Document.MSG_OPENED==msg;

	int pagenow = Integers.parseInt(doc.getAttr(Document.ATTR_PAGE), 1), pagecnt = Integers.parseInt(doc.getAttr(Document.ATTR_PAGECOUNT), PAGECOUNT_UNKNOWN);
//if (msg.indexOf("Page")!=-1) System.out.print(msg+", pagenow="+pagenow+" => ");
	int pagenew = pagenow;

	if (MSG_OPENPAGE==msg) {
		//Object arg = se.getArg();
		//Browser br = getBrowser();
		//Document doc = br.getCurDocument();
//System.out.println("MediaAdaptor msg="+msg+", page="+doc.getAttr(Document.ATTR_PAGE));
		if (doc.getAttr(Document.ATTR_PAGE)!=null) {
			doc.removeAllChildren();
//System.out.println("mp build page "+pagenow);
			doc.getLayer(Layer.SCRATCH).clear();
			doc.getLayers().buildBeforeAfter(doc);
			//buildBefore(doc); buildAfter(doc);
			br.setCurDocument(doc); // regen UI
		}

	} else if (MSG_GOPAGE==msg) {
		Object arg = se.getArg();
//System.out.println(msg+" |"+arg+"|, class="+(arg!=null? arg.getClass().getName(): null));
		if (arg instanceof String) {
			String snum = ((String)arg).trim();
			try { pagenew = Integer.parseInt(snum); } catch (NumberFormatException nfe) { /* too bad */ }
		} else if (arg instanceof Integer) {
			pagenew = ((Integer)arg).intValue();
		}

	} else if (pagecnt==PAGECOUNT_NOT_APPLICABLE) {}  // === barrier ===

	//else if (foD) pagenew = Math.max(1, Math.min(pagecnt, initialPage_));
	else if (foD) pagenew = Math.max(1, Math.min(pagenew, pagecnt));

	else if (MSG_PREVPAGE==msg) pagenew--;

	else if (MSG_NEXTPAGE==msg) pagenew++;

	else if (MSG_FIRSTPAGE==msg) pagenew=1;

	else if (pagecnt==PAGECOUNT_UNKNOWN) {}   // === barrier ===

	else if (MSG_LASTPAGE==msg) pagenew=pagecnt;



//System.out.println("Multipage "+msg+" "+pagenow+"=>"+pagenew);
	// LATER: check that pagenew within bounds: PAGE0...PAGECOUNT, special cases _UNKNOWN _N_A

	if ((pagenew!=pagenow || MSG_RELOADPAGE==msg || foD)
		&& ((pagenew>=1 && pagenew<=pagecnt) || pagecnt==PAGECOUNT_UNKNOWN || pagecnt==PAGECOUNT_NOT_APPLICABLE)) {
//System.out.println(msg+": "+pagenow+" => "+pagenew);
//System.out.println(pagenew);
		if (!foD) br.event(new SemanticEvent(br, MSG_CLOSEPAGE, Integer.toString(pagenow)));
		String snew = Integer.toString(pagenew);
		doc.putAttr(Document.ATTR_PAGE, snew); // setAttr sem ev?
//System.out.println("multipage "+snew);
//System.out.println("invalidating "+doc+" / "+doc.getName());
		doc.setValid(false); doc.getVsb().setValue(0);
		br.eventq(MSG_OPENPAGE, snew);
		// ... can't send MSG_OPENEDPAGE right after as may play URI tricks
//System.out.println("openDocumentPage "+pagenew);
	}
//if (pagenew!=pagenow) System.out.println("Multipage "+pagenow+" => "+pagenew+" of "+pagecnt+" on "+msg);

	return super.semanticEventAfter(se, msg);
  }


  public void buildAfter(Document doc) { doc.addObserver(this); }

  /**
	If at bottom of page, Space and PageDown flip to next page.
	If at top of page, PageUp flips to bottom of previous page.
	HOME goes to first page, END goes to last.
  */
  public boolean eventAfter(AWTEvent e, Point rel, Node n) {
	if (e.getID()==KeyEvent.KEY_PRESSED) {
		int code = ((KeyEvent)e).getKeyCode();
		Document doc = getDocument();
		VScrollbar vsb = doc.getVsb();
		int pagenow = Integers.parseInt(doc.getAttr(Document.ATTR_PAGE), 1), pagecnt = Integers.parseInt(doc.getAttr(Document.ATTR_PAGECOUNT), Integer.MAX_VALUE);
		Browser br = getBrowser();

		if (pagecnt==PAGECOUNT_NOT_APPLICABLE /*|| pagecnt==PAGECOUNT_UNKNOWN*/) {
		} else if (code==' ' || code==KeyEvent.VK_PAGE_DOWN) {
			if (pagenow < pagecnt && vsb.getValue()+doc.bbox.height >= vsb.getMax()) {
				br.eventq(MSG_GOPAGE, Integer.toString(pagenow+1));
				return true;
			}

		} else if (code==KeyEvent.VK_PAGE_UP) {
			if (pagenow > 0 && vsb.getValue()==vsb.getMin()) {
				br.eventq(MSG_GOPAGE, Integer.toString(pagenow-1));
				br.eventq(IScrollPane.MSG_SCROLL_TO, new Integer(Integer.MAX_VALUE));	// bottom of previous page so symmetric with going forward
				return true;
			}

		} else if (code==KeyEvent.VK_HOME) {
System.out.println("go page "+pagenow+"=>1");
			if (pagenow > 1) br.eventq(MSG_GOPAGE, new Integer(1));
		} else if (code==KeyEvent.VK_END) {
			if (pagenow < pagecnt) br.eventq(MSG_GOPAGE, new Integer(pagecnt));
//System.out.println("go page "+pagenow+"=>"+pagecnt);

		} else if (code==KeyEvent.VK_LEFT) {
			if (pagenow > 1 && !br.getCursorMark().isSet()) br.eventq(MSG_GOPAGE, new Integer(pagenow-1));
		} else if (code==KeyEvent.VK_RIGHT) {
			if (pagenow < pagecnt && !br.getCursorMark().isSet()) br.eventq(MSG_GOPAGE, new Integer(pagenow+1));
		}
	}

	return false;
  }



  /**
	If page given in URL anchor (e.g, <code>#page=5</code> or <code>#page10</code> or <code>#page.15</code>), use that.
	Else if PAGE attr already set, store it and set to null, so paginated media adaptor won't try to build.
  */
  public void restore(ESISNode n, Map<String,Object> attr, Layer layer) {
	super.restore(n, attr, layer);

	Document doc = getDocument();
	//initialPage_ = Integers.parseInt(doc.getAttr(Document.ATTR_PAGE), 1);
//System.out.println("Multipage initial page = "+initialPage_);
	doc.removeAttr(Document.ATTR_PAGE);

	// take page number from anchor
	URI uri = doc.getURI();
	String ref = uri.getFragment();
	if (ref!=null) {    // overrides page set by media adaptor or vice-versa?
		String lcref = ref.toLowerCase();
		if (lcref.startsWith("page")) { // "page" or "page=" ok
			int page=0; char ch; for (int i=lcref.length()-1, place=1; Character.isDigit(ch=lcref.charAt(i)); i--, place*=10) page += (ch-'0')*place;
			//*if (page>0)*/ initialPage_ = page;    // don't check validity here -- leave to media adaptor, as for example Plucker takes record numbers as pages
			if (page>0) doc.putAttr(Document.ATTR_PAGE, Integer.toString(page));
		}
	}
//System.out.println(ref+" => "+initialPage_);
  }
}
