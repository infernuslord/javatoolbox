package multivalent.std.ui;

import java.awt.*;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.event.KeyEvent;

import multivalent.*;
import multivalent.std.span.SelectionSpan;



/**
	Event bindings that are the same across platforms, such as right arrow key moving the cursor right.
	Other bindings, as for Emacs and Windoze, convert their more involved bindings to an event for this,
	as for instance Emacs rethrows a C-y event as a KeyEvent.VK_PASTE event.

	Pluggable events via hub document: pan-document type mouse and keyboard events.
	Other modules can provide Emacs, vi, Macintosh, Windows, ...

	@see multivalent.std.ui.BindingsEmacs
	@see multivalent.std.ui.BindingsTk

	@version $Revision: 1.4 $ $Date: 2002/06/25 00:25:33 $
*/
public class BindingsDefault extends Behavior implements EventListener {
  static final boolean DEBUG=false;

  Mark selpivot = new Mark(null,-1);	// same as cursor.	need to draw this
  //int dragx=0, dragy=0;
  //boolean inmediasres=false; => same as grab
  boolean wordwise_ = false;



  /** Adds self as observer on root in order catch mouse and key events. */
  public void buildAfter(Document doc) { doc.getRoot().addObserver(this); }



  public boolean eventBefore(AWTEvent e, Point rel, Node obsn) {
	if (e.getID()==MouseEvent.MOUSE_PRESSED) getBrowser().setScope(null);
	return super.eventBefore(e, rel, obsn);
  }



  public boolean eventAfter(AWTEvent e, Point rel, Node obsn) {
//System.out.println("eventAfter: BindingsDefault");
	Browser br = getBrowser();
	INode scope = br.getScope();
	if (br.getGrab()!=null && br.getGrab()!=this) return false;	// ugh
	Document doc = br.getCurDocument();
	CursorMark curs = br.getCursorMark();
	Mark cursm=curs.getMark(); Leaf cursn=cursm.leaf; int cursoff=cursm.offset;
	//Mark curm = br.getCurMark();
	//Node curp=br.getCurNode();
	//Leaf curn=curm.leaf; int curoff=curm.offset;
	Node curn=br.getCurNode(); int curoff=br.getCurOffset();
	Span sel = br.getSelectionSpan();
	//Point scrnpt = getBrowser().getCurScrn();
	//Point scrnpt = rel;
	int eid = e.getID();
	MouseEvent me = (MouseEvent.MOUSE_FIRST<=eid && eid<=MouseEvent.MOUSE_LAST? (MouseEvent)e: null);
	KeyEvent ke = (KeyEvent.KEY_FIRST<=eid && eid<=KeyEvent.KEY_LAST? (KeyEvent)e: null);

//System.err.println("curoff = "+curoff);
//if (eid!=MouseEvent.MOUSE_MOVED) System.out.println("Default event id="+eid+", mods="+((InputEvent)e).getModifiers());

//System.out.println("meta="+e.metaDown()+", control="+e.controlDown()+", shift="+e.shiftDown()+", alt="+((e.modifiers&Event.ALT_MASK)!=0));
//if (e instanceof KeyEvent) { System.out.println("key="+((KeyEvent)e).getKeyCode()+", mods = "+((KeyEvent)e).getModifiers()); }

	if (eid==MouseEvent.MOUSE_PRESSED && me.isShiftDown()) {  // not e.shiftDown() because want SHIFT only
		// shift-click extends selection (ignore and pretent didn't see previous MOUSE_UP)
		// if no previous selection, treat as regular MOUSE_DOWN
		br.requestFocus();
		//!!! if (sel.isSet() || curs.isSet()) { e.modifiers = e.modifiers^Event.SHIFT_MASK; return eventAfter(e); }
		return false;

	} else if (eid==MouseEvent.MOUSE_PRESSED && (me.getModifiers() & InputEvent.BUTTON1_MASK) !=0) {
/* moved to eventBefore
//System.out.println("**************** MOUSE_PRESSED ****");
		// set focus to new Document
		Node actn = curn;
		Document ndoc = actn.getDocument();
		if (ndoc!=null && doc!=ndoc && ndoc.getParentNode()!=null && !"_UIROOT".equals(ndoc.getParentNode().getName())) {  //!=br.getDocRoot()) {
			br.setCurDocument(ndoc);
			br.repaint(100);  // draw border
			//return true; -- awkward to double click to initiate selection in non-focus window
		}
*/
		if (curs.isSet() && me.getClickCount()==2) {
			Leaf n = cursm.leaf;
			sel.move(n,0, n,n.size());
			selpivot.move(n,0); curs.move(null,-1);
			n.repaint(100);

			/*inmediasres=true;*/ br.setGrab(this);	// lost grab with intermediate release!
			wordwise_ = true;

		} else {
			//if (n!=null) br.setCurDocument(n.getDocument());
//System.out.println("curn = "+curn+", scope="+scope);
			//if (curn!=null || curp!=null) {
				//Leaf newcurn=curn; int newcuroff=curoff;
				if (curn==null && scope!=null) {   // blank area of editable region move to end (should be start?)
					curn = scope.getLastLeaf();
					if (curn!=null) curoff=curn.size();
				}
				if (curn!=null && curn.isLeaf() && curoff>=0/* same as n.isLeaf()*/) {
					curs.move((Leaf)curn,curoff); //curs.viz=true;
//System.out.println("setting cursor to "+curn+"/"+curoff);
					br.requestFocus();
					curn.repaint(100);

					/*inmediasres=true;*/ br.setGrab(this);
					wordwise_ = false;
				}
			//}

			// regardless of setting cursor or clicking out of bounds, zap selection
			if (sel.isSet()) {
				sel.repaint(100);	// put area on queue to be restored
				sel.moveq(null);	//remove();	// clean up old selection
				selpivot.remove();	// start new span -- selpivot set to cursor on drag
			}
// save absolute bbox of node so can use for MOUSE_DRAG
			//} else return false; // don't eat if don't do anything
		}

	//} else if (eid==MouseEvent.MOUSE_PRESSED && me.isAltDown()) {
		//br.setGrab(this);
		//dragx=scrnpt.x; dragy=scrnpt.y;


	} else if (eid==KeyEvent.KEY_PRESSED && ke.isActionKey()) {
		boolean shift = ke.isShiftDown(), ctrl = ke.isControlDown();

		if (ke.getModifiers()==0) switch (ke.getKeyCode()) {
		// should throw appropriate events (e.g., SCROLL_PAGE_DOWN) instead
		case KeyEvent.VK_PAGE_DOWN: doc.scrollBy(0, doc.bbox.height-20); break;
		case KeyEvent.VK_PAGE_UP: doc.scrollBy(0, -(doc.bbox.height-20)); break;
		case KeyEvent.VK_DOWN: doc.scrollBy(0, 20); break;
		case KeyEvent.VK_UP: doc.scrollBy(0, -20); break;
		case KeyEvent.VK_HOME:
			if (scope==null) {
				/*if (ke.isControlDown())*/ doc.scrollTo(0,0);
			} else { // apply to cursor as in Windows?  are we an editor or a browser?  if cursor set, we're an editor?
				// move to WindozeBindings?
				Leaf scopel=scope.getFirstLeaf();
				if (shift) {
					if (curs.isSet()) { selpivot.move(cursn, cursoff); curs.move(null); }
					sel.move(scopel,0, selpivot.leaf,selpivot.offset);	// maybe just move to end of line (while leaves have same baseline)
				} else {
					sel.move(null); curs.move(scopel, 0);
				}
			}
			break;
		case KeyEvent.VK_END:
//System.err.println("Default, VK_END, scope="+scope);
			if (scope==null) {
				/*if (ke.isControlDown())*/ doc.scrollTo(0,Integer.MAX_VALUE);
			} else {
				Leaf scopel=scope.getLastLeaf(); int scopeend=scopel.size();
				if (shift) {
					if (curs.isSet()) { selpivot.move(cursn, cursoff); curs.move(null); }
					sel.move(selpivot.leaf,selpivot.offset, scopel,scopeend);
				} else {
					sel.move(null); curs.move(scopel, scopel.size());
				}
			}
			break;

		case KeyEvent.VK_RIGHT:
			curs.move(+1);
			if (scope!=null && !scope.contains(curs.getMark().leaf)) curs.move(-1);
			break;

		case KeyEvent.VK_LEFT:
			curs.move(-1);
			if (scope!=null && !scope.contains(curs.getMark().leaf)) curs.move(+1);
			break;

/*		case KeyEvent.VK_LEFT:
			if (cursoff!=0) curs.move(cursn,0);
			else { n=cursn.getPrevLeaf(); if (n!=null) curs.move(n,0); }
			break;*/

		//case KeyEvent.VK_DELETE: break;

		case KeyEvent.VK_COPY:
System.out.println("BindingsDefault COPY");
			br.eventq(StandardEdit.MSG_COPY, null);
			break;

		case KeyEvent.VK_PASTE:
System.out.println("BindingsDefault PASTE");
			br.eventq(StandardEdit.MSG_PASTE, null);
			break;

		} else return false;

		if (scope!=null && scope.contains(cursn)) cursm.scrollTo();

	} else if (eid==KeyEvent.KEY_PRESSED && ke.isControlDown()) {
		switch (ke.getKeyCode()+'a'-1) {
		case 'l':
			br.getRoot().markDirtySubtree(true);	// until incremental reformat works on harder cases
			br.repaint();		 // useful for debugging incremental repaint
			break;
		default: return false;
		}

	} else if (eid==KeyEvent.KEY_PRESSED && (ke.getModifiers()==0 || ke.isShiftDown())) {
		int keycode = ke.getKeyCode();

		boolean precursset = curs.isSet();     // pre-delete
		if (scope!=null && sel.isSet()) {   // centralized selection deletion
			Leaf l=sel.getStart().leaf; int off=sel.getStart().offset;
			l.delete(off, sel.getEnd().leaf,sel.getEnd().offset);
			cursn=cursm.leaf; cursoff=cursm.offset; // update to post delete values
		}

		switch (keycode) {
		case ' ':
			if (scope!=null) {
				//cursn.insert(cursoff, ' ', scope); -- later?
/*				if (cursoff==cursn.size() && curs.scope.getLastLeaf()==cursn) {
					Leaf l = new LeafAscii("",null, cursn.getParentNode());
					curs.move(l,0);
					cursn.markDirty();
				} else*/ //curs.move(
				cursn.insert(cursoff, ' ', scope);//  );
//System.out.println("split word @ "+cursn+"/"+cursoff);
			} else doc.scrollBy(0, doc.bbox.height-20); // move to BindingsEmacs?
			break;
		case 8: // backspace
		case 0x7f: // delete
			//Leaf postn=null; int postoff=0;
//System.out.println("scope = "+curs.scope+'
			if (scope!=null) {
				if (precursset) {
					Leaf l=null; int off=0;
					if (keycode == 8) curs.move(-1);	// delete previous character
					Mark m=curs.getMark(); l=m.leaf; off=m.offset;	// after moved cursor
					l.delete(off, cursn,cursoff);
				}
			} else doc.scrollBy(0, -(doc.bbox.height-20));
			break;

		case 10:
			// maybe put this functionality in Node or INode
			// for now, create new branch of same type as parent
//System.out.println("BindingsEmacs: split line");
			if (scope!=null && curs.isSet()) {
				cursn.split(cursoff);
				br.repaint();
			}
			break;
//			case KeyEvent.VK_DELETE: if (cursoff>0) cursn.delete(cursoff-1, cursn,cursoff); break;

		default:
			if (ke.getKeyCode()>=' ' && scope!=null /*regardless of precursset*/ && curs.isSet()) {
//System.out.println("BindingsDefault insert, sel.isSet()="+sel.isSet());
				cursn.insert(cursoff, ke.getKeyChar(), scope);
			} else return false;
			//return false;
		}

		if (scope!=null && scope.contains(cursn)) cursm.scrollTo();

	} else return false;
	return true;
  }



  public void event(AWTEvent e) {
	int eid = e.getID();
	Browser br = getBrowser();
	CursorMark curs = br.getCursorMark();
	Mark cursm=curs.getMark(); //Leaf cursn=cursm.leaf; int cursoff=cursm.offset;
	Span sel = br.getSelectionSpan();

	if (eid == MouseEvent.MOUSE_RELEASED) { // regardless of modifiers
		/*inmediasres=false;*/ br.releaseGrab(this);
		br.clipboard();	// on demand in Java 1.1
		if (curs.isSet()) br.eventq(CursorMark.MSG_SET, curs);   // had grab when these fired
		else if (sel.isSet()) br.eventq(SelectionSpan.MSG_SET, sel);   // had grab when these fired


	//} else if (debug && eid==MouseEvent.MOUSE_MOVED) {
		//showStatus("x="+e.x+", y="+e.y); -- GridBag bug in Cafe
		//br.eventq(Browser.MSG_STATUS, "

	// selection
//	} else if (inmediasres) {
	} else if (eid==MouseEvent.MOUSE_DRAGGED) {
		// should restrict search to current inode? (cache its abs x,y and subtract from scrnpt)
		//scrnpt.translate(+3,0);
		//Mark m = /*br.getCurDocument()*/doc.getRoot().findDFS(scrnpt);
		//br.eventq("findNode",null); => semantic events not passed through tree anymore
		//br.event(new TreeEvent(this, TreeEvent.FIND_NODE)/*, scrnpt/*, null*/);
//System.out.print(""+curn+" => ");
		br.setCurNode(null);
		br.getRoot().eventBeforeAfter(new TreeEvent(this, TreeEvent.FIND_NODE), br.getCurScrn());
		//Mark curm = br.getCurMark(); Leaf curn=curm.leaf; int curoff=curm.offset;	// update after FIND (grab set)
		Node curn=br.getCurNode(); int curoff=br.getCurOffset();
//System.out.println(curn);

//System.out.println("wordwise_ = "+wordwise_+", offset="+curoff);
		//scrnpt.translate(-3,0);
//if (curm!=null) System.out.println("dragged over "+curn+"/"+curoff);
		//if (curoff>=0 /* same as curn.isLeaf() -- not anymore */) {
		if (curn!=null && curn.isLeaf() && curoff>=0) {
			Leaf curl=(Leaf)curn;
//if (!(curn.isLeaf())) System.out.println("not a leaf!");
				//if (wordwise_) curoff = (curoff<curn.size()/2? 0: curn.size()); -- maybe, but refine

			Node oselendnode; int oselendoff;
			if (curs.isSet()) {	// dragging cursor into pivot+selection
				if (cursm.leaf.size()==1 && cursm.offset==1) cursm.move(-1);   // hack
				selpivot.move(cursm);
				oselendnode = cursm.leaf; oselendoff=cursm.offset;
				curs.move(null);
			} else {	// started dragging outside of leaf, so have to set pivot point
				if (!selpivot.isSet()) selpivot.move(curl,curoff);
				oselendnode = sel.getEnd().leaf; oselendoff=sel.getEnd().offset;
			}

			if (!(oselendnode==curn && oselendoff==curoff)) {
				sel.move(selpivot.leaf,selpivot.offset, curl,curoff);
//System.out.println("extending selection to "+curn+"/"+curoff);
			}
//System.out.println("moving endpoint to "+curn+"/"+curoff);
//System.out.println("selection now "+sel.getStart().leaf+"/"+sel.getStart().offset+".."+sel.getEnd().leaf+"/"+sel.getEnd().offset);
		}
	}
  }
}
