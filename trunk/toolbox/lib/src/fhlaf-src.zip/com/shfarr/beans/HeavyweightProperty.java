/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.beans;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.MethodDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import com.shfarr.BasicUtils;

public class HeavyweightProperty implements Comparable, Property{
	protected int level = 0;
    protected Method readMethod = null;
    protected Method writeMethod = null;
    protected String name = null;
    
    public HeavyweightProperty(String name, Class beanClass){
        this.name = name;
        this.readMethod = lookupGetter(name, beanClass);
        if(this.readMethod == null) throw new Error("Invalid property! there is no read method");
        this.writeMethod = lookupSetter(name, beanClass, getType());
    }

    public HeavyweightProperty(String name, int level, Method getter, Method setter){
        this.name = name;
        this.level = level;
        this.readMethod =  getter;
        this.writeMethod = setter;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int newLevel) {
        level = newLevel;
    }
    
    public String getName() {
        return name;
    }

    public Method getReadMethod() {
        return readMethod;
    }

    public void setReadMethod(Method readMethod) {
        this.readMethod = readMethod;
    }

    public Method getWriteMethod() {
        return writeMethod;
    }

    public void setWriteMethod(Method writeMethod) {
        this.writeMethod = writeMethod;
    }
    
    public String toString(){
        return name + " (" + (readMethod != null ? "R" : "") + (writeMethod != null ? "W" : "") + ")";
    }

    public Class getType(){
        return readMethod != null ? readMethod.getReturnType() : writeMethod.getParameterTypes()[0];
    }
    
    public boolean isReadOnly(){
        return writeMethod == null;
    }

    public boolean isWriteOnly(){
        return readMethod == null;
    }

    public boolean isReadWrite(){
        return !isReadOnly() && !isWriteOnly();
    }
    
    public static Method lookupGetter(String property, Class c){
        String getterMethodName = BasicUtils.changeCase(property, BasicUtils.CAPITAL_CASE), alternativeGetterMethodName = "is" + getterMethodName;

        getterMethodName = "get" + getterMethodName;

        MethodDescriptor[] md = null;

        try{
            BeanInfo bi = Introspector.getBeanInfo(c);
            md = bi.getMethodDescriptors();
        }
        catch(Exception e){
            e.printStackTrace();
        }

        for(int i = 0; i < md.length; i++) {
            if((md[i].getMethod().getName().equals(getterMethodName) || md[i].getMethod().getName().equals(alternativeGetterMethodName)) &&
                                                                                       md[i].getMethod().getParameterTypes().length == 0 &&
                                                                                       !md[i].getMethod().getReturnType().equals(void.class))
                return md[i].getMethod();
        }

        return null;
    }

    public static Method lookupSetter(String property, Class c, Class paramType){
        String setterMethodName = "set" + BasicUtils.changeCase(property, BasicUtils.CAPITAL_CASE);

        MethodDescriptor[] md = null;

        try{
            BeanInfo bi = Introspector.getBeanInfo(c);
            md = bi.getMethodDescriptors();
        }
        catch(Exception e){
            e.printStackTrace();
        }

        for(int i = 0; i < md.length; i++){
            if(md[i].getMethod().getName().equals(setterMethodName) && md[i].getMethod().getParameterTypes().length == 1 &&
                                                    paramType.isAssignableFrom(md[i].getMethod().getParameterTypes()[0]) &&
                                                    md[i].getMethod().getReturnType().equals(void.class))
                return md[i].getMethod();
        }

        return null;
    }
    
    public int compareTo(Object o){
        return name.compareTo(((HeavyweightProperty)o).getName());
    }
    
    public Object getValue(Object target){
        try{
			return getReadMethod().invoke(target, null);
		}
        catch(IllegalArgumentException e){
            throw new RuntimeException("" + getReadMethod() + " / " + target, e);
		}
        catch(IllegalAccessException e){
            throw new RuntimeException(e);
		}
        catch(InvocationTargetException e){
            throw new RuntimeException(e);
		}
    }

    public boolean setValue(Object target, Object value){
        try{
            getWriteMethod().invoke(target, new Object[] { value });
            return true;
        }
        catch (Exception e){
            return false;
        }
    }
    
    public boolean equals(Object o){
        return o instanceof Property && ((Property)o).getName().equals(getName());
    }
}
