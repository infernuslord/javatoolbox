/*
 *   The contents of this file are subject to the Mozilla Public License
 *   Version 1.1 (the "License"); you may not use this file except in
 *   compliance with the License. You may obtain a copy of the License at
 *   http://www.mozilla.org/MPL/
 *
 *   Software distributed under the License is distributed on an "AS IS"
 *   basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 *   License for the specific language governing rights and limitations
 *   under the License.
 *
 *   The Original Code is Matra - the DTD Parser.
 *
 *   The Initial Developer of the Original Code is Conrad S Roche.
 *   Portions created by Conrad S Roche are Copyright (C) Conrad 
 *   S Roche. All Rights Reserved.
 *
 *   Alternatively, the contents of this file may be used under the terms
 *   of the GNU GENERAL PUBLIC LICENSE Version 2 or any later version
 *   (the  "[GPL] License"), in which case the
 *   provisions of GPL License are applicable instead of those
 *   above.  If you wish to allow use of your version of this file only
 *   under the terms of the GPL License and not to allow others to use
 *   your version of this file under the MPL, indicate your decision by
 *   deleting  the provisions above and replace  them with the notice and
 *   other provisions required by the GPL License.  If you do not delete
 *   the provisions above, a recipient may use your version of this file
 *   under either the MPL or the GPL License."
 *
 *   [NOTE: The text of this Exhibit A may differ slightly from the text of
 *   the notices in the Source Code files of the Original Code. You should
 *   use the text of this Exhibit A rather than the text found in the
 *   Original Code Source Code for Your Modifications.]
 *
 * Created: Conrad S Roche <derupe at users.sourceforge.net>,  28-Sep-2003
 */
package com.conradroche.matra.test.parser;

import com.conradroche.dtd.decl.AttlistDecl;
import com.conradroche.dtd.parser.AttlistReader;
import com.conradroche.matra.data.DTDData;
import com.conradroche.matra.exception.DTDSyntaxException;
import com.conradroche.matra.parser.AttlistReaderImpl;

import junit.framework.Assert;
import junit.framework.TestCase;

/**
 * Class to unit test the AttlistReaderImpl class.
 *
 * @author Conrad Roche
 */
public class AttlistReaderImplTest extends TestCase {

	private AttlistReader reader = new AttlistReaderImpl();
	 
	/**
	 * Constructor for AttlistReaderImplTest.
	 * @param arg0
	 */
	public AttlistReaderImplTest(String arg0) {
		super(arg0);
	}
	//[52] AttlistDecl    ::= '<!ATTLIST' S Name AttDef* S? '>'
	//[53] AttDef         ::= S Name S AttType S DefaultDecl
	//[54] AttType        ::=    StringType | TokenizedType | EnumeratedType  
	//[55] StringType     ::=    'CDATA' 
	//[56] TokenizedType  ::=    'ID' | 'IDREF' | 'IDREFS' | 'ENTITY' | 'ENTITIES' | 'NMTOKEN' | 'NMTOKENS'
	//[57] EnumeratedType ::=    NotationType | Enumeration 
	//[58] NotationType   ::=    'NOTATION' S '(' S? Name (S? '|' S? Name)* S? ')' 
	//[59] Enumeration    ::=    '(' S? Nmtoken (S? '|' S? Nmtoken)* S? ')' 

	public void testNullData() {
		
		DTDData nullData = null;
		checkNonAttlist(nullData);
	}
	
	private void checkNonAttlist(DTDData data) {
		
		boolean isStart = false;
		try {
			isStart = reader.isAttlistStart(data);
		} catch(Throwable th) {
			Assert.fail("Caught exception in isAttlistStart while checking with (" + data + ") data. - " + th.getMessage()); 
		}
		Assert.assertFalse("isAttlistStart was true for data - " + data, isStart);
		
		AttlistDecl attlist = null;
		try {
			attlist = reader.readAttlist(data);
		} catch(Throwable th) {
			Assert.fail("Caught exception in readAttlist while checking with (" + data + ") data. - " + th.getMessage()); 
		}
		Assert.assertNull(attlist);
	}
	
	public void testEmptyData() {
		
		DTDData data = new DTDData("");
		checkNonAttlist(data);
		
		data.reset();
		checkNonAttlist(data);
	}
	
	public void testNonAttlist() {
		//provide '<!non-notation'
	
		String[] nonAttlists = { "  ", "\n\t \n", "<!TEST  ", "<!ENTITY asdasa", 
						"<!ATTLIST1", "<~ATTLIST", "ATTLIST", "!ATTLIST", "<ATTLIST", 
						"<!AttList", "<!Attlist", "<!attlist", "<!ATTlist"
						};
		for (int i = 0; i < nonAttlists.length; i++) {
			checkNonAttlist(nonAttlists[i]);
		}
	}
	
	private void checkNonAttlist(String str) {
		
		DTDData data = new DTDData(str);
		checkNonAttlist(data);
	}
	
	public void testEmptyAttlist() {
		//'<!ATTLIST' S Name S? '>'
		String[] S = {"", " ", "\t", "\n", "\r", "\t \n", "\r\t\n"};
		
		String[] name = {"elem", "name", "hi123"};
		String prepend = "<!ATTLIST";
		
		DTDData data = null;
		
		for(int i = 0; i < S.length - 1; i++) {
			for(int j = 0; j < name.length; j++) {
				for( int k = 0; k < S.length; k++) {
					data = new DTDData(prepend + S[i + 1] + name[j] + S[i] + ">");
					checkAttlistStart(data); 	
					checkValidAttlistRead(data);			
				}
			}
		}
	}
	
	public void testInvalidName() {
		//provide '<!ATTLIST' <invalid name>
		
		String[] invalidNames = { "3423"
						};
		String prepend = "<!ATTLIST ";
		String append[] = {" SYSTEM\tSYS_id>", "\tPUBLIC PUB_id>", "\nPUBLIC pub_ID\tSyS_id\n>"	};
		
		DTDData data = null;
		
		for(int i = 0; i < invalidNames.length; i++) {
			for(int j = 0; j < append.length; j++) {
				
				data = new DTDData(prepend + invalidNames[i] + append[j]);
				checkAttlistStart(data); 	
				checkInvalidAttlistRead(data);			
			}
		}
	}

	private void checkAttlistStart(DTDData data) {
		
		boolean isStart = false;
		try {
			isStart = reader.isAttlistStart(data);
		} catch(Throwable th) {
			Assert.fail("Caught exception in isAttlistStart while checking with (" + data + ") data. - " + th.getMessage());
			return; 
		}
		Assert.assertTrue("isAttlistStart was false for data - " + data, isStart);
	}
	
	private void checkInvalidAttlistRead(DTDData data) {
		
		try {
			AttlistDecl attlist = reader.readAttlist(data);
		} catch(DTDSyntaxException dse) {
//			dse.printStackTrace();
			return;
		} catch(Throwable th) {
//			th.printStackTrace();
			Assert.fail("Caught exception in readAttlist while checking with (" + data + ") data. - " + th.getMessage());
			return; 
		}
		Assert.fail("Didn't catch syntax exception while parsing AttList - " + data);
	}
	
	private AttlistDecl checkValidAttlistRead(DTDData data) {
		
		try {
			AttlistDecl attlist = reader.readAttlist(data);
			return attlist;
		} catch(DTDSyntaxException dse) {
//			dse.printStackTrace();
			Assert.fail("Caught DTDSyntaxException in readAttlist while checking with (" + data + ") data. - " + dse.getMessage());
		} catch(Throwable th) {
//			th.printStackTrace();
			Assert.fail("Caught exception in readAttlist while checking with (" + data + ") data. - " + th.getMessage());
		}
		return null;
	}
}
