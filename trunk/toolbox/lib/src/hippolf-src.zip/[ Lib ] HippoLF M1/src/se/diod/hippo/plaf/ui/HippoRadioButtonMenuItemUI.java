/*
 * 
 * Created on 2004-jul-22
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.ui;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.ButtonModel;
import javax.swing.JComponent;
import javax.swing.JMenuItem;
import javax.swing.UIManager;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicRadioButtonMenuItemUI;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-22
 *
 */
public class HippoRadioButtonMenuItemUI extends BasicRadioButtonMenuItemUI {
	protected String getPropertyPrefix() { return "RadioButtonMenuItem"; }



	
	/////////////////////////////////////////////////
	//                   Create                    //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	public static ComponentUI createUI( JComponent b ) {
		return new HippoRadioButtonMenuItemUI();
	}




	/////////////////////////////////////////////////
	//                  Install                    //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	protected void installDefaults() {
		super.installDefaults();
	}



	/////////////////////////////////////////////////
	//                 Uninstall                   //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	protected void uninstallDefaults() {
		super.uninstallDefaults();
	}




	/////////////////////////////////////////////////
	//                 Painting                    //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	protected void paintBackground(Graphics g, JMenuItem menuItem, Color bgColor) {
		super.paintBackground( g, menuItem, bgColor );

		paintMenuItemIconBackground( g, menuItem, bgColor );
	}




	/**
	 * 
	 * 
	 */
	private void paintMenuItemIconBackground( Graphics g, JMenuItem aMenuItem, Color bgColor ) {
		Graphics g2 = g.create();
		ButtonModel model = aMenuItem.getModel();

		int menuHeight = aMenuItem.getHeight();
		int menuWidth = aMenuItem.getWidth();

		// Clear background
		g2.setColor( UIManager.getColor( "RadioButtonMenuItem.background" ) );
		g2.fillRect( 0, 0, menuWidth, menuHeight );

		// Draw left gray border
		g2.setColor( javax.swing.UIManager.getColor( "MenuItem.iconBackground" ) );
		g2.fillRect(0, 0, 17, menuHeight);

		// If item is armed( selected ) create thin border around selection!
		if( model.isArmed() ) {
			g2.setColor( bgColor );
			g2.setColor( UIManager.getColor( "RadioButtonMenuItem.selectionBackground" ) );

			g2.fillRect( 1, 1, menuWidth-3, menuHeight-2 );

			g2.setColor( UIManager.getColor( "RadioButtonMenuItem.borderColor" ) );
			g2.drawRect( 1, 1, menuWidth-3, menuHeight-2 );
		}

		g2.dispose();
	}
}
