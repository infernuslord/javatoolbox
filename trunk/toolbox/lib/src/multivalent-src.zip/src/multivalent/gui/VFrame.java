package multivalent.gui;

import java.awt.AWTEvent;
import java.awt.event.MouseEvent;
//import java.awt.event.KeyEvent;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
// not java.awt.EventListener
import java.net.URI;
import java.util.Map;

import phelps.lang.Booleans;

import com.pt.awt.NFont;

import multivalent.*;
import multivalent.EventListener;



/**
	Movable, resizable internal window, with title bar.
	<i>Lens</i> subclasses to add composition of effects via a LensMan(ager).
	The class Note subclasses to add a Document instance.
	Dialog subclasses to add HTML form.

<!--
	<p>LATER: popup for changing pinned status.
	maybe option to turn off apparatus => just use raw Document!
	maybe option to write on JWindow as for menus (but what about subclassing for transparent Lens?)
-->

	@see multivalent.std.lens.Lens

	@version $Revision: 1.4 $ $Date: 2002/05/28 19:50:20 $

<!--
  A VWindow that has a content document as given by a URL, which it automatically sizes to fit.
  For example, content can be HTML page associated with behavior, and include a FORM for setting attributes.
  User closes with close box or perhaps close button provided by client.
  Submit button should send XXX event to close.
-->
<!--
Design decision:
1. extends Behavior
	+ that's Lenses do it (and if switch, would want to ajust lenses to match)

2. extends Document
	+ need way for script as in HTML FORM to close and VSCript has "<doc>"
	A. content paint/event at translations
		- want Document to be plain content, as for last mod's paintAfter
	B. content.y += titleh
		- super.paint() for scrollbars wrong (could adjust but not in spirit of modularity)

3. extends INode (content.y += titleh) -- WINNER
	- scrollbars require Document and everybody to respect that (which usually happens, as that's required in rest of tree)
	+ maybe useful to have plain without scrollbar, as for lens
	X in common case when do want to attach Document that formats according to bounds, have to reach in and set bounds, which isn't in spirit => use calculating size
	need to adjust content by titleh and BORDER
	- lenses need getContentBounds()
-->
*/
public class VFrame extends INode implements EventListener {
  /**
	Announce that Frame has changed size.
	<p><tt>"frameResized"</tt>: <tt>arg=</tt> {@link VFrame} <var>instance</var>.
  */
  public static final String MSG_RESIZED = "frameResized";

  /**
	Announce that Frame has been moved.
	<p><tt>"frameMoved"</tt>: <tt>arg=</tt> {@link VFrame} <var>instance</var>.
  */
  public static final String MSG_MOVED = "frameMoved";

  /**
	Announce that Frame has been closed.
	<p><tt>"frameResized"</tt>: <tt>arg=</tt> {@link VFrame} <var>instance</var>.
  */
  public static final String MSG_CLOSED = "frameClosed";

  /**
	Announce that Frame has raised above all other Frames.
	<p><tt>"frameRaised"</tt>: <tt>arg=</tt> {@link VFrame} <var>instance</var>.
  */
  public static final String MSG_RAISED = "frameRaised";

  /**
	Remove window controls when cursor not in frame?
	<p>Boolean <tt>"vanishingTitle"</tt>
  */
  public static final String PREF_VANISHING = "vanishingTitle";

  /** Minimum dimension for window. */
  public static final int WIDTH_MIN=75, HEIGHT_MIN=40;


  static NFont FONT_TITLE = NFont.getInstance("Dialog"/*"Serif"*/, NFont.WEIGHT_BOLD, NFont.FLAG_SERIF, 12f);
  static int titleh = (int)FONT_TITLE.getHeight() + 2 + 1;


  String title_ = null;

  /** "Pinned" to document (default) or float above. */
  boolean pinned_ = true;

  /** Refers to interactive resizing with mouse, not programmatic control. */
  public boolean resizable = true;

  /**  Show just title bar or full window.	Different than iconify. */
  public boolean lampshade = false;	// should do this with another behavior which hacks in

  /** Display window apparatus only when cursor within window. */
  private boolean in_=true;	// initially on even though cursor not necessarily within, so can see dimensions

  // could make these static as only one at a time
  private Point p0_;
  private Rectangle bbox0_ = new Rectangle();
  private boolean resizelens_ = false;
  private boolean movelens_ = false;
  private boolean metagrab_ = false;	 // grab for contents of window

//	boolean eatevent = false;



  public VFrame(String name,Map<String,Object> attr, INode parent) {
	super(name,attr, parent);
	if (parent!=null && parent==getDocument()) setPinned(pinned_);
	setBounds(100,100, 300,200);
  }

  /** Content given by passed URL; pass null if want to build subtree yourself. */
  public VFrame(String name,Map<String,Object> attr, INode parent, URI docuri) {
	this(name,attr, parent);

	Browser br = getBrowser();
	if (br!=null && docuri!=null) try {
		Document cdoc = new Document("content"/*null?*/,null, this);
		//setTitle("Test");
		DocInfo di = new DocInfo(docuri);
		di.doc = cdoc;
		br.event/*no q*/(new SemanticEvent(br, Document.MSG_OPEN, di));   // no eventq because want result available for immediate hacking
		getDocument().repaint(100);
	} catch (Exception e) {
		System.err.println("can't create document");
		e.printStackTrace();
	}
  }

  /** Bounds of window, with (x,y) relative to containing Document.
  public Rectangle getBounds() {
	Rectangle r = super.getBounds();
	if (lampshade) r.setSize(r.width,titleh+1);
//if (doc!=null) System.out.println("doc="+doc_+", x="+doc_.getHsb().getValue()+", y="+doc_.getVsb().getValue());
//System.out.print(r+" => ");
	Document doc=getDocument();
	if (!pinned_) r.translate(-doc.getHsb().getValue(), -doc.getVsb().getValue());
//System.out.println(" => "+r);
//	if (pir!=null) r.translate(-pir.x,-pir.y);
	return r;
  }
  public Rectangle getContentBounds() {
	Point p = getRelLocation(getDocument());
	return new Rectangle(p.x,p.y, bbox.width,bbox.height-titleh);
  }

 */  // resize, move maybe, but not if all lenses are interactive only

  public String getTitle() {
	if (title_!=null) return title_;
	Node n = getFirstLeaf();
	if (n!=null) return n.getName();
	return "";
  }

  public void setTitle(String title) { title_=title; repaint(100, 0,0, bbox.width,titleh); }

  public void setIn(boolean in) { in_=in; }



  /** Returns new Rectangle sized and positioned to cover content, not title bar. */
  public Rectangle getContentBounds() {
	//Rectangle r = new Rectangle(bbox.x+1,bbox.y+titleh+1, bbox.width-2,bbox.height-titleh-2);
	Rectangle r = new Rectangle(bbox.x,bbox.y+titleh, bbox.width,bbox.height-titleh);
	if (lampshade) r.setSize(0,0);
//	Document doc=getDocument();
//	if (!pinned_) r.translate(-doc.getHsb().getValue(), -doc.getVsb().getValue());
//	if (pir!=null) r.translate(-pir.x,-pir.y);
	return r;
  }


  public boolean isPinned() { return pinned_; }
  /**
	Moves between RELATIVE and ABSOLUTE visual layers on class Document,
	translating coordinates so window appears at same location at present scroll.
  */
  public void setPinned(boolean pinned) {
	//INode p = getParentNode();
	//Document doc = (p!=null? getParentNode().getDocument(): null);
	Document doc = getDocument();
	if (doc!=null) {
		if (pinned_ != pinned) {	// translate coordinates
			int dx=doc.getHsb().getValue(), dy=doc.getVsb().getValue();
			if (pinned) bbox.translate(dx,dy); else bbox.translate(-dx,-dy);
		}

		remove();
		//String vizname = (pinned? "multivalent.node.IRootAbs": "multivalent.node.IRootScreen");
		INode vp = doc.getVisualLayer(pinned? "multivalent.node.IRootAbs": "multivalent.node.IRootScreen");
		vp.appendChild(this);
//vp.dump();

		pinned_=pinned;
		doc.repaint(100);
	}
  }


  /** Windows added on top, so raise to top = remove + add. */
  public void raise() {
	INode p = getParentNode();
	if (p!=null && p.getLastChild()!=this) {
		p.removeChild(this); p.appendChild(this);
//p.dump();
		Browser br=getBrowser(); if (br!=null) br.eventq(MSG_RAISED, this);
		Document doc=getDocument(); if (doc!=null) doc.repaint(100);	// probably done as part of remove/add
	}
//	System.out.println("raise window: "+p);
  }

  /** Identical to setLocation(x,y), setSize(width,height); */
  public void setBounds(int x, int y, int width, int height) {
	setLocation(x,y);
	setSize(width,height);
  }

  /**
	Set dimensions of window, including title bar.
	Should be fast so can interactively resize window.
	Use this instead of setting bbox dimensions directly (should probably enforce all Node bbox manipulation with setSize/setLocation/setBounds).
  */
  public void setSize(int width, int height) {
	if (width!=bbox.width || height!=bbox.height) {
		int maxw=Math.max(bbox.width,width), maxh=Math.max(bbox.height,height);
		bbox.width=Math.max(width,WIDTH_MIN); bbox.height=Math.max(height,HEIGHT_MIN);
		markDirtySubtree(false);
		Browser br=getBrowser(); if (br!=null) br.eventq(MSG_RESIZED, this);
		repaint(100, 0,0, maxw,maxh);	// doesn't have to be quite as fast as moving
//System.out.println("resizing to "+bbox);
	}
  }


  /**
	Should be fast so can interactively move window --
	in the past have minimized amount of redrawing, but at 500MHz Pentium and HotSpot, plenty fast enough to redraw entire document.
  */
  public void setLocation(int x, int y) {
	// bound by (0,0) -- maybe bound by right and bottom edges too
	//int miny=Math.min(bbox.y,y), maxy=Math.max(bbox.y,y);
	bbox.setLocation(Math.max(0,x), Math.max(0,y));
	markDirty();
	Browser br=getBrowser();
	if (br!=null) {
		br.eventq(MSG_MOVED, this); //-- add if needed
		br.repaint(100);
	}
	//Document doc=getDocument(); if (doc!=null) doc.repaint(100); -- not working anymore, for some reason
//System.out.println("VFrame move repaint 100ms @ ("+x+","+y+"), "+w+"x"+h);
  }

  /** Remove window from screen. */
  public void close() {
	Browser br=getBrowser();
	//Document doc = getDocument(); if (doc!=null) br.setCurDocument(doc);
	br.eventq(MSG_CLOSED, this);    // for everybody else
	br.repaint(100);

	remove();	// simple as that!
  }

  //public static final int BORDER=1;
  public boolean formatNode(int width,int height, Context cx) {
	//if (valid_) return !valid_;
	Rectangle r = new Rectangle(bbox);
	boolean ret = super.formatNode(bbox.width/*-BORDER*2*/,bbox.height-titleh/*-BORDER*2*/, cx);
	//bbox.add(0,0);
	int miny=Integer.MAX_VALUE; for (int i=0,imax=size(); i<imax; i++) miny = Math.min(miny, childAt(i).bbox.y);
	int dy = titleh-miny; for (int i=0,imax=size(); i<imax; i++) childAt(i).bbox.y += dy;
	bbox.setBounds(r);	// contents have no effect on bounds
	return ret;
  }



  /*
   * PAINT
   */

  /**
	Draw content, then window apparatus (title bar, resize nib).
	LATER: take colors for window apparatus from style sheet.
  */
  public void paintNode(Rectangle docclip, Context cx) {
//System.out.println("bbox="+bbox+", docclip="+docclip);
	// first paint contents
	if (!lampshade) super.paintNode(docclip, cx);

	if (!in_ && !lampshade) return;

	// then draw window apparatus on top
	Graphics2D g = cx.g;
//System.out.println("bg="+cx.background);
	//g.setColor(Color.BLACK);
	//g.draw3DRect(0,0, bbox.width-1,lampshade?titleh:bbox.height-1, true);  // -- client decides about box around body

	// title bar: title, bars
	int xx = bbox.width - 28 - 1;
	g.setColor(Color.LIGHT_GRAY);
	g.fill3DRect(0,0, bbox.width-1,titleh, true);
	g.setColor(Color.BLACK);
	g.drawRect(0,0, bbox.width-1,titleh);

	String title = getTitle();
	int titlew = (int)FONT_TITLE.stringAdvance(title).getX();
	//int titlew=10;//compile hack
	FONT_TITLE.drawString(g, getTitle(), 5, (float)FONT_TITLE.getAscent() + 2);
	for (int i=0; i<titleh; i+=6) g.drawLine(titlew+7,i, xx-2,i);

	// close box
	g.setColor(Color.LIGHT_GRAY);
	g.fillRect(bbox.width-14-1,2, 14,titleh-4);
	g.setColor(Color.BLACK);
	g.drawRect(bbox.width-12-1,(titleh-10)/2, 10,10);

	// lampshade
	g.setColor(Color.LIGHT_GRAY);
	g.fillRect(xx,2, 14,titleh-4);
	g.setColor(Color.BLACK);
	g.drawRect(xx+2,(titleh-10)/2, 10,10);
	g.drawRect(xx+2,(titleh-10)/2+4, 10,2);

	// resize region
	if (resizable && !lampshade) {
		int bx=bbox.width-2, by=bbox.height-2;
		g.setColor(Color.BLACK);
		g.drawLine(bx-10,by, bx,by-10);
		g.drawLine(bx-5,by, bx,by-5);
	}
  }


  /*
   * EVENTS
   */
//	public boolean event(AWTEvent e, Point scrn) {	eventBefore(e, rel); return eventAfter(e, rel); }

  public boolean eventBeforeAfter(AWTEvent e, Point rel) {
	int eid=e.getID();
	if (eid==MouseEvent.MOUSE_ENTERED) { in_=true; repaint(100); /*System.out.println("* in VFrame "+getName());*/}
	else if (eid==MouseEvent.MOUSE_EXITED && Booleans.parseBoolean(getGlobal().getPreference(PREF_VANISHING, "true"), true)) { in_=false; repaint(1000); /*System.out.println("* out VFrame "+getName());*/}

/*System.out.print("ev in "+getName()+", curnode="+getBrowser().getCurNode()+" => ");
boolean ret= super.eventBeforeAfter(e, rel);
System.out.println(getBrowser().getCurNode()+" "+(getBrowser().getCurNode()==this));
return ret;*/
	return super.eventBeforeAfter(e, rel);
  }

  /*
	@return true if ate event in window moving or resizing, false if in content area and available to subclass.
  */
//	public boolean eventBefore(AWTEvent e, Point rel) {
  public boolean eventNode(AWTEvent e, Point rel) {
//System.out.println("in VFrame "+rel);
	Browser br = getBrowser();
	int eid = e.getID();
//	  Document doc = getDocument();
	//int ex = e.x-(pinned_?0:doc.getHsb().getValue()), ey = e.y-(pinned_?0:doc.getVsb().getValue());
//	int ex = rel.x-(pinned_?0:br.xoff), ey = rel.y-(pinned_?0:br.yoff);
	//Point scrnpt = br.getCurScrn();	// everything in screen coordinates: mouse event, lens coordinates
	//int ex=scrnpt.x, ey=scrnpt.y;
	//int idx=0, idy=0; if (pir_!=null) { idx=pir_.x; idy=pir_.y; }
	//int ex=rel.x-idx, ey=rel.y-idy;

	//boolean eat = metagrab_ || eid==KeyEvent.KEY_PRESSED || eid==KeyEvent.KEY_RELEASED || bbox.contains(ex, ey);
//System.out.println("eventNode in VFrame, eid="+eid+", eat="+eat);
	//if (!eat) return false;
	//if (!metagrab_ && eid!=KeyEvent.KEY_PRESSED && eid!=KeyEvent.KEY_RELEASED && !bbox.contains(ex, ey)) return /*(eatevent=*/ false/*)*/;
	//if (eid==MouseEvent.MOUSE_PRESSED /*|| eid==MouseEvent.MOUSE_MOVED--need to know when leave lens*/) {
	if (eid==MouseEvent.MOUSE_PRESSED && (((MouseEvent)e).getModifiers() & MouseEvent.BUTTON1_MASK) !=0) {
		int ex=rel.x, ey=rel.y;

		/*if (ey < titleh && (((MouseEvent)e).getModifiers() & MouseEvent.BUTTON3_MASK) !=0) {
		//if (ey < titleh && (((MouseEvent)e).getModifiers() & MouseEvent.BUTTON3_MASK) !=0) {
			// not so great.  maybe have pulldowns or something
			//br.eventq(new SemanticEvent(br, DocumentPopup.MSG_CREATE_DOCPOPUP, null, this, null));
			//return false;
			return true;
		}*/

		// temporarily handle close box on mouse down
		if (ey < titleh) {
			metagrab_ = true;	// don't let BindingsDefault grab mouse clicks!
			//int ex=-1;
			if (ex>bbox.width-15) {	 // close box
				close();

			} else if (ex>bbox.width-26) {
				lampshade = !lampshade;
				repaint(100);

			} else movelens_=true;

		} else if (lampshade) return true;

		//movelens_ = (ey<titleh);
		resizelens_ = (resizable && ex>bbox.width-10 && ey>bbox.height-10);

/*	} else if (eid==MouseEvent.MOUSE_PRESSED && (((MouseEvent)e).getModifiers() & MouseEvent.BUTTON3_MASK) !=0) {
System.out.println("b3");
		br.eventq(new SemanticEvent(br, DocumentPopup.MSG_CREATE_DOCPOPUP, null, this, null));
		return true;*/
	}
//MouseEvent me = (MouseEvent)e;
//System.out.println("button "+me.getModifiers()+" / "+MouseEvent.BUTTON3_MASK);

	if (metagrab_ || movelens_ || resizelens_) {
		p0_ = br.getCurScrn();
		bbox0_.setBounds(bbox);
		if (movelens_ && MouseEvent.MOUSE_FIRST<=eid && eid<=MouseEvent.MOUSE_LAST && !((MouseEvent)e).isAltDown()) raise();	// alt-click moves without raising to top

		br.setCurNode(this,0);  // so titlebar doesn't disappear when drag
		br.setGrab(this);	// doesn't work for lenses, which happen to work for different reasons
//System.out.println("grab = "+br.getGrab());
		//return true;	// no bleed through!

	} else {
//System.out.println("VFrame=>INode @ "+rel);
		//!boolean ret = super.eventNode(e, rel);
		//in_ = true;     // don't lose to content
		//return ret || (size()>0 && childAt(0).bbox.contains(rel)); //=> get mouse_exit when hit on leaf
		//!return true;
		/*return*/ super.eventNode(e, rel);
	}

	return true;	// no bleed through! (handles title bar here)
  }

  /** Handle events while moving, resizing, .... */
  public void event(AWTEvent e) {
  //public boolean event(AWTEvent e, Point scrn) {
	//return eventBeforeAfter(e, rel);
	int eid=e.getID();
	Browser br = getBrowser();
	if (eid==MouseEvent.MOUSE_DRAGGED) {
		Point cpt = br.getCurScrn();
		int dx=cpt.x-p0_.x, dy=cpt.y-p0_.y;
		int adx=Math.abs(dx), ady=Math.abs(dy);
		//x0=ex; y0=ey; // reset base (x,y)
		// if overwhelmingly horizontal or vertical, make entirely so can get sharper clip regions
		if (/*adx>3*ady || (*/adx>10 && ady<=5/*)*/) dy = 0;
		else if (/*ady>3*adx || (*/adx<=5 && ady>10/*)*/) dx = 0;

		if (resizelens_) setSize(bbox0_.width+dx, bbox0_.height+dy);
		else if (movelens_) setLocation(bbox0_.x+dx, bbox0_.y+dy);

	} else if (eid==MouseEvent.MOUSE_RELEASED) {
//			  if (movelens_) { br.endDrag(); repaint(); } //bbox.x-br.xoff,bbox.y-br.yoff, bbox.width,bbox.height);
		//if (movelens_ && ex>bbox.x+bbox.width-15) {	 // close box

		movelens_ = resizelens_ = false;
		br.releaseGrab(this);
//System.out.println("releasing grab = "+br.getGrab());
		metagrab_ = false;
	}

//	return true;
  }
}
