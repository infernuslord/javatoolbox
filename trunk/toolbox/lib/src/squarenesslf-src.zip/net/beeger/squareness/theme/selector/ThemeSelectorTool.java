package net.beeger.squareness.theme.selector;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ListModel;
import javax.swing.DefaultListModel;

/**
 * Created by IntelliJ IDEA.
 * User: rbeeger
 * Date: 28.03.2005
 * Time: 19:59:15
 * To change this template use File | Settings | File Templates.
 */
public class ThemeSelectorTool
{
  public void start()
  {
    _gui = new ThemeSelectorGUI();
    _model = new DefaultListModel();
    _gui.getThemeList().setModel(_model);
    _gui.getSelect().addActionListener(new ActionListener()
    {
      public void actionPerformed (ActionEvent e)
      {
        selectCurrentTheme();
      }

    });

  }

  private void selectCurrentTheme ()
  {
    _gui.getThemeList().getSelectedValue();
  }


  private DefaultListModel _model;
  private ThemeSelectorGUI _gui;
}
