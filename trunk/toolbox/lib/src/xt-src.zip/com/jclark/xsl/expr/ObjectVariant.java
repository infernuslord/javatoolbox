// $Id: ObjectVariant.java,v 1.1 2002/04/25 18:10:23 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

class ObjectVariant extends VariantBase 
{
    private final Object obj;

    ObjectVariant(Object obj)
    {
        this.obj = obj;
    }

    public Object convertToObject() 
    {
        return obj;
    }

    public String convertToString() 
    {
        if (obj == null) {
            return "";
	}
        return obj.toString();
    }

    public boolean convertToBoolean() 
    {
        return obj != null;
    }
}
