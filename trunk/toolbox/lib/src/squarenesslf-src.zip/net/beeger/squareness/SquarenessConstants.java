/*
  Copyright (C) 2003-2004 Robert F. Beeger (robert at beeger dot net)
  Licensed under the Academic Free License version 2.1
  OSI Certified Open Source Software

  Visit http://squareness.sourceforge.net/ for new releases of Squareness Look And Feel and other
  skins from the Squareness series.
*/
package net.beeger.squareness;

/**
 * <p>This class contains all the constants used in this Look And Feel.</p>
 */
public final class SquarenessConstants
{
  //
  // public interface
  //

  public static final String SCROLLBAR_THUMB_PRESSED_CLIENT_PROPERTY_KEY = "SquarenessScrollBarThumbPressed";
  public static final String SCROLLBAR_TRACK_PRESSED_CLIENT_PROPERTY_KEY = "SquarenessScrollBarTrackPressed";

  public static final String SCROLL_ARROW_LEFT_KEY = "scrollArrowLeft";
  public static final String SCROLL_ARROW_RIGHT_KEY = "scrollArrowRight";
  public static final String SCROLL_ARROW_UP_KEY = "scrollArrowUp";
  public static final String SCROLL_ARROW_DOWN_KEY = "scrollArrowDown";
  public static final String SPIN_UP_KEY = "spinUp";
  public static final String SPIN_DOWN_KEY = "spinDown";

  public static final String ROLLOVER_CLENT_PROPERTY_KEY = "SquarenessRollover";
  public static final String CHECKED_FOR_JEDIT_ROLLOVER ="SquarenessCheckedJEDITROLLOVER";

  private SquarenessConstants ()
  {
  }
}

/*
  $Log: SquarenessConstants.java,v $
  Revision 1.10  2004/09/18 17:30:48  rbeeger
  * Updated copyright block and license file. Squareness Look And Feel is now licensed under Academic Free License 2.1
  * Added themepack.

  Revision 1.9  2004/08/29 17:14:35  rbeeger
  * Started developing theming support

  Revision 1.8  2004/03/08 17:21:05  rbeeger
  Added pressed scrollbar track effect.

  Revision 1.7  2004/03/04 19:01:40  rbeeger
  Simplyfied scroll bar ui delegate code.
  Began work on pressed scroll bar track painting.

  Revision 1.6  2004/03/03 19:55:50  rbeeger
  Added special handling of jEdit RolloverButtons

  Revision 1.5  2004/02/14 19:12:35  rbeeger
  Updated copyright statement
  Added cvs log directive at the end of each file
  Optimized imports
  Reformated code

 */
