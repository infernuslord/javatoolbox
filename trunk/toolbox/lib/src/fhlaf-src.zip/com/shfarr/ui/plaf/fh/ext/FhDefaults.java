/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh.ext;

import java.awt.*;
import java.util.*;
import javax.swing.*;

import com.shfarr.ui.plaf.fh.textures.*;
import com.shfarr.ui.plaf.fh.theme.*;


public class FhDefaults{
	public static final int CHECK_BOX_CHECKER = 106;
	public static final int RADIO_BUTTON_UNFOCUSED = 107;
	public static final int RADIO_BUTTON_CHECKER = 108;
	public static final int RADIO_BUTTON_MENU_ITEM = 109;
	public static final int RADIO_BUTTON_MENU_ITEM_CHECKER = 110;


    public static Theme getTheme(){
        return ThemeManager.instance().getCurrentTheme();
    }
    
    
    public static ColorPalette getColorPalette(){
        return getTheme().colorPalette();
    }


	public static void paintTouch(Component c, Graphics g, int x, int y, int w, int h){
	  g.setColor(ThemeManager.instance().getCurrentTheme().getColor("highlight"));

	  g.fillRect(x, y, w, h);
      
	  UIManager.getDefaults().getBorder("Touch.border").paintBorder(c, g, x, y, w, h);
	}

	
	
	public static Texture getTextureFor(JComponent cmp){
	  try{
		  return (Texture)UIManager.getDefaults().get(cmp.getUIClassID().substring(0, cmp.getUIClassID().length() -2) + ".texture");
	  }
	  catch(Exception e){
	        System.out.println("Texture for: " + cmp.getUIClassID().substring(0, cmp.getUIClassID().length() -2));
	        return null;
	  }
	}
    
	public static int getTextType(String text){
	  try{
	      StringTokenizer affst = new java.util.StringTokenizer(UIManager.getDefaults().get("Affirmatives").toString(), ";, ", false);
	      while(affst.hasMoreTokens()) if(affst.nextToken().equalsIgnoreCase(text)) return 1;
	
	      StringTokenizer negst = new java.util.StringTokenizer(UIManager.getDefaults().get("Negatives").toString(), ";, ", false);
	      while(negst.hasMoreTokens()) if(negst.nextToken().equalsIgnoreCase(text)) return -1;
	  }
	  catch(Exception e){
		    return 0;
	  }
	
	  return 0;
	}
	
	public static int[][] pickMatrix(int type){
	  int[][] matrix = {{0}};
	
	  if(Math.abs(type)==CHECK_BOX_CHECKER){
		 matrix = new int[][]{{-9, -9,  0,  0,  0, -9, -9},
			                  {-9, -9, -9,  0, -9, -9, -9},
			                  { 0, -9, -9, -9, -9, -9,  0},
			                  { 0,  0, -9, -9, -9,  0,  0},
			                  { 0, -9, -9, -9, -9, -9,  0},
			                  {-9, -9, -9,  0, -9, -9, -9},
			                  {-9, -9,  0,  0,  0, -9, -9}
		                      };
	  }
	
	  if(Math.abs(type)==RADIO_BUTTON_UNFOCUSED){
	     matrix = new int[][]{{0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0},
	                          {0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0},
	                          {0,  0,  0,  0,  0,  4, -1, -9, -9, -9, -5,  6,  0,  0,  0,  0,  0,  0},
	                          {0,  0,  0,  0, -9, -9,  0,  0,  0,  0,  0, -1, -1,  9,  0,  0,  0,  0},
	                          {0,  0,  0, -9,  0,  0,  0,  0,  0,  0,  0,  0,  6, -1,  9,  0,  0,  0},
	                          {0,  0,  3, -9,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,  9,  6,  0,  0},
	                          {0,  0, -5,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  6,  3,  6,  0,  0},
	                          {0,  0, -9,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,  9,  0,  0},
	                          {0,  0, -9,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,  9,  0,  0},
	                          {0,  0, -5,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,  9,  0,  0},
	                          {0,  0, -1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  6, -1,  9,  0,  0},
	                          {0,  0,  3, -1,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,  9,  0,  0,  0},
	                          {0,  0,  0, -1,  6,  0,  0,  0,  0,  0,  0,  0,  6, -1,  9,  0,  0,  0},
	                          {0,  0,  0,  9, -1, -1,  6,  0,  0,  0,  6, -1, -1,  9,  0,  0,  0,  0},
	                          {0,  0,  0,  0,  9,  9,  3, -1, -1, -1, -1,  9,  9,  6,  0,  0,  0,  0},
	                          {0,  0,  0,  0,  0,  6,  6,  9,  9,  9,  9,  6,  0,  0,  0,  0,  0,  0},
	                          {0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0},
	                          {0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0},
	                          };
	  }
	  
	  if(Math.abs(type)==RADIO_BUTTON_CHECKER){
	     matrix = new int[][]{{ 0,  4, -1, -9, -5,  4,  0},
	                          { 4, -9, -9, -9, -9, -9,  4},
	                          {-1, -9,  0,  0, -9, -9, -1},
	                          {-9, -9,  0, -9, -9, -9, -9},
	                          {-1, -9, -9, -9, -9, -9, -1},
	                          { 4, -9, -9, -9, -9, -9,  4},
	                          { 0,  4, -1, -9, -1,  4,  0}
	                          };
	  }
	
	  if(Math.abs(type)==RADIO_BUTTON_MENU_ITEM){
	     matrix = new int[][]{{ 0,  0,  0,  4, -9, -9, -9, -5,  6,  0,  0,  0,  0},
	                          { 0,  0, -9, -9,  0,  0,  0,  0, -1, -1,  9,  0,  0},
	                          { 0, -9,  0,  0,  0,  0,  0,  0,  0,  6, -1,  9,  0},
	                          { 3, -9,  0,  0,  0,  0,  0,  0,  0,  0, -1,  9,  6},
	                          {-9,  0,  0,  0,  0,  0,  0,  0,  0,  0,  6,  3,  6},
	                          {-9,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,  9},
	                          {-9,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,  9},
	                          {-5,  0,  0,  0,  0,  0,  0,  0,  0,  0,  6, -1,  9},
	                          { 3, -1,  0,  0,  0,  0,  0,  0,  0,  0, -1,  9,  0},
	                          { 0, -1,  6,  0,  0,  0,  0,  0,  0,  6, -1,  9,  0},
	                          { 0,  9, -1, -1,  6,  0,  0,  6, -1, -1,  9,  0,  0},
	                          { 0,  0,  9,  9,  3, -1, -1, -1,  9,  9,  6,  0,  0},
	                          { 0,  0,  0,  6,  6,  9,  9,  9,  6,  0,  0,  0,  0}
	                          };
	  }
	  
	  if(Math.abs(type)==RADIO_BUTTON_MENU_ITEM_CHECKER){
	     matrix = new int[][]{{ 0,  4, -9, -5,  4,  0},
	                          { 4, -9, -9, -9, -9,  4},
	                          {-1, -9,  0, -9, -9, -1},
	                          {-1, -9, -9, -9, -9, -1},
	                          { 4, -9, -9, -9, -9,  4},
	                          { 0,  4, -9, -1,  4,  0}
	                          };
	  }
	
	  return matrix;
	}
}
