/*
 * Created on May 11, 2004
 */
package test.edu.uci.ics.jung.graph.impl;

import junit.framework.TestCase;


/**
 * Dummy class just provides methods that force, force I say garbage
 * collection. Which is tough with java.
 * from http://www.javaworld.com/javatips/jw-javatip130_p.html
 * @author danyelf
 */
public class ForceGC extends TestCase {


    /**
     *  
     */
    public static void gc() throws Exception {
        // It helps to call Runtime.gc()
        // using several method calls:
        for (int r = 0; r < 4; ++r)
            _runGC();
    }

    private static void _runGC() throws Exception {
        long usedMem1 = usedMemory(), usedMem2 = Long.MAX_VALUE;
        for (int i = 0; (usedMem1 < usedMem2) && (i < 500); ++i) {
            s_runtime.runFinalization();
            s_runtime.gc();
            Thread.currentThread().yield();

            usedMem2 = usedMem1;
            usedMem1 = usedMemory();
        }
    }

    private static long usedMemory() {
        return s_runtime.totalMemory() - s_runtime.freeMemory();
    }

    private static final Runtime s_runtime = Runtime.getRuntime(); // TODO

    
}
