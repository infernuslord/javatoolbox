/*
 * Created on Feb 2, 2005
 *
 */
package edu.uci.ics.jung.visualization.contrib;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

import javax.swing.JPanel;
import javax.swing.JScrollBar;

import edu.uci.ics.jung.visualization.GraphDraw;
import edu.uci.ics.jung.visualization.VisualizationViewer;


/**
 * GraphZoomScrollPane is a Container for the Graph
 * and includes custom horizontal and vertical scrollbars.
 * The scrollbars are modified so that they will allow panning
 * of the graph when the scale has been changed (e.g. zoomed-in
 * or zoomed-out).
 * samples.graph.GraphZoomScrollPane shows the use of this component.
 * 
 * @author Tom Nelson - RABA Technologies
 *
 * 
 */
public class GraphZoomScrollPane extends JPanel {
    private GraphDraw gd;
    private JScrollBar hsb;
    private JScrollBar vsb;
    
    /**
     * create the container for the graph along with 
     * two scrollbars to move the zoomed graph around.
     * The scrollbars have been customized to work with
     * the VisualizationViewer's zoom function.
     * @param gd for the Graph to display
     */
    public GraphZoomScrollPane(GraphDraw gd) {
        super(new BorderLayout());
        this.gd = gd;
        addComponentListener(new ResizeListener());        
        Dimension d = gd.getGraphLayout().getCurrentSize();
        vsb = new JScrollBar(JScrollBar.VERTICAL, 0, d.height, 0, d.height);
        hsb = new JScrollBar(JScrollBar.HORIZONTAL, 0, d.width, 0, d.width);
        vsb.addAdjustmentListener(new AdjustmentListenerImpl());
        hsb.addAdjustmentListener(new AdjustmentListenerImpl());
        add(gd);
        add(vsb, BorderLayout.EAST);
        add(hsb, BorderLayout.SOUTH);
    }
    
    /**
     * listen for adjustments of either scrollbar to change
     * the offset of the VisualizationViewer
     *
     */
    class AdjustmentListenerImpl implements AdjustmentListener {
        public void adjustmentValueChanged(AdjustmentEvent e) {
            int hmax = hsb.getMaximum();
            int vmax = vsb.getMaximum();
            gd.getVisualizationViewer().setOffset((double)hsb.getValue()/hmax,
                    (double)vsb.getValue()/vmax);
            gd.repaint();
        }
    }
    
    /**
     * proportionally zoom the graph by amout
     * For example '2.0' doubles the size, 0.5 halves
     * the size of the graph
     * @param amount
     */
    public void zoom(double hamount, double vamount) {
        VisualizationViewer vv = gd.getVisualizationViewer();
        double hmax = hsb.getMaximum()*hamount;
        double vmax = vsb.getMaximum()*vamount;
        // get the previous scale values and
        // change them by the passed amounts
        vv.setScale(vv.getScaleX()*hamount, vv.getScaleY()*vamount);
        Dimension d = gd.getGraphLayout().getCurrentSize();
        int xextent = d.width;
        int yextent = d.height;
        int xval = (int)((hmax-xextent)/2);
        int yval = (int)((vmax-yextent)/2);
        hsb.setValues(xval,xextent,0,(int)hmax);
        vsb.setValues(yval,yextent,0,(int)vmax);
    }
    
	protected class ResizeListener extends ComponentAdapter {

		public void componentHidden(ComponentEvent e) {
		}

		public void componentResized(ComponentEvent e) {
		    Rectangle b = ((Component)e.getSource()).getBounds();
		    hsb.setMaximum((int)(b.width*gd.getVisualizationViewer().getScaleX()));
		    vsb.setMaximum((int)(b.height*gd.getVisualizationViewer().getScaleY()));
		    hsb.setVisibleAmount(b.width);
		    vsb.setVisibleAmount(b.height);
		}	
		public void componentShown(ComponentEvent e) {
		}
	}
}
