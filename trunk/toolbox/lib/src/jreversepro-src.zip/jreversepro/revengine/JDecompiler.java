/**
  * @(#)JDecompiler.java
  *
  * JReversePro - Java Decompiler / Disassembler.
  * Copyright (C) 2000 2001 Karthik Kumar.
  * EMail: akkumar@users.sourceforge.net
  *
  * This program is free software; you can redistribute it and/or modify
  * it , under the terms of the GNU General Public License as published
  * by the Free Software Foundation; either version 2 of the License,
  * or (at your option) any later version.
  *
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  * See the GNU General Public License for more details.
  * You should have received a copy of the GNU General Public License
  * along with this program.If not, write to
  *  The Free Software Foundation, Inc.,
  *  59 Temple Place - Suite 330,
  *  Boston, MA 02111-1307, USA.
  **/

package jreversepro.revengine;


import jreversepro.parser.ClassParserException;
import java.io.IOException;

import jreversepro.reflect.JMethod;
import jreversepro.reflect.JConstantPool;
import jreversepro.reflect.JException;
import jreversepro.reflect.JInstruction;
import jreversepro.reflect.JImport;

import jreversepro.runtime.JSymbolTable;

import jreversepro.common.JJvmOpcodes;

import jreversepro.common.Helper;
import jreversepro.common.KeyWords;

import jreversepro.runtime.JRunTimeFrame;
import jreversepro.runtime.JOperandStack;

import jreversepro.runtime.JRunTimeContext;
import jreversepro.runtime.Operand;
import jreversepro.runtime.OperandConstants;
import jreversepro.runtime.JCodeBuffer;

import java.util.Vector;
import java.util.ListIterator;
import java.util.Stack;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Map;
import java.util.HashMap;

/**
 * This decompiles the source code.
 * @author Karthik Kumar
 * @version 1.3
 **/
public class JDecompiler
    implements BranchConstants,
               KeyWords,
               JReverseEngineer,
               JJvmOpcodes,
               OperandConstants {

    List           ByteIns;

    JConstantPool  CpInfo;
    JMethod        CurMethod;
    JSymbolTable   symTable;
    JBranchTable   Branches;
    static JImport importInfo;

    Map            mapCatchJExceptions;

    int lastIns = 0;
    /**
     * JDecompiler constructor.
     **/
    public JDecompiler(JMethod rhsMethod,
                       JConstantPool rhsCpInfo) {

        this.importInfo = rhsCpInfo.getImportedClasses();
        CurMethod = rhsMethod;
        CpInfo =  rhsCpInfo;
        symTable  = new JSymbolTable( rhsMethod, importInfo );
        Branches = new JBranchTable();

        ByteIns = rhsMethod.getInstructions();
        mapCatchJExceptions = rhsMethod.getAllCatchJExceptions();
    }

    /**
     * Finalizer of the class.
     **/
    protected void finalize() {
        Branches = null;
    }

    public JSymbolTable getSymbolTable() {
        return symTable;
    }

    /**
      * Don't depend on LineNumberTable Attribute of a method,
      * as it is optional. Available only if compiled with
      * debugging options on. ( -g ).
      **/
    public StringBuffer genCode()
                throws RevEngineException,
                        IOException {

        StringBuffer result =  new StringBuffer();
        Map mapGotos = loadSymbolTable();
        result.append( getMethodHeaders(CurMethod,
                                symTable) );

        if ( ByteIns.size() == 0 ) {
            //Indicates either an abstract class or an interface.
            result.append(";");
        } else {
            result.append(" {");
            if (Helper.isDebug()) {
                result.append(CurMethod.getLocalStackInfo());
            }

            try {
                Branches.setGotoTable( mapGotos );

                //Start decompiling code.
                JCollatingTable collatter = loadBranchTable();
                collatter.identifyWhileLoops(mapGotos);
                collatter.collate();

                Branches.setTables(collatter.getEffectiveBranches());

                Branches.setEndTryCatch(ByteIns);
                Branches.identifyMoreBranches();

                Branches.sort();
                Helper.log( Branches + "" );

                result.append( genSource() );
                //End Decompile
            } catch ( Exception ex ) {
                result.append(DECOMPILE_FAILED_MSG);
                ex.printStackTrace();
            }
            result.append("\n\t}");
        }
        return result;
    }


    /**
     * Loads the Local Symbol Table information.
     **/
    public Map loadSymbolTable()
            throws RevEngineException {
        Map mapGotos =  new HashMap();
        if ( ByteIns != null ) {
            Helper.log("Loading Symbol Table **********");

            JRunTimeFrame rtf =
                new JRunTimeFrame(CpInfo, symTable,
                    CurMethod.getReturnType());

            JOperandStack jos = new JOperandStack();

            for ( int i = 0 ; i < ByteIns.size(); i++ ) {
                JInstruction Ins = ( JInstruction ) ByteIns.get(i);
                int VarIndex = Ins.isStoreInstruction();
                String ExcDataType = (String)
                            mapCatchJExceptions.get(
                                    new Integer(Ins.index) );
                if ( ExcDataType != null ) {
                    symTable.assignDataType(
                      VarIndex, ExcDataType,
                            Ins.index, true);

                    jos.push(FOREIGN_OBJ, FOREIGN_CLASS, VALUE);

                } else {
                    if (Branches.isJSRTarget(Ins.index)) {
                        jos.push(FOREIGN_OBJ, FOREIGN_CLASS, VALUE);
                    }
                    if ( VarIndex != JInstruction.INVALID_VAR_INDEX ) {
                        //Save the local variable index.
                        symTable.assignDataType(
                            VarIndex,
                            jos.topDatatype(),
                            Ins.index,false);
                    }
                }
                rtf.operateStack ( Ins, jos );

                //Add a referenced count of line numbers
                int referredVar = Ins.referredVariable();
                if ( referredVar != JInstruction.INVALID_VAR_INDEX ) {
                    Helper.log( Ins.toString() + "  " + Ins.referredVariable() );
                    symTable.addReference(referredVar,
                                        jos.topDatatype(),
                                        Ins.index );
                }

                if ( Ins.opcode == OPCODE_INVOKEINTERFACE ) {
                    symTable.touchVariable(
                                    rtf.getInvokedObject().getValue(),
                                    rtf.getInvokedObject().getDatatype() );
                } else if (Ins.opcode == OPCODE_GOTO) {
                    mapGotos.put( new Integer(Ins.index),
                                new Integer(Ins.getTargetPc()) );
                } else if ( Ins.opcode == OPCODE_JSR ) {
                    Branches.addJSRPc( Ins.getTargetPc() );
                } else if ( Ins.opcode == OPCODE_RET ) {
                    Branches.addRetPc( Ins.getNextIndex() );
                } else if ( Ins.opcode == OPCODE_GOTOW ) {
                    mapGotos.put( new Integer(Ins.index),
                                    new Integer(Ins.getTargetPcW()) );
                } else if ( Ins.opcode == OPCODE_JSRW ) {
                    Branches.addJSRPc( Ins.getTargetPcW() );
                }
            }
            jos = null;
            rtf = null;
            Helper.log("Loaded Symbol Table **********");
            Helper.log(symTable.toString());
        }
        return mapGotos;
    }

    /**
     * Loads the Branch Table for a given method.
     **/
    private JCollatingTable loadBranchTable()
        throws RevEngineException,
                IOException {
        Helper.log("Loading Branch Table **********");
        JRunTimeFrame rtf =
                new JRunTimeFrame( CpInfo, symTable,
                            CurMethod.getReturnType());

        JOperandStack jos = new JOperandStack();
        JCollatingTable collatter =
                    new JCollatingTable();

        int PrevCode = 0;
        boolean EolFlag = false;
        for ( int i = 0 ; i < ByteIns.size() ; i++ ) {
            JInstruction ThisIns = ( JInstruction ) ByteIns.get(i);
            if(EolFlag) {
                PrevCode = ThisIns.index;
                EolFlag = false;
            }
            int InsIndex = ThisIns.index;
            String exc = (String)mapCatchJExceptions.get(new Integer(InsIndex));
            if( exc != null ) {
                // push exception on the operand stack for catch
                jos.push(FOREIGN_OBJ, FOREIGN_CLASS, VALUE);
                // add catch or catch (any) branch to branch table
                int storeIndex = ThisIns.isStoreInstruction();
                String varName = symTable.getName(storeIndex, InsIndex);
                String className = exc;
                if (exc.equals(ANY)) {
                    Branches.add( new JBranchEntry(InsIndex, InsIndex, -1, TYPE_CATCH_ANY, className, varName, ""));
                } else {
                    className = importInfo.getClassName(Helper.getJavaDataType(symTable.getDataType(storeIndex, InsIndex), false));
                    Branches.add( new JBranchEntry(InsIndex, InsIndex, -1, TYPE_CATCH, className, varName, ""));
                }
                EolFlag = true;
            } else if (Branches.isJSRTarget(ThisIns.index)) {
                // push exception on the operand stack for JSR
                jos.push(FOREIGN_OBJ, FOREIGN_CLASS, VALUE);
                EolFlag = true;
            }

            if ( ThisIns.opcode == OPCODE_TABLESWITCH ||
                 ThisIns.opcode == OPCODE_LOOKUPSWITCH ) {
                Branches.addSwitch(
                     new JSwitchTable(ThisIns, (Operand)jos.peek()));
                EolFlag = true;
            }
            try {
                rtf.operateStack(ThisIns,jos);
            }
            catch ( Exception ex ) {
                   throw new RevEngineException( "Error processing " +
                    " instruction " + ThisIns.toString(), ex );
            }
            if( ThisIns.isAnIfIns() ) {
                if( ThisIns.index > ThisIns.getTargetPc() ) {

                    collatter.addConditionalBranch(
                        ThisIns, PrevCode,
                        TYPE_WHILE,
                        rtf.getOpr1() ,
                        rtf.getOpr2() );
                } else {
                    collatter.addConditionalBranch(
                        ThisIns, PrevCode,
                        TYPE_IF,rtf.getOpr1() ,
                        rtf.getOpr2() );
                }
                EolFlag = true;
            } else if ( ThisIns.opcode == OPCODE_MONITORENTER ) {
                Branches.addMonitorPc ( ThisIns.index,
                            rtf.getStatement() );
                EolFlag = true;
            } else {
                EolFlag |= ThisIns.isEndOfLine() ||
                        ( ThisIns.isInvokeIns()  &&  jos.empty() ) ||
                        ThisIns.opcode == OPCODE_GOTO ||
                        ThisIns.opcode == OPCODE_GOTOW ||
                        ThisIns.opcode == OPCODE_JSR ||
                        ThisIns.opcode == OPCODE_JSRW ||
                        ThisIns.opcode == OPCODE_RET;
            }
        }

        // add try or try (any) branch to branch table
        Branches.addTryBlocks(CurMethod.getexceptionBlocks());

        rtf = null;
        jos = null;
        Helper.log("Loaded branch Table **********");
        return collatter;
    }


    private JRunTimeContext createRuntimeContext() {
        JRunTimeFrame rtf =
                new JRunTimeFrame(CpInfo, symTable,
                    CurMethod.getReturnType());
        JOperandStack jos = new JOperandStack();

        List restrict = new Vector();
        if( CurMethod.getName().compareTo(INIT) == 0 ||
            CurMethod.getName().compareTo(CLINIT) == 0  ) {
            restrict.add(RETURN);
        }
        JCodeBuffer code = new JCodeBuffer(restrict);

        JRunTimeContext context = new JRunTimeContext(
                        rtf,
                        jos,
                        code,
                        Branches );
        return context;
    }

    /**
     * Generates the source code for the given method.
     * @return Generates the source code for the given method.
     **/
    private StringBuffer genSource()
                       throws RevEngineException {

        Helper.log("Generating code ..............");
        JRunTimeContext context =  createRuntimeContext();
        ListIterator li = ByteIns.listIterator();

        while( li.hasNext() ) {
            JInstruction Ins = (JInstruction)li.next();

            getControlBeginStmt( context, Ins );
            processJVMInstruction( Ins, context );
            getControlEndStmt( context, Ins );
        }

        context.getFinalBlockStmt();
        Helper.log("Generated code ..............");
        return context.getCodeBuffer().getCode();
    }


    /**
     * Process a single instruction.
     **/
    private void processJVMInstruction(JInstruction ins,
                                       JRunTimeContext context)
                           throws RevEngineException {

        JOperandStack jos      = context.getOperandStack();

        if ( mapCatchJExceptions.get(new Integer(ins.index)) != null ) {
            jos.push(FOREIGN_OBJ, FOREIGN_CLASS, VALUE);
        } else if (Branches.isJSRTarget(ins.index)) {
            jos.push(FOREIGN_OBJ, FOREIGN_CLASS, VALUE);
        }

        boolean       foreign = jos.isTopDatatypeForeign();
        int           varIndex = ins.isStoreInstruction();
        String        dataType = symTable.declare(varIndex, ins.index);

//        context.addTextCode( "// " + ins );

        context.executeInstruction(ins);

        Helper.log( ins  + " " + jos.toString() );
        if (Helper.isDebug()) context.addTextCode( "// " + ins );
        if (ins.isEndOfLine() && jos.empty()) {
            String stmt = "";
            if (varIndex != JInstruction.INVALID_VAR_INDEX &&
                dataType != null)
            {
                // A Valid Store instruction.
                stmt = dataType + " ";
            }
            if (!foreign) {
                context.addCode( stmt); //new
            }
        } else if (ins.isInvokeIns() && jos.empty()) {
            context.addCode();
        } else if (ins.opcode == OPCODE_GOTO) {
            context.processBreakContinue(ins.index, ins.getTargetPc());
        } else if (ins.opcode == OPCODE_GOTOW) {
            context.processBreakContinue(ins.index, ins.getTargetPcW());
        }
    }

    private void getControlEndStmt(
                                JRunTimeContext context,
                                JInstruction ThisIns)
            throws RevEngineException {

        context.getEndStmt( ThisIns.getNextIndex() );
        return;
    }

    /**
     * For a given starting-point of one or more control-blocks,
     * this returns the next execution starting point.
     * It appends the corresponding code in cb also.
     **/
    private void getControlBeginStmt(
                                JRunTimeContext context,
                                JInstruction ThisIns)
            throws RevEngineException {

        context.writeBlockStart(ThisIns);
        List br_ent = Branches.startsWith(ThisIns.index);
        if ( br_ent.size() != 0 ) {
            context.getBeginStmt( br_ent, ThisIns.index, symTable );
        }
        return;
    }

    /**
     * Gets the methods intial headers, listing.
     *
     **/
    public static StringBuffer getMethodHeaders( JMethod  aMethod,
                                          JSymbolTable symTable )
                                 {

        StringBuffer sb = new StringBuffer();
        try {
            List args  = aMethod.getArgList();
            int symIndex = 1;
            if( aMethod.isStatic() ) {
                symIndex = 0;
            }

            if( aMethod.getName().compareTo(CLINIT) != 0 ) {
                sb.append("(");
                for(int i = 0; i < args.size(); i++) {
                    if( i!= 0 )  {
                        sb.append(" ,");
                    }
                    String jvmArgType = (String) args.get(i);
                    String argType = importInfo.getClassName(
                            Helper.getJavaDataType(jvmArgType, false) );

                    sb.append(  argType );
                    if ( symTable != null ) {
                        sb.append( " " +
                          symTable.getName(symIndex++, JSymbolTable.ARG_INDEX) );
                    }
                    if ( jvmArgType.equals(LONG) ||
                            jvmArgType.equals(DOUBLE) ) {
                        symIndex++;
                    }
                }
                sb.append(")");
            }
            sb.append( aMethod.getThrowsClause(importInfo) );
        } catch ( RevEngineException ree ) {
            //Should not occur
        }
        return sb;
    }
}
