/*
 * 
 * Created on 2004-jul-25
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.common;

import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.plaf.basic.BasicComboBoxEditor;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-25
 *
 */
public class ComboBoxEditor extends BasicComboBoxEditor {




	/**
	 * 
	 *
	 */
	public ComboBoxEditor() {
		editor = new JTextField( "", 9 );
		//editor.setBorder( UIManager.getBorder("ComboBox.editorBorder") );
		editor.setBorder( new LineBorder( new java.awt.Color( 170, 170, 170 ), 1 ) );	// TODO FIXED COLOR, BIG NONO!
	}




	/**
	 * A subclass of BasicComboBoxEditor that implements UIResource.
	 * BasicComboBoxEditor doesn't implement UIResource
	 * directly so that applications can safely override the
	 * cellRenderer property with BasicListCellRenderer subclasses.
	 */
	public static final class UIResource extends ComboBoxEditor implements javax.swing.plaf.UIResource {
	}
}
