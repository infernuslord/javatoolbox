// $Id: GreaterThanEqualsRelation.java,v 1.1 2002/04/25 18:07:46 bill Exp $

package com.jclark.xsl.expr;

class GreaterThanEqualsRelation extends NumericRelation {
    boolean relate(double d1, double d2) {
        return d1 >= d2;
    }
}
