/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr;

import java.lang.reflect.Array;
import java.util.*;

import java.awt.Font;

public class BasicUtils{
	public static final int CAPITAL_CASE = 1;
	public static final int NON_CAPITAL_CASE = 0;
	public static final String HEX_CHARS = "0123456789ABCDEF";


	/**
	 * Insert the method's description here.
	 * Creation date: (8/31/01 2:20:54 PM)
	 * @return java.lang.String
	 * @param b byte
	 */
    public static String byte2HexString(byte b, String prefix){
        return prefix + HEX_CHARS.charAt((b >> 4) & 0x0F) + HEX_CHARS.charAt(0x0F & b);
    }

    public static String bytes2HexString(byte[] bytes){
        return bytes2HexString(bytes, " 0x");
    }
    
	public static String bytes2HexString(byte[] bytes, String separator){
	  if(bytes==null) return null;
	
	  StringBuffer buffer = new StringBuffer();
	
	  for(int i=0; i<bytes.length; i++) buffer.append(byte2HexString(bytes[i], separator));
	
	  return buffer.length()==0 ? "" : buffer.substring(1);
	}
    
	public static String changeCase(String src, int newCase){
	  String s = new String(src);
	  
	  if(src.length()==0) return src;
	  switch(newCase){
		 case NON_CAPITAL_CASE : return s.substring(0, 1).toLowerCase() + s.substring(1);
		 case CAPITAL_CASE : return s.substring(0, 1).toUpperCase() + s.substring(1);
	  }
	
	  return s;
	}

    public static void replaceChars(char[] array, char replaceable, char replacement){
        for(int i = 0; i < array.length; i++) if(array[i] == replaceable) array[i] = replacement;
    }

	public static String encodeFont(Font f){
	  StringBuffer bf = new StringBuffer();
	 
	  bf.append(f.getFamily());
	  bf.append("-");
	  bf.append(f.isBold() ? "BOLD" : "");
	  bf.append(f.isItalic() ? "ITALIC" : "");
	  bf.append("-");
	  bf.append(f.getSize());
			
	  return bf.toString();
	}

    public static byte[] hexString2bytes(String src){
        return hexString2bytes(src, " ");
    }
    
	public static byte[] hexString2bytes(String src, String delimiter){
	  if(src==null) return null;
	
	  StringTokenizer st = new StringTokenizer(replaceString(src, "0x", ""), delimiter, false);
	  byte[] result = new byte[st.countTokens()];
	
	  for(int i=0; i<result.length; i++) result[i] = (byte)Integer.parseInt(st.nextToken(), 16);
	
	  return result;
	}


	/**
	 * Insert the method's description here.
	 * Creation date: (8/31/01 2:26:45 PM)
	 * @param args java.lang.String[]
	 */
	public static void main(String[] args){
	  byte[] b = new byte[256];
	
	  //String[] unp = unpack("core/recorder:.service", ':');
	  
	  String[] unp = removeBlanks(unpack(";core/remote admin service", ';'));
	  
	  String[] trm = removeBlanks(new String[]{"abc", "abc", "xxxx", "", "xyz", "zzzzz", "", "", "qtf", "abur"});
	  
	  for(int i=0; i<unp.length; i++) System.out.println("[" + unp[i] + "]");
	}

	public static int max(int[] elements){
	  if(elements.length < 1) throw new Error("there is no maximum for less than one element");
	
	  int max = elements[0];
	  for(int i=0; i<elements.length; i++) max = Math.max(max, elements[i]);
	
	  return max;
	}

	public static Object[] mergeArrays(Object[] a){
	  int ln = 0;
	  for(int i=0; i<a.length; i++) ln += ((Object[])a[i]).length;
	  Object[] c = new String[ln];
	
	  for(int i=0, index=0; i<a.length; i++){
		  System.arraycopy(a[i], 0, c, index, ((Object[])a[i]).length);
		  index += ((Object[])a[i]).length;
	  }
	
	  return c;
	}


	public static int min(int[] elements){
	  if(elements.length < 1) throw new Error("there is no minimum for less than one element");
	
	  int min = elements[0];
	  for(int i=0; i<elements.length; i++) min = Math.min(min, elements[i]);
	
	  return min;
	}


	/**
	 * Insert the method's description here.
	 * Creation date: (6/11/2001 9:23:50 PM)
	 * @return java.lang.String
	 * @param arg java.lang.String[]
	 */
	public static String pack(Object[] args, String separator){
	  StringBuffer result = new StringBuffer();
	  String varMarker = separator.equals("$") ? "&" : "$";
	
	  for(int i=0; i < args.length; i++){
		  if(args[i]==null) result.append(varMarker + "{null}");
		  else{
		       result.append(replaceString(args[i].toString(), "" + separator, varMarker + "{separator}"));
		       if(i < args.length -1) result.append(separator);
		  }
	  }
	  
	  return result.toString();
	}
	

	public static String smartReplaceString(String src, String replaceable, String replacement){
	  int startPos = 0,
	      cPos = src.indexOf(replaceable),
	      nextPos = -1,
          indent = 0;

	  if(cPos == -1) return src;	

      StringBuffer sb = new StringBuffer();
      String indentedReplacement = replacement;
      
	  while(cPos < src.length()){
            indent = src.lastIndexOf('\n', cPos);
            
            if(indent != -1){
                char[] characters = (char[])Array.newInstance(char.class, cPos -indent -1);
                
                Arrays.fill(characters, ' ');
                indentedReplacement = BasicUtils.replaceString(replacement, "\n", "\n" + String.valueOf(characters)); 
            }
          
            sb.append(src.substring(startPos, cPos));
	        sb.append(indentedReplacement);

			startPos = cPos +replaceable.length(); 
	        cPos = src.indexOf(replaceable, startPos);
            
            if(cPos == -1){
               cPos = src.length();
               sb.append(src.substring(startPos, cPos));
            }
	  }
	
	  return sb.toString();
	}


	public static String[] removeBlanks(String[] arg){
	    int blankCount = 0;
	    
	    for(int i = 0; i < arg.length; i++) if(arg[i]==null || arg[i].length()==0) blankCount++;
	    
	    String[] result = new String[arg.length -blankCount];
	    
	    for(int i = 0, k = 0; i < arg.length; i++) if(arg[i]!=null && arg[i].length()!=0) result[k++] = arg[i];
	    
	    return result;
	}


	public static Vector stringToVector(String s){
	  Vector result = new Vector();
	  StringTokenizer st = new StringTokenizer(s, ";", false);
	  while(st.hasMoreTokens()) result.addElement(st.nextToken());
	  
	  return result;
	}


	/**
	 * Insert the method's description here.
	 * Creation date: (6/11/2001 9:23:50 PM)
	 * @return java.lang.String
	 * @param arg java.lang.String[]
	 */
	public static String[] unpack(String arg, char separator){
	  return unpack(arg, separator, false);
	}


	public static long upRound(double d){
	  return (long)d + (d%(long)d !=0 ? 1 : 0);
	}


	public static int upRound(float f){
	  return (int)upRound((double)f);
	}


	public static String vectorToString(Vector v){
	  String data = "";
	  for(int i=0; i<v.size(); i++) data += v.elementAt(i).toString() + ";";
	
	  return data;
	}


	/**
	 * Insert the method's description here.
	 * Creation date: (6/11/2001 9:23:50 PM)
	 * @return java.lang.String
	 * @param arg java.lang.String[]
	 */
	public static String[] unpack(String arg, char separator, boolean trimSpaces){
	  int tokenCount = 1, 
	      indexBefore = 0;
	
	  char varMarker = separator == '$' ? '&' : '$';
	      
	  for(int i=0; i < arg.length(); i++) if(arg.charAt(i)==separator) tokenCount++;
	  
	  String[] values = new String[tokenCount];

	  for(int i = 0, k = 0; k < values.length; i++){
	      if(i >= arg.length() -1 || arg.charAt(i) == separator){
	         if(indexBefore == i) values[k] = new String();
	         else{
	              values[k] = arg.substring(indexBefore, i >= arg.length() -1 ? i +1 : i);
	       	      if(trimSpaces) values[k] = values[k].trim();
	      	      values[k] = replaceString(values[k], " {separator}".replace(' ', varMarker), "" + separator);
	      	      if(values[k].equals(" {null}".replace(' ', varMarker))) values[k] = null;
	         }
	
	         indexBefore = i +1;
	         k++;
	      }
	  }
	
	  return values;
	}
	

    public static Object removeFromArray(Object array, Object element){
        for(int index = 0; index < Array.getLength(array); index++){
            if(Array.get(array, index)==element){
               return removeFromArray(array, index);
            }
        }
        
        return array;
    }

	public static Object removeFromArray(Object array, int index){
        Object newArray = Array.newInstance(array.getClass().getComponentType(), ((Object[])array).length -1);
        System.arraycopy(array, 0, newArray, 0, index);
        System.arraycopy(array, index +1, newArray, index, ((Object[])array).length -index -1);
        
        return newArray;
	}


	public static Object insertIntoArray(Object array, Object object, int index){
        Object newArray = Array.newInstance(array.getClass().getComponentType(), ((Object[])array).length +1);
        System.arraycopy(array, 0, newArray, 0, index);
        System.arraycopy(array, index, newArray, index +1, ((Object[])array).length -index);
        Array.set(newArray, index, object);
        
        return newArray;
	}


    public static String replaceString(String src, String replaceable, String replacement){
      int startPos = 0,
          cPos = src.indexOf(replaceable),
          nextPos = -1;
    
      if(cPos == -1) return src;	
    
      StringBuffer sb = new StringBuffer();
        
      while(cPos < src.length()){
            sb.append(src.substring(startPos, cPos));
            sb.append(replacement);
    
    		startPos = cPos +replaceable.length(); 
            cPos = src.indexOf(replaceable, startPos);
            if(cPos == -1){
               cPos = src.length();
               sb.append(src.substring(startPos, cPos));
            }
      }
    
      return sb.toString();
    }
    
    public static String buildMessage(Throwable exception){
        StringBuffer buffer = new StringBuffer();
        
        while(exception != null){
            buffer.append(exception.toString());
            exception = exception.getCause();
            if(exception != null) buffer.append(", ");
        }
        
        return buffer.toString();
    }
}
