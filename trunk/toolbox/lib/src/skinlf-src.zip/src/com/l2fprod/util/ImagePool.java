/*
 * Copyright 2000-2002 by Castify Networks
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Castify Networks ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Castify Networks.
 *
 */
package com.l2fprod.util;

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.util.*;
import com.l2fprod.contrib.freehep.PanelArtistUtilities;

/**
 * .<BR>
 *
 *
 * <P>Copyright 2000-2002 by Castify Networks
 *
 * @author <a href="mailto:fred@castify.net">Frederic Lavigne</a>
 */
class ImagePool {

  private static Hashtable c_Pool = new Hashtable();

  private static int accessCount = 0;
  private static int poolHit = 0;

  public static Image getInstance(Image p_Image,
                                  int p_Width,
                                  int p_Height,
                                  Component p_Component) {    
    accessCount++;

    if (p_Width > 200 || p_Height > 200) {
      return p_Image;
    }
    
    PoolEntry entry = new PoolEntry(p_Image, p_Width, p_Height);
    Image image = (Image)c_Pool.get(entry);
    if (image == null) {
      image = entry.generate(p_Component);
      c_Pool.put(entry, image);
    } else {
      poolHit++;
    }
    System.out.println(poolHit + "/" + accessCount + "/" + c_Pool.size());
    if (image == null) {
      throw new Error("Null Image");
    } // end of if (image == null)

    System.out.println(image instanceof BufferedImage);
    return image;
  }

  static class PoolEntry {
    private Image m_Image;
    private int m_Width;
    private int m_Height;
    public PoolEntry(Image p_Image,
                     int p_Width,
                     int p_Height) {
      m_Image = p_Image;
      m_Width = p_Width;
      m_Height = p_Height;
    }
    public Image generate(Component c) {
      return m_Image.getScaledInstance(m_Width, m_Height, Image.SCALE_SMOOTH);
      /*if (m_Image instanceof BufferedImage && m_Width > 0 && m_Height > 0) {
         AffineTransform transform =
           PanelArtistUtilities.getResizeTransform(m_Image.getWidth(ImageUtils.producer),
                                                   m_Image.getHeight(ImageUtils.producer),
                                                   m_Width,
                                                   m_Height);
         AffineTransformOp op = 
           new AffineTransformOp(transform, null);
         return op.filter((BufferedImage)m_Image, null);
      } else {
        return m_Image.getScaledInstance(m_Width, m_Height, Image.SCALE_SMOOTH);
        }*/
    }
    public int hashCode() {
      return m_Image.hashCode();
    }
    public boolean equals(Object p_Object) {
      if (!(p_Object instanceof PoolEntry)) {
        return false;
      }
      if (p_Object == this) {
        return true;
      }
      return m_Image == ((PoolEntry)p_Object).m_Image &&
        m_Width == ((PoolEntry)p_Object).m_Width &&
        m_Height == ((PoolEntry)p_Object).m_Height;
    }
  }
}
