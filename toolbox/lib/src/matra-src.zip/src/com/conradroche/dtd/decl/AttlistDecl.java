/*
 *   The contents of this file are subject to the Mozilla Public License
 *   Version 1.1 (the "License"); you may not use this file except in
 *   compliance with the License. You may obtain a copy of the License at
 *   http://www.mozilla.org/MPL/
 *
 *   Software distributed under the License is distributed on an "AS IS"
 *   basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 *   License for the specific language governing rights and limitations
 *   under the License.
 *
 *   The Original Code is Matra - the DTD Parser.
 *
 *   The Initial Developer of the Original Code is Conrad S Roche.
 *   Portions created by Conrad S Roche are Copyright (C) Conrad 
 *   S Roche. All Rights Reserved.
 *
 *   Alternatively, the contents of this file may be used under the terms
 *   of the GNU GENERAL PUBLIC LICENSE Version 2 or any later version
 *   (the  "[GPL] License"), in which case the
 *   provisions of GPL License are applicable instead of those
 *   above.  If you wish to allow use of your version of this file only
 *   under the terms of the GPL License and not to allow others to use
 *   your version of this file under the MPL, indicate your decision by
 *   deleting  the provisions above and replace  them with the notice and
 *   other provisions required by the GPL License.  If you do not delete
 *   the provisions above, a recipient may use your version of this file
 *   under either the MPL or the GPL License."
 *
 *   [NOTE: The text of this Exhibit A may differ slightly from the text of
 *   the notices in the Source Code files of the Original Code. You should
 *   use the text of this Exhibit A rather than the text found in the
 *   Original Code Source Code for Your Modifications.]
 *
 * Created: Conrad S Roche <derupe at users.sourceforge.net>,  24-Sep-2003
 */
package com.conradroche.dtd.decl;

import java.util.Collection;

/**
 * This interface defines an attribute list
 * declaration. 
 * <br/>
 * From the XML Specification
 * [Section 3.3 Attribute-List Declarations] -
 * <br/>
 * [Definition: Attribute-list declarations specify 
 * the name, data type, and default value (if any) 
 * of each attribute associated with a given element 
 * type]
 *
 * @author Conrad Roche
 */
public interface AttlistDecl {

	/**
	 * Returns the element name associated with this
	 * attribute list declaration.
	 * 
	 * @see #setElementName
	 * 
	 * @return The element name.
	 */
	public String getElementName();
	
	/**
	 * Sets the element name associated with this
	 * attribute list declaration.
	 * 
	 * @see #getElementName
	 * 
	 * @param elemName The element name.
	 */
	public void setElementName(String elemName);
	
	/**
	 * Adds an attribute definition to this
	 * attribute list declaration.
	 * 
	 * @param attDef Attribute definition to add.
	 */
	public void addAttDef(AttDef attDef);
	
	/**
	 * Adds Attribute definitions to this
	 * attribute list declaration.
	 * 
	 * @param attDefs Attribute definitions to add.
	 */
	public void addAttDefs(Collection attDefs);
	
	/**
	 * Returns the attribute definitions
	 * contained within this attribute list
	 * declaration.
	 * 
	 * @return Collection of AttDef objects.
	 */
	public Collection getAttDefs();
}
