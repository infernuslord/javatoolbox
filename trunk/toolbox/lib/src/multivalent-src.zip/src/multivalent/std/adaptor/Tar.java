package multivalent.std.adaptor;

import java.io.*;
import java.net.URI;
//import java.net.MalformedURLException;
import java.util.List;
import java.util.ArrayList;

import multivalent.*;
//import multivalent.std.adaptor.ArchiveMediaAdaptor;

import phelps.util.Units;
import phelps.util.Dates;



/**
  Media adaptor for UNIX tape archive (Tar) files.  For now just makes a directory listing.
  POSIX header format taken from GNU tar.

  <p>To do
	extraction
	standard display format
<pre>
		-rwxr-xr-x 121/1111	  5773 1995-09-04 12:42 conote_client.pl
		-rw-r--r-- 121/1111		61 1995-09-04 11:37 Annotation/Debug.pl
		-rwxr-xr-x 121/1111	  6606 1995-09-03 22:09 Annotation/authentication.pl
</pre>
	support GNU extensions to header


<pre>
/* POSIX header.  * /

struct posix_header
{								/* byte offset * /
  char name[100];				/*	 0 * /
  char mode[8];				/* 100 * /
  char uid[8];					/* 108 * /
  char gid[8];					/* 116 * /
  char size[12];				/* 124 * /
  char mtime[12];				/* 136 * /
  char chksum[8];				/* 148 * /
  char typeflag;				/* 156 * /
  char linkname[100];			/* 157 * /
  char magic[6];				/* 257 * /
  char version[2];				/* 263 * /
  char uname[32];				/* 265 * /
  char gname[32];				/* 297 * /
  char devmajor[8];			/* 329 * /
  char devminor[8];			/* 337 * /
  char prefix[155];			/* 345 * /
								/* 500 * /
</pre>

	@version $Revision: 1.2 $ $Date: 2002/10/14 12:28:10 $
*/
public class Tar extends ArchiveMediaAdaptor {
  static final boolean DEBUG = false;
  static final int BLOCKSIZE = 512;


  //public void buildBefore(Document doc) {throw new ParseException("Use the class java.util.ZipFile to parse", -1);}
  public Object parse(INode parent) throws Exception {
	Document doc = parent.getDocument();
	URI uri = doc.getURI();

	//br.eventq(TableSort.MSG_ASCENDING, doc.findDFS("File")); -- keep archive order
	return parseHelper(toHTML(uri), "HTML", getLayer(), parent);
  }

  public String toHTML(URI uri) throws IOException {
	Cache cache = getGlobal().getCache();
	//String urifile = uri.getPath();
	File f = cache.mapTo(uri, null, Cache.COMPUTE);


	long now = System.currentTimeMillis();

	// make an HTML table -- make HTML table nodes public
	StringBuffer sb = new StringBuffer((int)f.length());

	sb.append("<html>\n<head>");
	//sb.append("\t<title>").append("Contents of tar file ").append(urifile).append("</title>\n");
	sb.append("\t<base href='").append(uri).append("/'>\n");	// .zip as if directory!
	sb.append("</head>\n");
	sb.append("<body>\n");

	int filesi=sb.length(), filecnt=0;
	sb.append(" files, ");
	int sizei=sb.length(); long sizec=0;
	//<h3>Contents of zip file ").append(urifile).append("</h3>\n"); => apparent in URI entry
	//zhsb.append("<p>").append(dirlist.length).append(" file"); if (dirlist.length!=1) hsb.append('s');
	sb.append("\n<table width='90%'>\n");

	// headers.  click to sort
	sb.append("<tr><span Behavior='ScriptSpan' script='event tableSort <node>'	title='Sort table'>");
	sb.append("<th align='left'>File / <b>Directory<th align='right'>Size<th align='right'>Last Modified</b></span>\n");

	// collect header fields => should go in getCatalog, which should take an InputStream
	byte[] buf = new byte[BLOCKSIZE];
	InputStream is = getInputStream();
	for (int c; is.read(buf)==BLOCKSIZE; filecnt++) {
		if (buf[0]==0) continue;  // break?
		String name=null; for (int i=0; i<100; i++) if (buf[i]==0) { name=new String(buf, 0, i); break; }
System.out.println("name = |"+name+"|");
		sb.append("<tr><td>");
		boolean dir = name.endsWith("/");
		if (dir) sb.append("<b>").append(name).append("</b>"); else sb.append(name);
		sb.append("\n");

		int size=0;
		for (int i=124; i<136; i++) {	// size in OCTAL!
			c=buf[i]; if (c>='0' && c<='7') size = size*8 + c-'0'; else if (c!=' ') break;
		}
		sb.append("<td align='right'>").append(size);
		sizec += size;
//System.out.println("size = "+size);
//			sb.append("<td><span Behavior='ElideSpan'>").append(lastmod).append("</span> ").append(Dates.relative(lastmod, now));

		long lastmod=0;
		for (int i=136; i<148; i++) {
			c=buf[i]; if (c>='0' && c<='7') lastmod = lastmod*8 + c-'0'; else if (c!=' ') break;
		}
		lastmod *= 1000;	// sec=>ms
//System.out.println("lastmod = "+lastmod+", rel="+Dates.relative(lastmod, now)+", rel*1000="+Dates.relative(lastmod*1000, now));
		sb.append("<td align='right'><span Behavior='ElideSpan'>").append(lastmod).append("</span> ").append(Dates.relative(lastmod, now));


		// skip data
		int toeat = size;
		while (toeat>0) toeat -= is.skip(BLOCKSIZE);
//break;
	}

	sb.insert(sizei, Units.prettySize(sizec));
	sb.insert(filesi, filecnt);
	sb.append("</table>\n</body></html>\n");

	return sb.toString();
  }


  protected String[] getPatterns() { String[] pat = { ".tar/" }; return pat; }

  public List<ArchiveFileEntry> getCatalog(File archive) throws IOException {
	List<ArchiveFileEntry> files = new ArrayList<ArchiveFileEntry>(500);
/*
	ZipFile zf = new ZipFile(archive);
	for (Enumeration e=zf.entries(); e.hasMoreElements(); ) {
		ZipEntry ze = (ZipEntry)e.nextElement();
		String zfname = ze.getName();
		files.add(new ArchiveFileEntry(ze.getName(), -1, null, ze.getSize(), ze.getCompressedSize(), -1, ze.getTime(), ze.getTime()));
	}*/
	return files;
  }


//	public InputStream getInputStream(File archive, String filename) throws IOException {
  public File extractFile(File archive, String filename, File outdir) throws IOException {
	File newfile = null;
/*
	ZipFile zf = new ZipFile(archive);
//	Cache cache = getGlobal().getCache();
//	URI zipuri = zf.toURI();
	for (Enumeration e=zf.entries(); e.hasMoreElements(); ) {
		ZipEntry ze = (ZipEntry)e.nextElement();
		String zfname = ze.getName();
//System.out.println("*** comparing "+filename+" with "+ze.getName());
		if (filename==ALLFILES || filename.equals(zfname)) {
			int inx=zfname.lastIndexOf('/'); if (inx!=-1) zfname=zfname.substring(inx+1);
			newfile = new File(outdir, zfname);
			//newfile.getParentFile().mkdirs();
if (DEBUG) System.out.println("*** extract");
			InputStream in = new BufferedInputStream(zf.getInputStream(ze));	// buffered make any difference in this case?
if (DEBUG) System.out.println("*** in = "+in);
if (DEBUG) System.out.println("*** out = "+newfile);
			OutputStream out = new BufferedOutputStream(new FileOutputStream(newfile));
if (DEBUG) System.out.println("*** out = "+out);
			byte[] buf = new byte[8*1024];
			for (int len; (len=in.read(buf))!=-1; ) {out.write(buf, 0,len);
if (DEBUG) System.out.println("*** "+len);}
			out.close(); in.close();
			if (filename!=ALLFILES) break;
		}
	}
	zf.close();*/
	return newfile;
  }
}
