/*
 * Please see COPYING for license details
 *
 * Copyright (C) 2003 Raghu K, All rights reserved.
 */

package hamsam.protocol.msn;

import hamsam.exception.IllegalStateException;
import hamsam.net.ProxyInfo;
import hamsam.protocol.msn.Command;

import java.io.IOException;
import java.net.UnknownHostException;

/**
 * Initial point of connection to MSN. Refers users to the appropriate
 * notification server. This server can be connected to through
 * messenger.hotmail.com on port 1863.
 */
class DispatchServer extends MsnServer
{
	/**
	 * Event processor for this server.
	 */
	private EventProcessor processor;

	/**
	 * MsnProtocol instance that owns this server.
	 */
	private MsnProtocol protocol;

	/**
	 * Constructs a dispatch server with a specified event processor
	 * and proxy information.
	 *
	 * @param protocol the MsnProtocol instance that owns this server.
	 * @param processor the event processor for this server.
	 * @param info proxy information to be used for connections.
	 * @throws UnknownHostException if host is not known.
	 * @throws IOException if an I/O error occurs while connecting to the host.
	 * @throws IllegalStateException if info is not initialized properly.
	 */
	DispatchServer(MsnProtocol protocol, EventProcessor processor, ProxyInfo info) throws UnknownHostException, IOException, IllegalStateException
	{
		super("messenger.hotmail.com", 1863, info);
		this.protocol = protocol;
		this.processor = processor;

		Command cmd = new Command("VER");
		cmd.addParam("MSNP8");
		sendToServer(cmd, "processVersion");
	}

	/**
	 * Process the reply for VER command.
	 *
	 * @param cmd the reply from the server.
	 */
	void processVersion(AbstractCommand cmd)
	{
		if(cmd instanceof Command)
		{
			if("VER".equals(cmd.getType()) && "MSNP8".equals(cmd.getParam(0)))
			{
				Command cvr = new Command("CVR");
				cvr.addParam("0x0409");
				
				String os = System.getProperty("os.name").toLowerCase();
				if(os.length() > 3)
					os = os.substring(0, 3);
				cvr.addParam(os);
				cvr.addParam(Util.urlDecode(System.getProperty("os.version")));
				cvr.addParam(Util.urlEncode(System.getProperty("os.arch")));
				cvr.addParam("Hamsam");
				cvr.addParam("0.2");
				cvr.addParam("Hamsam");
				cvr.addParam(Util.urlEncode(this.protocol.getUsername()));

				sendToServer(cvr, "processClientVersion");
				return;
			}
		}
		shutdown();
		processor.connectFailed("Version transaction failed - " + cmd);
	}

	/**
	 * Process the reply for CVR command.
	 *
	 * @param cmd the reply from the server.
	 */
	void processClientVersion(AbstractCommand cmd)
	{
		if(cmd instanceof Command)
		{
			if("CVR".equals(cmd.getType()))
			{
				Command usr = new Command("USR");
				usr.addParam("TWN");
				usr.addParam("I");	// I for initiate
				usr.addParam(protocol.getUsername());
				sendToServer(usr, "processAuthentication");
				return;
			}
		}
		shutdown();
		processor.connectFailed("Client versioning was rejected - " + cmd);
	}

	/**
	 * Process the reply for USR command.
	 *
	 * @param cmd the reply from the server.
	 */
	void processAuthentication(AbstractCommand cmd)
	{
		if(cmd instanceof Command)
		{
			if("XFR".equals(cmd.getType()) && "NS".equals(cmd.getParam(0)))
			{
				shutdown();

				String server = cmd.getParam(1);
				protocol.switchServer(server);
				return;
			}
		}
		shutdown();
		processor.connectFailed("Unknown authentication mechanism - " + cmd);
	}

	/**
	 * Processes messages received from MSN server. This method does nothing because
	 * we don't expect a message from a dispatch server.
	 */
	protected void processMessage(MsnMessage msg)
	{
	}

	/**
	 * Processes asynchronous commands received from MSN server.
	 * This method does nothing because we don't expect an asynchronous command
	 * from a dispatch server.
	 */
	protected void processAsyncCommand(AbstractCommand cmd)
	{
	}

	/**
	 * Invoked when the associated reader thread exits abnormally. This
	 * method shuts down the IM session.
	 */
	protected void readerExited()
	{
		shutdown();
		processor.disconnected();
	}

	/**
	 * Invoked when the associated writer thread exits abnormally. This
	 * method shuts down the IM session.
	 */
	protected void writerExited()
	{
		shutdown();
		processor.disconnected();
	}
}
