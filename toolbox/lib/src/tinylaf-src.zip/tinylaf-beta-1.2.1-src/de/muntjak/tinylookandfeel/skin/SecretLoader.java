package de.muntjak.tinylookandfeel.skin;

import java.awt.*;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URL;

import javax.swing.JPanel;

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*   XP Look and Feel                                                           *
*                                                                              *
*  (C) Copyright 2002, by Stefan Krause                                        *
*                                                                              *
*   This file is not licensed under the LGPL.                                  *
*   To protected Microsoft's rights for the xp images                          *
*   all images are encrypted and the source code for loading is omitted        *
*   You are not allowed to reengineer this class and / or use the images       *
*   for anything other than the purpose of this look and feel                  *
*   You may not use them on any other operating system than windows xp         *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

public class SecretLoader {
	
	// previously was a JPanel, changed this 2003-5-22
	// because of the PanelUI-not-found-bug.
    static Component component = new Label();
    static byte buffer[]=new byte[4096];
    
    static Image loadImage(String fileName)
    {
        URL url = SecretLoader.class.getResource("/de/muntjak/tinylookandfeel/icons/" + fileName);
        byte[] byteArray=null;
        
        try {
            InputStream fis=url.openStream();
            ByteArrayOutputStream bos=new ByteArrayOutputStream();

            if (fileName.endsWith(".res"))
            {
                fis.read();            
                fis.read();        
                
                int read=fis.read(buffer);
                while (read!=-1)
                {
                    bos.write(buffer,0,read);
                    read=fis.read(buffer);
                }

                byteArray=bos.toByteArray();
                
                for (int i=0;i<byteArray.length;i++)
                    byteArray[i]^=42;
            }
            else
            {                
                int read=fis.read(buffer);
                while (read!=-1)
                {
                    bos.write(buffer,0,read);
                    read=fis.read(buffer);
                }

                byteArray=bos.toByteArray();
                read=fis.read(byteArray);
            }
                        
            Image img = java.awt.Toolkit.getDefaultToolkit().createImage(byteArray,0,byteArray.length);
    
            MediaTracker tracker = new MediaTracker(component);
            tracker.addImage(img, 0);
            try {
                tracker.waitForID(0);
            } catch (InterruptedException ignore) {}
            
            return img;
        } catch (Throwable t) {
            throw new IllegalArgumentException("File " + fileName + " could not be loaded.");   
        }
    } 
}
