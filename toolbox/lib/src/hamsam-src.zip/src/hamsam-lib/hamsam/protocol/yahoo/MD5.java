/*
 * Please see COPYING for license details
 *
 * Copyright (C) 2003 Raghu K, All rights reserved.
 */

package hamsam.protocol.yahoo;

public class MD5
{
	private int count[];	/* two words */
	private int[] abcd;
	private char[] buff;

	private static final int T1 = 0xd76aa478;
	private static final int T2 = 0xe8c7b756;
	private static final int T3 = 0x242070db;
	private static final int T4 = 0xc1bdceee;
	private static final int T5 = 0xf57c0faf;
	private static final int T6 = 0x4787c62a;
	private static final int T7 = 0xa8304613;
	private static final int T8 = 0xfd469501;
	private static final int T9 = 0x698098d8;
	private static final int T10 = 0x8b44f7af;
	private static final int T11 = 0xffff5bb1;
	private static final int T12 = 0x895cd7be;
	private static final int T13 = 0x6b901122;
	private static final int T14 = 0xfd987193;
	private static final int T15 = 0xa679438e;
	private static final int T16 = 0x49b40821;
	private static final int T17 = 0xf61e2562;
	private static final int T18 = 0xc040b340;
	private static final int T19 = 0x265e5a51;
	private static final int T20 = 0xe9b6c7aa;
	private static final int T21 = 0xd62f105d;
	private static final int T22 = 0x02441453;
	private static final int T23 = 0xd8a1e681;
	private static final int T24 = 0xe7d3fbc8;
	private static final int T25 = 0x21e1cde6;
	private static final int T26 = 0xc33707d6;
	private static final int T27 = 0xf4d50d87;
	private static final int T28 = 0x455a14ed;
	private static final int T29 = 0xa9e3e905;
	private static final int T30 = 0xfcefa3f8;
	private static final int T31 = 0x676f02d9;
	private static final int T32 = 0x8d2a4c8a;
	private static final int T33 = 0xfffa3942;
	private static final int T34 = 0x8771f681;
	private static final int T35 = 0x6d9d6122;
	private static final int T36 = 0xfde5380c;
	private static final int T37 = 0xa4beea44;
	private static final int T38 = 0x4bdecfa9;
	private static final int T39 = 0xf6bb4b60;
	private static final int T40 = 0xbebfbc70;
	private static final int T41 = 0x289b7ec6;
	private static final int T42 = 0xeaa127fa;
	private static final int T43 = 0xd4ef3085;
	private static final int T44 = 0x04881d05;
	private static final int T45 = 0xd9d4d039;
	private static final int T46 = 0xe6db99e5;
	private static final int T47 = 0x1fa27cf8;
	private static final int T48 = 0xc4ac5665;
	private static final int T49 = 0xf4292244;
	private static final int T50 = 0x432aff97;
	private static final int T51 = 0xab9423a7;
	private static final int T52 = 0xfc93a039;
	private static final int T53 = 0x655b59c3;
	private static final int T54 = 0x8f0ccc92;
	private static final int T55 = 0xffeff47d;
	private static final int T56 = 0x85845dd1;
	private static final int T57 = 0x6fa87e4f;
	private static final int T58 = 0xfe2ce6e0;
	private static final int T59 = 0xa3014314;
	private static final int T60 = 0x4e0811a1;
	private static final int T61 = 0xf7537e82;
	private static final int T62 = 0xbd3af235;
	private static final int T63 = 0x2ad7d2bb;
	private static final int T64 = 0xeb86d391;

	public MD5()
	{
		count = new int[2];
		count[0] = count[1] = 0;
		abcd = new int[4];
		buff = new char[64];

	    abcd[0] = 0x67452301;
	    abcd[1] = 0xefcdab89;
    	abcd[2] = 0x98badcfe;
	    abcd[3] = 0x10325476;
	}

	public void append(String data)
	{
		char[] charData = data.toCharArray();
		append(charData, charData.length);
	}

	public void append(String data, int nbytes)
	{
		char[] charData = data.toCharArray();
		append(charData, nbytes);
	}

	public void append(char[] data, int nbytes)
	{
    	int left = nbytes;
		int offset = (count[0] >>> 3) & 63;
		char nbits = (char)(nbytes << 3);

		if(nbytes <= 0)
			return;

		/* Update the message length. */
		count[1] += ((long)nbytes >>> 29);
		count[0] += nbits;
		if(count[0] < nbits)
			count[1]++;

		/* Process an initial partial block. */
		int inOffset = 0;
		if(offset != 0)
		{
			int copy = (offset + nbytes > 64 ? 64 - offset : nbytes);

			memcpy(buff, offset, data, inOffset, copy);
			if(offset + copy < 64)
				return;

			inOffset += copy;
			left -= copy;
			process(buff, 0);
		}

		/* Process full blocks. */
		for(; left >= 64; inOffset += 64, left -= 64)
			process(data, inOffset);

		/* Process a final partial block. */
		if(left != 0)
			memcpy(buff, 0, data, inOffset, left);
	}

	public char[] finish()
	{
		char[] pad = {
			0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
	    };
		char[] data = new char[8];
		int i;

		/* Save the length before padding. */
		for(i = 0; i < 8; ++i)
			data[i] = (char)((count[i >>> 2] >>> ((i & 3) << 3)) & 0xff);
		/* Pad to 56 bytes mod 64. */
		append(pad, ((55 - (count[0] >>> 3)) & 63) + 1);
		/* Append the length. */
		append(data, 8);

		char[] digest = new char[16];
		for(i = 0; i < 16; ++i)
			digest[i] = (char)((abcd[i >>> 2] >>> ((i & 3) << 3)) & 0xff);

		return digest;
	}

	private void memcpy(char[] out, int outOffset, char[] in, int inOffset, int count)
	{
		for(int i = 0; i < count; i++)
			out[outOffset + i] = in[inOffset + i];
	}

	private void process(char[] data /*[64]*/, int start)
	{
		int a = abcd[0], b = abcd[1], c = abcd[2], d = abcd[3];
		int t;

		/*
	     * On big-endian machines, we must arrange the bytes in the right
    	 * order.  (This also works on machines of unknown byte order.)
	     */
		int[] X = new int[16];
    	int index = 0;

		for(int i = 0; i < 16; ++i, index += 4)
			X[i] = data[index + start] + (data[index + start + 1] << 8) + (data[index + start + 2] << 16) + (data[index + start + 3] << 24);

		/*
		 * On little-endian machines, we can process properly aligned data
		 * without copying it.
		 */
		/*
	    md5_word_t xbuf[16];
    	const md5_word_t *X;

	    if (!((data - (const md5_byte_t *)0) & 3)) {
		// data are properly aligned
		X = (const md5_word_t *)data;
    	} else {
		// not aligned
		memcpy(xbuf, data, 64);
		X = xbuf;
    	}
		*/

		/* Round 1. */
		/* Let [abcd k s i] denote the operation
		a = b + ((a + F(b,c,d) + X[k] + T[i]) <<< s). */
		/* #define SET(a, b, c, d, k, s, Ti)\
		  t = a + F(b,c,d) + X[k] + Ti;\
		  a = rotateLeft(t, s) + b
		*/
    	/* Do the following 16 operations. */
		t = a + ((b & c) | (~b & d)) + X[0] + T1;
		a = ((t << 7) | (t >>> (32 - 7))) + b;
		t = d + ((a & b) | (~a & c)) + X[1] + T2;
		d = ((t << 12) | (t >>> (32 - 12))) + a;
		t = c + ((d & a) | (~d & b)) + X[2] + T3;
		c = ((t << 17) | (t >>> (32 - 17))) + d;
		t = b + ((c & d) | (~c & a)) + X[3] + T4;
		b = ((t << 22) | (t >>> (32 - 22))) + c;
		t = a + ((b & c) | (~b & d)) + X[4] + T5;
		a = ((t << 7) | (t >>> (32 - 7))) + b;
		t = d + ((a & b) | (~a & c)) + X[5] + T6;
		d = ((t << 12) | (t >>> (32 - 12))) + a;
		t = c + ((d & a) | (~d & b)) + X[6] + T7;
		c = ((t << 17) | (t >>> (32 - 17))) + d;
		t = b + ((c & d) | (~c & a)) + X[7] + T8;
		b = ((t << 22) | (t >>> (32 - 22))) + c;
		t = a + ((b & c) | (~b & d)) + X[8] + T9;
		a = ((t << 7) | (t >>> (32 - 7))) + b;
		t = d + ((a & b) | (~a & c)) + X[9] + T10;
		d = ((t << 12) | (t >>> (32 - 12))) + a;
		t = c + ((d & a) | (~d & b)) + X[10] + T11;
		c = ((t << 17) | (t >>> (32 - 17))) + d;
		t = b + ((c & d) | (~c & a)) + X[11] + T12;
		b = ((t << 22) | (t >>> (32 - 22))) + c;
		t = a + ((b & c) | (~b & d)) + X[12] + T13;
		a = ((t << 7) | (t >>> (32 - 7))) + b;
		t = d + ((a & b) | (~a & c)) + X[13] + T14;
		d = ((t << 12) | (t >>> (32 - 12))) + a;
		t = c + ((d & a) | (~d & b)) + X[14] + T15;
		c = ((t << 17) | (t >>> (32 - 17))) + d;
		t = b + ((c & d) | (~c & a)) + X[15] + T16;
		b = ((t << 22) | (t >>> (32 - 22))) + c;

     /* Round 2. */
     /* Let [abcd k s i] denote the operation
          a = b + ((a + G(b,c,d) + X[k] + T[i]) <<< s). */
		/* #define SET(a, b, c, d, k, s, Ti)\
		  t = a + G(b,c,d) + X[k] + Ti;\
		  a = rotateLeft(t, s) + b */
     /* Do the following 16 operations. */
		t = a + ((b & d) | (c & ~d)) + X[1] + T17;
		a = ((t << 5) | (t >>> (32 - 5))) + b;
		t = d + ((a & c) | (b & ~c)) + X[6] + T18;
		d = ((t << 9) | (t >>> (32 - 9))) + a;
		t = c + ((d & b) | (a & ~b)) + X[11] + T19;
		c = ((t << 14) | (t >>> (32 - 14))) + d;
		t = b + ((c & a) | (d & ~a)) + X[0] + T20;
		b = ((t << 20) | (t >>> (32 - 20))) + c;
		t = a + ((b & d) | (c & ~d)) + X[5] + T21;
		a = ((t << 5) | (t >>> (32 - 5))) + b;
		t = d + ((a & c) | (b & ~c)) + X[10] + T22;
		d = ((t << 9) | (t >>> (32 - 9))) + a;
		t = c + ((d & b) | (a & ~b)) + X[15] + T23;
		c = ((t << 14) | (t >>> (32 - 14))) + d;
		t = b + ((c & a) | (d & ~a)) + X[4] + T24;
		b = ((t << 20) | (t >>> (32 - 20))) + c;
		t = a + ((b & d) | (c & ~d)) + X[9] + T25;
		a = ((t << 5) | (t >>> (32 - 5))) + b;
		t = d + ((a & c) | (b & ~c)) + X[14] + T26;
		d = ((t << 9) | (t >>> (32 - 9))) + a;
		t = c + ((d & b) | (a & ~b)) + X[3] + T27;
		c = ((t << 14) | (t >>> (32 - 14))) + d;
		t = b + ((c & a) | (d & ~a)) + X[8] + T28;
		b = ((t << 20) | (t >>> (32 - 20))) + c;
		t = a + ((b & d) | (c & ~d)) + X[13] + T29;
		a = ((t << 5) | (t >>> (32 - 5))) + b;
		t = d + ((a & c) | (b & ~c)) + X[2] + T30;
		d = ((t << 9) | (t >>> (32 - 9))) + a;
		t = c + ((d & b) | (a & ~b)) + X[7] + T31;
		c = ((t << 14) | (t >>> (32 - 14))) + d;
		t = b + ((c & a) | (d & ~a)) + X[12] + T32;
		b = ((t << 20) | (t >>> (32 - 20))) + c;

     /* Round 3. */
     /* Let [abcd k s t] denote the operation
          a = b + ((a + H(b,c,d) + X[k] + T[i]) <<< s). */
		/* #define SET(a, b, c, d, k, s, Ti)\
		  t = a + H(b,c,d) + X[k] + Ti;\
		  a = rotateLeft(t, s) + b
		*/
     /* Do the following 16 operations. */
		t = a + (b ^ c ^ d) + X[5] + T33;
		a = ((t << 4) | (t >>> (32 - 4))) + b;
		t = d + (a ^ b ^ c) + X[8] + T34;
		d = ((t << 11) | (t >>> (32 - 11))) + a;
		t = c + (d ^ a ^ b) + X[11] + T35;
		c = ((t << 16) | (t >>> (32 - 16))) + d;
		t = b + (c ^ d ^ a) + X[14] + T36;
		b = ((t << 23) | (t >>> (32 - 23))) + c;
		t = a + (b ^ c ^ d) + X[1] + T37;
		a = ((t << 4) | (t >>> (32 - 4))) + b;
		t = d + (a ^ b ^ c) + X[4] + T38;
		d = ((t << 11) | (t >>> (32 - 11))) + a;
		t = c + (d ^ a ^ b) + X[7] + T39;
		c = ((t << 16) | (t >>> (32 - 16))) + d;
		t = b + (c ^ d ^ a) + X[10] + T40;
		b = ((t << 23) | (t >>> (32 - 23))) + c;
		t = a + (b ^ c ^ d) + X[13] + T41;
		a = ((t << 4) | (t >>> (32 - 4))) + b;
		t = d + (a ^ b ^ c) + X[0] + T42;
		d = ((t << 11) | (t >>> (32 - 11))) + a;
		t = c + (d ^ a ^ b) + X[3] + T43;
		c = ((t << 16) | (t >>> (32 - 16))) + d;
		t = b + (c ^ d ^ a) + X[6] + T44;
		b = ((t << 23) | (t >>> (32 - 23))) + c;
		t = a + (b ^ c ^ d) + X[9] + T45;
		a = ((t << 4) | (t >>> (32 - 4))) + b;
		t = d + (a ^ b ^ c) + X[12] + T46;
		d = ((t << 11) | (t >>> (32 - 11))) + a;
		t = c + (d ^ a ^ b) + X[15] + T47;
		c = ((t << 16) | (t >>> (32 - 16))) + d;
		t = b + (c ^ d ^ a) + X[2] + T48;
		b = ((t << 23) | (t >>> (32 - 23))) + c;

     /* Round 4. */
     /* Let [abcd k s t] denote the operation
          a = b + ((a + I(b,c,d) + X[k] + T[i]) <<< s). */
		/*#define SET(a, b, c, d, k, s, Ti)\
		  t = a + I(b,c,d) + X[k] + Ti;\
		  a = rotateLeft(t, s) + b */
     /* Do the following 16 operations. */
		t = a + (c ^ (b | ~d)) + X[0] + T49;
		a = ((t << 6) | (t >>> (32 - 6))) + b;
		t = d + (b ^ (a | ~c)) + X[7] + T50;
		d = ((t << 10) | (t >>> (32 - 10))) + a;
		t = c + (a ^ (d | ~b)) + X[14] + T51;
		c = ((t << 15) | (t >>> (32 - 15))) + d;
		t = b + (d ^ (c | ~a)) + X[5] + T52;
		b = ((t << 21) | (t >>> (32 - 21))) + c;
		t = a + (c ^ (b | ~d)) + X[12] + T53;
		a = ((t << 6) | (t >>> (32 - 6))) + b;
		t = d + (b ^ (a | ~c)) + X[3] + T54;
		d = ((t << 10) | (t >>> (32 - 10))) + a;
		t = c + (a ^ (d | ~b)) + X[10] + T55;
		c = ((t << 15) | (t >>> (32 - 15))) + d;
		t = b + (d ^ (c | ~a)) + X[1] + T56;
		b = ((t << 21) | (t >>> (32 - 21))) + c;
		t = a + (c ^ (b | ~d)) + X[8] + T57;
		a = ((t << 6) | (t >>> (32 - 6))) + b;
		t = d + (b ^ (a | ~c)) + X[15] + T58;
		d = ((t << 10) | (t >>> (32 - 10))) + a;
		t = c + (a ^ (d | ~b)) + X[6] + T59;
		c = ((t << 15) | (t >>> (32 - 15))) + d;
		t = b + (d ^ (c | ~a)) + X[13] + T60;
		b = ((t << 21) | (t >>> (32 - 21))) + c;
		t = a + (c ^ (b | ~d)) + X[4] + T61;
		a = ((t << 6) | (t >>> (32 - 6))) + b;
		t = d + (b ^ (a | ~c)) + X[11] + T62;
		d = ((t << 10) | (t >>> (32 - 10))) + a;
		t = c + (a ^ (d | ~b)) + X[2] + T63;
		c = ((t << 15) | (t >>> (32 - 15))) + d;
		t = b + (d ^ (c | ~a)) + X[9] + T64;
		b = ((t << 21) | (t >>> (32 - 21))) + c;

		/* Then perform the following additions. (That is increment each
        of the four registers by the value it had before this block
        was started.) */
		abcd[0] += a;
		abcd[1] += b;
		abcd[2] += c;
		abcd[3] += d;
	}

	/*private char rotateLeft(char x, char n)
	{
		return (x << n) | (x >> (32 - n));
	}

	private char F(char x, char y, char z)
	{
		return (x & y) | (~x & z);
	}

	private char G(char x, char y, char z)
	{
		return (x & z) | (y & ~z);
	}

	private char H(char x, char y, char z)
	{
		return (x ^ y ^ z);
	}

	private I(char x, char y, char z)
	{
		return (y ^ (x | ~z));
	} */

	public static void main(String args[])
	{
		String test[] = {
				"", /*d41d8cd98f00b204e9800998ecf8427e*/
				"945399884.61923487334tuvga", /*0cc175b9c0f1b6a831c399e269772661*/
				"abc", /*900150983cd24fb0d6963f7d28e17f72*/
				"message digest", /*f96b697d7cb7938d525a2f31aaf161d0*/
				"abcdefghijklmnopqrstuvwxyz", /*c3fcd3d76192e4007dfb496cca67e13b*/
				"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
				/*d174ab98d277d9f5a5611c2c9f419d9f*/
				"12345678901234567890123456789012345678901234567890123456789012345678901234567890" /*57edf4a22be3c955ac49da2e2107b67a*/
		};

		for(int i = 0; i < 7; ++i)
		{
			MD5 state = new MD5();

			state.append(test[i], test[i].length());
			char[] digest = state.finish();

			System.out.print("MD5 (\"" + test[i] + "\") = ");
			for(int di = 0; di < 16; ++di)
				System.out.print((int)digest[di]);

			System.out.println();
		}
	}
}
