// $Id: ParentAxisExpr.java,v 1.1 2002/04/25 18:10:29 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

class ParentAxisExpr extends AxisExpr {
    public NodeIterator eval(Node node, ExprContext context) {
        return new SingleNodeIterator(node.getParent());
    }
    int getOptimizeFlags() {
        return SINGLE_LEVEL;
    }
}
