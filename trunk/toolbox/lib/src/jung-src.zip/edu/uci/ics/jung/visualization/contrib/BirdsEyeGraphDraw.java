/*
 * Copyright (c) 2003, the JUNG Project and the Regents of the University of
 * California All rights reserved.
 * 
 * This software is open-source under the BSD license; see either "license.txt"
 * or http://jung.sourceforge.net/license.txt for a description.
 */
package edu.uci.ics.jung.visualization.contrib;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JComponent;

import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.decorators.EdgeColorFunction;
import edu.uci.ics.jung.graph.decorators.EdgeThicknessFunction;
import edu.uci.ics.jung.graph.decorators.StringLabeller;
import edu.uci.ics.jung.graph.decorators.VertexColorFunction;
import edu.uci.ics.jung.visualization.Layout;
import edu.uci.ics.jung.visualization.Renderer;
import edu.uci.ics.jung.visualization.SpringLayout;
import edu.uci.ics.jung.visualization.graphdraw.SettableRenderer;

/**
 * Similar to GraphDraw, but with no method calls that will modify the
 * underlying graph. This component is used as the view to create a
 * birds-eye zoom/pan tool
 * 
 * @author Tom Nelson - adapted from code written by Danyel Fisher
 */
public class BirdsEyeGraphDraw extends JComponent {

    /**
     * the graph to manage
     */
	protected Graph graph;
	
	/**
	 * the first SettableRenderer created
	 */
	private final SettableRenderer originalRenderer;
	
	/**
	 * the renderer that is passed thru to the VisualizationViewer
	 */
	Renderer r;
	
	/**
	 * the layout in use
	 */
	Layout layout;
	
	/**
	 * the VisualizationViewer for this GraphDraw. It does not
	 * modify the underlying graph
	 */
	BirdsEyeVisualizationViewer vv;

	/**
	 * Creates a read-only graph drawing environment that draws this graph object. By
	 * default, uses the Spring layout, the Fade renderer and the
	 * AbstractSettable renderer, 
	 * 
	 * @param g the graph
	 * @param scalex the scale in the horizontal axis
	 * @param scaley the scale in the vertical axis
	 */
	public BirdsEyeGraphDraw(Graph g, double scalex, double scaley) {
		this.graph = g;
		StringLabeller sl = StringLabeller.getLabeller(g);
		layout = new SpringLayout(g);
		originalRenderer = new SettableRenderer(sl);
		r = originalRenderer;
		vv = new BirdsEyeVisualizationViewer(layout, r, scalex, scaley);
		setLayout(new BorderLayout());
		add(vv, BorderLayout.CENTER);

	}

	/**
	 * Returns the visualizationviewer that actually does the graph drawing.
	 * 
	 * @return
	 */
	public BirdsEyeVisualizationViewer getVisualizationViewer() {
		return vv;
	}

	public void setBackground(Color bg) {
		super.setBackground(bg);
		vv.setBackground(bg);
	}

	/**
	 * A method to set the renderer. Passes it to the VisualizationViewer
	 * 
	 * @param r
	 *            the new renderer
	 */
	public void setRenderer(Renderer r) {
		this.r = r;
		vv.setRenderer(r);
	}

	/**
	 * resets to the original renderer. Passes is to the VisualizationViewer
	 *
	 */
	public void resetRenderer() {
		this.r = originalRenderer;
		vv.setRenderer(r);
	}

	/** 
	 * getter for the original renderer
	 * @return the original renderer
	 */
	public SettableRenderer getRender() {
		return originalRenderer;
	}

	/**
	 * A passthrough to the function at <code>originalRenderer</code>.
	 * 
	 * @param c
	 *            the new edge color
	 */
	public void setEdgeColor(Color c) {
		originalRenderer.setEdgeColor(c);
	}

	/**
	 * A passthrough to the function at <code>originalRenderer</code>.
	 * 
	 * @param ecf
	 *            the new <code>EdgeColorFunction</code>
	 */
	public void setEdgeColorFunction(EdgeColorFunction ecf) {
		originalRenderer.setEdgeColorFunction(ecf);
	}

	/**
	 * A passthrough to the function at <code>originalRenderer</code>.
	 * 
	 * @param i
	 *            the thickness of the edge
	 */
	public void setEdgeThickness(int i) {
		originalRenderer.setEdgeThickness(i);
	}

	/**
	 * A passthrough to the function at <code>originalRenderer</code>.
	 * 
	 * @param etf
	 *            the new <code>EdgeThicknessFunction</code>
	 */
	public void setEdgeThicknessFunction(EdgeThicknessFunction etf) {
		originalRenderer.setEdgeThicknessFunction(etf);
	}

	/**
	 * A passthrough to the function at <code>originalRenderer</code>.
	 * 
	 * @param vertexColor
	 *            the new foreground color of the vertices
	 */
	public void setVertexForegroundColor(Color vertexColor) {
		originalRenderer.setVertexForegroundColor(vertexColor);
	}

	/**
	 * A passthrough to the function at <code>originalRenderer</code>.
	 * 
	 * @param vertexColor
	 *            the new picked color of the vertices
	 */
	public void setVertexPickedColor(Color vertexColor) {
		originalRenderer.setVertexPickedColor(vertexColor);
	}

	/**
	 * A passthrough to the function at <code>originalRenderer</code>.
	 * 
	 * @param vertexColor
	 *            the background color of the vertex that is to be set
	 */
	public void setVertexBGColor(Color vertexColor) {
		originalRenderer.setVertexBGColor(vertexColor);
	}

	/**
	 * A passthrough to the function at <code>originalRenderer</code>.
	 * 
	 * @param vcf
	 *            the new <code>VertexColorFunction</code>
	 */
	public void setVertexColorFunction(VertexColorFunction vcf) {
		originalRenderer.setVertexColorFunction(vcf);
	}

	/**
	 * Dynamically chooses a new GraphLayout.
	 * 
	 * @param l
	 *            the new graph layout algorithm
	 */
	public void setGraphLayout(Layout l) {
		this.layout = l;
		vv.setGraphLayout(l);
	}

	/**
	 * Returns the currently operative layout.
	 */
	public Layout getGraphLayout() {
		return layout;
	}

}
