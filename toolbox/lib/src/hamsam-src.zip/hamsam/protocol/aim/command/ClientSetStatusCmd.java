/*
 *
 * Hamsam - Instant Messaging API
 *
 * Copyright (C) 2003 Mike Miller <mikemil@users.sourceforge.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 */
package hamsam.protocol.aim.command;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;

import hamsam.protocol.aim.flap.FlapHeader;
import hamsam.protocol.aim.flap.FlapConstants;

import hamsam.protocol.aim.snac.SNACPacket;
import hamsam.protocol.aim.snac.SNACConstants;

import hamsam.protocol.aim.util.ByteUtils;
import hamsam.protocol.aim.util.TLV;
import hamsam.protocol.aim.util.TLVConstants;

/**
 * @author mikem
 */
public class ClientSetStatusCmd extends Command {


    private int modeFlags;
    private int statusFlags;

    // fields after the DC type in the Type 0x0C TLV
    private static final byte[] unknownFields = new byte[] {
      0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x50, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00};


    //~ Constructors -------------------------------------------------------------------------------
    /**
     *
     */
    public ClientSetStatusCmd(int seqNum, int statusflag) {
        flapHdr = new FlapHeader(FlapConstants.FLAP_CHANNEL_SNAC, seqNum);
        snacPacket = new SNACPacket(SNACConstants.SNAC_FAMILY_GENERIC_SERVICE_CONTROLS, SNACConstants.CLIENT_STATUS);

        statusFlags |= statusflag;
        byte[] flags = ByteUtils.getUInt( modeFlags | statusFlags );
        addTLV( new TLV(TLVConstants.TLV_TYPE_USER_STATUS_FLAGS, flags ) );

        // allocate bytes for the DC Info block
        byte[] dcinfo = new byte[ 0x25 ];

        InetAddress addr;
        try {
            addr = InetAddress.getLocalHost();
            byte[] ipAddr = addr.getAddress();
            System.arraycopy(ipAddr, 0, dcinfo, 0, ipAddr.length);
        } catch (UnknownHostException e) {
            // TODO Auto-generated catch block
        }
        
        
        dcinfo[8] = 0x04; // dc_type_normal
        System.arraycopy(unknownFields, 0, dcinfo, 9, unknownFields.length);

        addTLV( new TLV(TLVConstants.TLV_TYPE_DC_INFO, dcinfo) );


    }

    //~ Methods ------------------------------------------------------------------------------------

    /* (non-Javadoc)
     * @see hamsam.protocol.aim.command.Command#writeCommandData(java.io.OutputStream)
     */
    public void writeCommandData(OutputStream os) throws IOException {
    }
}


/*
 * $Log: ClientSetStatusCmd.java,v $
 * Revision 1.1  2003/09/20 03:23:45  mikemil
 * More implementation
 *
 */
