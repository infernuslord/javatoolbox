/* ====================================================================
 * Copyright (c) 2001-2003 OYOAHA. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. The names "OYOAHA" must not be used to endorse or promote products 
 *    derived from this software without prior written permission. 
 *    For written permission, please contact email@oyoaha.com.
 *
 * 3. Products derived from this software may not be called "OYOAHA",
 *    nor may "OYOAHA" appear in their name, without prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL OYOAHA OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.oyoaha.swing.plaf.oyoaha;

import java.io.*;
import java.util.*;
import javax.swing.*;

public class DebugOyoahaTheme extends OyoahaTheme
{
  protected DebugOyoahaConsole debug;

  public DebugOyoahaTheme(DebugOyoahaConsole _debug, File _file)
  {
    super(_file);
    debug = _debug;

    if(_file.isDirectory())
    {
      loader = new OyoahaFileThemeLoader(_debug, getClass().getClassLoader(), _file);
    }
    else
    if(!_file.getName().endsWith(".zotm"))
    {
      loader = new OyoahaFileThemeLoader(_debug, getClass().getClassLoader(), new File(_file.getParent()));
    }
  }

  protected void installUIDefaults(UIDefaults _defaults, Hashtable table)
  {
    if(!(loader instanceof OyoahaFileThemeLoader))
    {
      super.installUIDefaults(_defaults, table);
      return;
    }

    if(table==null)
    {
      debug.println("<font color=red>Empty table :(</font>");
      return;
    }

    debug.println("<hr>");
    debug.println("installUIDefaults from: <font color=blue>" + loader + "</font>");
    debug.println("<hr>");
    debug.println("");

    //object -> UIResourceObject
    checkForUIResource(table);

    //install
    Enumeration e = table.keys();

    while(e.hasMoreElements())
    {
      String s = (String)e.nextElement();
      int pos = s.indexOf('*');

      if(pos>=0)
      {
        Enumeration d = _defaults.keys();

        if(pos==0)
        {
          String end = s.substring(1,s.length());

          while(d.hasMoreElements())
          {
            String tmp = (String)d.nextElement();

            if(tmp.endsWith(end))
            {
            	_defaults.put(tmp, table.get(s));
            }
          }
        }
        else
        {
          String start = s.substring(0,pos);
          String end = s.substring(pos+1,s.length());

          while(d.hasMoreElements())
          {
            String tmp = (String)d.nextElement();

            if(tmp.startsWith(start) && tmp.endsWith(end))
            {
              _defaults.put(s, table.get(s));
              debug.println("<BR>put: <font color=blue>" + s + "</font> <font color=purple>" + table.get(s) + "</font>");
            }
          }
        }
      }
      else
      {
        debug.println("<BR>put: <font color=blue>" + s + "</font> <font color=purple>" + table.get(s) + "</font>");
        _defaults.put(s, table.get(s));
      }
    }
  }
}