/** ===================================================================
 *
 * L2FProd.com Common Components 0.1-dev License.
 *
 * Copyright (c) 2004 L2FProd.com.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by L2FProd.com
 *        (http://www.L2FProd.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "L2FProd.com Common Components", "l2fprod-common" and "L2FProd.com" must not
 *    be used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact info@L2FProd.com.
 *
 * 5. Products derived from this software may not be called "l2fprod-common"
 *    nor may "l2fprod-common" appear in their names without prior written
 *    permission of L2FProd.com.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL L2FPROD.COM OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package com.l2fprod.common.propertysheet;

import com.l2fprod.common.swing.IconPool;
import com.l2fprod.common.swing.LookAndFeelTweaks;
import com.l2fprod.common.swing.plaf.blue.BlueishButtonUI;
import com.l2fprod.common.util.ResourceManager;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.beans.BeanInfo;
import java.beans.PropertyChangeListener;
import java.beans.PropertyDescriptor;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.JEditorPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JToggleButton;
import javax.swing.UIManager;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 * PropertySheetPanel. <br>
 *  
 */
public class PropertySheetPanel extends JPanel implements PropertySheet {

  private PropertySheetTableModel model;
  private PropertySheetTable table;

  private JPanel actionPanel;
  private JToggleButton asCategoryButton;
  private JToggleButton descriptionButton;

  private JEditorPane descriptionPanel;

  public PropertySheetPanel() {
    model = new PropertySheetTableModel();
    buildUI();
  }

  /**
   * Toggles the visibility of the description panel.
   * 
   * @param visible
   */
  public void setDescriptionVisible(boolean visible) {
    descriptionPanel.setVisible(visible);
    descriptionButton.setSelected(visible);
    PropertySheetPanel.this.revalidate();
  }

  /**
   * Toggles the visibility of the toolbar panel
   * 
   * @param visible
   */
  public void setToolBarVisible(boolean visible) {
    actionPanel.setVisible(visible);
    PropertySheetPanel.this.revalidate();
  }

  public void setMode(int mode) {
    model.setMode(mode);
    asCategoryButton.setSelected(PropertySheet.VIEW_AS_CATEGORIES == mode);
  }

  public void setProperties(Property[] properties) {
    model.setProperties(properties);
  }

  public Property[] getProperties() {
    return model.getProperties();
  }

  public void setBeanInfo(BeanInfo beanInfo) {
    setProperties(beanInfo.getPropertyDescriptors());
  }

  public void setProperties(PropertyDescriptor[] descriptors) {
    Property[] properties = new Property[descriptors.length];
    for (int i = 0, c = descriptors.length; i < c; i++) {
      properties[i] = new PropertyDescriptorAdapter(descriptors[i]);
    }
    model.setProperties(properties);
  }

  public void readFromObject(Object data) {
    Property[] properties = model.getProperties();
    for (int i = 0, c = properties.length; i < c; i++) {
      ((Property)properties[i]).readFromObject(data);
    }
    repaint();
  }

  public void writeToObject(Object data) {
    Property[] props = getProperties();
    for (int i = 0, c = props.length; i < c; i++) {
      props[i].writeToObject(data);
    }
  }

  public void addPropertySheetChangeListener(PropertyChangeListener listener) {
    model.addPropertyChangeListener(listener);
  }

  public void removePropertySheetChangeListener(PropertyChangeListener listener) {
    model.removePropertyChangeListener(listener);
  }

  public PropertyEditorRegistry getEditorRegistry() {
    return table.getEditorRegistry();
  }

  private void buildUI() {
    LookAndFeelTweaks.setBorderLayout(this);
    LookAndFeelTweaks.setBorder(this);

    actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 0));
    actionPanel.setBorder(BorderFactory.createEmptyBorder(2, 0, 2, 0));
    add("North", actionPanel);

    asCategoryButton = new JToggleButton(new ToggleModeAction());
    asCategoryButton.setUI(new BlueishButtonUI());
    asCategoryButton.setText(null);
    actionPanel.add(asCategoryButton);

    descriptionButton = new JToggleButton(new ToggleDescriptionAction());
    descriptionButton.setUI(new BlueishButtonUI());
    descriptionButton.setText(null);
    actionPanel.add(descriptionButton);

    table = new PropertySheetTable(model);
    JScrollPane scroll = new JScrollPane(table);
    scroll.getViewport().setBackground(table.getBackground());
    add("Center", scroll);

    descriptionPanel = new JEditorPane("text/html", "<html>");
    descriptionPanel.setEditable(false);
    descriptionPanel.setBorder(
      LookAndFeelTweaks.addMargin(
        BorderFactory.createLineBorder(UIManager.getColor("controlDkShadow"))));
    descriptionPanel.setBackground(UIManager.getColor("Panel.background"));
    descriptionPanel.setPreferredSize(new Dimension(50, 50));
    LookAndFeelTweaks.htmlize(descriptionPanel);

    table
      .getSelectionModel()
      .addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        int row = table.getSelectedRow();
        if (row >= 0 && table.getRowCount() > row) {
          Object o = model.getPropertySheetElement(row);
          if (o instanceof Property) {
            descriptionPanel.setText(
              "<html>"
                + "<b>"
                + ((Property)o).getDisplayName()
                + "</b><br>"
                + ((Property)o).getShortDescription());
          } else {
            descriptionPanel.setText("<html>");
          }
        } else {
          descriptionPanel.setText("<html>");
        }
      }
    });

    add("South", descriptionPanel);

    // by default description is not visible, toolbar is visible.
    setDescriptionVisible(false);
    setToolBarVisible(true);
  }

  class ToggleModeAction extends AbstractAction {
    public ToggleModeAction() {
      super(
        "toggle",
        IconPool.shared().get(
          PropertySheet.class.getResource("icons/category.gif")));
      putValue(
        Action.SHORT_DESCRIPTION,
        ResourceManager.get(PropertySheet.class).getString(
          "PropertySheetPanel.category.shortDescription"));
    }
    public void actionPerformed(ActionEvent e) {
      if (asCategoryButton.isSelected()) {
        model.setMode(PropertySheet.VIEW_AS_CATEGORIES);
      } else {
        model.setMode(PropertySheet.VIEW_AS_FLAT_LIST);
      }
    }
  }

  class ToggleDescriptionAction extends AbstractAction {
    public ToggleDescriptionAction() {
      super(
        "toggleDescription",
        IconPool.shared().get(
          PropertySheet.class.getResource("icons/description.gif")));
      putValue(
        Action.SHORT_DESCRIPTION,
        ResourceManager.get(PropertySheet.class).getString(
          "PropertySheetPanel.description.shortDescription"));
    }
    public void actionPerformed(ActionEvent e) {
      descriptionPanel.setVisible(descriptionButton.isSelected());
      PropertySheetPanel.this.revalidate();
    }
  }
}
