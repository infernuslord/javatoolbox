/*
 * Created on Oct 8, 2004
 *
 */
package edu.uci.ics.jung.visualization.contrib;

import java.awt.Dimension;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import edu.uci.ics.jung.graph.Edge;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.utils.Pair;
import edu.uci.ics.jung.utils.UserData;
import edu.uci.ics.jung.visualization.AbstractLayout;
import edu.uci.ics.jung.visualization.Coordinates;
import edu.uci.ics.jung.visualization.Layout;

/**
 * Implementation of PersistentLayout.
 * Defers to another layout until 'restore' is called,
 * then it uses the saved vertex locations
 * 
 * @author Tom Nelson - RABA Technologies
 * 
 *  
 */
public class PersistentLayoutImpl implements PersistentLayout {

    /**
     * any layout to delegate to prior to restore
     */
    private Layout layout;

    /**
     * a container for Vertices
     */
    private Map map;

    /**
     * whether we are using the persisted layout
     */
    private boolean usingPersistedLocations;

    /**
     * a key for this class
     */
    private Object key;

    /**
     * a collection of Vertices that should not move
     */
    private Set dontmove;

    /**
     * whether the graph is locked (stops the VisualizationViewer rendering thread)
     */
    private boolean locked;

    private static final Object BASE_KEY = "edu.uci.ics.jung.Base_Visualization_Key";

    /**
     * create an instance with a passed layout
     * create containers for graph components
     * @param layout 
     */
    public PersistentLayoutImpl(Layout layout) {
        this.layout = layout;
        this.map = new HashMap();
        this.dontmove = new HashSet();
    }

    /**
     * This method calls <tt>initialize_local_vertex</tt> for each vertex, and
     * also adds initial coordinate information for each vertex. (The vertex's
     * initial location is set by calling <tt>initializeLocation</tt>.
     */
    protected void initializeLocations() {
        for (Iterator iter = layout.getGraph().getVertices().iterator(); iter
                .hasNext();) {
            Vertex v = (Vertex) iter.next();

            Coordinates coord = (Coordinates) v.getUserDatum(getBaseKey());
            if (coord == null) {
                coord = new Coordinates();
                v.addUserDatum(getBaseKey(), coord, UserData.REMOVE);
            }
            if (!dontmove.contains(v))
                initializeLocation(v, coord, layout.getCurrentSize());
            initialize_local_vertex(v);
        }
    }

    protected void initialize_local_vertex(Vertex v) {
    }

    /**
     * Sets persisted location for a vertex within the dimensions of the space.
     * If the vertex has not been persisted, sets a random location. If you want
     * to initialize in some different way, override this method.
     * 
     * @param v
     * @param coord
     * @param d
     */
    protected void initializeLocation(Vertex v, Coordinates coord, Dimension d) {
        double x;
        double y;
        Point point = (Point) map.get(new Integer(v.hashCode()));
        if (point == null) {
            x = Math.random() * d.getWidth();
            y = Math.random() * d.getHeight();
        } else {
            x = point.x;
            y = point.y;
        }
        coord.setX(x);
        coord.setY(y);
    }

    /**
     * save the Vertex locations to a file
     * @param fileName the file to save to	
     * @throws an IOException if the file cannot be used
     */
    public void persist(String fileName) throws IOException {
        Set set = getVisibleVertices();
        for (Iterator iterator = set.iterator(); iterator.hasNext();) {
            Vertex v = (Vertex) iterator.next();
            Point p = new Point(getX(v), getY(v));
            map.put(new Integer(v.hashCode()), p);
        }
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(
                fileName));
        oos.writeObject(map);
        oos.close();
    }

    /**
     * Restore the graph Vertex locations from a file
     * @param fileName the file to use
     * @throws IOException for file problems
     * @throws ClassNotFoundException for classpath problems
     */
    public void restore(String fileName) throws IOException,
            ClassNotFoundException {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(
                fileName));
        map = (Map) ois.readObject();
        ois.close();
        initializeLocations();
        usingPersistedLocations = true;
        locked = true;
    }

    public void lock(boolean locked) {
        this.locked = locked;
    }

    /*
     * (non-Javadoc)
     * 
     * @see edu.uci.ics.jung.visualization.Layout#initialize(java.awt.Dimension)
     */
    public void initialize(Dimension currentSize) {
        layout.initialize(currentSize);
    }

    /*
     * (non-Javadoc)
     * 
     * @see edu.uci.ics.jung.visualization.Layout#getX(edu.uci.ics.jung.graph.Vertex)
     */
    public double getX(Vertex v) {
        return layout.getX(v);
    }

    /*
     * (non-Javadoc)
     * 
     * @see edu.uci.ics.jung.visualization.Layout#getY(edu.uci.ics.jung.graph.Vertex)
     */
    public double getY(Vertex v) {
        return layout.getY(v);
    }

    /*
     * (non-Javadoc)
     * 
     * @see edu.uci.ics.jung.visualization.Layout#applyFilter(edu.uci.ics.jung.graph.Graph)
     */
    public void applyFilter(Graph subgraph) {
        layout.applyFilter(subgraph);
    }

    /*
     * (non-Javadoc)
     * 
     * @see edu.uci.ics.jung.visualization.Layout#getStatus()
     */
    public String getStatus() {
        return layout.getStatus();
    }

    /*
     * (non-Javadoc)
     * 
     * @see edu.uci.ics.jung.visualization.Layout#restart()
     */
    public void restart() {
        layout.restart();
    }

    /*
     * (non-Javadoc)
     * 
     * @see edu.uci.ics.jung.visualization.Layout#getVertex(double, double)
     */
    public Vertex getVertex(double x, double y) {
        return layout.getVertex(x, y);
    }

    /*
     * (non-Javadoc)
     * 
     * @see edu.uci.ics.jung.visualization.Layout#getVertex(double, double,
     *      double)
     */
    public Vertex getVertex(double x, double y, double maxDistance) {
        return layout.getVertex(x, y, maxDistance);
    }
    
	/**
	 * Gets the edge nearest to the location of the (x,y) location selected,
	 * within a distance of <tt>maxDistance</tt>, Iterates through all
	 * visible edges and checks their distance from the click. Override this
	 * method to provide a more efficient implementation.
	 * 
	 * @param x
	 * @param y
	 * @param maxDistance
	 * @return Edge closest to the click.
	 */
	public Edge getEdge(double x, double y, double maxDistance) {
	    return ((AbstractLayout)layout).getEdge(x, y, maxDistance);
	}
	
	/**
	 * Gets the edge nearest to the location of the (x,y) location selected.
	 * Calls the longer form of the call.
	 */
	public Edge getEdge(double x, double y) {
		return getEdge(x, y, Math.sqrt(Double.MAX_VALUE - 1000));
	}


    /*
     * (non-Javadoc)
     * 
     * @see edu.uci.ics.jung.visualization.Layout#getGraph()
     */
    public Graph getGraph() {
        return layout.getGraph();
    }

    /*
     * (non-Javadoc)
     * 
     * @see edu.uci.ics.jung.visualization.Layout#resize(java.awt.Dimension)
     */
    public void resize(Dimension d) {
        layout.resize(d);
    }

    /*
     * (non-Javadoc)
     * 
     * @see edu.uci.ics.jung.visualization.Layout#advancePositions()
     */
    public void advancePositions() {
        layout.advancePositions();
    }

    /*
     * (non-Javadoc)
     * 
     * @see edu.uci.ics.jung.visualization.Layout#isIncremental()
     */
    public boolean isIncremental() {
        return layout.isIncremental();
    }

    /*
     * (non-Javadoc)
     * 
     * @see edu.uci.ics.jung.visualization.Layout#incrementsAreDone()
     */
    public boolean incrementsAreDone() {
        return locked;
    }

    /*
     * (non-Javadoc)
     * 
     * @see edu.uci.ics.jung.visualization.Layout#lockVertex(edu.uci.ics.jung.graph.Vertex)
     */
    public void lockVertex(Vertex v) {
        dontmove.add(v);
        layout.lockVertex(v);
    }

    /*
     * (non-Javadoc)
     * 
     * @see edu.uci.ics.jung.visualization.Layout#unlockVertex(edu.uci.ics.jung.graph.Vertex)
     */
    public void unlockVertex(Vertex v) {
        dontmove.remove(v);
        layout.unlockVertex(v);
    }

    /**
     * Returns the Coordinates object that stores the vertex' x and y location.
     * 
     * @param v
     *            A Vertex that is a part of the Graph being visualized.
     * @return A Coordinates object with x and y locations.
     */
    public Coordinates getCoordinates(Vertex v) {
        return (Coordinates) v.getUserDatum(getBaseKey());
    }

    /*
     * (non-Javadoc)
     * 
     * @see edu.uci.ics.jung.visualization.Layout#forceMove(edu.uci.ics.jung.graph.Vertex,
     *      int, int)
     */
    public void forceMove(Vertex picked, int x, int y) {
        layout.forceMove(picked, x, y);
    }

    /*
     * (non-Javadoc)
     * 
     * @see edu.uci.ics.jung.visualization.Layout#getVisibleEdges()
     */
    public Set getVisibleEdges() {
        return layout.getVisibleEdges();
    }

    /*
     * (non-Javadoc)
     * 
     * @see edu.uci.ics.jung.visualization.Layout#getVisibleVertices()
     */
    public Set getVisibleVertices() {
        return layout.getVisibleVertices();
    }

    /*
     * (non-Javadoc)
     * 
     * @see edu.uci.ics.jung.visualization.Layout#getCurrentSize()
     */
    public Dimension getCurrentSize() {
        return layout.getCurrentSize();
    }

    /**
     * Returns a visualization-specific key (that is, specific to 
     * the layout in use) that can be used to access
     * UserData related to the <tt>AbstractLayout</tt>.
     */
    public Object getBaseKey() {
        if (key == null)
            key = new Pair(layout, BASE_KEY);
        return key;
    }

}