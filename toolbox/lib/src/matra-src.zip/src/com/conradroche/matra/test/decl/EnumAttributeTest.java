/*
 *   The contents of this file are subject to the Mozilla Public License
 *   Version 1.1 (the "License"); you may not use this file except in
 *   compliance with the License. You may obtain a copy of the License at
 *   http://www.mozilla.org/MPL/
 *
 *   Software distributed under the License is distributed on an "AS IS"
 *   basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 *   License for the specific language governing rights and limitations
 *   under the License.
 *
 *   The Original Code is Matra - the DTD Parser.
 *
 *   The Initial Developer of the Original Code is Conrad S Roche.
 *   Portions created by Conrad S Roche are Copyright (C) Conrad 
 *   S Roche. All Rights Reserved.
 *
 *   Alternatively, the contents of this file may be used under the terms
 *   of the GNU GENERAL PUBLIC LICENSE Version 2 or any later version
 *   (the  "[GPL] License"), in which case the
 *   provisions of GPL License are applicable instead of those
 *   above.  If you wish to allow use of your version of this file only
 *   under the terms of the GPL License and not to allow others to use
 *   your version of this file under the MPL, indicate your decision by
 *   deleting  the provisions above and replace  them with the notice and
 *   other provisions required by the GPL License.  If you do not delete
 *   the provisions above, a recipient may use your version of this file
 *   under either the MPL or the GPL License."
 *
 *   [NOTE: The text of this Exhibit A may differ slightly from the text of
 *   the notices in the Source Code files of the Original Code. You should
 *   use the text of this Exhibit A rather than the text found in the
 *   Original Code Source Code for Your Modifications.]
 *
 * Created: Conrad S Roche <derupe at users.sourceforge.net>,  23-Aug-2003
 */
package com.conradroche.matra.test.decl;

import java.util.ArrayList;

import junit.framework.Assert;

import com.conradroche.matra.data.DTDData;
import com.conradroche.matra.decl.Attribute;
import com.conradroche.matra.exception.DTDSyntaxException;
import com.conradroche.matra.test.util.AssertionUtil;
import com.conradroche.matra.test.util.DataValues;

/**
 * JUnit test case for the EnumAttributeTest class.
 * 
 * @author Conrad Roche
 */
public class EnumAttributeTest extends AttributeTest {

	/*
	 * Test Cases to check for
	 * I. Normal Conditions
	 * 
	 *  7. Enumeration (multiple values) + (#REQUIRED | #IMPLIED)		testEnumAttributes()
	 *  8. Enumeration (single value) + (#REQUIRED | #IMPLIED)			testSingleEnumAttributes()
	 *  CR: NOTE: Having FIXED values for EnumeratedType does not make sense to me! 
	 *  9. Enumeration + #FIXED + valid value
	 * 10. Enumeration + #FIXED + reference
	 * 11. Enumeration + valid value
	 * 12. Enumeration + reference
	 */

	/**
	 * Constructor for EnumAttributeTest.
	 * @param arg0
	 */
	public EnumAttributeTest(String arg0) {
		super(arg0);
	}

	/*
	 * @see AttributeTest#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
	}

	/**
	 * CR: JavaDoc: Add javadoc for EnumAttributeTest::checkEnumAttr
	 * 
	 * @param attr
	 * @param name
	 * @param optionality
	 */
	private void checkEnumAttr(Attribute attr, String name, String optionality) {
		
		Assert.assertEquals(name, attr.getAttributeName());
		Assert.assertEquals(Attribute.TYPE_ENUMERATION, attr.getAttType());
				
		//CR: TODO: This doesn't sound intuitive!
		Assert.assertNull(attr.getDataType());
				
		checkNonFixedOptionality(attr, optionality);
	}
	
	/**
	 * CR: JavaDoc: Add javadoc for EnumAttributeTest::buildEnumTypes
	 * 
	 * @param enum
	 * @return
	 */
	private String[] buildEnumTypes(String[] enum) {

		final String[] S = DataValues.getInstance().getSValues();
		
		//multiple element enumeration.
		//[59] Enumeration ::= '(' S? Nmtoken (S? '|' S? Nmtoken)* S? ')'
		//try (enum1  and ( S enum1
		StringBuffer sb1 = new StringBuffer("(");
		StringBuffer sb2 = new StringBuffer("(");
		StringBuffer sb3 = new StringBuffer("(");
		for(int i = 0; i < enum.length - 1; i++) {
			sb1.append(S[i % S.length] + enum[i] + S[i % S.length] + "|"); //(enum1 case
			sb2.append(S[(i + 1) % S.length] + enum[i] + S[i % S.length] + "|"); //( enum1 case
			sb3.append(S[(i + 2) % S.length] + enum[i] + S[i % S.length] + "|"); //( enum1 case
		}
		//add the last value
		sb1.append(enum[enum.length - 1] + " )"); //enumn ) case
		sb2.append(enum[enum.length - 1] + ")"); //enumn) case
		sb3.append(enum[enum.length - 1] + "\t)"); //enumn ) case
		
		String[] types = {sb1.toString(), sb2.toString(), sb3.toString()};
		return types;
	}
	
	/**
	 * CR: JavaDoc: Add javadoc for EnumAttributeTest::enumAttributeTest
	 * 
	 * @param enum
	 * @param isSingle
	 */
	private void enumAttributeTest(String[] enum, boolean isSingle) {
		
		final String[] defaults = {"#REQUIRED", "#IMPLIED"};
		
		String[] types = buildEnumTypes(enum);
		DTDData dData = buildAttrs(names, types, defaults);
		
		for(int i = 0; i < names.length; i++) {
		  for(int j = 0; j < types.length; j++) {
			for(int k = 0; k < defaults.length; k++) {
				
				try {
					attr.readNextAttribute(dData);
				} catch(DTDSyntaxException e) {
					fail("Caught syntax exception - " + e.getMessage());
				}

				checkEnumAttr(attr, names[i], defaults[k]);
				
				String[] s = attr.getEnumeratedValues();
				if(isSingle) {
					Assert.assertEquals(1, s.length);
					Assert.assertEquals(enum[j], s[0]);
				} else {
					AssertionUtil.assertEquals(enum, s);
				}
			} //for k
		  } //for j
		} //for i
	}
	
	/**
	 * CR: JavaDoc: Add javadoc for EnumAttributeTest::testEnumAttributes
	 */
	public void testEnumAttributes() {
	
		//mixed types
		final String[] enum = {"nmtoken", "123", "a", "0", "z34", ".", "-", "_", ":", ":-P"};
		enumAttributeTest(enum, false);
		fixedEnumTest(enum);
		
		//numbers only
		final String[] numerical = {"1", "9", "12", "53-", "6.7-", ".48-", "1.1", "0.12", ".06", "-10", "-1.23", "-0.0098", "-.54", "1234567890"};
		enumAttributeTest(numerical, false);
		fixedEnumTest(numerical);
		
		//alphabetical only
		final String[] alphabetical = {"a", "o", "a_yes", "my:value", "yes-no", "pi.value"};
		enumAttributeTest(alphabetical, false);
		fixedEnumTest(alphabetical);
		
		//symbols only
		final String[] symbols = {":-:", ".-:", ":::", "---------", "_.-"};
		enumAttributeTest(symbols, false);
		fixedEnumTest(symbols);
	}

	/**
	 * CR: JavaDoc: Add javadoc for EnumAttributeTest::buildSingleEnum
	 * 
	 * @param enum
	 * @return
	 */	
	private String[] buildSingleEnum(String[] enum) {
		
		final String[] S = {"", " ", "\t", "\r", "\n", " \t \n \r"};
	
		ArrayList typeList = new ArrayList();
		
		//one element enumeration!
		// '(' S? nmtoken S? ')'
		for(int i = 0; i < enum.length; i++) {
			typeList.add("(" + S[i % S.length] + enum[i] + S[i % S.length] + ")");
		}
		
		String[] types = (String[]) typeList.toArray(new String[0]);
		
		return types;
	}
	
	/**
	 * CR: JavaDoc: Add javadoc for EnumAttributeTest::testSingleEnumAttributes
	 */
	public void testSingleEnumAttributes() {
	
		String[] enum = {"nmtoken", "123", "a", "0", "z34", ".", "-", "_", ":",
						"1", "9", "12", "1.1", "0.12", ".06", "-10", "-1.23", "-0.0098", "-.54", "9999999",
						"a", "o", "a_yes", "my:value", "yes-no", "pi.value",
						":-:", ".-:", ":::", "---------", "_.-"};

		String[] types = buildSingleEnum(enum);

		enumAttributeTest(enum, true);
		fixedSingleEnumTest(enum);
		
		//another round
		enum = DataValues.getInstance().getNmTokenValues();
		enumAttributeTest(enum, true);
		fixedSingleEnumTest(enum);
	}

	/**
	 * CR: JavaDoc: Add javadoc for EnumAttributeTest::fixedEnumTest
	 * 
	 * @param enum
	 */	
	private void fixedEnumTest(String[] enum) {
		
		String[] types = buildEnumTypes(enum);
		
		ArrayList array = new ArrayList();
		final String[] quotes = { "\"", "'" }; 
		
		for(int i = 0; i < enum.length; i++) {
			for(int j = 0; j < quotes.length; j++) {
				array.add("#FIXED " + quotes[j] + enum[i] + quotes[j]);
			}
		}
		
		String[] defaults = (String[]) array.toArray(new String[0]);
		
		DTDData dData = buildAttrs(names, types, defaults);

		for(int i = 0; i < names.length; i++) {
		  for(int j = 0; j < types.length; j++) {
			for(int k = 0; k < defaults.length; k++) {
				
				try {
					attr.readNextAttribute(dData);
				} catch(DTDSyntaxException e) {
					fail("Caught syntax exception - " + e.getMessage());
				}

				checkFixedEnumAttr(enum);
			} //for k
		  } //for j
		} //for i
	}
	
	/**
	 * CR: JavaDoc: Add javadoc for EnumAttributeTest::checkFixedEnumAttr
	 * 
	 * @param enum
	 */
	private void checkFixedEnumAttr(String[] enum) {
		Assert.assertEquals(names, attr.getAttributeName());
		Assert.assertEquals(Attribute.TYPE_ENUMERATION, attr.getAttType());
				
		//CR: TODO: This doesn't sound intuitive!
		Assert.assertNull(attr.getDataType());
				
		checkFixedOptionality(attr);
				
		String[] s = attr.getEnumeratedValues();
		AssertionUtil.assertEquals(enum, s);
	}
	
	/**
	 * CR: JavaDoc: Add javadoc for EnumAttributeTest::fixedSingleEnumTest
	 * 
	 * @param enum
	 */
	private void fixedSingleEnumTest(String[] enum) {
		
		final String[] S = {" ", "\t", "\r", "\n", " \t \n \r"};
		final String[] quotes = { "\"", "'" }; 

		StringBuffer sb = new StringBuffer("");
		
		for(int i = 0; i < names.length; i++) {
			for(int j = 0; j < enum.length; j++) {
				for(int k = 0; k < quotes.length; k++) {
					sb.append(S[i % S.length]).append(names[i])
					  .append(S[i % S.length]).append("(").append(enum[j]).append(")")
					  .append(S[i % S.length]).append("#FIXED").append(S[i % S.length])
					  .append(quotes[k]).append(enum[j]).append(quotes[k]);
				}
			}
		}
		DTDData dData = new DTDData(sb.toString());
		
		for(int i = 0; i < names.length; i++) {
			for(int j = 0; j < enum.length; j++) {
				for(int k = 0; k < quotes.length; k++) {
					
					try {
						attr.readNextAttribute(dData);
					} catch(DTDSyntaxException e) {
						fail("Caught syntax exception - " + e.getMessage());
					}

					checkFixedSingleEnumAttr(enum[j]);
				}
			}
		}
	}
	
	/**
	 * CR: JavaDoc: Add javadoc for EnumAttributeTest::checkFixedSingleEnumAttr
	 * 
	 * @param enum
	 */
	private void checkFixedSingleEnumAttr(String enum) {
		Assert.assertEquals(names, attr.getAttributeName());
		Assert.assertEquals(Attribute.TYPE_ENUMERATION, attr.getAttType());
				
		//CR: TODO: This doesn't sound intuitive!
		Assert.assertNull(attr.getDataType());
				
		checkFixedOptionality(attr);
				
		String[] s = attr.getEnumeratedValues();
		Assert.assertEquals(1, s.length);
		Assert.assertEquals(enum, s[0]);
	}
}
