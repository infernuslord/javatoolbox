/*
 * Created on Apr 23, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package com.shfarr.ui;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JTextField;
import javax.swing.text.Document;

import com.shfarr.ui.layouts.QueueLayout;

public class FhActiveTextField extends JTextField{
    private FhSysButton more = null;
    private boolean interactionEnabled = true;

    public FhActiveTextField() {
        super();
        initialize();
    }

    public FhActiveTextField(int columns) {
        super(columns);
        initialize();
    }

    public FhActiveTextField(String text) {
        super(text);
        initialize();
    }

    public FhActiveTextField(String text, int columns) {
        super(text, columns);
        initialize();
    }

    public FhActiveTextField(Document doc, String text, int columns) {
        super(doc, text, columns);
        initialize();
    }

    public void setDocument(Document doc){
    	super.setDocument(doc);
        initialize();
    }

    private void initialize(){
        if(more == null){
            AllPurposeMouseAdapter apma = new AllPurposeMouseAdapter();
            
            more = new FhSysButton(FhSysIcon.MORE);
            more.setIcon(new FhSysIcon(FhSysIcon.MORE));
            
            more.setPreferredSize(new Dimension(more.getPreferredSize().width, 16));
            more.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
            more.setVisible(false);

            addMouseMotionListener(apma);
            addMouseListener(apma);

            more.addMouseListener(apma);
        }        
        
        setLayout(new QueueLayout(4, QueueLayout.HORIZONTAL, QueueLayout.STRECH_COMPONENTS));
        add(more, QueueLayout.END);
    }
    
    protected void processKeyEvent(KeyEvent ke){
        setInteractorShown(ke.isControlDown());
        super.processKeyEvent(ke);
    }

    public void setInteractionEnabled(boolean val){
        interactionEnabled = val; 
    }

    public boolean isInteractionEnabled(){
        return interactionEnabled;
    }
    
    public void addActionListener(ActionListener al){
        more.addActionListener(al);
    }

    public void removeActionListener(ActionListener al){
        more.removeActionListener(al);
    }

    protected void setInteractorShown(boolean val){
        more.setVisible(val);
        revalidate();
    }
    
    private class AllPurposeMouseAdapter implements MouseMotionListener, MouseListener{
        public void mouseDragged(MouseEvent e){
            if(!((Component)e.getSource()).isEnabled()) return;
            
            setInteractorShown(true);
        }

        public void mouseMoved(MouseEvent e){
            if(!((Component)e.getSource()).isEnabled()) return;
            
            setInteractorShown(true);
        }

        public void mouseClicked(MouseEvent e){
            if(!((Component)e.getSource()).isEnabled()) return;
            
            setInteractorShown(e.getSource() != FhActiveTextField.this);
        }

        public void mouseEntered(MouseEvent e){
            if(!((Component)e.getSource()).isEnabled()) return;
            
            setInteractorShown(true);
        }

        public void mouseExited(MouseEvent e){
            if(!((Component)e.getSource()).isEnabled()) return;
            
            setInteractorShown(false);
        }

        public void mousePressed(MouseEvent e){
            if(!((Component)e.getSource()).isEnabled()) return;
            
            setInteractorShown(e.getSource() != FhActiveTextField.this);
            grabFocus();
        }

        public void mouseReleased(MouseEvent e){
            if(!((Component)e.getSource()).isEnabled()) return;
            
            setInteractorShown(e.getSource() != FhActiveTextField.this);
        }
    }
}