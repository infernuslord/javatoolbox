package tool.pdf;

import java.io.IOException;
import java.io.File;
import java.io.PrintStream;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

import multivalent.ParseException;
import multivalent.std.adaptor.pdf.*;
import static multivalent.std.adaptor.pdf.COS.*;

import phelps.io.FileList;



/**
	Validate PDF integrity.
    Can also be run programmically by PDF generators to validate PDFs they just created.

	@version $Revision: 1.7 $ $Date: 2003/09/26 12:21:43 $
*/
public class Validate {
  static final boolean DEBUG = true;

  public static final String VERSION = "1.0.1 of $Date: 2003/09/26 12:21:43 $";
  public static final String USAGE = "java tool.pdf.Validate [options] <PDF-file...>\n"
	+ "\t[-fast] [-full] [-dev] [-password <password>]";

  public static final int LEVEL_QUICK = 0, LEVEL_FULL=1, LEVEL_DEVEL=2, LEVEL_DEVEL_WARNING=3, LEVEL_DEVEL_CONTENT=4;

  // required attributes
  //static final String[] ATTRS_ = {  };
  private static final String[] ATTRS_PAGES = { "Type", "Count", "Kids" };
  private static final String[] ATTRS_PAGE = { "Type", "Parent", "Resources", "MediaBox" };
  private static final String[] ATTRS_IMAGE = { "Width", "Height" };


  private List<String> errs_ = new ArrayList<String>(10);
  private String password_;
  private boolean frepairok_;
  private int level_;
  private boolean fverbose_, fquiet_, fmonitor_;
  private PrintStream out_;


  public Validate() {
	defaults();
  }

  public void defaults() {
	password_ = null;
	frepairok_ = false;
	level_ = LEVEL_DEVEL;

	fverbose_ = fquiet_ = fmonitor_ = false;
	out_ = phelps.io.PrintStreams.DEVNULL;
  }

  public void setLevel(int level) {
	assert LEVEL_QUICK<=level && level<=LEVEL_DEVEL_CONTENT;
	level_ = level;
  }

  public void setRepair(boolean b) { frepairok_ = b; }



  /** Returns true iff PDF valid. */
  public boolean validate(File file) throws IOException {
	if (fverbose_) System.out.println(file);
    assert file!=null && file.exists();

	errs_.clear();
	PDFReader pdfr = null;

	// LEVEL_QUICK: just open PDF (check for "%PDF-m.n", trailer, xref), catalog
	try { 
		pdfr = new PDFReader(file);
	} catch (ParseException pe) {
		err(-1, pe.toString()); return false;
	} catch (IOException ioe) { 
		System.err.println("Can't open "+file); throw ioe;
	} 
	pdfr.setExact(true);	// validing as is, not out cleaned up version
	pdfr.setPassword(password_);
	if (!pdfr.isAuthorized()) { System.err.println("invalid password "+file); return false; }
	Dict cat = pdfr.getCatalog();
	int objcnt = pdfr.getObjCnt();
	if (!frepairok_ && pdfr.isRepaired()) return false;
	// has "Pages", ...

	if (pdfr.getObjGen(0) != GEN_MAX) err(0, "generation must be "+GEN_MAX);


    // LEVEL_FULL: read each object
	Object o = null;
	/*if (errs_.isEmpty())*/ if (level_ >= LEVEL_FULL) {
		pdfr.fault();

		for (int i=0+1; i<objcnt; i++) {
			try {
				o = pdfr.getObject(i);
				if (CLASS_DICTIONARY==o.getClass() && ((Dict)o).get(STREAM_DATA) != null) {
					byte[] data = pdfr.getStreamData(new IRef(i,pdfr.getObjGen(i)), false, false);
				}

				//} catch (ParseException pe) {
				//	System.err.println("ParseException on object #"+i+": "+pe);
			} catch (/*IO*/Exception ioe) {	// IOException, ClassCastException
				ioe.printStackTrace();
				err(i, ioe.toString());
				System.out.println("#"+i+": "+o);
				break;
			}
		}
		if (!frepairok_ && pdfr.isRepaired()) return false;
	}

	if (errs_.isEmpty() && pdfr.isRepaired()) err(-1, file+" -- invalid but repairable (with tool.pdf.Repair)");


    // LEVEL_DEVEL
	if (errs_.isEmpty() && level_ >= LEVEL_DEVEL) validateDev(pdfr);


	pdfr.close();

	return errs_.isEmpty();
  }

  void validateDev(PDFReader pdfr) throws IOException {
	Object o;
	int objcnt = pdfr.getObjCnt();
    int pagecnt = pdfr.getPageCnt(); if (pagecnt==0) warn(-1, "No pages");

	//xref gen[0]==0xffff

	Dict trailer = pdfr.getTrailer();
    // accurate /Size in trailer
	if (trailer.get("Root")==null) err(-1, "No /Root in trailer");
	if ((o=trailer.get("Size"))==null) err(-1, "No /Size in trailer");
	else if (CLASS_INTEGER!=o.getClass()) err(-1, "/Size in trailer not direct integer");
	else { int size = ((Number)o).intValue(); if (size != objcnt) err(-1, "Wrong /Size in trailer: "+size+" should be "+objcnt); }

	Dict cat = pdfr.getCatalog();
	if (cat.get("Pages")==null) warn(-1, "No /Pages in catalog");

	Dict info = pdfr.getInfo(); 
	if (info==null) warn(-1, "No /Info with metadata in trailer");


	// refcnt to find unused objects
	// ...

	for (int i=0; i<pagecnt; i++) {
		IRef pageref = pdfr.getPageRef(i+1);
		Dict page = pdfr.getPage(i+1);	// fills in inherited
		requiredAttrs(pageref.id, page, ATTRS_PAGE);

	}

	for (int i=0; i<objcnt; i++) {	// loop over objects or walk trees?
		o = pdfr.getObject(i);
		if (CLASS_DICTIONARY!=o.getClass()) continue;
		Dict dict = (Dict)o;

		String type = (String)dict.get("Type"), subtype = (String)dict.get("Subtype");
		if ("Pages".equals(type)) {
			requiredAttrs(i, dict, ATTRS_PAGES);

		} else if ("Page".equals(type)) {
			//requiredAttrs(i, dict, ATTRS_PAGE); => after inherited
			if (dict.get("Contents")==null) warn(i, "/Page without /Contents");
			
		} else if (("XObject".equals(type) || null==type) && "Image".equals(subtype)) {
			requiredAttrs(i, dict, ATTRS_IMAGE);


		} else if (("XObject".equals(type) || null==type) && "Image".equals(subtype)) {
		}
	}
  }

  private void requiredAttrs(int objnum, Dict dict, String[] attrs) {
	boolean fok = true;
	for (int i=0,imax=attrs.length; i<imax; i++) {
		String attr = attrs[i];
		if (dict.get(attr) == null) err(objnum, "missing attr '"+attr+"'");
	}
  }



  private void err(int objnum, String msg) {
	//if (out_==null) return;
    out_.print("ERROR");
	if (objnum >= 0) out_.print(".  object #"+objnum);
	out_.println(": "+msg);
  }
  private void warn(int objnum, String msg) {
    if (level_ < LEVEL_DEVEL_WARNING/* || out_==null*/) return;
    out_.print("WARNING.  ");
	if (objnum >= 0) out_.print(" object #"+objnum);
	out_.println(": "+msg);
  }



  private int commandLine(String[] argv) {
    level_ = LEVEL_FULL;	// interactive default is different from programmatic
	out_ = System.out;

	int argi = 0, argc = argv.length;
	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.equals("-fast") || arg.equals("-quick")) level_ = LEVEL_QUICK;
		else if (arg.equals("-full")) level_ = LEVEL_FULL;
		else if (arg.startsWith("-dev"/*"eloper"*/)) level_ = LEVEL_DEVEL;
		else if (arg.startsWith("-rep"/*airok*/)) setRepair(true);
		else if (arg.startsWith("-pass"/*"word"*/)) password_ = argv[++argi];

		else if (arg.startsWith("-verb")) fverbose_ = true;
		//else if (arg.startsWith("-q"/*uiet*/)) fquiet = true;
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.startsWith("-h"/*"elp"*/)) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}
	if (LEVEL_DEVEL==level_ && fverbose_) level_ = LEVEL_DEVEL_WARNING;

	if (argi == argc) { System.err.println(USAGE); System.exit(0); }

	return argi;
  }

  public static void main(String[] argv) {
	Validate v = new Validate();
    int argi = v.commandLine(argv);

	for (Iterator<File> i = new FileList(argv, argi, FILTER).iterator(); i.hasNext(); ) {
		File file = i.next();
		try {
			//if (fquiet_) System.out.println(file);
			v.validate(file);
		} catch (Exception ioe) {
			System.err.println(file+": "+ioe);
			if (DEBUG) ioe.printStackTrace();
		}
	}
  }
}
