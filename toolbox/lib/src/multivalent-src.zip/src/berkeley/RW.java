package berkeley;

import java.io.*;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.FontMetrics;
import java.util.*;

import multivalent.*;
import multivalent.node.Root;
import multivalent.devel.Debug;


/**
	RW-specific tweaks.

	<ul>
	<li>("wipeAnnos" - moved to Annos.java)
	</ul>

	@version $Revision: 1.2 $ $Date: 2003/02/09 01:07:03 $
*/
public class RW extends Behavior {
  public boolean semanticEventBefore(SemanticEvent se, String msg) {
	if (super.semanticEventBefore(se,msg)) return true;
	else if (Debug.MSG_CREATE_DEBUG==msg) {
		INode menu = (INode)se.getOut();
		//createUI("button", "Wipe Annos from All Pages", "event wipeAnnos", menu, null, true); => in core now
	}
	return super.semanticEventBefore(se,msg);
  }


  public boolean semanticEventAfter(SemanticEvent se, String msg) {
	Browser br = getBrowser();
/*
	Node n=null; int offset=-1;
	INode p=null;
	Context cx;
	Span sel = br.getSelectionSpan();
	Span curspan = br.getCursorMark();
	Root curroot = (curspan.isSet()?curspan.getStart().node.getRoot():br.getRoot());
*/

	if ("wipeAnnosXXX"==msg) {
		br.getCurDocument().getLayer(Layer.PERSONAL).clear();
		br.eventq(Document.MSG_OPEN, null);
	} else if ("wipeAllAnnosXXX"==msg) {
	}

	return super.semanticEventAfter(se,msg);
  }
}
