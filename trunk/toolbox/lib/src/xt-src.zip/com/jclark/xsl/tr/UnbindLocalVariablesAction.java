// $Id: UnbindLocalVariablesAction.java,v 1.1 2002/04/25 18:19:49 bill Exp $

package com.jclark.xsl.tr;

import com.jclark.xsl.om.*;
import com.jclark.xsl.expr.VariantExpr;

/**
 *
 */
class UnbindLocalVariablesAction implements Action
{
    private final int n;

    UnbindLocalVariablesAction(int n)
    {
        this.n = n;
    }

    public void invoke(ProcessContext context, 
                       Node sourceNode, 
                       Result result)
    {
        context.unbindLocalVariables(n);
    }
}
