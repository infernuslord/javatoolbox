/*
  Copyright (C) 2003-2004 Robert F. Beeger (robert at beeger dot net)
  Licensed under the Academic Free License version 2.0
  OSI Certified Open Source Software

  Visit http://squareness.sourceforge.net/ for new releases of Squareness Look And Feel and other
  skins from the Squareness series.
*/
package net.beeger.squareness.util;

import java.awt.Font;
import javax.swing.plaf.FontUIResource;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.metal.DefaultMetalTheme;
import javax.swing.UIManager;

import net.beeger.squareness.SquarenessConstants;

public class SquarenessMetalTheme extends DefaultMetalTheme
{
  public FontUIResource getControlTextFont ()
  {
    if (_controlTextFont == null)
    {
      _controlTextFont = new FontUIResource("Dialog", Font.PLAIN, 11);
    }
    return _controlTextFont;
  }

  public FontUIResource getMenuTextFont ()
  {
    if (_menuTextFont == null)
    {
      _menuTextFont = new FontUIResource("Dialog", Font.PLAIN, 11);
    }
    return _menuTextFont;
  }

  public FontUIResource getSubTextFont ()
  {
    if (_subTextFont == null)
    {
      _subTextFont = new FontUIResource("Dialog", Font.PLAIN, 9);
    }
    return _subTextFont;
  }

  public FontUIResource getSystemTextFont ()
  {
    if (_systemTextFont == null)
    {
      _systemTextFont = new FontUIResource("Dialog", Font.PLAIN, 11);
    }
    return _systemTextFont;
  }

  public FontUIResource getUserTextFont ()
  {
    if (_userTextFont == null)
    {
      _userTextFont = new FontUIResource("Dialog", Font.PLAIN, 11);
    }
    return _userTextFont;
  }

  public FontUIResource getWindowTitleFont ()
  {
    if (_windowTitleFont == null)
    {
      _windowTitleFont = new FontUIResource("Dialog", Font.BOLD, 11);
    }
    return _windowTitleFont;
  }

  // these are blue in Metal Default Theme
  protected ColorUIResource getPrimary1 ()
  {
    return new ColorUIResource(34, 57, 73);
  }

  protected ColorUIResource getPrimary2 ()
  {
    return new ColorUIResource(211, 211, 42);
  }

  protected ColorUIResource getPrimary3 ()
  {
    return new ColorUIResource(211, 211, 42);
  }

  // these are gray in Metal Default Theme
  protected ColorUIResource getSecondary1 ()
  {
    return new ColorUIResource(34, 57, 73);
  }

  protected ColorUIResource getSecondary2 ()
  {
    return new ColorUIResource(134, 144, 150);
  }

  protected ColorUIResource getSecondary3 ()
  {
    return new ColorUIResource(247,242,225);
  }

  private FontUIResource _controlTextFont;
  private FontUIResource _menuTextFont;
  private FontUIResource _subTextFont;
  private FontUIResource _systemTextFont;
  private FontUIResource _userTextFont;
  private FontUIResource _windowTitleFont;
}

/*
  $Log: SquarenessMetalTheme.java,v $
  Revision 1.4  2004/03/07 16:49:22  rbeeger
  Added primary and secondary colors for Metal aware applications that use them.

  Revision 1.3  2004/02/14 19:12:35  rbeeger
  Updated copyright statement
  Added cvs log directive at the end of each file
  Optimized imports
  Reformated code

 */
