// $Id: StringFunction.java,v 1.1 2002/04/25 18:11:38 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

class StringFunction extends FunctionOpt1 {
    ConvertibleExpr makeCallExpr(ConvertibleExpr e) throws ParseException {
        return e.makeStringExpr();
    }
}
