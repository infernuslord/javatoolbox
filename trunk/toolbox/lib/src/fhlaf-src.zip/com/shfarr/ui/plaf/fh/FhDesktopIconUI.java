/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh;

import java.awt.*;
import javax.swing.*;
import javax.swing.plaf.*;
import javax.swing.plaf.basic.*;

import com.shfarr.ui.plaf.fh.textures.Texture;
import com.shfarr.ui.plaf.fh.theme.ThemeManager;

import java.beans.PropertyChangeListener;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeEvent;


public class FhDesktopIconUI extends BasicDesktopIconUI{
    private JButton button;
    private TitleListener titleListener;
    private int width;

    public FhDesktopIconUI() {
    	super();
    }


    public static ComponentUI createUI(JComponent cmp){
      return new FhDesktopIconUI();
    }


    public Dimension getMaximumSize(JComponent c) { 
        return getMinimumSize(c);
    }


    public Dimension getMinimumSize(JComponent c) { 
        return new Dimension(width, desktopIcon.getLayout().minimumLayoutSize(desktopIcon).height);
    }


    public Dimension getPreferredSize(JComponent c) {
        return getMinimumSize(c);
    }


    protected void installComponents() {
    	frame = desktopIcon.getInternalFrame();
    	Icon icon = frame.getFrameIcon();
    	String title = frame.getTitle();
    
    	button = new JButton (title, icon);
    	button.addActionListener(new ActionListener() {
        	                           public void actionPerformed(ActionEvent e) {
                                          deiconize(); 
                                       }
    	                             }
                                 );
    	button.setFont(desktopIcon.getFont());
    	button.setBackground(desktopIcon.getBackground());
    	button.setForeground(desktopIcon.getForeground());
    
    	int buttonH = button.getPreferredSize().height;
    	button.setDefaultCapable(false);
    
    	desktopIcon.setLayout(new BorderLayout(0, 0));
    	desktopIcon.add(button, BorderLayout.CENTER);
    }


    protected void installDefaults() {
        super.installDefaults();
        LookAndFeel.installColorsAndFont(desktopIcon, "DesktopIcon.background", "DesktopIcon.foreground", "DesktopIcon.font");
	    desktopIcon.setOpaque(true);
        width = UIManager.getInt("DesktopIcon.width");
    }


    protected void installListeners() {
        super.installListeners();
        desktopIcon.getInternalFrame().addPropertyChangeListener(
                titleListener = new TitleListener());
    }


    public void paint(Graphics g, JComponent c) {
      ThemeManager.instance().probeAntialiasing(g);

      super.paint(g, c);

	  Texture texture = (Texture)UIManager.getDefaults().get("DesktopIcon.texture");
	  if(texture != null && ThemeManager.instance().probeSmallTextures()) texture.apply(new Rectangle(0, 0, c.getSize().width, c.getSize().height), (Graphics2D)g, c);
    }


    protected void uninstallComponents() {
	desktopIcon.setLayout(null);
	desktopIcon.remove(button);
        button = null;
        frame = null;
    }


    protected void uninstallListeners() {
        desktopIcon.getInternalFrame().removePropertyChangeListener(
                titleListener);	
        titleListener = null;
        super.uninstallListeners();
    }


    /**
     * @version test 1.0
     * @author Stefan H. Farr
     * This software is published under the terms of General Public License
     */
    class TitleListener implements PropertyChangeListener{
        public void propertyChange(PropertyChangeEvent e){
      	  if(e.getPropertyName().equals("title")) button.setText((String)e.getNewValue());
      	  if(e.getPropertyName().equals("frameIcon")) button.setIcon((Icon)e.getNewValue());
    	}
    }
}
