package tool;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.MalformedURLException;

import multivalent.*;
import multivalent.node.FixedI;
import multivalent.node.LeafText;

import phelps.io.InputStreamCached;
import phelps.lang.Integers;



/**
	Convert document pages into images.
	Target image type can be anything supported by Java: JPEG, PNG;
	or if you have Image I/O installed, also JPEG2000, BMP, ....

	@version $Revision$ $Date$
*/
public class PageImages {
  static final boolean DEBUG = true;

  public static final String USAGE = "java tool.PageImages [-page <range>] [-format img] <file...>";
  public static final String VERSION = "0.1";

  public static void main(String[] argv) throws IOException {
  }
}
