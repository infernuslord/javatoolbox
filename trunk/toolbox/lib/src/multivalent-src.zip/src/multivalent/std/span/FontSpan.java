package multivalent.std.span;

import java.util.Map;

import multivalent.*;

import phelps.lang.Integers;
import phelps.lang.Floats;



/**
	Convenience span for setting font properties: family, size, style.
	Applications should usually instead use a generic {@link multivalent.Span} with a name, and set display properties in the stylesheet.

	@version $Revision: 1.1 $ $Date: 2002/02/02 13:16:26 $
*/
public class FontSpan extends Span {
  public static final String ATTR_FAMILY = "family";
  public static final String ATTR_SIZE = "size";
  public static final String ATTR_STYLE = "style";


  /** Family name, or null to disable. */
  public String family=null;
  /** Size in logical points.  Set to -1 to disable. */
  public float size = -1f;
  /** OR of Font.BOLD, Font.ITALIC, and Font.PLAIN; or -1 to disable. */
  public int style = -1;


  public boolean appearance(Context cx, boolean all) {
	if (family!=null) cx.family=family;
	if (size > 0.0) cx.size = size;
	if (style > 0) cx.style = style;
	return false;
  }

  public ESISNode save() {
	putAttr(ATTR_FAMILY, family); // if null, removed
	if (size>0.0) putAttr(ATTR_SIZE, Float.toString(size));
	if (style >= 0) putAttr(ATTR_STYLE, Integer.toString(style));  // later symbolic
	return super.save();
  }

  public void restore(ESISNode n, Map<String,Object> attr, Layer layer) {
	super.restore(n,attr,layer);

	family = getAttr(ATTR_FAMILY, null);
	size = Floats.parseFloat(getAttr(ATTR_SIZE), 0.0f);
	style = Integers.parseInt(getAttr(ATTR_STYLE), -1);
  }
}
