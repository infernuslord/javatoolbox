package phelps.awt.font;

import java.awt.Font;
import java.awt.font.*;
import java.io.*;

import multivalent.std.adaptor.pdf.PostScript;



/**
	Adobe Type 1 (www.adobe.com/...) utilities.
	See "Adobe Type 1 Font Format".

<!--
	Simply convert to OpenType.
-->
	Constructors: (1) data file + AFM file, (2) data stream + explicit data (as embedded in PDF)

	@version $Revision: 1.3 $ $Date: 2003/06/03 20:42:59 $
*/
public class Type1 {
  static final int R_EEXEC = 55665, R_CHARSTRING = 4330;

  //byte[] data_;


  public Type1(byte[] data) throws InstantiationException, IOException {
    assert data!=null && data.length>0;  

	//data_ = data;

	// standard or compact?
	if (data[0]=='%') parse(data);
	//else if (data[0]=='x' && data[1]=='y') parseCCF(data);
	else throw new InstantiationException("not a Type 1 font (font does not start with '%' or CCF header)");
  }

  private void parse(byte[] data) throws IOException {
	ByteArrayInputStream bis = new ByteArrayInputStream(data);
	PushbackInputStream pis  = new PushbackInputStream(bis, 5);
	// LATER: parse plaintext (up to "eexec")
    Object o;
    
	int clen=0, elen=0;
	bis.skip(clen);
	decrypt(R_EEXEC, data, clen, elen);

	// n=4, unless overridden by /Private /lenIV
	bis.skip(4);	// random bytes

	// decrypt CharStrings
	while ((o = PostScript.readObject(pis)) != null) {
		System.out.println(o);
		if ("Subrs".equals(o)) {
			int cnt = ((Number)PostScript.readObject(pis)).intValue();
			PostScript.readObject(pis);	// "array"
			PostScript.readObject(pis);	// "dup"
			int posn = ((Number)PostScript.readObject(pis)).intValue();
			int cslen = ((Number)PostScript.readObject(pis)).intValue();
			byte[] csb = new byte[cslen], newcsb = null;
			decrypt(R_CHARSTRING, csb, 0, csb.length);
			//xxx[posn] = new byte[cslen - 4]; System.arraycopy(csb,4, newcsb,0, cslen-4);			
			PostScript.readObject(pis);	// "NP"
		}
	}
    bis.close();

	// ignore trailing zeros
  }

  public static byte[] decrypt(byte[] data, int clen, int elen, int zlen) {
	assert data!=null && data.length > 0 && clen>0 && elen>0 && zlen>=0: data;
	byte[] b = new byte[clen + elen];
    System.arraycopy(data,0, b,0, clen+elen);		// remove zlen

	// LATER: verify "eexec"
	decrypt(R_EEXEC, b, clen, elen);
	for (int j=0; j<4; j++) b[clen+j] = (byte)' ';	// wipe random bytes

	// look for "RD" preceded by a number
	for (int i=clen, imax=i+elen - 1, c; i<imax; i++) {
		if (b[i]=='R' && b[i+1]=='D' && b[i-1]==' ' && (c=b[i-2])>='0' && c<='9') {
			int cnt = c-'0'; for (int j=i-3, mul=10; ; j--, mul*=10) if ((c=b[j])>='0' && c<='9') cnt += (c - '0')*mul; else break;
			//System.out.print(cnt+" ");
			i+=3; // "RD "
			decrypt(R_CHARSTRING, b, i, cnt);
			for (int j=0; j<4/*lenIV*/; j++) b[i+j] = (byte)' ';	// wipe random bytes
			i+= cnt;
		}
	}

	return b;
  }

  public static byte[] encrypt(byte[] data, int clen, int elen, int zlen) {
	assert data!=null && data.length >= clen+elen && clen>0 && elen>0 && zlen>=0: data.length;
	byte[] b = new byte[clen + elen + zlen];
    System.arraycopy(data,0, b,0, clen+elen);	// put back zlen if requested (which PDFWriter does not)

	for (int i=clen, imax=i+elen - 1, c; i<imax; i++) {
		if (b[i]=='R' && b[i+1]=='D' && b[i-1]==' ' && (c=b[i-2])>='0' && c<='9') {
			int cnt = c-'0'; for (int j=i-3, mul=10; ; j--, mul*=10) if ((c=b[j])>='0' && c<='9') cnt += (c - '0')*mul; else break;
			i+=3;
			encrypt(R_CHARSTRING, b, i, cnt);
			i+= cnt;
		}
	}

	encrypt(R_EEXEC, b, clen, elen);

	//if (zlen >= ZLEN_MIN && b[clen+elen) == 0) write new 00000\ncleartomark\n

	return b;
  }

  private static void decrypt(int r, byte[] b, int off, int len) {
	final int c1 = 52845, c2 = 22719;

	for (int i=off, imax=off+len; i<imax; i++) {
		int cipher = b[i]&0xff;
		b[i] = (byte)(cipher ^ (r>>8));
		r = ((cipher + r) * c1 + c2) & 0xffff;
	}
  }

  private static void encrypt(int r, byte[] b, int off, int len) {
	final int c1 = 52845, c2 = 22719;

	for (int i=off, imax=off+len; i<imax; i++) {
		int plain = b[i]&0xff;
		int cipher = (plain ^ (r>>8)) & 0xff;
		b[i] = (byte)cipher;
		r = ((cipher + r) * c1 + c2) & 0xffff;
	}
  }


  private void parseCCF() {
  }



  public void disassemble() {
  }


  /**
	Returns Type 1 font, with necessary encryption.
  */
  public byte[] export() {
	return null;
  }

  /** Returns Type 1 font, with necessary encryption, in "compact font format" (CCF). */
  public byte[] exportCCF() {
	return null;
  }

  /** Returns TrueType conversion. */
  public byte[] exportTrueType() {
	return null;
  }
}
