package se.diod.hippo.setup;


import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.UnsupportedLookAndFeelException;




/**
 * 
 * @author Robert Karlsson
 * @created 2003-okt-26
 *
 */
public class InstallLF {
	private static final String HIPPOLF_URL = "se.diod.hippo.plaf.HippoLookAndFeel";




	/**
	 * 
	 * Installs HippoLF
	 *
	 */
	public static String install( boolean defaultLnF, JFrame aFrame ) {
		boolean found 	= false;

		LookAndFeelInfo[] PLAFinfo = getInstalledPLAFs();
		for( int pos = 0; pos < PLAFinfo.length; pos++ ) {
			if( PLAFinfo[ pos ].getName().equals( "Hippo" )  ) {
				found = true;
			}
		}

		// If LnF is not found, install it..
		if( !found ) {
			UIManager.installLookAndFeel( "Hippo", HIPPOLF_URL );
		}


		// If LnF is set to default, activate it..
		if( defaultLnF ) {
			try {
				UIManager.setLookAndFeel( HIPPOLF_URL );
			} catch( ClassCastException e ) {
				return "[ClassCastException][SetupHippoPLAF::install(..)]" + e;
			} catch( ClassNotFoundException e ) {
				return "[ClassNotFoundException][SetupHippoPLAF::install(..)]" + e;
			} catch( UnsupportedLookAndFeelException e ) {
				return "[UnsupportedLookAndFeelException][SetupHippoPLAF::install(..)]" + e;
			} catch( InstantiationException e ) {
				return "[InstantiationException][SetupHippoPLAF::install(..)]" + e;
			} catch( IllegalAccessException e ) {
				return "[IllegalAccessException][SetupHippoPLAF::install(..)]" + e;
			};

			refreshUI( aFrame );
		}

		return "OK";
	}




	/**
	 * 
	 * Refresh HippoLF ComponentTreeUI
	 *
	 */
	protected static void refreshUI( JFrame aFrame ) {
		SwingUtilities.updateComponentTreeUI( aFrame );
	}




	/**
	 * 
	 * Retrieves the installed PLAFs
	 *
	 */
	protected static LookAndFeelInfo[] getInstalledPLAFs() {
		return UIManager.getInstalledLookAndFeels();
	}
}
