package phelps.lang;

import java.util.StringTokenizer;



/**
	Extensions to {@link java.lang.Integer}.

	<ul>
	<li>parsing with default value: {@link #parseInt(String, int)}
	<li>number ranges: {@link #toRange(int[])}, {@link #parseRange(String, int)}
	<li>possible object sharing: {@link #getInteger(int)}
	<li>formatting: {@link #toRomanString(int)}
	<li>algorithms: {@link #countOneBits(int)}
	</ul>

	@version $Revision: 1.4 $ $Date: 2003/10/01 13:21:29 $
*/
public class Integers {
  public static final Integer ZERO = new Integer(0);
  public static final Integer ONE = new Integer(1);
  //public static final Integer NEGATIVE_ONE = Integers.getInteger(-1);


  // cache of common, immutable, primitive-ish objects
  private static final int INTS_MIN=-100, INTS_MAX=1000;  // (4ref + 4val + 4objwrap) * 1100 = >12K
  //int[] ihist =  new int[INTS_MAX - INTS_MIN + 1];
  private static /*final--lazy /*const*/ Integer[] INTS = null;
  //static { for (int i=0, imax=INTS.length, val=INTS_MIN; i<imax; val++, i++) INTS[i]=new Integer(val); } => don't immediate give gc a 1000 objects to manage

  private static final int STRS_MIN=-10, STRS_MAX=100;
  private static /*final--lazy /*const*/ String[] STRS = null;

  private static String[] roman_ = {
	"(no zero)", "I","II","III","IV","V","VI","VII","VIII","IX",
	"X", "XI","XII","XIII","XIV","XV","XVI","XVII","XVIII","XIX",
	"XX", "XXI","XXII","XXIII","XXIV","XXV","XXVI","XXVII","XXVIII","XXIX",
	"XXX", "XXXI","XXXII","XXXIII","XXXIV","XXXV","XXXVI","XXXVII","XXXVIII","XXXIX",
	"XL", "XLI","XLII","XLIII","XLIV","XLV","XLVI","XLVII","XLVIII","XLIX",
   };

  private static byte[] bitcnt = new byte[256];
  static {
	bitcnt[0]=0;
	for (int base=1; base<256; base*=2) {
		for (int i=0; i<base; i++) bitcnt[base+i] = (byte)(bitcnt[i] + 1);
	}
  }


  private Integers() {}


  /**
	Tries to parse <var>value</var> as an <code>int</code>,
	but if String is <code>null</code> or can't be parsed as an <code>int</code> returns <var>defaultval</var> .
  */
  public static int parseInt(String value,/* int radix, */ int defaultval) {
	if (value==null) return defaultval;
	try { return Integer.parseInt(value.trim()); } catch (NumberFormatException e) { return defaultval; }
  }


  /** Caches {@link java.lang.Integer} objects, so the 1000s of instances of 0 all share the same Java object. */
  public static Integer getInteger(int val) {
	//return INTS_MIN<=val && val<=INTS_MAX? INTS[val - INTS_MIN]: new Integer(val);
	Integer into;
	if (INTS_MIN<=val && val<=INTS_MAX) {
		if (INTS==null) { INTS = new Integer[(int)(INTS_MAX - INTS_MIN + 1/*including 0*/)]; INTS[-INTS_MIN] = ZERO; INTS[-INTS_MIN+1] = ONE; }

		into = INTS[val - INTS_MIN];
		if (into==null) into = INTS[val - INTS_MIN] = new Integer(val);
	} else into = new Integer(val);

	return into;
  }
//if (INTS_MIN<=val && val<=INTS_MAX) ihist[val-INTS_MIN]++;


  /**
	Returns Roman numeral representation of numbers >0 && <=4000 (no numbers which require a bar to multiply by 1000).
	Numeral returned in uppercase; client can convert to lowercase.
	Numbers <0 or >=4000 are returned in Arabic.
	Used by HTML OL.
  */
  public static String toRomanString(int val) {   // like toHexString
	//assert => return Arabic
	if (val<=0 || val>=4000) /*throw NumberFormatException()*/return Integer.toString(val);

	if (val<roman_.length) return roman_[val];  // fast path for small numbers -- no object creation

	// i=1, v=5, x=10, l=50, c=100, d=500, m=1000, bar=multiply by 1000, no 0
	StringBuffer rn = new StringBuffer(10);
	while (val>=1000) { rn.append('M'); val-=1000; }
	if (val>=900) { rn.append("CM"); val-=900; }
	if (val>=500) { rn.append('D'); val-=500; }
	if (val>=400) { rn.append("CD"); val-=400; }
	while (val>=100) { rn.append('C'); val-=100; }
	if (val>=90) { rn.append("XC"); val-=90; }
	if (val>=50) { rn.append('L'); val-=50; }
	assert roman_.length >= 50;
	//if (val>=40) { rn.append("XL"); val-=40; }
	//while (val>=10) { rn.append('X'); val-=10; }
	//if (val>0) rn.append(roman_[val]);
	if (val>0) rn.append(roman_[val]);

	return rn.toString();
  }


  /** Converts array of numbers into sequence of ranges, of the form parsed by {@link #parseRange(int[])}. */
  public static String toRange(int[] nums) {
	assert nums!=null;
	StringBuffer sb = new StringBuffer(100);

	for (int i=0,imax=nums.length, j; i<imax; i=j) {
		int val = nums[i];
		j=i+1; while (j<imax && nums[j] == val+j-i) j++;
		if (j-i>=2) { sb.append(val).append("-").append(nums[j-1]).append(","); continue; }

		while (j<imax && nums[j] == val-(j-i)) j++;
		if (j-i>=2) { sb.append(val).append("-").append(nums[j-1]).append(","); continue; }

		// LATER: odd and even
		// ...

		sb.append(val).append(",");
	}
	sb.setLength(sb.length()-1);	// chop off trailing comma

	return sb.toString();
  }

  /**
	Parses range specification like "1-3,5,1,7-20" or "odd,even" or "odd,20-7" into array of <code>int</code>'s (<code>int[]</code>).

	<ul>
	<li>ranges: 1-3
	<li>reverse ranges: 20-7
	<li>every n<sup>th</sup>: 1-1000*100, 1000-1*100
	<li>logical groups: odd, even, all, reverse [all]
	<li>Multiple ranges separated with a comma.
	</ul>

	If <var>range</var> is null, returns array <var>min</var>..<var>max</var>, inclusive.
  */
  public static int[] parseRange(String range, int min, int max) /*throws ParseException*/ {
	//assert /*range!=null && range.length()>=1 &&*/ max>=1; // could range from -50 to 2

	if (range==null || range.trim().length()==0) range = min+"-"+max;
	else {	// strip internal whitespace
		StringBuffer sb = new StringBuffer(range.length());
		for (int i=0,imax=range.length(); i<imax; i++) {
			char ch = range.charAt(i);
			if (!Character.isWhitespace(ch)) sb.append(ch);
		}
		if (sb.length() < range.length()) range = sb.toString();
	}

	int[] nums = new int[max-min+1];
	int numsi=0;

	int inx;
	for (StringTokenizer st = new StringTokenizer(range, ","); st.hasMoreElements(); ) {
		String snum = st.nextToken().toLowerCase().trim();
		try {
			int pg1, pg2, step=1;

			if ("all".equals(snum)) { pg1=min; pg2=max; }
			else if (snum.startsWith("rev"/*erse*/)) { pg1=max; pg2=min; }
			else if ("odd".equals(snum)) { pg1 = min + (min%2)==0? 1: 0; pg2=max; step=2; }
			else if ("even".equals(snum)) { pg1= min + (min%2)==0? 0: 1; pg2=max; step=2; }
			// reverse odd? reverse even?

			else if ((inx = snum.indexOf('-'))==-1) { pg1 = pg2 = Integer.parseInt(snum); }
			else {    // "5-7", "1-100*5", "1-100*odd"
				int endinx = snum.length();
				String sstep = null;
				int stepinx = snum.indexOf('*',inx+1); if (stepinx!=-1) { endinx = stepinx; sstep = snum.substring(stepinx+1); }
				pg1 = inx>0? Integer.parseInt(snum.substring(0,inx)): min;
				pg2 = inx < snum.length()-1? Integer.parseInt(snum.substring(inx+1,endinx)): max;
				if (sstep!=null) {
					if (sstep.startsWith("odd")) { step=2; if (pg1%2==0) pg1++; }
					else if (sstep.startsWith("even")) { step=2; if (pg1%2!=0) pg1++; }
					else if (sstep.startsWith("rev"/*erse*/)) { int tmp=pg1; pg1=pg2; pg2=tmp; }
					else step = Integer.parseInt(sstep);
				}
			}

			pg1 = Math.min(Math.max(pg1, min), max); pg2 = Math.min(Math.max(pg2, min), max);
			int len = Math.abs(pg2-pg1)+1;
//System.out.println("  "+pg1+".."+pg2+" / "+(nums.length-numsi)+" + "+len);
			if (len <= nums.length - numsi) { int[] newnums=new int[len + nums.length*2]; System.arraycopy(nums,0, newnums,0, nums.length); nums=newnums; }

			if (pg1<=pg2) {
				if (step<0) step=-step;
				for (int i=pg1; i<=pg2; i+=step) nums[numsi++] = i;
			} else {
				if (step>0) step=-step;
				for (int i=pg1; i>=pg2; i+=step) nums[numsi++] = i;
			}

		} catch (NumberFormatException nfe) { System.out.println(nfe); }  // ignore
	}

	int[] ret = new int[numsi];
	System.arraycopy(nums,0, ret,0, numsi);
//System.out.print(range+" => "); for (int i=0,imax=ret.length; i<imax; i++) System.out.print(ret[i]+" ");  System.out.println();
	return ret;
  }

  /** @return number of 1-bits in 4-byte integer <var>value</var>. */
  public static int countOneBits(int value) {
	return bitcnt[value&0xff] + bitcnt[(value>>8)&0xff] + bitcnt[(value>>16)&0xff] + bitcnt[(value>>24)&0xff];
  }

  public static String toString(int val) {
	String s;
	if (STRS_MIN<=val && val<=STRS_MAX) {
		if (STRS==null) STRS = new String[(int)(STRS_MAX - STRS_MIN + 1)];

		s = STRS[val - STRS_MIN];
		if (s==null) s = STRS[val - STRS_MIN] = Integer.toString(val);
	} else s = Integer.toString(val);

	return s;
  }
}
