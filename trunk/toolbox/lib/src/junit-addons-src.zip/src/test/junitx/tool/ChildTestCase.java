package junitx.tool;

/**
 * @version $Revision: 1.1 $ $Date: 2002/09/22 22:19:34 $
 * @author <a href="mailto:benoitx@users.sourceforge.net">Benoit Xhenseval</a>
 */
public class ChildTestCase
        extends ParentTestCase {

    public ChildTestCase(String name) {
        super(name);
    }
}
