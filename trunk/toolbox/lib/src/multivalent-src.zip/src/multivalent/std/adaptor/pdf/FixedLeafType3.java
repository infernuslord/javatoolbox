package multivalent.std.adaptor.pdf;

import java.awt.Rectangle;
import java.awt.Graphics2D;
import java.util.Map;

import multivalent.Context;
import multivalent.Node;
import multivalent.INode;
import multivalent.node.LeafText;
import multivalent.node.Fixed;



/**
	{@link multivalent.node.LeafText} in that draws text.
	But since Type 3 not known to Java as are TrueType and Type 1, doesn't respond to font changes;
	similar to {@link multivalent.node.FixedLeafOCR} that way.

	@version $Revision: 1.7 $ $Date: 2003/08/29 04:01:24 $
*/
public class FixedLeafType3 extends LeafText implements Fixed {
  static final Rectangle NO_CLIPPING = new Rectangle(-10000,-10000,10000,10000);

  FontType3 f3_;
  Rectangle ibbox_ = new Rectangle();
  String glyphs_;


  public FixedLeafType3(String name, Map<String,Object> attr, INode parent, FontType3 font) {
	super(name,attr, parent);

	// LATER: translate name to Unicode
	//StringBuffer sb = new StringBuffer(20);
	//for (int i=0,imax=name.length(); i<imax; i++) { char ch = name.charAt(i); if (ch<' ') sb.append('^').append(ch+65); else if (ch<128) sb.append(ch); else sb.append("\\").append(Integer.toOctalString(name.charAt(i))); }
	//setName(sb.toString());
	glyphs_ = name;     // wrong!

	f3_ = font;
  }

  public Rectangle getIbbox() { return ibbox_; }

/*
  public boolean formatNode(int width, int height, Context cx) {
	int w = 0, maxh=0; String txt=getName();
	assert txt!=null && f3_!=null;
	for (int i=0,imax=txt.length(); i<imax; i++) {
		Rectangle glyphr = f3_.getGlyph(txt.charAt(i)).getBbox();
		assert glyphr!=null;
		w += glyphr.width;
		if (glyphr.height > maxh) maxh=glyphr.height;
	}

	bbox.setBounds(ibbox_.x, ibbox_.y, w, maxh); baseline = maxh; valid_ = true;
	bbox.setBounds(ibbox_); baseline = ibbox_.height; valid_ = true;
	return false;
  }
*/

  public boolean formatNodeContent(Context cx, int start, int end) {
	bbox.setBounds(ibbox_); baseline = ibbox_.height; valid_ = true;
	return false;
/*
	if (super.formatNodeContent(cx, start, end)) return true;
	if (start==0) {
		bbox.setBounds(ibbox_);
		int w = 0; for (int i=start; i<=end; i++) w += f3_.getGlyph(name.charAt(i)).getBbox().width;
	} else bbox.width = 0;
	return false;
*/
  }

  public void subelementCalc(Context cx) {
	int len = size();
	if (Widths_.length < len) Widths_=new int[len];

	double w = 0.0;
	String txt = getName();
	for (int i=0; i<len; i++) {
		w += bbox.width/*f3_.getAdvance(txt.charAt(i))*/;
		Widths_[i] = (int)w;
	}
  }

  public boolean paintNodeContent(Context cx, int start, int end) {
	if (super.paintNodeContent(cx, start, end)) return true;

	String txt = glyphs_;
	Graphics2D g = cx.g;
	assert txt!=null && g!=null && f3_!=null: txt+", "+g+", "+f3_;
	//g.setColor(java.awt.Color.RED); g.drawRect(0,0, bbox.width,bbox.height);
	double adv = cx.x;
	for (int len=txt.length(), i=Math.min(start,len),imax=Math.min(end,len-1); i<=imax; i++) {
		char ch = txt.charAt(i);
		Node glyph = f3_.getGlyph(ch);
		Rectangle glyphr = glyph.getBbox();
		int dx=(int)adv, dy = glyphr.y + baseline;
		//try {
		assert glyph.isValid();
		g.translate(dx,dy); glyph.paintNode(NO_CLIPPING, cx); g.translate(-dx,-dy);
		//} catch (Exception e) { System.out.println(e); }//{ e.printStackTrace(System.out); System.exit(1); }
		//glyph.paintNode(NO_CLIPPING, cx);
//String gname=glyph.getName(); if (ch==133) System.out.println("advance "+gname+" "+(int)ch+" = "+f3_.getAdvance(ch));
		adv += f3_.getAdvance(ch)/*glyphr.width*/;  // advance is often 0
		//cx.x += f3_.getAdvance(ch); => diddled by glyph.paintNode?
//if ("Bounding".equals(txt)) System.out.println(ch+"+"+f3_.getAdvance(ch)+", total="+adv+" vs "+cx.x+"/"+dx);
	}
	cx.x += Math.ceil(adv);
	return false;
  }
}
