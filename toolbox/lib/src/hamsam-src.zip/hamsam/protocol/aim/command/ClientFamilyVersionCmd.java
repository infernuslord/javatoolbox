/*
 *
 * Hamsam - Instant Messaging API
 *
 * Copyright (C) 2003 Mike Miller <mikemil@users.sourceforge.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 */

package hamsam.protocol.aim.command;

import java.io.IOException;
import java.io.OutputStream;

import hamsam.protocol.aim.flap.*;
import hamsam.protocol.aim.snac.*;
import hamsam.protocol.aim.util.*;

/**
 * @author mikem
 */
public class ClientFamilyVersionCmd extends Command {

    private static final short[] CLIENT_FAMILY =  { 0x0001, 0x0002, 0x0003, 0x0004, 0x0006, 0x0009, 0x000a, 0x000b, 0x0013, 0x0015 };
    private static final short[] CLIENT_VER    =  { 0x0003, 0x0001, 0x0001, 0x0001, 0x0001, 0x0001, 0x0001, 0x0001, 0x0002, 0x0001 };

    /**
     * Constructor
     */
    public ClientFamilyVersionCmd() {
        flapHdr = new FlapHeader(FlapConstants.FLAP_CHANNEL_SNAC, 3);
        snacPacket = new SNACPacket(SNACConstants.SNAC_FAMILY_GENERIC_SERVICE_CONTROLS, SNACConstants.REQ_SRV_SVC_VERSIONS);
    }

    /* (non-Javadoc)
     * @see hamsam.protocol.aim.command.Command#writeCommandData(java.io.OutputStream)
     */
    public void writeCommandData(OutputStream os) throws IOException {
         // write out the family/version pairs
         for (int i = 0; i < CLIENT_FAMILY.length; i++) {
            os.write(ByteUtils.getUShort(CLIENT_FAMILY[i]));
            os.write(ByteUtils.getUShort(CLIENT_VER[i]));
        }
    }

}
