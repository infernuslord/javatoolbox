package tex.dvi;

import java.awt.Color;
import java.awt.Point;
import java.awt.color.ColorSpace;
import java.util.Map;
import java.util.HashMap;
import java.util.regex.Pattern;

import multivalent.*;
import multivalent.std.span.ForegroundSpan;
import phelps.awt.color.ColorSpaceCMYK;
import phelps.awt.color.ColorSpaceHSV;



/**
	color push/pop TeX special,
	as defined by <a href='http://www.tug.org/texlive/tlprod/Master/texmf/doc/html/dvips/dvips_7.html'><code>dvips</code></a>.

	@version $Revision: 1.5 $ $Date: 2002/10/09 08:47:50 $

	@see tex.dvi.DVI
*/
public class SpecialColor extends Behavior {
  static final Pattern PARSESPEC = Pattern.compile("\\s+");

  static final ColorSpace
	CS_RGB = ColorSpace.getInstance(ColorSpace.CS_sRGB),
	CS_GRAY = ColorSpace.getInstance(ColorSpace.CS_GRAY),
	CS_CMYK = ColorSpaceCMYK.getInstance();


  static final Map<String,Color> BUILTIN;
  static {
	String[] colpr = {
	"GreenYellow","#D9FF4F",  "Yellow","#FFFF00",  "Goldenrod","#FFE628",  "Dandelion","#FFB528",
	"Apricot","#FFAE7A",  "Peach","#FF804C",  "Melon","#FF8A80",  "YellowOrange","#FF9400",
	"Orange","#FF6321",  "BurntOrange","#FF7D00",  "Bittersweet","#C20200",  "RedOrange","#FF3A21",
	"Mahogany","#A60000",  "Maroon","#AE0000",  "BrickRed","#B80000",  "Red","#FF0000",
	"OrangeRed","#FF0080", 	"RubineRed","#FF00DE",  "WildStrawberry","#FF0A9C",  "Salmon","#FF789E",
	"CarnationPink","#FF5EFF",  "Magenta","#FF00FF",  "VioletRed","#FF30FF",  "Rhodamine","#FF2EFF",
	"Mulberry","#A314FA",  "RedViolet","#9700A8",  "Fuchsia","#7302EB",  "Lavender","#FF85FF",
	"Thistle","#E168FF",  "Orchid","#AE5CFF",  "DarkOrchid","#9933CC",  "Purple","#8C23FF",
	"Plum","#8000FF",  "Violet","#351EFF",  "RoyalPurple","#4019FF",  "BlueViolet","#190CF5",
	"Periwinkle","#6E73FF",  "CadetBlue","#616EC5",  "CornflowerBlue","#59DEFF",  "MidnightBlue","#007091",
	"NavyBlue","#0F75FF",  "RoyalBlue","#0080FF",  "Blue","#0000FF",  "Cerulean","#0FE3FF",
	"Cyan","#00FFFF",  "ProcessBlue","#0AFFFF", "SkyBlue","#61FFE1",  "Turquoise","#26FFCC",
	"TealBlue","#1EFAA3",  "Aquamarine","#2EFFB3",  "BlueGreen","#26FFAB",  "Emerald","#00FF80",
	"JungleGreen","#02FF7A",  "SeaGreen","#4FFF80",  "Green","#00FF00",  "ForestGreen","#00E100",
	"PineGreen","#00C028",  "LimeGreen","#80FF00",  "YellowGreen","#8FFF42",  "SpringGreen","#BDFF3D",
	"OliveGreen","#009900",  "RawSienna","#8C0000",  "Sepia","#4C0000",  "Brown","#660000",
	"Tan","#DC9470",  "Gray","#808080",  "Black","#000000",  "White","#FFFFFF",
	};

	BUILTIN = new HashMap<String,Color>(colpr.length);
	assert colpr.length % 2 == 0;
	for (int i=0,imax=colpr.length; i<imax; i+=2) {
		assert colpr[i+1].startsWith("#");
		try { BUILTIN.put(colpr[i], new Color(Integer.parseInt(colpr[i+1].substring(1), 16))); } catch (NumberFormatException male) { System.err.println("bad color spec: "+colpr[i]+" = "+colpr[i+1]); }
	}
  }


  ForegroundSpan[] colors=new ForegroundSpan[100];  // nested spans
  int colori_=0;


  /** Get event from DVI parser. */
  public boolean semanticEventBefore(SemanticEvent se, String msg) {
	if (super.semanticEventBefore(se,msg)) return true;
	if (DVI.MSG_SPECIAL!=msg || se.getOut()==null/*scanning*/) return false;
	Object arg = se.getArg();
	if (arg==null || !(arg instanceof String)) return false;
	String special = (String)arg, scmp = special.toLowerCase();
	Point pt = (Point)se.getOut();
	Node lastn = null;
	String spage = null;
	if (pt!=null) lastn = (Node)se.getIn(); else spage=(String)se.getIn();


//System.out.println(scmp);
	if (special.startsWith("color push")) {  // \special{color push JungleGreen}
//System.out.println(scmp+", lastn="+lastn);
		if (lastn!=null && colori_ < colors.length) {
			Color c = getColor(special.substring("color push".length()));   // always push even if invalid color so pop has partner
			ForegroundSpan fgspan = (ForegroundSpan)Behavior.getInstance("color","multivalent.std.span.ForegroundSpan", null, getDocument().getLayer(Layer.SCRATCH));
			fgspan.setColor(c);
			fgspan.open(lastn);

			colors[colori_++] = fgspan;
		}

	} else if (special.startsWith("color pop")) { // \special{color pop}
//System.out.println(special+" .. "+lastn);
		if (colori_ > 0) {
			ForegroundSpan span = colors[--colori_];
//System.out.println("color = "+span.getColor());
			if (/*lastn!=null &&*/ span.getColor() != null) {
				span.close(lastn);
				if (Color.BLACK.equals(span.getColor()) && colori_==0) span.destroy();    // black is default
			}
			//if (lastn!=null /*&& color!=null*/) span.moveq(span.getStart().node,span.getStart().offset, lastn,lastn.size());
		}

	} else if (special.startsWith("color")) {
		Color c = getColor(special.substring("color".length()));

	} else if (special.startsWith("background")) {
		Color c = getColor(special.substring("background".length()));
		// set page background

	} else if (special.startsWith("reading new dvi")) {
		colori_ = 0;
	}

	return false;
  }

  /** Translate color specification to Color object. */
  public Color getColor(String spec) {
	Color c = null;
	// 1. PostScript procedure as defined in a PostScript header file. The `color.pro' file defines 64 of these, including `Maroon'
	// 2. name of a color model (initially, one of `rgb', `hsb', `cmyk', or `gray') followed by the appropriate number of parameters
	// 3. double quote followed by any sequence of PostScript
	spec = (spec!=null? spec.trim(): null);

	if (spec.startsWith("\"")) {    // ignore
		c = null;

	} else if ((c = (Color)BUILTIN.get(spec)) != null) {
		// c as just set

	} else {
		String[] parts = PARSESPEC.split(spec, 5);  // max +4 vals in cmyk case
		//if (parts.length()==0) ...
		String model = parts[0].intern();

		// values
		float val[] = new float[parts.length-1];
		for (int i=0,imax=val.length; i<imax; i++) {
			try { val[i] = Float.parseFloat(parts[i+1]); } catch (NumberFormatException nfe) {}
		}

		// rgb, hsb, cmyk, gray
		if ("rgb" == model /*&& val.length==3*/) c = new Color(CS_RGB, val, 1f); //c = new Color(val[0], val[1], val[2]);
		else if ("hsb" == model) c = Color.getHSBColor(val[0], val[1], val[2]);
		else if ("cmyk" == model) c = new Color(CS_CMYK, val, 1f);
		else if ("gray" == model) c = new Color(CS_GRAY, val, 1f); // val[0], val[0], val[0]);
	}

//System.out.println("=> "+c);
	return c;
  }
}
