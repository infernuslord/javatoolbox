// $Id: ExtensionContext.java,v 1.1 2002/04/25 18:06:47 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.XSLException;
import com.jclark.xsl.om.Node;

/**
 *
 */
public interface ExtensionContext 
{
    boolean available(String name);
    Object call(String name, Node currentNode, Object[] args) throws XSLException;
}
