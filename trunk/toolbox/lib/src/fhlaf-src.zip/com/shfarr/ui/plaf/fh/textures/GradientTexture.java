/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh.textures;

import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;

import javax.swing.JComponent;

import com.shfarr.ui.GraphicsUtils;


public class GradientTexture extends Texture{
    protected String[] colors = null;
    
    public GradientTexture(){
    }

    public GradientTexture(String[] colors){
        setColors(colors);
    }
    
    public void parse(String str){
    }
    

    public void apply(Shape s, Rectangle clip, Graphics2D g2D, JComponent c){
        GradientPaint gradient = null;
        Rectangle rect = s.getBounds();
        
        Shape oldClip = g2D.getClip();
        g2D.setClip(clip != null ? c.getVisibleRect().createIntersection(clip) : c.getVisibleRect());
        
        if(g2D.getClipBounds().width > 0 && g2D.getClipBounds().height > 0){
            float hStep = actualRotation() == GraphicsUtils.ROTATE_0 || actualRotation() == GraphicsUtils.ROTATE_180 ? rect.width/(float)(colors.length -1) : 0;
            float vStep = actualRotation() == GraphicsUtils.ROTATE_90 || actualRotation() == GraphicsUtils.ROTATE_270 ? rect.height/(float)(colors.length -1) : 0;

            for(int i = 0; i < colors.length -1; i++){
                if(actualRotation() == GraphicsUtils.ROTATE_0 || actualRotation() == GraphicsUtils.ROTATE_90){
                    gradient = new GradientPaint(rect.x +i*hStep, rect.y +i*vStep, theme.getColor(colors[i]), rect.x +(i +1)*hStep, rect.y  +(i +1)*vStep, theme.getColor(colors[i +1]));
                }
                else if(actualRotation() == GraphicsUtils.ROTATE_180 || actualRotation() == GraphicsUtils.ROTATE_270){
                    gradient = new GradientPaint(rect.x +(colors.length -i -1)*hStep, rect.y +(colors.length -i -1)*vStep, theme.getColor(colors[i]), rect.x +(colors.length -i -2)*hStep, rect.y  +(colors.length -i -2)*vStep, theme.getColor(colors[i +1]));
                }

                g2D.setPaint(gradient);

                if(actualRotation() == GraphicsUtils.ROTATE_0) g2D.fill(new Rectangle(rect.x +(int)((i)*hStep), rect.y, (int)hStep, rect.height));
                else if(actualRotation() == GraphicsUtils.ROTATE_90) g2D.fill(new Rectangle(rect.x, rect.y +(int)(i*vStep), rect.width, (int)vStep));
                else if(actualRotation() == GraphicsUtils.ROTATE_180) g2D.fill(new Rectangle(rect.x +(int)((colors.length -i -2)*hStep), rect.y, (int)hStep, rect.height));
                else if(actualRotation() == GraphicsUtils.ROTATE_270) g2D.fill(new Rectangle(rect.x, rect.y +(int)((colors.length -i -2)*vStep), rect.width, (int)vStep));
            }
        }

        g2D.setClip(oldClip);
    }
    
    public String[] getColors(){
        return colors;
    }

    public void setColors(String[] colors){
        this.colors = colors;
    }
}
