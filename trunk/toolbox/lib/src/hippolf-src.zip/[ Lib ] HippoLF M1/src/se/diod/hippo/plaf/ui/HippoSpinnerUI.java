/*
 * 
 * Created on 2004-jul-25
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.ui;

import java.awt.AWTEvent;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FocusTraversalPolicy;
import java.awt.Insets;
import java.awt.KeyboardFocusManager;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.AttributedCharacterIterator;
import java.text.CharacterIterator;
import java.text.DateFormat;
import java.text.Format;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Map;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFormattedTextField;
import javax.swing.JSpinner;
import javax.swing.SpinnerDateModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.BorderUIResource;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.UIResource;
import javax.swing.plaf.basic.BasicSpinnerUI;
import javax.swing.text.InternationalFormatter;

import se.diod.hippo.plaf.common.ScrollButton;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-25
 *
 */
public class HippoSpinnerUI extends BasicSpinnerUI {
	private static final Border EMPTY_BORDER = new BorderUIResource(new EmptyBorder(0, 0, 0, 0));


	/**
	 * The mouse/action listeners that are added to the spinner's 
	 * arrow buttons.  These listeners are shared by all 
	 * spinner arrow buttons.
	 * 
	 * @see #createNextButton
	 * @see #createPreviousButton
	 */
	private static final ArrowButtonHandler nextButtonHandler = new ArrowButtonHandler( "increment", true );
	private static final ArrowButtonHandler previousButtonHandler = new ArrowButtonHandler( "decrement", false );

	/**
	 * Used by the default LayoutManager class - SpinnerLayout for 
	 * missing (null) editor/nextButton/previousButton children.
	 */
	private static final Dimension zeroSize = new Dimension(0, 0);




	/**
	 * 
	 * 
	 */
	public static ComponentUI createUI(JComponent b) {
		return new HippoSpinnerUI();
	}




	/**
	 * Create a component that will replace the spinner models value
	 * with the object returned by <code>spinner.getPreviousValue</code>.
	 * By default the <code>previousButton</code> is a JButton
	 * who's <code>ActionListener</code> updates it's <code>JSpinner</code>
	 * ancestors model.  If a previousButton isn't needed (in a subclass)
	 * then override this method to return null.
	 *
	 * @return a component that will replace the spinners model with the
	 *     next value in the sequence, or null
	 * @see #installUI
	 * @see #createNextButton
	 */
	protected Component createPreviousButton() {
		int width  = UIManager.getInt("ScrollBar.width");
		JButton b = new ScrollButton( SwingConstants.SOUTH, width, true );
		b.addActionListener( previousButtonHandler );
		b.addMouseListener( previousButtonHandler );
		//Border buttonBorder =  UIManager.getBorder("Spinner.arrowButtonBorder");
		//if (buttonBorder instanceof UIResource) {
			// Wrap the border to avoid having the UIResource be replaced by
			// the ButtonUI. This is the opposite of using BorderUIResource.
		//	b.setBorder(new CompoundBorder(buttonBorder, null));
		//} else {
		//	b.setBorder(buttonBorder);
		//}
		//b.setBorder(new javax.swing.border.LineBorder( Color.BLACK, 1 ));
		return b;
	}




	/**
	 * Create a component that will replace the spinner models value
	 * with the object returned by <code>spinner.getNextValue</code>.
	 * By default the <code>nextButton</code> is a JButton
	 * who's <code>ActionListener</code> updates it's <code>JSpinner</code>
	 * ancestors model.  If a nextButton isn't needed (in a subclass)
	 * then override this method to return null.
	 *
	 * @return a component that will replace the spinners model with the
	 *     next value in the sequence, or null
	 * @see #installUI
	 * @see #createPreviousButton
	 */
	protected Component createNextButton() {
		int width  = UIManager.getInt("ScrollBar.width");
		JButton b = new ScrollButton(SwingConstants.NORTH, width, true);
		b.addActionListener( nextButtonHandler );
		b.addMouseListener( nextButtonHandler );
		Border buttonBorder = UIManager.getBorder("Spinner.arrowButtonBorder");
		if (buttonBorder instanceof UIResource) {
			// Wrap the border to avoid having the UIResource be replaced by
			// the ButtonUI. This is the opposite of using BorderUIResource.
			b.setBorder(new CompoundBorder(buttonBorder, null));
		} else {
			b.setBorder(buttonBorder);
		}
		return b;
	}




	/**
	 * This method is called by installUI to get the editor component
	 * of the <code>JSpinner</code>.  By default it just returns 
	 * <code>JSpinner.getEditor()</code>.  Subclasses can override
	 * <code>createEditor</code> to return a component that contains 
	 * the spinner's editor or null, if they're going to handle adding 
	 * the editor to the <code>JSpinner</code> in an 
	 * <code>installUI</code> override.
	 * <p>
	 * Typically this method would be overridden to wrap the editor
	 * with a container with a custom border, since one can't assume
	 * that the editors border can be set directly.  
	 * <p>
	 * The <code>replaceEditor</code> method is called when the spinners
	 * editor is changed with <code>JSpinner.setEditor</code>.  If you've
	 * overriden this method, then you'll probably want to override
	 * <code>replaceEditor</code> as well.
	 * 
	 * @return the JSpinners editor JComponent, spinner.getEditor() by default
	 * @see #installUI
	 * @see #replaceEditor
	 * @see JSpinner#getEditor
	 */
	protected JComponent createEditor() {
		JComponent editor = spinner.getEditor();
		configureEditor(editor);
		return editor;
	}
    
	/**
	 * Called by the <code>PropertyChangeListener</code> when the 
	 * <code>JSpinner</code> editor property changes.  It's the responsibility 
	 * of this method to remove the old editor and add the new one.  By
	 * default this operation is just:
	 * <pre>
	 * spinner.remove(oldEditor);
	 * spinner.add(newEditor, "Editor");
	 * </pre>
	 * The implementation of <code>replaceEditor</code> should be coordinated
	 * with the <code>createEditor</code> method.
	 * 
	 * @see #createEditor
	 * @see #createPropertyChangeListener
	 */
	protected void replaceEditor(JComponent oldEditor, JComponent newEditor) {
		spinner.remove(oldEditor);
		configureEditor(newEditor);
		spinner.add(newEditor, "Editor");
	}
    
    
	/**
	 * Removes an obsolete Border from Default editors.
	 */
	private void configureEditor(JComponent editor) {
		if ((editor instanceof JSpinner.DefaultEditor)) {
			JSpinner.DefaultEditor defaultEditor = (JSpinner.DefaultEditor) editor;
			defaultEditor.getTextField().setBorder(EMPTY_BORDER); 
		}
	}






	/**
	 * A handler for spinner arrow button mouse and action events.  When 
	 * a left mouse pressed event occurs we look up the (enabled) spinner 
	 * that's the source of the event and start the autorepeat timer.  The
	 * timer fires action events until any button is released at which 
	 * point the timer is stopped and the reference to the spinner cleared.
	 * The timer doesn't start until after a 300ms delay, so often the 
	 * source of the initial (and final) action event is just the button
	 * logic for mouse released - which means that we're relying on the fact
	 * that our mouse listener runs after the buttons mouse listener.
	 * <p>
	 * Note that one instance of this handler is shared by all slider previous 
	 * arrow buttons and likewise for all of the next buttons, 
	 * so it doesn't have any state that persists beyond the limits
	 * of a single button pressed/released gesture.
	 */
	private static class ArrowButtonHandler extends AbstractAction
						implements MouseListener, UIResource {
	final javax.swing.Timer autoRepeatTimer;
	final boolean isNext;
	JSpinner spinner = null;

	ArrowButtonHandler(String name, boolean isNext) {
			super(name);
		this.isNext = isNext;
		autoRepeatTimer = new javax.swing.Timer(60, this);
		autoRepeatTimer.setInitialDelay(300);
	}

	private JSpinner eventToSpinner(AWTEvent e) {
		Object src = e.getSource();
		while ((src instanceof Component) && !(src instanceof JSpinner)) {
		src = ((Component)src).getParent();
		}
		return (src instanceof JSpinner) ? (JSpinner)src : null;
	}

	public void actionPerformed(ActionEvent e) {
			JSpinner spinner = this.spinner;

			if (!(e.getSource() instanceof javax.swing.Timer)) {
				// Most likely resulting from being in ActionMap.
				spinner = eventToSpinner(e);
			}
			if (spinner != null) {
				try {
					int calendarField = getCalendarField(spinner);
					spinner.commitEdit();
					if (calendarField != -1) {
						((SpinnerDateModel)spinner.getModel()).
								 setCalendarField(calendarField);
					}
					Object value = (isNext) ? spinner.getNextValue() :
							   spinner.getPreviousValue();
					if (value != null) {
						spinner.setValue(value);
						select(spinner);
					}
				} catch (IllegalArgumentException iae) {
					UIManager.getLookAndFeel().provideErrorFeedback(spinner);
				} catch (ParseException pe) {
					UIManager.getLookAndFeel().provideErrorFeedback(spinner);
				}
			}
	}

		/**
		 * If the spinner's editor is a DateEditor, this selects the field
		 * associated with the value that is being incremented.
		 */
		private void select(JSpinner spinner) {
			JComponent editor = spinner.getEditor();

			if (editor instanceof JSpinner.DateEditor) {
				JSpinner.DateEditor dateEditor = (JSpinner.DateEditor)editor;
				JFormattedTextField ftf = dateEditor.getTextField();
				Format format = dateEditor.getFormat();
				Object value;

				if (format != null && (value = spinner.getValue()) != null) {
					SpinnerDateModel model = dateEditor.getModel();
					DateFormat.Field field = DateFormat.Field.ofCalendarField(
						model.getCalendarField());

					if (field != null) {
						try {
							AttributedCharacterIterator iterator = format.
								formatToCharacterIterator(value);
							if (!select(ftf, iterator, field) &&
									   field == DateFormat.Field.HOUR0) {
								select(ftf, iterator, DateFormat.Field.HOUR1);
							}
						}
						catch (IllegalArgumentException iae) {}
					}
				}
			}
		}

		/**
		 * Selects the passed in field, returning true if it is found,
		 * false otherwise.
		 */
		private boolean select(JFormattedTextField ftf,
							   AttributedCharacterIterator iterator,
							   DateFormat.Field field) {
			int max = ftf.getDocument().getLength();

			iterator.first();
			do {
				Map attrs = iterator.getAttributes();

				if (attrs != null && attrs.containsKey(field)){
					int start = iterator.getRunStart(field);
					int end = iterator.getRunLimit(field);

					if (start != -1 && end != -1 && start <= max &&
									   end <= max) {
						ftf.select(start, end);
					}
					return true;
				}
			} while (iterator.next() != CharacterIterator.DONE);
			return false;
		}

		/**
		 * Returns the calendarField under the start of the selection, or
		 * -1 if there is no valid calendar field under the selection (or
		 * the spinner isn't editing dates.
		 */
		private int getCalendarField(JSpinner spinner) {
			JComponent editor = spinner.getEditor();

			if (editor instanceof JSpinner.DateEditor) {
				JSpinner.DateEditor dateEditor = (JSpinner.DateEditor)editor;
				JFormattedTextField ftf = dateEditor.getTextField();
				int start = ftf.getSelectionStart();
				JFormattedTextField.AbstractFormatter formatter =
									ftf.getFormatter();

				if (formatter instanceof InternationalFormatter) {
					Format.Field[] fields = ((InternationalFormatter)
											 formatter).getFields(start);

					for (int counter = 0; counter < fields.length; counter++) {
						if (fields[counter] instanceof DateFormat.Field) {
							int calendarField;

							if (fields[counter] == DateFormat.Field.HOUR1) {
								calendarField = Calendar.HOUR;
							}
							else {
								calendarField = ((DateFormat.Field)
										fields[counter]).getCalendarField();
							}
							if (calendarField != -1) {
								return calendarField;
							}
						}
					}
				}
			}
			return -1;
		}

	public void mousePressed(MouseEvent e) {
		if (SwingUtilities.isLeftMouseButton(e) && e.getComponent().isEnabled()) {
		spinner = eventToSpinner(e);
		autoRepeatTimer.start();

				focusSpinnerIfNecessary();
		}
	}

	public void mouseReleased(MouseEvent e) {
		autoRepeatTimer.stop();	    
		spinner = null;
	}

		public void mouseClicked(MouseEvent e) {
		}

		public void mouseEntered(MouseEvent e) {
		}

		public void mouseExited(MouseEvent e) {
		}

		/**
		 * Requests focus on a child of the spinner if the spinner doesn't
		 * have focus.
		 */
		private void focusSpinnerIfNecessary() {
			Component fo = KeyboardFocusManager.
							  getCurrentKeyboardFocusManager().getFocusOwner();
			if (spinner.isRequestFocusEnabled() && (
						fo == null ||
						!SwingUtilities.isDescendingFrom(fo, spinner))) {
				Container root = spinner;

				if (!root.isFocusCycleRoot()) {
					root = root.getFocusCycleRootAncestor();
				}
				if (root != null) {
					FocusTraversalPolicy ftp = root.getFocusTraversalPolicy();
					Component child = ftp.getComponentAfter(root, spinner);

					if (child != null && SwingUtilities.isDescendingFrom(
														child, spinner)) {
						child.requestFocus();
					}
				}
			}
		}
	}






	/**
	 * A simple layout manager for the editor and the next/previous buttons.
	 * See the BasicSpinnerUI javadoc for more information about exactly
	 * how the components are arranged.
	 */
	private static class SpinnerLayout implements LayoutManager 
	{
	private Component nextButton = null;
	private Component previousButton = null;
	private Component editor = null;

	public void addLayoutComponent(String name, Component c) {
		if ("Next".equals(name)) {
		nextButton = c;
		}
		else if ("Previous".equals(name)) {
		previousButton = c;
		}
		else if ("Editor".equals(name)) {
		editor = c;
		}
	}

	public void removeLayoutComponent(Component c) {
		if (c == nextButton) {
		c = null;
		}
		else if (c == previousButton) {
		previousButton = null;
		}
		else if (c == editor) {
		editor = null;
		}
	}

	private Dimension preferredSize(Component c) {
		return (c == null) ? zeroSize : c.getPreferredSize();
	}

	public Dimension preferredLayoutSize(Container parent) {
		Dimension nextD = preferredSize(nextButton);
		Dimension previousD = preferredSize(previousButton);
		Dimension editorD = preferredSize(editor);

		/* Force the editors height to be a multiple of 2
		 */
		editorD.height = ((editorD.height + 1) / 2) * 2;     

		Dimension size = new Dimension(editorD.width, editorD.height);
		size.width += Math.max(nextD.width, previousD.width);
		Insets insets = parent.getInsets();
		size.width += insets.left + insets.right;
		size.height += insets.top + insets.bottom;
		return size;
	}

	public Dimension minimumLayoutSize(Container parent) {
		return preferredLayoutSize(parent);
	}

	private void setBounds(Component c, int x, int y, int width, int height) {
		if (c != null) {
		c.setBounds(x, y, width, height);
		}
	}

	public void layoutContainer(Container parent) {
		int width  = parent.getWidth();
		int height = parent.getHeight();

		Insets insets = parent.getInsets();
		Dimension nextD = preferredSize(nextButton);
		Dimension previousD = preferredSize(previousButton);	    
		int buttonsWidth = Math.max(nextD.width, previousD.width);
		int editorHeight = height - (insets.top + insets.bottom);

		// The arrowButtonInsets value is used instead of the JSpinner's
		// insets if not null. Defining this to be (0, 0, 0, 0) causes the
		// buttons to be aligned with the outer edge of the spinner's
		// border, and leaving it as "null" places the buttons completely
		// inside the spinner's border.
		Insets buttonInsets = UIManager.getInsets("Spinner.arrowButtonInsets");
		if (buttonInsets == null) {
		buttonInsets = insets;
		}

		/* Deal with the spinner's componentOrientation property.
		 */
		int editorX, editorWidth, buttonsX;
		if (parent.getComponentOrientation().isLeftToRight()) {
		editorX = insets.left;
		editorWidth = width - insets.left - buttonsWidth - buttonInsets.right;
		buttonsX = width - buttonsWidth - buttonInsets.right;
		} else {
		buttonsX = buttonInsets.left;
		editorX = buttonsX + buttonsWidth;
		editorWidth = width - buttonInsets.left - buttonsWidth - insets.right;
		}

		int nextY = buttonInsets.top;
		int nextHeight = (height / 2) + (height % 2) - nextY;
		int previousY = buttonInsets.top + nextHeight;
		int previousHeight = height - previousY - buttonInsets.bottom;

		setBounds(editor,         editorX,  insets.top, editorWidth, editorHeight);
		setBounds(nextButton,     buttonsX, nextY,      buttonsWidth, nextHeight);
		setBounds(previousButton, buttonsX, previousY,  buttonsWidth, previousHeight);
	}
	}
}
