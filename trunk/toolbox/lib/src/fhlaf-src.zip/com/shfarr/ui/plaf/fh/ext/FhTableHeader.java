/*
 * Created on Nov 13, 2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package com.shfarr.ui.plaf.fh.ext;

import java.awt.Container;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseMotionListener;

import javax.swing.JComponent;
import javax.swing.JViewport;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumnModel;

import com.shfarr.ui.layouts.MaxLayout;

/**
 * @author shfarr
 */
public class FhTableHeader extends JTableHeader{
    public static final MouseListener FAKE_MOUSE_LISTENER = new MouseAdapter(){};
    public static final MouseMotionListener FAKE_MOUSE_MOTION_LISTENER = new MouseMotionAdapter(){};
    
    protected JComponent title = null;
    
    public FhTableHeader(){
        super();
        init();
    }

    public FhTableHeader(TableColumnModel cm){
        super(cm);
        init();
    }
    
    private void init(){
        setLayout(new MaxLayout(){
            protected void performLayout(Container parent){
                java.awt.Insets ins = parent.getInsets();

                Rectangle vRect = ((JViewport)parent.getParent()).getVisibleRect();
                if(getTitle() != null) getTitle().setBounds(vRect.x, ins.top, vRect.width, getTitleHeight() -ins.top -ins.bottom);
            }
        });
    }
    
    public Rectangle getHeaderRect(int column) {
        Rectangle r = super.getHeaderRect(column);
        
        r.y += getTitleHeight();
        r.height -= getTitleHeight();
        
        return r;
    }
    
    public int getTitleHeight(){
        return title != null ? title.getPreferredSize().height : 0;
    }
    
    public JComponent getTitle(){
        return title;
    }
    
    public void setTitle(JComponent panel){
        if(panel != null){
            title = panel;
            add(title);
            
            title.addMouseListener(FAKE_MOUSE_LISTENER);
            title.addMouseMotionListener(FAKE_MOUSE_MOTION_LISTENER);
        }
        else{
            remove(title);
            title = null;
        }
    }
}
