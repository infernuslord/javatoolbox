package edu.uci.ics.jung.visualization.contrib;

import java.awt.Dimension;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import edu.uci.ics.jung.visualization.Layout;

/*
 * Created on Oct 13, 2004
 *
 */

/**
 * Lens is intended to be used as an overlay on the
 * BirdsEyeVisualizationViewer. It is a Rectangle that
 * acts as a MouseListener (for moving and resizing the
 * Rectangle). Lens also fires a PropertyChangeEvent,
 * with a payload containing the xoffset, yoffset, width,
 * and height of the Rectangle, as a percentage of the
 * graph layout size
 * @author Tom Nelson - RABA Technologies
 * 
 *  
 */
public class Lens extends Rectangle2D.Double implements MouseListener,
        MouseMotionListener {

    /**
     * true if we are dragging the Rectangle around
     */
    boolean pan;

    /**
     * true if we are dragging the right leg
     */
    boolean dragRightLeg;

    /**
     * true if we are dragging the base 
     */
    boolean dragBase;

    /**
     * true if we are dragging the left leg
     */
    boolean dragLeftLeg;

    /**
     * true if we are dragging the top
     */
    boolean dragTop;

    /**
     * true if the mouse pointer is outside the window
     */
    boolean outside;

    /**
     * the offset in the x direction, as a percentage of width
     */
    double offx;

    /**
     * the offset in the y direction, as a percentage of height
     */
    double offy;

    /**
     * the left leg of the rectangle
     */
    Line2D leftLeg;

    /**
     * the right leg of the rectangle
     */
    Line2D rightLeg;

    /**
     * the base of the rectangle
     */
    Line2D base;

    /**
     * the top of the rectangle
     */
    Line2D top;

    /**
     * the scale of the BirdsEyeViewer compared to
     * the graph display
     */
    double scalex;

    /**
     * the scale of the BirdsEyeViewer compared to
     * the graph display
     */
    double scaley;

    /**
     * the layout being used by the BirdsEye
     */
    Layout layout;

    /**
     * an payload object for the propertyChangeEvent
     */
    Stats stats;

    /**
     * support for property changes
     */
    PropertyChangeSupport support;

    /**
     * ratio of width to height
     */
    double aspectRatio;

    /**
     * Create a Lens that is centered in the 
     * BirdsEyeViewer
     * 
     */
    public Lens(Layout layout, double scalex, double scaley) {
        super(layout.getCurrentSize().width * scalex / 4, 
                layout.getCurrentSize().height * scaley / 4, 
                layout.getCurrentSize().width * scalex / 2,
                layout.getCurrentSize().height * scaley / 2);
        this.layout = layout;
        this.scalex = scalex;
        this.scaley = scaley;
        this.aspectRatio = (getMaxX() - getMinX()) / (getMaxY() - getMinY());
        rightLeg = new Line2D.Double(getMaxX(), getMinY(), getMaxX(), getMaxY());
        leftLeg = new Line2D.Double(getMinX(), getMinY(), getMinX(), getMaxY());
        base = new Line2D.Double(getMinX(), getMaxY(), getMaxX(), getMaxY());
        top = new Line2D.Double(getMinX(), getMinY(), getMaxX(), getMinY());
        Dimension d = new Dimension(
                (int) (layout.getCurrentSize().width * scalex), 
                (int) (layout.getCurrentSize().height * scaley));
        Stats oldStats = stats;
        stats = new Stats(getMinX() / d.width, getMinY() / d.height, 
                d.width / getWidth(), d.height / getHeight());
    }

    /**
     * getter for Stats
     * @return stats
     */
    public Stats getStats() {
        return stats;
    }

    /**
     * reset the rectangle to the full size of the BirdsEyeViewer
     * This will result in no zoom or pan of the main display
     *
     */
    public void reset() {
        Dimension d = new Dimension(
                (int) (layout.getCurrentSize().width * scalex), (int) (layout
                        .getCurrentSize().height * scaley));
        setRect(0, 0, d.width, d.height);
        Stats oldStats = stats;
        stats = new Stats(getMinX() / d.width, getMinY() / d.height, 
                d.width / getWidth(), d.height / getHeight());
        firePropertyChange("Lens", oldStats, stats);
    }
    
    /**
     * zoom proportionally in x and y axis, centered in the display
     * @param percent
     */
    public void zoom(double percent) {
        double centerX = getCenterX();
        double centerY = getCenterY();
        double maxX = centerX+(getMaxX()-centerX)/percent;
        double maxY = centerY+(getMaxY()-centerY)/percent;
        setFrameFromCenter(centerX, centerY, maxX, maxY);
        Stats oldStats = stats;
        Dimension d = new Dimension(
                (int) (layout.getCurrentSize().width * scalex), (int) (layout
                        .getCurrentSize().height * scaley));
       stats = new Stats(getMinX() / d.width, getMinY() / d.height, 
                d.width / getWidth(), d.height / getHeight());
        firePropertyChange("Lens", oldStats, stats);
    }

    /**
     * set the Rectangle to be centered in the BirdsEyeViewer
     *
     */
    public void init() {
        Dimension d = new Dimension(
                (int) (layout.getCurrentSize().width * scalex), (int) (layout
                        .getCurrentSize().height * scaley));
        setRect(d.width/4, d.height/4, d.width/2, d.height/2);
        Stats oldStats = stats;
        stats = new Stats(getMinX() / d.width, getMinY() / d.height, 
                d.width / getWidth(), d.height / getHeight());
        firePropertyChange("Lens", oldStats, stats);
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
     */
    public void mouseClicked(MouseEvent e) {
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
     */
    public void mousePressed(MouseEvent e) {
        Dimension d = new Dimension(
                (int) (layout.getCurrentSize().width * scalex), (int) (layout
                        .getCurrentSize().height * scaley));
        double downx = e.getX();
        double downy = e.getY();
        offx = downx - getX();
        offy = downy - getY();
        Point2D down = new Point2D.Double(downx, downy);
 
        if (leftLeg.ptLineDist(down) < 5) {
            dragLeftLeg = true;
        } else if (rightLeg.ptLineDist(down) < 5) {
            dragRightLeg = true;
        } else if (base.ptLineDist(down) < 5) {
            dragBase = true;
        } else if (top.ptLineDist(down) < 5) {
            dragTop = true;
        } else if (contains(down)) {
            pan = true;
        } else {
            pan = dragLeftLeg = dragRightLeg = dragBase = dragTop = false;
        }
        stats = new Stats(getMinX() / d.width, getMinY() / d.height,
                (double) d.width / getWidth(), (double) d.height / getHeight());
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
     */
    public void mouseReleased(MouseEvent e) {
        pan = dragLeftLeg = dragRightLeg = dragTop = dragBase = false;
        Stats oldStats = stats;
        Dimension d = new Dimension(
                (int) (layout.getCurrentSize().width * scalex), 
                (int) (layout.getCurrentSize().height * scaley));

        stats = new Stats(getMinX() / d.width, getMinY() / d.height, 
                d.width / getWidth(), d.height / getHeight());
        firePropertyChange("Lens", oldStats, stats);
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.awt.event.MouseListener#mouseEntered(java.awt.event.MouseEvent)
     */
    public void mouseEntered(MouseEvent e) {
        outside = false;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.awt.event.MouseListener#mouseExited(java.awt.event.MouseEvent)
     */
    public void mouseExited(MouseEvent e) {
        outside = true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.awt.event.MouseMotionListener#mouseDragged(java.awt.event.MouseEvent)
     */
    public void mouseDragged(MouseEvent e) {
        if (outside)
            return;
        double mx = e.getX();
        double my = e.getY();
        Point2D epoint = new Point2D.Double(e.getX(), e.getY());
        Rectangle2D oldLens = getBounds2D();

        if (pan) {
            setRect(mx - offx, my - offy, getWidth(), getHeight());
        } else {
            double dw = 0.0;
            double dh = 0.0;

            if (dragRightLeg) {

                dw = mx - getMaxX();
                dh = dw / aspectRatio;

            } else if (dragLeftLeg) {
                dw = getMinX() - mx;
                dh = dw / aspectRatio;

            } else if (dragBase) {
                dh = my - getMaxY();
                dw = dh * aspectRatio;

            } else if (dragTop) {
                dh = getMinY() - my;
                dw = dh * aspectRatio;
            }
            double pwidth = getMaxX() - getMinX();
            double pheight = getMaxY() - getMinY();
            double newWidth = pwidth + 2 * dw;
            double newHeight = pheight + 2 * dh;
            if (newWidth < 3 || newHeight < 3)
                return;
            setRect(getMinX() - dw, getMinY() - dh, newWidth, newHeight);
        }

        rightLeg = new Line2D.Double(getMaxX(), getMinY(), getMaxX(), getMaxY());
        leftLeg = new Line2D.Double(getMinX(), getMinY(), getMinX(), getMaxY());
        base = new Line2D.Double(getMinX(), getMaxY(), getMaxX(), getMaxY());
        top = new Line2D.Double(getMinX(), getMinY(), getMaxX(), getMinY());

        Stats oldStats = stats;
        Dimension d = new Dimension(
                (int) (layout.getCurrentSize().width * scalex), (int) (layout
                        .getCurrentSize().height * scaley));

        stats = new Stats(getMinX() / d.width, getMinY() / d.height, d.width
                / getWidth(), d.height / getHeight());
        firePropertyChange("Lens", oldStats, stats);
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.awt.event.MouseMotionListener#mouseMoved(java.awt.event.MouseEvent)
     */
    public void mouseMoved(MouseEvent e) {
    }

    /**
     * A C-struct like object to carry data in the
     * PropertyChangeEvent
     */
    public static class Stats {
        
        public double offsetx;

        public double offsety;

        public double scalex;

        public double scaley;

        public Stats(double offsetx, double offsety, double scalex,
                double scaley) {
            this.offsetx = offsetx;
            this.offsety = offsety;
            this.scalex = scalex;
            this.scaley = scaley;
        }

        public String toString() {
            return "offsetx=" + offsetx + ", offsety=" + offsety + ", scalex="
                    + scalex + ", scaley=" + scaley;
        }
    }

    public void addPropertyChangeListener(String name, PropertyChangeListener l) {
        if (support == null) {
            support = new PropertyChangeSupport(this);
        }
        support.addPropertyChangeListener(name, l);
    }

    public void removePropertyChangeListener(PropertyChangeListener l) {
        if (support != null) {
            support.removePropertyChangeListener(l);
        }
    }

    public void firePropertyChange(String name, Object oldValue, Object newValue) {
        if (support != null) {
            support.firePropertyChange(name, oldValue, newValue);
        }
    }
}