// Beta
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
*   XP Look and Feel                                                           *
*                                                                              *
*  (C) Copyright 2002, by Stefan Krause                                        *
*                                                                              *
*                                                                              *
*   This library is free software; you can redistribute it and/or modify it    *
*   under the terms of the GNU Lesser General Public License as published by   *
*   the Free Software Foundation; either version 2.1 of the License, or (at    *
*   your option) any later version.                                            *
*                                                                              *
*   This library is distributed in the hope that it will be useful,            *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of             *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                       *
*   See the GNU Lesser General Public License for more details.                *
*                                                                              *
*   You should have received a copy of the GNU General Public License along    *
*   with this program; if not, write to the Free Software Foundation, Inc.,    *
*   59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.                    *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package com.stefankrause.xplookandfeel;

import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.SwingConstants;
import javax.swing.plaf.ComponentUI;

import com.stefankrause.xplookandfeel.skin.Skin;
import com.stefankrause.xplookandfeel.skin.SkinSimpleButtonIndexModel;

/**
 * A button placed in the title frame of a internal frame to enable
 * closing, iconifying and maximizing of the internal frame.
 */
public class XPSpinnerButtonUI extends XPButtonUI {
    
    int type;

	/** The only instance for this UI */
    private static final String[] files={"XPSpinnerUp.res","XPSpinnerDown.res"};
    private static final String[] arrowfiles={"XPSpinnerUpArrows.res","XPSpinnerDownArrows.res"};
    /** the index model for the window buttons */
    private static SkinSimpleButtonIndexModel indexModel=new SkinSimpleButtonIndexModel(0,1,2,4); 
    
	static Skin skins[]=new Skin[2];
    static Skin arrowSkins[]=new Skin[2];
    
	public static ComponentUI createUI(JComponent c) {
        throw new IllegalStateException("Must not be used this way.");
	}
    
    /**
     * Creates a new Spinner Button. Use either SwingConstants.SOUTH or SwingConstants.NORTH
     * for a SpinnerButton of Type up or a down.
     * @param type
     */
    XPSpinnerButtonUI(int type)
    {
        this.type=type;   
    }

    public void paint(Graphics g, JComponent c) {

        AbstractButton button = (AbstractButton) c;

        indexModel.setButton(button);
        int index=indexModel.getIndexForState();
        // Paint the spinner button
        getSkin(type).draw(g, index,  button.getWidth(),  button.getHeight());
        // Paint the arrow for the button
        getArrowSkin(type).drawCentered(g, index,  button.getWidth(),  button.getHeight());

    }    

    /**
     * returns the spinner button
     * @param type
     * @return Skin
     */
	public static Skin getSkin(int type) {
        switch (type)
        {
            case SwingConstants.NORTH:
                skins[0]=new Skin(files[0],4, 2);
                return skins[0];
            case SwingConstants.SOUTH:              
                skins[1]=new Skin(files[1],4, 2);
                return skins[1];
            default:
                throw new IllegalStateException("type must be either SwingConstants.SOUTH or SwingConstants.NORTH for XPSpinnerButton");
        }
	}
    
    /**
     * returns the spinner button's arrow
     * @param type
     * @return Skin
     */
    protected Skin getArrowSkin(int type) {
        switch (type)
        {
            case SwingConstants.NORTH:
                arrowSkins[0]=new Skin(arrowfiles[0],4, 2);
                return arrowSkins[0];
            case SwingConstants.SOUTH:              
                arrowSkins[1]=new Skin(arrowfiles[1],4, 2);
                return arrowSkins[1];
            default:
                throw new IllegalStateException("type must be either SwingConstants.SOUTH or SwingConstants.NORTH for XPSpinnerButton");
        }
    }    
    
	/**
	 * @see javax.swing.plaf.basic.BasicButtonUI#getPreferredSize(javax.swing.JComponent)
	 */
	public Dimension getPreferredSize(JComponent c) {
		return new Dimension( getSkin(type).getHsize(), getSkin(type).getVsize() );
	}


}
