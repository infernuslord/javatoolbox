// $Id: ElementOrAttributeTest.java,v 1.1 2002/04/25 18:06:25 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

class ElementOrAttributeTest implements Pattern 
{
    private final Name name;

    ElementOrAttributeTest(Name name) 
    {
        this.name = name;
    }

    public boolean matches(Node node, ExprContext context) 
    {
        return (name.equals(node.getName())
                && node.getType() != Node.PROCESSING_INSTRUCTION);
    }
}
