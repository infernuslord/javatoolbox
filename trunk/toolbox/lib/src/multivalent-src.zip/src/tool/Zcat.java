package tool;

import java.io.*;
import java.util.Iterator;
import java.util.List;

import phelps.io.FileList;
import phelps.io.Streams;
import phelps.io.InputStreams;



/**
	Uncompress compressed data of several formats: UNIX compress, Flate, BZip2.

	@version $Revision: 1.6 $ $Date: 2003/08/29 04:42:21 $
*/
public class Zcat {
  static final boolean DEBUG = true;

  public static final String VERSION = "1.0 of $Date: 2003/08/29 04:42:21 $";
  public static final String USAGE = "java tool.Zcat [options] <file...>";//\n"
//	+ "\t[-fast] [-full] [-dev] [-password <password>]";

  private boolean fverbose_, fquiet_, fmonitor_;
  private PrintStream out_;


  public Zcat() {
	defaults();
  }

  public void defaults() {

	fverbose_ = fquiet_ = fmonitor_ = false;
	out_ = phelps.io.PrintStreams.DEVNULL;
  }



  /** Returns true iff PDF valid. */
  public void zcat(File file) throws IOException {
	if (fverbose_) System.out.println(file);
    assert file!=null && file.exists();

	InputStream in = InputStreams.uncompress(new BufferedInputStream(new FileInputStream(file)), file.toString());
	Streams.copy(in, out_, true);
  }



  private int commandLine(String[] argv) {
	out_ = System.out;

	int argi = 0, argc = argv.length;
	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.equals("-label")) {}

		else if (arg.startsWith("-verb")) fverbose_ = true;
		//else if (arg.startsWith("-q"/*uiet*/)) fquiet = true;
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.startsWith("-h"/*"elp"*/)) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	if (argi == argc) { System.err.println(USAGE); System.exit(0); }

	return argi;
  }

  public static void main(String[] argv) {
	Zcat z = new Zcat();
    int argi = z.commandLine(argv);

	for (Iterator<File> i = new FileList(argv, argi, null).iterator(); i.hasNext(); ) {
		File file = i.next();
		try {
			//if (fquiet_) System.out.println(file);
			z.zcat(file);
		} catch (Exception ioe) {
			System.err.println(file+": "+ioe);
			if (DEBUG) ioe.printStackTrace();
		}
	}
  }
}
