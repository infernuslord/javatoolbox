/*
 * Please see COPYING for license details
 *
 * Copyright (C) 2003 Raghu K, All rights reserved.
 */

package hamsam.protocol;

import hamsam.api.Buddy;
import hamsam.api.Conference;
import hamsam.api.IMListener;
import hamsam.api.Message;
import hamsam.api.SmileyComponent;
import hamsam.exception.IllegalArgumentException;
import hamsam.exception.IllegalStateException;
import hamsam.exception.UnsupportedOperationException;
import hamsam.net.ProxyInfo;

/**
 * A protocol is a specific implementation of instant messaging services.
 * Popular examples of instant messaging services are MSN, Yahoo!, NIM etc.
 *
 * <p>
 * Hamsam provides an implementation independent way of dealing with
 * protocols through this interface. Each of the protocols implements the
 * methods in this interface, so that a user of Hamsam library can use
 * these methods to talk to any protocol available.
 *
 * <p>
 * This also makes Hamsam a plug-and-play library. The <code>Protocol</code>
 * interface along with the <code>ProtocolManager</code> class, helps
 * to easily add new protocols, without any change to the source code. This
 * means that, if you have an application coded properly, you don't need to
 * change that code, as and when new versions of Hamsam library (with new
 * protocol additions) are released.
 *
 * @author Raghu
 * @see    ProtocolManager ProtocolManager
 */
public interface Protocol
{
	/**
	 * Change the status message for the user logged in for this protocol.
	 * If <code>status</code> is <code>null</code>, the status is changed
	 * to invisible. If this protocol does not support invisible status,
	 * it throws an IllegalArgumentException.
	 * <p>
	 * A protocol may support only a limited range of status messages. If you
	 * pass a status message which is not supported by the underlying protocol,
	 * it will throw an IllegalArgumentException. In order to get a complete list
	 * of supported status messages, use the getSupportedStatusMessages() method.
	 *
	 * @param status                          the new status message.
	 * @throws IllegalArgumentException       if <code>status</code> is null and this
	 *                                        protocol does not support invisible status,
	 *                                        or the status message is invalid.
	 * @throws IllegalStateException          if the protocol is not connected.
	 * @see #isInvisibleSupported()           isInvisibleSupported()
	 * @see #getSupportedStatusMessages()     getSupportedStatusMessages()
	 */
	public void changeStatus(String status) throws IllegalArgumentException, IllegalStateException;

	/**
	 * Connect to the instant messaging server. This is equivalent
	 * to the logging in to the service.
	 *
	 * @param username the user id to log in.
	 * @param password the password for authentication.
	 * @param info     the proxy information explaining how to connect.
	 *
	 * @throws IllegalStateException if no listener is set using the
	 *                               {@link #setListener(IMListener) setListener} method.
	 */
	public void connect(String username, String password, ProxyInfo info) throws IllegalStateException;

	/**
	 * Disconnect from the instant messaging service. This is equivalent to
	 * logging out from the service.
	 *
	 * @throws IllegalStateException if the protocol is not connected.
	 */
	public void disconnect() throws IllegalStateException;

	/**
	 * Returns the name of this protocol. This method is used to
	 * distinguish each of the protocols supported by the API. No two protocols
	 * will have the same name. The name is a symbolic one like Yahoo or MSN that
	 * may be displayed to the end-user to identify this protocol.
	 *
	 * @return the identifying name of this protocol.
	 */
	public String getProtocolName();

	/**
	 * Determines whether this protocol will notify you if
	 * a user attempts to add you to his / her buddy list.
	 *
	 * @return <code>true</code> if this protocol supports buddy add notifications,
	 *         <code>false</code> otherwise.
	 */
	public boolean isBuddyAddRequestSupported();

	/**
	 * Determines whether this protocol supports buddy name aliases.
	 * Some protocols supports a nickname (friendly name) for buddies.
	 *
	 * @return <code>true</code> if this protocol supports buddy aliases,
	 *         <code>false</code> otherwise.
	 */
	public boolean isBuddyNameAliasSupported();

	/**
	 * Determines whether this protocol supports arranging buddies in
	 * different groups.
	 *
	 * @return <code>true</code> if this protocol supports buddy groups,
	 *         <code>false</code> otherwise.
	 */
	public boolean isBuddyGroupSupported();

	/**
	 * Determines whether this protocol supports ignoring
	 * buddies. Ignored buddies can not send messages to
	 * the person who ignored them.
	 *
	 * @return <code>true</code> if this protocol supports buddy ignore,
	 *         <code>false</code> otherwise.
	 */
	public boolean isIgnoreSupported();

	/**
	 * Determines whether this protocol supports sending and
	 * receiving offline messages. Offline messages are messages
	 * which are sent when the receipient is not connected to
	 * the instant messaging system. These messages are stored
	 * by the instant messaging server and later delivered to the
	 * receipient when he / she connects to the system.
	 *
	 * @return <code>true</code> if this protocol supports offline messages,
	 *         <code>false</code> otherwise.
	 */
	public boolean isOfflineMessageSupported();

	/**
	 * Determines whether this protocol supports typing notifications.
	 * In an instant messaging session, some protocols inform one user
	 * that the other person starts or stops typing.
	 *
	 * @return <code>true</code> if this protocol supports typing notifications,
	 *         <code>false</code> otherwise.
	 */
	public boolean isTypingNotifySupported();

	/**
	 * Determines whether this protocol supports conferences.
	 *
	 * @return <code>true</code> if this protocol supports conferences,
	 *         <code>false</code> otherwise.
	 * @see hamsam.api.Conference Conference
	 */
	public boolean isConferenceSupported();

	/**
	 * Determines whether this protocol supports e-mail alerts. Many protcols have
	 * associated e-mail accounts. When an e-mail arrives in that account, a
	 * notification is sent.
	 * @return <code>true</code> if this protocol supports e-mail notifications,
	 *         <code>false</code> otherwise.
	 */
	public boolean isMailNotifySupported();

	/**
	 * Determines whether this protocol supports setting the status of the
	 * user to invisible. Invisible users appear as offline to other users
	 * although they can send and receive messages and participate in any
	 * other operations.
	 *
	 * @return <code>true</code> if this protocol supports invisible status,
	 *         <code>false</code> otherwise.
	 */
	public boolean isInvisibleSupported();

	/**
	 * Sets the listener for this protocol. This listener will be notified for
	 * any instant message events that originates from this protocol.
	 *
	 * @param listener the listener for this protocol, pass <code>null</code>
	 *                 to unregister the current listener.
	 */
	public void setListener(IMListener listener);

	/**
	 * Start a new conference by inviting some buddies.
	 *
	 * @param conf the conference which is to be started.
	 * @param message the invitation message to be sent.
	 *
	 * @throws UnsupportedOperationException if this protocol does not support
	 *                                       conferences.
	 * @throws IllegalStateException if the protocol is not yet connected.
	 */
	public void startConference(Conference conf, String message) throws UnsupportedOperationException, IllegalStateException;

	/**
	 * Disconnect the current user from a conference.
	 *
	 * @param conf the conference from which the user has to disconnect.
	 *
	 * @throws UnsupportedOperationException if this protocol does not support
	 *                                       conferences.
	 * @throws IllegalStateException if the protocol is not yet connected.
	 */
	public void quitConference(Conference conf) throws UnsupportedOperationException, IllegalStateException;

	/**
	 * Send a conference message.
	 *
	 * @param conf the conference to which the message is to be sent.
	 * @param message the instant message to be sent.
	 *
	 * @throws UnsupportedOperationException if this protocol does not support
	 *                                       conferences.
	 * @throws IllegalStateException if the protocol is not yet connected.
	 */
	public void sendConferenceMessage(Conference conf, Message message) throws UnsupportedOperationException, IllegalStateException;

	/**
	 * Add a buddy to your buddy list. The result of this operation
	 * will be notified to the registered <code>IMListener</code>.
	 *
	 * @param buddy the buddy to be added.
	 *
	 * @see IMListener#buddyAddRequest(Buddy,Buddy,String) IMListener.buddyAddRequest
	 * @see IMListener#buddyAdded(Buddy) IMListener.buddyAdded
	 * @see IMListener#buddyAddFailed(Buddy,String) IMListener.buddyAddFailed
	 *
	 * @throws IllegalArgumentException if the protocol supports buddy groups and the
	 *                                  group of the buddy is not specified.
	 * @throws IllegalStateException if the protocol is not yet connected.
	 */
	public void addToBuddyList(Buddy buddy) throws IllegalArgumentException, IllegalStateException;

	/**
	 * Delete a buddy from your buddy list. The result of this operation
	 * will be notified to the registered <code>IMListener</code>.
	 *
	 * @param buddy the buddy to be deleted.
	 *
	 * @see IMListener#buddyDeleted(Buddy) IMListener.buddyDeleted
	 * @see IMListener#buddyDeleteFailed(Buddy,String) IMListener.buddyDeleteFailed
	 *
	 * @throws IllegalArgumentException if the protocol supports buddy groups and the
	 *                                  group of the buddy is not specified.
	 * @throws IllegalStateException if the protocol is not yet connected.
	 */
	public void deleteFromBuddyList(Buddy buddy) throws IllegalArgumentException, IllegalStateException;

	/**
	 * Prevent a buddy from sending you messages. The result of this
	 * operation will be notified to the registered <code>IMListener</code>.
	 *
	 * @param buddy the buddy to be ignored.
	 *
	 * @see IMListener#buddyIgnored(Buddy) IMListener.buddyIgnored
	 * @see IMListener#buddyIgnoreFailed(Buddy,String) IMListener.buddyIgnoreFailed
	 *
	 * @throws UnsupportedOperationException if this protocol does not support ignoring buddies.
	 * @throws IllegalStateException if the protocol is not yet connected.
	 */
	public void ignoreBuddy(Buddy buddy) throws UnsupportedOperationException, IllegalStateException;

	/**
	 * Undo a previous ignore operation for a buddy. The result of this
	 * operation will be notified to the registered <code>IMListener</code>.
	 *
	 * @param buddy the buddy to be ignored.
	 *
	 * @see IMListener#buddyUnignored(Buddy) IMListener.buddyUnignored
	 * @see IMListener#buddyUnignoreFailed(Buddy,String) IMListener.buddyUnignoreFailed
	 *
	 * @throws UnsupportedOperationException if this protocol does not support ignoring buddies.
	 * @throws IllegalStateException if the protocol is not yet connected.
	 */	
	public void unignoreBuddy(Buddy buddy) throws UnsupportedOperationException, IllegalStateException;

	/**
	 * Send an instant message to a buddy.
	 *
	 * @param buddy the buddy to whom the message should be sent.
	 * @param message the message to be sent.
	 * @throws IllegalStateException if the protocol is not yet connected.
	 */
	public void sendInstantMessage(Buddy buddy, Message message) throws IllegalStateException;

	/**
	 * Notify this buddy that you have started typing.
	 *
	 * @param buddy the buddy to whom the typing notification is to be sent.
	 *
	 * @throws UnsupportedOperationException if this protocol does not support
	 *                                       typing notifications.
	 * @throws IllegalStateException if the protocol is not yet connected.
	 */
	public void typingStarted(Buddy buddy) throws UnsupportedOperationException, IllegalStateException;

	/**
	 * Notify this buddy that you have stopped typing.
	 *
	 * @param buddy the buddy to whom the typing notification is to be sent.
	 *
	 * @throws UnsupportedOperationException if this protocol does not support
	 *                                       typing notifications.
	 * @throws IllegalStateException if the protocol is not yet connected.
	 */
	public void typingStopped(Buddy buddy) throws UnsupportedOperationException, IllegalStateException;

	/**
	 * Returns an array of all SmileyComponents supported by this protocol.
	 *
	 * @return an array of all SmileyComponents supported by this protocol.
	 */
	public SmileyComponent[] getSupportedSmileys();

	/**
	 * Returns an array of status messages supported by this protocol. Some protocols
	 * may support any status message, in that case a <code>null</code> is returned.
	 *
	 * @return array of status messages supported by this protocol, or <code>null</code>
	 *         if this protocol supports any status message.
	 */
	public String[] getSupportedStatusMessages();

	/**
	 * Changes the alias of a buddy.
	 *
	 * @param buddy the buddy whose alias needs to be changed.
	 * @param alias the new alias of this buddy.
	 * @throws UnsupportedOperationException if this protocol does not support
	 *                                       buddy aliases.
	 * @see #isBuddyNameAliasSupported() isBuddyNameAliasSupported() 
	 */
	public void changeBuddyAlias(Buddy buddy, String alias) throws UnsupportedOperationException;
}
