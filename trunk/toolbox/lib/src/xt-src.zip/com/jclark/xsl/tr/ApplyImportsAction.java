// $Id: ApplyImportsAction.java,v 1.1 2002/04/25 18:16:57 bill Exp $

package com.jclark.xsl.tr;

import com.jclark.xsl.om.*;

/**
 *
 */
class ApplyImportsAction implements Action
{
    public void invoke(ProcessContext context, 
                       Node sourceNode, Result result) throws XSLException
    {
        context.applyImports(sourceNode, result);
    }
}
