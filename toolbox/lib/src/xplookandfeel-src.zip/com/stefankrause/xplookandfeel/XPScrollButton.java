// Beta
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	XP Look and Feel                                                           *
*                                                                              *
*  (C) Copyright 2002, by Stefan Krause                                        *
*                                                                              *
*                                                                              *
*   This library is free software; you can redistribute it and/or modify it    *
*   under the terms of the GNU Lesser General Public License as published by   *
*   the Free Software Foundation; either version 2.1 of the License, or (at    *
*   your option) any later version.                                            *
*                                                                              *
*   This library is distributed in the hope that it will be useful,            *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of             *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                       *
*   See the GNU Lesser General Public License for more details.                *
*                                                                              *
*   You should have received a copy of the GNU General Public License along    *
*   with this program; if not, write to the Free Software Foundation, Inc.,    *
*   59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.                    *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


package com.stefankrause.xplookandfeel;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;

import javax.swing.SwingConstants;
import javax.swing.plaf.metal.MetalScrollButton;

import com.stefankrause.xplookandfeel.skin.Skin;
import com.stefankrause.xplookandfeel.skin.SkinSimpleButtonIndexModel;

/**
 * This button is placed at either end of a scrollbar to move the scrollbar
 */
public class XPScrollButton extends MetalScrollButton {
	
	/** one of the four skins for the button */ 
	private static Skin skinUp= new Skin("XPScrollbuttonsUp.res", 4, 0);
	/** one of the four skins for the button */
	private static Skin skinDown= new Skin("XPScrollbuttonsDown.res", 4, 0);
	/** one of the four skins for the button */
	private static Skin skinLeft= new Skin("XPScrollbuttonsLeft.res", 4, 0);
	/** one of the four skins for the button */
	private static Skin skinRight= new Skin("XPScrollbuttonsRight.res", 4, 0);
	
	/** the skin used for this instance of the scroll button */
	private Skin skin;
	/** the index model for this button */
	private SkinSimpleButtonIndexModel indexModel=new SkinSimpleButtonIndexModel();

	/**
	 * Create a new ScrollButton.
	 * @see javax.swing.plaf.metal.MetalScrollButton#MetalScrollButton(int, int, boolean)
	 */
	public XPScrollButton(int orientation,int width, boolean freeStanding) {
		super(orientation, width, freeStanding);
		setBorder(null);
		setRolloverEnabled(true);
		setMargin(new Insets(0, 0, 0, 0));
		setBorder(null);
		indexModel.setButton(this);
		
		switch (orientation)
		{
			case SwingConstants.NORTH: 
				skin= skinUp;
				break; 
			case SwingConstants.SOUTH:
				skin= skinDown;
				break;
			case SwingConstants.EAST:
				skin= skinRight;
				break;
			case SwingConstants.WEST:
				skin= skinLeft;
				break;
		}
	}


	/**
	 * Paints the button
	 * @see java.awt.Component#paint(Graphics)
	 */
	public void paint(Graphics g) {
		skin.draw(g, indexModel.getIndexForState(), getWidth(), getHeight());
	}

	/**
	 * Returns the preferred size of the component wich is the size of the skin
	 * @see java.awt.Component#getPreferredSize()
	 */
	public Dimension getPreferredSize() {
		return new Dimension(skinUp.getHsize(),skinUp.getVsize());
	}
	
	/**
	 * Returns the skin for a button with the arrow pointing upwards
	 * @return Skin
	 */
	public static Skin getSkinUp()
	{
		return skinUp;	
	}
	
	/**
	 * Returns the skin for a button with the arrow pointing downwards
	 * @return Skin
	 */
	public static Skin getSkinDown()
	{
		return skinDown;
	}
	
	/**
	 * Returns the skin for a button with the arrow pointing to the left
	 * @return Skin
	 */
	public static Skin getSkinLeft()
	{
		return skinLeft;
	}
	
	/**
	 * Returns the skin for a button with the arrow pointing to the right
	 * @return Skin
	 */
	public static Skin getSkinRight()
	{
		return skinRight;
	}
	
	/**
	 * returns the skin for this instance of the button.
	 * @return Skin
	 */
	public Skin getSkin()
	{
		return skin;	
	}
}