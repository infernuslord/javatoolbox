package phelps.io;

import java.io.RandomAccessFile;
import java.io.File;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;



/**
	A RandomAccessFile interface to a <code>byte[]</code>,
	in the same way {@link java.io.ByteArrayInputStream} provides an InputStream interface.

	<p>Does not subclass {@link java.io.RandomAccessFile} because
	we want to use this class in restriced situations where reading of local files is not permitted
	and RAF always checks the readability of its file.
<!-- does not extend RancomAccess
	<p><em>WARNING!</em>  This class is not an exact drop-in replacement for RandomAccessFile.
	Do not use the two methods inherited from {@link RandomAccessFile}:
		{@link RandomAccessFile#writeBytes(String s)} and
		{@link RandomAccessFile#writeChars(String s)}.
		They are not compatible with buffered use.
	<em>Instead use</em> the methods {@link #writeString8(String)} and {@link #writeString16(String)}, respectively.
	(Also, {@link java.lang.String}s can also be written as UTF-8 with {@link RandomAccessFile#writeUTF(String)}).
-->

	@see BufferedRandomAccessFile
*/
public class ByteArrayRAF /*extends RandomAccessFile*/implements RandomAccess {
  private String mode_;

  private static final File READABLE_FILE;
  static {
	// is any file readable from within an applet / Java Web Start ?
	String path = new Integer(0).getClass().getResource("Integer.class").getPath();  // "jar:file:/.../rt.jar!/java/lang/Integer.class"
	int inx = path.indexOf('!'); if (inx != -1) path = path.substring(0,inx);
	if (path.startsWith("file:")) path = path.substring("file:".length());
	READABLE_FILE = new File(phelps.net.URIs.decode(path));
  }


  private byte[] buf_;
  private long pos_ = 0;
  private long length_;

  public ByteArrayRAF(byte[] buf, String mode) throws FileNotFoundException {
	//try { -- can't do this -- superclass constructor has to be absolute first
	//super(READABLE_FILE, "r");  // work even if no write permission to local file system
	//try { super.close(); } catch (IOException ignore) {} // don't use that file -- just to satisfy constructor

	buf_ = buf;
	length_ = buf.length;
	mode_ = mode;
  }

/*  public ByteArrayRAF(File, long offset, long length) throws IOException {
  }*/

  /**
	Sets contents from remainder of <var>in</var> and closes <var>in</var>.
  */
  public ByteArrayRAF(InputStream in, String mode) throws IOException {
	ByteArrayOutputStream out = new ByteArrayOutputStream(8*1024);
	byte[] buf = new byte[8*1024]; for (int len; (len = in.read(buf)) >= 0; ) out.write(buf,0,len);
	buf_ = out.toByteArray();
	out.close();
	in.close();

	//this(buf, mode); -- illegal
	mode_ = mode;
	length_ = buf_.length;
  }


  private void resize(long length) {
	if (length != buf_.length) {
		byte[] newbuf = new byte[(int)length];
		System.arraycopy(buf_,0, newbuf,0, (int)Math.min(buf_.length, length));
		buf_ = newbuf;
	}
  }


  public int read(byte[] b) { return read(b, 0, b.length); }

  public int read(byte[] b, int off, int len) {
	assert b!=null && off>=0 && len>=0 && len+off <= b.length;
	if (len == 0) return 0;
	else if (getFilePointer() == length()) return -1;

	len = Math.min(len, (int)(length() - getFilePointer()));
	System.arraycopy(buf_,(int)pos_, b,off, len);
	pos_ += len;
	return len;
  }

  public int read() { return getFilePointer() < length()? buf_[(int)pos_++] & 0xff: -1; }

  public void readFully(byte[] b) throws IOException { read(b); }
  public void readFully(byte[] b, int off, int len) throws IOException { read(b,off,len); }


  public void writeString8(String s) throws IOException { for (int i=0,imax=s.length(); i<imax; i++) write(s.charAt(i)); }
  public void writeString16(String s) throws IOException { for (int i=0,imax=s.length(); i<imax; i++) writeChar(s.charAt(i)); }
  public void writeChar(char ch) throws IOException { write(ch>>8); write((int)ch); }

  public void write(byte[] b) throws IOException { write(b, 0, b.length); }

  public void write(byte[] b, int off, int len) throws IOException {
	if (mode_.indexOf("w")!=-1) throw new IOException("File not opened for writing");   // throw unchecked instead?
	assert b!=null && off>=0 && len>=0 && off+len <= b.length;

	long newlen = Math.max(getFilePointer() + len, length());
	if (newlen > buf_.length) { resize(newlen + 100*1024); length_ = newlen; }  // double in size?
	System.arraycopy(b,off, buf_,(int)pos_, len);
	pos_ += len;
  }

  public void write(int b) throws IOException {
	if (mode_.indexOf("w")!=-1) throw new IOException("File not opened for writing");

	if (getFilePointer() + 1 > buf_.length) { resize(length() + 100*1024); length_++; }   // extra space so can keep writing without reallocating after each byte
	buf_[(int)pos_++] = (byte)b;
  }

/*
  public void writeTo(RandomAccess w, int len) throws IOException {
	long now = getFilePointer();
	long newlen = Math.min(now + len, length());
	w.write(buf_, (int)now, (int)newlen);
	pos_ += len;
  }

  public void writeTo(OutputStream w, int len) throws IOException {
	long now = getFilePointer();
	long newlen = Math.min(now + len, length());
	w.write(buf_, (int)now, (int)newlen);
	pos_ += len;
  }
*/


  public long getFilePointer() { return pos_; }

  public void setLength(long newLength) {
	assert newLength >= 0;
	resize((int)newLength);
	length_ = newLength;
  }

  public long length() { return length_; }

  public void seek(long pos) {
	pos_ = Math.max(0, Math.min(length(), pos));
	assert pos == pos_: pos + " != "+pos_;;
  }

  public int skipBytes(int n) throws IOException {
	long now = getFilePointer();
	seek(now + n);
	return (int)(getFilePointer() - now);
  }

  public void close() {
	//super.close();  // ?
	buf_ = null;
  }


  public byte[] getByteArray() {
	byte[] buf = new byte[(int)length_];
	System.arraycopy(buf_,0, buf,0, (int)length_);
	return buf;
  }

/*  public static void main(String[] argv) {
	try {
		RandomAccessFile raf = new ByteArrayRAF(new byte[20], "rw");
		raf.read();
		raf.close();
	} catch (Exception e) {
		System.err.println("shouldn't happen: "+e);
	}
  }*/
}
