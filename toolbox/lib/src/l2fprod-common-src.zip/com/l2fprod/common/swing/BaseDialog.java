/** ===================================================================
 *
 * @PROJECT.FULLNAME@ @VERSION@ License.
 *
 * Copyright (c) @YEAR@ L2FProd.com.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by L2FProd.com
 *        (http://www.L2FProd.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "@PROJECT.FULLNAME@", "@PROJECT.SHORTNAME@" and "L2FProd.com" must not
 *    be used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact info@L2FProd.com.
 *
 * 5. Products derived from this software may not be called "@PROJECT.SHORTNAME@"
 *    nor may "@PROJECT.SHORTNAME@" appear in their names without prior written
 *    permission of L2FProd.com.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL L2FPROD.COM OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package com.l2fprod.common.swing;

import com.l2fprod.common.util.ResourceManager;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.KeyStroke;

/**
 * BaseDialog. <br>Adds:
 * <ul>
 * <li>support for ESCAPE key to dispose the window</li>
 * <li>ok, cancel methods</li>
 * <li>simple method to check if ok or cancel was called ({link #ask})</li>
 * <li>button pane</li>
 * <li>banner pane
 * <li>
 * </ul>
 */
public class BaseDialog extends JDialog {

  public final static int OK_CANCEL_DIALOG = 0;

  public final static int CLOSE_DIALOG = 1;

  private BannerPanel banner;
  private JPanel contentPane;
  private JPanel buttonPane;
  private boolean cancelClicked;

  private JButton okButton;
  private JButton cancelOrCloseButton;

  private Action okAction = new AbstractAction() {
    public void actionPerformed(ActionEvent e) {
      ok();
    }
  };

  private Action cancelOrCloseAction = new AbstractAction() {
    public void actionPerformed(ActionEvent e) {
      cancel();
    }
  };

  public BaseDialog() throws HeadlessException {
    super();
    buildUI();
  }

  public BaseDialog(Dialog owner) throws HeadlessException {
    super(owner);
    buildUI();
  }

  public BaseDialog(Dialog owner, boolean modal) throws HeadlessException {
    super(owner, modal);
    buildUI();
  }

  public BaseDialog(Frame owner) throws HeadlessException {
    super(owner);
    buildUI();
  }

  public BaseDialog(Frame owner, boolean modal) throws HeadlessException {
    super(owner, modal);
    buildUI();
  }

  public BaseDialog(Dialog owner, String title) throws HeadlessException {
    super(owner, title);
    buildUI();
  }

  public BaseDialog(Dialog owner, String title, boolean modal)
    throws HeadlessException {
    super(owner, title, modal);
    buildUI();
  }

  public BaseDialog(Frame owner, String title) throws HeadlessException {
    super(owner, title);
    buildUI();
  }

  public BaseDialog(Frame owner, String title, boolean modal)
    throws HeadlessException {
    super(owner, title, modal);
    buildUI();
  }

  public BaseDialog(
    Dialog owner,
    String title,
    boolean modal,
    GraphicsConfiguration gc)
    throws HeadlessException {
    super(owner, title, modal, gc);
    buildUI();
  }

  public BaseDialog(
    Frame owner,
    String title,
    boolean modal,
    GraphicsConfiguration gc) {
    super(owner, title, modal, gc);
    buildUI();
  }

  public final BannerPanel getBanner() {
    return banner;
  }

  public final Container getContentPane() {
    return contentPane;
  }

  /**
   * Returns true if OK was clicked, false if CANCEL or CLOSE was clicked
   * 
   * @return
   */
  public boolean ask() {
    show();
    dispose();
    return !cancelClicked;
  }

  public void ok() {    
    cancelClicked = false;
    setVisible(false);
  }

  public void cancel() {
    cancelClicked = true;
    setVisible(false);
  }

  public void setDialogMode(int mode) {
    if (okButton != null) {
      buttonPane.remove(okButton);
      okButton = null;
    }
    if (cancelOrCloseButton != null) {
      buttonPane.remove(cancelOrCloseButton);
      cancelOrCloseButton = null;
    }

    switch (mode) {
      case OK_CANCEL_DIALOG :
        okButton =
          new JButton(ResourceManager.all(BaseDialog.class).getString("ok"));
        okButton.addActionListener(okAction);
        buttonPane.add(okButton);
        cancelOrCloseButton =
          new JButton(
            ResourceManager.all(BaseDialog.class).getString("cancel"));
        cancelOrCloseButton.addActionListener(cancelOrCloseAction);
        buttonPane.add(cancelOrCloseButton);
        break;
      case CLOSE_DIALOG :
        cancelOrCloseButton =
          new JButton(ResourceManager.all(BaseDialog.class).getString("close"));
        cancelOrCloseButton.addActionListener(cancelOrCloseAction);
        buttonPane.add(cancelOrCloseButton);
        break;
      default :
        throw new IllegalArgumentException("invalid dialog mode");
    }

  }

  public void centerOnScreen() {
    UIUtilities.centerOnScreen(this);
  }
  
  private void buildUI() {
    Container container = super.getContentPane();
    container.setLayout(new BorderLayout(0, 0));

    banner = new BannerPanel();
    container.add("North", banner);

    JPanel contentPaneAndButtons = new JPanel();
    contentPaneAndButtons.setLayout(LookAndFeelTweaks.createVerticalPercentLayout());
    contentPaneAndButtons.setBorder(LookAndFeelTweaks.WINDOW_BORDER);
    container.add("Center", contentPaneAndButtons);
    
    contentPane = new JPanel();
    LookAndFeelTweaks.setBorderLayout(contentPane);
    LookAndFeelTweaks.setBorder(contentPane);
    contentPaneAndButtons.add(contentPane, "*");
    
    contentPaneAndButtons.add(new JSeparator(JSeparator.HORIZONTAL));

    buttonPane = new JPanel();
    buttonPane.setLayout(LookAndFeelTweaks.createButtonAreaLayout());
    LookAndFeelTweaks.setBorder(buttonPane);
    contentPaneAndButtons.add(buttonPane);

    // layout is done, now everything about "cancel", "escape key" and "click
    // on close in window bar"
    setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

    ((JComponent)container).registerKeyboardAction(
      cancelOrCloseAction,
      KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
      JComponent.WHEN_IN_FOCUSED_WINDOW);

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        cancel();
      }
    });
  }

}
