/*
 * 
 * Created on 2004-jun-29
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.ui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.AbstractButton;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.UIManager;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.UIResource;
import javax.swing.plaf.basic.BasicMenuUI;

import se.diod.hippo.plaf.renderer.MenuItemRenderer;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jun-29
 *
 */
public class HippoMenuUI extends BasicMenuUI {
	private static final String MENU_PROPERTY_PREFIX    = "Menu";
	private static final String SUBMENU_PROPERTY_PREFIX = "MenuItem";

	// May be changed to SUBMENU_PROPERTY_PREFIX later
	private String propertyPrefix = MENU_PROPERTY_PREFIX;  

	private MenuItemRenderer renderer;
	private MouseListener    mouseListener;




	/////////////////////////////////////////////////
	//                   Create                    //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	public static ComponentUI createUI(JComponent b) {
		return new HippoMenuUI();
	}




	/////////////////////////////////////////////////
	//                  Install                    //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	protected void installDefaults() {
		super.installDefaults();

		if (arrowIcon == null || arrowIcon instanceof UIResource) {
			arrowIcon = UIManager.getIcon("Menu.arrowIcon");
		}

		renderer			= new MenuItemRenderer( menuItem, acceleratorFont, selectionForeground, disabledForeground, acceleratorForeground, acceleratorSelectionForeground);
		Integer gap			= (Integer) UIManager.get( getPropertyPrefix() + ".textIconGap" );
		defaultTextIconGap	= gap != null ? gap.intValue() : 2;
	}




	/////////////////////////////////////////////////
	//                 Uninstall                   //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	protected void uninstallDefaults() {
		renderer = null;
		super.uninstallDefaults();
	}




	/////////////////////////////////////////////////
	//                 Painting                    //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	protected void paintMenuItem(Graphics g, JComponent c, Icon aCheckIcon, Icon anArrowIcon, Color background, Color foreground, int textIconGap) {
		Graphics g2 = g.create();
		JMenuItem b = (JMenuItem) c;

		if( ( ( JMenu )menuItem ).isTopLevelMenu() ) {
			// Top menu..
			b.setOpaque( false );

			if( b.getModel().isSelected() ) {
				int menuWidth  = menuItem.getWidth();
				int menuHeight = menuItem.getHeight();

				// Draw background..
				g2.setColor( background );
				g2.fillRect( 0, 0, menuWidth, menuHeight );

				// Draw border..
				g2.setColor( UIManager.getColor( "Menu.borderColor" ) );
				g2.drawLine(           0, 0,   menuWidth,          0 );		// Top
				g2.drawLine(           0, 0,           0, menuHeight );		// Left
				g2.drawLine( menuWidth-1, 0, menuWidth-1, menuHeight );		// Right
			}
		}

		// Antialiasing fonts to get rid of the jaggies ..
		//Graphics2D g2d = (Graphics2D)g2;
		//g2d.addRenderingHints(new RenderingHints( RenderingHints.KEY_ANTIALIASING , RenderingHints.VALUE_ANTIALIAS_ON ));

		if( isSubMenu( menuItem ) ) {
			renderer.paintMenuItem( g2, c, aCheckIcon, anArrowIcon, background, foreground, textIconGap );
		} else {
			super.paintMenuItem( g2, c, aCheckIcon, anArrowIcon, background, foreground, textIconGap);
		}

		g2.dispose();
		//g2d.dispose();
	}






	/////////////////////////////////////////////////
	//                  Helpers                    //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	private boolean isSubMenu( JMenuItem aMenuItem ) {
		return !((JMenu) aMenuItem).isTopLevelMenu();
	}
	
	
	
	
	/**
	 * 
	 * Checks if we have already detected the correct menu type,
	 * menu in menu bar vs. sub menu; reinstalls if necessary.
	 * 
	 */
	private void ensureSubMenuInstalled() {
		if (propertyPrefix.equals(SUBMENU_PROPERTY_PREFIX))
			return;

		//System.out.println("Sub menu detected.");
		uninstallRolloverListener();
		uninstallDefaults();
		propertyPrefix = SUBMENU_PROPERTY_PREFIX;
		installDefaults();
	}






	/////////////////////////////////////////////////
	//                   Other                     //
	/////////////////////////////////////////////////
	protected Dimension getPreferredMenuItemSize(
		JComponent c,
		Icon aCheckIcon,
		Icon anArrowIcon,
		int textIconGap) {

		if (isSubMenu(menuItem)) {
			ensureSubMenuInstalled();
			return renderer.getPreferredMenuItemSize(
				c,
				aCheckIcon,
				anArrowIcon,
				textIconGap);
		} else
			return super.getPreferredMenuItemSize(
				c,
				aCheckIcon,
				anArrowIcon,
				textIconGap);
	}




	// Rollover Listener ****************************************************

	protected void installListeners() {
		super.installListeners();
		mouseListener = createRolloverListener();
		menuItem.addMouseListener(mouseListener);
	}

	protected void uninstallListeners() {
		super.uninstallListeners();
		uninstallRolloverListener();
	}
    
	private void uninstallRolloverListener() {
		if (mouseListener != null) {
			menuItem.removeMouseListener(mouseListener);
			mouseListener = null;
		}
	}

	protected MouseListener createRolloverListener() {
		return new MouseAdapter() {
			public void mouseEntered(MouseEvent e) {
				AbstractButton b = (AbstractButton) e.getSource();
				b.getModel().setRollover(true);
			}
			public void mouseExited(MouseEvent e) {
				AbstractButton b = (AbstractButton) e.getSource();
				b.getModel().setRollover(false);
			}
		};
	}


}
