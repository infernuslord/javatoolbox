/*
 *
 * Hamsam - Instant Messaging API
 *
 * Copyright (C) 2003 Mike Miller <mikemil@users.sourceforge.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 */

package hamsam.protocol.aim.command;

import java.io.IOException;
import java.io.OutputStream;
import hamsam.protocol.aim.flap.FlapConstants;
import hamsam.protocol.aim.flap.FlapHeader;
import hamsam.protocol.aim.snac.SNACConstants;
import hamsam.protocol.aim.snac.SNACPacket;

/**
 * @author mike
 */
public class RequestICBMParmCmd extends Command {

    /**
     * Constructor
     * 
     * @param seqNum sequence number for the FlapHeader
     * @param buddy Buddy to be ignored
     */
    public RequestICBMParmCmd(int seqNum) {
        flapHdr = new FlapHeader(FlapConstants.FLAP_CHANNEL_SNAC, seqNum);
        snacPacket = new SNACPacket(SNACConstants.SNAC_FAMILY_MESSAGING, SNACConstants.REQUEST_ICBM_PARMIFO);
    }


    /* (non-Javadoc)
     * @see hamsam.protocol.aim.command.Command#writeCommandData(java.io.OutputStream)
     */
    public void writeCommandData(OutputStream os) throws IOException {
    }

}
