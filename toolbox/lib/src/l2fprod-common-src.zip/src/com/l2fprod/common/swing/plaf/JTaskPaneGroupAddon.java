/**
 * $ $ License.
 *
 * Copyright $ L2FProd.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.l2fprod.common.swing.plaf;

import com.l2fprod.common.swing.plaf.basic.BasicLookAndFeelAddons;
import com.l2fprod.common.swing.plaf.metal.MetalLookAndFeelAddons;
import com.l2fprod.common.swing.plaf.windows.WindowsClassicLookAndFeelAddons;
import com.l2fprod.common.swing.plaf.windows.WindowsLookAndFeelAddons;

import java.awt.Color;
import java.awt.Font;
import java.awt.SystemColor;

import javax.swing.UIDefaults;
import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;

/**
 * Addon for <code>JTaskPaneGroup</code>.<br>
 *
 */
public class JTaskPaneGroupAddon implements ComponentAddon {

  public String getName() {
    return "JTaskPaneGroup";
  }

  public void initialize(LookAndFeelAddons addon) {
    if (addon instanceof BasicLookAndFeelAddons) {
      Color menuBackground = new ColorUIResource(SystemColor.menu);
      addon.loadDefaults(new Object[]{
        "TaskPaneGroupUI",
        "com.l2fprod.common.swing.plaf.basic.BasicTaskPaneGroupUI",
        "TaskPaneGroup.font",
        new FontUIResource(
          UIManager.getFont("Label.font").deriveFont(Font.BOLD)),        
        "TaskPaneGroup.background",
        UIManager.getColor("List.background"),
        "TaskPaneGroup.specialTitleBackground",
        new ColorUIResource(menuBackground.darker()),
        "TaskPaneGroup.titleBackgroundGradientStart",
        menuBackground,
        "TaskPaneGroup.titleBackgroundGradientEnd",
        menuBackground,
        "TaskPaneGroup.titleForeground",
        new ColorUIResource(SystemColor.menuText),
        "TaskPaneGroup.specialTitleForeground",
        new ColorUIResource(SystemColor.menuText).brighter(),
        "TaskPaneGroup.animate",
        Boolean.TRUE,
        "TaskPaneGroup.focusInputMap",
        new UIDefaults.LazyInputMap(
          new Object[] {
            "ENTER",
            "toggleExpanded",
            "SPACE",
            "toggleExpanded" }),
      });
    }

    if (addon instanceof MetalLookAndFeelAddons) {
      addon.loadDefaults(new Object[]{
        "TaskPaneGroupUI",
        "com.l2fprod.common.swing.plaf.metal.MetalTaskPaneGroupUI",
        "TaskPaneGroup.foreground",
        UIManager.getColor("InternalFrame.foreground"),
        "TaskPaneGroup.background",
        new ColorUIResource(214, 223, 247),
        "TaskPaneGroup.specialTitleBackground",
        UIManager.getColor("desktop").darker(),
        "TaskPaneGroup.titleBackgroundGradientStart",
        UIManager.getColor("activeCaption"),
        "TaskPaneGroup.titleBackgroundGradientEnd",
        new ColorUIResource(199, 212, 247),
        "TaskPaneGroup.titleForeground",
        UIManager.getColor("activeCaptionText"),        
        "TaskPaneGroup.specialTitleForeground",
        new ColorUIResource(Color.white),
      });      
    }
    
    if (addon instanceof WindowsLookAndFeelAddons) {
      addon.loadDefaults(new Object[]{
        "TaskPaneGroupUI",
        "com.l2fprod.common.swing.plaf.windows.WindowsTaskPaneGroupUI",
        "TaskPaneGroup.foreground",
        new ColorUIResource(Color.white),
        "TaskPaneGroup.background",
        new ColorUIResource(214, 223, 247),
        "TaskPaneGroup.specialTitleBackground",
        new ColorUIResource(33, 89, 201),
        "TaskPaneGroup.titleBackgroundGradientStart",
        new ColorUIResource(Color.white),
        "TaskPaneGroup.titleBackgroundGradientEnd",
        new ColorUIResource(199, 212, 247),
        "TaskPaneGroup.titleForeground",
        new ColorUIResource(33, 89, 201),
        "TaskPaneGroup.specialTitleForeground",
        new ColorUIResource(Color.white),
      });
    }
    
    if (addon instanceof WindowsClassicLookAndFeelAddons) {
      addon.loadDefaults(new Object[]{
        "TaskPaneGroupUI",
        "com.l2fprod.common.swing.plaf.windows.WindowsClassicTaskPaneGroupUI",
        "TaskPaneGroup.foreground",
        new ColorUIResource(Color.black),
        "TaskPaneGroup.specialTitleBackground",
        new ColorUIResource(10, 36, 106),
        "TaskPaneGroup.titleBackgroundGradientStart",
        new ColorUIResource(212, 208, 200),
        "TaskPaneGroup.titleBackgroundGradientEnd",
        new ColorUIResource(212, 208, 200),
        "TaskPaneGroup.titleForeground",
        new ColorUIResource(Color.black),
        "TaskPaneGroup.specialTitleForeground",
        new ColorUIResource(Color.white),
      });
    }
  }
  
  public void uninitialize(LookAndFeelAddons addon) {
  }

}
