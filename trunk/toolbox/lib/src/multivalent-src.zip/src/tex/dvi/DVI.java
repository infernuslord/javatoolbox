package tex.dvi;

import java.io.IOException;
import java.io.File;
import java.io.FilenameFilter;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.awt.*;  // Point, Font, Rectangle, Color, Toolkit, GraphicsEnvironment, Graphics2D, ...
import java.awt.font.TextAttribute;
import java.awt.font.FontRenderContext;
import java.awt.geom.Rectangle2D;
import java.awt.geom.AffineTransform;
import java.lang.ref.SoftReference;

import multivalent.*;
//import multivalent.node.FixedI;
import multivalent.node.Fixed;
import multivalent.node.FixedIVBox;
import multivalent.node.FixedIHBox;
import multivalent.node.FixedLeafAsciiKern; // always use kern in case concat and already throw node to HyperTeX
import multivalent.node.LeafAscii;
import multivalent.node.IVBox;
import multivalent.std.span.FontSpan;
import multivalent.std.span.SubSupSpan;
import multivalent.gui.VMenu;
import multivalent.gui.VCheckbox;

import phelps.lang.Integers;
import phelps.lang.Strings;
import phelps.lang.Booleans;
import phelps.io.RandomAccess;



/**
	Media adaptor for TeX device-independent (DVI) files, a fixed-format document type with all pages bound in one file.
	DVI data format taken from Knuth's <code>dvitype.web</code>, available on <a href='http://www.ctan.org/'>CTAN</a>.

	<p>An open-ended set of <code>\special</code>s can be implemented without modifying this parser.
	Instead, implement specials as behaviors that listen for the semantic event <code>TeXspecial</code> ({@link #MSG_SPECIAL}), which
	will have the special <code>String</code> in the argument, the last <code>Node</code> constructed in <tt>in</tt> and the current <code>Point</code> in pixels in <tt>out</tt>.
	(Instead of magstep controls, we'll use the general scale to any percentage behavior, when it's written.)

	<hr>To do
	<ul>
	<li>coalese text clipboard extraction if from same word just different nodes
	<li>Group letters into words, words into lines, lines into paragraphs or some larger unit
	<!--li>respond to a "TeXDVIscan" to scan all pages, building doc tree and generating all semantic events,
		so can do full-text search and scan for link destinations -- need table of arg sizes
		=> full-text indexers should be page-aware  -->
	<li>Could split out disassembly into own behavior but would have to duplicate sign1()/unsign4()/... and page start offset array and ...
	<li>Look around for TEXMF tree for fonts, when Java can createFont() on Type 1 not just TrueType as tree just has Type 1.
	<li>recognize sub/superscripts and put as spans or offsets into same word

	<li>kill font tracking in favor of Span.open/close (Node fontn => Span fontspan)
	</ul>

	<p>Used <a href='http://users.iclway.co.uk/l.emmett/'>Softy</a> to correct errors in TrueType versions of Computer Modern fonts.

	<p>Would like to separate italics/bold from font, but no universal naming convention, alas.

	@see tex.dvi.HyperTeX
	@see tex.dvi.PaperSize
	@see tex.dvi.ColorDVI
	@see tex.dvi.Src
	@see tex.dvi.EPS

	@version $Revision: 1.51 $ $Date: 2003/09/29 14:37:36 $
*/
public class DVI extends multivalent.std.adaptor.MediaAdaptorRandom {
  static final boolean DEBUG=false, DVITYPE=false;

  /**
	Reports TeX special.
	This media adaptor doesn't implement any specials, instead allowing other behaviors to do so.
	<p><tt>"TeXspecial"</tt>: <tt>arg=</tt> {@link java.lang.String} <var>special-text</var>, <tt>in=</tt> {@link multivalent.Node} <var>last node built in tree</var>, <tt>out=</tt> {@link java.awt.Point} <var>current geometric position</var>.
  */
  public static final String MSG_SPECIAL = "TeXspecial";

  /**
	Set state of verbose information.
	<p><tt>"dviSetVerbose"</tt>: <tt>arg=</tt> <var>boolean-setting<var> (<code>null</code> toggles).
  */
  public static final String MSG_SET_VERBOSE = "dviSetVerbose";

  /**
	Set state of disassembly display.
	<p><tt>"dviDisasm"</tt>: <tt>arg=</tt> <var>boolean-setting</var> (<code>null</code> toggles).
  */
  public static final String MSG_DISASM = "dviDisasm";

  /**
	Scan&mdash;read and parse, reporting specials&mdash; all pages of DVI.
	<p><tt>"dviScan"</tt>.
  */
  public static final String MSG_SCAN = "dviScan";

  /** Generic identifier at head of DVI (sub)tree. */
  public static final String GI_SUBROOT = "dvi";

  /*public*/ static final String ATTR_VERBOSE = "dviVerbose";
  /*public*/ static final String ATTR_DISASM = "dviDisasm";


  static final String COMMENT_BOILER = " TeX output ";
  static final int PPI = Toolkit.getDefaultToolkit().getScreenResolution();

  static final int ALLSPECIALCNT = 256, ALLCMDCNT=257/*last*/;
  static final int MAXFONT=256;     // large enough for TeX's use

  static final FontRenderContext FRC = new FontRenderContext(new AffineTransform(), true, true);
  static Map<String,SoftReference<Font>> TTF_ = new HashMap<String,SoftReference<Font>>(200);
  static String[] JREfonts_ = null;

  // only used when dumping, so could remove from production
  public static final String[] CMDS = new String[256];
  static {
	for (int i=0; i<32; i++) CMDS[i]="set_char_"+i;
	for (int i=32; i<=127; i++) CMDS[i]="set_char_"+i+"  '"+(char)i+"'";
	CMDS[128]="set1"; CMDS[129]="set2"; CMDS[130]="set3"; CMDS[131]="set4"; CMDS[132]="set_rule";
	CMDS[133]="put1"; CMDS[134]="put2"; CMDS[135]="put3"; CMDS[136]="put4"; CMDS[137]="put_rule";
	CMDS[138]="nop"; CMDS[139]="bop"; CMDS[140]="eop"; CMDS[141]="push"; CMDS[142]="pop";
	for (int i=0; i<=4; i++) { CMDS[147+i]="w"+i; CMDS[152+i]="x"+i; CMDS[161+i]="y"+i; CMDS[166+i]="z"+i; }
	for (int i=0,j=1; j<=4; i++,j++) {
		CMDS[143+i]="right"+j; CMDS[157+i]="down"+j;
		CMDS[235+i]="fnt"+j; CMDS[239+i]="special"/*"xxx"*/+i; CMDS[243+i]="fnt_def"+j;
	}
	for (int i=0; i<=63; i++) CMDS[171+i]="font_num_"+i;
	CMDS[247]="pre"; CMDS[248]="post"; CMDS[249]="post_post";
	for (int i=250; i<=255; i++) CMDS[i]="UNDEFINED";
  }

  public static final int[] CMDLEN = new int[256];  // byte[]?
  static {
	for (int i=0; i<256; i++) CMDLEN[i]=1;  // most commands one byte long: chars, push/pop, bop/eop, ...

	int[] l128 = {
		2,3,4,5, 9, 2,3,4,5,9, 1,45,1,1,1,
		2,3,4,5, 1,2,3,4,5, 1,2,3,4,5,
		2,3,4,5, 1,2,3,4,5, 1,2,3,4,5,
	};
	assert 128+l128.length == 171;
	for (int i=0,j=128,jmax=171; j<jmax; i++,j++) CMDLEN[j] = l128[i];
	CMDLEN[235]=2; CMDLEN[236]=3; CMDLEN[237]=4; CMDLEN[238]=5;

	// variable: specials, fnt_def
  }

  private static Font smallFont__ = new Font("serif", Font.PLAIN, 10);


  Node dviroot_=null, disasmroot_=null;
  String missing_=""/*, vinfo_=null*/;
  String[] fontnames_;
  int[] cmdcnt_ = null;
  int ppi_;

  // state shared among all pages -- should those taken from DVI available through accessors
  RandomAccess raf_=null;
  String comment_=null;
  private byte[] buf256_ = new byte[256];   // holds bytes of font name before converting to text + bytes of (<=256 byte) specials
  private String[] fontfam_=new String[MAXFONT];
  private float[] logicalsize_ = new float[MAXFONT];
  private long[] size_=new long[MAXFONT], design_=new long[MAXFONT];
  private Font[] fonts_ = new Font[MAXFONT];
  /** To convert from TeX coordinates to pixels, multiply by <code>fac_</code>. */
  private double fac_=1.0;
  private long pageoff_[];
  /** dvitype.web: "height-plus-depth of the tallest page"--not paper size--for possible positioning on paper, but in practice ignored. */
  long height_;
  /** dvitype.web: "width of the widest page" */
  long width_;
  long mag_;
  private int maxstack_=0;
  /** Record last modification date of .dvi and reload if changes. */
  long lastmod_ = -1;
  int pagecnt_ = -1;


  public void restore(ESISNode n, Map<String,Object> attr, Layer layer) {
	super.restore(n, attr, layer);
	Browser br = getBrowser();

	Toolkit tk = br!=null? br.getToolkit(): Toolkit.getDefaultToolkit();
	ppi_ = tk.getScreenResolution();    // essential!
  }

  /** Also add self as observer, to show verbose information. */
  public void buildBefore(Document doc) {
	super.buildBefore(doc);
	dviroot_.addObserver(this);     // for verbose paintAfter
  }


  /** Switch for verbose information. */
  public boolean semanticEventBefore(SemanticEvent se, String msg) {
	if (super.semanticEventBefore(se, msg)) return true;
	else if (VMenu.MSG_CREATE_VIEW==msg) {
		INode menu = (INode)se.getOut();
		VCheckbox ui = (VCheckbox)createUI("checkbox", "Verbose DVI info", "event "+MSG_SET_VERBOSE, menu, VMenu.CATEGORY_MEDIUM, false);
		ui.setState(getRoot().getAttr(ATTR_VERBOSE)!=null);

		ui = (VCheckbox)createUI("checkbox", "Disassemble DVI codes", "event "+MSG_DISASM, menu, VMenu.CATEGORY_MEDIUM, false);
		ui.setState(getRoot().getAttr(ATTR_DISASM)!=null);
	}
	return false;
  }

  /** Switch for verbose information and disassembly. */
  public boolean semanticEventAfter(SemanticEvent se, String msg) {
	Object arg = se.getArg();
	if (MSG_SET_VERBOSE==msg) {
		// set and redraw
		INode root = getRoot();
		root.putAttr(ATTR_VERBOSE, Booleans.parseBoolean(arg, !Booleans.parseBoolean(root.getAttr(ATTR_VERBOSE), false))? "true": "false");
//  /*arg is true || */(arg==null && root.getAttr(ATTR_VERBOSE)==null)? ATTR_VERBOSE: null);
		getBrowser().repaint();

	} else if (MSG_DISASM==msg) {
		// toggle and redraw
		INode root = getRoot();
		boolean on = Booleans.parseBoolean(arg, Booleans.parseBoolean(root.getAttr(ATTR_DISASM), false));
		root.putAttr(ATTR_DISASM, on? ATTR_DISASM: null);

		Document doc = getDocument();
		if (on) {
			if (disasmroot_ == null) try {
				disasmroot_ = (INode)disasm(null);
				disasmroot_.bbox.setLocation(0,0);
			} catch (Exception ignore) {}
			doc.appendChild(disasmroot_);   // maybe show in a note.  Still pretty elegant.

		} else {
			if (disasmroot_!=null/*always?*/) doc.removeChild(disasmroot_);
		}

		getBrowser().repaint();

	} else if (MSG_SCAN==msg) scan();

	return super.semanticEventAfter(se, msg);
  }


  public boolean paintAfter(Context cx, Node node) {
	Graphics2D g = cx.g;

	int h = (int)smallFont__.getMaxCharBounds(FRC).getHeight();
	if (missing_.length()>0) {
		g.setColor(Color.RED);
		g.setFont(smallFont__);
		int x=20 + PPI, y = PPI;  // or perhaps top left of current scroll position
		g.drawString("MISSING FONTS -- install Type 1 or TrueType of following from www.ctan.org into $JRE/lib/fonts", x,y+h);
		g.drawString(missing_, x, y + h*2);
	}

	if (getRoot().getAttr(ATTR_VERBOSE)!=null) {
		scan();

		g.setColor(Color.BLACK);
		g.setFont(smallFont__);
		int x=10/*getDocument().bbox.width - 100*/, y=h*3;
/*		for (int sep=0,lastsep=0, y=h*2; (sep=vinfo_.indexOf('|', sep+1))!=-1; lastsep=sep+1, y+=h) {
			g.drawString(vinfo_.substring(lastsep, sep), x, y);
		}*/
		if (comment_!=null) { g.drawString((comment_.startsWith(COMMENT_BOILER)? comment_.substring(COMMENT_BOILER.length()): comment_), x,y-3); y+=h; }
		g.drawString(cmdcnt_[ALLCMDCNT]+" commands", x,y); y+=h;
		g.drawString(cmdcnt_[ALLSPECIALCNT]+" specials", x,y); y+=h;
		y+=h;

		//g.drawString("page "+width_+"x"+height_, x,y); y+=h;
		g.drawString("mag "+mag_, x,y); y+=h;
		g.drawString("max stack = "+maxstack_, x,y); y+=h;
		y+=h;   // blank line

		for (int i=0,imax=fontnames_.length; i<imax; i++, y+=h) g.drawString(fontnames_[i], x,y);
	}

	return super.paintAfter(cx, node);
  }



  int sign1() throws IOException { int b=raf_.read(); return (b<0x80? b: 0xffffff00 | b); }
  int sign2() throws IOException { int b=raf_.read(); return (b<0x80? 0: 0xffff0000) | (b<<8) | raf_.read(); }  // if ((b&0x80000000)!=0) b=(~b)+1 ?
  int sign3() throws IOException { int b=raf_.read(); return (b<0x80? 0: 0xff000000) | (b<<16) | (raf_.read()<<8) | raf_.read(); }
  int sign4() throws IOException { return (raf_.read()<<24) | (raf_.read()<<16) | (raf_.read()<<8) | raf_.read(); }

  int unsign1() throws IOException { return raf_.read(); }
  int unsign2() throws IOException { return (raf_.read()<<8) | raf_.read(); }
  int unsign3() throws IOException { return (raf_.read()<<16) | (raf_.read()<<8) | raf_.read(); }
  long unsign4() throws IOException { return ((raf_.read()&0xffffffffL)<<24) | (raf_.read()<<16) | (raf_.read()<<8) | raf_.read(); }



  /** Centralize and reload if changed since last read.  Client should close when done. */
  RandomAccess getRAF() throws ParseException,IOException {
	File file = getFile();
//System.out.println("dvi file = "+file);
	if (!file.canRead()) throw new IOException();

	if (file.lastModified() > lastmod_) {  // if changed, reset
		lastmod_ = file.lastModified();
		//raf_ = new RandomAccessFile(cachefile, "r");
		readPreamble();
	}

	return new phelps.io.BufferedRandomAccessFile(file, "r");
  }


  void readPreamble() throws ParseException,IOException {
	int k,a;
	long l;

	// find postamble, build list of page offsets, jump to desired page
	raf_ = getRAF();    // not infinite loop because lastmod set
	List<String> fontlist = new ArrayList<String>(50);

	// pre
	int precmd = unsign1();	// should be 247/0xf7
	int id = unsign1(); // should be 2 -- maybe report uncertainty if !=2
	if (precmd!=247 || id!=2) throw new ParseException("Invalid DVI file: doesn't start with signature bytes 0xf7 0x02", raf_.getFilePointer()-2);

	long num = unsign4();   // always 25400000
	long den = unsign4();   // always 7227 * 2^16 = 473628672
	mag_ = unsign4();
	//fac = (numerator/254000.0)*(resolution/denominator) * (mag/1000); -- magic from dvitype.web line 2463
	fac_ = (num * ppi_ * mag_) / (den * 254000.0 * 1000.0);  // "fraction by which all dimensions in the \.{DVI} file could be multiplied in order to get lengths in units of $10^{-7}$ meters"
if (DVITYPE) System.out.println("num="+num+", den="+den+", mag="+mag_+", ppi="+ppi_+", fac="+fac_);
//System.out.println("fac = "+fac_+", mag="+mag_+", ppi="+ppi_);
	k = unsign1(); if (k>0) { raf_.read(buf256_, 0,k/*,encoding"en_us"?*/); comment_ = new String(buf256_,0,k); }
//System.out.println("\tid="+id+", num/den="+num+"/"+den+", mag="+mag+", fac="+fac_+", comment=|"+comment_+"|");
	//bop0 = raf_.getFilePointer();   	// should now be at first bop
//System.out.println("bop for first page = "+raf_.getFilePointer());


	// post_post ==249/0xf9
	long postpost = raf_.length()-1;
//System.out.println("len = "+(postpost+1));
	raf_.seek(postpost);
	while (raf_.read()==223) raf_.seek(--postpost);	// four to seven 233 bytes to pad out file to multiple of 4 bytes
//System.out.println("postpost = "+postpost);
	postpost -= 5;
//System.out.println("postpost = "+postpost);
	raf_.seek(postpost);
	int postcmd = unsign1();  assert postcmd == 249: postcmd;
	long post = unsign4();	// pointer to start of post
	id = unsign1(); // ==2?
	if (id!=2) throw new ParseException("Invalid DVI file: postamble doesn't start with bytes 0xf9 0x02", raf_.getFilePointer()-2);
	// followed by four to seven 233 bytes to pad out file to multiple of 4 bytes


	// post
	raf_.seek(post);
//System.out.println("post = "+post);
	unsign1();	// check ==248/0xf8
	long bop = unsign4();	// pointer to final bop
//System.out.println("bop from pointer = "+bop);
	num = unsign4();	// duplicates of preamble
	den = unsign4();
	mag_ = unsign4();
	height_ = unsign4();
	width_ = unsign4();
	maxstack_ = unsign2();	// max stack depth -- some pages have > 1000 pushes, which entails malloc

	pagecnt_ = unsign2();    // subsequently find as attr or pageoff.length, not as instance var
	//doc.putAttr(Document.ATTR_PAGECOUNT, Integer.toString(pagecnt));
if (DVITYPE) System.out.println("\tnum/den="+num+"/"+den+", mag="+mag_+", WxH="+width_+"x"+height_+", pagecnt="+pagecnt_);


	int cmd;
	// read fonts names here (don't instantiate) so can make verbose report, as elsewhere defined just before first use, which may not be current page
	while ((cmd=unsign1())!=-1 && cmd!=249/*post_post*/) {
	  switch (cmd) {
		case 138: break;   // nop/0x8a -- can occur in postamble
		// fnt_def -- guaranteed to appear before first use of font
		case 243: // fnt_def1/0xf3
		case 244: // fnt_def2/0xf4
		case 245: // fnt_def3/0xf5
		case 246: // fnt_def4/0xf6
			// "Once font |k| is defined, it must not be defined again"" -- at particular design size
			l = (cmd==243? unsign1(): cmd==244? unsign2(): cmd==245? unsign3(): sign4());
			a = (int)l;
			/*long cksum =*/ unsign4();	// checksum of font in .tfm when file generated => ignored as don't use these
			size_[a]=unsign4();  	// fixed point scale factor to apply to font metrics, as modified by fac
			design_[a]=unsign4();	// use font at design size, modified by mag to get point size

			k=unsign1(); raf_.skipBytes(k);    // font dir -- ignore
			k=unsign1(); raf_.read(buf256_, 0,k);  // family name
			//assert k>0: "0-length font family name";
			String extname = new String(buf256_, 0,k/*,encoding "en_us"--probably default for local system best*/).toLowerCase();
			fontlist.add(extname); fontfam_[a]=extname;     // LATER: if scaled to different size that design size, report that in name

			break;
		default:
			assert false: cmd;
			//System.out.println("unanticipated command in postamble "+cmd);
	  }
	}

	// build table of page starts.  Touches bytes throughout file, but usually read page 1 so no extra work, and besides it's fast.
	pageoff_ = new long[pagecnt_];
//long bop0 = 0;
	for (int i=pagecnt_-1; i>=0; i--) {
		pageoff_[i] = bop;
//System.out.println("seeking to "+bop+", delta = "+(bop-bop0));  bop0=bop;
		raf_.seek(bop+1+40);    // skip over cmd and parameters
		bop=unsign4();	// pointer to previous bop
	}
	//bop==-1, "bop of first page != -1: "+bop);


	fontnames_ = fontlist.toArray(new String[fontlist.size()]); 
	Arrays.sort(fontnames_);

	raf_.close();
  }


  public Object parse(INode parent) throws Exception {
	Browser br = getBrowser();
	Document doc = parent.getDocument();

	//if (pageoff_==null) try { readPreamble(); } catch (IOException ioe) { return dviroot_ = new LeafAscii("Trouble reading DVI: "+ioe,null, parent); }

	disasmroot_ = null;
	doc.putAttr(ATTR_DISASM, null);   // turn off for each fresh page?

	try { raf_ = getRAF(); } catch (IOException ioe) { return dviroot_ = new LeafAscii(/*"Trouble reading DVI: "+*/ioe.toString(),null, parent); }

	if (doc.getAttr(Document.ATTR_PAGECOUNT)==null) {
		// for Multipage protocol
		doc.putAttr(Document.ATTR_PAGECOUNT, Integer.toString(pagecnt_));
	}
	if (doc.getAttr(Document.ATTR_PAGE)==null) return dviroot_ = new LeafAscii("Loading fonts..."/*"no PAGE attr for DVI"*/,null, parent);
//System.out.println("seeking to "+pageoff_[pagenow-1]+" for page "+pagenow);

	int pagenow = Math.max(1, Math.min(Integers.parseInt(doc.getAttr(Document.ATTR_PAGE, "1"), 1), pageoff_.length));

	raf_.seek(pageoff_[pagenow-1]);  // -1 because 0-based array


	StringBuffer wordsb = new StringBuffer(20);
	int h=0,v=0, w=0,x=0,y=0,z=0;	// signed
	double wwidth = 0.0;     // width of word under construction
	int[] posnStack = new int[maxstack_ * 6]; // could have struct
	int posni=0;
	int a,b, fontnum=-1;
	Font curfont=null;
	float cursize = 12f;
	//at.scale(ppi/72.0, ppi/72.0);  // points => pixels
//System.out.println("at scale x = "+at.getScaleX());

	String curfam=null;
	int curascent=-1, curheight=-1, curmaxad=-1, xadv=0;
	int[] fontcnt=new int[MAXFONT], spcnt=new int[MAXFONT];  // determine the most popular font, make the base font in order to reduce span count and make structure better
	int[] count = new int[10];

	FixedLeafAsciiKern lastn=null; Fixed lastl=null;
	Leaf fontn=null;
	int fontoff=0;	  // could generalize, if get enough of these
	Rectangle bbox=null, lastbbox = null;      // infer sub/sup

	//int pushpop=0;

	FixedIVBox root = new FixedIVBox(GI_SUBROOT,null, parent);
	FixedIVBox region = new FixedIVBox("region",null, root);    // for now only one region, but some day determine columns and so on
	FixedIHBox line = null;
	int curbaseline = Integer.MIN_VALUE;
	char ch;

	int cmd = unsign1();
	if (cmd!=139/*bop*/) return new LeafAscii("bad page start "+cmd+" != 139 @ "+(raf_.getFilePointer()-1),null, parent);
	for (int i=0; i<10; i++) count[i] = sign4();	// count0..count9 -- counts not used by other DVI commands, maybe by specials
	unsign4();	// pointer to previous bop
if (DEBUG) { System.out.print("bop: counts="); for (int i=0; i<10; i++) System.out.print(count[i]+","); }


	while ((cmd=unsign1())!=-1 && cmd!=140/*eop*/) {
	  if (DEBUG && cmd>=128) {
		System.out.print("h="+h+"/"+(h*fac_)+", v="+v+"/"+(v*fac_));
		System.out.print("   cmd="+cmd+"/"+CMDS[cmd]);
		//if (cmd>=143 && cmd<=156) wordsb.append(' ');
		//if (wordsb.length()>0 && cmd>=143/*157*/ && cmd<=170) { System.out.println(/*"("+h+","+v+")	"+*/wordsb);/*ord.setLength(0);*/}
		//if (wordsb.length()>0) System.out.println("  "+wordsb);
		System.out.println();
	  }

	  //if (false && cmd>=143 && cmd<=170 && wordsb.length()>0 && cmd==0) {

	  // close current word when needed
	  if (cmd>=132 && wordsb.length()>0) {
		String word = Strings.valueOf(wordsb);
//System.out.print(word+" ");
		FixedLeafAsciiKern n = new FixedLeafAsciiKern(word,null, null, null);

		// bbox: (x,y) given by (h,v), compute (w,h) by measuring text (each media adaptor has some variation!)
//if (fm==null) { System.out.println("null font metrics for word |"+wordsb+"| (len="+word.length()+")"); System.exit(1); } -- always change font before use
		//int wwidth=fm.stringWidth(word); // => fractional widths => accumulate as get width of characters
		//Rectangle2D r2 = curfont.getStringBounds(word, FRC);
		//double wwidth = Math.ceil(r2.getWidth());// * frcscale;
/*if (DVITYPE) {
System.out.println(fm.stringWidth(word)+" vs "+r2.getWidth());//+" vs "+(r2.getWidth()*frcscale));
for (int i=0,imax=word.length(); i<imax; i++) System.out.print("   "+word.charAt(i)+"="+(curfont.getStringBounds(word, i,i+1, frc).getWidth()/fac_)); System.out.println();
}*/
		bbox = n.getIbbox();
		bbox.setBounds((int)Math.round(h*fac_ - wwidth),(int)Math.round(v*fac_)-curascent, /*(int)Math.round(*/(int)Math.ceil(wwidth)/*+0.99)*/,curheight);
		//h += Math.round(wwidth/fac_);   // => done character-wise
//if (DVITYPE) System.out.println("h += "+(wwidth/fac_)+"/"+wwidth+"  =  "+h+"/"+(h*fac_));//(int)(wwidth/fac_)+" TeX points");
		//n.curbaseline = curascent;
		//n.bbox.setSize((int)Math.ceil(wwidth), curheight);
		n.bbox.setBounds(bbox); n.baseline = curascent; n.setValid(true);     // efficiency hack
		wordsb.setLength(0); wwidth=0.0;

		// look for subscripts/superscripts -- be careful of equations, with hard-to-determine baselines
//if (v!=baseline && lastn!=null && Math.abs(lastbbox.x+lastbbox.width - bbox.x) < 5) System.out.println("close on "+lastn+"/"+lastbbox+", "+n+"/"+bbox); /*Math.abs(v-baseline)<=5 &&*/
		int bl = bbox.y + curascent;
		SubSupSpan span = null;
		if (bl==curbaseline) {
//if (lastn!=null && Math.abs(lastbbox.x+lastbbox.width - bbox.x) <= 2) System.out.println("concat "+lastn.getName() + " + "+n.getName()+": "+(lastbbox.x+lastbbox.width - bbox.x));

		} else if (line!=null /*Math.abs(v-baseline)<=5 &&*/ && Math.abs(lastbbox.x+lastbbox.width - bbox.x) < curmaxad
			//&& ((bl-bbox.height < bbox.y)/*sup*/ || (bbox.y-bbox.height < bl)/*sub*/) ) {
			&& bbox.y < curbaseline && bl > curbaseline-curascent ) {    // some y overlap
			//&& (Math.abs(lastn.bbox.y - (n.bbox.y+n.bbox.height))<5 || Math.abs(lastn.bbox.y+lastn.bbox.height - n.bbox.y)<5)) //{
//System.out.println("*** sub/sup on |"+word+"|");
//if ("2".equals(word)) { System.out.println(word+", "+n.getIbbox()+", lastn="+lastn+"/"+lastbbox+", xdiff="+(lastbbox.x+lastbbox.width - bbox.x)+", sup="+(lastbbox.y-lastbbox.height < bbox.y)+", sub="+(bbox.y-bbox.height < lastbbox.y)); }
			int delta = curbaseline - bl;
			span = (SubSupSpan)Behavior.getInstance(delta>0? "sup": "sub", "multivalent.std.span.SubSupSpan", null, null/*scratchLayer*/);
			span.setDelta(delta); bbox.y = curbaseline - curascent;
			span.moveq(n,0, n,n.size());
			// curbaseline = bl; -- NO, maintain current baseline

/*		} else if (line!=null) {
			System.out.println("close on "+lastn+"/"+lastbbox+", "+n+"/"+bbox+" dx="+Math.abs(lastbbox.x+lastbbox.width - bbox.x));
			line = new FixedIHBox("line",null, region); baseline = v; // copied from below
*/
		} else { line = new FixedIHBox("line",null, region); curbaseline = bl; /*System.out.println("new line, baseline="+v);*/ }

		// concatenate or new word?
		// concat important for general structure, searching, full-text searching, cursor position, select+paste, ... (not so much anno attachment)
		if (line.size()>0 && /*Character.isLetterOrDigit(word.charAt(0)) &&*/ /*Math.abs--NO*/(xadv = bbox.x - (lastbbox.x+lastbbox.width)) <= 2 && xadv > -curmaxad  &&  lastn!=null) {
//System.out.println(lastn.getName() + " + "+n.getName()+": "+xadv+" => ");

			// strip new leaf and concatenate to lastn
			int oldlen = lastn.size();
			lastn.setName(lastn.getName() + n.getName());
			int wc = lastbbox.width+bbox.width + xadv, hc = Math.max(lastbbox.height, bbox.height)/*FIX: wrong if sub/sup*/;
			lastbbox.setSize(wc, hc);
			lastn.bbox.setSize(wc, hc);

			// concat kerns.  LATER: concat w/0 and backpatch kern at point of concat
			byte[] k = lastn.getKern(); if (k==null) k = new byte[oldlen];
			byte[] newk = new byte[k.length + n.size()];
			System.arraycopy(k,0, newk,0, k.length);    // rest 0s
			newk[k.length-1] += (byte)xadv;  // invariant: kern after character at that position
//System.out.println("kern["+k.length+"] = "+xadv);
			lastn.setKern(newk);

			// copy over sub/sup from new leaf, if any -- spans on old node still valid, no completed font spans on new node yet since haven't hit change of font
			if (span!=null) span.moveq(lastn,oldlen, lastn,lastn.size());
			//for (int i=0,imax=lastn.
//System.out.println(lastn.getIbbox()+" / "+lastn.bbox+", "+lastn.isValid());
			//lastn.setValid(true); -- still valid (Span.moveq doesn't affect validity)

			if (fontn==null) { fontn=lastn; fontoff=oldlen; }

			// keep same lastn, lastbbox

		} else {    // new word
			line.appendChild(n);
			lastl=lastn=n; lastbbox=bbox; if (fontn==null) fontn=n;
		}
	  }


	  if (cmd <= 131) {		// set_char_[0-127], set1/0x80, set2/0x81, set3/0x82, set4/0x83: typeset character and advance h by width of character
		ch = (char)(cmd<=127? cmd: cmd==128? unsign1(): cmd==129? unsign2(): cmd==130? unsign3(): unsign4());   // if three- or four-byte value is bigger than Unicode

		//boolean fglyph = curfont.canDisplay(ch);    // should be unneccesary
		//if (ch<32 && !fglyph && curfont.canDisplay((char)(ch+DOZEOFF))) { ch = (char)(ch+DOZEOFF); fglyph=true; }    // can Java's TrueType rasterizer display low characters?
		//if (ch<32) ch+=DOZEOFF; boolean fglyph=true;
		if (ch<32) ch += (ch<=9 || curfont.canDisplay((char)171)? 161: 163);    // how disgusting is this!  (outside of ASCII, doesn't match up with Unicode anyhow...)
//if (!curfont.canDisplay(ch)) System.out.println(fglyph+" / can't display "+ch+"/"+(int)ch);

		wordsb.append(ch);
		//cw = fm.charWidth(ch);
		Rectangle2D r = curfont.getStringBounds(Strings.valueOf(ch), FRC);
//System.out.print(ch+"/"+(int)ch+"="+cw+"/"+r.getWidth()+"    "); //System.out.flush();
		fontcnt[fontnum]++;
		wwidth += r.getWidth();
		h += (int)(r.getWidth() / fac_);    // could premultiply, but fast enough
//System.out.println("+"); System.out.flush();
		//} else System.err.println("no glyph for "+(int)ch+" in "+curfam);
//if (DVITYPE) System.out.println("setchar"+cmd+"'"+ch+"', h += "+(int)(fm.charWidth(ch)/fac_)+"/"+fm.charWidth(ch)+"  =  "+h+"/"+(int)(h*fac_));//(int)(wwidth/fac_)+" TeX points");

	  } else switch (cmd) {
		case 132:	// set_rule/0x84
		case 137:	// put_rule/0x89
			a=sign4(); b=sign4();
//System.out.println("rule+advance: w="+b+", h="+a+", parent="+line);
			if (a>0 && b>0) {	// rectangle--bottom-left at (h,v), height=a, width=b
				int rx=(int)Math.round(h*fac_), ry=(int)Math.round((v-a)*fac_) -1, rw=(int)Math.ceil(b*fac_), rh=(int)Math.ceil(a*fac_);
				INode p = region;   //root;
				if (lastn!=null) {
					Rectangle r = lastn.getIbbox();
					if (/*Math.abs(r.x + r.width -- no advance on math - rx) </*=* / r.width *2 &&*/ Math.abs(r.y + r.height/2 - ry) < r.height *2) p = line;
//else System.out.println("rule on same line? "+rx+","+ry+" near "+lastn.getName()+", "+r+"  "/*+(p==line? "yes": "no")*//*+", x "+(Math.abs(r.x + r.width - rx) <= r.width)*/+", y="+(Math.abs(r.y + r.height/2 - ry) < r.height));
				}
				DVIRule rulen = new DVIRule("rule",null, p);
				rulen.getIbbox().setBounds(rx, ry, rw,rh);
				rulen.bbox.setSize(rw, rh); rulen.setValid(true);   // efficiency hack
				//if (p==line) rulen.baseline = curaseline - ry;  // rh? -- whatever,
				rulen.baseline = rh;    // whatever, just keep current baseline; baseline not used same way as for flowed
				lastl = rulen;
//System.out.println("making rule = "+a+"x"+b);
			};
			if (cmd==132) h += b;   // regardless if box typeset (i.e., even if b<0)
			break;


		// put 0x85-0x88 -- same as set except don't advance h (accents?)
		case 133: // put1/0x85
		case 134: // put2/0x86
		case 135: // put3/0x87
		case 136: // put4/0x88
			ch = (char)(cmd==133? unsign1(): cmd==134? unsign2(): cmd==135? unsign3(): unsign4());

			FixedLeafAsciiKern n = new FixedLeafAsciiKern(Strings.valueOf(ch),null, null,  null);

			//int cw = fm.charWidth(ch);
			Rectangle2D r = curfont.getStringBounds(Strings.valueOf(ch), FRC);
			fontcnt[fontnum]++;
			bbox = n.getIbbox();
			bbox.setBounds((int)Math.round(h*fac_),(int)Math.round(v*fac_)-curascent, /*was: cw*/(int)Math.ceil(r.getWidth()),curheight);
			// h += (int)(wwidth/fac_); => explicitly not
			//n.baseline = curascent;
			//n.bbox.setSize(cw,curheight);
			n.bbox.setBounds(bbox); n.baseline = curascent; n.setValid(true);     // efficiency hack

//System.out.println("no h on |"+ch+"| / "+(int)ch+", bbox="+bbox);
			int bl = bbox.y + curascent;
			if (bl==curbaseline) {
			} else if (line!=null /*Math.abs(v-baseline)<=5 &&*/ && Math.abs(lastbbox.x+lastbbox.width - bbox.x) < curmaxad
				&& bbox.y < curbaseline && bl > curbaseline-curascent ) {    // some y overlap
//System.out.println("*** sub/sup on CH |"+ch+"|");
				int delta = curbaseline - bl;
				// just set baseline rather than superscript (and subscript too?)
				SubSupSpan span = (SubSupSpan)Behavior.getInstance(delta>0? "sup": "sub", "multivalent.std.span.SubSupSpan", null, null/*scratchLayer*/);
				span.setDelta(delta); bbox.y = curbaseline - curascent;
				span.moveq(n,0, n,n.size()/*always 1*/);
				// curbaseline = bl; -- NO, maintain current baseline

			} else { line = new FixedIHBox("line",null, region); curbaseline = bl; /*System.out.println("new line, baseline="+v);*/ }
			line.appendChild(n);

			lastl=lastn=n; lastbbox=bbox; if (fontn==null) fontn=n;
			break;


		//case 137:	// put_rule/0x89 -- combined with set_rule, above

		case 138: break;   // nop/0x8a

		//case 139:  // bop/0x8b -- handled before loop
			//for (int i=0; i<10; i++) count[i] = sign4();	// count0..count9 -- counts not used by other DVI commands, maybe by specials
			//unsign4();	// pointer to previous bop
			// maybe report error of bop before eop

		//case 140: // eop/0x8c -- output accumulated page image
			// handled in loop test

		case 141:	// push/0x8d
			//System.out.println("push");
			posnStack[posni]=h; posnStack[posni+1]=v; posnStack[posni+2]=w; posnStack[posni+3]=x; posnStack[posni+4]=y; posnStack[posni+5]=z;
			posni += 6;
			// do not change values (such as zeroing them)
			//pushpop++;  // pop==push, presumably
			break;
		case 142:	// pop/0x8e
			posni -= 6;
			h=posnStack[posni]; v=posnStack[posni+1]; w=posnStack[posni+2]; x=posnStack[posni+3]; y=posnStack[posni+4]; z=posnStack[posni+5];
			//System.out.println("pop");
			break;

		case 143: h += sign1(); break;	// right1/0x8f
		case 144: h += sign2(); break;	// right2/0x90
		case 145: h += sign3(); break;	// right3/0x91
		case 146: h += sign4(); break;	// right4/0x92

		case 147: h += w; break;	// w0/0x93
		case 148: w = sign1(); h += w; break;	// w1/0x94
		case 149: w = sign2(); h += w; break;	// w2/0x95
		case 150: w = sign3(); h += w; break;	// w3/0x96
		case 151: w = sign4(); h += w; break;	// w4/0x97

		case 152: h += x; break;	// x0/0x98
		case 153: x = sign1(); h += x; break;	// x1/0x99
		case 154: x = sign2(); h += x; break;	// x2/0x9a
		case 155: x = sign3(); h += x; break;	// x3/0x9b
		case 156: x = sign4(); h += x; break;	// x4/0x9c


		case 157: v += sign1(); break; // down1/0x9d
		case 158: v += sign2(); break; // down2/0x9e
		case 159: v += sign3(); break; // down3/0x9f
		case 160: v += sign4(); break; // down4/0xa0

		case 161: v += y; break;	// y0/0xa1
		case 162: y = sign1(); v += y; break;	// y1/0xa1
		case 163: y = sign2(); v += y; break;	// y2/0xa2
		case 164: y = sign3(); v += y; break;	// y3/0xa3
		case 165: y = sign4(); v += y; break;	// y4/0xa4

		case 166: v += z; break;	// z0/0xa5
		case 167: z = sign1(); v += z; break;	// z1/0xa6
		case 168: z = sign2(); v += z; break;	// z2/0xa7
		case 169: z = sign3(); v += z; break;	// z3/0xa8
		case 170: z = sign4(); v += z; break;	// z4/0xa9


		// fnt_num_{0-63} / 0xb0-0xea
		/*case170*/case 171: case 172: case 173: case 174: case 175: case 176: case 177: case 178: case 179:
		case 180: case 181: case 182: case 183: case 184: case 185: case 186: case 187: case 188: case 189:
		case 190: case 191: case 192: case 193: case 194: case 195: case 196: case 197: case 198: case 199:
		case 200: case 201: case 202: case 203: case 204: case 205: case 206: case 207: case 208: case 209:
		case 210: case 211: case 212: case 213: case 214: case 215: case 216: case 217: case 218: case 219:
		case 220: case 221: case 222: case 223: case 224: case 225: case 226: case 227: case 228: case 229:
		case 230: case 231: case 232: case 233: case 234:
		case 235: // fnt1/0xeb
		case 236: // fnt2/0xec -- we go boom if this happens as only allocated 256 fonts
		case 237: // fnt3/0xed -- boom
		case 238: // fnt4/0xee -- boom
			if (fontn!=null && curfont!=null) { // close previous font span
//System.out.println(curfont.getFamily()+"/"+curfont.getSize()+"  over  "+fontn.getName()+"/0 .. "+lastn.getName()+"/"+lastn.size());
				//new FontSpan(curfam, curfont.getSize()).moveq(fontn,0, lastn,lastn.size()); -- faster but just drawing single page so don't need
				FontSpan span = (FontSpan)Behavior.getInstance(curfam/*"DVIFontSpan"*/, "multivalent.std.span.FontSpan", null, null/*scratchLayer*/);
				span.family=curfam; span.size=cursize; //span.style = Font.PLAIN;
				span.moveq(fontn,fontoff, lastn,lastn.size());
				spcnt[fontnum]++;
			} //else System.out.println("first font change? "+fontn+", curfont="+curfont);
			fontn=null; fontoff=0;

			fontnum = (cmd<=234? cmd-171: cmd==235? unsign1(): cmd==236? unsign2(): cmd==237? unsign3(): (int)unsign4());
			if (cmd>=236) System.err.println("font number too big "+fontnum);
			curfam = fontfam_[fontnum];
			curfont = getFont(curfam, fontnum, br); cursize=logicalsize_[fontnum];
			Rectangle2D maxr = curfont.getMaxCharBounds(FRC);
			curascent = (int)-maxr.getY(); curheight = (int)maxr.getHeight(); curmaxad = (int)maxr.getWidth();
//if (DVITYPE) System.out.println("curfont: "+curfont.getFamily()+", "+curfont.getSize2D()+", ascent="+curascent);
			break;


		// xxx - "undefined in general" - used for specials
		case 239: // xxx1/0xef
		case 240: // xxx2/0xf0
		case 241: // xxx3/0xf1
		case 242: // xxx4/0xf2
			String special = readSpecial(cmd);
			// announce special to possible implementors -- don't implement any here in parser
//System.out.println("special |"+special+"| after "+lastl+" vs old "+lastn);
			if (special!=null && br!=null) br.event/*no q--change by time it's processed!*/(new SemanticEvent(br, MSG_SPECIAL, special, lastl/*lastn*/, new Point((int)Math.round(h*fac_), (int)Math.round(v*fac_))));
//if (/*DVITYPE &&*/ special!=null) System.out.println(special);
			break;


		// fnt_def -- guaranteed to appear before first use of font
		case 243: // fnt_def1/0xf3
		case 244: // fnt_def2/0xf4
		case 245: // fnt_def3/0xf5
		case 246: // fnt_def4/0xf6
			// done in postamble
			raf_.skipBytes( (cmd-242)+4+4+4);
			raf_.skipBytes( unsign1()+unsign1() );  // name
			break;

		// read out of loop -- shouldn't even see here
		case 247: // pre/0xf7
		case 248: // post/0xf8
		case 249: // post_post/0xf9
			break;

		//case 250: case 251: case 252: case 253: case 254: case 255: // undefined/0xfa-0xff
			// ignore
		//	break;

		default:
			assert false: cmd;
			//System.err.println("should NOT see this command in body of page: "+cmd);
	  }

if (DVITYPE) {
if (cmd>=143 && cmd<=156) System.out.println(CMDS[cmd]+": h = "+h+" / "+(h*fac_));
else if (cmd>=157 && cmd<=170) System.out.println(CMDS[cmd]+": v = "+v+" / "+(v*fac_));
}
	}
//System.out.println("done cmds");
//System.exit(0);

	// pending word at EOP -- never necessary on ones I've seen, but be safe
if (wordsb.length()>0) System.out.println("unforced word: |"+wordsb.toString());    // always forced before 140/eop, apparently

	// pending span at EOP
	if (fontn!=null && curfont!=null) {
		//new FontSpan(curfam, curfont.getSize()).moveq(fontn,0, lastn,lastn.size());
		FontSpan span = (FontSpan)Behavior.getInstance(curfam/*"DVIFontSpan"*/, "multivalent.std.span.FontSpan", null, null/*scrathLayer*/);
		span.family=curfam; span.size=cursize; //span.style = Font.PLAIN;
		span.moveq(fontn,fontoff, lastn,lastn.size());
		spcnt[fontnum]++;
	}
//System.out.println("push count = "+pushpop);

	raf_.close();   // don't hold open file descriptor so we can use as an interactive previewer as document continually reprocessed in other window (reloading handled in separate, general behavior)

	//for (int i=0; i<256; i++) if (fontcnt[i]>0) System.out.println(fontfam_[i]+" "+fontcnt[i]+" / "+spcnt[i]);
	// if (fontcnt[i]>0) assert spcnt[i]>0;
	//System.out.println("=========");
	clean(root, fontcnt, spcnt);

	dviroot_ = root;
	return root;
  }


  Font getFont(String familypt, int a, Browser br) throws IOException {
	Font font = fonts_[a];
	if (font==null) {    // load fonts on demand
///*if (DEBUG)*/if (curfont!=null) System.out.println("\tfont to "+(cmd-171)+" = "+curfont.getFamily()+"/"+curfont.getSize()); else System.out.println("switching to a null font!	"+(cmd-171));
//if (DEBUG) System.out.println("\tnum="+l+", name=|"+extname+"|, s="+size+", d="+design);
		String family = null, fam=familypt;
		long pts = 0;
		for (int i=familypt.length()-1, base=1; i>0; i--, base*=10) {
			if (Character.isDigit(familypt.charAt(i))) pts += (familypt.charAt(i)-'0')*base;
			else { family = familypt.substring(0,i+1); break; }
		}
		float pointsize = ((pts!=0? pts: 12) * size_[a] * mag_)/(design_[a] * 1000f);
		logicalsize_[a] = pointsize;
//if (DVITYPE) System.out.println("#"+a+" "+curfam+", mag_="+mag_+", s/d="+(size_[a]/(double)design_[a])+", pointsize="+opintsize);   //size="+size_[a]+" / design_="+design_[a]);

//System.out.println("checking "+fontref);
		// 0. cached from previous run
		SoftReference<Font> ref = null;
		if ((ref=TTF_.get(familypt))!=null && ref.get()!=null) {
			font = ref.get();
//System.out.println("\tcache "+familypt);
		}

		// 1. JRE/lib/fonts -- first so that user fonts will override
		if (font==null) {
			if (JREfonts_==null) {
				String jhome = System.getProperty("java.home");
				if (jhome!=null) {
					File fontdir = new File(System.getProperty("java.home")+"/lib/fonts");
					FilenameFilter filter = new FilenameFilter() {
						public boolean accept(File dir, String name) {
							File f = new File(dir, name);
							return f.canRead() && f.isFile() && name.indexOf('.')!=-1;
						}
					};
					JREfonts_ = fontdir.list(filter);
					for (int i=0,imax=JREfonts_.length; i<imax; i++) JREfonts_[i] = JREfonts_[i].toLowerCase().substring(0, JREfonts_[i].lastIndexOf('.'));     // canonicalize: lc + shop suffix
				}
				if (JREfonts_==null) JREfonts_ = new String[0];
			}

			for (int i=0,imax=JREfonts_.length; i<imax; i++) {  // exact match
//System.out.println("exact on "+JREfonts_[i]);
				if (JREfonts_[i].equals(familypt)) { font = new Font(familypt, Font.PLAIN, 12); break; }
			}
		}

		// 2. TEXMF tree
		if (font==null) {
			// search tree...
			//	for Type 1, getFontName()/getFamily/getPSName = CMMI10/Computer Modern/PS=CMMI10
			//  check for right family as well as right family+point size
			if (false/*found in tree*/) {
				try {
					InputStream urlin = new FileInputStream("XXXX");    // Font.createFont buffers and copies to File
					//font = Font.createFont(Font.TRUETYPE_FONT, urlin); -- LATER, when Java implements this
					urlin.close();
				//} catch (FontFormatException shouldnthappen) { System.err.println(shouldnthappen); }
				} catch (FileNotFoundException shouldnthappen) { System.err.println(shouldnthappen); }
			}
		}

		// 3. TrueType in JAR
		if (font==null) {//&& false) { // false tries loading from $JRE/lib/fonts
			InputStream urlin = getClass().getResourceAsStream("font/"+familypt.toLowerCase()+".ttf");
//System.out.println("in JAR? "+urlin);
			//if (urlin==null) urlin = getClass().getResourceAsStream("fonts/"+family.toLowerCase()+".ttf");  // how to try at different point size?
			if (urlin!=null) {
				try {
//System.out.println(familypt);
					font = Font.createFont(Font.TRUETYPE_FONT, urlin);
//System.out.println(familypt+" -- created from JAR");
				} catch (FontFormatException shouldnthappen) { System.err.println(shouldnthappen);
				} finally { urlin.close(); }
			}
		}


		// 4. JRE/lib/fonts matches except for pointsize
		if (font==null) for (int i=0,imax=JREfonts_.length; i<imax; i++) {  //
			if (JREfonts_[i].startsWith(family)) { font = new Font(family, Font.PLAIN, 12); fam=family; System.out.println("sub: "+JREfonts_[i]+" => "+family); break; }
		}


		// FAIL -- report missing
		if (font==null) missing_ += familypt + (Math.abs(pts-pointsize) > 0.01? "@"+pointsize: "") + " ";


		// scale
		Map<TextAttribute,Object> map = new HashMap<TextAttribute,Object>(5);
		map.put(TextAttribute.FAMILY, fam);  // will take from system if not in DVI.jar, so can use Type 1 fonts
		map.put(TextAttribute.SIZE, new Float(pointsize * ppi_ / 72f));
//if (DVITYPE) System.out.println("request "+pointsize+" points (-> "+(pointsize*ppi_/72f)+")");
		map.put(TextAttribute.POSTURE, TextAttribute.POSTURE_REGULAR); //=> lame TeX
		map.put(TextAttribute.WEIGHT, TextAttribute.WEIGHT_REGULAR); //=> lame TeX
//System.out.println("derive font "+familypt);
		font = fonts_[a] = new Font(map);   // rounds point size to int
//System.out.println("derived "+fonts_[a]);

		//String mapto = fonts_[a].getFamily();
		//if (extname.equals(mapto)) fontlist.add(extname); else errsb.append(extname)/*.append(" => ").append(mapto).append('|')*/.append("   ");
//System.out.println(familypt+" @ "+pointsize+"  =>  "+fonts_[a].getFontName()+"/"+fonts_[a].getFamily()+"/PS="+fonts_[a].getPSName());

		TTF_.put(familypt, new SoftReference<Font>(font));    // regardless of closeness of match
		//TTF_.put(familypt, new SoftReference(font));     // maybe cache scaled version instead, but then concat scale size with key
		//if (!familypt.equals(font.getFontName().toLowerCase())) missing_ += familypt + (pts-pointsize>0.01? "@"+pointsize: "") + " ";
//System.out.println("	=>	"+fonts_[(int)l].getFamily()+"/"+fonts_[(int)l].getStyle()+"/"+(int)pointsize);
	}
//System.out.println(fontfam_[a]+" / "+font.getPSName()+" @ "+fonts_[a].getSize2D());
	return font;
  }


  /**
	Parsing tracks font usage.
	This method sets the font used by the most number of characters as the page default and deletes its individual spans.
  */
  void clean(INode root, int[] charcnt, int[] spancnt) {
	// compute max
	int maxi=-1, max=0;
	// assert charcnt.length == MAXFONT
	for (int i=0,imax=charcnt.length; i<imax; i++) if (charcnt[i] > max) { max=charcnt[i]; maxi=i; }    // base font is greatest number of characters, regardless of number of spans
//System.out.println("max @ "+maxi+" = "+max);
	if (maxi!=-1) { // could have empty page, I guess
		// set in stylesheet (genre stylesheet already set -- whew)
		StyleSheet ss = root.getDocument().getStyleSheet();
		CLGeneral cl = (CLGeneral)ss.get(GI_SUBROOT);
		if (cl==null) { cl = new CLGeneral(); ss.put(GI_SUBROOT, cl); }

		String family = fontfam_[maxi];
		float size = logicalsize_[maxi];
		cl.setFamily(family); cl.setSize(size);
//System.out.println("set base to "+family+" @ "+size);

		// wipe corresponding span from tree
		// iterates over all spans with instanceof, but since just built tree and don't make many spans (just a minimal number of font spans), not too bad
		int spcnt=0, killcnt=0;
		for (Leaf l=root.getFirstLeaf(), endl=root.getLastLeaf().getNextLeaf(); l!=endl; l=l.getNextLeaf()) {
			for (int i=0; i < l.sizeSticky()/*size changed by loop*/; i++) {
				Mark m = l.getSticky(i);
				Object o = m.getOwner();
				if (o instanceof FontSpan) { // all for now
					FontSpan span = (FontSpan)o;
					if (m==span.getStart() && family.equals(span.family) && Math.abs(size - span.size) < 0.01) {
						span.moveq(null);   // more efficient to do before destroy
						span.destroy();
						killcnt++;
					}
				}
				spcnt++;
			}
		}
		//System.out.println("examined "+spcnt+" spans, killed "+killcnt+" vs "+spancnt[maxi]);
		//assert killcnt == spancnt[maxi];
	}
  }


  /**
	Read special String at current position in file.
	Used by parse(), scan() (doesn't skip over; sends semantic event), disasm().
  */
  String readSpecial(int cmd) throws IOException {
	String special = null;
	long l = (cmd==239? unsign1(): cmd==240? unsign2(): cmd==241? unsign3(): unsign4());

	if (l>0) {  // always?
		byte[] xbuf = (l<256? buf256_: new byte[(int)l]);
		raf_.read(xbuf, 0,(int)l);
		special = new String(xbuf, 0,(int)l/*,encoding"en_us"?*/);
//System.out.println(special.substring(0, Math.min(special.length(),100)));
	}
	return special;
  }


  /**
	Scan through entire .dvi file, collecting statistics and signaling specials.
	Takes long enough that want to scan on demand (100s of pages, HyperTeX refs everything).
	Main client is HyperTeX (finds destination anchors), but also count total specials, and could be others.
  */
  void scan() {
	if (cmdcnt_!=null) return;
	cmdcnt_ = new int[ALLCMDCNT+1];   //  last one for all specials combined
	int total = 0;

	Browser br = getBrowser();
	int pagenum = 0; String spagenum = null;
	try {
		raf_ = getRAF();
		for (int cmd; (cmd=raf_.read())!=-1; ) {
			total++; cmdcnt_[cmd]++;
//System.out.print(cmd+" ");

			if (cmd==139) spagenum = Integer.toString(++pagenum);
//System.out.println("page="+pagenum+" ");}

			else if (cmd >= 239 && cmd <= 242) {
				// semantic event with String, page, byte offset?
				String special = readSpecial(cmd);
				if (special!=null) br.event/*no q--on demand*/(new SemanticEvent(br, MSG_SPECIAL, special, spagenum, null/*distinguishes from parse*/));
				cmdcnt_[ALLSPECIALCNT]++;

			} else if (cmd >=243 && cmd <=246) {
				raf_.skipBytes( (cmd-242)+4+4+4);
				raf_.skipBytes( unsign1()+unsign1() );

			} else raf_.skipBytes(CMDLEN[cmd]-1);   // -1 => already ate command num itself
		}
		raf_.close();
	} catch (Exception ioe) {
		// ignore for now
	}

	cmdcnt_[ALLCMDCNT] = total;
  }


  /**
	Disassembly of DVI codes as a document tree.
	Maybe make pagewise command counts too.
	Could split this out into own behavior, but want to use scan1()/unsign4()/.... and pageoff_[]
  */
  Object disasm(INode parent) throws ParseException,IOException {
	Document doc = getDocument();
	int pagenow = Math.max(1, Math.min(Integers.parseInt(doc.getAttr(Document.ATTR_PAGE, "1"), 1), pageoff_.length));

	raf_ = getRAF();
	raf_.seek(pageoff_[pagenow-1]);  // -1 because 0-based array

	IVBox root = new IVBox("disasm", null, parent);

	int a,b,k; long l;
	StringBuffer sb=new StringBuffer(50), wordsb=new StringBuffer(20);
	for (int cmd; (cmd=unsign1())!=-1; ) {
		sb.setLength(0);

		if (cmd<=127) { // cluster together ordinary characters
			if (wordsb.length()==0) wordsb.append("set_char_  ");
			wordsb.append("  ").append(cmd);
			if (cmd>=32) wordsb.append(" '").append((char)cmd).append("'");

		} else {
			if (wordsb.length()>0) { new LeafAscii(wordsb.substring(0),null, root); wordsb.setLength(0); }   // flushed (guaranteed at end by eop)
			sb.append(CMDS[cmd]);

			switch (cmd) {

			// unsign1()
			case 128: case 133:
				sb.append("  ").append(unsign1());
				break;
			// unsign2()
			case 129: case 134:
				sb.append("  ").append(unsign2());
				break;
			// unsign3()
			case 130: case 135:
				sb.append("  ").append(unsign3());
				break;
			// unsign4()
			case 131: case 136:
				sb.append("  ").append(unsign4());
				break;

			// sign1
			case 143: case 148: case 153:
			case 157: case 162: case 167:
				a=sign1();
				sb.append("  ").append(a).append(" / ").append(a*fac_);
				break;
			// sign2
			case 144: case 149: case 154:
			case 158: case 163: case 168:
				a=sign2();
				sb.append("  ").append(a).append(" / ").append(a*fac_);
				break;
			// sign3
			case 145: case 150: case 155:
			case 159: case 164: case 169:
				a=sign3();
				sb.append("  ").append(a).append(" / ").append(a*fac_);
				break;
			// sign4
			case 146: case 151: case 156:
			case 160: case 165: case 170:
				a=sign4();
				sb.append("  ").append(a).append(" / ").append(a*fac_);
				break;

			case 132: case 137:
				a=sign4(); b=sign4();
				sb.append(", x = ").append(a).append('/').append(a*fac_).append(", y = ").append(b).append('/').append(b*fac_);
				break;

			case 139:   // bop
				sb.append(", counts:");
				for (int i=0; i<10; i++) sb.append("   ").append(sign4());
				unsign4();  // pointer -- not shown
				sb.append("  @  0x").append(Integer.toHexString((int)raf_.getFilePointer()-10*4-4));
				break;

			/*case170*/case 171: case 172: case 173: case 174: case 175: case 176: case 177: case 178: case 179:
			case 180: case 181: case 182: case 183: case 184: case 185: case 186: case 187: case 188: case 189:
			case 190: case 191: case 192: case 193: case 194: case 195: case 196: case 197: case 198: case 199:
			case 200: case 201: case 202: case 203: case 204: case 205: case 206: case 207: case 208: case 209:
			case 210: case 211: case 212: case 213: case 214: case 215: case 216: case 217: case 218: case 219:
			case 220: case 221: case 222: case 223: case 224: case 225: case 226: case 227: case 228: case 229:
			case 230: case 231: case 232: case 233: case 234:
			case 235: // fnt1/0xeb
			case 236: // fnt2/0xec -- we go boom if this happens as only allocated 256 fonts
			case 237: // fnt3/0xed -- boom
			case 238: // fnt4/0xee -- boom
				a = (cmd<=234? cmd-171: cmd==235? unsign1(): cmd==236? unsign2(): cmd==237? unsign3(): (int)unsign4());
				sb/*.append(a)--already*/.append("  ").append(fontfam_[a]);
				break;

			case 239: case 240: case 241: case 242: // special
				String special = readSpecial(cmd);
				sb.append(", |").append(special).append("|");
				//cmdcnt_[ALLSPECIALCNT]++;
				break;

			case 243: case 244: case 245: case 246: // fnt_def
				l = (cmd==243? unsign1(): cmd==244? unsign2(): cmd==245? unsign3(): sign4());
				unsign4();  // checksum -- not shown
				sb.append("   sz=").append(unsign4()).append(", dsn="+unsign4());
				k=unsign1(); if (k>0) { raf_.read(buf256_, 0, k); sb.append(", dir=").append(new String(buf256_,0,k)); }
				k=unsign1(); if (k>0) { raf_.read(buf256_, 0, k); sb.append(", ").append(new String(buf256_,0,k)); }
				break;

			case 250: case 251: case 252: case 253: case 254: case 255: // undefined/0xfa-0xff
				// shouldn't get these -- show in red?
				break;

			default:
				raf_.skipBytes(CMDLEN[cmd]-1);   // -1 => already ate command num itself
			}

			// everybody gets a line
			new LeafAscii(sb.substring(0),null, root);
		}

		if (cmd==140) break;    // not in for() because want to process eop
	}

	raf_.close();

	return root;
  }
}
