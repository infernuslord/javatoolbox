package tool.pdf;

import java.io.*;
import java.util.Iterator;
import java.util.Observer;
import java.util.Observable;

import multivalent.std.adaptor.pdf.*;
import multivalent.std.adaptor.pdf.SecurityHandler;
import multivalent.ParseException;
import static multivalent.std.adaptor.pdf.COS.*;

import phelps.io.FileList;



/**
	Decrypt.

	Copyright (c) 2002 - 2003  Thomas A. Phelps
	@version $Revision: 1.11 $ $Date: 2003/08/29 04:37:32 $
*/
public class Decrypt implements Observer {
  static final boolean DEBUG = true;

  public static final String VERSION = "1.0 of $Date: 2003/08/29 04:37:32 $";
  public static final String USAGE = "java tool.pdf.Decrypt [-password <owner-password>] [-inplace] <PDF-file...>";
//  [-out <file>]

  private String password_;
  private boolean finplace_;
  private boolean fverbose_, fquiet_;

  private PDFReader pdfr_; private PDFWriter pdfw_;

  public Decrypt() {
	defaults();
  }

  public void defaults() {
	password_ = null;
	finplace_ = false;
  }

  public void setPassword(String password) { password_=password; }



  public void decrypt(File file) throws IOException,ParseException {
	String path = file.getPath();
	String pathout = finplace_? path: (path.toLowerCase().endsWith(".pdf")? path.substring(0, path.length()-4): path) + "-d.pdf";
	decrypt(file, new File(pathout));
  }

  /**
	Decrypt encrypted file.
	Not MT-safe.
  */
  public void decrypt(File in, File out) throws IOException,ParseException {
//Runtime rt = Runtime.getRuntime();
//System.out.println("in = "+rt.freeMemory()+"/"+rt.totalMemory());
	PDFReader pdfr = new PDFReader(in);
	//pdfr.setExact(true); => kills Compact

	// verify encryption
	if (pdfr.getTrailer().get("Encrypt")==null) { System.out.println("PDF not encrypted -- no action taken."); pdfr.close(); return; }

	//pdfr.setPassword(password_); //setPasswords(pdfr);	// owner password required
	SecurityHandler sh = pdfr.getEncrypt().getSecurityHandler();
	sh.authOwner(password_);
	if (!sh.isAuthorized()) throw new ParseException("owner password required");


	pdfr.fault();

	// defang
	PDFWriter pdfw = new PDFWriter(out, pdfr); pdfw.setExact(true);
	pdfw.getTrailer().remove("Encrypt");
	//pdfw.refcnt(); => retain encryption dictionary in case want to look at later and it's small

	pdfr_ = pdfr; pdfw_ = pdfw;
	pdfw.writePDF(this);
	pdfr_ = null; pdfw_ = null;

	pdfw.close();
//System.out.println("out = "+rt.freeMemory()+"/"+rt.totalMemory());
  }

  /** Strips /Crypt filters from streams, unless <code>/Identity</code>. */
  public void update(Observable obs, Object o) {
	if (CLASS_DICTIONARY == o.getClass() && ((Dict)o).get(STREAM_DATA) != null) try {
		Dict dict = (Dict)o;
		if (/*compareVersion(1,5)<0) ||*/ pdfr_.getEncrypt().getCryptFilter(dict) != CryptFilter.IDENTITY) pdfw_.removeFilter(dict, "Crypt");
	} catch (IOException ioe) { /* leave as is? */ }
  }


  private int commandLine(String[] argv) {
	int argi=0, argc = argv.length;
	for ( ; argi < argc; argi++) {
		String arg = argv[argi]; if (!arg.startsWith("-")) break;
		if (arg.equals("-password")) setPassword(argv[++argi]);
		else if (arg.equals("-inplace")) { finplace_=true; /*pathout=null;*/ }
		//else if (arg.startsWith("-out"/*file*/)) { pathout = argv[++argi]; finplace_=false; }

		else if (arg.startsWith("-q"/*uiet*/)) fquiet_ = true;
		else if (arg.startsWith("-h"/*"elp"*/)) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	if (argi == argc) { System.err.println(USAGE); System.exit(0); }

	return argi;
  }


  public static void main(String[] argv) {
	Decrypt decrypt = new Decrypt();
    int argi = decrypt.commandLine(argv);

	for (Iterator<File> i = new FileList(argv, argi, FILTER).iterator(); i.hasNext(); ) {
		File file = i.next();
		try {
			//if (!fquiet_) System.out.println(file);
			decrypt.decrypt(file);
		} catch (Exception ioe) {
			System.err.println(file+": "+ioe);
			if (DEBUG) ioe.printStackTrace();
		}
	}
  }
}
