/*
 * @(#)JSwitchTable.java
 *
 * JReversePro - Java Decompiler / Disassembler.
 * Copyright (C) 2000 2001 Karthik Kumar.
 * EMail: akkumar@users.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it , under the terms of the GNU General Public License as published
 * by the Free Software Foundation; either version 2 of the License,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program.If not, write to
 *  The Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330,
 *  Boston, MA 02111-1307, USA.
 */
package jreversepro.revengine;

import jreversepro.common.Helper;
import jreversepro.common.KeyWords;
import jreversepro.common.JJvmSet;
import jreversepro.common.JJvmOpcodes;

import jreversepro.reflect.JInstruction;

import jreversepro.runtime.Operand;

import java.io.DataInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;

import java.util.Vector;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.List;
import java.util.HashMap;

import java.util.Enumeration;

/** JSwitchTable represents the 'switch' statement as entry pairs as
 * follows.
 * Pair = { CaseValues, Targets }.
 * @author Karthik Kumar
 * @version 1.3
 **/
public class JSwitchTable implements KeyWords,
                                JJvmOpcodes {
    int mInsIndex;
    List mCases;
    int defaultByte;
    String mVarName;
    String dataType;


    public JSwitchTable( JInstruction ins )
                    throws RevEngineException,
                        IOException {
        mInsIndex = ins.index;
        mCases  = new Vector();

        if( ins.opcode == OPCODE_TABLESWITCH ) {
            createTableSwitch(ins.args, ins.index);
        } else if( ins.opcode == OPCODE_LOOKUPSWITCH ) {
            createLookupSwitch(ins.args, ins.index);
        } else {
            throw new RevEngineException("Not a switch statement");
        }
        dataType = null;
    }
    public JSwitchTable ( JInstruction Ins, Operand op1 )
                        throws RevEngineException,
                            IOException {
        this ( Ins );
        this.dataType = op1.getDatatype();
        this.mVarName = op1.getValue();
    }

    public final int getDefaultByte() {
        return defaultByte;
    }

    private void createTableSwitch( byte [] Entries, int Offset )
            throws IOException {
        DataInputStream dis = new DataInputStream(
                    new ByteArrayInputStream(Entries) );
        defaultByte = dis.readInt() + Offset;
        int LowVal =  dis.readInt();
        int HighVal = dis.readInt();

        Map mapCases = new HashMap();
        for(int i = LowVal; i <= HighVal ; i++ ) {
            int curTarget = dis.readInt() + Offset;
            String value =  Helper.getValue( String.valueOf(i),
                                                dataType);
            Object obj = mapCases.get( new Integer(curTarget) );
            if ( obj == null ) {
                mapCases.put(
                        new Integer(curTarget),
                        new JCaseEntry(value, curTarget) );
            } else {
                JCaseEntry ent = ( JCaseEntry ) obj;
                ent.addValue( value );
            }
        }
        mCases = new Vector(mapCases.values());
        dis.close();
        processData();
    }

    private void createLookupSwitch( byte [] Entries, int Offset )
            throws IOException {
        DataInputStream dis = new DataInputStream(
                    new ByteArrayInputStream(Entries) );

        defaultByte = dis.readInt() + Offset;
        int NumVal =  dis.readInt();

        Map mapCases = new HashMap();

        for(int i = 0; i < NumVal ; i++ ) {
            String value =
                Helper.getValue( String.valueOf(dis.readInt()),
                                                    dataType);
            int curTarget = dis.readInt() + Offset;

            Object obj = mapCases.get( new Integer(curTarget) );
            if ( obj == null ) {
                mapCases.put(
                        new Integer(curTarget),
                        new JCaseEntry(value, curTarget) );
            } else {
                JCaseEntry ent = ( JCaseEntry ) obj;
                ent.addValue( value );
            }
        }
        mCases = new Vector(mapCases.values());
        dis.close();
        processData();
    }

    public List getCases() {
        return mCases;
    }

    public String disassemble() {
        StringBuffer sb = new StringBuffer("");
        for ( int i = 0; i < mCases.size() ; i++ ) {
            sb.append("\n\t\t\t" + mCases.get(i) );
        }
        return sb.toString();
    }

    public void setTypeValue(String RhsType , String RhsValue ) {
        mVarName  = RhsValue;
        dataType = RhsType;
        //dataType could be either int or char.
    }

    public void processData() {
        //Sort the entries
        Collections.sort( mCases, new JCaseComparator() );

        //Assign endTargets for all of them.
        int i = 0;
        for ( ; i < mCases.size() - 1 ; i++ ) {
            JCaseEntry ent = ( JCaseEntry ) mCases.get(i);
            JCaseEntry entNext = ( JCaseEntry ) mCases.get(i+1);
            ent.setEndTarget( entNext.getTarget() );
        }
        JCaseEntry entLast = (JCaseEntry)mCases.get(i);
        entLast.setEndTarget( defaultByte );
    }

    public JBranchEntry getBranchEntry( int maxTarget ) {
        return new JBranchEntry( mInsIndex,
                                  maxTarget,
                                  maxTarget,
                                  BranchConstants.TYPE_SWITCH,
                                  mVarName,
                                  "","");
    }

    /**
     *  Inserts a CaseEntry in the list.
     **/
    public void addCaseEntry( JCaseEntry aCaseEntry ) {
        mCases.add ( aCaseEntry );
    }

    public String toString() {
        return mCases.toString();
    }
}
