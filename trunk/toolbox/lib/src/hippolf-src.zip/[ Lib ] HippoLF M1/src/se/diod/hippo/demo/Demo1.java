package se.diod.hippo.demo;


import java.awt.BorderLayout;

import javax.swing.BoxLayout;
import javax.swing.JColorChooser;
import javax.swing.JDesktopPane;
import javax.swing.JEditorPane;
import javax.swing.JProgressBar;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JSlider;
import javax.swing.JTextPane;
import javax.swing.JToolBar;
import javax.swing.JTabbedPane;
import javax.swing.JToggleButton;
import javax.swing.JScrollPane;
import javax.swing.JScrollBar;
import javax.swing.JSplitPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.JTextArea;
import javax.swing.JInternalFrame;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.Border;

import se.diod.hippo.setup.InstallMenu;




/**
 * 
 * @author Robert Karlsson
 * @created 2003-okt-26
 *
 */
public class Demo1 extends JFrame implements java.awt.event.ActionListener {
	private JPanel			workPane;
	private JTabbedPane		tabPane;
	private javax.swing.JPopupMenu		popup	= null;




	/**
	 * 
	 *
	 */
	public Demo1() {
		// Install third party look and feels..
		UIManager.installLookAndFeel( "Plastic", "com.jgoodies.plaf.plastic.PlasticLookAndFeel" );
		UIManager.installLookAndFeel( "PlasticXP", "com.jgoodies.plaf.plastic.PlasticXPLookAndFeel" );
		UIManager.installLookAndFeel( "Plastic3D", "com.jgoodies.plaf.plastic.Plastic3DLookAndFeel" );
		UIManager.installLookAndFeel( "WindowsExt", "com.jgoodies.plaf.windows.ExtWindowsLookAndFeel" );
		UIManager.installLookAndFeel( "Tonic", "com.digitprop.tonic.TonicLookAndFeel" );
		UIManager.installLookAndFeel( "Tiny", "de.muntjak.tinylookandfeel.TinyLookAndFeel" );
		UIManager.installLookAndFeel( "XP", "com.stefankrause.xplookandfeel.XPLookAndFeel" );
		UIManager.installLookAndFeel( "Liquid", "com.birosoft.liquid.LiquidLookAndFeel" );

		setLookAndFeel();

		workPane		= new JPanel();
		//this.workPane	= new JxTitlePanel( "Test Cases", true, icon );
		this.tabPane	= new JTabbedPane( JTabbedPane.TOP );
		//this.tabPane.setTabLayoutPolicy( JTabbedPane.SCROLL_TAB_LAYOUT );

		createWorkPane( this.workPane );
		 //createStatusBar( this.workPane );
		createMenu();
		createToolBar( this.workPane );
		createTabSplitPane( this.tabPane );
		createEditors( this.tabPane );
		createTabTabs( this.tabPane );
		createTabDesktop( this.tabPane );
		 //createTabTabbedPane();
		 //createTabDesktop();
		createTabStates( this.tabPane );
		createTabDialogs( this.tabPane );
		 //createTabHTML Labels();
		 //createTabNarrowTest();
		 //createTabAlignment();
		 //createTabClearLook();

		setBounds( 350, 20, 600, 400 );
		setTitle("HippoLF Test Application");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.show();
	}




	/**
	 * 
	 *
	 */
	protected void createWorkPane( JPanel aWorkPane ) {
		aWorkPane.setLayout( new BorderLayout() );

		aWorkPane.add( BorderLayout.CENTER, this.tabPane );

		this.getContentPane().add( workPane );
	}




	/**
	 * 
	 *
	 */
	protected void createStatusBar( JPanel aWorkPane ) {
		JPanel sb = new JPanel();

		sb.setBackground( new java.awt.Color( 245, 245, 245, 255 ) );

		Border tmp1 = javax.swing.BorderFactory.createLineBorder( new java.awt.Color( 155, 155, 155, 255 ) );
		Border tmp2 = new javax.swing.plaf.basic.BasicBorders.MarginBorder();
		Border fin	= new javax.swing.border.CompoundBorder( tmp1, tmp2 );

		sb.setBorder( fin );
		sb.setPreferredSize( new java.awt.Dimension( 0, 18 ) );

		aWorkPane.add( BorderLayout.SOUTH, sb );
	}




	/**
	 * 
	 *
	 */
	protected void createMenu() {
		JMenuBar menubar = new JMenuBar();
		this.setJMenuBar( menubar );

		JMenu test 			= new JMenu( "Menu" );				menubar.add( test );
		JMenuItem testitem1 = new JMenuItem( "Disabled" );		testitem1.setEnabled( false ); test.add( testitem1 );
		JMenuItem testitem2 = new JMenuItem( "MenuItem2" );		test.add( testitem2 );

		test.addSeparator();

		JMenu subtest			= new JMenu( "Menu" );				test.add( subtest );
		JMenuItem subtestitem1	= new JMenuItem( "MenuItem" );		subtest.add( subtestitem1 );
		JMenuItem subtestitem2	= new JMenuItem( "MenuItem" );		subtest.add( subtestitem2 );

		test.addSeparator();
		
		javax.swing.JRadioButtonMenuItem testradio1 = new javax.swing.JRadioButtonMenuItem( "RadioButton" );		test.add( testradio1 );
		javax.swing.JRadioButtonMenuItem testradio2 = new javax.swing.JRadioButtonMenuItem( "RadioButton" );		test.add( testradio2 );
		javax.swing.ButtonGroup group = new javax.swing.ButtonGroup();
		group.add( testradio1 );
		group.add( testradio2 );

		test.addSeparator();

		javax.swing.JCheckBoxMenuItem testcheck1 = new javax.swing.JCheckBoxMenuItem( "CheckButton" );		test.add( testcheck1 );
		javax.swing.JCheckBoxMenuItem testcheck2 = new javax.swing.JCheckBoxMenuItem( "CheckButton" );		test.add( testcheck2 );

		// Create the popup menu.
		  popup = new javax.swing.JPopupMenu();
		  JMenuItem menuItem = new JMenuItem("A popup menu item");
		  menuItem.addActionListener(this);
		  popup.add(menuItem);
		  menuItem = new JMenuItem("Another popup menu item");
		  menuItem.addActionListener(this);
		  popup.add(menuItem);

		java.awt.event.MouseListener popupListener = new PopupListener();
		menubar.addMouseListener( popupListener );


		InstallMenu plafMenu = new InstallMenu();		
		plafMenu.createMenu( this, menubar, false, "Look & Feel", true );
	}




	class PopupListener extends java.awt.event.MouseAdapter {
		public void mousePressed(java.awt.event.MouseEvent e) {
			maybeShowPopup(e);
		}

		public void mouseReleased(java.awt.event.MouseEvent e) {
			maybeShowPopup(e);
		}

		private void maybeShowPopup(java.awt.event.MouseEvent e) {
			if (e.isPopupTrigger()) {
				popup.show(e.getComponent(),
						   e.getX(), e.getY());
			}
		}
	}




	/**
	 * 
	 *
	 */
	protected void createToolBar( JPanel aWorkPane ) {
		JToolBar tb = new JToolBar();
		tb.setMargin( new java.awt.Insets( 0, 0, 0, 120) );

		try {
			java.net.URL url	= this.getClass().getResource( "/se/diod/hippo/images/TreeOpen.gif" );
			java.net.URL url2	= this.getClass().getResource( "/se/diod/hippo/images/TreeClosed.gif" );
			java.net.URL url3	= this.getClass().getResource( "/se/diod/hippo/images/TreeLeaf.gif" );

			java.awt.Toolkit toolkit = java.awt.Toolkit.getDefaultToolkit(); 

			javax.swing.ImageIcon blueball = new javax.swing.ImageIcon( url ); 
			javax.swing.ImageIcon blueball2 = new javax.swing.ImageIcon( url2 ); 
			javax.swing.ImageIcon blueball3 = new javax.swing.ImageIcon( url3 ); 

			JButton tbButton1 = new JButton( "", blueball );
			tbButton1.setHorizontalTextPosition( javax.swing.SwingConstants.CENTER );
			tbButton1.setVerticalTextPosition( javax.swing.SwingConstants.BOTTOM );
			tb.add( tbButton1 );
			tbButton1.setMargin( new java.awt.Insets( 2, 10, 2, 10 ) );

			JButton tbButton2 = new JButton( "Button2", blueball2 );
			tbButton2.setHorizontalTextPosition( javax.swing.SwingConstants.CENTER );
			tbButton2.setVerticalTextPosition( javax.swing.SwingConstants.BOTTOM );
			tb.add( tbButton2 );

			tb.addSeparator( new java.awt.Dimension( 40, 18));

			JButton tbButton3 = new JButton( "Button3", blueball );
			tbButton3.setHorizontalTextPosition( javax.swing.SwingConstants.CENTER );
			tbButton3.setVerticalTextPosition( javax.swing.SwingConstants.BOTTOM );
			tb.add( tbButton3 );

			JButton tbButton4 = new JButton( "Button4", blueball2 );
			tbButton4.setHorizontalTextPosition( javax.swing.SwingConstants.CENTER );
			tbButton4.setVerticalTextPosition( javax.swing.SwingConstants.BOTTOM );
			tb.add( tbButton4 );
		} catch( Exception e ) {
			System.out.println( "[Demo1 | createToolBar] :: " + e );
		}

		this.getContentPane().add( BorderLayout.NORTH, tb );
	}




	/**
	 * 
	 *
	 */
	protected void createTabSplitPane( JTabbedPane aTabPane ) {
		// Add table..
		Object[][] data = {
			{"Mary", "Campione", "Snowboarding", new Integer(5), new Boolean(false)},
			{"Alison", "Huml", 	 "Rowing", new Integer(3), new Boolean(true)},
			{"Kathy", "Walrath", "Chasing toddlers", new Integer(2), new Boolean(false)},
			{"Sharon", "Zakhour", "Speed reading", new Integer(20), new Boolean(true)},
			{"Angela", "Lih","Teaching high school", new Integer(4), new Boolean(false)}
		};

		String[] columnNames = {"First Name", 
								"Last Name",
								"Sport",
								"# of Years",
								"Vegetarian"};
		JTable bord = new JTable( data, columnNames );
		JScrollPane scrollPane = new JScrollPane(bord);

		// Add tree..
		JTree tree = new JTree();
		JScrollPane scrollPane2 = new JScrollPane(tree);
		

		// Add splitpanes..
		JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scrollPane2, scrollPane);

		split.setDividerLocation(150);

		split.setOneTouchExpandable( true );

		aTabPane.addTab( "SplitPane", split );
	}




	/**
	 * 
	 *
	 */
	protected void createTabDesktop( JTabbedPane aTabPane ) {
		JDesktopPane desktop = new JDesktopPane();

		JInternalFrame iFrame1;

		iFrame1 = new JInternalFrame( "iFrame1", true, true, true, true );
		iFrame1.setContentPane( new JPanel() );
		iFrame1.setBounds( 40, 40, 200, 70 );
		iFrame1.setVisible( true );
		desktop.add( iFrame1, javax.swing.JLayeredPane.PALETTE_LAYER );

		iFrame1 = new JInternalFrame( "iFrame2", false, false, false, false );
		iFrame1.setContentPane( new JPanel() );
		iFrame1.setBounds( 40, 140, 200, 70 );
		iFrame1.setVisible( true );
		desktop.add( iFrame1, javax.swing.JLayeredPane.FRAME_CONTENT_LAYER );

		iFrame1 = new JInternalFrame( "iFrame3", true, false, false, false );
		iFrame1.setContentPane( new JPanel() );
		iFrame1.setBounds( 260, 40, 200, 170 );
		iFrame1.setVisible( true );
		iFrame1.putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
		desktop.add( iFrame1, javax.swing.JLayeredPane.PALETTE_LAYER );

		aTabPane.addTab( "Desktop", desktop );
	}




	/**
	 * 
	 *
	 */
	protected void createTabTabs( JTabbedPane aTabPane ) {
		//JTabbedPane tab1 = new JTabbedPane( JTabbedPane.TOP );
		JTabbedPane tab2 = new JTabbedPane( JTabbedPane.BOTTOM );
		//JTabbedPane tab3 = new JTabbedPane( JTabbedPane.LEFT );
		//JTabbedPane tab4 = new JTabbedPane( JTabbedPane.RIGHT );

		String[] listData	= { "Red", "Blue", "Yellow", "Green", "Orange", "Black", "Purple" };
		JList			item12 = new JList( listData );

		//tab1.add( "Test1_1", new JPanel() );
		//tab1.add( "Test1_2", new JPanel() );
		//tab1.add( "Test1_3", new JPanel() );
		tab2.add( "JList", item12 );
		tab2.add( "Empty", new JPanel() );
		tab2.add( "Empty", new JPanel() );
		//tab3.add( "Test3_1", new JPanel() );
		//tab3.add( "Test3_2", new JPanel() );
		//tab3.add( "Test3_3", new JPanel() );
		//tab4.add( "Test4_1", new JPanel() );
		//tab4.add( "Test4_2", new JPanel() );
		//tab4.add( "Test4_3", new JPanel() );

		//JSplitPane split3 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, tab1, tab2 );
		//JSplitPane split2 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, tab3, tab4 );
		//JSplitPane split1 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, tab1, tab2 );

		//split1.setDividerLocation( 120 );
		//split2.setDividerLocation( 280 );
		//split3.setDividerLocation( 280 );

		aTabPane.add( "JTabbedPane", tab2 );
	}




	/**
	 * 
	 *
	 */
	protected void createTabStates( JTabbedPane aTabPane ) {
		JPanel work = new JPanel( );
		JPanel work2 = new JPanel( );
		String[] test = { "row 1", "row 2", "row 3", "i was here playing ball" };

		JButton			item1 = new JButton( "AButton" );
		JToggleButton	item2 = new JToggleButton( "Toggle" );
		JSpinner		item3 = new JSpinner();	item3.setValue( new Integer( 30 ) );
		JComboBox		item4 = new JComboBox( test );
		JProgressBar	item5 = new JProgressBar( 0, 100 );
		JTextField		item6 = new JTextField( "JTextField" );
		JSlider			item7 = new JSlider( JSlider.HORIZONTAL, 0, 50, 14 );
		JSlider			item8 = new JSlider( JSlider.VERTICAL, 0, 50, 14 );
		JProgressBar	item9 = new JProgressBar( 0, 100 );
		JSpinner		item10 = new JSpinner();
		JProgressBar	item11 = new JProgressBar( 0, 100 );
		JPasswordField	item12 = new JPasswordField();
		JScrollBar		item13 = new JScrollBar();
		JScrollBar		item14 = new JScrollBar( JScrollBar.HORIZONTAL );

		item1.setToolTipText( "A sentence." );

		item12.setColumns( 20 );

		
		work.setLayout( new BorderLayout() );

		item5.setValue( 39 );
		item9.setValue( 39 );
		item9.setOrientation( JProgressBar.VERTICAL );
		item10.setPreferredSize( new java.awt.Dimension( 50, 17 ) );
		item11.setIndeterminate( true );

		work2.add( item5 );
		work2.add( item6 );
		work2.add( item12 );
		work2.add( item4 );
		work2.add( item1 );
		work2.add( item2 );
		work2.add( item10 );
		//work2.add( item3 );
		work2.add( item7 );
		work2.add( item8 );
		work2.add( item9 );
		//work2.add( item11 );
		work2.add( item13 );
		work2.add( item14 );

		//work.add( BorderLayout.WEST, item12 );
		work.add( BorderLayout.CENTER, work2 );

		aTabPane.add( "States", work );
	}




	/**
	 * 
	 *
	 */
	protected void createEditors( JTabbedPane aTabPane ) {
		try {
			JPanel work = new JPanel();
			work.setLayout( new BorderLayout() );

			JEditorPane ep	= new JEditorPane();
			JTextPane tp	= new JTextPane();

			ep.setText( "JEditorPane" );
			tp.setText( "JTextPane" );

			JScrollPane scrollPane1 = new JScrollPane( ep );
			JScrollPane scrollPane2 = new JScrollPane( tp );

			// Add textarea..
			JScrollPane scrollPane3 = new JScrollPane( new JTextArea("JTextArea") );

			// Add splitpanes..
			JSplitPane split = new JSplitPane( JSplitPane.HORIZONTAL_SPLIT, scrollPane1, scrollPane2 );
			JSplitPane split2 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, scrollPane3, split);

			split2.setDividerLocation(100);
			split.setDividerLocation( 150 );

			work.add( BorderLayout.CENTER, split2 );

			aTabPane.add( "Editors", work );
		} catch( Exception e ) {
			System.out.println( "TestApp1::createEditors::> " + e );
		}
	}



	/**
	 * 
	 *
	 */
	protected void createTabDialogs( JTabbedPane aTabPane ) {
		JPanel work = new JPanel();
		BoxLayout bl2 = new BoxLayout( work, BoxLayout.X_AXIS );
		work.setLayout( bl2 );

		JPanel bpanel = new JPanel( /*new java.awt.GridLayout( 2, 3 )*/ );
		BoxLayout bl = new BoxLayout( bpanel, BoxLayout.Y_AXIS );
		bpanel.setLayout( bl );
		JButton	b1 = new JButton( "Open dialog.." );
		JButton	b2 = new JButton( "Save dialog.." );
		JButton	b3 = new JButton( "Color dialog.." );
		JButton	b4 = new JButton( "Information dialog.." );
		JButton	b5 = new JButton( "Warning dialog.." );
		JButton	b6 = new JButton( "Error dialog.." );
		b1.addActionListener( this );
		b2.addActionListener( this );
		b3.addActionListener( this );
		b4.addActionListener( this );
		b5.addActionListener( this );
		b6.addActionListener( this );
		bpanel.add( b1 );
		bpanel.add( b2 );
		bpanel.add( b3 );
		bpanel.add( b4 );
		bpanel.add( b5 );
		bpanel.add( b6 );

		// Native dialog...
		//new java.awt.FileDialog( getParentFrame(), "Open File (Native)").show();

		work.add( bpanel );

		aTabPane.add( "Dialogs", work );
	}




	/**
	 * 
	 * 
	 */
	public void actionPerformed( java.awt.event.ActionEvent ae ) {
		Object o = ae.getSource();
		
		if( ((JButton)o).getText().equals( "Open dialog.." ) ) {
			new javax.swing.JFileChooser().showOpenDialog( this );
		} else if( ((JButton)o).getText().equals( "Save dialog.." ) ) {
			new javax.swing.JFileChooser().showSaveDialog( this );
		} else if( ((JButton)o).getText().equals( "Color dialog.." ) ) {
			JColorChooser.showDialog( this, "Test", java.awt.Color.red);
		} else if( ((JButton)o).getText().equals( "Information dialog.." ) ) {
			javax.swing.JOptionPane.showMessageDialog( this, "Information dialog");
		} else if( ((JButton)o).getText().equals( "Warning dialog.." ) ) {
			javax.swing.JOptionPane.showMessageDialog( this, "Warning dialog", "Inane warning", javax.swing.JOptionPane.WARNING_MESSAGE);
		} else if( ((JButton)o).getText().equals( "Error dialog.." ) ) {
			javax.swing.JOptionPane.showMessageDialog( this, "Error dialog", "Inane error", javax.swing.JOptionPane.ERROR_MESSAGE);
		}
	}




	/**
	 * 
	 * 
	 */
	protected void setLookAndFeel() {
		String lafName1 = "javax.swing.plaf.metal.MetalLookAndFeel";
		String lafName2 = "com.sun.java.swing.plaf.motif.MotifLookAndFeel";
		String lafName3 = "se.diod.hippo.plaf.HippoLookAndFeel";

		try {
			UIManager.setLookAndFeel( lafName3 );
		} catch (Exception e) {
			System.err.println("Can't set look & feel:" + e);
		};
	}
}
