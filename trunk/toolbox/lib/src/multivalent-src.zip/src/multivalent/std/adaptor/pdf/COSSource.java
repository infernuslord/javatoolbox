package multivalent.std.adaptor.pdf;

import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

import static multivalent.std.adaptor.pdf.COS.*;



/**
	Abstract superclass for classes that can produce PDF COS objects.

	<ul>
	<li>Object access: {@link #getObject(Object)}, {@link #getObjCnt()} {@link #getTrailer()}
	<li>Algorithms: {@link #connected(Object)}
	<li>Object inspection: {@link #getDecodeParms(Dict, String)}, 
	<li>Versioning: {@link #getMajorVersion()}, {@link #getMinorVersion()}, {@link #compareVersion(int,int)}
	</ul>

	@version $Revision: 1.2 $ $Date: 2003/08/29 03:49:10 $
*/
public abstract class COSSource {
  // OBJECT ACCESS

  public abstract Object getObject(Object ref) throws IOException;
  public abstract int getObjCnt();
  public abstract Dict getTrailer();
  /** Convenience method for <code>((Number)getObject(<var>ref</var>)).intValue()</code>. */
  public int getObjInt(Object ref) throws IOException { return ((Number)getObject(ref)).intValue(); }
  /** Convenience method for <code>(Dict)getObject(<var>ref</var>))</code>. 
  public Dict getDict(Object ref) throws IOException { return (Dict)getObject(ref); }*/
  /** Convenience method for <code>((Number)getObject(<var>ref</var>)).intValue()</code>. 
  public double getReal(Object ref) throws IOException { return ((Number)getObject(ref)).intValue(); }*/


  // OBJECT CREATION
  // getColorSpace, getImage, getFont, ...


  // ENCRYPTION



  // ALGORITHMS

  /**
	Collect list of {@link IRef}s to objects reachable from object <var>obj</var> connected by nested data structures or indirect references.
  */
  public List<IRef> connected(Object obj) throws IOException {
	List<IRef> l = new ArrayList<IRef>(20);
	connected(obj, l, new boolean[getObjCnt()]);	// boolean[] so fast even if connected(getTrailer()), so can use for fault()
	//if (obj!=null && CLASS_IREF==obj.getClass() && !l.contains(obj)) l.add(obj);
	return l;
  }

  private void connected(Object o, List<IRef> l, boolean[] seen) throws IOException {
	if (o==null) return;

	Class cl = o.getClass();
	if (CLASS_IREF==o.getClass()) {
		IRef iref = (IRef)o; int id = iref.id;
		if (id<0 || id>=seen.length || seen[id]) return;
		l.add(iref);	// only IRefs in list, which may or may not include initiating object
		seen[id] = true;
		o = getObject(o); cl = o.getClass();
	}

	if (CLASS_ARRAY==cl) {
		Object[] oa = (Object[])o;
		for (int i=0,imax=oa.length; i<imax; i++) connected(oa[i], l, seen);
	} else if (CLASS_DICTIONARY==cl) {
		Dict dict = (Dict)o;
		for (Iterator<Object> i = dict.values().iterator(); i.hasNext(); ) connected(i.next(), l, seen);
	}
  }



  // VERSIONING
  /** Returns the major version of PDF used; for example, for PDF 1.4, the major version is 1. */
  public abstract int getMajorVersion();
  /** Returns the minor version of PDF used; for example, for PDF 1.4, the minor version is 4. */
  public abstract int getMinorVersion();
  /** Compare PDF version to passed numbers and return -1 if less, 0 if equal, and 1 if greater. */
  public int compareVersion(int major, int minor) { return getMajorVersion()!=major? getMajorVersion()-major: getMinorVersion()-minor; }



  /** Returns DecodeParms associated with <var>filter</var>; or if no filter by that name returns null. */
  public Object getDecodeParms(Dict stream, String filter) throws IOException {
	assert stream!=null && filter!=null;

	Object dp = null;
	Object fo = getObject(stream.get("Filter")), dpo = getObject(stream.get("DecodeParms"));
	if (fo==null) {
	} else if (CLASS_NAME==fo.getClass()) {
		if (fo.equals(filter)) dp = dpo!=null? dpo: OBJECT_NULL;
	} else { assert CLASS_ARRAY==fo.getClass();
		Object[] foa = (Object[])fo;
		for (int i=0,imax=foa.length; i<imax; i++) {
			if (filter.equals(foa[i])) {
				dp = dpo!=null? getObject(((Object[])dpo)[i]): OBJECT_NULL;
				break;
			}
		}	
	}
	return dp;
  }
}
