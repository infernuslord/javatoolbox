/**
 * L2FProd.com Common Components 0.1-dev License.
 *
 * Copyright 2004 L2FProd.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.l2fprod.common.swing.plaf.basic;

import com.l2fprod.common.swing.JLinkButton;
import com.l2fprod.common.swing.JTaskPaneGroup;
import com.l2fprod.common.swing.PercentLayout;
import com.l2fprod.common.swing.icons.EmptyIcon;
import com.l2fprod.common.swing.plaf.TaskPaneGroupUI;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.LayoutManager2;
import java.awt.event.ActionEvent;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.event.MouseInputAdapter;
import javax.swing.event.MouseInputListener;
import javax.swing.plaf.ActionMapUIResource;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicGraphicsUtils;

/**
 * Base implementation of the <code>JTaskPaneGroup</code> UI.
 *  
 */
public class BasicTaskPaneGroupUI extends TaskPaneGroupUI {

  private static FocusListener focusListener = new RepaintOnFocus();

  public static ComponentUI createUI(JComponent c) {
    return new BasicTaskPaneGroupUI();
  }

  protected JTaskPaneGroup group;

  protected boolean mouseOver;
  protected PropertyChangeListener propertyListener;
  protected MouseInputListener mouseListener;

  public void installUI(JComponent c) {
    super.installUI(c);
    group = (JTaskPaneGroup)c;

    installDefaults();
    installListeners();
    installKeyboardActions();
  }

  protected void installDefaults() {
    group.setLayout(new Layout(new PercentLayout(PercentLayout.VERTICAL, 2)));
    group.setOpaque(true);

    group.setBorder(
      new CompoundBorder(
        createPaneBorder(),
        BorderFactory.createEmptyBorder(10, 10, 0, 10)));

    LookAndFeel.installColorsAndFont(
      group,
      "TaskPaneGroup.background",
      "TaskPaneGroup.foreground",
      "TaskPaneGroup.font");
  }

  protected void installListeners() {
    propertyListener = createPropertyListener();
    group.addPropertyChangeListener(propertyListener);

    mouseListener = createMouseInputListener();
    group.addMouseMotionListener(mouseListener);
    group.addMouseListener(mouseListener);

    group.addFocusListener(focusListener);
  }

  protected void installKeyboardActions() {
    InputMap inputMap = (InputMap)UIManager.get("TaskPaneGroup.focusInputMap");
    if (inputMap != null) {
      SwingUtilities.replaceUIInputMap(
        group,
        JComponent.WHEN_FOCUSED,
        inputMap);
    }

    ActionMap map = getActionMap();
    if (map != null) {
      SwingUtilities.replaceUIActionMap(group, map);
    }
  }

  ActionMap getActionMap() {
    ActionMap map = new ActionMapUIResource();
    map.put("toggleExpanded", new ToggleExpandedAction());
    return map;
  }

  public void uninstallUI(JComponent c) {
    uninstallListeners();
    super.uninstallUI(c);
  }

  protected void uninstallListeners() {
    group.removeMouseListener(mouseListener);
    group.removeMouseMotionListener(mouseListener);
    group.removeFocusListener(focusListener);
  }

  protected MouseInputListener createMouseInputListener() {
    return new ToggleListener();
  }

  protected PropertyChangeListener createPropertyListener() {
    return new ChangeListener();
  }

  protected boolean isInBorder(MouseEvent event) {
    return event.getY() < getTitleHeight();
  }

  protected int getTitleHeight() {
    return 25;
  }

  protected Border createPaneBorder() {
    return new PaneBorder();
  }

  public Component createAction(Action action) {
    JLinkButton button = new JLinkButton(action);
    button.setOpaque(false);
    button.setBorder(null);
    button.setBorderPainted(false);
    button.setFocusPainted(true);
    button.setForeground(UIManager.getColor("TaskPaneGroup.titleForeground"));
    return button;
  }

  protected void expandedStateChanged() {
    // when the group is not expanded, we have to make sure all components
    // inside are not focusable. We hide them to simulate this.
    // We could do this by having our custom focus manager for the
    // JTaskPaneGroup, unfortunately until now I do not know how to do this.
    //
    // PENDING(fred) what if someone put hidden components in the taskpane, the
    // component will be made visible. We should somehow track which components
    // we need to make visible.
    Component[] components = group.getComponents();
    boolean expanded = group.isExpanded();
    boolean componentHadFocus = false;
    for (int i = 0, c = components.length; i < c; i++) {
      components[i].setVisible(expanded);
      if (!expanded && components[i].hasFocus()) {
        componentHadFocus = true;
      }
    }
    if (componentHadFocus) {
      group.requestFocus();
    }
  }

  static class RepaintOnFocus implements FocusListener {
    public void focusGained(FocusEvent e) {
      e.getComponent().repaint();
    }
    public void focusLost(FocusEvent e) {
      e.getComponent().repaint();
    }
  }

  class ToggleListener extends MouseInputAdapter {
    public void mouseEntered(MouseEvent e) {
      if (isInBorder(e)) {
        e.getComponent().setCursor(
          Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
      } else {
        mouseOver = false;
        group.repaint();
      }
    }
    public void mouseExited(MouseEvent e) {
      e.getComponent().setCursor(Cursor.getDefaultCursor());
      mouseOver = false;
      group.repaint();
    }
    public void mouseMoved(MouseEvent e) {
      if (isInBorder(e)) {
        e.getComponent().setCursor(
          Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        mouseOver = true;
        group.repaint();
      } else {
        e.getComponent().setCursor(Cursor.getDefaultCursor());
        mouseOver = false;
        group.repaint();
      }
    }
    public void mouseReleased(MouseEvent e) {
      if (isInBorder(e)) {
        group.setExpanded(!group.isExpanded());
      }
    }
  }

  class ChangeListener implements PropertyChangeListener {
    public void propertyChange(PropertyChangeEvent evt) {
      if (JTaskPaneGroup.EXPANDED_CHANGED_KEY.equals(evt.getPropertyName())) {
        expandedStateChanged();
        group.revalidate();
        group.repaint();
      } else {
        group.repaint();
      }
    }
  }

  class ToggleExpandedAction extends AbstractAction {
    public ToggleExpandedAction() {
      super("toggleExpanded");
    }
    public void actionPerformed(ActionEvent e) {
      group.setExpanded(!group.isExpanded());
    }
    public boolean isEnabled() {
      return group.isVisible();
    }
  }

  /**
   * Wrapper around a layout manager to support expand/collapse.
   */
  protected static class Layout implements LayoutManager2 {
    private LayoutManager2 layout;
    public Layout(LayoutManager2 layout) {
      this.layout = layout;
    }
    public void addLayoutComponent(Component comp, Object constraints) {
      layout.addLayoutComponent(comp, constraints);
    }
    public void addLayoutComponent(String name, Component comp) {
      layout.addLayoutComponent(name, comp);
    }
    public float getLayoutAlignmentX(Container target) {
      return layout.getLayoutAlignmentX(target);
    }
    public float getLayoutAlignmentY(Container target) {
      return layout.getLayoutAlignmentY(target);
    }
    public void invalidateLayout(Container target) {
      layout.invalidateLayout(target);
    }
    public void layoutContainer(Container parent) {
      if (((JTaskPaneGroup)parent).isExpanded()) {
        layout.layoutContainer(parent);
      }
    }
    public Dimension maximumLayoutSize(Container target) {
      JTaskPaneGroup group = (JTaskPaneGroup)target;
      if (group.isExpanded()) {
        return layout.maximumLayoutSize(target);
      } else {
        return new Dimension(
          Integer.MAX_VALUE,
          ((BasicTaskPaneGroupUI)group.getUI()).getTitleHeight());
      }
    }
    public Dimension minimumLayoutSize(Container parent) {
      return preferredLayoutSize(parent);
    }
    public Dimension preferredLayoutSize(Container parent) {
      Dimension size = layout.preferredLayoutSize(parent);
      Insets insets = parent.getInsets();
      JTaskPaneGroup group = (JTaskPaneGroup)parent;
      int titleWidth = getTitleHeight(group);

      FontMetrics metrics =
        parent.getToolkit().getFontMetrics(parent.getFont());
      if (metrics != null && group.getText() != null) {
        titleWidth
          += SwingUtilities.computeStringWidth(metrics, group.getText());
      }
      titleWidth += insets.left + insets.right;
      if (group.getIcon() != null) {
        titleWidth += group.getIcon().getIconWidth();
      }
      if (group.isExpanded()) {
        return new Dimension(Math.max(size.width, titleWidth), size.height);
      } else {
        return new Dimension(
          Math.max(size.width, titleWidth),
          getTitleHeight(group));
      }
    }
    public void removeLayoutComponent(Component comp) {
      layout.removeLayoutComponent(comp);
    }
  }

  protected static class ChevronIcon implements Icon {
    boolean up = true;
    public ChevronIcon(boolean up) {
      this.up = up;
    }
    public int getIconHeight() {
      return 3;
    }
    public int getIconWidth() {
      return 6;
    }
    public void paintIcon(Component c, Graphics g, int x, int y) {
      if (up) {
        g.drawLine(x + 3, y, x, y + 3);
        g.drawLine(x + 3, y, x + 6, y + 3);
      } else {
        g.drawLine(x, y, x + 3, y + 3);
        g.drawLine(x + 3, y + 3, x + 6, y);
      }
    }
  }

  protected static int getTitleHeight(Component c) {
    return ((BasicTaskPaneGroupUI) ((JTaskPaneGroup)c).getUI())
      .getTitleHeight();
  }

  /**
   * The border of the taskpane group paints the "text", the "icon", the
   * "expanded" status and the "special" type.
   *  
   */
  protected static class PaneBorder implements Border {

    public Insets getBorderInsets(Component c) {
      return new Insets(getTitleHeight(c), 1, 1, 1);
    }

    public boolean isBorderOpaque() {
      return false;
    }

    protected void paintBorder(JTaskPaneGroup group, Graphics g) {
      // if the group is expanded, paint a border around the group
      if (group.isExpanded()) {
        if (group.isSpecial()) {
          g.setColor(
            UIManager.getColor("TaskPaneGroup.specialTitleBackground"));
        } else {
          g.setColor(
            UIManager.getColor("TaskPaneGroup.titleBackgroundGradientStart"));
        }
        g.drawRect(0, 0, group.getWidth() - 1, group.getHeight() - 1);
      }
    }

    protected void paintTitleBackground(JTaskPaneGroup group, Graphics g) {
      if (group.isSpecial()) {
        g.setColor(UIManager.getColor("TaskPaneGroup.specialTitleBackground"));
      } else {
        g.setColor(
          UIManager.getColor("TaskPaneGroup.titleBackgroundGradientStart"));
      }
      g.fillRect(0, 0, group.getWidth(), getTitleHeight(group) - 1);
    }

    protected void paintTitle(
      JTaskPaneGroup group,
      Graphics g,
      Color textColor,
      int x,
      int y,
      int width,
      int height) {
      JLabel label = new JLabel();
      label.setOpaque(false);
      label.setForeground(textColor);
      label.setFont(g.getFont());
      label.setIconTextGap(8);
      label.setText(group.getText());
      label.setIcon(
        group.getIcon() == null ? new EmptyIcon() : group.getIcon());
      g.translate(x, y);
      label.setBounds(0, 0, width, height);
      label.paint(g);
      g.translate(-x, -y);
    }

    protected void paintExpandedControls(JTaskPaneGroup group, Graphics g) {
    }

    public void paintBorder(
      Component c,
      Graphics g,
      int x,
      int y,
      int width,
      int height) {

      JTaskPaneGroup group = (JTaskPaneGroup)c;

      // paint the border of the group
      paintBorder(group, g);

      // paint the title background
      paintTitleBackground(group, g);

      // paint the the toggles
      paintExpandedControls(group, g);

      // paint the title text and icon
      Color paintColor;
      if (group.isSpecial()) {
        paintColor = UIManager.getColor("TaskPaneGroup.specialTitleForeground");
      } else {
        paintColor = UIManager.getColor("TaskPaneGroup.titleForeground");
      }

      // focus painted same color as text
      if (group.hasFocus()) {
        g.setColor(paintColor);
        BasicGraphicsUtils.drawDashedRect(
          g,
          3,
          3,
          width - 6,
          getTitleHeight(c) - 6);
      }

      paintTitle(
        group,
        g,
        paintColor,
        3,
        0,
        c.getWidth() - getTitleHeight(c) - 3,
        getTitleHeight(c));
    }
  }

}
