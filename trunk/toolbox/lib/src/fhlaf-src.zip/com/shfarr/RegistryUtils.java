package com.shfarr;

import java.util.Enumeration;
import java.util.HashMap;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import com.ice.jni.registry.RegBinaryValue;
import com.ice.jni.registry.RegDWordValue;
import com.ice.jni.registry.RegMultiStringValue;
import com.ice.jni.registry.RegStringValue;
import com.ice.jni.registry.Registry;
import com.ice.jni.registry.RegistryKey;
import com.ice.jni.registry.RegistryValue;

/**
 * $COPYRIGHT$
 * $Id: RegistryUtils.java,v 1.3 2004/06/22 16:22:25 shfarr Exp $
 * 
 * Created on: Apr 27, 2004
 * Author: Borsos Szabolcs
 */

public class RegistryUtils {
    private static RegistryUtils regUtils;

    private RegistryUtils() {
        
    }
    
    public static RegistryUtils getInstance() {
        if (regUtils == null) {
            regUtils = new RegistryUtils();
        }
        
        return regUtils;
    }
    
    public String getRegistryValue(RegistryKey regkey, String valueName) {
        try {
            return new String(regkey.getValue(valueName).getByteData()).trim();
        } catch (Exception ex) {
            ex.printStackTrace();
            return "";
        }
    }
    
    public HashMap getRegistryKeys(Object[] keys) {
        HashMap result = new HashMap();
        for (int i = 0; i < keys.length; i++) {
            String current = (String) keys[i];

            RegistryKey root = null;

            // variables
            if(current.startsWith("${")) {

                // hard coded search for IP Address
                if (current.equalsIgnoreCase("${ip}")) {
                    StringBuffer buffer = new StringBuffer();
                    try {
                        RegistryKey clientIP = Registry.HKEY_LOCAL_MACHINE.createSubKey("SYSTEM\\CurrentControlSet\\Services", "", RegistryKey.ACCESS_READ);

                        for (Enumeration e = clientIP.keyElements(); e.hasMoreElements(); ) {
                            RegistryKey tcpKey = searchForTCPKey(clientIP.openSubKey((String) e.nextElement()), "Parameters");

                            if (tcpKey != null) {
                                String ip = new String(tcpKey.getValue("IPAddress").getByteData()).trim();
                                if (ip.equals("0.0.0.0")) continue;
                                if (buffer.length() == 0) {
                                    buffer.append(";" + ip);
                                } else {
                                    buffer.append(ip);
                                }
                            }
                        }
                    } catch (Exception ex) {
                        System.out.println("An error occured: " + ex.getMessage());
                    }
                    result.put(current, encode(buffer.toString()));
                    continue;
                }
            } else {
                root = getRootKey(current);
            }
            
            if (root == null) {
                System.out.println("Error parsing the key: " + current);
                continue;
            }
            
            try {
                RegistryKey key = getRegistryKey(current, RegistryKey.ACCESS_READ);
                if (key == null) continue;
                String name = current.substring(current.lastIndexOf("\\")+1);
                if (name.equals("*")) {
                    HashMap values = new HashMap();
                    for (Enumeration e = key.valueElements(); e.hasMoreElements(); ) {
                        String crt = (String) e.nextElement();
                        if (key.getStringValue(crt).trim().length() != 0) {
                            values.put(crt, encode(key.getStringValue(crt).trim()));
                        } else {
                            RegistryValue value = key.getValue(crt);
                            if (!value.getName().equals("")) {
                                values.put(value.getName(), encode(getRegistryValue(value)));
                            }
                        }
                    }
                    result.put(current, values);
                } else {
                    result.put(current, encode(getRegistryValue(key.getValue(name.trim()))));
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                result.put(current, null);
            }
        }
        return result;
    }
    
    public RegistryKey getRegistryKey(String keyPath, int access) {
        try {
            return getRootKey(keyPath).openSubKey(keyPath.substring(keyPath.indexOf("\\")+1, keyPath.lastIndexOf("\\")), access);
        } catch (Exception ex) {
            return null;
        }
    }
    
    public RegistryKey getRootKey(String keyName) {
        RegistryKey root = null;
        
        if (keyName.startsWith("HKEY_CLASSES_ROOT")) {
            root = Registry.HKEY_CLASSES_ROOT;
        } else if (keyName.startsWith("HKEY_CURRENT_CONFIG")) {
            root = Registry.HKEY_CURRENT_CONFIG;
        } else if (keyName.startsWith("HKEY_CURRENT_USER")) {
            root = Registry.HKEY_CURRENT_USER;
        } else if (keyName.startsWith("HKEY_DYN_DATA")) {
            root = Registry.HKEY_DYN_DATA;
        } else if (keyName.startsWith("HKEY_LOCAL_MACHINE")) {
            root = Registry.HKEY_LOCAL_MACHINE;
        } else if (keyName.startsWith("HKEY_PERFORMANCE_DATA")) {
            root = Registry.HKEY_PERFORMANCE_DATA;
        } else if (keyName.startsWith("HKEY_USERS")) {
            root = Registry.HKEY_USERS;
        }
        
        return root;
    }
    
    private RegistryKey searchForTCPKey(RegistryKey parent, String searchFor) {
        try {
            for (Enumeration e = parent.keyElements(); e.hasMoreElements(); ) {
                RegistryKey current = parent.openSubKey((String) e.nextElement());
                if (current.getName().equals(searchFor)) {
                    if (searchFor.equals("Parameters")) return searchForTCPKey(current, "Tcpip");
                    else return current;
                }
            }
        } catch (Exception ex) {}

        return null;
    }
    
    public HashMap getLocalNetworkSetting() {
        HashMap result = new HashMap();
        String pKey = "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings\\*";
        HashMap inetSet = getRegistryKeys(new String[] {pKey});
        HashMap proxy = (HashMap) inetSet.get(pKey);
        result.put("ProxyEnabled", (String) proxy.get("ProxyEnable"));
        if (decode((String) proxy.get("ProxyEnable")).equals("1")) {
            String proxyServer = (String) decode(proxy.get("ProxyServer"));
            result.put("ProxyIP", proxyServer.substring(0, proxyServer.indexOf(":")));
            result.put("ProxyPort", proxyServer.substring(proxyServer.indexOf(":")+1));
        }
        return result;
    }
    
    public String getRegistryValue(RegistryValue value) {
        switch (value.getType()) {
            case RegistryValue.REG_DWORD:
                return String.valueOf(((RegDWordValue) value).getData());
            case RegistryValue.REG_BINARY:
                return new String(((RegBinaryValue) value).getData()).trim();
            case RegistryValue.REG_SZ:
            case RegistryValue.REG_EXPAND_SZ:
                return ((RegStringValue) value).getData().trim();
            case RegistryValue.REG_MULTI_SZ:
                return BasicUtils.pack(((RegMultiStringValue) value).getData(), "|");
            default:
                return null;
        }
    }
    
    public void setRegistryValue(String keyPath, String newValue) {
        RegistryKey key = getRegistryKey(keyPath, ACCESS_ALL);
        setRegistryValue(key, keyPath.substring(keyPath.lastIndexOf("\\") + 1), newValue);
    }
    
    public void setRegistryValue(RegistryKey key, String attributeName, String newValue) {
        try {
            int attributeType = 0;
            try {
                RegistryValue attr = key.getValue(attributeName);
                attributeType = attr.getType();
            } catch (Exception ex) {
                // This must do like this thanks to a bug in registry value's get expand string value method.
                attributeType = RegistryValue.REG_EXPAND_SZ;
            }
            
            switch (attributeType) {
                case RegistryValue.REG_SZ:
                case RegistryValue.REG_EXPAND_SZ:
                    key.setValue(new RegStringValue(key, attributeName, newValue)); break;
                case RegistryValue.REG_DWORD:
                    key.setValue(new RegDWordValue(key, attributeName, RegistryValue.REG_DWORD, Integer.parseInt(newValue))); break;
                case RegistryValue.REG_BINARY:
                    key.setValue(new RegBinaryValue(key, attributeName, newValue.getBytes())); break;
                case RegistryValue.REG_MULTI_SZ:
                    key.setValue(new RegMultiStringValue(key, attributeName, BasicUtils.unpack(newValue, '|'))); break;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void setProxySettings() {
        HashMap network = RegistryUtils.getInstance().getLocalNetworkSetting();
        if (network.get("ProxyEnabled") != null && RegistryUtils.getInstance().decode(network.get("ProxyEnabled")).equals("1") &&
        		System.getProperty("http.proxyHost") == null && System.getProperty("http.proxyPort") == null) {
            if (network.get("ProxyIP") != null) System.setProperty("http.proxyHost", (String) network.get("ProxyIP"));
            if (network.get("ProxyPort") != null) System.setProperty("http.proxyPort", (String) network.get("ProxyPort"));
        }
    }
    
    public Object encode(Object obj) {
        return new BASE64Encoder().encodeBuffer(((String) obj).getBytes());
    }
    
    public Object decode(Object obj) {
        try {
            if (obj instanceof String) return new String(new BASE64Decoder().decodeBuffer((String) obj));
        } catch (Exception ex) {
            System.out.println("An error occured: " + ex.getMessage());
        }
        return obj;
    }
    
    public final int ACCESS_READ = RegistryKey.ACCESS_READ;
    public final int ACCESS_WRITE = RegistryKey.ACCESS_WRITE;
    public final int ACCESS_DEFAULT = RegistryKey.ACCESS_DEFAULT;
    public final int ACCESS_ALL = RegistryKey.ACCESS_ALL;
    public final int ACCESS_EXECUTE = RegistryKey.ACCESS_EXECUTE;
}
