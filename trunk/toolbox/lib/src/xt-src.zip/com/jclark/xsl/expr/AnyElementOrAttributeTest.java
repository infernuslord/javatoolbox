// $Id: AnyElementOrAttributeTest.java,v 1.1 2002/04/25 18:04:42 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

class AnyElementOrAttributeTest implements Pattern
{
    public boolean matches(Node node, ExprContext context)
    {
        switch (node.getType()) {
        case Node.ELEMENT:
        case Node.ATTRIBUTE:
            return true;
        }
        return false;
    }
}
