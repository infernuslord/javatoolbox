package org.outerj.pollo.xmleditor.model;

public class InvalidXmlException extends Exception
{
    public InvalidXmlException(String message)
    {
        super(message);
    }
}
