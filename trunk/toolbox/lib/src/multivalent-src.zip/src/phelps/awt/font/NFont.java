package phelps.awt.font;

import java.awt.Font;
import java.awt.font.*;
import java.awt.GraphicsEnvironment;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;



/**
	Superclass for <i>new fonts</i>.
	Advantages over {@link java.awt.Font}:
	<ul>
	<li><code>java.awt.Graphics</code> treats <code>java.awt.Font</code> as a special case graphical primitive,
	so subclasses aren't kosher.  This class takes the graphics canvas as a parameter to drawing,
	so we can have subclasses for not only Type 1 and TrueType, but also Type 3, Type 0, OpenType, and so on.
	<li>different AffineTransform per glyph, which is needed for PDF font substitution
	<li>more tenacious searching for font matching specification
	<li>glyph numbers <=> Unicode characters
	</ul>

	<ul>
	<li>{@link #createFont(String, String, float, int)} more tenacious version of {@link java.awt.Font#Font(String, int, int)}
	</ul>

	@version $Revision$ $Date$
*/

public abstract class NFont {
  // steal from java.awt.Font
  //measure string
  // ...
  public abstract Rectangle2D getStringBounds(String str, int beginIndex, int limit, FontRenderContext frc);
  public abstract float getSize2D();

  // from java.awt.Graphics{,2D}
  public abstract void drawString(Graphics2D g, String str, int x, int y);
  //public abstract void drawString(AttributedCharacterIterator iterator, int x, int y);
  public abstract void drawString(String s, float x, float y);
  //public abstract void drawString(AttributedCharacterIterator iterator, float x, float y);

}
