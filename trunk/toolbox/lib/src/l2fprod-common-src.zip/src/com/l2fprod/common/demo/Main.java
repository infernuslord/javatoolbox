/** ===================================================================
 *
 * L2FProd.com Common Components 0.1-dev License.
 *
 * Copyright (c) 2004 L2FProd.com.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by L2FProd.com
 *        (http://www.L2FProd.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "L2FProd.com Common Components", "l2fprod-common" and "L2FProd.com" must not
 *    be used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact info@L2FProd.com.
 *
 * 5. Products derived from this software may not be called "l2fprod-common"
 *    nor may "l2fprod-common" appear in their names without prior written
 *    permission of L2FProd.com.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL L2FPROD.COM OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package com.l2fprod.common.demo;

import com.l2fprod.common.swing.JButtonBar;
import com.l2fprod.common.swing.LookAndFeelTweaks;
import com.l2fprod.common.swing.StatusBar;
import com.l2fprod.common.swing.UIUtilities;
import com.l2fprod.common.swing.plaf.misc.IconPackagerButtonBarUI;
import com.l2fprod.common.util.ResourceManager;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

/**
 * Main. <br>Demonstration of L2FProd.com Common Components
 *  
 */
public class Main extends JFrame {

  static ResourceManager RESOURCE = ResourceManager.all(Main.class);

  private Component currentComponent;

  public Main() {
    super(RESOURCE.getString("Main.title"));
    buildUI();
  }

  private void show(Component component) {
    if (currentComponent != null) {
      getContentPane().remove(currentComponent);
    }
    getContentPane().add("Center", currentComponent = component);
    getContentPane().invalidate();
    getContentPane().validate();
    getContentPane().repaint();
  }

  private void addButton(
    String title,
    String iconUrl,
    final Component component,
    JButtonBar left,
    JButtonBar right,
    ButtonGroup group) {
    Action action =
      new AbstractAction(
        title,
        new ImageIcon(Main.class.getResource(iconUrl))) {
      public void actionPerformed(ActionEvent e) {
        show(component);
      }
    };

    JToggleButton buttonLeft = new JToggleButton(action);
    left.add(buttonLeft);
    
    group.add(buttonLeft);

    JToggleButton buttonRight = new JToggleButton(action);
    right.add(buttonRight);
    buttonRight.setModel(buttonLeft.getModel());

    if (group.getSelection() == null) {
      buttonLeft.setSelected(true);
      show(component);
    }
  }

  private void buildUI() {
    ((JComponent)getContentPane()).setBorder(LookAndFeelTweaks.PANEL_BORDER);

    getContentPane().setLayout(LookAndFeelTweaks.createBorderLayout());

    setDefaultCloseOperation(EXIT_ON_CLOSE);

    // We will have two button bar, one on the left and one on the right
    // both with different look and feels
    JButtonBar toolbarLeft = new JButtonBar(JButtonBar.VERTICAL);
    
    // use the IconPackager ui for the right pane
    JButtonBar toolbarRight = new JButtonBar(JButtonBar.VERTICAL);
    toolbarRight.setUI(new IconPackagerButtonBarUI());

    getContentPane().add("West", toolbarLeft);
    getContentPane().add("East", toolbarRight);

    ButtonGroup group = new ButtonGroup();

    addButton(
      RESOURCE.getString("Main.welcome"),
      "icons/welcome32x32.png",
      new WelcomePage(RESOURCE.getString("Main.welcome")),
      toolbarLeft,
      toolbarRight,
      group);

    addButton(
      RESOURCE.getString("Main.sheet1"),
      "icons/propertysheet32x32.png",
      new PropertySheetPage(RESOURCE.getString("Main.sheet1")),
      toolbarLeft,
      toolbarRight,
      group);

    addButton(
      RESOURCE.getString("Main.sheet2"),
      "icons/propertysheet32x32.png",
      new PropertySheetPage2(RESOURCE.getString("Main.sheet2")),
      toolbarLeft,
      toolbarRight,
      group);

    addButton(
      RESOURCE.getString("Main.fonts"),
      "icons/fonts32x32.png",
      new FontChooserPage(RESOURCE.getString("Main.fonts")),
      toolbarLeft,
      toolbarRight,
      group);

    addButton(
      RESOURCE.getString("Main.folder"),
      "icons/folder32x32.png",
      new FolderPage(RESOURCE.getString("Main.folder")),
      toolbarLeft,
      toolbarRight,
      group);
    
    // a simple menubar
    JMenuBar menubar = new JMenuBar();
    JMenu file = new JMenu(RESOURCE.getString("file.text"));
    file.setMnemonic(RESOURCE.getChar("file.mnemonic"));
    JMenuItem exit = new JMenuItem(RESOURCE.getString("exit.text"));
    exit.setMnemonic(RESOURCE.getChar("exit.mnemonic"));
    exit.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        System.exit(0);
      }
    });
    file.add(exit);
    menubar.add(file);
    setJMenuBar(menubar);

    // a status bar with two zones, the message zone and a progress
    StatusBar statusbar = new StatusBar();
    statusbar.addZone("message", new JLabel(" "), "*");
    statusbar.addZone("progress", new JProgressBar(), "150");
    getContentPane().add("South", statusbar);

    // set a text in the message zone
    ((JLabel)statusbar.getZone("message")).setText(RESOURCE.getString("ready"));
    // put the progress in indeterminate state
    ((JProgressBar)statusbar.getZone("progress")).setIndeterminate(true);

    setSize(640, 480);
    UIUtilities.centerOnScreen(this);
  }

  public static void main(String[] args) throws Exception {
    
    try {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
      //UIManager.setLookAndFeel("com.digitprop.tonic.TonicLookAndFeel");
    } catch (Exception e) {
    }

    LookAndFeelTweaks.tweak();

    Main main = new Main();
    main.show();
  }

}
