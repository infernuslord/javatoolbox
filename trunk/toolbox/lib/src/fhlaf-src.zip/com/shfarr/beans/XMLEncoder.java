/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.beans;

import java.io.*;
import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.SortedMap;
import java.util.SortedSet;

import sun.misc.BASE64Encoder;

public class XMLEncoder implements ObjectEncoder{
    protected static String encoding = "UTF-8";
    protected PrintWriter output = null;
    protected int currentIndent;
    protected int depth = -1;
    protected ObjectEncoder encoder = null;
    protected int indentIncrement = 6;
    protected boolean breakingLines = true;

    /**
     * XMLEncoder constructor comment.
     */
    public XMLEncoder(OutputStream os) throws IOException {
        this(os, null);
    }

    /**
     * XMLEncoder constructor comment.
     */
    public XMLEncoder(OutputStream os, ObjectEncoder encoder) throws IOException {
        output = new PrintWriter(os);
        this.encoder = encoder;
    }

    public void close(){
        output.close();
    }

    protected String indent(String s){
        byte[] ind = new byte[currentIndent];
        for(int i = 0; i < ind.length; i++) ind[i] = (byte)32;

        return new String(ind) + s + (isBreakingLines() ? "\r\n" : "");
    }

    protected String quote(String s){
        return "\"" + s + "\"";
    }
    
    public String toString(Object o){
        if(o instanceof Number || o instanceof Character || o instanceof String || o instanceof Boolean) return o.toString();
        else if(o instanceof byte[]) return "\r\n" + new BASE64Encoder().encode((byte[])o);

        return null;
    }
    
    protected Class clearType(Class type){
        while(type.isArray()) type = type.getComponentType();
        return type;
    }
    
    protected String getExtentAttribute(Object o){
        String extent = null;
        
        while(o != null && o.getClass().isArray()){
            int len = Array.getLength(o); 
            
            if(extent == null) extent = "" +len;
            else extent += "x" +len;  
            
            if(len > 0) o = Array.get(o, 0);
            else break;   
        }
        
        return extent;
    }
    
    public void writeObject(Object obj) throws IOException{
        depth ++;
        currentIndent += indentIncrement;

        // ----- init -------------

        Class type = obj instanceof PropertyHandler ? ((PropertyHandler)obj).getProperty().getType() : obj.getClass();
//        System.out.println("---=( shfarr )=->  : " + obj.toString());
        int extent = !(obj instanceof PropertyHandler) && type.isArray() ? Array.getLength(obj) : -1;

        String typeValue = BeanUtils.getName(clearType(type));
        String packageAttribute = " package=" + quote(BeanUtils.getPackage(clearType(type)));

        String typeAttribute = " type=" + quote(clearType(type).getName() + (type.isArray() ? "[]" : ""));
        String extentAttribute = type.isArray() ? " extent=" +quote(getExtentAttribute(obj)) : "";
        String qName = obj instanceof PropertyHandler ? BeanUtils.packPropertyName(((PropertyHandler)obj).getProperty().getName()) : typeValue;

        if(depth == 0){
            currentIndent -= indentIncrement;
            output.print(indent("<?xml version=" + quote("1.0") + " encoding=" + quote(encoding) + "?>"));
        }

        // ----- process -----------

        String objectValue = getEncoder().toString(obj);

        if(objectValue != null){
            // if the object was encoded by the encoder
            write(indent("<" + qName + packageAttribute + extentAttribute + ">" + objectValue + "</"  +qName + ">"));
        }
        else if(obj instanceof PropertyHandler){
            // if the object is a property handler
            Object o = ((PropertyHandler)obj).getValue();
            String sv = getEncoder().toString(o);
            String enclosedTypeAttribute = o == null ? "" : " enclosed=" + quote((o.getClass().isArray() ? o.getClass().getComponentType() : o.getClass()).getName() + (o.getClass().isArray() ? "[]" : ""));
            
            if(o == null) write(indent("<" + qName + typeAttribute + enclosedTypeAttribute + ">null</"  +qName + ">"));
            else if(sv != null) write(indent("<" + qName + typeAttribute + enclosedTypeAttribute + ">" + sv + "</"  +qName + ">"));
            else{
                write(indent("<" + qName + typeAttribute+ ">"));
                writeObject(o);
                write(indent("</"  +qName + ">"));
            }
        }
        else{
            // any other case we consider it as an object

            String comparatorAttribute = "";
            if(obj instanceof SortedMap && ((SortedMap)obj).comparator() != null) comparatorAttribute = " comparator=" + quote(((SortedMap)obj).comparator().getClass().getName());
            if(obj instanceof SortedSet && ((SortedSet)obj).comparator() != null) comparatorAttribute = " comparator=" + quote(((SortedSet)obj).comparator().getClass().getName());
            
            write(indent("<" + qName + packageAttribute + extentAttribute + comparatorAttribute + ">"));

            if(extent != -1){
                // if the object is an array
                for(int i = 0; i < extent; i++){
                    if(Array.get(obj, i) == null) {
                        currentIndent += indentIncrement;
                        write(indent("<Void package=\"java.lang\">null</Void>"));
                        //write(indent("<" + qName + packageAttribute + extentAttribute + ">null</"  +qName + ">"));
                        currentIndent -= indentIncrement;
                    }
                    else writeObject(Array.get(obj, i));
                }
            }
            else if(obj instanceof Collection){
                // if the object is a collection
                for(Iterator iter = ((Collection)obj).iterator(); iter.hasNext(); ){
                    Object o = iter.next();
                    
                    if(o == null){
                        currentIndent += indentIncrement;
                        write(indent("<Void package=\"java.lang\">null</Void>"));
                        currentIndent -= indentIncrement;
                    }
                    else writeObject(o);
                }
            }
            else if(obj instanceof Map) {
                // if the object is a map (key, value) pairs
                for(Iterator iter = ((Map)obj).keySet().iterator(); iter.hasNext(); ){
                    Object key = iter.next();
                    writeObject(key);
                    
                    if(((Map)obj).get(key) == null) {
                        currentIndent += indentIncrement;
                        write(indent("<Void package=\"java.lang\" >null</Void>"));
                        currentIndent -= indentIncrement;
                    }
                    else writeObject(((Map)obj).get(key));
                }
            }
            else{
                // otherwise we cosider it as a bean read it's properties
                // and applay the method recursively
                PropertyHandler[] handlers = BeanUtils.getHandlers(obj);
                for(int i = 0; i < handlers.length; i++) if(handlers[i].getProperty().isReadWrite()) writeObject(handlers[i]);
            } 
        
            write(indent("</"  +qName + ">"));
        }
        
        // ----- finalize -------------

        if(depth == 0){
            output.flush();
            output.close();
        }

        currentIndent -= indentIncrement;
        depth --;
    }
    
    protected void write(String s){
//        System.out.print(s);
        output.write(s);
    }
    
    public ObjectEncoder getEncoder() {
        return encoder != null ? encoder : this;
    }

    public void setEncoder(ObjectEncoder encoder) {
        this.encoder = encoder;
    }
    
    public int getIndentIncrement() {
        return indentIncrement;
    }

    public void setIndentIncrement(int indentIncrement) {
        this.indentIncrement = indentIncrement;
    }

    public boolean isBreakingLines() {
        return breakingLines;
    }

    public void setBreakingLines(boolean breakingLines) {
        this.breakingLines = breakingLines;
    }
}
