// $Id: ExtensionHandler.java,v 1.1 2002/04/25 18:17:53 bill Exp $

package com.jclark.xsl.tr;

import java.net.URL;

import com.jclark.xsl.om.XSLException;
import com.jclark.xsl.expr.ExtensionContext;

/**
 * for extension functions -- i think
 */
public interface ExtensionHandler
{

    /**
     *
     */
    ExtensionContext createContext(String namespace) throws XSLException;

    /**
     *
     */
    Object wrapResultFragmentVariant(ResultFragmentVariant frag) 
        throws XSLException;
}
