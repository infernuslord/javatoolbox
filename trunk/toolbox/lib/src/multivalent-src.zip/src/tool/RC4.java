package tool;

import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Iterator;

import phelps.io.FileList;



/**
	Encrypts/decrypts files according to password.
	Processing once encrypts, and since RC4 is symmetric processing again decrypts.

	@version $Revision: 1.2 $ $Date: 2003/08/28 20:35:44 $
*/
public class RC4 {
  public static final String USAGE = "java tool.RC4 <password> <file-or-directory...>";
  public static final String VERSION = "1.1 of $Date: 2003/08/28 20:35:44 $";

  private String password_;
  private boolean fverbose_;

  public RC4() {
	defaults();
  }

  public void defaults() {
	password_ = null;

	fverbose_ = false;
  }


  private int commandLine(String[] argv) {
	int argi=0, argc=argv.length;

	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.startsWith("-pass"/*word*/)) password_ = argv[++argi];	// accept this way too

		else if (arg.startsWith("-verb"/*ose*/)) fverbose_ = true;
		else if (arg.startsWith("-q"/*uiet*/)) {}
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.equals("-help")) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	if (argi == argc) { System.err.println(USAGE); System.exit(0); }

	if (password_==null) password_ =  argv[++argi];

	return argi;
  }

  public void rc4(File file) throws IOException {
	phelps.crypto.RC4 rc4 = new phelps.crypto.RC4(password_.getBytes(/*"UTF-8"*/));  // explicit encoding so always the same
	File dir = file.getParentFile();
	File tmp = file.createTempFile("crypt", "tmp", dir);

	FileInputStream fis = new FileInputStream(file);
	FileOutputStream fos = new FileOutputStream(tmp);

	// use PDF crypt filter?
	byte[] buf = new byte[8*1024];
	for (int len; (len = fis.read(buf)) >= 0; ) {
		rc4.encrypt(buf, 0, len);
		fos.write(buf, 0, len);
	}

	fos.close();
	fis.close();

	file.delete();
	boolean ok = tmp.renameTo(file);
	if (!ok) System.err.println("couldn't rename "+tmp+" to "+file);
  }


  public static void main(String[] argv) {
	int argc = argv.length;
	if (argc < 2) { System.err.println(USAGE); System.exit(1); }

	RC4 rc4 = new RC4();
	int argi = rc4.commandLine(argv);
	for (Iterator<File> i = new FileList(argv, argi, null).iterator(); i.hasNext(); ) {
		File f = i.next();
		// if ("Multivalent.jar") continue;
		if (!f.canWrite()) { System.out.println("can't write "+f); continue; }
		try {
			rc4.rc4(f);
		} catch (IOException ioe) {
			System.err.println(f+": "+ioe);
			// clean up
			// ...
		}
	}
  }
}
