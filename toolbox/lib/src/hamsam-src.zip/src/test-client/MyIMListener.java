
import java.util.*;
import hamsam.api.*;
import hamsam.protocol.*;

public class MyIMListener implements IMListener //extends IMAdapter
{
	private TestClient client;

	public MyIMListener(TestClient client)
	{
		this.client = client;
	}

	public void connecting(Protocol protocol)
	{
		System.out.println("Connecting...");
	}

	public void connected(Protocol protocol)
	{
		System.out.println("Connected");
	}

	public void connectFailed(Protocol protocol, String message)
	{
		System.out.println("Connect failed: " + message);
	}

	public void disconnected(Protocol protocol)
	{
		System.out.println("Disconnected: " + Thread.currentThread().activeCount());
	}

	public void buddyListReceived(Protocol protocol, Buddy[] buddies)
	{
		System.out.println("Buddy list received: ");
		for(int i = 0; i < buddies.length; i++)
			System.out.println(buddies[i].getUsername());
	}

	public void ignoreListReceived(Protocol protocol, Buddy[] buddies)
	{
		System.out.println("Ignore list received: ");
		for(int i = 0; i < buddies.length; i++)
			System.out.println(buddies[i].getUsername());
	}

	public void protocolMessageReceived(Protocol protocol, Message msg)
	{
		printMessage("Protocol Message: ", msg);
	}

	public void instantMessageReceived(Buddy buddy, Message msg)
	{
		printMessage(buddy.getUsername() + ": ", msg);
	}

	public void offlineMessageReceived(Buddy buddy, Date time, Message msg)
	{
		printMessage(buddy.getUsername() + " [offline @ " + time + "] : ", msg);
	}

	public void mailNotificationReceived(Protocol protocol, int count, String[] from, String[] subject)
	{
		if(count == -1)
			System.out.println("You have new mail");
		else
			System.out.println("You have " + count + " new mail(s).");

		if(from != null && subject != null)
		{
			for(int i = 0; i < from.length || i < subject.length; i++)
				System.out.println("\t(" + (i + 1) + ") from: " + from[i] + " subject: " + subject[i]);
		}
	}

	public void conferenceInvitationAccepted(Conference conf, Buddy buddy)
	{
		System.out.println(buddy.getUsername() + " joined the conference: " + conf);
	}

	public void conferenceInvitationDeclined(Conference conf, Buddy buddy, String message)
	{
		System.out.println(buddy.getUsername() + " declined to join the conference: " + conf + " with the message: " + message);
	}

	public Response conferenceInvitationReceived(Conference conf, String message)
	{
		client.setConference(conf);

		Buddy[] parts = conf.getParticipants();
		System.out.print("Conference invitation: ");

		for(int i = 0; i < parts.length; i++)
			System.out.print(parts[i].getUsername() + " ");
		
		System.out.println();

		return new Response();
	}

	public void conferenceMessageReceived(Conference conf, Buddy buddy, Message message)
	{
		System.out.print(conf);
		printMessage(" conference: " + buddy.getUsername() + ": ", message);
	}

	public void buddyStatusChanged(Buddy buddy)
	{
		System.out.println("Status of " + buddy.getUsername() + " is now " + buddy.getStatus());
	}

	public void conferenceParticipantLeft(Conference conf, Buddy buddy)
	{
		System.out.println(buddy.getUsername() + " left the conference: " + conf);
	}

	public void conferenceParticipantJoined(Conference conf, Buddy buddy)
	{
		System.out.println(buddy.getUsername() + " joined the conference: " + conf);
	}

	public void typingStarted(Buddy buddy)
	{
		System.out.println(buddy.getUsername() + " is typing");
	}

	public void typingStopped(Buddy buddy)
	{
		System.out.println(buddy.getUsername() + " stopped typing");
	}

	public void buddyAdded(Buddy buddy)
	{
		System.out.println(buddy.getUsername() + " is added to the buddy list");
	}

	public void buddyAddRejected(Buddy buddy, String reasonMessage)
	{
		System.out.println(buddy.getUsername() + " rejected to be a buddy: " + reasonMessage);
	}

	public void buddyAddFailed(Buddy buddy, String reasonMessage)
	{
		System.out.println("Attempt to add " + buddy.getUsername() + " failed: " + reasonMessage);
	}

	public Response buddyAddRequest(Buddy buddy, Buddy myself, String message)
	{
		System.out.println(buddy.getUsername() + " is trying to add " + myself.getUsername() + " to his buddy list: " + message);
		return new Response();
	}

	public void buddyDeleted(Buddy buddy)
	{
		System.out.println(buddy.getUsername() + " is deleted from the buddy list");
	}

	public void buddyDeleteFailed(Buddy buddy, String reasonMessage)
	{
		System.out.println("Attempt to delete " + buddy.getUsername() + " failed: " + reasonMessage);
	}

	public void buddyIgnored(Buddy buddy)
	{
		System.out.println(buddy.getUsername() + " is ignored now");
	}

	public void buddyIgnoreFailed(Buddy buddy, String reasonMessage)
	{
		System.out.println("Attempt to ignore " + buddy.getUsername() + " failed: " + reasonMessage);
	}

	public void buddyUnignored(Buddy buddy)
	{
		System.out.println(buddy.getUsername() + " is unignored now");
	}

	public void buddyUnignoreFailed(Buddy buddy, String reasonMessage)
	{
		System.out.println("Attempt to unignore " + buddy.getUsername() + " failed: " + reasonMessage);
	}

	public void conferenceClosed(Conference conf)
	{
		System.out.println("Conference closed: " + conf);
	}

	private void printMessage(String header, Message msg)
	{
		System.out.print(header);

		Enumeration e = msg.getComponents();
		while(e.hasMoreElements())
		{
			MessageComponent comp = (MessageComponent) e.nextElement();
			if(comp instanceof TextComponent)
			{
				TextComponent txt = (TextComponent) comp;
				System.out.print("<text>" + new String(txt.getSequence()));
			}
			else if(comp instanceof SmileyComponent)
			{
				SmileyComponent sml = (SmileyComponent) comp;
				System.out.print("<smiley>" + sml.getName());
			}
			else if(comp instanceof URLComponent)
			{
				URLComponent url = (URLComponent) comp;
				System.out.print("<url>" + url.getLinkText());
			}
			else
				System.out.println(comp);
		}

		System.out.println();
	}
} 
