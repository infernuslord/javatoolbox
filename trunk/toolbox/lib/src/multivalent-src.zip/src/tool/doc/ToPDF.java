package tool.doc;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.MalformedURLException;

import multivalent.*;
import multivalent.node.FixedI;
import multivalent.node.LeafText;

import phelps.io.InputStreamCached;
import phelps.lang.Integers;



/**
	Convert any format to PDF.

	@version $Revision$ $Date$
*/
public class ToPDF {
  static final boolean DEBUG = true;

  public static final String USAGE = "java  tool.doc.ToPDF [-page <range>] [-format <img>] <file...>";
  public static final String VERSION = "0.1";

  public static void main(String[] argv) throws IOException {
  }
}
