package phelps.io;

import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.List;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.ArrayList;
import java.util.Arrays;
import java.lang.ref.SoftReference;
import java.io.File;
import java.io.RandomAccessFile;
import java.io.IOException;

//import phelps.io.BufferedRandomAccessFile; -- shouldn't have many disk accesses so shouldn't make much difference



  // Rec and Node as (1) struct-like classes as they are now, (2) inner classes with xxxRaw, (3) non-nested classes DiskHashDataStore and DiskHashKeyStore ?
/**
	Store (key, data-offset) pairs.

	Keys are saved in a B-tree - like data structure, which can access very large key sets with minimal disk access and memory use.
	Keys are Unicode strings of any length, provided that three can fit into blocksize.
	The data associated with a key is a <code>long</code> (8 bytes), which is used by {@link DiskHash} as an offset into a {@link DataStore}.
	Nodes of the B-tree are read on demand and cached in memory in {@link java.lang.ref.SoftReference}s.
	Nodes written to are kept in memory and not written to disk until a {@link #flush()} or a {@link #close()}.

	@see DiskHash
	@see DataStore
*/
public class KeyStore {
  static final boolean DEBUG = true;

  /** Data format version. */
  public static final int VERSION = 1;

  static final String FREE_SFX = ".free";
  static final int INT_LENGTH = 4, LONG_LENGTH = 8;
  static final int HEADER_LENGTH = 1*1024/*room for expansion -- set to 8K/16K/32K to match disk blocksize?*/, HEADER_USED = INT_LENGTH * 3,
	NODE_OVERHEAD = 2/*keys in node*/ + INT_LENGTH/*one more child than key*/,
	ENTRY_OVERHEAD = LONG_LENGTH/*data*/ + INT_LENGTH/*child*/;   // maybe just take first blocksize bytes
  static {
	assert HEADER_LENGTH >= HEADER_USED;
  }

  class Node {
	int index;
	int bytelen = NODE_OVERHEAD;    // for count of number of keys in node (max 65K)

	String[] key;
	long[] data;    // offsets into data store
	int[] child; // indexes of children < and >

	/**
		Set bytelen to <0 to have it computed.
	*/
	Node(int index, String[] key, long[] data, int[] child, int bytelen) { this.index = index; set(key, data, child, bytelen); }
	Node(int index) { this(index, new String[0], new long[0], new int[0+1], NODE_OVERHEAD); }
	Node(int index, Node node) { this(index, node.key, node.data, node.child, node.bytelen); }

	public void set(String[] key, long[] data, int[] child, int bytelen) {
		assert key!=null && data!=null && child!=null && key.length==data.length && key.length==child.length-1;
		this.child=child;
		this.key=key; this.data=data;
		if (bytelen>=NODE_OVERHEAD) this.bytelen=bytelen; else computeBytelen();
	}

	/** Return number of (keys, data) pairs in node.  Note that the number of child pointers is size()+1. */
	public int size() { return key.length; }

	public int computeBytelen() {
		int bytelen = NODE_OVERHEAD + size() * ENTRY_OVERHEAD;
//System.out.print("size="+size()+", len w/o key content = "+NODE_OVERHEAD+" + "+size()+" * "+ENTRY_OVERHEAD+" = "+bytelen);
		for (int i=0,imax=size(); i<imax; i++) bytelen += countUTF(key[i]);
//System.out.println(", w/ = "+bytelen);
		this.bytelen = bytelen;
		return bytelen;
	}

	//Node read(RandomAccessFile raf) {}
	//void write(RandomAccessFile raf) {}

/*
	public int hashCode() { return index; }
	public boolean equals(Object obj) {
		if (this==obj) return true; else if (!(obj instanceof Node)) return false;
		return index == ((Node)obj).index;
	}
*/
	public String toString() { return "#"+index+" "+size()/*+"/"+dirty*/+"/"+bytelen; }

	public void dump() { /*if (DEBUG)*/ try {
		int cnt = size();
		System.out.print("#"+index+" "+cnt/*+"/"+dirty*/+"/"+bytelen+": ");
		if (cnt==0) { System.out.println(); return; }
		List<Node> children = new ArrayList<Node>(10);
		for (int i=0; i<cnt; i++) {
			System.out.print(" "+child[i]+" "+key[i]+"/"+data[i]);
			if (child[i]>0) {
				Node left = readNode(child[i]);
				assert child[i] == left.index: child[i]+" vs "+left.index;
				children.add(left);
			}
		}
		if (child[cnt]>0) children.add(readNode(child[cnt]));
		System.out.println(" "+child[cnt]);

		for (int i=0,imax=children.size(); i<imax; i++) {
			//System.out.println("child "+((Node)children.get(i)).index);
			children.get(i).dump();
		}
	} catch (Exception e) { e.printStackTrace(); System.err.println(e); }
	}
  }


  class KeyIterator implements Iterator<String> {
	List<Object> stack_ = new ArrayList<Object>(10);    // node/index pairs

	String lastkey_ = null;
	String endrange_ = null;
	Node node_; int index_;

	KeyIterator() /*throws IOException*/ {
		Node n=root_;
		while (n.child[0] > 0) {
			stack_.add(n); stack_.add(new Integer(0));
			try { n = readNode(n.child[0]); } catch (IOException kill) { n=null; break; }   // invariant: have traversed leftmost child
		}
		node_ = n; index_ = 0;
	}

	KeyIterator(List<Object> stack, String endrange) /*throws IOException*/ {
		index_ = ((Integer)stack.remove(stack.size()-1)).intValue();
		node_ = (Node)stack.remove(stack.size()-1);

		stack_ = stack;
		endrange_ = endrange;
	}

	public boolean hasNext() { return node_ != null; }

	public String next() throws NoSuchElementException/*, IOException -- can't throw and still implement interface*/ {
		if (node_ == null) throw new NoSuchElementException();

		lastkey_ = node_.key[index_];   // last <- current

		// traversing (key n, child n+1 -- right of key n), (key n+1, child n+2), ... in current node.  Already traversed down left, so going key, its right child, ....
		index_++;

		// descend down children, if any
		while (node_.child[index_] > 0) {
//System.out.println("  \\"+node_.index+"/"+index_+"="+node_.child[index_]+"/  ");
			stack_.add(node_); stack_.add(new Integer(index_));
			try { node_ = readNode(node_.child[index_]); } catch (IOException kill) { node_ = null; }
			index_ = 0;   // leftmost with child
		}

		// exhausted current node, so climb up stack
		while (index_ == node_.size() && stack_.size()>0) {
			index_ = ((Integer)stack_.remove(stack_.size()-1)).intValue();
			node_ = (Node)stack_.remove(stack_.size()-1);
//System.out.println("  /"+node_.index+"/"+index_+"\\  ");
		}

		// termination
		if (index_ == node_.size() || lastkey_.equals(endrange_)) node_ = null;

		return lastkey_;
	}

	/** Not supported. */
	public void remove() throws UnsupportedOperationException, IllegalStateException/*throws IOException -- can't*/ {
		//throw new UnsupportedOperationException();
		if (lastkey_ == null) throw new IllegalStateException();

		boolean fsame = node_!=null && Arrays.binarySearch(node_.key, lastkey_)>=0;   // if key removed on same node as current, adjust index

		try {
			KeyStore.this.remove(lastkey_);
			lastkey_ = null;    // can only remove once
			if (fsame) index_--;
		} catch (IOException cant) {}
	}
  }



  /** Root node always cached in memory and always stored in block 0. */
  Node root_;
  String filename_;
  int blockSize_;
  int maxrec_;
  Map<Integer,SoftReference<Node>> cache_ = new HashMap<Integer,SoftReference<Node>>(100);
  Set<Node> dirty_ = new java.util.HashSet<Node>(10);
  /** List of empty node numbers, which we can recycle. */
  List<Integer> recycle_;

  /*Buffered*/RandomAccessFile raf_;   // first get working on non-Buffered


  public KeyStore(String filename) throws IOException { this(filename, 8*1024); }

  /**
	@param blocksize  size of tree nodes, mimimum of 1K bytes.  If KeyStore already exists, the passed value is ignored and the value is retrieved from its storage on disk.
  */
  public KeyStore(String filename, int blocksize) throws IOException {
	filename_ = filename;
	raf_ = new /*Buffered*/RandomAccessFile(filename, "rw");

	if (raf_!=null && raf_.length() > 0) {   // read old state
		raf_.seek(0);
		int v = raf_.readInt();
		assert v == VERSION: v+" != "+VERSION;  // if every have different versions, maybe support more than one
		blockSize_ = raf_.readInt();
		maxrec_ = raf_.readInt();
		assert HEADER_USED == raf_.getFilePointer(): HEADER_USED+" vs "+raf_.getFilePointer();

		recycle_ = null;    // read on demand, i.e., when need to insert
		root_ = readNode(0);
//System.out.println("old root = "+root_);

	} else {    // init new
		blockSize_ = Math.max(blocksize, 1*1024);    // and make muliple of 1K?
		maxrec_ = 0;
		root_ = new Node(maxrec_++);
		dirty_.add(root_);
		recycle_ = new ArrayList<Integer>(10);
	}
  }

  /** Return data offset for given key.  If no such key, return DiskHash.NO_RECORD. */
  public long get(String key) throws IOException {
	List<Object> stack = find(key);
	int index = ((Integer)stack.get(stack.size()-1)).intValue();

	return (index>=0? ((Node)stack.get(stack.size()-2)).data[index]: DiskHash.NO_RECORD);
  }

  /** Replace data offset for <var>key</var>.  Key must already exist. */
  public void set(String key, long dataoffset) throws IOException {
	List<Object> stack = find(key);
	int index = ((Integer)stack.get(stack.size()-1)).intValue();
	assert index>=0;  //if (index<0) return;

	Node node = ((Node)stack.get(stack.size()-2));
if (DEBUG) System.out.println("setKey "+key+"/"+dataoffset+" @ "+index+" in "+node);
	if (node.data[index] != dataoffset) {
		node.data[index] = dataoffset;
		dirty_.add(node);
	}
  }

  /** Add key of given name and data offset to B-tree.  Key must not already exist. */
  public synchronized void insert(String key, long dataoffset) throws IOException {
	List<Object> stack = find(key);

	// flip index to positive
	int index = ((Integer)stack.remove(stack.size()-1)).intValue();
	assert index<0: index+" for "+key+"/"+dataoffset; //if (index>=0) return;
	index = -index - 1;
	stack.add(new Integer(index));

	//Node node = ((Node)stack.get(stack.size()-2));
	insert(key, dataoffset, 0,0, stack);    // inserts always start at leaves
  }

  void insert(String key, long dataoffset, int leftptr, int rightptr, List<Object> stack) {
	int index = ((Integer)stack.remove(stack.size()-1)).intValue();
	assert index>=0;
	Node node = ((Node)stack.remove(stack.size()-1));
//System.out.println("insertKey "+key+"/"+dataoffset+" @ "+index+", l/r="+leftptr+"/"+rightptr);//+" in "+node);

	// insert key into node
	int cnt = node.size() + 1;
//System.out.println(cnt+": left=0..+"+index+"|"+index+"|"+", right="+(index+1)+"+"+(cnt-1-index));
	//node.insert(index, key, dataoffset, leftptr, rightptr);
	String[] newkey=new String[cnt]; System.arraycopy(node.key,0, newkey,0, index); System.arraycopy(node.key,index, newkey,index+1, cnt-1-index); node.key=newkey;
	long[] newdata = new long[cnt]; System.arraycopy(node.data,0, newdata,0, index); System.arraycopy(node.data,index, newdata,index+1, cnt-1-index); node.data=newdata;
	int[] newchild = new int[cnt+1]; System.arraycopy(node.child,0, newchild,0, index); System.arraycopy(node.child,index+1, newchild,index+1 +1, cnt-1-index); node.child=newchild;
	node.key[index]=key; node.data[index]=dataoffset; node.child[index]=leftptr; node.child[index+1]=rightptr;
	node.bytelen += (countUTF(key) + ENTRY_OVERHEAD);
	dirty_.add(node);

	// need to split?
	if (node.bytelen > blockSize_) {
		int splitat = cnt/2;
if (DEBUG) System.out.println("split at "+splitat+" with "+cnt+" / "+node.bytelen);

		// split: left, right, and middle pieces
		String middlekey = node.key[splitat]; long middledata=node.data[splitat]; //int middlechildren=node.children[splitat]; => left and right

		// right
		int rcnt = cnt - splitat - 1;   // splitat+1 .. cnt
if (DEBUG) System.out.println("  right "+(splitat+1)+"+"+rcnt);
		newkey=new String[rcnt]; System.arraycopy(node.key,splitat+1, newkey,0, rcnt);
		newdata = new long[rcnt]; System.arraycopy(node.data,splitat+1, newdata,0, rcnt);
		newchild = new int[rcnt+1]; System.arraycopy(node.child,splitat+1+1, newchild,0+1, rcnt); newchild[0]=0;

		Node newright = new Node(getRecNum(), newkey, newdata, newchild, -1);
		dirty_.add(newright);
		cache_.put(new Integer(newright.index), new SoftReference<Node>(newright));


		// left
		int lcnt = splitat; // 0..splitat-1
if (DEBUG) System.out.println("  left 0"+"+"+lcnt);
		newkey=new String[lcnt]; System.arraycopy(node.key,0, newkey,0, lcnt); node.key=newkey;
		newdata = new long[lcnt]; System.arraycopy(node.data,0, newdata,0, lcnt); node.data=newdata;
		newchild = new int[lcnt+1]; System.arraycopy(node.child,0, newchild,0, lcnt); newchild[lcnt]=0; node.child=newchild;
		node.computeBytelen();
		// already: in cache, dirty


		// middle - insert onto parent, recursively
		if (stack.size()>0) {
if (DEBUG) System.out.println("splitting internal");
			insert(middlekey, middledata, node.index/*same as before*/,newright.index, stack);
//if (DEBUG) root_.dump();
//System.exit(0);

		} else {    // split root
if (DEBUG) System.out.println("splitting root "+node.index+"/"+newright.index);
			assert node.index==0 && node==root_: node.index;

			// copy old root to new node, and transform old to new root
			// This way root is always at 0, so never a child so can use 0 as no-child mark; and same instance, so no trouble with HashMap / Set.
			Node newnode = new Node(getRecNum(), node);
//System.out.println("old root => #"+newnode.index);
			cache_.put(new Integer(newnode.index), new SoftReference<Node>(newnode));
			dirty_.add(newnode);

			newkey=new String[1]; newkey[0]=middlekey;
			newdata=new long[1]; newdata[0]=middledata;
			newchild=new int[2]; newchild[0]=newnode.index; newchild[1]=newright.index;
if (DEBUG) System.out.println("   "+newchild[0]+" "+middlekey+"/"+middledata+"  "+newchild[1]);
			node.set(newkey, newdata, newchild, -1);
			// already dirty

//System.out.println("indexes l/r/root: "+node.index+"/"+newright.index+"/"+root.index+"/"+keyCount_);
//System.out.println("indexes l/r/root: "+node.index+"/"+newright.index+"/"+root.index+"/"+keyCount_);
if (DEBUG) root_.dump();
		}
	}
  }

  public synchronized void remove(String key) throws IOException {  // data removed separately
	List<Object> stack = find(key);
	int index = ((Integer)stack.remove(stack.size()-1)).intValue();
	assert index>=0;
	Node node = ((Node)stack.remove(stack.size()-1));
//System.out.println("remove "+key+" from "+node+"/"+index);
	dirty_.add(node);

	int left=node.child[index], right=node.child[index+1];
	Node p; int pi;

	/*if (node.size()==1) {   // leaving empty node: replace with a child
	} else*/ if (left > 0) { // replace key with rightmost leaf from left subtree
		Node ln = readNode(left); p=node; pi=index;
		while ((right = ln.child[ln.size()]) > 0) { p=ln; pi=ln.size();  ln = readNode(ln.child[right]); }
		String newkey = ln.key[ln.size()-1]; node.key[index] = newkey; /*node.child same*/ node.data[index] = ln.data[ln.size()-1];     // replace
		node.bytelen += (countUTF(newkey) - countUTF(key));
		key=newkey; node=ln; index=ln.size()-1;

	} else if (right > 0) { // replace key with leftmost leaf from right subtree
		Node rn = readNode(right); p=node; pi=index+1;
		while ((left = rn.child[0]) > 0) { p=rn; pi=0;  rn = readNode(rn.child[left]); }
		String newkey=rn.key[0]; node.key[index] = newkey; /*node.child same*/ node.data[index] = rn.data[0];     // replace
		node.bytelen += (countUTF(newkey) - countUTF(key));
		key=newkey; node=rn; index=0;

	} else {    // leaf -- simply remove key from node
		//key=key; node=node; index=index;
		pi = ((Integer)stack.remove(stack.size()-1)).intValue();
		p = ((Node)stack.remove(stack.size()-1));
	}

	// some key gets removed -- always a leaf, so left/right pointers both 0
	int cnt = node.size() - 1;
	String[] newkey=new String[cnt]; System.arraycopy(node.key,0, newkey,0, index); System.arraycopy(node.key,index+1, newkey,index, cnt-index);
	long[] newdata = new long[cnt]; System.arraycopy(node.data,0, newdata,0, index); System.arraycopy(node.data,index+1, newdata,index, cnt-index);
	assert node.child[index]==0 && node.child[index+1]==0: node.child[index]+" "+node.child[index+1];
	int[] newchild = new int[cnt+1]; System.arraycopy(node.child,0, newchild,0, index); System.arraycopy(node.child,index+1, newchild,index, cnt-index+1);
	node.set(newkey, newdata, newchild, node.bytelen - (ENTRY_OVERHEAD + countUTF(key))); dirty_.add(node);
	//int before = node.bytelen, delta = ENTRY_OVERHEAD + countUTF(key);
	int after=node.bytelen; assert after == node.computeBytelen(): /*before+"-"+delta+"="+*/after+" != "+node.computeBytelen();

	// left with empty node?
	if (cnt == 0 && node!=root_/*or node.index > 0*/) { // remove whole node
if (DEBUG) System.out.println("empties Node");
		p.child[pi]=0; dirty_.add(p);

		Integer iobj = new Integer(node.index);
		cache_.remove(iobj);
		dirty_.remove(node);
		recycle_.add(iobj);
	}
  }

  /** Returns heterogeneous List: last element is Integer position in node (negative position if would be inserted there), rest is path of Nodes to that node. */
  List<Object> find(String key) throws IOException {
	List<Object> stack = new ArrayList<Object>(10);
	Node node = root_, lastnode = node;
	do {
		stack.add(node);
		lastnode = node;

		int index = Arrays.binarySearch(node.key, key);
		if (index < 0) {
			int i = -(index+1);
			if (node.child[i] > 0) { index=i; node = readNode(node.child[i]); }     // descend child
		}

		stack.add(new Integer(index));
	} while (lastnode != node);

	assert stack.size()%2 == 0: stack.size();
	return stack;
  }


  Node readNode(int index) throws IOException {
	assert index>=0 && index<maxrec_;

	// in cache?
	if (index==0 && root_!=null) return root_;  // always cached
	Integer iobj = new Integer(index);
	SoftReference<Node> ref = cache_.get(iobj);
	if (ref!=null && ref.get()!=null) return ref.get();
	//Node node = (Node)cache_.get(iobj); if (node!=null) return node;

	// read from disk
	RandomAccessFile raf = raf_;
	long tell = HEADER_LENGTH + index * blockSize_;
	raf.seek(tell);
	// child .. key (len, chars) + data offset .. child .. key .. child
	int cnt = ((raf_.read() << 8) | raf_.read()) & 0xffff;   // two byte count of number of keys in node (max 64K per node)
	String[] key = new String[cnt]; long[] data = new long[cnt]; int[] child = new int[cnt+1];
	for (int i=0; i<cnt; i++) {
		child[i] = raf_.readInt();
		key[i] = raf_.readUTF(); data[i]=raf_.readLong();
	}
	child[cnt] = raf_.readInt();

	Node node = new Node(index, key, data, child,  (int)(raf.getFilePointer() - tell));
	cache_.put(iobj, new SoftReference<Node>(node));

	return node;
  }

  void writeNode(Node node) throws IOException {
	//if (!node.dirty) return;

	RandomAccessFile raf = raf_; raf.seek(HEADER_LENGTH + node.index * blockSize_);
	int cnt = node.size(); String key[]=node.key; long[] data=node.data; int[] child=node.child;
	raf_.writeByte(cnt>>8); raf_.writeByte(cnt);
	for (int i=0; i<cnt; i++) {
		raf.writeInt(child[i]);
		raf.writeUTF(key[i]); raf.writeLong(data[i]);
	}
	raf.writeInt(child[cnt]);

	//dirty_.remove(node); => ConcurrentModificationException in flush()
  }


  /** Iterator over keys, in sorted order. */
  public Iterator<String> iterator() /*throws IOException*/ { return new KeyIterator(); }

  /**
	Iterator over range from <var>key1</var> to <var>key2</var>, inclusive.
	If <var>key1</var> is null, the first key in the store is used;
	if <var>key2</var> is null, the last key in the store is used.
  */
  public Iterator<String> iterator(String key1, String key2) /*throws IOException*/ {
	List<Object> stack = null;
	if (key1 !=null) {
		try { stack = find(key1); } catch (IOException e) { stack=new ArrayList<Object>(0); key1=null; }
		// verify that it exists

	} else {    // find first key
		for (Node n=root_; true; ) {
			stack.add(n); stack.add(new Integer(0));
			if (n.child[0] > 0) try { n = readNode(n.child[0]); } catch (IOException kill) { break; }
			else break;
		}
	}

	return new KeyIterator(stack, key2);
  }


  /**
	Return an unused record number.
	If previous nodes have been deleted (because all of their keys have been removed), then return on of those.
	Otherwise return a number one higher than the number of nodes previously in use.
  */
  int getRecNum() {
	if (recycle_==null) {
		String freefile = filename_ + FREE_SFX;
		if (new File(freefile).canRead()) try {	// read in from disk
			RandomAccessFile free = new /*Buffered*/RandomAccessFile(freefile, "r");
			int cnt = free.readInt();
			recycle_ = new ArrayList<Integer>(cnt);
			for (int i=0; i<cnt; i++) recycle_.add(new Integer(free.readInt()));
			free.close();
		} catch (IOException ioe) {}    // just an optimization

		if (recycle_==null) recycle_ = new ArrayList<Integer>(10);   // either no free list or error reading free list
	}

	return (recycle_.size()>0? (recycle_.remove(recycle_.size()-1)).intValue(): maxrec_++);
  }

  void writeFree(List<Integer> empty) throws IOException {
	String freefile = filename_ + FREE_SFX;
	if (new File(freefile).canWrite()) {	// read in from disk
		RandomAccessFile free = new /*Buffered*/RandomAccessFile(freefile, "rw");
		int cnt = empty.size();
		free.writeInt(cnt);
		for (int i=0; i<cnt; i++) free.writeInt(empty.get(i).intValue());
		free.close();
	}
  }

  public void flush() throws IOException {
	// write dirty key nodes
	for (Iterator<Node> i=dirty_.iterator(); i.hasNext(); ) writeNode(i.next());
	dirty_.clear();

	raf_.seek(0);
	raf_.writeInt(VERSION);
	raf_.writeInt(blockSize_);
	raf_.writeInt(maxrec_);

	writeFree(recycle_); //try {} catch (IOException ioe) {}     // just an optimization

	//raf_.flush();
  }

  public void close() throws IOException {
	flush();
	raf_.close();
  }

  // if dirty save as hard ref, if not save as SoftReference?
  //void setDirty(Node node, boolean flag) {}

  /** Taken from java.io.DataOutputStream. */
  static int countUTF(String utf) {
	int utflen = 0;
	for (int i=0,imax=utf.length(); i<imax; i++) {
		int c = utf.charAt(i);
		if ((c >= 0x0001) && (c <= 0x007F)) utflen++;
		else if (c > 0x07FF) utflen += 3;
		else utflen += 2;
	}
	return utflen + 2/*length bytes */;
  }
}
