package multivalent.std.adaptor.pdf;

import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.font.OpenType;  // TrueType AND Type 1 -- but not implemented by Sun
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphMetrics;
import java.awt.font.GlyphVector;
import java.util.Map;
import java.util.HashMap;
import java.io.InputStream;
import java.io.IOException;

import multivalent.Behavior;

import phelps.awt.Fonts;



/**
	Font creation, with bundled encoding and PDF-specific widths table.

	@version $Revision: 1.17 $ $Date: 2003/10/04 21:02:04 $
*/
public class FontPDF implements Cloneable {
  static final boolean DEBUG = !false && multivalent.Multivalent.DEVEL;
  

  /*private--FontType3*/ static final Font BASEFONT = new Font("Times", Font.PLAIN, 12);

  /** Adobe to screen PPI scaling. */
  private final float A2S = 72f / java.awt.Toolkit.getDefaultToolkit().getScreenResolution();
  private Font tf_; // create on demand?
  /** Logical point size. */
  //double pointsize_;
  /** Actual size as shaped by Tm.  Different from getFont().getSize2D() if shaping. */
  double size_;
  Encoding encoding_ = null;
  int[] widths_ = null;
  boolean fstdwidths_;
  Rectangle2D maxr_;
  int firstch_, lastch_;
  boolean fTeX_ = false;
  AffineTransform shaping_;


  public static FontPDF create(Dict fontdict, double pointsize, float size, AffineTransform Tm, Dict page, PDF pdf, PDFReader pdfr) throws IOException {
	String subtype = (String)pdfr.getObject(fontdict.get("Subtype"));

	return "Type3".equals(subtype)? new FontType3(fontdict, pointsize, size, Tm, page, pdf, pdfr):
		new FontPDF(fontdict, pointsize, size, Tm, pdfr);
  }

  /*package-private*/ FontPDF(Dict fontdict, double pointsize, float size, AffineTransform Tm, PDFReader pdfr) throws IOException {
	size_ = size;

/*	Dict fdesc = (Dict)pdfr.getObject(fd.get("FontDescriptor"));
	if (fdesc==null) {
		fdesc = Core14AFM.getFontDescriptor(family);
		if (fdesc!=null) fontdict.put("FontDescriptor", fdesc);
	}*/

	tf_ = createFont(fontdict, pointsize, size, Tm, pdfr);

	setEncoding(fontdict, pdfr);    // before widths
	setWidths(fontdict, pdfr);
	shaping_ = computeShaping(fontdict, pdfr);
//System.out.println("new font "+tf_.getFamily()+", "+pointsize+"/"+size+" * "+(shaping!=null? shaping.getScaleX(): 1));

	//deriveFont(pointsize, size, Tm);    // considers shaping matrix
	size = (float)(size * shaping_.getScaleX() * A2S);
//System.out.println(size);
	if (Math.abs(size - tf_.getSize2D())>0.001) tf_ = tf_.deriveFont(size);

	setMaxr(Tm);
  }

  /** Return new font at new size and transformation. */
  public FontPDF deriveFont(double pointsize, float size, AffineTransform Tm) {
	float shsize = (float)(size * shaping_.getScaleX()) * A2S;
//System.out.println(size);
	if (Math.abs(shsize - tf_.getSize2D())<0.001) return this;

	FontPDF newfont = null; try { newfont = (FontPDF)clone(); } catch (Exception canthappen) {}  // can share almost everything
	newfont.size_ = size;
	newfont.tf_ = tf_.deriveFont(shsize);
	//pointsize_ = pointsize;
	newfont.setMaxr(Tm);

	return newfont;
  }


  public double getSize2D() { return size_/*tf_.getSize2D()*/; }
  public String getFamily() { return tf_.getFamily(); }
  public Font getFont() { return tf_; }
  public Rectangle2D getMaxCharBounds() { return maxr_; }
  /** Temporary, while don't support Type 0. */
  public boolean canRender() { return widths_!=null; }


  // just need ascent and height, which may be available in font descriptor
  private void setMaxr(AffineTransform Tm) {
	//if (shaping_!=null) Tm.concatenate(shaping);
	FontRenderContext tfrc = new FontRenderContext(Tm, true, true); // aa, fract => scaled by shaping!
	maxr_ = tf_.getMaxCharBounds(tfrc);  //-- height and ascent of bboxes
  }

  /*package-private*/ void setWidths(Dict fd, PDFReader pdfr) throws IOException {
	assert encoding_!=null; // set encoding before so know if TeX
	//if (fdesc!=null) System.out.println(family+": FontBBox = "+COS.array2Rectangle((Object[])fdesc.get("FontBBox"), IDENTITY_TRANSFORM)+" vs "+newfont.getMaxCharBounds(new FontRenderContext(IDENTITY_TRANSFORM, false, false)));
	Object o = pdfr.getObject(fd.get("Widths"));
	if (o!=null && o.getClass()==COS.CLASS_ARRAY) {
		Object[] wo = (Object[])o;
		int[] wint = new int[wo.length];
		for (int i=0,imax=wo.length; i<imax; i++) wint[i] = pdfr.getObjInt(wo[i]);

		widths_ = wint;
		firstch_ = ((o = fd.get("FirstChar"))!=null? pdfr.getObjInt(o): 0);  // required
		fstdwidths_ = false;

	} else { assert o==null: o;   // core 14, which don't have /Widths
		widths_ = Core14AFM.getWidths(Fonts.getPDFCanonical((String)fd.get("BaseFont")));
//System.out.println("widths for core "+fontdict.get("BaseFont")+" = "+widths);
		firstch_ = 32;   // happens to be 32 for entire core 14
		fstdwidths_ = true;  // have to translate text without widths to match this encoding
		//fstdwidths_ = (encoding_!=Encoding.TEX161_ENCODING && encoding_!=Encoding.TEX163_ENCODING);    // unless it's TeX, in which case use identity
		fstdwidths_ = !fTeX_;
	}

	if (widths_ != null)    // Type 0
	lastch_ = ((o = fd.get("LastChar"))!=null? pdfr.getObjInt(o): firstch_ + widths_.length);  // required
	//assert widths_ != null: fd.get("Family"); -- Type 0
  }

  private AffineTransform computeShaping(Dict dict, PDFReader pdfr) throws IOException {
	AffineTransform at = new AffineTransform();

	int[] w = widths_; if (w==null) return at;    // Type 0 -- as in RESIDU p51

	String family = (String)pdfr.getObject(dict.get("BaseFont"));
	Dict desc = (Dict)pdfr.getObject(dict.get("FontDescriptor"));  // required except for core 14
	if (desc==null) desc = Core14AFM.getFontDescriptor(family);
	Object o=null;
	int flags = desc!=null && (o=desc.get("Flags"))!=null? pdfr.getObjInt(o): Fonts.FLAG_SERIF | Fonts.FLAG_NONSYMBOLIC;
	//int AvgWidth = (desc!=null && (o=desc.get("AvgWidth"))!=null? pdfr.getObjInt(o): 0);
//System.out.println("flags = "+o+" => "+Integer.toBinaryString(flags));
	if ((flags&Fonts.FLAG_SYMBOLIC)!=0) { /*System.out.println("can't shape: symbolic");*/ return at; }

	int glyphcnt = w.length;
	Font f=tf_; int firstch=firstch_, lastch=lastch_; double sz=size_/*tf_.getSize2D()*/;

	// if (AvgWidth==0) ...
	StringBuffer sb = new StringBuffer(glyphcnt);
	for (int i=Math.max(firstch, 'a'),imax=Math.min('z',lastch)+1; i<imax; i++) sb.append((char)i);
	for (int i=Math.max(firstch, 'A'),imax=Math.min('Z',lastch)+1; i<imax; i++) sb.append((char)i);
	for (int i=Math.max(firstch, '0'),imax=Math.min('9',lastch)+1; i<imax; i++) sb.append((char)i);
	//sb.append('.');
	if (sb.length()==0) {/*System.out.println("can't shape: weird encoding "+firstch+".."+lastch);*/ return at; }
	FontRenderContext frc = new FontRenderContext(new AffineTransform(), true, true);
	String txt = translate(sb); //sb.toString();
	GlyphVector gv = f.createGlyphVector(frc, txt);

	float advw=0f, advact=0f;//, diff=0f, mindiff=Float.MAX_VALUE, maxdiff=Float.MIN_VALUE;
	for (int i=0,imax=gv.getNumGlyphs(); i<imax; i++) {
		int wi = w[txt.charAt(i) - firstch]; if (wi == 0) continue;  // skipped that place in widths table
		GlyphMetrics gm = gv.getGlyphMetrics(i);    // FontMetrics no good because integer
		float aw=(float)(wi/1000.0*sz), aa=gm.getAdvanceX();
		advw += aw; advact += aa;
//System.out.print(txt.charAt(i)+" "+w[txt.charAt(i)-firstch]+" "+(aa*1000.0/sz)+"   ");
//if (txt.charAt(i)=='.') System.out.println(aw+" vs "+aa+", ratio "+(aw/aa));
		//double d = aw - aa;
		//diff += d;
		//if (d<mindiff) mindiff=d; /*else*/ if (d>maxdiff) maxdiff=d;
		//if (Math.abs(d)>2) System.out.print("    "+txt.charAt(i)+": "+aw+"="+aa);
	}
//System.out.println("advance: "+advact+" vs "+gv.getPixelBounds(null, 0f, 0f));
//double avgdiff = diff / glyphcnt;
//System.out.println("   "+glyphcnt+" glyphs, "+mindiff+" .. "+avgdiff+" .. "+maxdiff+", cf "+(w[1]/1000.0*sz));
	double scaleby = (advw>0.0 && advact>0.0? advw/advact: 1.0);

//if (PDF.DEBUG) System.out.println(family+" => "+advw+"/"+advact+"="+scaleby);
	at.scale(scaleby, scaleby);
	return at;
  }

  public double measureText(char ch) {
	int off = ch - firstch_;
	return (widths_!=null/*Type3 or Type 0*/ && off>=0 && off<widths_.length? widths_[off]/1000.0 * size_/*tf_.getSize2D()*//*pointsize*/: 0.0);
	//int spacei = 32-firstch_;
	//spacew = (widths_!=null && spacei>=0 && spacei<widths_.length? widths_[spacei] / 1000.0 * pointsize: /* 0? */tf_.getStringBounds(" ", tfrc).getWidth() / Tm.getScaleX() /*250.0/1000.0 * tf_.getSize2D()*/);   // possible that space not in font!, as in TeX font
  }

  /** Measurements from PDF-specific widths array, not from underlying java.awt.Font. */
  public double measureText(StringBuffer txt8, int s, int e) {
	int[] w = widths_; if (w==null) return 0.0;
	int pdfw = 0, firstch=firstch_;
	for (int j=s, wlen=w.length; j<e; j++) {
		char ch = txt8.charAt(j);   // for widths, use non-translated
		int off = ch - firstch;
//if (ch-firstch_ < 0 || ch-firstch_ >= wlen) System.out.println(ch+"/"+(int)ch+" @ "+j+" in |"+txt8+"| not in "+firstch_+".."+(firstch_+wlen)+" in font "+fontdict.get("BaseFont")+"/"+tf_.getFamily());
		if (off>=0 && off<wlen) /*{*/pdfw += w[off]; // else 0 width
		//if (widths_[off]==0) System.out.println("warning: 0 width for "+(int)ch+" / "+ch+" in font "+fontdict+", standard="+fstdwidths_);}    // -- goes nuts on Type 3
	}
	return pdfw / 1000.0 * size_/*tf_.getSize2D()*/;
  }



  private void setEncoding(Dict fd, PDFReader pdfr) throws IOException {
	Object o = pdfr.getObject(fd.get("Encoding"));
	if (fTeX_ && o instanceof Dict) {    // epodd/volume8/issue2/1point1.pdf has TeX with /Encoding /WinAnsiEncoding
		if (o==null) { o=new Dict(3); fd.put("Encoding", o); }
		Dict en = (Dict)o;
		en.put("BaseEncoding", "TeX");
//System.out.println("TeX encoding = "+en.get("BaseEncoding"));
	}

	//Encoding en;
	//if (o==null/*use built-in encoding*/ && fTeX_) encoding_ = (tf.canDisplay((char)171)? Encoding.TEX161_ENCODING: Encoding.TEX163_ENCODING);
	//else
	encoding_ = Encoding.getInstance(fd, pdfr);

	// if TeX encoding, translated to genuine TeX, so we have to translate glyphs in 0..31 due to Windoze lameness
	if (fTeX_) {
		//en.remove("BaseEncoding");

		char[] map = (char[])encoding_.toUni_.clone();
		//patchTeX(map);  // temporarily
		int off = (tf_.canDisplay((char)171)? 161: 163);
		for (int i=0,imax=map.length; i<imax; i++) if (map[i] < 32) map[i] += off;
		encoding_.toUni_ = map;
	}

	assert encoding_!=null: fd;
  }


  public String translate(StringBuffer txt8) {
	return encoding_.translate(txt8, fstdwidths_);
  }



  /**
	Constructs {@link java.awt.Font} based on font dictionary, scaled to <var>size</var> pixels.

	<p>Sequence to choose font:
	<ol>
	<li>Embedded font data
	<li>TeX font name, with font data embedded in DVI.jar
	<li>{@link Fonts#createFont(String,float,int)}.
	</ol>
  */
  /*package-private*/ Font createFont(Dict fd, double pointsize, float size, AffineTransform Tm, PDFReader pdfr) throws IOException {
	assert fd!=null && size>=0f /*&& size<200f*/: fd+", size="+size;    // ==0f seen in riggs.pdf page 20
	assert "Font".equals(fd.get("Type")) || null==fd.get("Type");


	String family = (String)pdfr.getObject(fd.get("BaseFont"));
	int inx = family.indexOf('+'); if (inx!=-1) family = family.substring(inx+1);	// embedded fonts "XXXXXX+...".  could have embedded Type1/Type1C or CID that's not supported, and need to load from OS
	Dict fdesc = (Dict)pdfr.getObject(fd.get("FontDescriptor"));
	if (fdesc==null) fdesc = Core14AFM.getFontDescriptor(family);

	Font newfont = BASEFONT;
	String subtype = (String)pdfr.getObject(fd.get("Subtype"));
//if (DEBUG) System.out.println("basefont = "+family);// +", fd="+fdesc);

	//if ((pdf.getFlags() & MediaAdaptor.FLAG_DISPLAY) == 0) ... don't need actual font

	if ("Type0".equals(subtype)) {  // LATER (FontType0?)
		//newfont = BASEFONT;
		family = "Arial";
		//newfont = new Font("Arial", size, flags);	// large subset of Unicode glyphs
		PDF.unsupported("embedded Type 0 font "+family);

	//} else if ("Type3".equals(subtype)) { => create() passes this off to FontType3

	} else { // Type 1 or TrueType
		boolean match = false;

		// 1. embedded font (first since result is perfectly correct)
		Object emfontref;
//System.out.println(fdesc)
		if (fdesc==null) {  // core 14 -- should have already worked
			// take whatever Java derived
//System.out.println("core 14: "+family);
			newfont = new Font(family, Font.PLAIN, 12);
			newfont = newfont.deriveFont(size);

		} else if ((emfontref=(IRef)fdesc.get("FontFile"))!=null/*Type 1*/ 
				   || ("Type1C".equals(subtype) && (emfontref=(IRef)fdesc.get("FontFile3"))!=null)) {
			if (PDF.DEBUG) System.err.println("Embedded Type 1 font, "+family+".  Java can't dynamically load Type 1 fonts until Java 1.5.");

			// instantiate like TrueType below
			InputStream in = pdfr.getInputStream(emfontref);

			// if Java 1.5 needs trailing 512 zeros and "cleartomark", read data stream and add
			/*Dict embed = (Dict)pdfr.getObject(emfontref);
			final String EOF = "cleartomark\n";
			final int ZLEN_MIN = 512 + EOF.length();
			int zlen = getObjInt(embed.get("Length3"));
			if (zlen < ZLEN_MIN) {
				byte[] data = getStreamData(iref, false, true);
				byte[] newdata = new byte[clen + elen + zlen];
				System.arraycopy(data,0, newdata,0, newdata.length);
				for (int i=clen+elen, imax=i+512; i<imax; i++) newdata[i] = (byte)'0';	// supposed to linebreak?
				for (int i=clen+elen+512, j=0, jmax=EOF.length(); j<jmax; i++,j++) newdata[i] = (byte)EOF.charAt(j);
				in = new ByteArrayInputStream(newdata);
			}*/

			// if Java 1.5 can't handle CCF, translate to standard format here via phelps.awt.font.Type1

			try {
				//newfont = Font.createFont(Font.TYPE1_FONT, in);
				//newfont = newfont.deriveFont(size);
				//fam = newfont.getFamily();
//System.out.println("created new TrueType font from embedded stream, name = "+fam+", "+newfont.getPSName());
				//match = true;
			//} catch (FontFormatException failed) {  // happens in Aiken lectures, created by Aladdin Ghostscript 6.0
				//System.err.println("couldn't create embedded Type 1:" +failed);
				//failed.printStackTrace(); -- unenlightening, a native method
			} finally { in.close(); } // -- Font.createFont() closes and InputStreamComposite wants to nulls

		} else if ((emfontref = fdesc.get("FontFile2"))!=null) {
//System.out.println(rawfont);
//System.out.println("length = "+pdfr.getObject(rawfont.get("Length1")));
			InputStream in = pdfr.getInputStream(emfontref);
			try {
				newfont = Font.createFont(Font.TRUETYPE_FONT, in);
				newfont = newfont.deriveFont(size);
				//fam = newfont.getFamily();
//System.out.println("created new TrueType font from embedded stream, name = "+family+", "+newfont.getPSName());
				match = true;
			} catch (FontFormatException failed) {  // happens in Aiken lectures, created by Aladdin Ghostscript 6.0
				System.err.println("couldn't create embedded TrueType:" +failed);
				//failed.printStackTrace(); -- unenlightening, a native method
			} finally { in.close(); } // -- Font.createFont() closes and InputStreamComposite wants to nulls

		} else if (fdesc.get("FontFile3")!=null/* "CIDFontType0C"or other */) {
			if (PDF.DEBUG) System.err.println("Embedded font of unsupported type: "+family+" of type "+subtype);

		}


		// 2. special case: try TeX font => with Java 1.5 take out as these will be embedded
		if (!match /*&& fam. contains number -- not always true*/) {     // special case: try TeX font, which might be available in tex.dvi package
			Behavior dvi = Behavior.getInstance("dvi", "DVI", null, null, null);
			if (dvi!=null) {
				String fam = family.toLowerCase();

				//String tfam = (fam.indexOf('+')==-1? fam: fam.substring(fam.indexOf('+')+1));   // embedded name has been straight name, TAG+name, and apparently random name
				InputStream in = dvi.getClass().getResourceAsStream("font/"+fam+".ttf");
//System.out.println("searching for TeX: "+fam);
				if (in!=null) try {
					newfont = Font.createFont(Font.TRUETYPE_FONT, in);
					newfont = newfont.deriveFont(size);  // know family; italic and weight bogus for TeX
					match = true;
					fTeX_ = true;
//System.out.println("\tTeX font");
				} catch (FontFormatException failed) { System.out.println(failed);
				} finally { in.close(); }   // -- Font.createFont() closes and InputStreamComposite wants to nulls
			}
		}


		// 3. substitute from flags
		if (!match) {
			Object flagso = fdesc!=null? fdesc.get("Flags"): null;
			int flags = flagso!=null? pdfr.getObjInt(flagso): Fonts.FLAG_NONE;
			newfont = Fonts.createFont(family, size, flags);
		}
	}

if (newfont instanceof OpenType) {   // NOTHING DOES!
	OpenType otf = (OpenType)newfont;
	System.out.println("OpenType v"+(otf.getVersion()>>16)+"."+(otf.getVersion()&0xffff));
}
//System.out.println("decode = "+Font.decode(family));
//System.out.println(family+"->"+newfont.getFamily()+", encoding="+en+", flags="+flags+", charOffset_="+charOffset_);
//System.out.println("space width="+newfont.getStringBounds(" ", new FontRenderContext(new AffineTransform(), false, false)));
//System.out.println(family+" => "+newfont);
//if (DEBUG) System.out.println("Tf: "+family+" @ "+size+" => "+newfont.getFamily());  // +", b/i="+tf.isBold()+"/"+tf.isItalic());

/*
	Object o;

	o = (fdesc!=null? pdfr.getObject(fdesc.get("FontBBox")): null);
	if (o instanceof Object[]) {
		Object[] oa = (Object[])o;
		double ew=((Number)oa[2]).doubleValue()/72.0, eh=((Number)oa[3]).doubleValue()/72.0;

		//Rectangle2D maxr_ = newfont.getMaxCharBounds(IDENTITY_RENDER);
		//System.out.println(ew+" x "+eh+"  vs  "+maxr_.getWidth()+" x "+maxr_.getHeight());

		int firstchar = getObjInt(fd.get("FirstChar"));
		Object[] wo = (Object[])fd.get("Widths");
		double Mw = ((Number)wo['M' - firstChar]).doubleValue() / 72.0, capheight = ((Number)fdesc.get("CapHeight")).doubleValue() / 72.0;
		Rectangle2D rr = newfont.getStringBounds("M", IDENTITY_RENDER);
		System.out.println(Mw+" x "+capheight+" ("+(Mw/capheight)+")  vs  "+rr.getWidth()+" x "+(-rr.getY())+" ("+(rr.getWidth()/-rr.getY())+")");  // getY() is ascent
		//AffineTransform warp = AffineTransform.getScaleInstance(1.0, 1.0);
	}
*/

//System.out.println("spacew = "+spacew); // +" vs "+widths_[spacei]);
/*Graphics2D g = (Graphics2D)br.getGraphics();
Map hints = new HashMap(); hints.put(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
g.addRenderingHints(hints);
FontMetrics fm = br.getGraphics().getFontMetrics(tf);
if (widths_!=null && widths_.length>=32+'M') System.out.println(tf_.getFamily()+": "+(widths_['M'-32]/1000.0 * Tm.getScaleX() * pointsize)+" vs "+fm.getStringBounds("M", br.getGraphics()).getWidth());
*/

/*		double ppi = java.awt.Toolkit.getDefaultToolkit().getScreenResolution() / 72.0;
		AffineTransform af = new AffineTransform();
		//af = Tm;
		af = new AffineTransform(1000.0/ppi, 0.0, 0.0, 1000.0/ppi, 0.0, 0.0);
		FontRenderContext frc = new FontRenderContext(af, false, false);
		AffineTransform t2p = new AffineTransform(1.0, 0.0, 0.0, 1.0, 0.0,0.0);
		System.out.println(COS.array2Rectangle((Object[])pdfr.getObject(fdesc.get("FontBBox")), t2p)+" vs "+newfont.deriveFont(1f).getMaxCharBounds(frc));
*/

if (DEBUG) System.out.println(family+" => "+newfont);
	assert newfont!=null: family;
	return newfont;
  }
}
