package phelps.io;

import java.io.InputStream;
import java.io.IOException;



/**
	Utility methods for {@link java.io.InputStreams}s.

    <ul>
	<li>{@link #DEVNULL}
	<li>{@link #uncompress(InputStream, String)}
	</ul>

	@version $Revision: 1.2 $ $Date: 2003/08/17 14:00:05 $
*/
public class InputStreams {
  /**
	InputStream that always reports end of file (<code>-1</code>) on read.
  */
  public final static InputStream DEVNULL = new InputStream() {
	public int read() { return -1; }
	public int read(byte[] b) { return read(b,0,b.length); }
	public int read(byte[] b, int off, int len) { return -1; }
	public long skip(long n) { return n; }
	public int available() { return Integer.MAX_VALUE; }

	public void close() {}

	public void mark(int readlimit) {}
	public void reset() {}
	public boolean markSupported() { return true; }
  };


  private InputStreams() {}


  /* Inspect input stream to determine type. 
  public static InputStream uncompress(InputStream is) throws IOException {
  	LZW magic number (1f 9d)
	LZW/PDF  /Filter /LZWDecode
	Flate 0x80
	BZip2 (B Z h [1-9])
  }*/

  /**
	 Wraps <var>is</var> with another stream that uncompresses it.
	 @param file  filename with compression suffix, or compression type (<code>LZW</code>, <code>gzip</code>, <code>deflate</code>, <code>bzip2</code>).
   */
  public static InputStream uncompress(InputStream is, String fileOrType) throws IOException {
	int inx = fileOrType.lastIndexOf('.');
	String suffix = inx!=-1? fileOrType.substring(inx+1): fileOrType;
	String type = fileOrType.toLowerCase();

	if ("Z".equals(suffix) || "z".equals(suffix) || "lzw".equals(type)) is = new phelps.io.InputStreamLZW(is);
	else if ("gz".equals(suffix) || "gzip".equals(type)) is = new java.util.zip.GZIPInputStream(is);
	else if ("deflate".equals(type) || "flate".equals(type)) is = new java.util.zip.InflaterInputStream(is);
	else if ("bz2".equals(suffix) || "bzip2".equals(suffix) || "bzip2".equals(type)) is = new org.apache.tools.bzip2.CBZip2InputStream(is);
	//else keep as is

	return is;
  }
}
