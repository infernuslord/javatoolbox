jikes -sourcepath 'src;tests/classes' -bootclasspath 'c:/j2sdk1.4.2/jre/lib/rt.jar' -d classes src/bsh/*.java src/bsh/*/*.java tests/classes/*.java tests/classes/*/*.java
