/*
 * Copyright (c) 2004, the JUNG Project and the Regents of the University of
 * California All rights reserved.
 * 
 * This software is open-source under the BSD license; see either "license.txt"
 * or http://jung.sourceforge.net/license.txt for a description.
 * 
 * Created on Nov 7, 2004
 */
package samples.graph;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.swing.JApplet;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;

import org.apache.commons.collections.Predicate;
import org.apache.commons.collections.functors.TruePredicate;

import edu.uci.ics.jung.algorithms.importance.VoltageRanker;
import edu.uci.ics.jung.graph.DirectedEdge;
import edu.uci.ics.jung.graph.Edge;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.UndirectedEdge;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.graph.decorators.AbstractVertexShapeFunction;
import edu.uci.ics.jung.graph.decorators.ConstantEdgeStringer;
import edu.uci.ics.jung.graph.decorators.ConstantVertexColorFunction;
import edu.uci.ics.jung.graph.decorators.ConstantVertexStringer;
import edu.uci.ics.jung.graph.decorators.EdgeColorFunction;
import edu.uci.ics.jung.graph.decorators.EdgeFontFunction;
import edu.uci.ics.jung.graph.decorators.EdgeStringer;
import edu.uci.ics.jung.graph.decorators.EdgeStrokeFunction;
import edu.uci.ics.jung.graph.decorators.NumberEdgeValue;
import edu.uci.ics.jung.graph.decorators.NumberEdgeValueStringer;
import edu.uci.ics.jung.graph.decorators.NumberVertexValue;
import edu.uci.ics.jung.graph.decorators.NumberVertexValueStringer;
import edu.uci.ics.jung.graph.decorators.UserDatumNumberEdgeValue;
import edu.uci.ics.jung.graph.decorators.UserDatumNumberVertexValue;
import edu.uci.ics.jung.graph.decorators.VertexAspectRatioFunction;
import edu.uci.ics.jung.graph.decorators.VertexColorFunction;
import edu.uci.ics.jung.graph.decorators.VertexFontFunction;
import edu.uci.ics.jung.graph.decorators.VertexSizeFunction;
import edu.uci.ics.jung.graph.decorators.VertexStringer;
import edu.uci.ics.jung.graph.decorators.VertexStrokeFunction;
import edu.uci.ics.jung.graph.predicates.ContainsUserDataKeyVertexPredicate;
import edu.uci.ics.jung.random.generators.BarabasiAlbertGenerator;
import edu.uci.ics.jung.utils.PredicateUtils;
import edu.uci.ics.jung.utils.TestGraphs;
import edu.uci.ics.jung.visualization.FRLayout;
import edu.uci.ics.jung.visualization.GraphDraw;
import edu.uci.ics.jung.visualization.PickedInfo;
import edu.uci.ics.jung.visualization.PluggableRenderer;
import edu.uci.ics.jung.visualization.VisualizationViewer;


/**
 * Shows off some of the capabilities of <code>PluggableRenderer</code>.
 * This code provides examples of different ways to provide and
 * change the various functions that provide property information
 * to the renderer.
 * 
 * <p>This demo creates a random mixed-mode graph with random edge
 * weights using <code>TestGraph.generateMixedRandomGraph</code>.
 * It then runs <code>VoltageRanker</code> on this graph, using half
 * of the "seed" vertices from the random graph generation as 
 * voltage sources, and half of them as voltage sinks.</p>
 * 
 * <p>What the controls do:
 * <ul>
 * <li/>"vertex seed coloring": if checked, the seed vertices are colored blue, 
 * and all other vertices are colored red.  Otherwise, all vertices are colored
 * a slightly transparent red (except the currently "picked" vertex, which is
 * colored transparent purple).
 * <li/>"vertex selection stroke highlighting": if checked, the picked vertex
 * and its neighbors are all drawn with heavy borders.  Otherwise, all vertices
 * are drawn with light borders.
 * <li/>"show vertex ranks (voltages)": if checked, each vertex is labeled with its
 * calculated 'voltage'.  Otherwise, vertices are unlabeled.
 * <li/>"vertex degree shapes": if checked, vertices are drawn with a polygon with
 * number of sides proportional to its degree.  Otherwise, vertices are drawn
 * as ellipses.
 * <li/>"vertex voltage size": if checked, vertices are drawn with a size 
 * proportional to their voltage ranking.  Otherwise, all vertices are drawn 
 * at the same size.
 * <li/>"vertex degree ratio stretch": if checked, vertices are drawn with an
 * aspect ratio (height/width ratio) proportional to the ratio of their indegree to
 * their outdegree.  Otherwise, vertices are drawn with an aspect ratio of 1.
 * <li/>"bold text": if checked, all vertex and edge labels are drawn using a
 * boldface font.  Otherwise, a normal-weight font is used.  (Has no effect if
 * no labels are currently visible.)
 * <li/>"edge weight highlighting": if checked, edges with weight greater than
 * a threshold value are drawn using thick black solid lines, and other edges are drawn
 * using thin gray dotted lines.  (This combines edge stroke and color.) Otherwise,
 * all edges are drawn with thin black solid lines.
 * <li/>"show edge weights": if checked, edges are labeled with their weights.
 * Otherwise, edges are not labeled.
 * <li/>"show undirected edge arrows": if checked, undirected edges are drawn with
 * arrowheads at each end.  Otherwise, no arrows are used for undirected edges.
 * <li/>"show directed edges": if checked, directed edges are shown.  Otherwise, 
 * directed edges are not shown.
 * <li/>"show undirected edges": if checked, undirected edges are shown.  Otherwise,
 * undirected edges are not shown.
 * </ul>
 * </p>
 * 
 * @author Danyel Fisher, Joshua O'Madadhain
 */
public class PluggableRendererDemo extends JApplet implements ActionListener 
{
    protected JCheckBox v_color;
    protected JCheckBox e_color;
    protected JCheckBox v_stroke;
    protected JCheckBox e_arrow_pred;
    protected JCheckBox v_shape;
    protected JCheckBox v_size;
    protected JCheckBox v_aspect;
    protected JCheckBox v_labels;
    protected JCheckBox e_labels;
    protected JCheckBox font;
    protected JCheckBox e_show_d;
    protected JCheckBox e_show_u;
    protected JCheckBox v_small;
    
    protected PluggableRenderer pr;
    protected VertexColorFunction vcf_constant;
    protected VertexColorFunction vcf_degree;
    protected EdgeWeightColorStroke ewcs;
    protected VertexStrokeHighlight vsh;
    protected VertexStringer vs;
    protected VertexStringer vs_none;
    protected EdgeStringer es;
    protected EdgeStringer es_none;
    protected FontHandler ff;
    protected VertexShapeSizeAspect vssa;
    protected EdgeDisplayPredicate show_edge;
    protected VertexDisplayPredicate show_vertex;
    protected final static Object VOLTAGE_KEY = "voltages";
    
    protected NumberEdgeValue edge_weight = new UserDatumNumberEdgeValue("edge_weight");
    protected NumberVertexValue voltages = new UserDatumNumberVertexValue(VOLTAGE_KEY);

    private static int DUMP_ID;

    protected GraphDraw gd;
    
    public void start()
    {
        getContentPane().add( startFunction() );
    }

    public static void main(String[] s ) 
    {
        JFrame jf = new JFrame();
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel jp = new PluggableRendererDemo().startFunction();
        jf.getContentPane().add(jp);
        jf.pack();
        jf.show();
    }
    
    
    public PluggableRendererDemo()
    {
    }
    
    public JPanel startFunction() {
        Graph g = getGraph();

        // create decorators
        pr = new PluggableRenderer();
        vcf_constant = new ConstantVertexColorFunction(
                pr, Color.BLACK, new Color(1f,0f,0f,.9f), new Color(1f,0f,1f,.9f));
        vcf_degree = new SeedColor();
        ewcs = new EdgeWeightColorStroke(edge_weight);
        vsh = new VertexStrokeHighlight(pr);
        ff = new FontHandler();
        vs_none = new ConstantVertexStringer(null);
        es_none = new ConstantEdgeStringer(null);
        vssa = new VertexShapeSizeAspect(voltages);
        show_edge = new EdgeDisplayPredicate(true, true);
        show_vertex = new VertexDisplayPredicate(false);

        pr.setVertexColorFunction(vcf_constant);
        pr.setVertexStrokeFunction(vsh);
        pr.setVertexStringer(vs_none);
        pr.setVertexFontFunction(ff);
        pr.setVertexShapeFunction(vssa);
        pr.setVertexIncludePredicate(show_vertex);
        
        pr.setEdgeColorFunction(ewcs);
        pr.setEdgeStringer(es_none);
        pr.setEdgeFontFunction(ff);
        pr.setEdgeStrokeFunction(ewcs);
        pr.setEdgeIncludePredicate(show_edge);
        
        JPanel jp = new JPanel();
        jp.setLayout(new BorderLayout());
        
        gd = new GraphDraw( g );
        VisualizationViewer vv = gd.getVisualizationViewer();
        gd.setGraphLayout( new FRLayout(g));
        
        gd.setRenderer( pr );
        
        gd.setBackground(Color.white);
        jp.add( gd );
        addBottomControls( jp );
        
        return jp;
        
    }

    /**
     * Generates a mixed-mode random graph, runs VoltageRanker on it, and
     * returns the resultant graph.
     */
    public Graph getGraph()
    {
        Graph g = TestGraphs.generateMixedRandomGraph(edge_weight, 20);
        vs = new NumberVertexValueStringer(voltages);
        es = new NumberEdgeValueStringer(edge_weight);
        
        // collect the seeds used to define the random graph
        Collection seeds = PredicateUtils.getVertices(g, 
                new ContainsUserDataKeyVertexPredicate(BarabasiAlbertGenerator.SEED));
        if (seeds.size() < 2)
            System.out.println("need at least 2 seeds (one source, one sink)");
        
        // use these seeds as source and sink vertices, run VoltageRanker
        boolean source = true;
        Set sources = new HashSet();
        Set sinks = new HashSet();
        for (Iterator iter = seeds.iterator(); iter.hasNext(); )
        {
            if (source)
                sources.add(iter.next());
            else
                sinks.add(iter.next());
            source = !source;
        }
        VoltageRanker vr = new VoltageRanker(edge_weight, voltages, 100, 0.01);
        vr.calculateVoltages(g, sources, sinks);
        
        return g;  
    }

    /**
     * @param jp
     * @param gd
     */
    protected void addBottomControls(final JPanel jp) 
    {
        final JPanel control_panel = new JPanel();
        jp.add(control_panel, BorderLayout.SOUTH);
        control_panel.setLayout(new BorderLayout());
        final JPanel vertex_panel = new JPanel();
        vertex_panel.setLayout(new GridLayout(0,1));
        final JPanel edge_panel = new JPanel();
        edge_panel.setLayout(new GridLayout(0,1));
        final JPanel both_panel = new JPanel();
        both_panel.setLayout(new GridLayout(0,1));
        control_panel.add(vertex_panel, BorderLayout.WEST);
        control_panel.add(edge_panel, BorderLayout.EAST);
        control_panel.add(both_panel, BorderLayout.CENTER);

        v_color = new JCheckBox("vertex seed coloring");
        v_color.addActionListener(this);
        
        v_stroke = new JCheckBox("vertex selection stroke highlighting");
        v_stroke.addActionListener(this);

        v_labels = new JCheckBox("show vertex ranks (voltages)");
        v_labels.addActionListener(this);

        v_shape = new JCheckBox("vertex degree shapes");
        v_shape.addActionListener(this);
        
        v_size = new JCheckBox("vertex voltage size");
        v_size.addActionListener(this);
        
        v_aspect = new JCheckBox("vertex degree ratio stretch");
        v_aspect.addActionListener(this);
        
        v_small = new JCheckBox("filter vertices of degree < " + VertexDisplayPredicate.MIN_DEGREE);
        v_small.addActionListener(this);
        
        
        e_color = new JCheckBox("edge weight highlighting");
        e_color.addActionListener(this);
        
        e_labels = new JCheckBox("show edge weights");
        e_labels.addActionListener(this);

        e_arrow_pred = new JCheckBox("show undirected edge arrows");
        e_arrow_pred.addActionListener(this);
        
        e_show_d = new JCheckBox("show directed edges");
        e_show_d.addActionListener(this);
        e_show_d.setSelected(true);
        
        e_show_u = new JCheckBox("show undirected edges");
        e_show_u.addActionListener(this);
        e_show_u.setSelected(true);
        
        font = new JCheckBox("bold text");
        font.addActionListener(this);
        
        vertex_panel.add(v_color);
        vertex_panel.add(v_stroke);
        vertex_panel.add(v_labels);
        vertex_panel.add(v_shape);
        vertex_panel.add(v_size);
        vertex_panel.add(v_aspect);
        vertex_panel.add(v_small);
        edge_panel.add(e_color);
        edge_panel.add(e_labels);
        edge_panel.add(e_arrow_pred);
        edge_panel.add(e_show_d);
        edge_panel.add(e_show_u);
        both_panel.add(font);
    }

    public void actionPerformed(ActionEvent e)
    {
        JCheckBox source = (JCheckBox)(e.getSource());
        if (source == v_color)
        {
            if (source.isSelected())
                pr.setVertexColorFunction(vcf_degree);
            else
                pr.setVertexColorFunction(vcf_constant);
        }
        else if (source == e_color)
        {
            ewcs.setWeighted(source.isSelected());
        }
        else if (source == v_stroke) 
        {
            vsh.setHighlight(source.isSelected());
        }
        else if (source == v_labels)
        {
            if (source.isSelected())
                pr.setVertexStringer(vs);
            else
                pr.setVertexStringer(vs_none);
        }
        else if (source == e_labels)
        {
            if (source.isSelected())
                pr.setEdgeStringer(es);
            else
                pr.setEdgeStringer(es_none);
        }
        else if (source == e_arrow_pred)
        {
            if (source.isSelected())
                pr.setEdgeArrowPredicate(TruePredicate.getInstance());
            else
                pr.setEdgeArrowPredicate(Graph.DIRECTED_EDGE);
        }
        else if (source == font)
        {
            ff.setBold(source.isSelected());
        }
        else if (source == v_shape)
        {
            vssa.useFunnyShapes(source.isSelected());
        }
        else if (source == v_size)
        {
            vssa.setScaling(source.isSelected());
        }
        else if (source == v_aspect)
        {
            vssa.setStretching(source.isSelected());
        }
        else if (source == e_show_d)
        {
            show_edge.showDirected(source.isSelected());
        }
        else if (source == e_show_u)
        {
            show_edge.showUndirected(source.isSelected());
        }
        else if (source == v_small)
        {
            show_vertex.filterSmall(source.isSelected());
        }
        
        gd.repaint();
    }
    
    private final static class SeedColor implements VertexColorFunction
    {
        private final static Color DARK_BLUE = new Color(0, 0, 100);
        public Color getForeColor(Vertex v)
        {
            return Color.BLACK;
        }
        public Color getBackColor(Vertex v)
        {
            if (v.containsUserDatumKey(BarabasiAlbertGenerator.SEED))
                return DARK_BLUE;
            else
                return Color.RED;
        }
    }
    
    private final static class EdgeWeightColorStroke 
        implements EdgeColorFunction, EdgeStrokeFunction
    {
        protected static final Stroke basic = new BasicStroke(1);
        protected static final Stroke heavy = new BasicStroke(2);
        protected static final Stroke dotted = PluggableRenderer.DOTTED;

        protected boolean weighted = false;
        protected NumberEdgeValue edge_weight;
        
        public EdgeWeightColorStroke(NumberEdgeValue edge_weight)
        {
            this.edge_weight = edge_weight;
        }
        
        public void setWeighted(boolean weighted)
        {
            this.weighted = weighted;
        }
        
        public Color getEdgeColor(Edge e)
        {
            if (weighted)
            {
                float value;
                if (drawHeavy(e))
                    value = 0;
                else
                    value = 0.5f;
                return new Color(value, value, value);
            }
            else
                return Color.BLACK;
        }
        
        public Stroke getStroke(Edge e)
        {
            if (weighted)
            {
                if (drawHeavy(e))
                    return heavy;
                else
                    return dotted;
            }
            else
                return basic;
        }
        
        protected boolean drawHeavy(Edge e)
        {
            double value = edge_weight.getNumber(e).doubleValue();
            if (value > 0.7)
                return true;
            else
                return false;
        }
        
    }
    
    private final static class VertexStrokeHighlight implements VertexStrokeFunction
    {
        protected boolean highlight = false;
        protected Stroke heavy = new BasicStroke(5);
        protected Stroke medium = new BasicStroke(3);
        protected Stroke light = new BasicStroke(1);
        protected PickedInfo pi;
        
        public VertexStrokeHighlight(PickedInfo pi)
        {
            this.pi = pi;
        }
        
        public void setHighlight(boolean highlight)
        {
            this.highlight = highlight;
        }
        
        public Stroke getStroke(Vertex v)
        {
            if (highlight)
            {
                if (pi.isPicked(v))
                    return heavy;
                else
                {
                    for (Iterator iter = v.getNeighbors().iterator(); iter.hasNext(); )
                    {
                        Vertex w = (Vertex)iter.next();
                        if (pi.isPicked(w))
                            return medium;
                    }
                    return light;
                }
            }
            else
                return light; 
        }
    }
    
    private final static class FontHandler implements VertexFontFunction, EdgeFontFunction
    {
        protected boolean bold = false;
        Font f = new Font("Helvetica", Font.PLAIN, 12);
        Font b = new Font("Helvetica", Font.BOLD, 12);
        
        public void setBold(boolean bold)
        {
            this.bold = bold;
        }
        
        public Font getFont(Vertex v)
        {
            if (bold)
                return b;
            else
                return f;
        }

        public Font getFont(Edge e)
        {
            if (bold)
                return b;
            else 
                return f;
        }
    }
    
    private final static class EdgeDisplayPredicate implements Predicate
    {
        protected boolean show_d;
        protected boolean show_u;
        
        public EdgeDisplayPredicate(boolean show_d, boolean show_u)
        {
            this.show_d = show_d;
            this.show_u = show_u;
        }
        
        public void showDirected(boolean b)
        {
            show_d = b;
        }
        
        public void showUndirected(boolean b)
        {
            show_u = b;
        }

        public boolean evaluate(Object arg0)
        {
            if (arg0 instanceof DirectedEdge && show_d)
                return true;
            if (arg0 instanceof UndirectedEdge && show_u)
                return true;
            return false;
        }
    }
    
    private final static class VertexDisplayPredicate implements Predicate
    {
        protected boolean filter_small;
        protected final static int MIN_DEGREE = 4;
        
        public VertexDisplayPredicate(boolean filter)
        {
            this.filter_small = filter;
        }
        
        public void filterSmall(boolean b)
        {
            filter_small = b;
        }
        
        public boolean evaluate(Object arg0)
        {
            Vertex v = (Vertex)arg0;
            if (filter_small)
                return (v.degree() >= MIN_DEGREE);
            else
                return true;
        }
    }
    
    /**
     * Controls the shape, size, and aspect ratio for each vertex.
     * 
     * @author Joshua O'Madadhain
     */
    private final static class VertexShapeSizeAspect 
        extends AbstractVertexShapeFunction 
        implements VertexSizeFunction, VertexAspectRatioFunction
    {
        protected boolean stretch = false;
        protected boolean scale = false;
        protected boolean funny_shapes = false;
        protected NumberVertexValue voltages;
        
        public VertexShapeSizeAspect(NumberVertexValue voltages)
        {
            this.voltages = voltages;
            setSizeFunction(this);
            setAspectRatioFunction(this);
        }

        public void setStretching(boolean stretch)
        {
            this.stretch = stretch;
        }
        
        public void setScaling(boolean scale)
        {
            this.scale = scale;
        }
        
        public void useFunnyShapes(boolean use)
        {
            this.funny_shapes = use;
        }
        
        public int getSize(Vertex v)
        {
            if (scale)
                return (int)(voltages.getNumber(v).doubleValue() * 30) + 20;
            else
                return 20;
        }

        public float getAspectRatio(Vertex v)
        {
            if (stretch)
                return (float)(v.inDegree() + 1) / (v.outDegree() + 1);
            else
                return 1.0f;
        }

        public Shape getShape(Vertex v)
        {
            if (funny_shapes)
            {
                if (v.degree() < 5)
                {
                    int sides = (int)Math.max(v.degree(), 3);
                    return factory.getRegularPolygon(v, sides);
                }
                else
                    return factory.getRegularStar(v, v.degree());
            }
            else
                return factory.getEllipse(v);
        }
        
    }
    
    
}
