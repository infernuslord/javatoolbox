/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	Tiny Look and Feel                                                         *
*                                                                              *
*  (C) Copyright 2003, Hans Bickel                                             *
*                                                                              *
*   For licensing information and credits, please refer to the                 *
*   comment in file de.muntjak.tinylookandfeel.TinyLookAndFeel                 *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package de.muntjak.tinylookandfeel;

import java.awt.Component;

import javax.swing.*;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.metal.MetalInternalFrameUI;

import de.muntjak.tinylookandfeel.borders.*;

/**
 * TinyInternalFrameUI
 * 
 * @version 1.0
 * @author Hans Bickel
 */
public class TinyInternalFrameUI extends MetalInternalFrameUI {

	private TinyInternalFrameBorder frameBorder;
	
	/**
	 * The metouia version of the internal frame title pane.
	 */
	private TinyInternalFrameTitlePane titlePane;

	/**
	 * Creates the UI delegate for the given frame.
	 *
	 * @param frame The frame to create its UI delegate.
	 */
	public TinyInternalFrameUI(JInternalFrame frame) {
		super(frame);
	}

	/**
	 * Creates the UI delegate for the given component.
	 *
	 * @param mainColor The component to create its UI delegate.
	 * @return The UI delegate for the given component.
	 */
	public static ComponentUI createUI(JComponent c) {
		return new TinyInternalFrameUI((JInternalFrame) c);
	}

	JDesktopPane getDesktopPane(JComponent frame) {
		JDesktopPane pane = null;
		Component c = frame.getParent();

		// Find the JDesktopPane
		while (pane == null) {
			if(c instanceof JDesktopPane) {
				pane = (JDesktopPane) c;
			} else if (c == null) {
				break;
			} else {
				c = c.getParent();
			}
		}

		return pane;
	}

    private static DesktopManager sharedDesktopManager;
    
    protected DesktopManager getDesktopManager() {
    	if (!Theme.frameIsTransparent[Theme.style]) {
    		return super.getDesktopManager();
    	}
    	
		if(sharedDesktopManager == null) {
		  sharedDesktopManager = createDesktopManager();
		}
		
		return sharedDesktopManager;	
    }
  
    protected DesktopManager createDesktopManager() {
		if (!Theme.frameIsTransparent[Theme.style]) {
    		return super.createDesktopManager();
		}
    	else {
    		return new TinyDesktopManager();
    	}
    }

	public void installUI(JComponent c) {
		super.installUI(c);
		
		frameBorder = new TinyInternalFrameBorder(frame);
		frame.setBorder(frameBorder);
		frame.setOpaque(false);
	}
	
	/**
	 * Creates the north pane (the internal frame title pane) for the given frame.
	 *
	 * @param frame The frame to create its north pane.
	 */
	protected JComponent createNorthPane(JInternalFrame frame) {
		super.createNorthPane(frame);
		titlePane = new TinyInternalFrameTitlePane(frame);
		
		return titlePane;
	}
    protected void activateFrame(JInternalFrame f) {
		super.activateFrame(f);
		frameBorder.setActive(true);
		titlePane.activate();
    }
    /** This method is called when the frame is no longer selected.
      * This action is delegated to the desktopManager.
      */
    protected void deactivateFrame(JInternalFrame f) {
		super.deactivateFrame(f);
		frameBorder.setActive(false);
		titlePane.deactivate();
    }
	/**
	 * Changes this internal frame mode from / to palette mode.
	 * This affect only the title pane.
	 *
	 * @param isPalette The target palette mode.
	 */
	public void setPalette(boolean isPalette) {
		super.setPalette(isPalette);
		titlePane.setPalette(isPalette);
		frame.setBorder(frameBorder);
		frame.putClientProperty("isPalette",
			isPalette ? Boolean.TRUE : Boolean.FALSE);
	}
}