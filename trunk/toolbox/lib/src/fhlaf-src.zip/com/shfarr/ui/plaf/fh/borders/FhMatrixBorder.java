/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh.borders;

import javax.swing.border.*;
import javax.swing.plaf.UIResource;

import com.shfarr.ui.GraphicsUtils;
import com.shfarr.ui.plaf.fh.theme.ThemeManager;

import java.awt.*;
import java.awt.image.BufferedImage;

public class FhMatrixBorder extends AbstractBorder implements UIResource{
    protected String[][] matrix = null;
    protected Insets insets;
    protected boolean[] dash = null;
    protected boolean painting = true;
    protected int centerX = -1;
    protected int centerY = -1;
    protected BufferedImage matrixImage, topBuffer, bottomBuffer, leftBuffer, rightBuffer;

    protected FhMatrixBorder(){}

    public FhMatrixBorder(String[][] customMatrix) throws NullPointerException{
        if(customMatrix == null) throw new NullPointerException("Empty matrix");
        setMatrix(customMatrix);
    }

    public Insets getBorderInsets(Component c){
        if( !isPainting()) return new Insets(0, 0, 0, 0);

        if(this.insets == null)
                this.insets = new Insets(centerY, centerX, matrixImage.getHeight() - centerY - 1, matrixImage.getWidth() - centerX - 1);

        return insets;
    }

    public Insets getBorderInsets(Component c, Insets insets){
        Insets ins = getBorderInsets(c);

        insets.top = ins.top;
        insets.left = ins.left;
        insets.bottom = ins.bottom;
        insets.right = ins.right;

        return insets;
    }

    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height){
        Rectangle clip = g.getClipBounds();

        // top left
        if(centerX > 0 && centerY > 0){
            g.setClip(x, y, centerX, centerY);
            if(clip != null) g.setClip(clip.createIntersection(g.getClipBounds()));
            
            if(g.getClipBounds().width > 0 && g.getClipBounds().height > 0) g.drawImage(matrixImage, x, y, null);
        }

        // bottom left
        if(centerX > 0 && matrixImage.getHeight() - centerY - 1 > 0){
            g.setClip(x, y + height - (matrixImage.getHeight() - centerY - 1), centerX, matrixImage.getHeight() - centerY - 1);
            if(clip != null) g.setClip(clip.createIntersection(g.getClipBounds()));
            
            if(g.getClipBounds().width > 0 && g.getClipBounds().height > 0) g.drawImage(matrixImage, x, y + height - matrixImage.getHeight(), null);
        }

        // top right
        if(matrixImage.getWidth() - centerX - 1 > 0 && centerY > 0){
            g.setClip(x + width - (matrixImage.getWidth() - centerX - 1), y, matrixImage.getWidth() - centerX - 1, centerY);
            if(clip != null) g.setClip(clip.createIntersection(g.getClipBounds()));
            
            if(g.getClipBounds().width > 0 && g.getClipBounds().height > 0) g.drawImage(matrixImage, x + width - matrixImage.getWidth(), y, null);
        }

        // bottom left
        if(matrixImage.getWidth() - centerX - 1 > 0 && matrixImage.getHeight() - centerY - 1 > 0){
            g.setClip(x + width - (matrixImage.getWidth() - centerX - 1),
                      y + height - (matrixImage.getHeight() - centerY - 1), matrixImage.getWidth() - centerX - 1,
                      matrixImage.getHeight() - centerY - 1);

            if(clip != null) g.setClip(clip.createIntersection(g.getClipBounds()));

            if(g.getClipBounds().width > 0 && g.getClipBounds().height > 0) g.drawImage(matrixImage, x + width - matrixImage.getWidth(), y + height - matrixImage.getHeight(), null);
        }

        if(leftBuffer == null && rightBuffer == null){
            if(centerX > 0){
                leftBuffer = new BufferedImage(centerX, 100, BufferedImage.TYPE_INT_ARGB);
                Graphics ag = leftBuffer.createGraphics();

                BufferedImage a = matrixImage.getSubimage(0, centerY, centerX, 1);
                for(int i = 0; i < 100; i++)
                    ag.drawImage(a, 0, i, null);
            }

            if(matrixImage.getWidth() - centerX - 1 > 0){
                rightBuffer = new BufferedImage(matrixImage.getWidth() - centerX - 1, 100, BufferedImage.TYPE_INT_ARGB);
                Graphics ag = rightBuffer.createGraphics();

                BufferedImage b = matrixImage.getSubimage(centerX + 1, centerY, matrixImage.getWidth() - centerX - 1, 1);
                for(int i = 0; i < 100; i++)
                    ag.drawImage(b, 0, i, null);
            }
        }

        if(topBuffer == null && bottomBuffer == null){
            if(centerY > 0){
                topBuffer = new BufferedImage(100, centerY, BufferedImage.TYPE_INT_ARGB);
                Graphics ag = topBuffer.createGraphics();

                BufferedImage a = matrixImage.getSubimage(centerX, 0, 1, centerY);
                for(int i = 0; i < 100; i++)
                    ag.drawImage(a, i, 0, null);
            }

            if(matrixImage.getHeight() - centerY - 1 > 0){
                bottomBuffer = new BufferedImage(100, matrixImage.getHeight() - centerY - 1, BufferedImage.TYPE_INT_ARGB);
                Graphics ag = bottomBuffer.createGraphics();

                BufferedImage b = matrixImage.getSubimage(centerX, centerY + 1, 1, matrixImage.getHeight() - centerY - 1);
                for(int i = 0; i < 100; i++)
                    ag.drawImage(b, i, 0, null);
            }
        }

        if(topBuffer != null){
            g.setClip(x + centerX, y, width - (matrixImage.getWidth() - 1), centerY);
            if(clip != null) g.setClip(clip.createIntersection(g.getClipBounds()));

            if(g.getClipBounds().width > 0 && g.getClipBounds().height > 0) for(int i = x; i < x + width; i += 100)
                g.drawImage(topBuffer, i, y, null);
        }

        if(bottomBuffer != null){
            g.setClip(x + centerX, y + height - bottomBuffer.getHeight(), width - (matrixImage.getWidth() - 1), bottomBuffer.getHeight());
            if(clip != null) g.setClip(clip.createIntersection(g.getClipBounds()));

            if(g.getClipBounds().width > 0 && g.getClipBounds().height > 0) for(int i = x; i < x + width; i += 100)
                g.drawImage(bottomBuffer, i, y + height - bottomBuffer.getHeight(), null);
        }

        if(leftBuffer != null){
            g.setClip(x, y + centerY, centerX, height - (matrixImage.getHeight() - 1));
            if(clip != null) g.setClip(clip.createIntersection(g.getClipBounds()));

            if(g.getClipBounds().width > 0 && g.getClipBounds().height > 0) for(int i = y; i < y + height; i += 100)
                g.drawImage(leftBuffer, x, i, null);
        }

        if(rightBuffer != null){
            g.setClip(x + width - rightBuffer.getWidth(), y + centerY, rightBuffer.getWidth(), height - (matrixImage.getHeight() - 1));
            if(clip != null) g.setClip(clip.createIntersection(g.getClipBounds()));

            if(g.getClipBounds().width > 0 && g.getClipBounds().height > 0) for(int i = y; i < y + height; i += 100)
                g.drawImage(rightBuffer, x + width - rightBuffer.getWidth(), i, null);
        }
        
        g.setClip(clip);
    }

    public FhMatrixBorder deriveBorder(int rotation){
        return new FhMatrixBorder(GraphicsUtils.rotateClockwise(getMatrix(), rotation));
    }

    public boolean isPainting(){
        return painting;
    }

    public void setPainting(boolean painting){
        this.painting = painting;
    }

    public synchronized void setCenter(int cx, int cy){
        centerX = cx == -1 ? matrix[0].length / 2 : cx;
        centerY = cy == -1 ? matrix.length / 2 : cy;

        setMatrix(getMatrix());
    }

    public void dumpMatrix(String[][] matrix){
        for(int i = 0; i < matrix.length; i++){
            for(int k = 0; k < matrix[i].length; k++){
                System.out.print(matrix[i][k] + ", ");
            }

            System.out.println();
        }

        System.out.println();
    }

    protected Color getColor(String name){
        return ThemeManager.instance().getCurrentTheme().getColor(name);
    }

    public synchronized String[][] getMatrix(){
        String[][] m = GraphicsUtils.rotateClockwise(matrix, 0);

        for(int i = 0; i < m.length; i++){
            for(int k = 0; k < m[i].length; k++){
                if(m[i][k] == null) m[i][k] = "x";
                else if(m[i][k].startsWith("!")) m[i][k] = m[i][k].substring(1);
            }
        }

        boolean doubling = ThemeManager.instance().getPreferences().isBordersDoubled();
        m[doubling ? centerY / 2 : centerY][doubling ? centerX / 2 : centerX] =
                "!" + m[doubling ? centerY / 2 : centerY][doubling ? centerX / 2 : centerX];

        return m;
    }

    public int[] getCenter(){
        return new int[]{centerX, centerY};
    }

    public synchronized void setMatrix(String[][] m){
        try{
            // set the matrix
            this.matrix = GraphicsUtils.rotateClockwise(m, 0);

            // set the center
            boolean centerSet = false;

            for(int i = 0; i < matrix.length; i++){
                for(int k = 0; k < matrix[i].length; k++){
                    if(matrix[i][k] != null && matrix[i][k].indexOf("!") != -1){
                        centerX = k;
                        centerY = i;
                        centerSet = true;
                    }
                }
            }

            if( !centerSet){
                centerX = matrix[0].length / 2;
                centerY = matrix.length / 2;
            }

            // create the image
            // -------------------------------------------------------------------------
            boolean doubling = ThemeManager.instance().getPreferences().isBordersDoubled();

            if(doubling){
                centerX = 2 * centerX;
                centerY = 2 * centerY;
            }

            int[][] mi = doubling ? new int[2 * matrix.length - 1][2 * matrix[0].length - 1] : new int[matrix.length][matrix[0].length];

            boolean ceil = false;
            //dumpMatrix(m);
            for(int i = 0; i < mi.length; i++){
                for(int k = 0; k < mi[i].length; k++){
                    String val = matrix[doubling ? ceil ? (int)Math.ceil(i / 2.0) : i / 2 : i][doubling ? ceil ? (int)Math.ceil(k / 2.0)
                                                                                                              : k / 2 : k];

                    if(val == null) mi[i][k] = 0x00000000;
                    else{
                        if(val.indexOf('!') != -1){
                            mi[i][k] = val.equals("!x") ? 0x00000000 : getColor(val.substring(1)).getRGB();
                            ceil = true;
                        }
                        else mi[i][k] = val.equals("x") ? 0x00000000 : getColor(val).getRGB();
                    }
                }
            }

            matrixImage = GraphicsUtils.createTextureImage(mi, 0);
            topBuffer = leftBuffer = rightBuffer = bottomBuffer = null;
            
            insets = null;
        }
        catch (Exception e){
            System.out.println("(shfarr :: FhMatrixBorder.java) -> Caught unhandled exception: " + e);
            e.printStackTrace();
        }
    }
}
