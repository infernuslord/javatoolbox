/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.plaf.*;
import javax.swing.plaf.basic.*;

import com.shfarr.ui.layouts.QueueLayout;
import com.shfarr.ui.plaf.fh.borders.FHMultiMatrixBorder;
import com.shfarr.ui.plaf.fh.textures.Texture;
import com.shfarr.ui.plaf.fh.theme.ThemeManager;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Hashtable;


public class FhToolBarUI extends BasicToolBarUI{

	public FhToolBarUI() {
		super();
	}


	public static ComponentUI createUI(JComponent cmp){
	  return new FhToolBarUI();
	}


	public void installUI(JComponent jc){
	  super.installUI(jc);
	  
	  jc.addPropertyChangeListener(new FhPropertyChangeHandler());
	  jc.setLayout(new FhToolBarLayoutManager());
	  //installRolloverBorders(jc);
	}

    protected void installRolloverBorders(JComponent c ){
        Component[] components = c.getComponents();
        for(int i = 0; i < components.length; ++i ) setBorderToRollover(components[i]);
    }
    
    protected void installNonRolloverBorders(JComponent c ){
        Component[] components = c.getComponents();
        for(int i = 0; i < components.length; ++i ) setBorderToNonRollover(components[i]);
    }
    
    protected void setBorderToRollover(Component c){
        if(c instanceof AbstractButton) ((AbstractButton)c).setRolloverEnabled(true);
    }
    
    protected void setBorderToNonRollover(Component c){
        if(c instanceof AbstractButton) ((AbstractButton)c).setRolloverEnabled(false);
    }
    
	public void paint(Graphics g, JComponent c) {
      ThemeManager.instance().probeAntialiasing(g);

      if(c.getBorder() instanceof FHMultiMatrixBorder){
          if(((JToolBar)c).getOrientation()==JToolBar.HORIZONTAL) ((FHMultiMatrixBorder)c.getBorder()).selectMatrix("normal");
          else ((FHMultiMatrixBorder)c.getBorder()).selectMatrix("vertical");
      }
      
      super.paint(g, c);

      Insets ins = c.getInsets();
	  
	  Texture texture = (Texture)UIManager.getDefaults().get("ToolBar.texture");
	  if(texture != null && ThemeManager.instance().probeSmallTextures()) texture.apply(new Rectangle(ins.left, ins.top, c.getSize().width -ins.left -ins.right, c.getSize().height -ins.top -ins.bottom), (Graphics2D)g, c);
      
      texture = (Texture)UIManager.getDefaults().get("Toolbar.thumbTexture");
      if(texture != null && ThemeManager.instance().probeSmallTextures()){
          if(((JToolBar)c).getOrientation()==JToolBar.HORIZONTAL) texture.apply(new Rectangle(ins.left, ins.top, 13, c.getSize().height -ins.top -ins.bottom), (Graphics2D)g, c);
          else texture.apply(new Rectangle(ins.left, ins.top, c.getSize().width -ins.left -ins.right, 14), (Graphics2D)g, c);
      }
	}

    /**
     * @version test 1.0
     * @author Stefan H. Farr This software is published under the terms of
     *         General Public License
     */
	protected class FhPropertyChangeHandler implements PropertyChangeListener{
		public void propertyChange(PropertyChangeEvent e){
		  for(int i=0; i<((Container)e.getSource()).getComponentCount(); i++){
		      if(((Container)e.getSource()).getComponent(i) instanceof JSeparator){
		         ((JSeparator)((Container)e.getSource()).getComponent(i)).setOrientation(((JToolBar)e.getSource()).getOrientation() == JToolBar.HORIZONTAL ? JSeparator.VERTICAL : JSeparator.HORIZONTAL);
		      }
		  }
		}
	}


    /**
     * @version test 1.0
     * @author Stefan H. Farr This software is published under the terms of
     *         General Public License
     */
	public class FhToolBarLayoutManager extends QueueLayout{
		protected Hashtable popupHash = null;
	
	
		public FhToolBarLayoutManager(){
		  super(2, HORIZONTAL, CENTER_COMPONENTS);
		  popupHash = new Hashtable();
		}
	
	
		public JPopupMenu createMorePopup(Container c, int index){
		  JPopupMenu menu = new JPopupMenu();
		  menu.setLayout(new QueueLayout());
		
		  Component[] cps = c.getComponents();
		
		  for(int i=index; i<cps.length && index >= 0; i++){
			  if(!cps[i].isVisible()) continue;
			  Border b = ((JComponent)cps[i]).getBorder();
			  c.remove(cps[i]);
			  menu.add(cps[i]);
			  ((JComponent)cps[i]).setBorder(b);
		  }
		
		  popupHash.put(c, menu);
		
		  return menu;
		}
		
		
		protected int getBreakIndex(Container c){
		   Component[] cps = c.getComponents();
//		   if(true) return cps.length;
		   Dimension d = getMaxSize(c);
		   Dimension cs = usableSize(c);
		
		   int index = cps.length -1;
		
		
		   if(((JToolBar)c).getOrientation()==JToolBar.HORIZONTAL){
		      while(d.width > cs.width){
			        if(!cps[index].isVisible()) continue;
		
			        d.width -= cps[index].getPreferredSize().width; 
			        index--;
		      }
		
		      if(index +1 < cps.length && d.width > cs.width -20) index--;
		   }
		   else{
		        while(d.height > cs.height){
			          if(!cps[index].isVisible()) continue;
		
			          d.height -= cps[index].getPreferredSize().height; 
			          index--;
		        }
		
		        if(index +1 < cps.length && d.height > cs.height -20) index--;
		   }
		    
		   return index +1;
		}
		
		
		protected Dimension getMaxSize(Container c){
		   Component[] cps = c.getComponents();
		   Dimension d = new Dimension(0, 0);
		
		   for(int i=0; i<cps.length; i++){
			   if(!cps[i].isVisible()) continue;
		
			   if(((JToolBar)c).getOrientation()==JToolBar.HORIZONTAL){
			      d.width += cps[i].getPreferredSize().width; 
			      if(!(cps[i] instanceof JToolBar.Separator)) d.height = Math.max(cps[i].getPreferredSize().height, d.height);
			   }
			   else{
			        d.width = Math.max(cps[i].getPreferredSize().width, d.width); 
			        if(!(cps[i] instanceof JToolBar.Separator)) d.height += cps[i].getPreferredSize().height;
			   }
		   }
		
		   return d;
		}
		
        protected void performLayout(Container parent){
          Component[] cps = parent.getComponents();
          Insets ins = parent.getInsets();
          Dimension cPrefSize = null,
                    pSize = parent.getSize();
    
          int offset = 0;
    
          int startOffset = (orientation == VERTICAL ? ins.top : ins.left) +16,
              availSpace = (orientation == VERTICAL ? pSize.height -ins.bottom -ins.top : pSize.width -ins.right -ins.left) -16,
              endOffset = startOffset +availSpace +getGap(),
              mobileVal = 0;
    
          for(int i=0; i<cps.length; i++){
              if(!cps[i].isVisible()) continue;
    
              cPrefSize = cps[i].getPreferredSize()!=null ? cps[i].getPreferredSize() : new Dimension(20, 20);
              mobileVal = orientation==VERTICAL ? cPrefSize.height : cPrefSize.width;
    
              //availSpace -= mobileVal;
    
              if(BEGIN.equals(getConstraintsFor(cps[i]))){
                 offset = startOffset;
                 startOffset += mobileVal +getGap();
              }
              else{
                   endOffset -=  mobileVal +getGap();
                   offset = endOffset;
              }
    
              // CENTER_COMPONENTS by default
              int x = ins.left + (pSize.width -ins.left -ins.right -cPrefSize.width)/2,
                  y = ins.top + (pSize.height -ins.top -ins.bottom -cPrefSize.height)/2,
                  w = cPrefSize.width,
                  h = cPrefSize.height;
    
              if(alignment==STRECH_COMPONENTS){
                 x = ins.left;
                 y = ins.top;
                 w = pSize.width -ins.right -ins.left;
                 h = pSize.height -ins.top -ins.bottom;
              }
          
          
              if(cps[i] instanceof JSeparator){
                 x = ins.left +2;
                 y = ins.top +2;
                 w = pSize.width -ins.right -ins.left -4;
                 h = pSize.height -ins.top -ins.bottom -4;
              }
    
              if(orientation==VERTICAL) cps[i].setBounds(x, offset, w, mobileVal);
              else cps[i].setBounds(offset, y, mobileVal, h);
    
              availSpace -= getGap() +mobileVal;
          }
        }
		
		public void layoutContainer(Container parent){
            if(parent instanceof JToolBar){
               if(((JToolBar)parent).getOrientation()==JToolBar.HORIZONTAL) orientation = HORIZONTAL;
               else orientation = VERTICAL;
            }

            super.layoutContainer(parent);
		}
		
		
		public Dimension preferredLayoutSize(Container parent){
		  int preferredOrientation = getOrientation();
		
		  if(parent instanceof JToolBar){
		     if(((JToolBar)parent).getOrientation()==JToolBar.HORIZONTAL) orientation = HORIZONTAL;
		     else orientation = VERTICAL;
		  }
		
		  Dimension d = super.preferredLayoutSize(parent);

          if(parent instanceof JToolBar){
             if(((JToolBar)parent).getOrientation()==JToolBar.HORIZONTAL) d.width += 16;
             else  d.height += 16;
          }
		
		  orientation = preferredOrientation;
		
		  return d;
		}
		
		
		protected void showPopup(Container src){
		  JPopupMenu popup = (JPopupMenu)popupHash.get(src);
		  
		  Point point = null;
		  JRootPane rp = SwingUtilities.getRootPane(src);
		
		  if(((JToolBar)src).getOrientation()==JToolBar.HORIZONTAL){
			 point = new Point(src.getSize().width -popup.getPreferredSize().width -1, rp.getSize().height > src.getLocation().y +popup.getPreferredSize().height
				                                                                       ? src.getSize().height -1
				                                                                       : -popup.getPreferredSize().height);
		  }
		  else{
			   point = new Point(rp.getSize().width > src.getLocation().x +popup.getPreferredSize().width
				                 ? src.getSize().width -1
				                 : -popup.getPreferredSize().width, src.getSize().height -popup.getPreferredSize().height -1);
		  }
		
		  point = SwingUtilities.convertPoint(src, point, rp);
		  popup.show(rp, point.x, point.y);
		}
	
	
		protected Dimension usableSize(Container c){
		  Dimension d = c.getSize();
		
		  Insets ins = c.getInsets()!=null ? c.getInsets() : new Insets(0, 0, 0, 0);
		
		  d.width -= ins.left +ins.right;
		  d.height -= ins.top +ins.bottom;
		  
		  return d;
		}
	}
}
