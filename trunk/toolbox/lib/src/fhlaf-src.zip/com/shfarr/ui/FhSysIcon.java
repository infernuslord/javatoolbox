/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui;

import javax.swing.*;
import javax.swing.plaf.UIResource;
import java.awt.Color;
import java.awt.Rectangle;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Arc2D;


public class FhSysIcon implements Icon, UIResource{
	public static final int CHECK_BOX = 0;
	public static final int RADIO_BUTTON = 1;
	public static final int CHECK_BOX_MENU_ITEM = 3;
	public static final int RADIO_BUTTON_MENU_ITEM = 4;
	public static final int ARROW = 5;
    public static final int MORE = 200;
	
	protected int type = 0;
	private int rotation = 0;

    public FhSysIcon(int type){
        this(type, 0);
    }

    public FhSysIcon(int type, int rotation){
		super();
        
		this.type = type;
        this.rotation = rotation;
	}


	public int getIconHeight(){
	  switch(type){
	         case RADIO_BUTTON : return 19;
	         case CHECK_BOX : return 19;
	         case RADIO_BUTTON_MENU_ITEM : return 15;
	         case CHECK_BOX_MENU_ITEM : return 15;
	         case ARROW : return 13;
             case MORE : return 18;
	         
	         default : return 12;
	  }
	}
	
	
	public int getIconWidth(){
	  switch(type){
	         case RADIO_BUTTON : return 19;
	         case CHECK_BOX : return 19;
	         case RADIO_BUTTON_MENU_ITEM : return 15;
	         case CHECK_BOX_MENU_ITEM : return 15;
	         case ARROW : return 13;
             case MORE : return 18;
	         
	         default : return 12;
	  }
	}
	
	
	protected int[][] getMatrix(int type, int c){
	  int[][] matrix = null;
	  
	  switch(type){
	  	     case FhSysIcon.MORE : matrix = new int[][]{{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                                                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                                                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                                                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                                                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                                                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                                                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                                                        {c, c, 0, 0, 0, c, c, 0, 0, 0, c, c},
                                                        {c, c, 0, 0, 0, c, c, 0, 0, 0, c, c},
                                                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                                                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                                                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
                                                        };
                                             break;

		     case FhSysButton.MINIMIZER : matrix = new int[][]{{c, c, c, c, c, c, c},
			                                                   {0, c, c, c, c, c, 0},
			                                                   {0, 0, c, c, c, 0, 0},
			                                                   {0, 0, 0, c, 0, 0, 0},
			                                                   {0, 0, 0, 0, 0, 0, 0},
			                                                   {c, c, c, c, c, c, c},
			                                                   {c, c, c, c, c, c, c},
		                                                       };
		                                      break;
	
		     case FhSysButton.MAXIMIZER : matrix = new int[][]{{0, c, c, c, c, c, c},
			                                                   {0, 0, c, c, c, c, c},
			                                                   {0, 0, 0, c, c, c, c},
			                                                   {0, 0, c, c, c, c, c},
			                                                   {0, c, c, c, 0, c, c},
			                                                   {0, 0, c, 0, 0, 0, c},
			                                                   {0, 0, 0, 0, 0, 0, 0},
		                                                       };
		                                      break;

		     case FhSysButton.RESTORER : matrix = GraphicsUtils.rotateClockwise(getMatrix(FhSysButton.MAXIMIZER, c), GraphicsUtils.ROTATE_180);
                                         break;
	
	
		     case FhSysButton.CLOSER : matrix = new int[][]{{0, c, 0, 0, 0, c, 0},
			                                                {c, c, c, 0, c, c, c},
			                                                {0, c, c, c, c, c, 0},
			                                                {0, 0, c, c, c, 0, 0},
			                                                {0, c, c, c, c, c, 0},
			                                                {c, c, c, 0, c, c, c},
			                                                {0, c, 0, 0, 0, c, 0},
		                                                    };
		                                   break;
	
	
	  }
	
	  return matrix;
	}


	public void paintIcon(java.awt.Component c, java.awt.Graphics g, int x, int y){
	  if(this.type==CHECK_BOX){
         ImageIcon icon = (ImageIcon)UIManager.getDefaults().getIcon(c instanceof AbstractButton && ((AbstractButton)c).isSelected() ? "CheckBox.selectedIcon" : "CheckBox.unselectedIcon");
         if(!c.isEnabled()) icon = GraphicsUtils.applyFilter(icon, new ChannelImageFilter(0.5, 0, 0, 0)); 
          
	     icon.paintIcon(c, g, x +2, y +2);

	     if(c.hasFocus() && c instanceof AbstractButton && ((AbstractButton)c).isFocusPainted()){
	        g.setColor(UIManager.getColor("Component.moderatedShadow"));
	        g.drawRect(x, y, 18, 18);
	     }
	     
	     return;
	  }

      if(this.type == RADIO_BUTTON){
          ImageIcon icon = (ImageIcon)UIManager.getDefaults().getIcon(c instanceof AbstractButton && ((AbstractButton)c).isSelected() ? "RadioButton.selectedIcon" : "RadioButton.unselectedIcon");
          if(!c.isEnabled()) icon = GraphicsUtils.applyFilter(icon, new ChannelImageFilter(0.5, 0, 0, 0)); 
          
          icon.paintIcon(c, g, x +2, y +2);

          if(c.hasFocus() && c instanceof AbstractButton && ((AbstractButton)c).isFocusPainted()){
             g.setColor(UIManager.getColor("Component.moderatedShadow"));
             ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
             ((Graphics2D)g).draw(new Arc2D.Float(x, y, 18, 18, 0, 360, Arc2D.CHORD));
          }
         
          return;
      }

	  if(this.type==CHECK_BOX_MENU_ITEM){
          ImageIcon icon = (ImageIcon)UIManager.getDefaults().getIcon(c instanceof AbstractButton && ((AbstractButton)c).isSelected() ? "CheckBoxMenuItem.selectedIcon" : "CheckBoxMenuItem.unselectedIcon");
          if(!c.isEnabled()) icon = GraphicsUtils.applyFilter(icon, new ChannelImageFilter(0.5, 0, 0, 0)); 
          
          icon.paintIcon(c, g, x, y);

	      return;
	  }

	
	  if(this.type==RADIO_BUTTON_MENU_ITEM){
          ImageIcon icon = (ImageIcon)UIManager.getDefaults().getIcon(c instanceof AbstractButton && ((AbstractButton)c).isSelected() ? "RadioButtonMenuItem.selectedIcon" : "RadioButtonMenuItem.unselectedIcon");
          if(!c.isEnabled()) icon = GraphicsUtils.applyFilter(icon, new ChannelImageFilter(0.5, 0, 0, 0)); 
          
          icon.paintIcon(c, g, x, y);

		  return;
	  }

	
	  if(this.type==ARROW){
		 FhSysButton.paintArrow(c, g, FhSysButton.ARROW_EAST, new Rectangle(x +4, y +2, c.getSize().height -2*(y +2), c.getSize().height -2*(y +2)), (Color)UIManager.getDefaults().get("EditableComponent.background"), c.getForeground());

		 return;
	  }
	
	 
	  if(this.type >= 100){
	     g.drawImage(GraphicsUtils.createTextureImage(getMatrix(type, 0xFFFFFFFF), rotation), x +4, y +4, null);	   
	     g.drawImage(GraphicsUtils.createTextureImage(getMatrix(type, c.getForeground().getRGB()), rotation), x +3, y +3, null);	   

	     return;
	  }
	}
}
