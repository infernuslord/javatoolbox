/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	Liquid Look and Feel                                                   *
*                                                                              *
*  Author, Miroslav Lazarevic                                                  *
*                                                                              *
*   For licensing information and credits, please refer to the                 *
*   comment in file com.birosoft.liquid.LiquidLookAndFeel                      *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package com.birosoft.liquid;

import java.awt.Graphics;

import javax.swing.JComponent;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicTextFieldUI;
import javax.swing.text.JTextComponent;


public class LiquidTextFieldUI extends BasicTextFieldUI
{
    
    JTextField textField;
    /**
     * Method createUI.
     * @param c
     * @return ComponentUI
     */
    public static ComponentUI createUI(JComponent c)
    {
        return new LiquidTextFieldUI();
    }
    
    /**
     * @see javax.swing.plaf.basic.BasicTextFieldUI#installUI(javax.swing.JComponent)
     */
    public void installUI(JComponent c)
    {
        super.installUI(c);
        textField=(JTextField)c;
    }
    
    protected void paintBackground(Graphics g)
    {
        JTextComponent editor=getComponent();
        if (editor.isEnabled())
        {
            g.setColor(editor.getBackground());
        } else
        {
            g.setColor(UIManager.getDefaults().getColor("TextField.disabledBackground"));
        }
        g.fillRect(0, 0, editor.getWidth(), editor.getHeight());
    }
}