/*
 *   The contents of this file are subject to the Mozilla Public License
 *   Version 1.1 (the "License"); you may not use this file except in
 *   compliance with the License. You may obtain a copy of the License at
 *   http://www.mozilla.org/MPL/
 *
 *   Software distributed under the License is distributed on an "AS IS"
 *   basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 *   License for the specific language governing rights and limitations
 *   under the License.
 *
 *   The Original Code is Matra - the DTD Parser.
 *
 *   The Initial Developer of the Original Code is Conrad S Roche.
 *   Portions created by Conrad S Roche are Copyright (C) Conrad 
 *   S Roche. All Rights Reserved.
 *
 *   Alternatively, the contents of this file may be used under the terms
 *   of the GNU GENERAL PUBLIC LICENSE Version 2 or any later version
 *   (the  "[GPL] License"), in which case the
 *   provisions of GPL License are applicable instead of those
 *   above.  If you wish to allow use of your version of this file only
 *   under the terms of the GPL License and not to allow others to use
 *   your version of this file under the MPL, indicate your decision by
 *   deleting  the provisions above and replace  them with the notice and
 *   other provisions required by the GPL License.  If you do not delete
 *   the provisions above, a recipient may use your version of this file
 *   under either the MPL or the GPL License."
 *
 *   [NOTE: The text of this Exhibit A may differ slightly from the text of
 *   the notices in the Source Code files of the Original Code. You should
 *   use the text of this Exhibit A rather than the text found in the
 *   Original Code Source Code for Your Modifications.]
 *
 * Created: Conrad S Roche <derupe at users.sourceforge.net>,  13-Aug-2003
 */
package com.conradroche.matra.test.decl;

import com.conradroche.matra.decl.ElementType;
import com.conradroche.matra.exception.DTDException;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * JUnit test case for the ElementType class.
 * 
 * @author Conrad Roche
 */
public class ElementTypeTest extends TestCase {

	ElementType elem;
	/**
	 * Constructor for ElementTypeTest.
	 * @param arg0
	 */
	public ElementTypeTest(String arg0) {
		super(arg0);
	}

	/*
	 * @see TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
	}

	/**
	 * Returns a test suite with ElementTypeTest.
	 * 
	 * @return
	 */
	public static Test suite() {

		TestSuite suite = new TestSuite();

		suite.addTestSuite(ElementTypeTest.class);

		return suite;
	}

	/*
	 * Test for void ElementType()
	 */
	public void testElementType() {
	}
	
	/**
	 * CR: JavaDoc: Add javadoc for ElementTypeTest::testMissingContentModel
	 */
	public void testMissingContentModel() {
		
		//empty string
		try {
			elem = new ElementType("");
		} catch(DTDException dt) {
			//CR: TODO: What to check here?
		}

		//null string
		try {
			elem = new ElementType(null);
		} catch(DTDException dt) {
			//CR: TODO: What to check here?
		} catch(NullPointerException ne) {
			Assert.fail("NullPointerException caught");
		}
	}

	/**
	 * CR: JavaDoc: Add javadoc for ElementTypeTest::testAnyContentModel
	 */	
	public void testAnyContentModel() {
		emptyAnyContentModelTest("ANY");
	}

	/**
	 * CR: JavaDoc: Add javadoc for ElementTypeTest::testEmptyContentModel
	 */	
	public void testEmptyContentModel() {
		emptyAnyContentModelTest("EMPTY");
	}

	/**
	 * CR: JavaDoc: Add javadoc for ElementTypeTest::emptyAnyContentModelTest
	 * 
	 * @param emptyAny
	 */	
	private void emptyAnyContentModelTest(String emptyAny) {
		/*
		[45] elementdecl ::= '<!ELEMENT' S Name S contentspec S? '>' [VC: Unique Element Type
		Declaration]
		[46] contentspec ::= 'EMPTY' | 'ANY' | Mixed | children 
		*/
		
		String[] S = {" ", "\t", "\n", "\r", "\t \n"};
		String[] elemName = {"foobar"};
		
		StringBuffer sb;
		
		for(int i = 0; i < elemName.length; i++) {
				sb = new StringBuffer();
				
				//CR: TODO: Do not add "<!ELEMENT" since it does not currently expect it.
//				sb.append("<!ELEMENT ");
				sb.append(elemName[i]).append(" ");
				sb.append(emptyAny);
//				  .append(">");
				  
				try {		
					elem = new ElementType(sb.toString());
				} catch(DTDException de) {
//					de.printStackTrace();
					Assert.fail("DTDException caught - " + de.getMessage());
				}
		}

		for(int i = 0; i < elemName.length; i++) {
			for(int j = 0; j < S.length; j++) {
				sb = new StringBuffer();
//				sb.append("<!ELEMENT");
				sb.append(S[j])
				  .append(elemName[i]).append(S[j])
				  .append(emptyAny).append(S[j]);
//				  .append(">");
				  
				try {		
					elem = new ElementType(sb.toString());
				} catch(DTDException de) {
//					de.printStackTrace();
					Assert.fail("DTDException caught - " + de.getMessage());
				}
			}
		}

	}

	/*
	 * Test for void ElementType(String)
	 */
	public void testElementTypeString() {
	}

	public void testGetAttList() {
	}

	public void testGetAttributeNames() {
	}

	public void testGetChildOptionality() {
	}

	public void testGetChildren() {
	}

	public void testGetChildrenNames() {
	}

	public void testGetName() {
	}

	public void testGetParentNames() {
	}

	public void testHasChildren() {
	}

	public void testIsAnyContentModel() {
	}

	public void testIsEmptyContentModel() {
	}

	public void testLoad() {
	}

	public void testSetAttList() {
	}

	public void testSetAttributeNames() {
	}

	public void testSetChildren() {
	}

	public void testSetChildrenNames() {
	}

	public void testSetName() {
	}

	public void testSetParentNames() {
	}

	/*
	 * Test for String toString()
	 */
	public void testToString() {
	}

}
