package tool;

import java.io.File;
import java.io.PrintStream;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Enumeration;
import java.util.Properties;
import java.nio.charset.Charset;

import phelps.awt.NFont;
import phelps.io.FileList;



/**
	Report various system information.

	@version $Revision: 1.2 $ $Date: 2004/01/07 10:58:50 $
*/
public class Info {
  static final boolean DEBUG = true;

  public static final String VERSION = "1.0 of $Date: 2004/01/07 10:58:50 $";
  public static final String USAGE = "java tool.Info [options]\n"
	+ "\t[-verbose]";




  private boolean fverbose_, fquiet_;
  private PrintStream out_;

  public Info() {
	defaults();
  }

  public void defaults() {
	fverbose_ = fquiet_ = false;
	out_ = phelps.io.PrintStreams.DEVNULL;
  }

  public void setOut(PrintStream out) { out_ = out!=null? out: phelps.io.PrintStreams.DEVNULL; }



  public void info() {
	out_.println("System info "+new java.util.Date());
	out_.println();

	// Multivalent version
	out_.println("Multivalent v"+multivalent.Multivalent.VERSION);

	/*out_.println("\n\n*** JARs ***\n\n");
	URL[] urls = ((URLClassLoader)Multivalent.getInstance().getClass().getClassLoader()).getURLs();
	for (int i=0,imax=urls.length; i<imax; i++) sb.append(urls[i]).append("\n");
	*/

	// operating system
	out_.println();

	out_.println("*** Filesystem Roots ***");
	for (File root: File.listRoots()) out_.println(root);
	out_.println();

	out_.println("*** Properties ***");
	Properties props = System.getProperties();
	for (Enumeration e=props.keys(); e.hasMoreElements(); ) {
		Object key=e.nextElement();
		out_.println(key+": "+props.get(key));
	}
	out_.println();

	out_.println("*** NFonts ***");	// => want fonts.fl so get flags and more
	String[] names = NFont.getFontManager().getAvailableNames();
	for (int i=0,imax=names.length; i<imax; i++) out_.println(names[i]/*+"\t"+flags*/);
	out_.println();

	// returns logical names, not face names for Java 2D
	out_.println("*** AWT Fonts ***");
	String[] fam = java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
	for (int i=0,imax=fam.length; i<imax; i++) out_.println(fam[i]);
	out_.println();

	if (fverbose_) {
		out_.println("*** Font Files ***");
		for (Iterator<File> i = new FileList(File.listRoots(), NFont.FILTER).iterator(); i.hasNext(); ) out_.println(i.next());
	}

	out_.println("*** Charsets ***");
	Map<String,Charset> cs = Charset.availableCharsets();
	for (Iterator<String> i = cs.keySet().iterator(); i.hasNext(); ) out_.println(i.next());
	out_.println();
  }



  private int commandLine(String[] argv) {
	out_ = System.out;

	int argi = 0, argc = argv.length;
	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.startsWith("-verb")) fverbose_ = true;
		else if (arg.startsWith("-q"/*uiet*/)) fquiet_ = true;
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.equals("-help")) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	//if (argi == argc) { System.err.println(USAGE); System.exit(0); }

	return argi;
  }

  public static void main(String[] argv) {
	Info info = new Info();
	int argi = info.commandLine(argv);

	try {
		info.info();
	} catch (Exception e) {
		e.printStackTrace();
	}
	System.exit(0);
  }
}
