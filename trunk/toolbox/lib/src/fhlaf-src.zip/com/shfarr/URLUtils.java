package com.shfarr;

/**
 * $COPYRIGHT$
 * $Id: URLUtils.java,v 1.3 2004/06/22 18:53:22 borzy Exp $
 * 
 * Created on: May 5, 2004
 * Author: Borsos Szabolcs
 */

public class URLUtils {
    private static URLUtils urlUtils;

    private URLUtils() {
        
    }
    
    public static URLUtils getInstance() {
        if (urlUtils == null) {
            urlUtils = new URLUtils();
        }
        
        return urlUtils;
    }
    
    public String normalizePath(String path) {
        while (path.endsWith("/") || path.endsWith("\\")) {
            path = path.substring(0, path.length() - 1);
        }
        
//        StringBuffer buffer = new StringBuffer(path);
//        int index = 0;
//        while ((index = buffer.indexOf("\\", index)) != -1) {
//            if (buffer.charAt(index + 1) != '\\') {
//                buffer.insert(index, "\\");
//                index += 2;
//            }
//        }
        
        return path.replace('\\', '/');
    }
    
    public String getFileName(String url) {
        int slashIndex = url.lastIndexOf("\\") + 1;
        int backslashIndex = url.lastIndexOf("/") + 1;
        return slashIndex != 0 || backslashIndex != 0 ? url.substring(slashIndex < backslashIndex ? backslashIndex : slashIndex) : "";
    }
}
