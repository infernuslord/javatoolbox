package tool.lucene;

import java.io.File;
import java.io.IOException;
import java.io.Reader;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.search.*;
import org.apache.lucene.analysis.*;
import org.apache.lucene.analysis.standard.*;
import org.apache.lucene.document.*;

import phelps.io.Files;



/**
	Command-line interface to <a href='http://jakarta.apache.org/lucene/docs/index.html'> searching.
	See <a href='http://jakarta.apache.org/lucene/docs/queryparsersyntax.html'>Lucene query syntax</a>.
	Assumes that the Lucene JAR is in the CLASSPATH.

	@see tool.lucene.Index

	@version $Revision: 1.6 $ $Date: 2003/08/28 20:31:42 $
*/
public class Search {
  public static final String VERSION = "1.1 of $Date: 2003/08/28 20:31:42 $";
  public static final String USAGE = "java tool.lucene.Search [options] <search-expression>\n"
	+ "\t[-maxhits <max-hits>] [-index <directory>]";

  static final String[] STOP_WORDS = {
	// start with StopAnalyzer.ENGLISH_STOP_WORDS
	"a", "and", "are", "as", "at", "be", "but", "by",
	"for", "if", "in", "into", "is", "it",
	"no", "not", "of", "on", "or", "s", "such",
	"t", "that", "the", "their", "then", "there", "these",
	"they", "this", "to", "was", "will", "with",

	// and add these
	// "an", "am" => filter out 1- and 2-letter words anyhow
  };

  /** Analyzer used in searching.  Indexing should use the same analyzer. */
  public static final Analyzer ANALYZER = new Analyzer() {
	public final TokenStream tokenStream(String fieldName, Reader reader) {
		TokenStream ts = new StandardTokenizer(reader);
		ts = new StandardFilter(ts);    // acronyms, contractions
		ts = new ShortFilter(ts, 3);
		ts = new AccentFilter(ts);
		ts = new LowerCaseFilter(ts);
		ts = new StopFilter(ts, STOP_WORDS);
		ts = new PorterStemFilter(ts);
		return ts;
	}
  };



  private File index_;
  private int hitsmax_;
  private boolean fverbose_;

  private IndexReader r_ = null;


  public Search() {
	defaults();
  }

  public void defaults() {
	index_ = Files.getFile("~/.lucene");
	hitsmax_ = 10;
	fverbose_ = false;
  }

  //public void setIndex(File index) {}


  /** Searches index with <var>query</var>, and prints at most <var>max</var> hits. */
  public void search(String query) throws IOException, ParseException {
	if (r_==null) r_ = IndexReader.open(index_);

	QueryParser qp = new QueryParser("body", ANALYZER);

	Query q = qp.parse(query);
	if (fverbose_) { System.out.println("input query: |"+query+"|"); System.out.println("parsed query: "+q); }

	Searcher searcher = new IndexSearcher(r_);
	Hits hits = searcher.search(q);
	int hitcnt = hits.length();

	if (fverbose_) System.out.println(r_.numDocs()+" documents indexed");
	for (int i=0, imax=Math.min(hitcnt, hitsmax_); i<imax; i++) {
		Document doc = hits.doc(i);
		String suri = doc.get("uri");
		if (suri.startsWith("file:")) suri = suri.substring("file:".length());
		System.out.println(hits.score(i)+"   "+suri);
	}

	searcher.close();   // Hits calls back to Searcher
	System.out.println(hitcnt+" Results" + (hitcnt <= hitsmax_? "": (", first "+hitsmax_+" (-maxhits <num> for more)")) + ":");
  }

  public void close() throws IOException {
	r_.close();
  }



  private int commandLine(String[] argv) {
	int argi = 0, argc = argv.length;
	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.startsWith("-ind")) index_ = Files.getFile(argv[++argi]);
		else if (arg.startsWith("-hit"/*smax*/) || arg.startsWith("-max"/*hits*/)) {
			String num = argv[++argi];
			if (num.equals("all")) hitsmax_ = Integer.MAX_VALUE;
			else try { hitsmax_ = Integer.parseInt(num); } catch (NumberFormatException nfe) { System.err.println("can't parse \""+argv[argi]+"\" as number"); System.exit(1); }
		}

		else if (arg.startsWith("-verb")) fverbose_ = true;
		else if (arg.startsWith("-q"/*uiet*/)) {}
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.startsWith("-h"/*"elp"*/)) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	if (argi == argc) { System.err.println(USAGE); System.exit(0); }

	return argi;
  }

  public static void main(String[] argv) {
	Search lu = new Search();
	int argi = lu.commandLine(argv);

	// paste together shell tokenization
	int qlen = argv.length - argi;
	String query = argv[argi];
	if (qlen > 1) {
		StringBuffer sb = new StringBuffer(query);
		for (int i=argi+1, imax=argv.length; i<imax; i++) sb.append(' ').append(argv[i]);
		query = sb.toString();
	}

	try {
		lu.search(query);
		lu.close();

	} catch (ParseException pe) {
		System.out.println("invalid query: "+pe);

	} catch (IOException ioe) {
		System.err.println(ioe);
		ioe.printStackTrace();
	}
  }
}
