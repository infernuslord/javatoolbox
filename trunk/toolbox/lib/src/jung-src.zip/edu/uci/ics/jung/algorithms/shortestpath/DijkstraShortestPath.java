/*
* Copyright (c) 2003, the JUNG Project and the Regents of the University 
* of California
* All rights reserved.
*
* This software is open-source under the BSD license; see either
* "license.txt" or
* http://jung.sourceforge.net/license.txt for a description.
*/
package edu.uci.ics.jung.algorithms.shortestpath;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import edu.uci.ics.jung.graph.Edge;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.graph.decorators.ConstantEdgeValue;
import edu.uci.ics.jung.graph.decorators.NumberEdgeValue;
import edu.uci.ics.jung.utils.MapBinaryHeap;

/**
 * <p>Calculates distances in a specified graph, using  
 * Dijkstra's single-source-shortest-path algorithm.  All edge weights
 * in the graph must be nonnegative; if any edge with negative weight is 
 * found in the course of calculating distances, an 
 * <code>IllegalArgumentException</code> will be thrown.
 * (Note: this exception will only be thrown when such an edge would be
 * used to update a given tentative distance;
 * the algorithm does not check for negative-weight edges "up front".)
 * 
 * <p>Distances and partial results are optionally cached (by this instance)
 * for later reference.  Thus, if the 10 closest vertices to a specified source 
 * vertex are known, calculating the 20 closest vertices does not require 
 * starting Dijkstra's algorithm over from scratch.</p>
 * 
 * <p>Distances are stored as double-precision values.  
 * If a vertex is not reachable from the specified source vertex, no 
 * distance is stored.  <b>This is new behavior with version 1.4</b>;
 * the previous behavior was to store a value of 
 * <code>Double.POSITIVE_INFINITY</code>.  This change gives the algorithm
 * an approximate complexity of O(kD log k), where k is either the number of
 * requested targets or the number of reachable vertices (whichever is smaller),
 * and D is the average degree of a vertex.</p>
 * 
 * <p> The elements in the maps returned by <code>getDistanceMap</code> 
 * and <code>getIncomingEdgeMap</code> are ordered (that is, returned 
 * by the iterator) by nondecreasing distance from <code>source</code>.</p>
 * 
 * <p>Users are cautioned that distances calculated should be assumed to
 * be invalidated by changes to the graph, and should invoke <code>reset()</code>
 * when appropriate so that the distances can be recalculated.</p>
 * 
 * @author Joshua O'Madadhain
 */
public class DijkstraShortestPath extends ShortestPath implements Distance
{
    protected Graph g;
    protected NumberEdgeValue nev;
    protected Map sourceMap;   // a map of source vertices to an instance of SourceData
    protected boolean cached;
    protected static final NumberEdgeValue dev = new ConstantEdgeValue(new Integer(1));
    
    /**
     * <p>Creates an instance of <code>DijkstraShortestPath</code> for 
     * the specified graph and the specified method of extracting weights 
     * from edges, which caches results locally if and only if 
     * <code>cached</code> is <code>true</code>.
     * 
     * @param g     the graph on which distances will be calculated
     * @param nev   the class responsible for returning weights for edges
     * @param cached    specifies whether the results are to be cached
     */
    public DijkstraShortestPath(Graph g, NumberEdgeValue nev, boolean cached)
    {
        this.g = g;
        this.nev = nev;
        this.sourceMap = new HashMap();
        this.cached = cached;
    }
    
    /**
     * <p>Creates an instance of <code>DijkstraShortestPath</code> for 
     * the specified graph and the specified method of extracting weights 
     * from edges, which caches results locally.
     * 
     * @param g     the graph on which distances will be calculated
     * @param nev   the class responsible for returning weights for edges
     */
    public DijkstraShortestPath(Graph g, NumberEdgeValue nev)
    {
        this(g, nev, true);
    }
    
    /**
     * <p>Creates an instance of <code>DijkstraShortestPath</code> for 
     * the specified unweighted graph (that is, all weights 1) which
     * caches results locally.
     * 
     * @param g     the graph on which distances will be calculated
     */ 
    public DijkstraShortestPath(Graph g)
    {
        this(g, dev, true);
    }

    /**
     * <p>Creates an instance of <code>DijkstraShortestPath</code> for 
     * the specified unweighted graph (that is, all weights 1) which
     * caches results locally.
     * 
     * @param g     the graph on which distances will be calculated
     * @param cached    specifies whether the results are to be cached
     */ 
    public DijkstraShortestPath(Graph g, boolean cached)
    {
        this(g, dev, cached);
    }
    
    /**
     * Implements Dijkstra's single-source shortest-path algorithm for
     * weighted graphs.  Uses a <code>MapBinaryHeap</code> as the priority queue, 
     * which gives this algorithm a time complexity of O(m lg n) (m = # of edges, n = 
     * # of vertices).
     * This algorithm will terminate when any of the following have occurred (in order
     * of priority):
     * <ul>
     * <li> the distance to the specified target (if any) has been found
     * <li/> no more vertices are reachable 
     * <li> the specified # of distances have been found
     * <li> all distances have been found
     * </ul>
     * 
     * @param source    the vertex from which distances are to be measured
     * @param numDests  the number of distances to measure
     * @param distances vertex-distance map for vertices whose distances from source are known
     */
    private LinkedHashMap singleSourceShortestPath(Vertex source, Vertex target, int numDests)
    {
        SourceData sd = (SourceData)sourceMap.get(source);
        if (sd == null)
            sd = new SourceData(source);

        // if we already have all the distances we need, we're done
        if ((target != null && sd.distances.containsKey(target)) || 
            (sd.distances.size() >= numDests))
            return sd.distances;
        
        while (!sd.unknownVertices.isEmpty() && sd.distances.size() < numDests)
        {
            Vertex v = (Vertex)sd.unknownVertices.pop();
            Double dist = (Double)sd.estimatedDistances.remove(v);
            sd.distances.put(v, dist);
            Edge incoming = (Edge)sd.tentativeIncomingEdges.remove(v);
            sd.incomingEdges.put(v, incoming);
            double v_dist = dist.doubleValue();
            
            for (Iterator out_iter = v.getOutEdges().iterator(); out_iter.hasNext(); )
            {
                Edge e = (Edge)out_iter.next();
                Vertex w = e.getOpposite(v);
                if (!sd.distances.containsKey(w))
                {
                    double edge_weight = nev.getNumber(e).doubleValue();
                    if (edge_weight < 0)
                        throw new IllegalArgumentException("Edge weights must be non-negative");
                    double new_dist = v_dist + edge_weight;
                    if (!sd.estimatedDistances.containsKey(w))
                    {
                        sd.estimatedDistances.put(w, new Double(new_dist));
                        sd.unknownVertices.insert(w);
                        sd.tentativeIncomingEdges.put(w, e);
                    }
                    else
                    {
                        double w_dist = ((Double)sd.estimatedDistances.get(w)).doubleValue();
                        if (new_dist < w_dist) // update tentative distance & path for w
                            sd.update(w, e, new_dist);
                    }
                }
            }
            // if we have calculated the distance to the target, stop
            if (v == target)
                break;

        }
        return sd.distances;
    }
    
    /**
     * Returns the length of a shortest path from the source to the target vertex,
     * or null if the target is not reachable from the source.
     * If either vertex is not in the graph for which this instance
     * was created, throws <code>IllegalArgumentException</code>.
     * 
     * @see #getDistanceMap(Vertex)
     * @see #getDistanceMap(Vertex,int)
     */
    public Number getDistance(Vertex source, Vertex target)
    {
        if (source.getGraph() != g)
            throw new IllegalArgumentException("Specified source vertex " + 
        			source + " is not part of graph " + g);

        if (target.getGraph() != g)
            throw new IllegalArgumentException("Specified target vertex " + 
                target + " is not part of graph " + g);

        Map distanceMap = singleSourceShortestPath(source, target, g.numVertices());
        Double val = (Double)distanceMap.get(target);
        
        if (!cached)
            reset(source);
        
        return val;
    }
    
    /**
     * <p>Returns the last edge on a shortest path from <code>source</code>
     * to <code>target</code>, or null if <code>target</code> is not 
     * reachable from <code>source</code>.</p>
     * 
     * <p>If either vertex is not in the graph for which this instance
     * was created, throws <code>IllegalArgumentException</code>.</p>
     */
	public Edge getIncomingEdge(Vertex source, Vertex target)
	{
        if (source.getGraph() != g)
            throw new IllegalArgumentException("Specified source vertex " + 
                    source + " is not part of graph " + g);

        if (target.getGraph() != g)
            throw new IllegalArgumentException("Specified target vertex " + 
                    target + " is not part of graph " + g);

        singleSourceShortestPath(source, target, g.numVertices());
        Map incomingEdgeMap = 
            ((SourceData)sourceMap.get(source)).incomingEdges;
        Edge incomingEdge = (Edge)incomingEdgeMap.get(target);
        
        if (!cached)
            reset(source);
        
        return incomingEdge;
	}

    /**
     * <p>Returns a <code>LinkedHashMap</code> which maps each vertex 
     * in the graph (including the <code>source</code> vertex) 
     * to its distance from the <code>source</code> vertex.
     * The map's iterator will return the elements in order of 
     * increasing distance from <code>source</code>.</p>
     * 
     * <p>The size of the map returned will be the number of 
     * vertices reachable from <code>source</code>.</p>
     * 
     * @see #getDistanceMap(Vertex,int)
     * @see #getDistance(Vertex,Vertex)
     * @param source    the vertex from which distances are measured
     */
    public Map getDistanceMap(Vertex source)
    {
        return getDistanceMap(source, g.numVertices());
    }
    
    /**
     * <p>Returns a <code>LinkedHashMap</code> which maps each vertex 
     * in the graph (including the <code>source</code> vertex) 
     * to the last edge on the shortest path from the 
     * <code>source</code> vertex.
     * The map's iterator will return the elements in order of 
     * increasing distance from <code>source</code>.</p>
     * 
     * @see #getDistanceMap(Vertex,int)
     * @see #getDistance(Vertex,Vertex)
     * @param source    the vertex from which distances are measured
     */
    public Map getIncomingEdgeMap(Vertex source)
	{
		return getIncomingEdgeMap(source, g.numVertices());
	}

    /**
     * Returns a <code>List</code> of the edges on the shortest path from 
     * <code>source</code> to <code>target</code>, in order of their
     * occurrence on this path.  
     * If either vertex is not in the graph for which this instance
     * was created, throws <code>IllegalArgumentException</code>.
     */
	public List getPath(Vertex source, Vertex target)
	{
        LinkedList path = new LinkedList();

        // collect path data; must use internal method rather than
        // calling getIncomingEdge() because getIncomingEdge() may
        // wipe out results if results are not cached
        singleSourceShortestPath(source, target, g.numVertices());
        Map incomingEdges = 
            ((SourceData)sourceMap.get(source)).incomingEdges;
        
        if (incomingEdges.isEmpty() || incomingEdges.get(target) == null)
            return path;
        Vertex current = target;
        while (current != source)
        {
            Edge incoming = (Edge)incomingEdges.get(current);
            path.addFirst(incoming);
            current = incoming.getOpposite(current);
        }
		return path;
	}

    /**
     * <p>Returns a <code>LinkedHashMap</code> which maps each of the closest 
     * <code>numDist</code> vertices to the <code>source</code> vertex 
     * in the graph (including the <code>source</code> vertex) 
     * to its distance from the <code>source</code> vertex.  Throws 
     * an <code>IllegalArgumentException</code> if <code>source</code>
     * is not in this instance's graph, or if <code>numDests</code> is 
     * either less than 1 or greater than the number of vertices in the 
     * graph.</p>
     * 
     * <p>The size of the map returned will be the smaller of 
     * <code>numDests</code> and the number of vertices reachable from
     * <code>source</code>. 
     * 
     * @see #getDistanceMap(Vertex)
     * @see #getDistance(Vertex,Vertex)
     * @param source    the vertex from which distances are measured
     * @param numDests  the number of vertices for which to measure distances
     */
    public LinkedHashMap getDistanceMap(Vertex source, int numDests)
    {
        if (source.getGraph() != g)
            throw new IllegalArgumentException("Specified source vertex " + 
                source + " is not part of graph " + g);

        if (numDests < 1 || numDests > g.numVertices())
            throw new IllegalArgumentException("numDests must be >= 1 " + 
                "and <= g.numVertices()");

        LinkedHashMap distanceMap = singleSourceShortestPath(source, null, numDests);
                
        if (!cached)
            reset(source);
        
        return distanceMap;        
    }
    
    /**
     * <p>Returns a <code>LinkedHashMap</code> which maps each of the closest 
     * <code>numDist</code> vertices to the <code>source</code> vertex 
     * in the graph (including the <code>source</code> vertex) 
     * to the incoming edge along the path from that vertex.  Throws 
     * an <code>IllegalArgumentException</code> if <code>source</code>
     * is not in this instance's graph, or if <code>numDests</code> is 
     * either less than 1 or greater than the number of vertices in the 
     * graph.
     * 
     * @see #getIncomingEdgeMap(Vertex)
     * @see #getPath(Vertex,Vertex)
     * @param source    the vertex from which distances are measured
     * @param numDests  the number of vertics for which to measure distances
     */
	public LinkedHashMap getIncomingEdgeMap(Vertex source, int numDests)
	{
        if (source.getGraph() != g)
            throw new IllegalArgumentException("Specified source vertex " + 
                    source + " is not part of graph " + g);

        if (numDests < 1 || numDests > g.numVertices())
            throw new IllegalArgumentException("numDests must be >= 1 " + 
            "and <= g.numVertices()");

        singleSourceShortestPath(source, null, numDests);
        
        LinkedHashMap incomingEdgeMap = 
            ((SourceData)sourceMap.get(source)).incomingEdges;
        
        if (!cached)
            reset(source);
        
        return incomingEdgeMap;        
	}
     
    /**
     * Clears all stored distances for this instance.  
     * Should be called whenever the graph is modified (edge weights 
     * changed or edges added/removed).  If the user knows that
     * some currently calculated distances are unaffected by a
     * change, <code>reset(Vertex)</code> may be appropriate instead.
     * 
     * @see #reset(Vertex)
     */
    public void reset()
    {
        sourceMap = new HashMap();
    }
        
    /**
     * Specifies whether or not this instance of <code>DijkstraShortestPath</code>
     * should cache its results (final and partial) for future reference.
     * 
     * @param enable    <code>true</code> if the results are to be cached, and
     *                  <code>false</code> otherwise
     */
    public void enableCaching(boolean enable)
    {
        this.cached = enable;
    }
    
    /**
     * Clears all stored distances for the specified source vertex 
     * <code>source</code>.  Should be called whenever the stored distances
     * from this vertex are invalidated by changes to the graph.
     * 
     * @see #reset()
     */
    public void reset(Vertex source)
    {
        sourceMap.put(source, null);
    }

    /**
     * Compares according to distances, so that the BinaryHeap knows how to 
     * order the tree.  
     */
    private class VertexComparator implements Comparator
    {
        private Map distances;
        
        public VertexComparator(Map distances)
        {
            this.distances = distances;
        }

        public int compare(Object o1, Object o2)
        {
            return ((Comparable)distances.get(o1)).compareTo(distances.get(o2));
        }
    }
    
    /**
     * For a given source vertex, holds the estimated and final distances, 
     * tentative and final assignments of incoming edges on the shortest path from
     * the source vertex, and a priority queue (ordered by estimaed distance)
     * of the vertices for which distances are unknown.
     * 
     * @author Joshua O'Madadhain
     */
    private class SourceData
    {
        public LinkedHashMap distances;
        public Map estimatedDistances;
        public Map tentativeIncomingEdges;
        public MapBinaryHeap unknownVertices;
		public LinkedHashMap incomingEdges;

		public SourceData(Vertex source)
		{
            distances = new LinkedHashMap();
            estimatedDistances = new HashMap();
            unknownVertices = new MapBinaryHeap(new VertexComparator(estimatedDistances));
            incomingEdges = new LinkedHashMap();
            tentativeIncomingEdges = new HashMap();
            
            sourceMap.put(source, this);
            
            // initialize priority queue
            estimatedDistances.put(source, new Double(0)); // distance from source to itself is 0
            unknownVertices.insert(source);
		}
        
        public void update(Vertex dest, Edge tentative_edge, double new_dist)
        {
            estimatedDistances.put(dest, new Double(new_dist));
            unknownVertices.update(dest);
            tentativeIncomingEdges.put(dest, tentative_edge);
        }
    }

}
