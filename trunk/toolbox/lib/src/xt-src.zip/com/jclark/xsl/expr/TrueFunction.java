// $Id: TrueFunction.java,v 1.1 2002/04/25 18:12:23 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

class TrueFunction extends Function0 {
    ConvertibleExpr makeCallExpr() {
        return new TrueExpr();
    }
}
