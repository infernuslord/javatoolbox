// Copyright 2002, 2003 Elliotte Rusty Harold
// 
// This library is free software; you can redistribute 
// it and/or modify it under the terms of version 2.1 of 
// the GNU Lesser General Public License as published by  
// the Free Software Foundation.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General 
// Public License along with this library; if not, write to the 
// Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
// Boston, MA  02111-1307  USA
// 
// You can contact Elliotte Rusty Harold by sending e-mail to
// elharo@metalab.unc.edu. Please include the word "XOM" in the
// subject line. The XOM home page is temporarily located at
// http://www.cafeconleche.org/XOM/  but will eventually move
// to http://www.xom.nu/

package nu.xom.tests;

import junit.framework.Assert;
import junit.framework.TestCase;

import nu.xom.Element;
import nu.xom.IllegalDataException;
import nu.xom.Text;

/**
 * @author Elliotte Rusty Harold
 *
 */
public class TextTest extends TestCase {

    public TextTest() {
        super("Text tests");
    }

    public TextTest(String name) {
        super(name);
    }

    public void testConstructor() {
        
        Text a1 = new Text("test");
        Assert.assertEquals(a1.getValue(), "test");


    }

    public void testSetter() {
        
        String[] legal = {
          "Hello",
          "hello there",
          "  spaces on both ends  ",
          " quotes \" \" quotes",
          " single \'\' quotes",
          " both double and single \"\'\"\' quotes",  
          " angle brackets <  > <<<",  
          " carriage returns \r\r\r",  
          " CDATA end: ]]>",  
          " <![CDATA[ CDATA end: ]]>",  
          " &amp; ",  
          " ampersands & &&& &name; "  
        };

        Text a1 = new Text("name");
        
        // Things that shouldn't cause an exception
        for (int i = 0; i < legal.length; i++) {
            a1.setValue(legal[i]);   
            Assert.assertEquals(a1.getValue(), legal[i]);
        }
        
        a1.setValue(null);
        Assert.assertEquals(a1.getValue(), "");
        
        try {
          a1.setValue("test \u0000 test ");
          fail("Should raise an IllegalDataException");
        }
        catch (IllegalDataException success) {}


     }

    public void testEquals() {
        Text c1 = new Text("test");
        Text c2 = new Text("test");
        Text c3 = new Text("skjlchsakdjh");

        Assert.assertEquals(c1, c1);
        Assert.assertEquals(c1.hashCode(), c1.hashCode());
        Assert.assertTrue(!c1.equals(c2));
        Assert.assertTrue(!c1.equals(c3));
    }

    public void testCopy() {
        Text c1 = new Text("test");
        Text c2 = (Text) c1.copy();

        Assert.assertEquals(c1.getValue(), c2.getValue());
        Assert.assertEquals(c1.getValue(), c2.getValue());
        Assert.assertTrue(!c1.equals(c2));
        Assert.assertNull(c2.getParent());

    }

    // Check passing in a string with broken surrogate pairs
    // and with correct surrogate pairs
    public void testSurrogates() {

        String goodString = "test: \uD8F5\uDF80  ";
        Text c = new Text(goodString);
        Assert.assertEquals(goodString, c.getValue());

        // Two high-halves
        try {
          Text c1 = new Text("test: \uD8F5\uDBF0  ");
          fail("Should raise an IllegalDataException");
        }
        catch (IllegalDataException success) {}


        // Two high-halves
        try {
          Text c1 = new Text("test: \uD8F5\uD8F5  ");
          fail("Should raise an IllegalDataException");
        }
        catch (IllegalDataException success) {}

        // One high-half
        try {
           Text c1 = new Text("test: \uD8F5  ");
           fail("Should raise an IllegalDataException");
         }
         catch (IllegalDataException success) {}

        // One low half
         try {
            Text c1 = new Text("test: \uDF80  ");
            fail("Should raise an IllegalDataException");
          }
          catch (IllegalDataException success) {}

        // Low half before high half
         try {
            Text c1 = new Text("test: \uDCF5\uD8F5  ");
            fail("Should raise an IllegalDataException");
          }
          catch (IllegalDataException success) {}


    }


    public void testLeafNode() {

        Text c1 = new Text("data");
        Assert.assertEquals(c1.getChildCount(), 0);
        Assert.assertTrue(!c1.hasChildren());
        try {
            c1.getChild(0);
            fail("Didn't throw IndexOutofBoundsException");
        }
        catch (IndexOutOfBoundsException ex) {
            // success   
        }
        
        /*
        Assert.assertNull(c1.getPreviousSibling());
        Assert.assertNull(c1.getNextSibling()); */
        Assert.assertNull(c1.getParent());

        Element element = new Element("test");
        element.appendChild(c1);
        Assert.assertEquals(c1.getParent(), element);
        Assert.assertEquals(c1, element.getChild(0));

        element.removeChild(c1);
        assertTrue(!element.hasChildren());

    }

}
