/*
 *
 * Hamsam - Instant Messaging API
 *
 * Copyright (C) 2003 Mike Miller <mikemil@users.sourceforge.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 */

package hamsam.protocol.aim.command;

import java.io.IOException;
import java.io.OutputStream;

import hamsam.protocol.aim.flap.*;
import hamsam.protocol.aim.snac.*;
import hamsam.protocol.aim.util.*;


/**
 * @author mikem
 */
public class ClientICMB extends Command {

    private byte[] MSGID_COOKIE = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00  };
    private byte CHANNEL = 0x01;
    private String screenName;
   
    private static final int TLV_MSG_DATA = 0x002;
    private static final int TLV_MSG_ACK = 0x0003;
    private static final int TLV_STORE_MSG_IF_OFFLINE = 0x0006;
    private static final int TLV_CLIENT_FUTURE = 0x0501;
    private static final int TLV_MSG_TEXT = 0x0101;
    private static final byte[] CLI_FUTURE = { 0x01  };


    //~ Constructors -------------------------------------------------------------------------------
    
    /**
     * Constructor
     */
    public ClientICMB(int seqNum, String screenName, String msgContent) {
        flapHdr        = new FlapHeader(FlapConstants.FLAP_CHANNEL_SNAC, seqNum);
        snacPacket     = new SNACPacket(SNACConstants.SNAC_FAMILY_MESSAGING, 
                                        SNACConstants.CLIENT_SEND_ICBM);
        
        this.screenName = screenName;
        
        TLV clientFutures = new TLV(TLV_CLIENT_FUTURE, CLI_FUTURE );
        
        byte[] msgTextBytes = ByteUtils.getBytes(msgContent);
        byte[] tlvData = new byte[msgTextBytes.length + 4];
        
        // format the byte array
        tlvData[0] = 0x00;
        tlvData[1] = 0x00;
        tlvData[2] = (byte)0xff;
        tlvData[3] = (byte)0xff;
        System.arraycopy(msgTextBytes, 0, tlvData, 4, msgTextBytes.length);
        
        TLV tlvMsgText = new TLV(TLV_MSG_TEXT, tlvData); 

        // combine the bytes for the two TLVs above into a single TLV
        int tlvLen = clientFutures.getTotalLength() + tlvMsgText.getTotalLength();
        byte[] msgData = new byte[tlvLen];
        System.arraycopy( clientFutures.getBytes(), 0, msgData, 0, clientFutures.getTotalLength());
        System.arraycopy( tlvMsgText.getBytes(), 0, msgData, clientFutures.getTotalLength(), tlvMsgText.getTotalLength());
        
        addTLV( new TLV(TLV_MSG_DATA, msgData) );
        
        // add tlv 03 & 06 as empty TLVs
        byte[] empty = null;
        addTLV( new TLV(TLV_MSG_ACK, empty) );
        addTLV( new TLV(TLV_STORE_MSG_IF_OFFLINE, empty) );
        
    }

    //~ Methods ------------------------------------------------------------------------------------

    /* (non-Javadoc)
     * @see hamsam.protocol.aim.command.Command#writeCommandData(java.io.OutputStream)
     */
    public void writeCommandData(OutputStream os) throws IOException {
        os.write(MSGID_COOKIE);
        os.write(0x00);
        os.write(CHANNEL);
        os.write(screenName.length());
        os.write(ByteUtils.getBytes(screenName));
        
    }
}
