// $Id: Comparator.java,v 1.1 2002/04/25 18:20:35 bill Exp $

package com.jclark.xsl.util;

public interface Comparator
{
    int compare(Object obj1, Object obj2);
}
