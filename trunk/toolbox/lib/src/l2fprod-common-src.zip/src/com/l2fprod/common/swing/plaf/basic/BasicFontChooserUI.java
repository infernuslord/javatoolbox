/** ===================================================================
 *
 * L2FProd.com Common Components 0.1-dev License.
 *
 * Copyright (c) 2004 L2FProd.com.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by L2FProd.com
 *        (http://www.L2FProd.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "L2FProd.com Common Components", "l2fprod-common" and "L2FProd.com" must not
 *    be used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact info@L2FProd.com.
 *
 * 5. Products derived from this software may not be called "l2fprod-common"
 *    nor may "l2fprod-common" appear in their names without prior written
 *    permission of L2FProd.com.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL L2FPROD.COM OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package com.l2fprod.common.swing.plaf.basic;

import com.l2fprod.common.swing.JFontChooser;
import com.l2fprod.common.swing.LookAndFeelTweaks;
import com.l2fprod.common.swing.PercentLayout;
import com.l2fprod.common.swing.plaf.FontChooserUI;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.font.TextAttribute;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.plaf.ComponentUI;

/**
 * BasicFontChooserUI. <br>
 *  
 */
public class BasicFontChooserUI extends FontChooserUI {

  public static ComponentUI createUI(JComponent component) {
    return new BasicFontChooserUI();
  }

  private JFontChooser chooser;

  private JPanel fontPanel;
  private JTextField fontField;
  private JList fontList;

  private JPanel fontSizePanel;
  private JTextField fontSizeField;
  private JList fontSizeList;

  private JCheckBox boldCheck;
  private JCheckBox italicCheck;

  private JTextArea previewPanel;

  private PropertyChangeListener propertyListener;

  static String[] DEFAULT_FONT_SIZES =
    {
      "6",
      "8",
      "10",
      "11",
      "12",
      "14",
      "16",
      "18",
      "20",
      "22",
      "24",
      "26",
      "28",
      "32",
      "40",
      "48",
      "56",
      "64",
      "72" };

  public void installUI(JComponent c) {
    super.installUI(c);

    chooser = (JFontChooser)c;

    installComponents();
    installListeners();
  }

  protected void installComponents() {
    JLabel label;

    ResourceBundle bundle =
      ResourceBundle.getBundle(FontChooserUI.class.getName() + "RB");

    fontPanel = new JPanel(new PercentLayout(PercentLayout.VERTICAL, 2));
    fontPanel.add(
      label = new JLabel(bundle.getString("FontChooserUI.fontLabel")));
    fontPanel.add(fontField = new JTextField(25));
    fontField.setEditable(false);
    fontPanel.add(new JScrollPane(fontList = new JList()), "*");
    label.setLabelFor(fontList);
    label.setDisplayedMnemonic(
      bundle.getString("FontChooserUI.fontLabel.mnemonic").charAt(0));
    fontList.setVisibleRowCount(7);
    fontList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

    String[] fontFamilies =
      GraphicsEnvironment
        .getLocalGraphicsEnvironment()
        .getAvailableFontFamilyNames();
    Arrays.sort(fontFamilies);
    fontList.setListData(fontFamilies);

    fontSizePanel = new JPanel(new PercentLayout(PercentLayout.VERTICAL, 2));

    fontSizePanel.add(
      label = new JLabel(bundle.getString("FontChooserUI.styleLabel")));
    fontSizePanel.add(
      boldCheck = new JCheckBox(bundle.getString("FontChooserUI.style.bold")));
    fontSizePanel.add(
      italicCheck =
        new JCheckBox(bundle.getString("FontChooserUI.style.italic")));
    boldCheck.setMnemonic(
      bundle.getString("FontChooserUI.style.bold.mnemonic").charAt(0));
    italicCheck.setMnemonic(
      bundle.getString("FontChooserUI.style.italic.mnemonic").charAt(0));

    fontSizePanel.add(
      label = new JLabel(bundle.getString("FontChooserUI.sizeLabel")));

    label.setDisplayedMnemonic(
      bundle.getString("FontChooserUI.sizeLabel.mnemonic").charAt(0));

    fontSizePanel.add(fontSizeField = new JTextField());
    label.setLabelFor(fontSizeField);
    fontSizePanel.add(new JScrollPane(fontSizeList = new JList()), "*");
    fontSizeList.setListData(DEFAULT_FONT_SIZES);
    fontSizeList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    fontSizeList.setVisibleRowCount(2);

    chooser.setLayout(LookAndFeelTweaks.createBorderLayout());
    JPanel panel = new JPanel();
    panel.setLayout(LookAndFeelTweaks.createHorizontalPercentLayout());
    panel.add(fontPanel, "*");
    panel.add(fontSizePanel);
    chooser.add("Center", panel);

    previewPanel = new JTextArea();
    previewPanel.setPreferredSize(new Dimension(100, 40));
    previewPanel.setText(bundle.getString("FontChooserUI.previewText"));
    JScrollPane scroll = new JScrollPane(previewPanel);
    chooser.add("South", scroll);
  }

  protected void installListeners() {
    SelectedFontUpdater listener = new SelectedFontUpdater();
    fontList.addListSelectionListener(listener);
    fontSizeList.addListSelectionListener(listener);
    fontSizeField.getDocument().addDocumentListener(listener);
    boldCheck.addActionListener(listener);
    italicCheck.addActionListener(listener);

    propertyListener = createPropertyChangeListener();
    chooser.addPropertyChangeListener(
      JFontChooser.SELECTED_FONT_CHANGED_KEY,
      propertyListener);
  }

  public void uninstallUI(JComponent c) {
    chooser.remove(fontPanel);
    chooser.remove(fontSizePanel);

    super.uninstallUI(c);
  }

  public void uninstallListeners() {
    chooser.removePropertyChangeListener(propertyListener);
  }

  protected PropertyChangeListener createPropertyChangeListener() {
    return new PropertyChangeListener() {
      public void propertyChange(PropertyChangeEvent evt) {
        updateDisplay();
      }
    };
  }

  private void updateDisplay() {
    Font selected = chooser.getSelectedFont();
    if (selected != null) {
      previewPanel.setFont(selected);
      fontList.setSelectedValue(selected.getName(), true);
      fontSizeField.setText(String.valueOf(selected.getSize()));
      fontSizeList.setSelectedValue(String.valueOf(selected.getSize()), true);
      boldCheck.setSelected(selected.isBold());
      italicCheck.setSelected(selected.isItalic());
    }
  }

  private void updateSelectedFont() {
    Font currentFont = chooser.getSelectedFont();
    String fontFamily =
      currentFont == null ? "SansSerif" : currentFont.getName();
    int fontSize = currentFont == null ? 11 : currentFont.getSize();

    if (fontList.getSelectedIndex() >= 0) {
      fontFamily = (String)fontList.getSelectedValue();
    }

    if (fontSizeField.getText().trim().length() > 0) {
      try {
        fontSize = Integer.parseInt(fontSizeField.getText().trim());
      } catch (Exception e) {
        // ignore the NumberFormatException
      }
    }

    Map attributes = new HashMap();
    attributes.put(TextAttribute.SIZE, new Float(fontSize));
    attributes.put(TextAttribute.FAMILY, fontFamily);
    if (boldCheck.isSelected()) {
      attributes.put(TextAttribute.WEIGHT, TextAttribute.WEIGHT_BOLD);
    }
    if (italicCheck.isSelected()) {
      attributes.put(TextAttribute.POSTURE, TextAttribute.POSTURE_OBLIQUE);
    }

    Font font = Font.getFont(attributes);
    if (!font.equals(currentFont)) {
      chooser.setSelectedFont(font);
      previewPanel.setFont(font);
    }
  }

  private class SelectedFontUpdater
    implements ListSelectionListener, DocumentListener, ActionListener {
    public void valueChanged(ListSelectionEvent e) {
      if (fontList == e.getSource() && fontList.getSelectedValue() != null) {
        fontField.setText((String)fontList.getSelectedValue());
      }
      if (fontSizeList == e.getSource()
        && fontSizeList.getSelectedValue() != null) {
        fontSizeField.setText((String)fontSizeList.getSelectedValue());
      }
      updateSelectedFont();
    }
    public void changedUpdate(DocumentEvent e) {
      updateLater();
    }
    public void insertUpdate(DocumentEvent e) {
      updateLater();
    }
    public void removeUpdate(DocumentEvent e) {
      updateLater();
    }
    public void actionPerformed(ActionEvent e) {
      updateLater();
    }
    void updateLater() {
      SwingUtilities.invokeLater(new Runnable() {
        public void run() {
          updateSelectedFont();
        }
      });
    }
  }

}
