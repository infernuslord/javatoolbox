/*
 * 
 * Created on 2004-jun-29
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.ui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicMenuItemUI;

import se.diod.hippo.plaf.renderer.MenuItemRenderer;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jun-29
 *
 */
public class HippoMenuItemUI extends BasicMenuItemUI {
	private MenuItemRenderer renderer;
	private static final int MINIMUM_WIDTH = 80;
	private Border storedBorder							= null;





	/////////////////////////////////////////////////
	//                   Create                    //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	public static ComponentUI createUI(JComponent b) {
		return new HippoMenuItemUI();
	}




	/////////////////////////////////////////////////
	//                  Install                    //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	protected void installDefaults() {
		super.installDefaults();

		renderer = new MenuItemRenderer( menuItem, acceleratorFont, selectionForeground, disabledForeground, acceleratorForeground, acceleratorSelectionForeground );
		Integer gap = ( Integer ) UIManager.get( getPropertyPrefix() + ".textIconGap" );
		defaultTextIconGap = gap != null ? gap.intValue() : 2;
	}




	/**
	 * 
	 * 
	 */
	public void installUI( JComponent c ) {
		super.installUI( c );

		// Save current border..
		storedBorder = c.getBorder();
	}




	/////////////////////////////////////////////////
	//                 Uninstall                   //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	protected void uninstallDefaults() {
		renderer = null;
		super.uninstallDefaults();
	}




	/**
	 * 
	 * Restores the original <code>Border</code>.
	 * 
	 */
	public void uninstallUI( JComponent c ) {
		// Restore old border..
		if( storedBorder != null ) {
			c.setBorder( storedBorder );
		}

		super.uninstallUI( c );
	}




	/////////////////////////////////////////////////
	//                 Painting                    //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	public void paint( Graphics g, JComponent c ) {
		Graphics g2 = g.create();
		super.paint( g2, c );
		g2.dispose();
	}
 
 


	/**
	 * 
	 * 
	 */
 	protected void paintMenuItem( Graphics g, JComponent c, Icon aCheckIcon, Icon anArrowIcon, Color background, Color foreground, int textIconGap) {
		Graphics g2 = g.create();
		renderer.paintMenuItem( g2, c, aCheckIcon, anArrowIcon, background, foreground, textIconGap);
		g2.dispose();
	}




	/**
	 * 
	 * 
	 */
	protected Dimension getPreferredMenuItemSize( JComponent c, Icon aCheckIcon, Icon anArrowIcon, int textIconGap ) {
		//if (storedCheckIcon == null) replaceIcons();
		Dimension size = renderer.getPreferredMenuItemSize( c, aCheckIcon, anArrowIcon, textIconGap );
		int width = Math.max(MINIMUM_WIDTH, size.width);
		int height = size.height;
		return new Dimension(width, height);
	}
}
