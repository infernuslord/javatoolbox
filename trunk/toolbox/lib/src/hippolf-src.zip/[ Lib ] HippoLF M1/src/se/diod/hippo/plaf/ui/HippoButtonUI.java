/*
 * 
 * Created on 2004-jul-23
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.ui;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.JToolBar;
import javax.swing.border.Border;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicGraphicsUtils;
import javax.swing.plaf.basic.BasicHTML;
import javax.swing.plaf.metal.MetalButtonUI;
import javax.swing.text.View;





/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-23
 *
 */
public class HippoButtonUI extends MetalButtonUI {
	private static final HippoButtonUI INSTANCE			= new HippoButtonUI();
	private static final ButtonMouseListener bmlistener	= new ButtonMouseListener();
	private Border storedBorder							= null;




	/**
	 * 
	 * 
	 */
	public static ComponentUI createUI( JComponent c ) {
		return INSTANCE;
	}




	/**
	 * 
	 * 
	 */
	public void installUI( JComponent c ) {
		super.installUI( c );

		// Save current border..
		storedBorder = c.getBorder();
	}




	/**
	 * 
	 * Restores the original <code>Border</code>.
	 * 
	 */
	public void uninstallUI( JComponent c ) {
		super.uninstallUI( c );

		// Restore old border..
		if( storedBorder != null ) {
			c.setBorder( storedBorder );
		}
	}




	/**
	 * 
	 * 
	 */
	protected void installListeners( AbstractButton b ) {
		super.installListeners( b );

		if( bmlistener != null ) {
			b.addMouseListener( bmlistener );
		}
	}




	/**
	 * 
	 * 
	 */
	protected void uninstallListeners( AbstractButton b ) {
		super.uninstallListeners( b );

		if( bmlistener != null ) {
			b.removeMouseListener( bmlistener );
		}
	}

	

	/**
	 * 
	 * @author Robert Karlsson
	 * @created 2003-okt-28
	 *
	 */
	private static final class ButtonMouseListener implements MouseListener {
		public void mouseExited( MouseEvent mevent ) {
			AbstractButton b = (AbstractButton) mevent.getSource();
			if( isToolBarButton( b ) ) {
				b.setBorder( se.diod.hippo.plaf.common.Border.getToolBarButtonBorder() );
			}
		}
		public void mouseEntered( MouseEvent mevent ) {
			AbstractButton b = (AbstractButton) mevent.getSource();
			if( isToolBarButton( b ) ) {
				b.setBorder( se.diod.hippo.plaf.common.Border.getToolBarSelectedButtonBorder() );
			}
		}

		public void mouseClicked( MouseEvent mevent ) {}
		public void mouseReleased( MouseEvent mevent ) {}
		public void mousePressed( MouseEvent mevent ) {}
	}




	/**
	 * 
	 * 
	 */
	public void update( Graphics g, JComponent c ) {
		javax.swing.ButtonModel model = ((javax.swing.AbstractButton)c).getModel();

		Graphics g2 = g.create();
		AbstractButton b = ( AbstractButton )c;

		if( c.isOpaque() ) {
			if( isToolBarButton( b ) ) {
				// TODO [ButtonUI::update] Check if this way is OK, with newsgroup (also in togglebuttonui)
				c.setBorder( se.diod.hippo.plaf.common.Border.getToolBarButtonBorder() );
				c.setOpaque( false );
			} else {
				// Clear background..
				if( model.isEnabled() ) {
					g2.setColor( c.getBackground() );
					g2.fillRect( 0, 0, c.getWidth(), c.getHeight() );
				} else {
					c.setOpaque( false );
				}
			}
		} else {
			if( isToolBarButton( b ) ) {
				// Clear background..
				if( b.getModel().isRollover() ) {
					g2.setColor( javax.swing.UIManager.getColor( "Button.rolloverBackground" ) );
					g2.fillRect( 0, 0, c.getWidth(), c.getHeight() );
				}
			}
		}

		g2.dispose();
		paint( g, c );
	}




	/**
	 * 
	 * Paints the focus with close to the button's border.
	 * 
	 */
	protected void paintFocus( Graphics g, AbstractButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect) {}






	// **********************************************************************
	//
	//                 Helper methods                
	//
	// **********************************************************************
	/**
	 * 
	 * Checks and answers if this button is in a tool bar.
	 * 
	 */
	protected static boolean isToolBarButton( AbstractButton b ) {
		Container parent 		= b.getParent();
		return ( parent != null ) && ( parent instanceof JToolBar || parent.getParent() instanceof JToolBar );
	}




	// **********************************************************************
	//
	//          Layout Methods
	//
	// **********************************************************************
	final int MIN_HEIGHT = 17;
	/**
	 * 
	 * 
	 */
	public Dimension getMinimumSize( JComponent c ) {
		Dimension d = getPreferredSize( c );
		View v = (View) c.getClientProperty(BasicHTML.propertyKey);
		if (v != null) {
			d.width -= v.getPreferredSpan(View.X_AXIS) - v.getMinimumSpan(View.X_AXIS);
		}

		return d;
	}




	/**
	 * 
	 * 
	 */
	public Dimension getPreferredSize(JComponent c) {
		AbstractButton b = (AbstractButton)c;
		Dimension d = BasicGraphicsUtils.getPreferredButtonSize(b, b.getIconTextGap());

		if( d.height < MIN_HEIGHT )
			d.height = MIN_HEIGHT;

		return d;
	}




	/**
	 * 
	 * 
	 */
	public Dimension getMaximumSize(JComponent c) {
		Dimension d = getPreferredSize(c);
		View v = (View) c.getClientProperty(BasicHTML.propertyKey);
		if (v != null) {
			d.width += v.getMaximumSpan(View.X_AXIS) - v.getPreferredSpan(View.X_AXIS);
		}
		return d;
	}
}
