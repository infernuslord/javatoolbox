/*
 * 
 * Created on 2004-jul-25
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.ui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;

import javax.swing.JComponent;
import javax.swing.JSlider;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.metal.MetalLookAndFeel;
import javax.swing.plaf.metal.MetalSliderUI;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-25
 *
 */
public class HippoSliderUI extends MetalSliderUI {






	/////////////////////////////////////////////////
	//                   Create                    //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	public static ComponentUI createUI( JComponent c ) {
		return new HippoSliderUI();
	}




	/////////////////////////////////////////////////
	//                  Install                    //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	public void installUI( JComponent c ) {
		super.installUI( c );
	}




	/////////////////////////////////////////////////
	//                 Uninstall                   //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	public void uninstallUI( JComponent c ) {
		super.uninstallUI( c );
	}




	/////////////////////////////////////////////////
	//                 Painting                    //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	public void paintThumb( Graphics g )  {
		Rectangle knobBounds = thumbRect;

		if ( slider.getOrientation() == JSlider.HORIZONTAL ) {
			g.translate( knobBounds.x, knobBounds.y );
			horizThumbIcon.paintIcon( slider, g, 0, 0 );
			g.translate( -knobBounds.x, -knobBounds.y );
		} else {
			g.translate( knobBounds.x, knobBounds.y );
			vertThumbIcon.paintIcon( slider, g, 0, 0 );
			g.translate( -(knobBounds.x), -knobBounds.y );
		}
	}




	/**
	 * 
	 * 
	 */
	public void paintTrack( Graphics g )  {
		Graphics g2 = g.create();

		g2.translate( trackRect.x, trackRect.y );

		int trackLeft	= 0;
		int trackTop	= 0;
		int trackRight	= 0;
		int trackBottom	= 0;

		// Retrieve positions
		if( slider.getOrientation() == JSlider.HORIZONTAL ) {
			trackBottom	= ((trackRect.height - 1) - getThumbOverhang()) + 2;
			trackTop	= trackBottom - (getTrackWidth() - 1) - 2;
			trackRight	= trackRect.width - 1;
		} else {
			trackLeft	= trackRect.width - getThumbOverhang() - getTrackWidth()-3;
			trackRight	= trackRect.width - getThumbOverhang() - 2;
			trackBottom	= trackRect.height - 1;
		}

		// Draw the track
		if ( slider.isEnabled() ) {
			// Draw background
			g2.setColor( Color.white );  // FIXED COLOR, BIG NONO!
			g2.fillRect( trackLeft, trackTop,(trackRight - trackLeft) - 1, (trackBottom - trackTop) - 1 );

			// Draw border
			g2.setColor( new Color( 155, 155, 155 ) );  // FIXED COLOR, BIG NONO!
			g2.drawRect( trackLeft, trackTop,(trackRight - trackLeft) - 1, (trackBottom - trackTop) - 1 );
		} else {
			g2.setColor( MetalLookAndFeel.getControlShadow() );
			g2.drawRect( trackLeft, trackTop, (trackRight - trackLeft) - 1, (trackBottom - trackTop) - 1 );
		}

		// Draw the fill
		if( filledSlider ) {
			int middleOfThumb = 0;
			int fillTop = 0;
			int fillLeft = 0;
			int fillBottom = 0;
			int fillRight = 0;

			if ( slider.getOrientation() == JSlider.HORIZONTAL ) {
				middleOfThumb = thumbRect.x + (thumbRect.width / 2);
				middleOfThumb -= trackRect.x; // To compensate for the g.translate()
				fillTop = !slider.isEnabled() ? trackTop : trackTop + 1;
				fillBottom = !slider.isEnabled() ? trackBottom - 1 : trackBottom - 2;
		
				if ( !drawInverted() ) {
					fillLeft = !slider.isEnabled() ? trackLeft : trackLeft + 1;
					fillRight = middleOfThumb;
				} else {
					fillLeft = middleOfThumb;
					fillRight = !slider.isEnabled() ? trackRight - 1 : trackRight - 2;
				}
			} else {
				middleOfThumb = thumbRect.y + (thumbRect.height / 2);
				middleOfThumb -= trackRect.y; // To compensate for the g.translate()
				fillLeft = !slider.isEnabled() ? trackLeft : trackLeft + 1;
				fillRight = !slider.isEnabled() ? trackRight - 1 : trackRight - 2;
		
				if ( !drawInverted() ) {
					fillTop = middleOfThumb;
					fillBottom = !slider.isEnabled() ? trackBottom - 1 : trackBottom - 2;
				} else {
					fillTop = !slider.isEnabled() ? trackTop : trackTop + 1;
					fillBottom = middleOfThumb;
				}
			}

			if ( slider.isEnabled() ) {
				g2.setColor( slider.getBackground() );
				g2.drawLine( fillLeft, fillTop, fillRight, fillTop );
				g2.drawLine( fillLeft, fillTop, fillLeft, fillBottom );

				g2.setColor( MetalLookAndFeel.getControlShadow() );
				g2.fillRect( fillLeft + 1, fillTop + 1,
				fillRight - fillLeft, fillBottom - fillTop );
			} else {
				g2.setColor( MetalLookAndFeel.getControlShadow() );
				g2.fillRect( fillLeft, fillTop,
				fillRight - fillLeft, trackBottom - trackTop );
			}
		}

		g2.translate( -trackRect.x, -trackRect.y );
		g2.dispose();
	}






	/////////////////////////////////////////////////
	//                   Other                     //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	protected void calculateThumbLocation(){
		super.calculateThumbLocation();

		if( slider.getOrientation() == JSlider.HORIZONTAL )
			thumbRect.translate(0, -Math.min(4, thumbRect.y));
			//thumbRect.translate(0, -Math.min(4, thumbRect.y)-3);
		else
			thumbRect.translate( -Math.min(4, thumbRect.x) , 0 );
			//thumbRect.translate( -Math.min(5, thumbRect.x) + 3, 0 );
	}




	/**
	 * 
	 * 
	 */
	protected Dimension getThumbSize() {
		Dimension size = new Dimension();

		if ( slider.getOrientation() == JSlider.VERTICAL ) {
			size.width	= vertThumbIcon.getIconWidth();
			size.height	= vertThumbIcon.getIconHeight();
		} else {
			size.width	= horizThumbIcon.getIconWidth();
			size.height = horizThumbIcon.getIconHeight();
		}
	
		return size;
	}
}
