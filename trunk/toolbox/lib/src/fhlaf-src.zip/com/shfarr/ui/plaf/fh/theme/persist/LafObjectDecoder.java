/*
 * Created on Sep 2, 2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package com.shfarr.ui.plaf.fh.theme.persist;

import java.awt.Color;
import java.awt.Font;

import sun.misc.BASE64Decoder;

import com.shfarr.beans.ObjectDecoder;

/**
 * @author Administrator
 */
public class LafObjectDecoder implements ObjectDecoder{
    public Object decodeObject(String value, Class c){
        if(c.equals(boolean.class) || c.equals(Boolean.class)) return new Boolean(value);
        if(c.equals(byte.class) || c.equals(Byte.class)) return new Byte(value);
        if(c.equals(char.class) || c.equals(Character.class)) return new Character(value.charAt(0));
        if(c.equals(short.class) || c.equals(Short.class)) return new Short(value);
        if(c.equals(int.class) || c.equals(Integer.class)) return new Integer(value);
        if(c.equals(long.class) || c.equals(Long.class)) return new Long(value);
        if(c.equals(float.class) || c.equals(Float.class)) return new Float(value);
        if(c.equals(double.class) || c.equals(Double.class)) return new Double(value);
        if(c.equals(byte[].class)){
            try{
                return new BASE64Decoder().decodeBuffer(value);
            }
            catch(Exception e){
                System.out.println("Caught unhandled exception: " + e);
                e.printStackTrace();
            }
        }
        if(c.equals(java.math.BigDecimal.class)) return new java.math.BigDecimal(value);
        if(c.equals(java.math.BigInteger.class)) return new java.math.BigInteger(value);
        if(c.equals(String.class)) return value;
        if(Color.class.isAssignableFrom(c)){
            String[] colors = value.trim().split(" *, *");
            return new Color(Integer.parseInt(colors[0]), Integer.parseInt(colors[1]), Integer.parseInt(colors[2]), Integer.parseInt(colors[3]));
        }
        if(Font.class.isAssignableFrom(c)) {
            int style = Font.PLAIN;
            if(value.indexOf("bold") != -1) style = style | Font.BOLD;
            if(value.indexOf("italic") != -1) style = style | Font.ITALIC;
                   
            String[] fontElements = value.trim().split(" *, *");
            Font font = new Font(fontElements[0], style, (int)(Integer.parseInt(fontElements[2])));
            
            return font;
        }
        return null;
    }
}
