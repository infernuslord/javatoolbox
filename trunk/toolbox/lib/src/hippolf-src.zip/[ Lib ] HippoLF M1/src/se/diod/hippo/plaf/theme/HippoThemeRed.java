/*
 * 
 * Created on 2004-jun-29
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.theme;

import java.awt.Color;

import javax.swing.plaf.ColorUIResource;




/**
 * 
 * Red Color: 210, 169, 156
 * 
 * @author Robert Karlsson
 * @created 2004-jun-29
 *
 */
public class HippoThemeRed extends HippoThemeGray {
	private final static Color PRIMARY_COLOR = new Color( 210, 169, 156 );
	private final static Color DARK_COLOR    = new Color( 190, 149, 136 );

	
	
	
	/**
	 * 
	 * 
	 */
	public String getName() {
		return "Red";
	}

	
	
	
	// CheckBox
	private static final Color 		myCheckBoxBackground						= PRIMARY_COLOR;

	// Combobox
	private static final Color 		myComboBoxSelectionBackground				= PRIMARY_COLOR;

	// Desktop
	private static final Color 		myDesktopBackground							= PRIMARY_COLOR;

	// EditorPane
	private static final Color 		myEditorPaneSelectionBackground				= PRIMARY_COLOR;

	// InternalFrame
	private static final Color 		myInternalFrameActiveTitleBackground		= DARK_COLOR;
	private static final Color 		myInternalFrameActiveTitleBackground2		= PRIMARY_COLOR;

	// List
	private static final Color 		myListSelectionBackground					= PRIMARY_COLOR;
	
	// Menu
	private static final Color 		myMenuIconBackground						= PRIMARY_COLOR;

	// OptionPane
	private static final Color 		myOptionPaneBackground						= PRIMARY_COLOR;

	// Panel
	private static final Color 		myPanelBackground							= PRIMARY_COLOR;

	// ProgressBar
	private static final Color 		myProgressBarForeground						= PRIMARY_COLOR;

	// RadioButton
	private static final Color 		myRadioButtonBackground						= PRIMARY_COLOR;

	// ScrollBar
	private static final Color 		myScrollBarThumbBackground					= PRIMARY_COLOR;

	// Slider
	private static final Color 		mySliderBackground							= PRIMARY_COLOR;

	// SplitPane
	private static final Color 		mySplitPaneBackground						= PRIMARY_COLOR;
	private static final Color 		mySplitPaneHighlight						= PRIMARY_COLOR;
	private static final Color 		mySplitPaneShadow							= PRIMARY_COLOR;
	private static final Color 		mySplitPaneDarkShadow						= PRIMARY_COLOR;

	// TabbedPane
	private static final Color 		myTabbedPaneBackground						= PRIMARY_COLOR;

	// Table
	private static final Color 		myTableGridColor							= PRIMARY_COLOR;
	private static final Color 		myTableSelectionBackground					= PRIMARY_COLOR;

	// TableHeader
	private static final Color 		myTableHeaderBackground						= DARK_COLOR;
	private static final Color 		myTableHeaderGridColor						= new Color( 170, 129, 116 );

	// TextArea
	private static final Color 		myTextAreaSelectionBackground				= PRIMARY_COLOR;

	// TextField
	private static final Color 		myTextFieldInactiveBackground				= PRIMARY_COLOR;
	private static final Color 		myTextFieldSelectionBackground				= PRIMARY_COLOR;

	// TextPane
	private static final Color 		myTextPaneSelectionBackground				= PRIMARY_COLOR;
	
	// ToolBar
	private static final Color 		myToolBarBackground							= PRIMARY_COLOR;

	// Tree
	private static final Color 		myTreeSelectionBackground					= PRIMARY_COLOR;
	private static final Color 		myTreeHash									= PRIMARY_COLOR;

	

	/**
	 * 
	 * CheckBox Background
	 * 
	 */
	public ColorUIResource getCheckBoxBackground() {
		return new ColorUIResource( myCheckBoxBackground );
	}

	
	
	
	/**
	 * 
	 * ComboBoxSelection Background
	 * 
	 */
	public ColorUIResource getComboBoxSelectionBackground() {
		return new ColorUIResource( myComboBoxSelectionBackground );
	}

	
	
	
	/**
	 * 
	 * Desktop Background
	 * 
	 */
	public ColorUIResource getDesktopBackground() {
		return new ColorUIResource( myDesktopBackground );
	}

	
	
	
	/**
	 * 
	 * EditorPaneSelection Background
	 * 
	 */
	public ColorUIResource getEditorPaneSelectionBackground() {
		return new ColorUIResource( myEditorPaneSelectionBackground );
	}


	
	
	/**
	 * 
	 * InternalFrameActiveTitle Background
	 * 
	 */
	public ColorUIResource getInternalFrameActiveTitleBackground() {
		return new ColorUIResource( myInternalFrameActiveTitleBackground );
	}


	
	
	/**
	 * 
	 * InternalFrameActiveTitle Background2
	 * 
	 */
	public ColorUIResource getInternalFrameActiveTitleBackground2() {
		return new ColorUIResource( myInternalFrameActiveTitleBackground2 );
	}


	
	
	/**
	 * 
	 * ListSelection Background
	 * 
	 */
	public ColorUIResource getListSelectionBackground() {
		return new ColorUIResource( myListSelectionBackground );
	}

	
	
	
	/**
	 * 
	 * MenuIcon Background
	 * 
	 */
	public ColorUIResource getMenuIconBackground() {
		return new ColorUIResource( myMenuIconBackground );
	}


	
	
	/**
	 * 
	 * OptionPane Background
	 * 
	 */
	public ColorUIResource getOptionPaneBackground() {
		return new ColorUIResource( myOptionPaneBackground );
	}

	
	
	
	/**
	 * 
	 * Panel Background
	 * 
	 */
	public ColorUIResource getPanelBackground() {
		return new ColorUIResource( myPanelBackground );
	}

	
	
	
	/**
	 * 
	 * ProgressBar Foreground
	 * 
	 */
	public ColorUIResource getProgressBarForeground() {
		return new ColorUIResource( myProgressBarForeground );
	}

	
	
	
	/**
	 * 
	 * RadioButton Background
	 * 
	 */
	public ColorUIResource getRadioButtonBackground() {
		return new ColorUIResource( myRadioButtonBackground );
	}

	
	
	
	/**
	 * 
	 * ScrollBarThumbBackground
	 * 
	 */
	public ColorUIResource getScrollBarThumbBackground() {
		return new ColorUIResource( myScrollBarThumbBackground );
	}


	
	
	/**
	 * 
	 * Slider
	 * 
	 */
	public ColorUIResource getSliderBackground() {
		return new ColorUIResource( mySliderBackground );
	}

	
	
	
	/**
	 * 
	 * SplitPane Background
	 * 
	 */
	public ColorUIResource getSplitPaneBackground() {
		return new ColorUIResource( mySplitPaneBackground );
	}


	
	
	/**
	 * 
	 * SplitPane Highlight
	 * 
	 */
	public ColorUIResource getSplitPaneHighlight() {
		return new ColorUIResource( mySplitPaneHighlight );
	}


	
	
	/**
	 * 
	 * SplitPane Shadow
	 * 
	 */
	public ColorUIResource getSplitPaneShadow() {
		return new ColorUIResource( mySplitPaneShadow );
	}




	/**
	 * 
	 * SplitPaneDark Shadow
	 * 
	 */
	public ColorUIResource getSplitPaneDarkShadow() {
		return new ColorUIResource( mySplitPaneDarkShadow );
	}

	
	
	
	/**
	 * 
	 * TabbedPane Background
	 * 
	 */
	public ColorUIResource getTabbedPaneBackground() {
		return new ColorUIResource( myTabbedPaneBackground );
	}

	
	
	
	/**
	 * 
	 * TableGrid Color
	 * 
	 */
	public ColorUIResource getTableGridColor() {
		return new ColorUIResource( myTableGridColor );
	}


	
	
	/**
	 * 
	 * TableSelection Background
	 * 
	 */
	public ColorUIResource getTableSelectionBackground() {
		return new ColorUIResource( myTableSelectionBackground );
	}

	
	
	
	/**
	 * 
	 * TableHeader Background
	 * 
	 */
	public ColorUIResource getTableHeaderBackground() {
		return new ColorUIResource( myTableHeaderBackground );
	}

	
	
	
	/**
	 * 
	 * TableHeader Background
	 * 
	 */
	public ColorUIResource getTableHeaderGridColor() {
		return new ColorUIResource( myTableHeaderGridColor );
	}

	
	
	
	/**
	 * 
	 * TextAreaSelection Background
	 * 
	 */
	public ColorUIResource getTextAreaSelectionBackground() {
		return new ColorUIResource( myTextAreaSelectionBackground );
	}


	
	
	/**
	 * 
	 * TextFieldInactive Background
	 * 
	 */
	public ColorUIResource getTextFieldInactiveBackground() {
		return new ColorUIResource( myTextFieldInactiveBackground );
	}


	
	
	/**
	 * 
	 * TextFieldSelection Background
	 * 
	 */
	public ColorUIResource getTextFieldSelectionBackground() {
		return new ColorUIResource( myTextFieldSelectionBackground );
	}


	
	
	/**
	 * 
	 * TextPaneSelection Background
	 * 
	 */
	public ColorUIResource getTextPaneSelectionBackground() {
		return new ColorUIResource( myTextPaneSelectionBackground );
	}

	
	
	
	/**
	 * 
	 * ToolBar Background
	 * 
	 */
	public ColorUIResource getToolBarBackground() {
		return new ColorUIResource( myToolBarBackground );
	}




	/**
	 * 
	 * TreeSelection Background
	 * 
	 */
	public ColorUIResource getTreeSelectionBackground() {
		return new ColorUIResource( myTreeSelectionBackground );
	}


	
	
	/**
	 * 
	 * TreeHash
	 * 
	 */
	public ColorUIResource getTreeHash() {
		return new ColorUIResource( myTreeHash );
	}
}
