package phelps.io;

//import java.net.URI;
//import java.net.URL;
//import java.net.MalformedURLException;
import java.io.*;



/**
	Incrementally caches data to a cache file as it streams.
	If the data is needed as a random-access file, rather than a stream,
	{@link #getFile()} reads all the data from the stream to disk (if not already cached),
	then returns a handle to the cached location.
	This class is a low-level data mover,
	underneath a cache management policy that determines whether already cached and if so whether to refresh,
	and the path for the cache file.

	@version $Revision: 1.2 $ $Date: 2002/10/24 21:21:33 $
*/
public class InputStreamCached extends FilterInputStream {
  File outfile_ = null;
  File infile_ = null;

  /** If <code>null</code>, then fully written (or reading from file or already cached stream). */
  OutputStream out_ = null;


  /**
	Read from <var>in</var> and write to <var>cacheto</var>.
	Simple byte copier; cacheing policies to be performed by client.
  */
  //public InputStreamCached(InputStream in, File cacheto) throws FileNotFoundException {
  public InputStreamCached(InputStream in, File infile, File cacheto) throws FileNotFoundException {
	//super(new BufferedInputStream(in, 8*1024)); // too late if wait for client to wrap in BIS
	super(in);
	assert in!=null;
	//assert cacheto!=null;

//System.out.println(" cacheto = "+cacheto);
	infile_ = infile;
	outfile_ = cacheto;

	// GZipOutputStream? no, client of getFile() such as PDF may require uncompressed data
	if (cacheto!=null) out_ = new BufferedOutputStream(new FileOutputStream(cacheto), 8*1024);
  }

/*  public InputStreamCached(InputStream in) throws FileNotFoundException {
	super(new BufferedInputStream(in, 8*1024));
	out_ = null;
  }*/

  /**
	Open a stream from the <var>file</var>, which can easily be
	Provides a uniform interface to local files as to network URIs.
  public InputStreamCached(File file) throws FileNotFoundException {
	//super(new BufferedInputStream(new FileInputStream(file), 8*1024));   // wrapping in BufferedInputStream client option
	assert file!=null;

	outfile_ = file;
System.out.println(" in = out = "+outfile_);
	out_ = null;
  }
  */

/*
	If the data is already cached, it reads from the cache.
  public InputStreamCached(URI uri, File cacheto) { // => complicated: HTTP return codes, HTTP cache-control headers
	super(null);    // satisfy constructor

	InputStream is;
	String scheme = uri.getScheme();
	if ("file".equals(scheme)) {
		is = new FileInputStream(cacheto);
		out_ = null;

	} else if ("http".equals(scheme) || "https".equals(scheme) || "ftp".equals(scheme)) {
		URL url = URIs.toURL(uri);

		is = url.openConnection();
	}

	in = new BufferedInputStream(is, 8*1024);

	//in_ = in;

	// if already cached
	//out_ = new BufferedOutputStream(new FileOutputStream(cacheto));

	// else write to disk as pass on to client
  }
*/

  public void close() throws IOException {
	super.close();  // handles in.close()
	if (out_!=null) { out_.close(); out_=null; }
//System.out.println("closing "+outfile_);
	// still allow getFile()
  }


  public int read() throws IOException {
	int c = super.read();
	if (out_!=null && c>=0) out_.write(c);
	return c;
  }

  public int read(byte[] b, int off, int len) throws IOException {
	int hunk = super.read(b, off, len);
	if (out_!=null && hunk >= 0) out_.write(b, off, hunk);
	return hunk;
  }

  /**
	Cancel: terminate gracefully by closing streams and delete any incomplete cache file.
  */
  public void cancel() throws IOException {
	boolean fzap = out_!=null;
	close(); //try { close(); } catch (IOException ignore) {}
	if (fzap) outfile_.delete();
  }


  /**
	Read all data from stream into a file, {@link #close()} both input and file-writing streams, then return the file.
  */
  public File getFile() throws IOException {
//System.out.println(" CIS getFile "+outfile_);
	//if (out_==null) create in temp directory? under what name?

	// read in entirety
	if (outfile_!=null) {
		if (out_!=null) {
			byte[] buf = new byte[8*1024];
			for (int hunk; (hunk = in.read(buf)) >= 0; ) out_.write(buf, 0, hunk);
		}
	}

	close();

	// then return file
//System.out.println(" outfile_ = "+outfile_+", infile_="+infile_);
	return outfile_!=null? outfile_: infile_;
  }

  public String toString() {
	return "CIS from "+in+" to "+outfile_;
  }
}
