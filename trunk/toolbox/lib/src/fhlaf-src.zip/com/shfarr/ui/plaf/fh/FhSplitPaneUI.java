/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh;

import javax.swing.plaf.basic.*;

import javax.swing.border.Border;
import javax.swing.plaf.ComponentUI;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;

import java.awt.Graphics2D;

import java.awt.Insets;
import java.awt.Rectangle;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JSplitPane;
import javax.swing.UIManager;

import com.shfarr.ui.*;
import com.shfarr.ui.plaf.fh.ext.*;
import com.shfarr.ui.plaf.fh.textures.*;
import com.shfarr.ui.plaf.fh.theme.*;


public class FhSplitPaneUI extends BasicSplitPaneUI{

	public FhSplitPaneUI() {
		super();
	}


	public BasicSplitPaneDivider createDefaultDivider(){
	  return new FhSplitPaneDivider(this);
	}


	public static ComponentUI createUI(JComponent x){
	  return new FhSplitPaneUI();
	}


    /**
     * @version test 1.0
     * @author Stefan H. Farr
     * This software is published under the terms of General Public License
     */
	public class FhSplitPaneDivider extends BasicSplitPaneDivider{
	
		public FhSplitPaneDivider(BasicSplitPaneUI ui){
			super(ui);
		}
	
	
		protected JButton createLeftOneTouchButton(){
		  JButton b = new FhSysButton(0, 1){
		                    public void setBorder(Border b){}
		
		                    public int getType(){
			                  return getOrientation()==JSplitPane.VERTICAL_SPLIT ? FhSysButton.SIMPLE_ARROW_NORTH : FhSysButton.SIMPLE_ARROW_WEST;
		                    }
		
		                    public Color getForeground(){
			                  return getModel().isArmed() ? new Color(GraphicsUtils.channel(super.getForeground().getRGB(), 0.5, 0.0, 0.0)): super.getForeground();
		                    }
		                  };
		
		  b.setRequestFocusEnabled(false);
		  b.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		  b.setFocusPainted(false);
		  b.setBorderPainted(false);
		  b.setContentAreaFilled(false);
		  return b;
		}
	
	
		protected JButton createRightOneTouchButton() {
		  JButton b = new FhSysButton(0, 1){
		                    public void setBorder(Border b){}
		
		                    public int getType(){
			                  return getOrientation()==JSplitPane.VERTICAL_SPLIT ? FhSysButton.SIMPLE_ARROW_SOUTH : FhSysButton.SIMPLE_ARROW_EAST;
		                    }
		
		                    public Color getForeground(){
			                  return getModel().isArmed() ? new Color(GraphicsUtils.channel(super.getForeground().getRGB(), 0.5, 0.0, 0.0)): super.getForeground();
		                    }
		                  };
		
		  b.setRequestFocusEnabled(false);
		  b.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		  b.setFocusPainted(false);
		  b.setBorderPainted(false);
		  b.setContentAreaFilled(false);
		  return b;
		}
		
		
		public int getOrientation(){
		  return splitPane.getOrientation();
		}
	
	
		public void paint(Graphics g){
		  Dimension s = getSize();
		  Insets ins = getInsets()!=null ? getInsets() : new Insets(0, 0, 0, 0);
		  
		  super.paint(g);

	      Texture texture = (Texture)UIManager.getDefaults().get("SplitPane.dividerTexture");
		  
		  if(texture != null && ThemeManager.instance().probeSmallTextures() && splitPaneUI.getOrientation() == JSplitPane.HORIZONTAL_SPLIT){
		     texture.rotate(Texture.ROTATE_90);
             
             if(ThemeManager.instance().probeSmallTextures()){
                 texture.apply(new Rectangle(ins.left, ins.top +30, getSize().width -ins.left -ins.right, getSize().height -ins.top -ins.bottom), (Graphics2D)g, splitPane);
                 texture.rotate(-Texture.ROTATE_90);
             }
          }
		  else{
              texture.apply(new Rectangle(ins.left +30, ins.top, getSize().width -ins.left -ins.right, getSize().height -ins.top -ins.bottom), (Graphics2D)g, splitPane);
          }
		}
	}
}
