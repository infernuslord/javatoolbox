package tool.doc;

import java.net.URI;
import java.io.File;
import java.io.IOException;

import phelps.net.RobustHyperlink;



/**
	Compute and display lexical signature for URL.

	@version $Revision: 1.3 $ $Date: 2003/07/04 08:40:24 $
*/
public class LexSig {
  public static final String VERSION = "1.1 of $Date: 2003/07/04 08:40:24 $";
  public static final String USAGE = "java tool.doc.LexSig [-verbose] <URL-or-file>";

  boolean fverbose_, fquiet_;

  ExtractText et_ = new ExtractText();

  public LexSig() {
	defaults();
  }

  public void defaults() {
	fverbose_ = true;	// word frequency gathering lengthy process, so show progress
	fquiet_ = false;
	//out_ = phelps.io.PrintStreams.DEVNULL;
  }

	/*
	// is URL really a directory?  (I know, should ask the server)
	if (f!=null) {
		String basefile = url.getFile();
		//if (basefile.length()==0) basefile="/";
		int lastslashi = basefile.lastIndexOf('/');
		if (lastslashi==-1 || lastslashi+1 != basefile.length()) {
			if (lastslashi==-1) lastslashi=0;
			int doti = basefile.indexOf('.', lastslashi);
			String sfile = f.getAbsolutePath().replace('\\','/');
			int flastslash = sfile.lastIndexOf('/');
			if (flastslash!=-1) sfile = sfile.substring(flastslash);
//System.out.println("doti="+doti+", query="+basefile.indexOf('?')+", basefile="+basefile.substring(lastslashi)+", sfile="+sfile);
			if (doti==-1 && basefile.indexOf('?')==-1 && !basefile.substring(lastslashi).equals(sfile)) {
				try { url = new URL(url, url.getFile()+"/"); } catch (MalformedURLException canthappen) {}
			}
		}
//		System.out.println("basefile=|"+basefile+"|");
//		System.out.println("base = "+url);
	}
  */

  public String computeSignature(URI uri) throws Exception {
	String txt = et_.extract(uri, null);

	boolean v = RobustHyperlink.Verbose;
	RobustHyperlink.Verbose = fverbose_;
	String sig = RobustHyperlink.computeSignature(txt);
	RobustHyperlink.Verbose = v;
	
	return sig;
  }



  private int commandLine(String[] argv) {
	int argi = 0, argc = argv.length;
	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.startsWith("-minwordlen")) RobustHyperlink.MinWordLength = Integer.parseInt(argv[++argi]);
		else if (arg.startsWith("-pre"/*servecase"*/)) RobustHyperlink.FoldCase=false;
		//else if ("-signqueries") SignQueries=true;
		//else if ("-force") force=true;

		else if (arg.startsWith("-verb")) { fverbose_ = true; fquiet_ = false; }
		else if (arg.startsWith("-q"/*uiet*/)) { fquiet_ = true; fverbose_ = false; }
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.startsWith("-h"/*"elp"*/)) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	if (argi == argc) { System.err.println(USAGE); System.exit(0); }

	return argi;
  }

  public static void main(String[] argv) throws IOException {
	LexSig lex = new LexSig();
	int argi = lex.commandLine(argv);

	//for (Iterator<File> i = new FileList(argv, argi, FILTER).iterator(); i.hasNext() ; ) => extract text over network
	URI BASE = new File(".").getCanonicalFile().toURI();
	for (int argc=argv.length; argi < argc; argi++) {
		try {
			URI uri = BASE.resolve(argv[argi]);
			System.out.println(uri);
			String sig = lex.computeSignature(uri);
			System.out.println(sig);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	RobustHyperlink.writeCache();

	System.exit(0); // now that created some GUI thing someplace, have to exit
  }
}
