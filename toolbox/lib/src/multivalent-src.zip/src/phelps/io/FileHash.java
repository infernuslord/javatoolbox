package phelps.io;

import java.io.IOException;
import java.util.Iterator;



/**
	<i>Under development</i>
	Disk-based hash, like dbm/ndbm/gdbm, which is useful for simple key-value databases that do not require SQL queries or crash recovery.
	Keys are arbitrary strings.
	Data is an arbitrary byte array, of length up to (2^31)-1 bytes (2GB), which is the largest byte array Java will allocate.
	Disk hashes are the same across machine architectures.

	<p>Performance is biased toward an access pattern of many reads, some writes, few deletions.

	<p>To do: data space recycling, database dump, separate constructors for create and open new, automatic compression ({@link java.util.zip.Deflater}) and encryption ({@link phelps.crypto.RC4}) with flags to constructor.

	@see <a href='http://www.sleepycat.com/'>Sleepycat Software</a>
	for a commercial, supported version of gdbm, with Java bindings and ACID properties
	@see <a href='http://jdbm.sourceforge.net/'>jdbm</a>

	@author T.A. Phelps
	@version $Revision: 1.11 $ $Date: 2003/06/01 08:09:25 $
*/
public class FileHash {
  static final boolean DEBUG = true;

  public static final long NO_RECORD = -1L;


  KeyStore key_;
  DataStore data_;

  /**
	Open disk hash on passed file.
	If no such file exists, create a new disk hash.
	@param keyblocksize indirectly determines the number of keys per node, and thus the depth of tree and number of disk accesses it takes to locate the key's value.
	@throws IOException
  */
  public FileHash(String filename, int keyblocksize) throws IOException {
	this(new KeyStore(filename+".key", keyblocksize), new DataStore(filename+".data"));
  }

/*
GDBM_FILE gdbm_open(name, block_size, flags, mode, fatal_func);
void gdbm_close(dbf);
int gdbm_store(dbf, key, content, flag);
datum gdbm_fetch(dbf, key);
int gdbm_delete(dbf, key);
datum gdbm_firstkey(dbf);
datum gdbm_nextkey(dbf, key);
int gdbm_reorganize(dbf);
void gdbm_sync(dbf);
int gdbm_exists(dbf, key);
char *gdbm_strerror(errno);
int gdbm_setopt(dbf, option, value, size)
*/

  public FileHash(String filename) throws IOException { this(filename, 32*1024); }

  /*public*/ FileHash(KeyStore keystore, DataStore datastore) throws IOException {
	key_ = keystore;
	data_ = datastore;
  }


  /**
	Return data at given key, or <code>null</code> if no such key.
  */
  public byte[] get(String key) throws IOException {
	long posn = key_.get(key);
	byte[] data = null;
	if (posn != NO_RECORD) try { data = data_.readRecord(posn); } catch (InstantiationException ioe) {}
	return data;
  }

  public byte[] get(String key,  byte[] b, int offset, int length) throws IOException {
	long posn = key_.get(key);
	if (posn != NO_RECORD) try { data_.readRecord(posn, b, offset, length); } catch (InstantiationException ioe) {}
	else b = null;
	return b;
  }

  /**
	Save data at given key.
	Any existing under this key is lost.
	If new data replaces old, then it if the new data is shorter or the same size as the old it overwrites the old,
	and if the new is large than the old the new is appended.
	Zero-length data is acceptable, but negative length is not.
  */
  public void put(String key,  byte[] data, int offset, int length) throws IOException {
	assert length>=0;
	assert offset + length <= data.length;

	long posn = key_.get(key);
	long newposn = data_.writeRecord(posn,  data, offset, length);

	if (posn == NO_RECORD) key_.insert(key, newposn);
	else if (posn != newposn) key_.set(key, newposn);
  }

  // convenience methods: all translated into put(key, data, offset, length)
  public void put(String key, byte[] data) throws IOException { put(key, data, 0, data.length); }
  //public void put(String key, String data) {}
  //public void put(String key, int data) {}


  public boolean exists(String key) throws IOException {
	return key_.get(key) != NO_RECORD;
  }

  /** Remove/delete key and associated data. */
  public void remove(String key) throws IOException {
	long posn = key_.get(key);
	if (posn != NO_RECORD) {
		key_.remove(key);
		data_.removeRecord(posn);
	}
  }

  /** Returns Iterator over keys, in sorted order. */
  public Iterator<String> iterator() { return key_.iterator(); }

  /**
	Returns Iterator over keys range from <var>key1</var> to <var>key2</var>, inclusive.
	If <var>key1</var> is null, the first key in the store is used;
	if <var>key2</var> is null, the last key in the store is used.
  */
  public Iterator<String> iterator(String key1, String key2) { return key_.iterator(key1, key2); }


  /** Write pending key and data changes to disk. */
  public void flush() throws IOException {
	key_.flush();
	data_.flush();
  }

  /**
	Hash must be closed.
	Hash instance cannot be used again after close.
  */
  public void close() throws IOException {
	if (key_!=null) {
		key_.close(); data_.close();

		key_=null; // mark closed
	  }
  }

  /**
	Optimize for space by squeezing out holes in the data stream which were created by overriding data with shorter data.
	Since this generally copies all the data, it can be slow.
  */
  public void optimize() throws IOException {
	DataStore newdata = null;

	try {
		optimizeAtomic(null, null);

		key_.flush();
		// delete original data file, rename new to old name
		data_.close();

		// delete old files

		data_ = newdata;

	} catch (InstantiationException ioe) {
		// delete new files, which failed
	}
  }

  public void optimizeAtomic(KeyStore newkey, DataStore keydata) throws IOException, InstantiationException {
	// optimize to new file to avoid problems if crash during optimization and to reduce disk fragmentation
	// maybe ask data about wasted space

	// data reorgs into new instance and passes back array of posn
	// iterate over keys, find new posn, rewrite posn

	// iterate over keys
	// rewrite data while updating key offsets
	for (Iterator<String> i=key_.iterator(); i.hasNext(); ) {
		String key = i.next();
		long posn = key_.get(key);
		byte[] data = data_.readRecord(posn);

		long newposn = -1;
		key_.set(key, newposn);
	}

  }
}
