package multivalent.std.adaptor;

import java.io.Reader;
import java.io.PushbackReader;

import multivalent.*;
import multivalent.node.IVBox;
import multivalent.node.LeafUnicode;
import multivalent.node.IParaBox;



/**
	Media adaptor for plain old ASCII files (.txt => doc tree)
	groups lines into heuristically determined paragraphs
	(two styles of paragraph: blank line between and indended)
	MUST RETAIN SPACES, WHICH THIS PRESENTLY DOESN'T.

	@version $Revision: 1.4 $ $Date: 2003/06/02 05:37:46 $
*/
public class ASCII extends MediaAdaptor {
  //static final boolean DEBUG = false;

  public Object parse(INode parent) throws Exception {
	Browser br = getBrowser();
	Document doc = parent.getDocument();
	doc.getStyleSheet().getContext(null, null).zoom = getZoom();

	// LATER
	/*
		BufferedReader durlin = new BufferedReader(new InputStreamReader(urlin));
		String line;
		lines = new ArrayList<>(100);
		while ((line=durlin.readLine())!=null) lines.add(line);
		*/
	INode ascii = new IVBox("ascii",null, parent); // always return this, maybe with no children

	// ocr - para - line
	INode paraNode = null;
	INode lineNode = null;
	LeafUnicode wordLeaf = null;
	//String line;
	boolean startpara = true;
	int prcnt=0;

	PushbackReader ir = new PushbackReader(getInputUni().getReader(), 1);
	StringBuffer sb = new StringBuffer(1000);	// size to accommodate largest expected line
	//int tabwidth = 10;
	for (int ch=0; ch!=-1; ) {	//int i=0,imax=lines.size(); i<imax; /*y += h,*/ i++) {
		//line = (String)lines.get(i);
		sb.setLength(0);

		// get line
		// can't rely on host convention because reading pages from all kinds of machines
		// UNIX == 0xa, Macintosh == 0xd (?), Windoze == 0xd 0xa
		//while ((ch=in.read())!=0xd && ch!=0xa && ch!=-1) sb.append((char)ch);
		while ((ch=ir.read())!='\n' && ch!='\r' && ch!=-1) sb.append((char)ch);
		// gobble Windoze trailing 0xa
		//if (ch=='\r') { int ch2=ir.read(); if (ch2!='\n') ir.unread(ch2); }
		if (ch=='\r' && (ch=ir.read())!='\n') ir.unread(ch);
		//if (ch==0xd) { int ch2=ir.read(); if (ch2!=0xa) ir.unread(ch2); }


		// chop line into words
		//boolean blankline = (line.trim().length()==0);
		boolean blankline = (sb.length()==0);

		if (blankline) {
			// add to previous paragraph
			if (paraNode!=null) {
				lineNode = new IParaBox("Line", null, paraNode);	// IHBox?
				new LeafUnicode(" ", null, lineNode);
			}
			startpara = true;
			continue;
		}

		if (startpara) {
			paraNode = new IVBox("para", null, ascii);
			startpara = false;
		}
		lineNode = new IParaBox("Line", null, paraNode);	// IHBox?

		int start = 0;
		//for (int j=0,jmax=line.length(); j<jmax; j++) {
		for (int i=0,imax=sb.length(); i<imax; i++) {
			char wch = sb.charAt(i);
			if (wch=='\t') { // tabs get own word
				if (i>start) wordLeaf = new LeafUnicode(sb.substring(start,i), null, lineNode);
				wordLeaf = new LeafUnicode(sb.substring(i,i+1), null, lineNode);
				start = i+1;
			} else if (wch==' ') {
				if (i>start) {
					String txt = (i-start==1? phelps.lang.Strings.valueOf(sb.charAt(start)): sb.substring(start,i));
					wordLeaf = new LeafUnicode(txt, null, lineNode);
				}
				/// ignore space itself
				start = i+1;
			}
		}
		if (start < sb.length()) {
			wordLeaf = new LeafUnicode(sb.substring(start), null, lineNode);
		}

		if (++prcnt > 100 && br!=null) {
			//br.repaintNow(); prcnt=0;
			br.paintImmediately(br.getBounds()); prcnt=0;
		}
	}
	ir.close();

	return ascii;
  }
}
