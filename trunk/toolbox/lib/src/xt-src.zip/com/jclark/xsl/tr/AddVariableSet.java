// $Id: AddVariableSet.java,v 1.1 2002/04/25 18:16:48 bill Exp $

package com.jclark.xsl.tr;

import com.jclark.xsl.om.*;
import com.jclark.xsl.expr.VariableSet;

class AddVariableSet implements VariableSet
{
    private final Name var;
    private final VariableSet set;

    AddVariableSet(Name var, VariableSet set)
    {
        this.var = var;
        this.set = set;
    }

    public boolean contains(Name name)
    {
        return name.equals(var) || set.contains(name);
    }
}
