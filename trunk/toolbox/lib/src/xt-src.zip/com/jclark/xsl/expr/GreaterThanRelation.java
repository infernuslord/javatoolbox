// $Id: GreaterThanRelation.java,v 1.1 2002/04/25 18:07:49 bill Exp $

package com.jclark.xsl.expr;

class GreaterThanRelation extends NumericRelation {
    boolean relate(double d1, double d2) {
        return d1 > d2;
    }
}
