/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	Tiny Look and Feel                                                         *
*                                                                              *
*  (C) Copyright 2003, Hans Bickel                                             *
*                                                                              *
*   For licensing information and credits, please refer to the                 *
*   comment in file de.muntjak.tinylookandfeel.TinyLookAndFeel                 *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package de.muntjak.tinylookandfeel;

import java.awt.*;
import javax.swing.*;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicTextAreaUI;
import javax.swing.text.JTextComponent;

import de.muntjak.tinylookandfeel.controlpanel.*;

/**
 * TinyTextAreaUI
 * 
 * @version 1.0
 * @author Hans Bickel
 */
public class TinyTextAreaUI extends BasicTextAreaUI {
	/**
	 * Method createUI.
	 * @param mainColor
	 * @return ComponentUI
	 */
	public static ComponentUI createUI(JComponent c) {
		//System.out.println(c);
		return new TinyTextAreaUI();
	}

	/**
	 * @see javax.swing.plaf.basic.BasicTextFieldUI#installUI(javax.swing.JComponent)
	 */
	public void installUI(JComponent c) {
		super.installUI(c);

		if(!ControlPanel.isInstantiated) return;
		
		JTextArea textArea = (JTextArea)c;
		textArea.setSelectionColor(Theme.textSelectedBgColor[Theme.style].getColor());
		textArea.setSelectedTextColor(Theme.textSelectedTextColor[Theme.style].getColor());
		textArea.setBackground(Theme.textBgColor[Theme.style].getColor());
		textArea.setForeground(Theme.textTextColor[Theme.style].getColor());
		textArea.setDisabledTextColor(Theme.disColor[Theme.style].getColor());
	}
}
