package phelps.imageio.plugins;

import java.awt.image.*;
import java.awt.color.*;
import java.awt.Transparency;
import java.awt.geom.AffineTransform;
import java.awt.geom.NoninvertibleTransformException;
import java.awt.geom.Point2D;
import java.util.Arrays;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;



/**
	World's fastest Java-based CCITT FAX decoding (Group 3 1-D and Group 4), and high-quality scaling.
	Does no cacheing; always creates new image.
	Since FAX images are often 8MB in size (say, 2560x3300 pixels), performance is extremely important.

	Doesn't fit into Image I/O framework because FAX bitstream doesn't contain necessary metadata.
	Used by PDF and could by used by a TIFF decoder.

	<p>WANTED: Test data for Group 3 2-D.

	@author T.A. Phelps
	@version $Revision: 1.11 $ $Date: 2003/12/03 04:40:55 $
*/
public class Fax {
  static final boolean DEBUG = false;

  static final int MAX_CODE_BITS_WHITE=12, MAX_CODE_BITS_BLACK=13, MAX_CODE_BITS=Math.max(MAX_CODE_BITS_WHITE, MAX_CODE_BITS_BLACK);
  static final int MAX_RUN = 2560;
  /** Scaling threshold for considering a pixel black.  < 0x80 to darken.  0 (comparison >0) is too dark. */
  static final int MASK_THRESHOLD = 0x20;

  /** Map directly from up to MAX_CODE_BITS bits to run length. */
  private static /*final--not init in static block*/ short[] runW_=null, runB_;      // length of run
  /** Map from run length to number of bits eaten by that code.  Shared by decoding and encoding. */
  private static /*final*/ byte[] eatW_, eatB_, eat7_;      // # of bits in code word
  /** Map from up to 7 bits to mode (p/l/r). */
  private static /*final*/ char[] mode7_;
  /** Map from up to 7 bits to mode length (0-3). */
  private static /*final*/ int[] off7_;           // 2D controls: h/v/p + amount

  // for compression (eat @ run in eatW/B above)
  /** Map from run length to bits. */
  private static short[] wcnt2bits_, bcnt2bits_;
  /** Map from run lengths >=64 to bits, after dividing by 64. */
  private static short[] w64cnt2bits_, b64cnt2bits_;


  public static final ColorModel GRAY8_REV;	// IndexColorModel is immutable
  static {
	int[] cmap = new int[256];
	for (int i=0,imax=cmap.length; i<imax; i++) cmap[imax-i-1] = (0xff<<24) | (i<<16) | (i<<8) | i;
	//cmap[0] &= 0x00ffffff;  // white is transparent

	GRAY8_REV = new IndexColorModel(8, 256, cmap, 0, true, 0/*transparent*/, DataBuffer.TYPE_BYTE);
  }



  private Fax() {}


  public static BufferedImage decode(int K, int cols, int rows, InputStream in) throws IOException {
	return decode(K, cols, rows,  false, true, false, (byte)0, 0,  in);
  }


  /**
	Highly optimized FAX decoder.

	@param K    <0 for Group 4, 0 for Group 3, >0 for Group 3 2-D
	@param cols number of columns in decoded image
	@param rows number of rows in decoded image.  If this is not known, pass a negative number whose absolute value is an estimate, or pass 0 for an estimate computed from the number of columns.  Performance relies in accurate estimates.
	@param WHITE value of white pixel, 0 or 1
	@param in   data (should be buffered somehow, such as BufferedInputStream or ByteArrayInputStream)
  */
  public static BufferedImage decode(int K, int cols, int rows,
	boolean EndOfLine, boolean EndOfBlock, boolean EncodedByteAlign, final byte WHITE, int DamagedRowsBeforeError,
	InputStream in) throws IOException {

	assert WHITE==0 || WHITE==1;
	assert cols>0 && rows<Integer.MAX_VALUE: cols+" x "+rows;
	assert rows<Integer.MAX_VALUE;
	assert in != null;

	init();
	short[] runW=runW_, runB=runB_; byte[] eatW=eatW_, eatB=eatB_, eat7=eat7_; char[] mode7=mode7_; int[] off7=off7_;   // slightly faster to use locals vs class

	// Optimize for scanned text: black ink on white paper.
	// (1) More white than black, so just draw black.
	// (2) Java zeros byte[], so make that white, which means inverting colors in decoded data and re-inverting with color map.
	final byte BLACK=(byte)(1 - WHITE), INVALID_COLOR=2;
	final int stride = cols /*+ 1*/;  // (1) then FAX spec's bogus phantom == WHITE, then (2) edge buffer during scaling!

	byte[] line = new byte[1/*start*/+ cols +1/*screwball first code l1*/ +1/*sentinal*/], ref=new byte[line.length]; int[] lineX=new int[line.length], refX=new int[line.length];
	ref[0]=WHITE; refX[0]=0; ref[1]=INVALID_COLOR; refX[1]=cols;
	byte[] line1 = new byte[stride]; Arrays.fill(line1, (byte)1);

	int buf0 = 0 + stride/*scaling*/ + (K<0? 1: 0), bufi=buf0;      // phantom column of first line in 2D
	int bufn = 0/*stride*/;  // amount of extra space at end of buffer needed for scaling
	int fillop=0, reallocop=0, rows0=rows;  // instrumentation
	int estheight = rows; if (rows<=0) { estheight = (rows<0? -rows: (cols*3)/2); rows=Integer.MAX_VALUE; }
	byte[] buf = new byte[buf0 + stride * estheight + bufn];   // 1 pixel per element


//int hist[] = new int[MAX_RUN], chist[] = new int[128];
	int bits=0, valid=0;    // bits all run together from line to line in one big stream

	// format-specific init
	int c;
	if (K==0)/*always?*/ {   // initial EOL
		while (valid<12 && (c=in.read())!=-1) { bits = (bits<<8 | c); valid+=8; }
		if (valid>=12 && ((bits>>(valid-12))&0xfff) == 1) valid -= 12;  // always for Group 3?
//System.out.println("initial EOL");
	} //else if (K>0) { ... }

	//if (EndOfBlock) rows = Integer.MAX_VALUE;     // wait for sample data
	for (int rowi=0/*, c*/, b=-1; rowi<rows; rowi++, bufi+=stride) {

		if (bufi + stride + bufn > buf.length) { byte[] tmp=new byte[buf.length * 2]; System.arraycopy(buf,0, tmp,0, buf.length); buf=tmp; reallocop++; }

		byte color=WHITE, opcolor=BLACK;   // each line starts with white, though not necessarily on byte boundary
		int coli=0-1;   // make available to post-loop assertion
		int linei=1, refi=1;

//System.out.print(rowi+":");
		while (coli < cols) {
			char mode;
			if (K<0) {
				if (valid<7 && (c=in.read())!=-1) { bits = (bits<<8) | c; valid+=8; }  assert valid>=1; //: valid+", row="+rowi+"/"+rows+", col= "+coli;  //if (c==-1 || valid < 7) break;   // eof -- which shouldn't happen in middle of line
				b = (valid>=7? (bits >> (valid-7)): bits << (7-valid)) & 0x7f;
				mode = mode7[b];
				valid -= eat7[b];
			} else { assert K==0;   // Group 3 1-D
				mode = 'h';     // => lift out of loop
			}
			//chist[mode]++;
//System.out.print(coli+"/"+mode+"   ");

//System.out.print("  "+(char)mode);
			// run according to mode
			if (mode=='r' || mode=='l') {
				// find b1, the "next changing element to the right" of current position
				int b1 = coli + 1/*"to the right"*/;
//System.out.print(off7[b]+" "+x1+" vs refX["+refi+"]="+refX[refi]+" => ");
				while (refX[refi] < b1) refi++;
				if (ref[refi] == color) refi++;
				b1 = refX[refi];
				if (mode=='r') b1+=off7[b]; else { b1-=off7[b]; refi--; }     // if l3, could be next changing element twice, but at most twice
//System.out.println(off7[b]);
				assert 0<=linei && linei<line.length: linei+" vs "+line.length;

				line[linei]=opcolor; lineX[linei]=b1; linei++;

				coli = b1;
				byte tmpcolor=color; color=opcolor; opcolor=tmpcolor;    // 3 assignments vs "color = (color==WHITE? BLACK: WHITE);"'s assignment, comparison, jump that kills processor pipeline?

			} else if (mode=='h') {     // same as Group 3 1-D (almost)
				int run, eat;
				for (int bw=0, b1=coli; bw<2; ) {    // black and white
					while (valid<MAX_CODE_BITS && (c=in.read())!=-1) { bits = (bits<<8 | c); valid+=8; }
//if (valid<MAX_CODE_BITS) System.out.println("valid="+valid+", "+Integer.toBinaryString(bits)+" => "+Integer.toBinaryString(b));

					if (color==WHITE) {
						b = (valid>=MAX_CODE_BITS_WHITE? bits >> (valid-MAX_CODE_BITS_WHITE): bits << (MAX_CODE_BITS_WHITE-valid)) & 0xfff;
//if (valid<MAX_CODE_BITS_WHITE) System.out.println("b="+b+"/"+Integer.toBinaryString(b)+", valid="+valid+", bits="+Integer.toBinaryString(bits)+", runW[b]="+runW[b]);
						// check for validity: valid array bounds and value is valid (!= -1)
						run=runW[b]; eat=eatW[run];
					} else {
						b = (valid>=MAX_CODE_BITS_BLACK? bits >> (valid-MAX_CODE_BITS_BLACK): bits << (MAX_CODE_BITS_BLACK-valid)) & 0x1fff;
						run=runB[b]; eat=eatB[run];
					}
					valid -= eat;
					b1 += run;
//if (b1>cols) { System.out.println(b1+" > "+cols); System.exit(1); }
					assert run>=0 && eat>=2 && b1<=cols: b1+"+"+run+" > "+cols+", eat="+eat+", color="+(color==WHITE? "W":"B")+", valid="+valid+", bits="+Integer.toBinaryString(b)+" @ row="+rowi;
//System.out.print("="+(color==WHITE?'W':'B')+""+Integer.toHexString(run));
//if (color==WHITE) System.out.print("h/"+coli+".."+(coli+run)+"  ");
					if (run<64) {   // terminator as opposed to make-up code (compute total run: all makeups + terminaror) -- run length exclusive of coli==0 bump
						if (coli < 0) b1++;     // totally lame special case for "first picture element"
						coli = b1;  // and b1=coli

						bw++;
						line[linei]=opcolor; lineX[linei]=b1; linei++;
						byte tmpcolor=color; color=opcolor; opcolor=tmpcolor;
						if (coli>=cols && K==0/*G3 only (including G3 2D?)*/ && bw<2) bw=2;  // G3 can end after white; G4 requires white-black pair
					}
				}

			} else if (mode=='p') {
				// find second changing element of same color.  Not same as two of Vr or Vl
				int b1 = coli + 1;
				while (refX[refi] < b1) refi++;
				if (ref[refi] == color) refi++;    // skip over any opposite color above
				refi++;  // skip over opposite color above
				b1 = refX[refi];
				//line[linei]=color; lineX[linei]=x1; linei++; => not a transition

				coli = b1;
				// keep same color

			} else { assert mode=='x': mode+" / "+(int)mode;
				// extension -- skip
				valid -= 3;  // eat extension bits(?)
			}
//System.out.println("linei = "+linei);
		}
		assert coli == cols: rowi+": "+coli+" vs "+cols;

//System.out.println(".   refX["+linei+"] = "+cols);
		// EOL mark?
		while (valid<12 && (c=in.read())!=-1) { bits = (bits<<8 | c); valid+=8; }
		if (EndOfLine || (valid>=12 && ((bits>>(valid-12)) & 0xfff) == 1)) {    // maybe enforce end of line but always accept
			assert valid>=12 && ((bits>>(valid-12)) & 0xfff)==1: valid+" "+Integer.toBinaryString(bits);
			valid -= 12;
//System.out.println("EOL @ row="+rowi);

			// end of data or EOFB mark (second 0xfff)
			while (valid<12 && (c=in.read())!=-1) { bits = (bits<<8 | c); valid+=8; }
			if (valid<12 || ((bits>>(valid-12)) & 0xfff) == 1) rows = rowi + 1;     // break loop over rows
		}

		if (EncodedByteAlign) valid -= valid % 8;

		// set reference line to line just built by swapping (not copying)
		byte[] tmpline=ref; ref=line; line=tmpline;
		int[] tmplineX=refX; refX=lineX; lineX=tmplineX;
		ref[linei]=INVALID_COLOR; refX[linei]=cols;   // sentinals


		// transitions => buffer data
		// (pixel-per-byte vs 8 pixels-per-byte?)
		for (int i=0+BLACK; i</*=*/linei; i+=2) {  // 1-ranges only
			coli=refX[i] + bufi; int b1 = refX[i+1] + bufi, len=b1-coli;
			// buf[] filled with 0 automatically by Java, so just fill in 1s
			if (len<16) for (int j=coli; j<b1; j++) buf[j]=1;
			else System.arraycopy(line1,0, buf,coli, len);     // faster than Arrays.fill, straight System.arraycopy (lots of small runs), and very slightly faster on average than straight array setting -- what about HotSpot array bounds checking elimination?
//hist[b1-coli]++;
		}
	}

//for (int i=0,imax=hist.length; i<imax; i++) if (hist[i]>0) System.out.print(i+"="+hist[i]+"  ");  System.out.println();
//System.out.println("FAX command count r="+chist['r']+", l="+chist['l']+", h="+chist['h']+", p="+chist['p']+", x="+chist['x']);

	// from data in buf, create BufferedImage
	assert bufi == buf0 + stride * rows: bufi+" vs "+cols+"*"+rows+"="+(cols*rows);
	bufi += bufn;  // extra row for scaling
	assert buf.length - bufi >= 0: bufi+" vs "+buf.length;
	if (bufi + 2*1024/*ok to waste a little*/ < buf.length) { reallocop+=(buf.length-bufi); byte[] bufbig=buf; buf=new byte[bufi]; System.arraycopy(bufbig,0, buf,0, bufi); bufbig=null; /*reallocop+=10000;*/ }   // array not copied by DataBufferByte, which is the right thing, so make copy so don't waste space
//for (int i=0,imax=hist.length; i<imax; i++) if (hist[i]>10) System.out.print(i+"="+hist[i]+"  ");  System.out.println();
//if (reallocop>0) System.out.println("reallocop="+reallocop+", rows="+rows+"/"+rows+"/rows0="+rows0+", fillop="+fillop+" of "+cols+"x"+rows+"="+(cols*rows)+", wasted "+(buf.length-bufi));

	DataBufferByte db = new DataBufferByte(buf, bufi, buf0);
	WritableRaster r = Raster.createInterleavedRaster(db, cols,rows, stride,1, new int[] { 0 }, null);
	ColorModel cm = new ComponentColorModel(ColorSpace.getInstance(ColorSpace.CS_GRAY)/*Separation? it's inverse grayscale*/, false, true, Transparency.OPAQUE, DataBuffer.TYPE_BYTE);

	return new BufferedImage(cm, r, false, new java.util.Hashtable());
  }


  /**
	NOT IMPLEMENTED.
	Encode image as FAX -- only Group 3 implemented (which produces valid, but larger Group 4).
	Source image is interpreted as bi-tonal as follows: black pixel in source = black in FAX, non-black = white.
	@param K     <0 Group 4 (yields highest compression), >=0 Group 3 1D
  */
  public static void encode(int K, BufferedImage img, OutputStream out) throws IOException {
	init();
	short[] wcnt2bits=wcnt2bits_, w64cnt2bits=w64cnt2bits_, bcnt2bits=bcnt2bits_, b64cnt2bits=b64cnt2bits_; byte[] eatW=eatW_, eatB=eatB_, eat7=eat7_; char[] mode7=mode7_; int[] off7=off7_;

	Raster r = img.getRaster();

	char mode;
	int bits=0, valid=0, newvalid;
	for (int y=r.getMinY(), ymax=y+r.getHeight(); y<ymax; y++) {
		int trans = 0;  // transition point in previous line
		for (int x=r.getMinX(), xmax=x+r.getWidth(); x<xmax; x++) {

			// white run
			int cnt = 0;
			for (int i=x; i<xmax; i++, cnt++) if (r.getSample(x, y, 0) != 0) break;
			mode = 'h';
			if (K<0) {
				// find transition in previous line
				// since performance not as important as decode, just scan x..i
				// 'l' / 'r' / 'p'
			}
			x += cnt;

			if (mode=='h') {
				while (cnt>=64) {   // make up
					int cnt2560 = Math.min(cnt, MAX_RUN);
					newvalid = eatW[cnt2560];
					bits = (bits << newvalid) | w64cnt2bits[cnt/64];
					valid = bitsout(bits, valid + newvalid, out);
					cnt -= cnt2560;
				}
				newvalid = eatW[cnt];
				bits = (bits << newvalid) | wcnt2bits[cnt];
				valid = bitsout(bits, valid + newvalid, out);
			}


			// black run -- maybe make loop with white when working
			if (K==0 && x==xmax) continue;   // Group 3 can end in middle of b/w
			cnt=0;
			for (int i=x; i<xmax; i++, cnt++) if (r.getSample(x, y, 0) == 0) break;
			mode = 'h';
			if (K<0) {
			}
			x += cnt;

			if (mode=='h') {
				while (cnt>=64) {   // make up
					int cnt2560 = Math.min(cnt, MAX_RUN);
					newvalid = eatB[cnt2560];
					bits = (bits << newvalid) | b64cnt2bits[cnt/64];
					valid = bitsout(bits, valid + newvalid, out);
					cnt -= cnt2560;
				}
				newvalid = eatB[cnt];
				bits = (bits << newvalid) | bcnt2bits[cnt];
				valid = bitsout(bits, valid + newvalid, out);
			}
		}
	}

  }

  /**
	Output 8-bit chunks from high bits, return count of unprocessed bits (<8; == valid % 8).
  */
  private static int bitsout(int bits, int valid, OutputStream out) throws IOException {
	while (valid >= 8) {
		out.write( bits >> (valid-8) );
		valid -= 8;
	}
	return valid;
  }



  /**
	High quality and performance-optimized custom scaler for FAX images.
	Produces 8-bit indexed grayscale image:
	8-bit to (more or less) match screen depth (and avoid length conversions from 1/2/4 bits during selection and lens dragging),
	grayscale for quality,
	and indexed for transparent pixels for selections and highlight annotations.

	At present, shearing is ignored.
  */
  public static BufferedImage scale(BufferedImage img, AffineTransform iat) {
	// data
	Raster r = img.getRaster();
	final int w=r.getWidth(), stride=((ComponentSampleModel)r.getSampleModel()).getScanlineStride(), h=r.getHeight();
	DataBufferByte db = (DataBufferByte)r.getDataBuffer();
	byte[] buf = db.getData();     // efficient: doesn't make a copy
	int buf0 = db.getOffset();
//System.out.println(w+" x "+h+", off="+buf0+", stride="+stride);

	// scaled
	Point2D src = new Point2D.Double(w,h), dst=new Point2D.Double();
	iat.deltaTransform(src, dst);   // delta for inverted images
	int wsc = Math.max((int)(Math.abs(dst.getX())+0.0), 1), hsc = Math.max((int)(Math.abs(dst.getY())+0.0), 1);	// can't round (+0.5) because inverse transform would be too big
	//if (wsc==0 || hsc==0) { /*if (DEBUG)*/ System.out.println("too small: "+w+"x"+h+" scaled "+iat.getScaleX()+"x"+iat.getScaleY()); return null; }  // too small to show
	boolean frot = Math.abs(iat.getScaleX()) < Math.abs(iat.getShearY());
	//if (frot) { int tmp=wsc; wsc=hsc; hsc=tmp; }    // NO
//System.out.println(iat+": "+w+"x"+h+" => "+wsc+"*"+hsc+" = "+(wsc*hsc)+", scale by "+(w/wsc)+" x "+(h/hsc));
	final int xscale0=Math.max(1, (frot? h: w)/wsc), yscale0=Math.max(1, (frot? w: h)/hsc);
	//if (xscale==1 && yscale==1) { AffineTransformOp aop = new AffineTransformOp(iat, AffineTransformOp.TYPE_NEAREST_NEIGHBOR); return aop.filter(img, null); }   //.TYPE_BILINEAR would do useless work => dropout in MarkUp.pdf
//System.out.println(iat+": "+w+"/"+wsc+" x "+h+"/"+hsc+" => "+xscale0+" x "+yscale0);//+" = "+maxsum
	//assert wsc>0 && hsc>0: w+"x"+h+" "+iat+" => "+wsc+"x"+hsc;
	byte[] bufsc = new byte[wsc * hsc];

	// matrix
	// Java's AffineImageOp wants transform that maps (0,0) of inverted image to (0,h), but should mathematically be (0,h-1)
	// if inverted over x or y, adjust a little so have room to scoop pixels from below or to the right
	assert iat.getDeterminant() != 0.0: "can't invert "+iat;
	AffineTransform vt=null; try { vt = iat.createInverse(); } catch (NoninvertibleTransformException nte) {}
	double[] d = new double[6]; vt.getMatrix(d); if (d[4]>0.0) d[4] -= xscale0; if (d[5]>0.0) d[5] -= yscale0;
	vt = new AffineTransform(d);
//System.out.println("inverse = "+vt);

	// transform
	int k = 0;
//int[] hist = new int[maxsum+1];
	for (int i=0; i<hsc; i++) {  // worry about cumulative roundoff error?
		int xscale=xscale0, yscale=yscale0;
		if (i+1==hsc && !frot) {
			src.setLocation(0.0, i); vt.transform(src, dst);
			yscale = h - (int)(frot? dst.getX(): dst.getY());
		}
//if (i+1==hsc) System.out.println(",   last row: "+yscale0+" => "+yscale+" ("+h+"-"+yscale0+"*"+i+")");
		int maxsum=xscale*yscale; float normal=255f/maxsum;

		for (int j=0; j<wsc; j++) {
			src.setLocation(j,i); vt.transform(src, dst);
			double x=dst.getX(), y=dst.getY();  //assert x>=0.0 && y>=0.0: j+","+i+" (< "+jmax+","+imax+")  over "+vt+"  => "+x+","+y;    // sometimes just the smalles bit negative, like -0.004
			// apparently double=>int much more expensive than int=>double.  if compute x0=(int)x + xfloor=(double)x0 much faster than xfloor=Math.floor(x) + x0=(int)xfloor
			//double xfloor=Math.floor(x), yfloor=Math.floor(y);
			int x0=(int)x, y0=(int)y;
			//if (x0<0) x0=0; if (y0<0) y0=0;
			assert x0>=0 && y0>=0 && x0<w && y0<h:  j+","+i+" => "+x+"/"+x0+","+y+"/"+y0+" vs "+w+","+h;
			if (j+1==wsc && !frot) { xscale = w - x0/*w-xscale0*j*/; maxsum=xscale*yscale; normal=255f/maxsum; }	// last column gobbles up extra pixels, if any
//if (i==0 && j+1==wsc) System.out.print("last col: "+xscale0+" => "+xscale);

			// average of pixels in scaled area
			int sum = 0;
//System.out.println(iat+", xscale="+w+"/"+wsc+"="+xscale+", yscale="+h+"/"+hsc+"="+yscale);
//if (i+1==hsc /*&& j+1==wsc*/) System.out.println("  base="+(y0*stride+buf0)+" of "+buf.length+" @ ("+x0+","+y0+")");
			for (int n=0, base = y0*stride+buf0; n<yscale; n++, base+=stride)
				for (int off=base+x0, offmax=off+xscale/*Math.min(off+xscale, buf.length)*/; off<offmax; off++)
					//if (off>=buf.length) break;//{ System.out.println(j+","+i+" => "+x0+","+y0+" => "+(off-base)+","+n+" = "+off); System.exit(1); } else
					sum += buf[off];

			//assert sum>=0 && sum<=maxsum: sum;
			if (sum==0) {} else bufsc[k] = (sum==maxsum? (byte)0xff: (byte)(sum * normal + 0.5));
//System.out.print(sum+"->"+Integer.toHexString(bufsc[k]&0xff)+" ");
//hist[sum]++;
			k++;
		}
	}

//System.out.println("histogram"); for (int i=0,imax=hist.length; i<imax; i++) System.out.print(hist[i]+" ");  System.out.println();
	assert k == bufsc.length: k+" vs "+bufsc.length;


	WritableRaster rsc = Raster.createInterleavedRaster(new DataBufferByte(bufsc, bufsc.length), wsc,hsc, wsc,1, new int[] { 0 }, null);

//System.out.println(img.getColorModel().getClass().getName());
	if (img.getColorModel() instanceof IndexColorModel) {    // mask
		//for (int i=0,imax=bufsc.length; i<imax; i++) if (/*bufsc[i]!=0*/(bufsc[i]&0xff)>MASK_THRESHOLD/*signed bytes!*/) bufsc[i]=1;    // threshold
		for (int i=0,imax=bufsc.length; i<imax; i++) bufsc[i] = (/*bufsc[i]!=0*/(bufsc[i]&0xff)<MASK_THRESHOLD/*signed bytes!*/? (byte)0: (byte)1);    // threshold
		img = new BufferedImage(img.getColorModel(), rsc, false, new java.util.Hashtable());

	} else {
//System.out.println("GRAY8_REV");
//for (int i=0; i<=maxsum; i++) System.out.print(hist[i]+" ");  System.out.println();
		img = new BufferedImage(GRAY8_REV/*img.getColorModel()*/, rsc, false, new java.util.Hashtable());

		//img = phelps.OCR.xyCuts(img);
	}

	return img;
  }



  /**
	Function rather than static block so only pay for tables if view FAX.
	(Can scale without tables.)
<!--
bits / cnt
2 2
3 2
4 8
5 7
6 11
7 15
8 44
9 17

// following start with "0000"
10 5
11 7
12 46
13 20
-->
  */
  private static void init() {
	if (eatW_!=null) return;
	// Table straight from spec, which is interpreted to produce optimized tables
	// String[] not so great, but want to keep binary representation and no binary literal
	// Since both white and black have a code that starts with 1, both make full use of 13-bit table.
	String[] spec = {
	// terminator
	"0w00110101", "0b0000110111",
	"1w000111", "1b010",
	"2w0111", "2b11",
	"3w1000", "3b10",
	"4w1011", "4b011",
	"5w1100", "5b0011",
	"6w1110", "6b0010",
	"7w1111", "7b00011",
	"8w10011", "8b000101",
	"9w10100", "9b000100",
	"10w00111", "10b0000100",
	"11w01000", "11b0000101",
	"12w001000", "12b0000111",
	"13w000011", "13b00000100",
	"14w110100", "14b00000111",
	"15w110101", "15b000011000",
	"16w101010", "16b0000010111",
	"17w101011", "17b0000011000",
	"18w0100111", "18b0000001000",
	"19w0001100", "19b00001100111",
	"20w0001000", "20b00001101000",
	"21w0010111", "21b00001101100",
	"22w0000011", "22b00000110111",
	"23w0000100", "23b00000101000",
	"24w0101000", "24b00000010111",
	"25w0101011", "25b00000011000",
	"26w0010011", "26b000011001010",
	"27w0100100", "27b000011001011",
	"28w0011000", "28b000011001100",
	"29w00000010", "29b000011001101",
	"30w00000011", "30b000001101000",
	"31w00011010", "31b000001101001",
	"32w00011011", "32b000001101010",
	"33w00010010", "33b000001101011",
	"34w00010011", "34b000011010010",
	"35w00010100", "35b000011010011",
	"36w00010101", "36b000011010100",
	"37w00010110", "37b000011010101",
	"38w00010111", "38b000011010110",
	"39w00101000", "39b000011010111",
	"40w00101001", "40b000001101100",
	"41w00101010", "41b000001101101",
	"42w00101011", "42b000011011010",
	"43w00101100", "43b000011011011",
	"44w00101101", "44b000001010100",
	"45w00000100", "45b000001010101",
	"46w00000101", "46b000001010110",
	"47w00001010", "47b000001010111",
	"48w00001011", "48b000001100100",
	"49w01010010", "49b000001100101",
	"50w01010011", "50b000001010010",
	"51w01010100", "51b000001010011",
	"52w01010101", "52b000000100100",
	"53w00100100", "53b000000110111",
	"54w00100101", "54b000000111000",
	"55w01011000", "55b000000100111",
	"56w01011001", "56b000000101000",
	"57w01011010", "57b000001011000",
	"58w01011011", "58b000001011001",
	"59w01001010", "59b000000101011",
	"60w01001011", "60b000000101100",
	"61w00110010", "61b000001011010",
	"62w00110011", "62b000001100110",
	"63w00110100", "63b000001100111",

	// make-up
	"64w11011", "64b0000001111",
	"128w10010", "128b000011001000",
	"192w010111", "192b000011001001",
	"256w0110111", "256b000001011011",
	"320w00110110", "320b000000110011",
	"384w00110111", "384b000000110100",
	"448w01100100", "448b000000110101",
	"512w01100101", "512b0000001101100",
	"576w01101000", "576b0000001101101",
	"640w01100111", "640b0000001001010",
	"704w011001100", "704b0000001001011",
	"768w011001101", "768b0000001001100",
	"832w011010010", "832b0000001001101",
	"896w011010011", "896b0000001110010",
	"960w011010100", "960b0000001110011",
	"1024w011010101", "1024b0000001110100",
	"1088w011010110", "1088b0000001110101",
	"1152w011010111", "1152b0000001110110",
	"1216w011011000", "1216b0000001110111",
	"1280w011011001", "1280b0000001010010",
	"1344w011011010", "1344b0000001010011",
	"1408w011011011", "1408b0000001010100",
	"1472w010011000", "1472b0000001010101",
	"1536w010011001", "1536b0000001011010",
	"1600w010011010", "1600b0000001011011",
	"1664w011000", "1664b0000001100100",
	"1728w010011011", "1728b0000001100101",

	//"0e000000000001", "0e000000000001"  -- special case in code

	"1792 00000001000",
	"1856 00000001100",
	"1920 00000001101",
	"1984 000000010010",
	"2048 000000010011",
	"2112 000000010100",
	"2176 000000010101",
	"2240 000000010110",
	"2304 000000010111",
	"2368 000000011100",
	"2432 000000011101",
	"2496 000000011110",
	"2560 000000011111",
	};

	// Group 4 modes
	String[] modes = {
	"0p0001",   // pass

	"0h001", // + M(a0a1) + M(a1a2) - horizontal

	"0r1",    // vertical
	"1r011",    // right 1...
	"2r000011",
	"3r0000011",
	"1l010",    // left 1...
	"2l000010",
	"3l0000010",

	"0x0000001" //...xxx - extension

	};

	runW_ = new short[1<<MAX_CODE_BITS_WHITE]; runB_ = new short[1<<MAX_CODE_BITS_BLACK]; off7_ = new int[1<<7];
	eatW_=new byte[MAX_RUN+1/*0-based*/]; eatB_=new byte[MAX_RUN+1]; eat7_=new byte[off7_.length];  assert eatW_.length < runW_.length;
	mode7_=new char[off7_.length];
	// compress
	wcnt2bits_ = new short[64]; bcnt2bits_ = new short[wcnt2bits_.length];
	w64cnt2bits_ = new short[MAX_RUN/64 + 1/*0-based*/]; b64cnt2bits_ = new short[w64cnt2bits_.length];


	// mark invalid for checks during table building (0 is valid run length)
	Arrays.fill(runW_, (short)-1); Arrays.fill(runB_, (short)-1); Arrays.fill(off7_, -1);
	//assert spec.length % 2 == 0;    // black and white pairs ... plus some for both
//int h[] = new int[20];  // histogram

	// populate runs
	for (int i=0,imax=spec.length, c; i<imax; i++) {
		String tup = spec[i];
		int j=0, jmax=tup.length();
		//while ((c=tup.charAt(j))!=' ' && c!='w' && c!='b') j++; -- alternative: first find split; or use regexp to split
		short run=0; for ( ; (c=tup.charAt(j))>='0' && c<='9'; j++) run = (short)(run*10 + (c-'0'));  assert run>=0 && run<=MAX_RUN;
		byte type = (byte)c;  assert type=='w' || type=='b' || type==' ': type;
		j++;
		byte cnt = (byte)(jmax - j);  assert 2<=cnt && cnt<=MAX_CODE_BITS: cnt;
		short bits = Short.parseShort(tup.substring(j), 2/*binary*/);
//h[cnt]++;
//if (DEBUG) System.out.println(run+" "+(char)type+", bits="+cnt+", run="+run+" "+tup.substring(j)+": "+(b<<((cnt<10?9:13)-cnt))+" + 0.."+(1<<(9-(cnt<10?cnt:cnt-4))));


		if (type=='w' || type==' ') {
			assert cnt <= MAX_CODE_BITS_WHITE;
			//Arrays.fill(runW_, k, kmax, run);     // correct but be safe
			for (int k = bits<<(MAX_CODE_BITS_WHITE-cnt), kmax = k + (1<<(MAX_CODE_BITS_WHITE-cnt)); k<kmax; k++) {  // fill in low order bits too
				assert runW_[k]==-1: "W "+run+" <= "+runW_[k];
				runW_[k] = run;
			}
			eatW_[run] = cnt;
			if (run<64) wcnt2bits_[run]=bits; else w64cnt2bits_[run/64]=bits;
		}
		if (type=='b' || type==' ') {
			for (int k = bits<<(MAX_CODE_BITS_BLACK-cnt), kmax = k + (1<<(MAX_CODE_BITS_BLACK-cnt)); k<kmax; k++) {
				assert runB_[k]==-1: "B "+run+" <= "+runB_[k];
				runB_[k] = run;
			}
			eatB_[run]=cnt;
			if (run<64) bcnt2bits_[run]=bits; else b64cnt2bits_[run/64]=bits;
		}
	}

	//for (int i=0; i<32; i++) assert runW_[i]==-1 && runB_[i]==-1;
	//for (int i=32,imax=runW_.length; i<imax; i++) assert runW_[i]>=0 && runB_[i]>=0;
//	for (int i=0,imax=h.length; i<imax; i++) if (h[i]>0) System.out.println(i+" "+h[i]);
//if (DEBUG) for (int i=0,imax=run9.length; i<imax; i++) System.out.println(i+" "+eat9[i]+" "+run9[i]);


	// populate modes
	for (int i=0,imax=modes.length, c; i<imax; i++) {
		String tup = modes[i];
		int off = tup.charAt(0) - '0';  assert 0<=off && off<=3;
		char mode = tup.charAt(1);
		int jmax=tup.length();
		byte eat=(byte)(jmax-2);
		//int b = 0; for (int j=2; j<jmax; j++) b = (b<<1) | (tup.charAt(j) - '0');
		int bits = Integer.parseInt(tup.substring(2), 2);
//if (DEBUG) System.out.println(eat+" "+(char)mode+" "+tup.substring(2)+": 0.."+(1<<(7-eat)));
		for (int k = bits<<(7-eat), kmax = k + (1<<(7-eat)); k<kmax; k++) {
			assert off7_[k]==-1;
			off7_[k]=off; eat7_[k]=eat; mode7_[k]=mode;
		}
	}
  }
}
