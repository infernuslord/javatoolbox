// $Id: Importance.java,v 1.1 2002/04/25 18:18:02 bill Exp $

package com.jclark.xsl.tr;

final class Importance
{
    private final int n;

    private Importance(int n)
    {
        this.n = n;
    }

    static public Importance create()
    {
        return new Importance(0);
    }

    public Importance createHigher()
    {
        return new Importance(n + 1);
    }

    public int compareTo(Importance p)
    {
        return this.n - p.n;
    }

}
