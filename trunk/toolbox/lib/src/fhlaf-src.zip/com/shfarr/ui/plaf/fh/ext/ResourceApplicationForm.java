/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh.ext;


public class ResourceApplicationForm{
	protected String[] names;
	protected Class[] types;
	
	public ResourceApplicationForm(Object[] resourceMap){
	    initialize(resourceMap);
	}
	
	
	public ResourceApplicationForm(String[] names, Class[] types){
	    this.names = names;
	    this.types = types;
	}
    
    /**
     * Gets the names.
     * @return Returns a String[]
     */
    public String[] getNames() {
        return names;
    }

    /**
     * Sets the names.
     * @param names The names to set
     */
    public void setNames(String[] names) {
        this.names = names;
    }

    /**
     * Gets the types.
     * @return Returns a Class[]
     */
    public Class[] getTypes() {
        return types;
    }

    /**
     * Sets the types.
     * @param types The types to set
     */
    public void setTypes(Class[] types) {
        this.types = types;
    }
	
	
	public Class getResourceType(String name){
	    for(int i=0; i<names.length; i++) if(names[i].equals(name)) return types[i];
	    
	    return null;
	}
	
	public void initialize(Object[] resourceMap){
        String[] names = new String[resourceMap.length/2];
        Class[] types = new Class[resourceMap.length/2];
        
        for(int i=0; i < names.length; i++){
            names[i] = (String)resourceMap[2*i];
            types[i] = (Class)resourceMap[2*i +1];
        }
        
        setNames(names);
        setTypes(types);
	}
}
