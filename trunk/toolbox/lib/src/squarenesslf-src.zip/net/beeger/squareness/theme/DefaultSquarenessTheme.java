/*
  Copyright (C) 2003-2004 Robert F. Beeger (robert at beeger dot net)
  Licensed under the Academic Free License version 2.1
  OSI Certified Open Source Software

  Visit http://squareness.sourceforge.net/ for new releases of Squareness Look And Feel and other
  skins from the Squareness series.
*/
package net.beeger.squareness.theme;

import javax.swing.plaf.ColorUIResource;

/**
 * Created by IntelliJ IDEA.
 * User: Robert F. Beeger
 * Date: 22.08.2004
 * Time: 20:12:55
 * To change this template use File | Settings | File Templates.
 */
public class DefaultSquarenessTheme extends SquarenessTheme
{
  public String getName ()
  {
    return "Original";
  }

  public ColorUIResource getDesktopColor ()
  {
    return new ColorUIResource(234, 216, 164);
  }

  public ColorUIResource getWindowBackgroundColor ()
  {
    return new ColorUIResource(247,242,225);    
  }

  public ColorUIResource getDisabledBorderColor ()
  {
    return new ColorUIResource(134, 144, 150);
  }

  public ColorUIResource getNormalBorderColor ()
  {
    return new ColorUIResource(34, 57, 73);
  }

  public ColorUIResource getSelectedControlBackgroundColor ()
  {
    return new ColorUIResource(211, 211, 42);
  }



  public ColorUIResource getInactiveWindowBorderColor ()
  {
    return new ColorUIResource(184,175,119);
  }

  public ColorUIResource getDefaultButtonBorderColor ()
  {
    return new ColorUIResource(170,59,34);
  }

  public ColorUIResource getNormalControlBackgroundColor ()
  {
    return new ColorUIResource(219,196,99);
  }

  public ColorUIResource getSelectedControlBackgroundShadowColor ()
  {
    return new ColorUIResource(163,159,28);
  }

  public ColorUIResource getProgressBarBackgroundColor ()
  {
    return new ColorUIResource(245,246,220);
  }

  public ColorUIResource getPressedScrollBarTrackBackgroundColor ()
  {
    return new ColorUIResource(237,225,185);
  }

  public ColorUIResource getTextInputBackgroundColor ()
  {
    return new ColorUIResource(255,255,255);
  }

  public ColorUIResource getTextColor ()
  {
    return new ColorUIResource(0,0,0);
  }
}
/*
  $Log: DefaultSquarenessTheme.java,v $
  Revision 1.3  2004/09/18 17:30:47  rbeeger
  * Updated copyright block and license file. Squareness Look And Feel is now licensed under Academic Free License 2.1
  * Added themepack.

  Revision 1.2  2004/09/10 17:29:32  rbeeger
  * title pane now works for internal frame ui and root pane ui
  * SquarenessRootPaneUI is mostly a copy of MetalRootPaneUI. The only difference: the title pane.
  * Fixed bug [ 1017901 ] An undecorated frame doesn't update properly with 1.1.1: An empty border in the frame border that worked ok in internal frames, didn't work on JFrames at all.
  * Added documentation in some places.

 */
