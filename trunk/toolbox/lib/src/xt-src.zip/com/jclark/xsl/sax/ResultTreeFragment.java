// $Id: ResultTreeFragment.java,v 1.1 2002/04/25 18:16:12 bill Exp $

package com.jclark.xsl.sax;

import org.xml.sax.*;

public interface ResultTreeFragment
{
    void emit(DocumentHandler handler) throws SAXException;
}
