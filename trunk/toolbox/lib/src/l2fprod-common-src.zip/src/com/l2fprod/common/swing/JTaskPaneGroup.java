/**
 * L2FProd.com Common Components 0.1-dev License.
 *
 * Copyright 2004 L2FProd.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.l2fprod.common.swing;

import com.l2fprod.common.swing.plaf.LookAndFeelAddons;
import com.l2fprod.common.swing.plaf.TaskPaneGroupUI;

import java.awt.Component;

import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.UIManager;

/**
 * <code>JTaskPaneGroup</code> is a container for tasks and other arbitrary
 * components. <code>JTaskPaneGroup</code> s are added to a
 * {@link com.l2fprod.common.swing.JTaskPane}.<code>JTaskPaneGroup</code>
 * provides control to be expanded and collapsed in order to show or hide the
 * task list. It can have an <code>icon</code>, a <code>text</code> and
 * can be marked as <code>special</code>. Marking a <code>JTaskPaneGroup</code>
 * as <code>special</code> is only an hint for the pluggable UI which will
 * usually paint it differently (by example by using another color for the
 * border of the pane).
 */
public class JTaskPaneGroup extends JComponent {

  // ensure at least the default ui is registered
  static {
    try {
      Class.forName(LookAndFeelAddons.class.getName());
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    }
  }

  public static final String EXPANDED_CHANGED_KEY = "expanded";

  public static final String TEXT_CHANGED_KEY = "text";

  public static final String ICON_CHANGED_KEY = "icon";

  private String text;
  private Icon icon;
  private boolean special;
  private boolean expanded = true;

  /**
   * Creates a new empty <code>JTaskPaneGroup</code>.
   *  
   */
  public JTaskPaneGroup() {
    updateUI();
    setFocusable(true);
  }

  /**
   * Notification from the <code>UIManager</code> that the L&F has changed.
   * Replaces the current UI object with the latest version from the <code>UIManager</code>.
   * 
   * @see javax.swing.JComponent#updateUI
   */
  public void updateUI() {
    setUI(((TaskPaneGroupUI)UIManager.getUI(this)));
  }

  /**
   * Sets the L&F object that renders this component.
   * 
   * @param ui the <code>TaskPaneGroupUI</code> L&F object
   * @see javax.swing.UIDefaults#getUI
   * 
   * @beaninfo bound: true hidden: true description: The UI object that
   * implements the taskpane group's LookAndFeel.
   */
  public void setUI(TaskPaneGroupUI ui) {
    super.setUI(ui);
  }

  public TaskPaneGroupUI getUI() {
    return (TaskPaneGroupUI)ui;
  }

  /**
   * Returns the name of the L&F class that renders this component.
   * 
   * @return the string "TaskPaneGroupUI"
   * @see javax.swing.JComponent#getUIClassID
   * @see javax.swing.UIDefaults#getUI
   */
  public String getUIClassID() {
    return "TaskPaneGroupUI";
  }

  /**
   * Returns the text currently displayed in the border of this pane.
   * 
   * @return
   */
  public String getText() {
    return text;
  }

  /**
   * Sets the text to be displayed in the border of this pane.
   * 
   * @param text
   */
  public void setText(String text) {
    String old = text;
    this.text = text;
    firePropertyChange(TEXT_CHANGED_KEY, old, text);
  }

  /**
   * Returns the icon currently displayed in the border of this pane.
   * 
   * @return
   */
  public Icon getIcon() {
    return icon;
  }

  /**
   * Sets the icon to be displayed in the border of this pane. Some pluggable
   * UIs may impose size constraints for the icon. A size of 16x16 pixels is
   * the recommended icon size.
   * 
   * @param icon
   */
  public void setIcon(Icon icon) {
    Icon old = icon;
    this.icon = icon;
    firePropertyChange(ICON_CHANGED_KEY, old, icon);
  }

  /**
   * Returns true if this pane is "special".
   * 
   * @return
   */
  public boolean isSpecial() {
    return special;
  }

  /**
   * Sets this pane to be "special" or not.
   * 
   * @param isSpecial
   */
  public void setSpecial(boolean isSpecial) {
    this.special = isSpecial;
  }

  /**
   * Expands or collapses this group.
   * 
   * @param expanded
   */
  public void setExpanded(boolean expanded) {
    if (this.expanded != expanded) {
      boolean old = this.expanded;
      this.expanded = expanded;
      firePropertyChange(EXPANDED_CHANGED_KEY, old, expanded);
    }
  }

  /**
   * Returns true if this taskpane is expanded, false if it is collapsed.
   * 
   * @return true if this taskpane is expanded, false if it is collapsed.
   */
  public boolean isExpanded() {
    return expanded;
  }

  /**
   * Adds an action to this <code>JTaskPaneGroup</code>. Returns a component
   * built from the action. The returned component has been added to the <code>JTaskPaneGroup</code>.
   * 
   * @param action
   * @return
   */
  public Component add(Action action) {
    Component c = ((TaskPaneGroupUI)ui).createAction(action);
    add(c);
    return c;
  }

  protected String paramString() {
    return super.paramString()
      + ",text="
      + getText()
      + ",icon="
      + getIcon()
      + ",expanded="
      + String.valueOf(isExpanded())
      + ",special="
      + String.valueOf(isSpecial());
  }

}
