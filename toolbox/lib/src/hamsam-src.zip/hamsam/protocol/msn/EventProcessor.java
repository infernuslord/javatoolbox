/*
 * Hamsam - Instant Messaging API
 * Copyright (C) 2003 Raghu K
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package hamsam.protocol.msn;

import hamsam.api.IMListener;
import hamsam.api.Buddy;
import hamsam.api.Conference;
import hamsam.api.Message;
import hamsam.api.Response;

/**
 * @author raghuk
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
/**
 * Collects all events from the MsnServers and sends those to the listener for
 * MSN protocol.
 */
class EventProcessor
{
	/**
	 * MsnProtocol for this event processor.
	 */
	private MsnProtocol protocol;

	/**
	 * IMListener for this event processor.
	 */
	private IMListener listener;

	/**
	 * Default constructor.
	 *
	 * @param protocol the MsnProtocol for this event processor.
	 */
	EventProcessor(MsnProtocol protocol)
	{
		this.protocol = protocol;
	}

	/**
	 * Sets the listener for this protocol.
	 *
	 * @param listener the IMListener for this event processor.
	 */
	void setListener(IMListener listener)
	{
		this.listener = listener;
	}

	/**
	 * Invoked when there is a failure during the start up.
	 *
	 * @param reasonMessage the reason for the failure as a string.
	 */
	void connectFailed(String reasonMessage)
	{
		if(listener != null)
			listener.connectFailed(protocol, reasonMessage);
	}

	/**
	 * Invoked when we login successfully.
	 */
	void connected()
	{
		if(listener != null)
			listener.connected(protocol);
	}

	/**
	 * Invoked when the buddy list is received from the server upon login.
	 *
	 * @param buddies the array of buddies
	 */
	void buddyListReceived(Buddy[] buddies)
	{
		if(listener != null)
			listener.buddyListReceived(protocol, buddies);
	}

	/**
	 * Invoked when the protocol is disconnected, normally or abnormally.
	 */
	void disconnected()
	{
		if(listener != null)
			listener.disconnected(protocol);
	}

	/**
	 * Invoked when an attempt to remove a buddy fails.
	 *
	 * @param buddy buddy whom you tried to remove
	 * @param reason the reason for failure as a descriptive string
	 */
	void buddyDeleteFailed(Buddy buddy, String reason)
	{
		if(listener != null)
			listener.buddyDeleteFailed(buddy, reason);
	}

	/**
	 * Invoked when a swichboard invitation is received.
	 *
	 * @param conf the conference to which this user was invited
	 * @param message the invitation message
	 */
	Response conferenceInvitationReceived(Conference conf, String message)
	{
		if(listener != null)
			return listener.conferenceInvitationReceived(conf, message);
		else
			return null;
	}

	/**
	 * Invoked when a buddy joins a swichboard session.
	 *
	 * @param conf the conference referred to.
	 * @param buddy the buddy who joined the conference.
	 */
	void conferenceParticipantJoined(Conference conf, Buddy buddy)
	{
		if(listener != null)
			listener.conferenceParticipantJoined(conf, buddy);
	}
	
	/**
	 * Invoked when a conference message arrives from the MSN server.
	 * 
	 * @param conf the conference to which the message arrived.
	 * @param buddy the buddy who sent this message.
	 * @param msg the message that arrived.
	 */
	void conferenceMessageReceived(Conference conf, Buddy buddy, Message msg)
	{
		if(listener != null)
			listener.conferenceMessageReceived(conf, buddy, msg);
	}

	/**
	 * Invoked when a buddy leaves from a conference.
	 *
	 * @param conf the conference we are talking about
	 * @param buddy the buddy who left
	 */
	void conferenceParticipantLeft(Conference conf, Buddy buddy)
	{
		if(listener != null)
			listener.conferenceParticipantLeft(conf, buddy);
	}

	/**
	 * Invoked when the status of a buddy changes.
	 *
	 * @param buddy
	 */
	void buddyStatusChanged(Buddy buddy)
	{
		if(listener != null)
			listener.buddyStatusChanged(buddy);
	}

	/**
	 * Invoked when a message from protocol is to be delivered to the user.
	 *
	 * @param message the message from MSN protocol
	 */
	void protocolMessageReceived(Message message)
	{
		if(listener != null)
			listener.protocolMessageReceived(protocol, message);
	}

	/**
	 * Invoked when an E-mail alert comes from MSN.
	 *
	 * @param count the number of e-mails arrived
	 * @param from the sender's E-mail address
	 * @param subject the subject line of the mail
	 */
	void mailNotificationReceived(int count, String from, String subject)
	{
		if(listener != null)
		{
			String[] fromArray = from == null? null : new String[] { from };
			String[] subjectArray = subject == null ? null : new String[] { subject };
			listener.mailNotificationReceived(protocol, count, fromArray, subjectArray);
		}
	}

	/**
	 * Invoked when a conference is closed.
	 *
	 * @param conf
	 */
	void conferenceClosed(Conference conf)
	{
		if(listener != null)
			listener.conferenceClosed(conf);
	}
}
