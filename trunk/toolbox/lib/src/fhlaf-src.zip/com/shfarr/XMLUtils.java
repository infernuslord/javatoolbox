package com.shfarr;

import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLDecoder;
import java.util.StringTokenizer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * $COPYRIGHT$
 * $Id: XMLUtils.java,v 1.4 2004/06/21 17:44:39 borzy Exp $
 * 
 * Created on: Apr 24, 2004
 * Author: Borsos Szabolcs
 */

public class XMLUtils {
    private String openedFromURL;
    private Document doc;

    public XMLUtils(String pathToXML) {
        openedFromURL = pathToXML;
        doc = getDocument(pathToXML);
    }
    
    public void save() {
        saveAs(openedFromURL);
    }
    
    public void saveAs(String newLocation) {
        try {
            String url = getClass().getResource(newLocation).toString();
            url = url.substring(5);
            PrintWriter out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(URLDecoder.decode(url))));
            OutputFormat outForm = new OutputFormat(doc);
            XMLSerializer serializer = new XMLSerializer(out, outForm);
            outForm.setIndenting(true);
            serializer.serialize(doc.getDocumentElement());
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    /**
     * Returns the number of child nodes for the specified node which have the specified name and 
     * an attribute with this name value.
     * @param pathToElement path to the node of which child want to count.
     * @param childsNameToCount the child nodes name which will be counted.
     * @param attrName the attribute name which will be searched in child nodes found with the specified name.
     * @param attrValue the attribute value which will be searched in child nodes found with the specified name.
     * @return the number of child nodes which met the conditions.
     */
    public int getChildCount(String pathToElement, String childsNameToCount, String attrName, String attrValue) {
        int childCount = 0;
        
        try {
            Element parent = getElement(pathToElement);
            NodeList nl = parent.getChildNodes();
            for (int i = 0; i < nl.getLength(); i++) {
                if (nl.item(i).getNodeName().startsWith(childsNameToCount)) {
                    if (attrName == null || attrName.equals("") || attrValue == null) childCount++;
                    else if (getElement(pathToElement + "/" + nl.item(i).getNodeName()).getAttribute(attrName).equals(attrValue)) childCount++;
                }
            }
        } catch (Exception ex) {}
        
        return childCount;
    }
    
    /**
     * Returns the number of child nodes for the specified node which have the specified name.
     * @param pathToElement  path to the node of which child want to count.
     * @param childsNameToCount the child nodes name which will be counted.
     * @return the number of child nodes which met the conditions.
     */
    public int getChildCount(String pathToElement, String childsNameToCount) {
        return getChildCount(pathToElement, childsNameToCount, null, null);
    }
    
    public Node getChildNamed(String pathToElement, String childName, boolean caseSensitive) {
    	NodeList childs = getElement(pathToElement).getChildNodes();

    	for (int i = 0; i < childs.getLength(); i++) {
    		if (caseSensitive ? childs.item(i).getNodeName().equals(childName) : childs.item(i).getNodeName().equalsIgnoreCase(childName)) {
    			return childs.item(i);
    		}
    	}

    	return null;
    }
    
    public Element getElement(String pathToElement) {
        StringTokenizer st = new StringTokenizer(pathToElement, "/");
        Node node = null;
        
        while (st.hasMoreTokens()) {
            String current = st.nextToken();
            if (node == null) node = getNode(current, null);
            else node = getNode(current, node);
        }
        
        if (node != null) return (Element) node;
        else return null;        
    }

    public Element getElement(String pathToElement, String key, String value) {
        StringTokenizer st = new StringTokenizer(pathToElement, "/");
        Node node = null;
        
        while (st.hasMoreTokens()) {
            String current = st.nextToken();
            if (node == null) node = getNode(current, null, key, value, !st.hasMoreTokens());
            else node = getNode(current, node, key, value, !st.hasMoreTokens());
            if (node == null) return null;
        }
        
        if (node != null) return (Element) node;
        else return null;        
    }
    
    public Node getNode(String name, Node parent) {
        Node ret = null;
        Node node;
        
        if (parent == null) node = doc.getDocumentElement().getFirstChild();
        else node = parent.getFirstChild();
        
        while (node != null) {
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                if ((((Element) node).getTagName()).equals(name)) ret = node;
            }
            node = node.getNextSibling();
        }
        return ret;
    }

    public Node getNode(String name, Node parent, String key, String value, boolean isLast) {
        Node node;
        
        if (parent == null) node = doc.getDocumentElement().getFirstChild();
        else node = parent.getFirstChild();
        
        while (node != null) {
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element el = (Element)node;
                if (el.getTagName().equals(name)) {
                    if (!isLast) return node;
                    else if (el.getAttribute(key).equals(value)) return node;
                }
            }
            node = node.getNextSibling();
        }
        return null;
    }

	public void setNodeValue(String name, String v)  {
		Element e = getElement(name);
		NodeList nl = e.getChildNodes();
		if (nl.getLength() > 0) nl.item(0).setNodeValue(v);
		else e.appendChild(doc.createTextNode(v));
	}

	public String getNodeValue(String name)  {
		String ret = "";
		NodeList nl = getElement(name).getChildNodes();
		for (int i = 0; i < nl.getLength(); i++) ret = ret + nl.item(i).getNodeValue();
		return ret;
	}

    public String getAbsolutePath(Element elem) {
        StringBuffer path = new StringBuffer(elem.getNodeName());
        
        try {
            Element parent = elem;
            while ((parent = (Element) parent.getParentNode()) != null) {
                path.insert(0, parent.getNodeName() + "/");
            }
        } catch (Exception ex) {}
        
        return path.toString();
    }
    
    private Document getDocument(String path) {
        Document document = null;
        try {
            URL url = new URL("file:/" + path);
            DocumentBuilderFactory doomFactory = DocumentBuilderFactory.newInstance();
            doomFactory.setValidating(false);
            DocumentBuilder doomBuilder = doomFactory.newDocumentBuilder();
            
            if (url != null) {
                document = doomBuilder.parse(URLDecoder.decode(url.toString()));
            } else {
                System.out.println("The specified url to the xml is not correct!");
                throw new RuntimeException();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return document;
    }
}
