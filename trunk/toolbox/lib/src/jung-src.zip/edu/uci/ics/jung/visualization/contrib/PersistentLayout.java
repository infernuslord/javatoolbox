/*
 * Created on Oct 9, 2004
 *
  */
package edu.uci.ics.jung.visualization.contrib;

import java.io.IOException;
import java.io.Serializable;

import edu.uci.ics.jung.visualization.Layout;

/**
 * interface for PersistentLayout
 * Also holds a nested class Point to serialize the
 * Vertex locations
 * 
 * @author Tom Nelson - RABA Technologies
 */
public interface PersistentLayout extends Layout {
    
    void persist(String fileName) throws IOException;

    void restore(String fileName) throws IOException, ClassNotFoundException;
    
    void lock(boolean state);
    
    /**
     * a serializable class to save locations
     */
    static class Point implements Serializable {
        public double x;
        public double y;
        public Point(double x, double y) {
            this.x=x;
            this.y=y;
        }
    }

}