package multivalent.std.adaptor;

import java.io.*;
import java.util.*;

import multivalent.MediaAdaptor;



/**
	Superclass for byte stream-based document formats.

	@see multivalent.std.adaptor.ManualPage

	@version $Revision: 1.3 $ $Date: 2002/10/14 17:05:37 $
*/
public abstract class MediaAdaptorByte extends MediaAdaptor {

// no functionality now, but keep as grouping class for the future
/*
  // big endian
  protected int read() {}
  protected int read2() {}
  protected int read4() {}
  protected int readN() {}

  // little endian
  protected int read() {}
  protected int read2LE() {}
  protected int read4LE() {}
  protected long readNLE() {}

*/

/*
  protected void eatLine() throws IOException {
	int ch;
	while ((ch=is_.read())!='\n' && ch!='\r' && ch!=-1) {/*eat* /}
	if (ch=='\r' && (ch=is_.read())!='\n') is_.unread(ch);  // Doze
  }*/

  // binary data type readers: readInt(), ... => wrap in DataInputStream
}
