/*
  Copyright (C) 2003-2004 Robert F. Beeger (robert at beeger dot net)
  Licensed under the Academic Free License version 2.0
  OSI Certified Open Source Software

  Visit http://squareness.sourceforge.net/ for new releases of Squareness Look And Feel and other
  skins from the Squareness series.
*/
package net.beeger.squareness.delegate;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.MouseListener;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicSpinnerUI;

import net.beeger.squareness.SquarenessConstants;

/**
 * The Squareness Spinner UI Delegate.
 */
public class SquarenessSpinnerUI extends BasicSpinnerUI
{
  /**
   * Create the UI delegate for the given component
   * 
   * @param component The component for which to create the ui delegate
   * @return The created ui delegate
   */
  public static ComponentUI createUI (JComponent component)
  {
    return new SquarenessSpinnerUI();
  }

  /**
   * Install the UI delegate for the given component.
   *
   * @param component The component for which to install the UI delegate.
   */
  public void installUI (JComponent component)
  {
    super.installUI(component);
    _nextButton.addActionListener(SwingUtilities.getUIActionMap(spinner).get("increment"));
    _nextButton.addMouseListener((MouseListener) SwingUtilities.getUIActionMap(spinner).get("increment"));
    _previousButton.addActionListener(SwingUtilities.getUIActionMap(spinner).get("decrement"));
    _previousButton.addMouseListener((MouseListener) SwingUtilities.getUIActionMap(spinner).get("decrement"));
  }

  /**
   * Create the button which increases the value of the spinner.
   *
   * @return The created button
   */
  protected Component createNextButton ()
  {
    _nextButton = new JButton(UIManager.getIcon(SquarenessConstants.SPIN_UP_KEY));
    _nextButton.setPreferredSize(new Dimension(16, 16));
    _nextButton.setMinimumSize(new Dimension(5, 5));
    _nextButton.setHorizontalAlignment(SwingConstants.CENTER);
    _nextButton.setVerticalAlignment(SwingConstants.CENTER);
    return _nextButton;

  }

  /**
   * Create the button which decreases the value of the spinner.
   *
   * @return The create button
   */
  protected Component createPreviousButton ()
  {
    _previousButton = new JButton(UIManager.getIcon(SquarenessConstants.SPIN_DOWN_KEY));
    _previousButton.setPreferredSize(new Dimension(16, 16));
    _previousButton.setMinimumSize(new Dimension(5, 5));
    _previousButton.setHorizontalAlignment(SwingConstants.CENTER);
    _previousButton.setVerticalAlignment(SwingConstants.CENTER);
    return _previousButton;
  }

  private JButton _previousButton;
  private JButton _nextButton;

}

/*
  $Log: SquarenessSpinnerUI.java,v $
  Revision 1.4  2004/03/08 15:12:26  rbeeger
  Added and enhanced comments.
  Simplified code.

  Revision 1.3  2004/02/14 19:12:34  rbeeger
  Updated copyright statement
  Added cvs log directive at the end of each file
  Optimized imports
  Reformated code

 */
