/**
 * L2FProd.com Common Components 0.1-dev License.
 *
 * Copyright 2004 L2FProd.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.l2fprod.common.swing;

import com.l2fprod.common.swing.plaf.LookAndFeelAddons;
import com.l2fprod.common.swing.plaf.TaskPaneUI;

import java.awt.Dimension;
import java.awt.Rectangle;

import javax.swing.JComponent;
import javax.swing.JViewport;
import javax.swing.Scrollable;
import javax.swing.UIManager;

/**
 * <code>JTaskPane</code> provides an elegant view to display a list of tasks
 * ordered by groups. It can be added to a JScrollPane.
 *
 * @beaninfo
 *  attribute: isContainer true
 *  description: A component that contains groups and tasks.
 */
public class JTaskPane extends JComponent implements Scrollable {

  // ensure at least the default ui is registered
  static {
    try {
      Class.forName(LookAndFeelAddons.class.getName());
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    }
  }

  /**
   * Creates a new empty taskpane.
   *  
   */
  public JTaskPane() {
    updateUI();
  }

  /**
   * Notification from the <code>UIManager</code> that the L&F has changed.
   * Replaces the current UI object with the latest version from the <code>UIManager</code>.
   * 
   * @see javax.swing.JComponent#updateUI
   */
  public void updateUI() {
    setUI(((TaskPaneUI)UIManager.getUI(this)));
  }

  /**
   * Sets the L&F object that renders this component.
   * 
   * @param ui the <code>TaskPaneUI</code> L&F object
   * @see javax.swing.UIDefaults#getUI
   * 
   * @beaninfo bound: true hidden: true description: The UI object that
   * implements the taskpane's LookAndFeel.
   */
  public void setUI(TaskPaneUI ui) {
    super.setUI(ui);
  }

  /**
   * Returns the name of the L&F class that renders this component.
   * 
   * @return the string "TaskPaneUI"
   * @see javax.swing.JComponent#getUIClassID
   * @see javax.swing.UIDefaults#getUI
   */
  public String getUIClassID() {
    return "TaskPaneUI";
  }

  /**
   * Adds a new <code>JTaskPaneGroup</code> to this JTaskPane.
   * 
   * @param group
   */
  public void add(JTaskPaneGroup group) {
    super.add(group);
  }

  /**
   * Removes a new <code>JTaskPaneGroup</code> from this JTaskPane.
   * 
   * @param group
   */
  public void remove(JTaskPaneGroup group) {
    super.remove(group);
  }

  public Dimension getPreferredScrollableViewportSize() {
    return getPreferredSize();
  }
  
  public int getScrollableBlockIncrement(
    Rectangle visibleRect,
    int orientation,
    int direction) {
    return 1;
  }
  
  public boolean getScrollableTracksViewportHeight() {
    if (getParent() instanceof JViewport) {
      return (((JViewport)getParent()).getHeight() > getPreferredSize().height);
    } else {
      return false;
    }
  }
  
  public boolean getScrollableTracksViewportWidth() {
    return true;
  }
  
  public int getScrollableUnitIncrement(
    Rectangle visibleRect,
    int orientation,
    int direction) {
    return 10;
  }
  
}
