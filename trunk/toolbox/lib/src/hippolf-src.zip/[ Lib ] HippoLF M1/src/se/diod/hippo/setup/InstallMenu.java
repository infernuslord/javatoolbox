package se.diod.hippo.setup;


import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.LookAndFeel;
import javax.swing.SwingUtilities;
import javax.swing.ButtonGroup;

import se.diod.hippo.plaf.HippoLookAndFeel;
import se.diod.hippo.plaf.theme.HippoTheme;
import se.diod.hippo.plaf.theme.ThemeUtil;




/**
 * 
 * @author Robert Karlsson
 * @created 2003-okt-26
 *
 */
public class InstallMenu implements ActionListener {
	private ThemeListener	tl				= new ThemeListener();

	private JMenuBar		currentMenuBar	= null;
	private JFrame			frame			= null;
	private JMenu			themeSubMenu	= null;

	private static String[][] looks;




	/**
	 * 
	 * Creates a Look and Feel selection menu on the
	 * specified menubar.
	 *
	 * @param aFrame The top frame that is going to use HippoLF
	 * @param aMenuBar The menubar to add the menu to
	 * @param setAsDefaultLnF If true HippoLF will be activated
	 * @param aTitle The title of the menu
	 * 
	 */
	public void createMenu( JFrame aFrame, JMenuBar aMenuBar, boolean setAsDefaultLnF, String menuTitle, boolean showThemeMenu ) {
		SwingUtilities.updateComponentTreeUI( aFrame );

		this.frame			= aFrame;
		this.currentMenuBar = aMenuBar;

		InstallLF.install( setAsDefaultLnF, aFrame );					// Install LnF

		JMenu plafMenu = createMenuItems( menuTitle, showThemeMenu );	// Create menu items
		currentMenuBar.add( plafMenu );									// Add menu to menubar

		SwingUtilities.updateComponentTreeUI( aFrame );
	}




	/**
	 * 
	 * 
	 */
	private JMenu createMenuItems( String menuTitle, boolean showThemeSubMenu ) {
		LookAndFeelInfo[] PLAFinfo = InstallLF.getInstalledPLAFs();

		JMenu plafMenu		= new JMenu( menuTitle );
		String[] menuItems	= new String[ PLAFinfo.length ];
		looks				= new String[ PLAFinfo.length ][ 2 ];
		
		ButtonGroup group = new ButtonGroup();

		for( int i = 0; i < menuItems.length; i++ ) {
			JRadioButtonMenuItem tmpItem = new JRadioButtonMenuItem( PLAFinfo[ i ].getName() );
			tmpItem.addActionListener( this );
			plafMenu.add( tmpItem );
			group.add( tmpItem );

			if( UIManager.getLookAndFeel().getName().equals( PLAFinfo[ i ].getName() ) ) {
				tmpItem.setSelected( true );
			}

			looks[i][0] = PLAFinfo[ i ].getName();
			looks[i][1] = PLAFinfo[ i ].getClassName();
		}

		if( showThemeSubMenu ) {
			plafMenu.addSeparator();
			plafMenu.add( createThemeSubMenuItems( "Themes" ) );
		}

		return plafMenu;
	}






	/**
	 * 
	 * 
	 */
	private JMenu createThemeSubMenuItems( String menuTitle ) {
		String[] availableThemes = ThemeUtil.getAvailableThemes();

		JMenu themeMenu		= new JMenu( menuTitle );
		String[] menuItems	= new String[ availableThemes.length ];

		ButtonGroup group = new ButtonGroup();

		for( int i = 0; i < menuItems.length; i++ ) {
			JRadioButtonMenuItem tmpItem = new JRadioButtonMenuItem( availableThemes[ i ] );
			tmpItem.addActionListener( tl );
			themeMenu.add( tmpItem );
			group.add( tmpItem );

			if( UIManager.getLookAndFeel() instanceof HippoLookAndFeel ) {
				HippoTheme theme = HippoLookAndFeel.getMyCurrentTheme();
				if( availableThemes[ i ].equalsIgnoreCase( theme.getName() ) )
					tmpItem.setSelected( true );
			}
		}

		themeSubMenu = themeMenu;
		return themeMenu;
	}




	////////////////////////////////////////////////////////
	//                      Listener                      //
	////////////////////////////////////////////////////////
	public void actionPerformed( ActionEvent aevent ) {
		Object hit		= aevent.getSource();
		String LnFName	= ( ( JMenuItem )hit ).getText();

		if( LnFName.equalsIgnoreCase( "Hippo" ) ) {
			themeSubMenu.enable();
		} else {
			themeSubMenu.disable();
		}

		try {
			for( int i = 0; i < looks.length; i++ ) {
				if( LnFName.equals( looks[i][0] )) {
					UIManager.setLookAndFeel( looks[ i ][ 1 ] );
					InstallLF.refreshUI( frame );
				}
			}
		} catch (Exception e) {
			System.err.println("Can't set look & feel:" + e);
			return;
		};
	}






	/**
	 * 
	 * @author Robert Karlsson
	 * @created 2004-feb-10
	 *
	 */
	private class ThemeListener implements ActionListener {
		public void actionPerformed( ActionEvent aevent ) {
			try{
				Object hit			= aevent.getSource();
				String ThemeName	= ( ( JMenuItem )hit ).getText();
	
				LookAndFeel lnf = UIManager.getLookAndFeel();
	
				if( UIManager.getLookAndFeel() instanceof HippoLookAndFeel ) {
					HippoLookAndFeel.setMyCurrentTheme( HippoLookAndFeel.createTheme( ThemeName ) );
					UIManager.setLookAndFeel( "se.diod.hippo.plaf.HippoLookAndFeel" );
					InstallLF.refreshUI( frame );
				}
			} catch (Exception e) {
				System.err.println("Can't set look & feel:" + e);
				return;
			};
		}
	}
}
