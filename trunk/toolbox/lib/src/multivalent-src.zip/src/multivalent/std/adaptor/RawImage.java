package multivalent.std.adaptor;

import multivalent.MediaAdaptor;
import multivalent.Document;
import multivalent.INode;
import multivalent.node.LeafImage;


/**
	MediaAdaptor that builds tree to show raw image, PNG/JPEG/GIF/XBM.

	@version $Revision: 1.3 $ $Date: 2002/10/16 08:56:15 $
*/
public class RawImage extends MediaAdaptor {
  public Object parse(INode parent) throws Exception {
	Document doc = parent.getDocument();
	LeafImage l = new LeafImage("image",null, doc, doc.getURI());

	// using ImageIO, put metadata in Document
	// ...

	return l;  // constructed image
  }
}
