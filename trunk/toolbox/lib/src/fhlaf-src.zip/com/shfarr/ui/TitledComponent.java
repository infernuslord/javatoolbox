/*
 * Created on Oct 9, 2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package com.shfarr.ui;

import java.awt.BorderLayout;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import com.shfarr.ui.layouts.QueueLayout;

/**
 * @author shfarr
 */
public class TitledComponent extends JPanel{
    protected JPanel titlePane = null;
    protected JLabel title = null;
    protected JComponent component = null;
    protected JScrollPane scrollPane = null;
    
    public TitledComponent(String title){
        super(new BorderLayout(0, 0));
        
        scrollPane = createScrollPane();        
        
        this.titlePane = new JPanel(new QueueLayout(2, QueueLayout.HORIZONTAL, QueueLayout.STRECH_COMPONENTS));
        this.titlePane.setBorder(new EmptyBorder(2, 2, 2, 2));

        this.title = new JLabel(title);
        this.title.setBorder(new EmptyBorder(3, 3, 3, 3));
        
        this.titlePane.add(this.title, QueueLayout.BEGIN);

        add(titlePane, "North");
        add(scrollPane, "Center");
    }

    public TitledComponent(String title, JComponent jc){
        this(title);
        setComponent(jc);
    }
    
    protected JScrollPane createScrollPane(){
        return new JScrollPane();
    }
    
    public void setComponent(JComponent jc){
        this.component = jc;
        this.scrollPane.setViewportView(jc);
        
        revalidate();
    }

    public void setTitle(String title){
        this.title.setText(title);
    }
    
    public void addTitleComponet(JComponent jc){
        titlePane.add(jc, QueueLayout.END);
    }
}
