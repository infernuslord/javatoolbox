package phelps.imageio.plugins;

import javax.imageio.ImageReader;
import javax.imageio.spi.ImageReaderSpi;
import javax.imageio.metadata.IIOMetadata;
import javax.imageio.ImageReadParam;
import javax.imageio.stream.ImageInputStream;
import java.io.IOException;
import java.awt.image.BufferedImage;
import java.util.Iterator;



/**
	NOT IMPLEMENTED.
	Share scale with Fax.scale()

	@version $Revision$ $Date$
*/
public class JBIG2ImageReader extends ImageReader {

  public JBIG2ImageReader(ImageReaderSpi originatingProvider, Object extension) {
	super(originatingProvider);
  }

  public Iterator getImageTypes(int imageIndex) {
	check(imageIndex);
	return null;
  }

  public int getNumImages(boolean allowSearch) {
	check(0);
	return 1;
  }

  public int getHeight(int imageIndex) throws IOException {
	check(imageIndex);
	return -1;
  }

  public int getWidth(int imageIndex) throws IOException {
	check(imageIndex);
	return -1;
  }

  public IIOMetadata getStreamMetadata() {
	check(0);
	return null;
  }

  public IIOMetadata getImageMetadata(int imageIndex) {
	check(imageIndex);
	return null;
  }

  public BufferedImage read(int imageIndex, ImageReadParam param) throws IOException {
	check(imageIndex);
	return null;
  }


  private void check(int imageIndex) {
  }
}
