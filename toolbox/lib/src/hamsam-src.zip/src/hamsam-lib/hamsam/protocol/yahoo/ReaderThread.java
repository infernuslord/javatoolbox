/*
 * Please see COPYING for license details
 *
 * Copyright (C) 2003 Raghu K, All rights reserved.
 */

package hamsam.protocol.yahoo;

import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.IOException;
import hamsam.net.Connection;
import hamsam.util.log.LogManager;
import hamsam.exception.IllegalArgumentException;

/**
 * A thread to receive all incoming packets from Yahoo.
 *
 * @author Raghu
 */
public class ReaderThread extends Thread
{
	/**
	 * The connection used for reading.
	 */
	private Connection conn;

	/**
	 * The buffer to which to write.
	 */
	private Vector buffer;

	/**
	 * Flag to stop this thread.
	 */
	private boolean quit;

	/**
	 * The parent YahooProtocol thread that created this reader thread.
	 */
	private YahooProtocol protocol;

	/**
	 * Construct a new reader thread which reads from a specified connection and
	 * writes to a specified buffer.
	 *
	 * @param protocol the parent YahooProtocol thread that created this reader thread.
	 * @param conn the connection for reading.
	 * @param buffer the buffer to which to put the packets.
	 */
	public ReaderThread(YahooProtocol protocol, Connection conn, Vector buffer)
	{
		this.protocol = protocol;
		this.conn = conn;
		this.buffer = buffer;
		this.quit = false;
		setName("hamsam.protocol.yahoo.ReaderThread");
	}

	/**
	 * Change the connection object and start using a new one. This
	 * will close the old connection if it is not already closed.
	 *
	 * @param conn the new connection object.
	 */
	public void changeConnection(Connection conn)
	{
		synchronized(this.conn)
		{
			try
			{
				this.conn.close();
			}
			catch(IOException e)
			{
				/* we may get an exception because the connection is already closed */
			}

			this.conn = conn;
		}
	}

	/**
	 * The thread starts here.
	 */
	public void run()
	{
		Logger logger = LogManager.getLogger();
		while(!quit)
		{
			Packet pack = null;

			try
			{
				pack = new Packet(conn);
			}
			catch(IOException e)
			{
				protocol.shutdown(e);
				return;
			}
			catch(IllegalArgumentException e)
			{
				/* very much unlikely that you will get this */
				continue;
			}

			String msg = "Server: " + pack.toString();
			logger.logp(Level.INFO, this.getClass().getName(), "run", msg);

			synchronized(buffer)
			{
				if(pack != null)
				{
					buffer.add(pack);
					buffer.notify();
				}
			}
		}
	}

	/**
	 * Stop this thread safely.
	 */
	public void stopReading()
	{
		quit = true;

		try
		{
			conn.close();
		}
		catch(IOException e)
		{
		}

		protocol.interrupt();
	}
}
