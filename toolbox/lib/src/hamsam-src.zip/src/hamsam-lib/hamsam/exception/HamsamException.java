/*
 * Please see COPYING for license details
 *
 * Copyright (C) 2003 Raghu K, All rights reserved.
 */

package hamsam.exception;

/**
 * <code>HamsamException</code> is the superclass of all exceptions thrown by
 * the Hamsam API.
 */
public class HamsamException extends Exception
{
	/**
	 * Constructs a new Hamsam exception with <code>null<code> as its detailed
	 * message.
	 */
	public HamsamException()
	{
		super();
	}

	/**
	 * Constructs a new Hamsam exception with the specified detail message.
	 *
	 * @param message the detail message. The detail message is saved for later
	 *                retrieval by the Throwable.getMessage() method.
	 */
	public HamsamException(String message)
	{
		super(message);
	}
}
