// $Id: FollowingAxisExpr.java,v 1.1 2002/04/25 18:07:09 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

class FollowingAxisExpr extends AxisExpr 
{
    public NodeIterator eval(Node node, ExprContext context) 
    {
        return new FollowingNodeIterator(node);
    }
}
