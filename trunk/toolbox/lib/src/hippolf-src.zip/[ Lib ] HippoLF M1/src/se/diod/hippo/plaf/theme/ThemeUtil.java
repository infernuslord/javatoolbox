/*
 * 
 * Created on 2004-jul-02
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.theme;

/**
 * @author Robert
 * @created 2004-jul-02
 *
 */
public class ThemeUtil {


	private static final String[] availableThemes = { "Brown", "Gray", "Green", "Orange", "Red", "Yellow" };




	/**
	 * 
	 *
	 */
	public static String[] getAvailableThemes() {
		return availableThemes;
	}
}
