// $Id: EmptyVariableSet.java,v 1.1 2002/04/25 18:06:31 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

public class EmptyVariableSet implements VariableSet 
{
    public boolean contains(Name name) 
    {
        return false;
    }
}
