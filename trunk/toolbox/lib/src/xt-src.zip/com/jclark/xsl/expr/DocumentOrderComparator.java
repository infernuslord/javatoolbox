// $Id: DocumentOrderComparator.java,v 1.1 2002/04/25 18:06:19 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.util.Comparator;
import com.jclark.xsl.om.Node;

/**
 *
 */
class DocumentOrderComparator implements Comparator 
{
    public int compare(Object obj1, Object obj2) 
    {
        return ((Node)obj1).compareTo((Node)obj2);
    }
}
