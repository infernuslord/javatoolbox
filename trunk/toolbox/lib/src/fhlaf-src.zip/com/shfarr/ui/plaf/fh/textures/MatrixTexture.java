/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh.textures;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.TexturePaint;
import java.awt.image.BufferedImage;

import javax.swing.JComponent;

import com.shfarr.ui.GraphicsUtils;
import com.shfarr.ui.plaf.fh.theme.ThemeManager;


public class MatrixTexture extends Texture{
    protected String[][] matrix = null;
    protected BufferedImage matrixImage;
    
    public MatrixTexture(){
    }

    public MatrixTexture(String[][] customMatrix){
        setMatrix(customMatrix);
    }

    public void parse(String str){
        //setMatrix(getPalette().getTheme().loadMatrix(str));
    }
    
	public void apply(Shape s, Rectangle clip, Graphics2D g2D, JComponent c){
      Shape oldClip = g2D.getClip();
      g2D.setClip(clip != null ? c.getVisibleRect().createIntersection(clip) : c.getVisibleRect());
      
      if(g2D.getClipBounds().width > 0 && g2D.getClipBounds().height > 0){
          Rectangle anchor = s.getBounds();
          anchor.width = matrixImage.getWidth();
          anchor.height = matrixImage.getHeight();

          Paint op = g2D.getPaint();
          
          g2D.setPaint(new TexturePaint(matrixImage, anchor));
          
          g2D.fill(s);
          
          g2D.setPaint(op);
      }
      
      g2D.setClip(oldClip);
	}
    
    /**
     * Sets the rotation.
     * @param rotation The rotation to set
     */
    public void rotate(int rotation) {
        super.rotate(rotation);
    }
    
    
    /**
     * Gets the colorMatrix.
     * @return Returns a int[][]
     */
    public String[][] getMatrix(){
        return matrix;
    }

    /**
     * Sets the colorMatrix.
     * @param colorMatrix The colorMatrix to set
     */
    public void setMatrix(String[][] matrix){
        if(matrix == null) throw new NullPointerException("Matrix null");

        this.matrix = GraphicsUtils.rotateClockwise(matrix, 0);
        
        int[][] mi = new int[matrix.length][matrix[0].length];
        for(int i = 0; i < mi.length; i++){
            for(int k = 0; k < mi[i].length; k++) {
                mi[i][k] = matrix[i][k] != null ? matrix[i][k].equals("x") || getColor(matrix[i][k]) != null ? getColor(matrix[i][k]).getRGB() : 0x00000000 : 0x00000000;
            }
        }
        
        matrixImage = GraphicsUtils.createTextureImage(mi, getRotation());
    }

    protected Color getColor(String name){
        return ThemeManager.instance().getCurrentTheme().getColor(name);
    }

    public Texture deriveTexture(int rotation){
        MatrixTexture b = new MatrixTexture();
        
        b.setMatrix(GraphicsUtils.rotateClockwise(matrix, ThemeManager.instance().getCurrentTheme().metaPalette().get("Matrix Textures rotate").equals(Boolean.TRUE) ? rotation : 0));
        
        return b;
    }
}
