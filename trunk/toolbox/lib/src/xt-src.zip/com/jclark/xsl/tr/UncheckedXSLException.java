// $Id: UncheckedXSLException.java,v 1.1 2002/04/25 18:19:52 bill Exp $

package com.jclark.xsl.tr;

import com.jclark.xsl.om.XSLException;

class UncheckedXSLException extends RuntimeException
{
    private XSLException e;

    UncheckedXSLException(XSLException e)
    { this.e = e; }

    XSLException getXSLException()
    { return e; }
}
