package multivalent.node;

import java.util.Map;
import java.util.Arrays;

import multivalent.INode;
import multivalent.Context;



/**
	Leaf subclass for fixed-formatted ASCII with kerning.
	Kern can in range of -128 to +127 pixels.

	@version $Revision: 1.3 $ $Date: 2002/02/02 13:41:39 $
*/
public class FixedLeafAsciiKern extends FixedLeafAscii implements Fixed {
  //static final byte[] KERN0 = new byte[0];
  byte[] kern_;
  //int ksum_; -- always dealing with substrings, so not so useful... and probably not many instances

  /** <code>null</code> <var>kern</var> means none or 0 kern. */
  public FixedLeafAsciiKern(String name, Map<String,Object> attr, INode parent, byte[] kern) {
	super(name,attr, parent);
	setKern(kern);
  }

  /** Constant kerning. */
  public FixedLeafAsciiKern(String name, Map<String,Object> attr, INode parent, double kern) {
	super(name,attr, parent);
	//if (!(-127.0 <= kern&&kern <=127.0)) System.out.println(getName()+": kern out of bounds "+kern);

	byte[] k;
	if (kern==0) k=null; else { k = new byte[name.length()]; Arrays.fill(k, (byte)kern); }
	setKern(k);
  }


  public byte[] getKern() { return kern_; }
  public double getKernAt(int index) {
	assert index>=0 && index<size(): index+" not in 0.."+size();
	return (kern_!=null? kern_[index]: 0);
  }

  public void setKern(byte[] kern) {
	//kern_ = (kern!=null? kern: KERN0);
	kern_ = kern;
	setValid(false);
  }
  public void setKernAt(int index, double kern) {
	assert index>=0 && index<size(): index+" not in 0.."+size();
	//if (!(-127 <= kern&&kern <=127)) System.out.println(getName()+": kern out of bounds "+kern);

	byte b = (byte)kern;
	if (kern_==null) kern_ = new byte[size()];
	if (kern_[index]!=b) {
		kern_[index] = b;
		setValid(false);
	}
  }


  //public void appendText(String text, byte[] kern) {}
  public void appendText(String text) { appendText(text, (byte)0); }
  public void appendText(String text, double kern) {
	assert text!=null && text.length()>0;
	//assert constant kern
	if (kern_==null && kern==0.0) {
		// keep kern_==null
	} else {
		int len=getName().length(), nlen = text.length() + len;
		if (kern_==null) kern_ = new byte[nlen];
		else { byte[] k=kern_; kern_=new byte[nlen]; System.arraycopy(k,0, kern_,0, k.length); }
		Arrays.fill(kern_, len,nlen, (byte)kern);
	}
	super.appendText(text);
//if (kern_!=null) for (int i=0,imax=size(); i<imax; i++) System.out.print(kern_[i]+" ");  System.out.println("  |"+getName()+"|");
  }


  /** Measurements adjusted by kerns. */
  public boolean formatNodeContent(Context cx, int start, int end) {
	boolean ret = super.formatNodeContent(cx, start, end);

	// adjust by kern
	if (kern_!=null && kern_.length==size()) {
		int w = 0; for (int i=start, imax=Math.min(end,size()-1); i<=imax; i++) w += kern_[i];
		bbox.width += w;
	}
//System.out.println("format "+getName()+" "+getIbbox().width+" => "+bbox.width);

	if (start==0) bbox.setLocation(ibbox_.x, ibbox_.y);
	return ret;
  }

  /** Chunk by kerns as well as spans. */
  public boolean paintNodeContent(Context cx, int start, int end) {
	int laststart = start;
	if (kern_!=null && kern_.length==size()) for (int i=start; i<=Math.min(end, size()-1); i++) {
		if (kern_[i]!=0) {  // chunks between non-zero kerns
			super.paintNodeContent(cx, laststart, i);
			cx.x += kern_[i];
//System.out.print(getName().substring(laststart,i+1)+"  "+kern_[i]);
//System.out.print("  k"+kern_[i]+"/"+getName().substring(laststart,i+1));
			laststart = i+1;
		}
	} //else System.out.println("kern len off: "+kern_.length+" != "+size());
//if (start==end) System.out.println("skipped "+start);//name_.charAt(start));
//System.out.println("+"+getName().substring(laststart,Math.min(end,size())));
	return super.paintNodeContent(cx, laststart, end);
  }

  /** Widths adjusted by kerns. */
  public void subelementCalc(Context cx) {
	super.subelementCalc(cx);
	if (kern_!=null && kern_.length==size()) {
		for (int i=0,imax=kern_.length; i<imax; i++) Widths_[i] += kern_[i];
	}
  }

/*  public void dump(int level, boolean recurse) {
	System.out.println(getName()+", ibbox="+Formats.pretty(ibbox_)+", bbox="+Formats.pretty(bbox));
  }*/

/*
  public boolean eventNode(java.awt.AWTEvent e, java.awt.Point rel) {
	System.out.println("LeafKern "+getName()+" vs existing "+getBrowser().getCurNode());
	return super.eventNode(e,rel);
  }*/
}
