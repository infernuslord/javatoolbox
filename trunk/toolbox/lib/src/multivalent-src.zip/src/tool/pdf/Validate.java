package tool.pdf;

import java.io.IOException;
import java.io.File;
import java.io.PrintStream;
import java.awt.Rectangle;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

import multivalent.ParseException;
import multivalent.std.adaptor.pdf.*;
import static multivalent.std.adaptor.pdf.COS.*;

import phelps.io.FileList;
import phelps.awt.geom.Rectangles2D;



/**
	Validate PDF integrity.
	Can also be run programmically by PDF generators to validate PDFs they just created.

	@version $Revision: 1.8 $ $Date: 2004/03/13 03:52:51 $
*/
public class Validate {
  static final boolean DEBUG = true && multivalent.Multivalent.DEVEL;

  public static final String VERSION = "1.2 of $Date: 2004/03/13 03:52:51 $";	// 1.1 = PDFReader, 1.2 = link checking
  public static final String USAGE = "java tool.pdf.Validate [options] <PDF-file...>\n"
	+ "\t[-fast | -full | -obj]\n" // | -dev [-error | -warning]
	+ "\t[-password <password>]";

  public static final int LEVEL_FAST = 0, LEVEL_FULL=1, LEVEL_OBJECTS=2,
	  LEVEL_DEVEL=10, LEVEL_DEVEL_WARNING=11, LEVEL_DEVEL_CONTENT=12;

  // required attributes
  //static final String[] ATTRS_ = {  };
  private static final String[] ATTRS_PAGES = { "Type", "Count", "Kids" };
  private static final String[] ATTRS_PAGE = { "Type", "Parent", "Resources", "MediaBox" };
  private static final String[] ATTRS_IMAGE = { "Width", "Height" };

  /** Amount by which */
  static final int OVERLAP_FUZZ = 3;

  private List<String> errs_ = new ArrayList<String>(10);
  private String password_;
  private boolean frepairok_;
  private int level_;
  /** Name of current file to show at first error, or null already shown. */
  private String name1_;
  private boolean fverbose_, fquiet_, fmonitor_;
  private PrintStream out_;


  public Validate() {
	defaults();
  }

  public void defaults() {
	password_ = null;
	frepairok_ = true;
	level_ = LEVEL_DEVEL;

	fverbose_ = fquiet_ = fmonitor_ = false;
	out_ = phelps.io.PrintStreams.DEVNULL;
  }

  public void setLevel(int level) {
	assert LEVEL_FAST<=level && level<=LEVEL_DEVEL_CONTENT;
	level_ = level;
  }

  public void setRepair(boolean b) { frepairok_ = b; }



  /** Returns true iff PDF valid. */
  public boolean validate(File file) throws IOException {
	if (fverbose_) System.out.println(file);
	assert file!=null && file.exists();

	errs_.clear();
	PDFReader pdfr = null;

	// LEVEL_FAST: just open PDF (check for "%PDF-m.n", trailer, xref), catalog
	try { 
		name1_ = file.getPath();
		pdfr = new PDFReader(file);
	} catch (ParseException pe) {
		err(-1, pe.toString()); return false;
	} catch (IOException ioe) { 
		System.err.println("Can't open "+file); throw ioe;
	}

	return validate(pdfr);
  }

  public boolean validate(PDFReader pdfr) throws IOException {
	pdfr.setExact(true);	// validing as is, not out cleaned up version
	pdfr.setPassword(password_);
	if (!pdfr.isAuthorized()) { err(-1, "invalid password "+pdfr.getFile()); return false; }
	if (!frepairok_ && pdfr.isRepaired()) return false;
	// has "Pages", ...

	//if (pdfr.getObjGen(0) != GEN_MAX) err(0, "generation must be "+GEN_MAX); => points to deleted chain

	if (level_ >= LEVEL_FULL && errs_.isEmpty()) validateFull(pdfr);
	if (!frepairok_ && pdfr.isRepaired()) return false;

	// pagewise
	int pagecnt=pdfr.getPageCnt();
	if (level_ >= LEVEL_OBJECTS && errs_.isEmpty()) for (int i=1; i<=pagecnt; i++) {	// iterate over pages so can report bad links by page
		if (fmonitor_) out_.print(" "+i);
		Dict page = pdfr.getPage(i);
		if (level_ >= LEVEL_OBJECTS && errs_.isEmpty()) {
			validateAnnots(page, i, pdfr);
			//validateImages(pdfr);
		}
		//if (level_ >= LEVEL_DEVEL) validateContent(pdfr);
	}
	if (fmonitor_ && pagecnt>0) out_.println();
	
	if (level_ >= LEVEL_DEVEL && errs_.isEmpty()) validateDev(pdfr);


	pdfr.close();


	if (errs_.isEmpty() && pdfr.isRepaired()) err(-1, "invalid but repairable (with tool.pdf.Repair)");
	return errs_.isEmpty();
  }


  /**
	<ul>
	<li>Read each object.
	</ul>
  */
  public boolean validateFull(PDFReader pdfr) throws IOException {
	boolean ok = true;
	Object o = null;
	pdfr.fault();

	//Dict cat = pdfr.getCatalog();
	int objcnt = pdfr.getObjCnt();
	for (int i=0+1; i<objcnt; i++) {
		try {
			o = pdfr.getObject(i);
			if (CLASS_DICTIONARY==o.getClass() && ((Dict)o).get(STREAM_DATA) != null) {
				byte[] data = pdfr.getStreamData(new IRef(i,pdfr.getObjGen(i)), false, false);
			}

			//} catch (ParseException pe) {
			//	System.err.println("ParseException on object #"+i+": "+pe);
		} catch (/*IO*/Exception ioe) {	// IOException, ClassCastException
			//ioe.printStackTrace();
			err(i, ioe.toString());
			System.out.println("#"+i+": "+o);
			ok = false;
			break;
		}
	}

	return ok;
  }


  /**
	<ul>
	<li>Link
	</ul>
  */
  public boolean validateAnnots(Dict page, int pg,  PDFReader pdfr) throws IOException {
	int errsin = errs_.size();
	int objcnt = pdfr.getObjCnt(), pagecnt = pdfr.getPageCnt();

	//boolean[] seen = new bolean[objcnt];	// shouldn't have same link on different pages, but possible
	Object o = page.get("Annots"); if (o==null) return true;
	Object[] annots = (Object[])pdfr.getObject(o); if (OBJECT_NULL==annots) return true;
	int aaid = CLASS_IREF==o.getClass()? ((IRef)o).id: -1;

	List<Rectangle> bboxes = new ArrayList<Rectangle>(10);	// collect bboxes in page
	for (int i=annots.length-1; i>=0; i--) {	// apparently examined backwards
		//IRef iref = annots[j]; //if (seen[iref.id]) continue; else 
		o = annots[i];
		int aid = CLASS_IREF==o.getClass()? ((IRef)o).id: aaid;
		o = pdfr.getObject(o); if (CLASS_DICTIONARY!=o.getClass()) continue;
		Dict annot = (Dict)o;
		Object type = pdfr.getObject(annot.get("Type")), subtype = pdfr.getObject(annot.get("Subtype"));
		if (type!=null && !"Annot".equals(type)) { err(aid, "no /Type /Annot"); continue; }

		if ("Link".equals(subtype)) {
			// a. check for validity
			Object dest = annot.get("Dest");
			Object a = annot.get("A");
			if (dest==null && a==null) err(aid, "link annotation but no destination (no /Dest or /A)");
			else if (dest!=null && a!=null) err(aid, "link annotation has both /Dest and /A");
			else if (dest!=null) checkDest(dest,  pg, aid, pdfr);

			// b. check for overlap
			Rectangle bbox = COS.array2Rectangle((Object[])pdfr.getObject(annot.get("Rect")), null);
			int area = bbox.width * bbox.height;
			for (int j=0,jmax=bboxes.size(); j<jmax; j++) {
				Rectangle x = bboxes.get(j);
				Rectangle overlap = bbox.intersection(x);
				//if (area < 5) err(-1, "very small hit");
				if (overlap.width <= 0 || overlap.height <=0) {
					// no overlap
				} else if (overlap.width * overlap.height == area) {
					err(-1, "page "+pg+": link rectangle "+Rectangles2D.pretty(x)+" blocks "+Rectangles2D.pretty(bbox)/*+" overlap = "+overlap+" vs area = "+area*/);
					break;
				// else if (inlaid in background) {}
				} else if (overlap.width>OVERLAP_FUZZ && overlap.height>OVERLAP_FUZZ) {	// small overlap OK
					err(-1, "page "+pg+": link rectangle "+Rectangles2D.pretty(x)+" partially overlaps "+Rectangles2D.pretty(bbox));
					break;
				}
			}
			bboxes.add(bbox);
		}

		// all annos
		o = annot.get("A");
		if (o!=null && !"Movie".equals(subtype)) validateAction(o, pg, aid, pdfr);
		o = pdfr.getObject(annot.get("AA"));
		if (o!=null && CLASS_DICTIONARY==o.getClass()) for (Iterator j = ((Dict)o).values().iterator(); j.hasNext(); ) validateAction(j.next(), pg, aid, pdfr);
	}

	return errsin == errs_.size();
  }

  private void checkDest(Object dest,  int pg, int aid, PDFReader pdfr) throws IOException {
	if (dest==null) return;

	String msg=null; Object ref=dest;
	dest = pdfr.getObject(dest);

	Class cl = dest.getClass();
	if (CLASS_ARRAY==cl) {
		Object[] oa = (Object[])dest;
		Object o = pdfr.getObject(oa[0]);
		if (CLASS_DICTIONARY==o.getClass()) {
			Dict pagedict = (Dict)o;
			if (!"Page".equals(pdfr.getObject(pagedict.get("Type")))) msg = "doesn't point to page";
		} else msg = "points to bad page: "+o;

	} else if (CLASS_NAME==cl || CLASS_STRING==cl) {	// named destination, either /old-style or (new-style)
		Object o;
		if (CLASS_NAME==cl) {
			o = pdfr.getObject(pdfr.getCatalog().get("Dests"));
		} else { assert CLASS_STRING==cl;
			o = pdfr.getObject(pdfr.getCatalog().get("Names"));
			if (o==null || OBJECT_NULL==o || CLASS_DICTIONARY!=o.getClass()) msg = "named destination but no /Names dictionary";
			else o = pdfr.getObject(((Dict)o).get("Dests"));
		}

//System.out.println("subdest1 = "+o);
		if (msg!=null) {}
		else if (o==null || OBJECT_NULL==o) msg = "named destination but no /Dests dictionary";
		else if (CLASS_DICTIONARY==o.getClass()) {
			Dict dests = (Dict)o;
			o = CLASS_NAME==cl? pdfr.getObject(dests.get(dest)): pdfr.findNameTree(dests, (StringBuffer)dest);
			if (o==null) msg = "named destination '"+dest+"' does not exist";
			else if (OBJECT_NULL==dest) msg = "points to null";
			else {
				Object subdest = pdfr.getObject(o);
//System.out.println("subdest2 = "+subdest);
				if (CLASS_DICTIONARY==subdest.getClass()) subdest = ((Dict)subdest).get("D");
				checkDest(subdest,  pg, aid, pdfr);
			}
		}
		
	} else if (OBJECT_NULL==dest) msg = "points to null";
	else msg = "has invalid type (should be array, name, or string)";


	if (msg!=null) {
		int id = CLASS_IREF==ref.getClass()? ((IRef)ref).id: -1;
		err(id, "on page "+pg+" in object "+aid+": "+msg);
	}
  }

  /**
	Validates PDF action.
	Chains via <code./Next</code>.
  */
  private void validateAction(Object ref,  int pg, int aid, PDFReader pdfr) throws IOException {
	if (ref==null) return;
	else if (CLASS_IREF==ref.getClass()) { aid = ((IRef)ref).id; ref = pdfr.getObject(ref); }
	if (CLASS_ARRAY==ref.getClass()) for (Object nref: (Object[])ref) validateAction(nref,  pg, aid, pdfr);
	if (CLASS_DICTIONARY != ref.getClass()) return;
	Dict action = (Dict)ref;

	Object subtype = null;
	Object o;
	String S = (String)pdfr.getObject(action.get("S"));

	if ("GoTo".equals(S)) {
		checkDest(action.get("D"), pg, aid, pdfr);

	} else if ("GoToR".equals(S)) {
		Object F = pdfr.getObject(action.get("F"));
//System.out.println("GoToR "+F);
		Object D = pdfr.getObject(action.get("D"));	// if array, oa[0] is integer page number
		if (F==null || OBJECT_NULL==F) err(aid, "no destination file (/F)");
		else if (CLASS_STRING==F.getClass()) {}
		else if (CLASS_STRING!=F.getClass()) err(aid, "/F not string or dictionary");
		else {
			Dict fspec = (Dict)F;
			o = pdfr.getObject(fspec.get("F"));
			File f = new File(pdfr.getFile(), o.toString());	// not URI/http
			if (!f.exists()) err(aid, "destination file not found: "+o);
			else if (D==null || OBJECT_NULL==D) err(aid, "no destination within file "+F);
			else {
				PDFReader pdfr2 = null;
				try {
					pdfr2 = new PDFReader(f);
					if (CLASS_ARRAY==D.getClass()) {
						o = pdfr.getObject(((Object[])D)[0]);
						if (o instanceof Number) {
							int p = ((Number)o).intValue();
							if (p < 1 || p > pdfr2.getPageCnt()) err(aid, "points to page "+p+" in "+F+", but only "+pdfr2.getPageCnt()+" pages");
						}
					} else checkDest(D,  pg, aid, pdfr2);
				} catch (Exception e) {
				} finally {
					if (pdfr2!=null) pdfr2.close();
				}
			}
		}

	} else if ("Launch".equals(S)) {
		// check for unsafe paths
		Object F = pdfr.getObject(action.get("F"));
//System.out.println(action+" => "+F);

	} else if ("URI".equals(S)) {
		// check for unsafe paths
//System.out.println(action);

	} else {
//System.out.println(pdfr.getFile().getName()+": validateAction: "+S+" "+action);
	}


	validateAction(action.get("Next"), pg, aid, pdfr);
  }



  public void validateDev(PDFReader pdfr) throws IOException {
	Object o;
	int objcnt = pdfr.getObjCnt();
	int pagecnt = pdfr.getPageCnt(); if (pagecnt==0) warn(-1, "No pages");

	//xref gen[0]==0xffff

	Dict trailer = pdfr.getTrailer();
	// accurate /Size in trailer
	if (trailer.get("Root")==null) err(-1, "No /Root in trailer");
	if ((o=trailer.get("Size"))==null) err(-1, "No /Size in trailer");
	else if (CLASS_INTEGER!=o.getClass()) err(-1, "/Size in trailer not direct integer");
	else { int size = ((Number)o).intValue(); if (size != objcnt) err(-1, "Wrong /Size in trailer: "+size+" should be "+objcnt); }

	Dict cat = pdfr.getCatalog();
	if (cat.get("Pages")==null) warn(-1, "No /Pages in catalog");

	Dict info = pdfr.getInfo(); 
	if (info==null) warn(-1, "No /Info with metadata in trailer");


	// refcnt to find unused objects
	// ...

	for (int i=0; i<pagecnt; i++) {
		IRef pageref = pdfr.getPageRef(i+1);
		Dict page = pdfr.getPage(i+1);	// fills in inherited
		requiredAttrs(pageref.id, page, ATTRS_PAGE);

	}

	for (int i=0; i<objcnt; i++) {	// loop over objects or walk trees?
		o = pdfr.getObject(i);
		if (CLASS_DICTIONARY!=o.getClass()) continue;
		Dict dict = (Dict)o;

		String type = (String)dict.get("Type"), subtype = (String)dict.get("Subtype");
		if ("Pages".equals(type)) {
			requiredAttrs(i, dict, ATTRS_PAGES);

		} else if ("Page".equals(type)) {
			//requiredAttrs(i, dict, ATTRS_PAGE); => after inherited
			if (dict.get("Contents")==null) warn(i, "/Page without /Contents");
			
		} else if (("XObject".equals(type) || null==type) && "Image".equals(subtype)) {
			requiredAttrs(i, dict, ATTRS_IMAGE);


		} else if (("XObject".equals(type) || null==type) && "Image".equals(subtype)) {
		}
	}
  }

  private void requiredAttrs(int objnum, Dict dict, String[] attrs) {
	boolean fok = true;
	for (int i=0,imax=attrs.length; i<imax; i++) {
		String attr = attrs[i];
		if (dict.get(attr) == null) err(objnum, "missing attr '"+attr+"'");
	}
  }


  private void err(int objnum, String msg) {
	//if (out_==null) return;
	if (name1_!=null) { out_.println("File: "+name1_); name1_=null; }
	String txt = "ERROR";
	if (objnum >= 0) txt += ".  object #"+objnum;
	txt += ": "+msg;
	errs_.add(txt);
	out_.println(txt);
  }

  private void warn(int objnum, String msg) {
	if (level_ < LEVEL_DEVEL_WARNING/* || out_==null*/) return;
	if (name1_!=null) { out_.println("File: "+name1_); name1_=null; }
	out_.print("WARNING.  ");
	if (objnum >= 0) out_.print(" object #"+objnum);
	out_.println(": "+msg);
  }



  private int commandLine(String[] argv) {
	level_ = LEVEL_FULL;	// interactive default is different from programmatic
	out_ = System.out;

	int argi = 0, argc = argv.length;
	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.equals("-fast") || arg.equals("-quick")) level_ = LEVEL_FAST;
		else if (arg.equals("-full")) level_ = LEVEL_FULL;
		else if (arg.startsWith("-dev"/*"eloper"*/)) level_ = LEVEL_DEVEL;
		else if (arg.startsWith("-obj"/*"ects"*/) || arg.startsWith("-link"/*"s"*/)) level_ = LEVEL_OBJECTS;

		else if (arg.startsWith("-rep"/*airok*/)) setRepair(true);
		else if (arg.startsWith("-pass"/*"word"*/)) password_ = argv[++argi];

		else if (arg.startsWith("-verb")) fverbose_ = true;
		else if (arg.startsWith("-mon"/*itor*/)) { fmonitor_ = fverbose_ = true; fquiet_ = false; }
		//else if (arg.startsWith("-q"/*uiet*/)) fquiet = true;
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.startsWith("-h"/*"elp"*/)) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}
	if (LEVEL_DEVEL==level_ && fverbose_) level_ = LEVEL_DEVEL_WARNING;

	if (argi == argc) { System.err.println(USAGE); System.exit(0); }

	return argi;
  }

  public static void main(String[] argv) {
	Validate v = new Validate();
	int argi = v.commandLine(argv);

	for (Iterator<File> i = new FileList(argv, argi, FILTER).iterator(); i.hasNext(); ) {
		File file = i.next();
		try {
			//if (fquiet_) System.out.println(file);
			v.validate(file);
		} catch (Exception e) {
			System.err.println(file+": "+e);
			if (DEBUG) e.printStackTrace();
		}
	}
	System.exit(0);
  }
}
