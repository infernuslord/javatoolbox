// $Id: NumberFunction.java,v 1.1 2002/04/25 18:10:11 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

class NumberFunction extends FunctionOpt1 {
    ConvertibleExpr makeCallExpr(ConvertibleExpr e) throws ParseException {
        return e.makeNumberExpr();
    }
}
