/*
  Copyright (C) 2003-2004 Robert F. Beeger (robert at beeger dot net)
  Licensed under the Academic Free License version 2.0
  OSI Certified Open Source Software

  Visit http://squareness.sourceforge.net/ for new releases of Squareness Look And Feel and other
  skins from the Squareness series.
*/
package net.beeger.squareness.delegate;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import javax.swing.JComponent;
import javax.swing.JSlider;
import javax.swing.UIManager;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicSliderUI;

import net.beeger.squareness.SquarenessConstants;

/**
 * The Squareness Slider UI delegate.
 */
public class SquarenessSliderUI extends BasicSliderUI
{
  /**
   * Create an UI delegate for the given component.
   *
   * @param component The component for which to create the UI delegate.
   * @return The created UI delegate.
   */
  public static ComponentUI createUI (JComponent component)
  {
    return new SquarenessSliderUI((JSlider) component);
  }

  /**
   * Create the UI delegate.
   *
   * @param slider The slider for which this delegate will be used.
   */
  public SquarenessSliderUI (JSlider slider)
  {
    super(slider);
  }

  /**
   * Paint the track of the slider.
   *
   * @param graphics The graphics object to use for painting the track.
   */
  public void paintTrack (Graphics graphics)
  {
    Color oldColor = graphics.getColor();
    int x, y, width, height;

    if (slider.getOrientation() == JSlider.HORIZONTAL)
    {
      x = trackRect.x;
      y = trackRect.y + (trackRect.height >> 1) - 2;
      width = trackRect.width;
      height = 5;
    }
    else
    {
      x = trackRect.x + (trackRect.width >> 1) - 2;
      y = trackRect.y;
      width = 5;
      height = trackRect.height;
    }

    graphics.setColor(UIManager.getColor(SquarenessConstants.PROGRESS_BAR_BACKGROUND_COLOR_KEY));
    graphics.fillRect(x, y, width, height);

    graphics.setColor(UIManager.getColor(SquarenessConstants.CONTROL_BORDER_COLOR_KEY));
    graphics.drawRect(x, y, width - 1, height - 1);

    if (slider.getClientProperty("JSlider.isFilled") != null
        && ((Boolean) slider.getClientProperty("JSlider.isFilled")).booleanValue())
    {
      graphics.setColor(UIManager.getColor(SquarenessConstants.SELECTED_CONTROL_COLOR_KEY));

      if (slider.getOrientation() == JSlider.HORIZONTAL)
      {
        if (drawInverted())
        {
          graphics.fillRect(thumbRect.x, y + 1, width - 2 - (thumbRect.x - x), height - 2);
        }
        else
        {
          graphics.fillRect(x + 1, y + 1, thumbRect.x - x, height - 2);
        }
      }
      else
      {
        if (drawInverted())
        {
          graphics.fillRect(x + 1, thumbRect.y, width - 2 - (thumbRect.y - y), height - 2);
        }
        else
        {
          graphics.fillRect(x + 1, y + 1, width - 2, thumbRect.y - y);
        }
      }
    }

    graphics.setColor(oldColor);
  }

  /**
   * Paint the thumb of the slider.
   *
   * @param graphics The graphics object to use for the painting.
   */
  public void paintThumb (Graphics graphics)
  {
    Color oldColor = graphics.getColor();

    graphics.setColor(UIManager.getColor(SquarenessConstants.NORMAL_CONTROL_COLOR_KEY));
    graphics.fillRect(thumbRect.x, thumbRect.y, thumbRect.width, thumbRect.height);
    if (slider.isEnabled())
    {
      graphics.setColor(UIManager.getColor(SquarenessConstants.CONTROL_BORDER_COLOR_KEY));
    }
    else
    {
      graphics.setColor(UIManager.getColor(SquarenessConstants.DISABLED_CONTROL_BORDER_COLOR_KEY));
    }
    graphics.drawRect(thumbRect.x, thumbRect.y, thumbRect.width - 1, thumbRect.height - 1);

    if (slider.getPaintTicks())
    {
      int yBot = thumbRect.y + thumbRect.height - 1;
      int xRight = thumbRect.x + thumbRect.width - 1;
      if (slider.getOrientation() == JSlider.HORIZONTAL)
      {
        graphics.drawLine(thumbRect.x + 2, yBot - 5, thumbRect.x + 5, yBot - 2);
        graphics.drawLine(thumbRect.x + 3, yBot - 5, thumbRect.x + 5, yBot - 3);
        graphics.drawLine(thumbRect.x + 3, yBot - 6, thumbRect.x + 5, yBot - 4);

        graphics.drawLine(xRight - 2, yBot - 5, thumbRect.x + 5, yBot - 2);
        graphics.drawLine(xRight - 3, yBot - 5, thumbRect.x + 5, yBot - 3);
        graphics.drawLine(xRight - 3, yBot - 6, thumbRect.x + 5, yBot - 4);
      }
      else
      {
        graphics.drawLine(xRight - 5, thumbRect.y + 2, xRight - 2, thumbRect.y + 5);
        graphics.drawLine(xRight - 5, thumbRect.y + 3, xRight - 3, thumbRect.y + 5);
        graphics.drawLine(xRight - 6, thumbRect.y + 3, xRight - 4, thumbRect.y + 5);

        graphics.drawLine(xRight - 5, yBot - 2, xRight - 2, thumbRect.y + 5);
        graphics.drawLine(xRight - 5, yBot - 3, xRight - 3, thumbRect.y + 5);
        graphics.drawLine(xRight - 6, yBot - 3, xRight - 4, thumbRect.y + 5);
      }
    }

    graphics.setColor(oldColor);
  }

  /**
   * Paint a minor tick for a horizontal slider.
   *
   * @param graphics The graphics object to use for painting.
   * @param tickBounds The bounds of the tick.
   * @param x The x position at which to paint the tick.
   */
  protected void paintMinorTickForHorizSlider (Graphics graphics, Rectangle tickBounds, int x)
  {
    graphics.drawLine(x, 1, x, (tickBounds.height >> 1) - 1);
  }

  /**
   * Paint a major tick for a horizontal slider.
   *
   * @param graphics The graphics object to use for painting.
   * @param tickBounds The bounds of the tick.
   * @param x The x position at which to paint the tick.
   */
  protected void paintMajorTickForHorizSlider (Graphics graphics, Rectangle tickBounds, int x)
  {
    graphics.drawLine(x, 1, x, tickBounds.height - 2);
  }

  /**
   * Paint a minor tick for a vertical slider.
   *
   * @param graphics The graphics object to use for painting.
   * @param tickBounds The bounds of the tick.
   * @param y The y position at which to paint the tick.
   */
  protected void paintMinorTickForVertSlider (Graphics graphics, Rectangle tickBounds, int y)
  {
    graphics.drawLine(1, y, (tickBounds.width >> 1) - 1, y);
  }

  /**
   * Paint a major tick for a vertical slider.
   *
   * @param graphics The graphics object to use for painting.
   * @param tickBounds The bounds of the tick.
   * @param y The y position at which to paint the tick.
   */
  protected void paintMajorTickForVertSlider (Graphics graphics, Rectangle tickBounds, int y)
  {
    graphics.drawLine(1, y, tickBounds.width - 2, y);
  }

}

/*
  $Log: SquarenessSliderUI.java,v $
  Revision 1.5  2004/03/08 15:12:26  rbeeger
  Added and enhanced comments.
  Simplified code.

  Revision 1.4  2004/03/03 19:56:42  rbeeger
  Fixed filled track painting.

  Revision 1.3  2004/02/14 19:12:34  rbeeger
  Updated copyright statement
  Added cvs log directive at the end of each file
  Optimized imports
  Reformated code

 */
