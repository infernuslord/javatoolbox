package org.outerj.pollo.xmleditor;

public interface NodeClickedListener
{
    public void nodeClicked(NodeClickedEvent e);
}
