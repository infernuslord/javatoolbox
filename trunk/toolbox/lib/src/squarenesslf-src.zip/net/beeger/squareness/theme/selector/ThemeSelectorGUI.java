package net.beeger.squareness.theme.selector;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JFrame;

/**
 * The GUI of the theme selector.
 */
public class ThemeSelectorGUI extends JFrame
{
  public ThemeSelectorGUI ()
  {
    _themeList = new JList();
    JScrollPane listScroller =  new JScrollPane(_themeList);
    _select = new JButton("Select");

    getContentPane().setLayout(new BorderLayout(5,5));
    getContentPane().add(listScroller, BorderLayout.CENTER);
    getContentPane().add(_select, BorderLayout.SOUTH);
  }

  public JList getThemeList ()
  {
    return _themeList;
  }

  public void setThemeList (JList themeList)
  {
    _themeList = themeList;
  }

  public JButton getSelect ()
  {
    return _select;
  }

  public void setSelect (JButton select)
  {
    _select = select;
  }

  private JList _themeList;
  private JButton _select;
}
