// Copyright 2002, 2003 Elliotte Rusty Harold
// 
// This library is free software; you can redistribute 
// it and/or modify it under the terms of version 2.1 of 
// the GNU Lesser General Public License as published by  
// the Free Software Foundation.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General 
// Public License along with this library; if not, write to the 
// Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
// Boston, MA  02111-1307  USA
// 
// You can contact Elliotte Rusty Harold by sending e-mail to
// elharo@metalab.unc.edu. Please include the word "XOM" in the
// subject line. The XOM home page is temporarily located at
// http://www.cafeconleche.org/XOM/  but will eventually move
// to http://www.xom.nu/

package nu.xom.tests;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.OutputStream;

import junit.framework.TestCase;

import nu.xom.Builder;
import nu.xom.Document;
import nu.xom.ParseException;
import nu.xom.Serializer;
import nu.xom.canonical.CanonicalXMLSerializer;

/**
 * @author Elliotte Rusty Harold
 *
 */
public class CanonicalizerTest extends TestCase {

    /**
     * Constructor for CanonicalizerTest.
     */
    public CanonicalizerTest(String name) {
        super(name);
    }

    private Builder builder;
    
    protected void setUp() {        
        builder = new Builder();       
    }

    public void testWithComments() throws ParseException, IOException {
      
        File tests = new File("data/canonical/input/");
        String[] inputs = tests.list(new XMLFilter());
        for (int i = 0; i < inputs.length; i++) {
            File input = new File(tests, inputs[i]); 
            // System.err.println(input);  
            Document doc = builder.build(input);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            Serializer serializer = new CanonicalXMLSerializer(out);
            serializer.write(doc);
            serializer.flush();
            
            byte[] actual = out.toByteArray();
            
            // for debugging
            File debug = new File("data/canonical/debug/" + input.getName() + ".dbg");
            OutputStream fout = new FileOutputStream(debug);
            fout.write(actual);
            fout.flush();
            fout.close();      
            
            File expected = new File("data/canonical/output/" + input.getName() + ".out");
            assertEquals(input.getName(), actual.length, expected.length());
            byte[] expectedBytes = new byte[actual.length];
            DataInputStream in =  new DataInputStream(new FileInputStream(expected));
            in.readFully(expectedBytes);
            for (int j = 0; j < expectedBytes.length; j++) {
                assertEquals(actual[i], expectedBytes[i]);   
            }
            
        }
      
        
    }
    
    public void testWithoutComments() throws ParseException, IOException {
      
        File tests = new File("data/canonical/input/");
        String[] inputs = tests.list(new XMLFilter());
        for (int i = 0; i < inputs.length; i++) {
            File input = new File(tests, inputs[i]); 
            // System.err.println(input);  
            Document doc = builder.build(input);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            Serializer serializer = new CanonicalXMLSerializer(out, false);
            serializer.write(doc);
            serializer.flush();
            
            byte[] actual = out.toByteArray();
            
            // for debugging
          /*  File debug = new File("data/canonical/debug/" + input.getName() + ".dbg");
            OutputStream fout = new FileOutputStream(debug);
            fout.write(actual);
            fout.close(); */
            
            File expected = new File("data/canonical/wocommentsoutput/" + input.getName() + ".out");
            // assertEquals(actual.length, expected.length());
            byte[] expectedBytes = new byte[actual.length];
            DataInputStream in =  new DataInputStream(new FileInputStream(expected));
            in.readFully(expectedBytes);
            for (int j = 0; j < expectedBytes.length; j++) {
                assertEquals(actual[i], expectedBytes[i]);   
            }
            
        }
      
        
    }    
    
    private static class XMLFilter implements FilenameFilter {
        
        
        public boolean accept(File directory, String name) {
            
            if (name.endsWith(".xml")) return true;
            return false;
            
        }
        
    }

}
