/*
 * Please see COPYING for license details
 *
 * Copyright (C) 2003 Raghu K, All rights reserved.
 */

package hamsam.protocol.msn;

import java.awt.Color;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.Enumeration;
import java.util.Hashtable;

/**
 * A message is used for sending and receiving IMs and server
 * notifications.
 */
class MsnMessage extends AbstractCommand
{
	/**
	 * MIME headers of the message are stored here.
	 */
	private Hashtable headers;

	/**
	 * Body part of this message.
	 */
	private StringBuffer body;

	/**
	 * Constructor for incoming messages.
	 *
	 * @param passport passport of the sender.
	 * @param alias alias of the sender.
	 * @param data body of this message.
	 */
	MsnMessage(String passport, String alias, char[] data)
	{
		super("MSG");
		addParam(passport);
		addParam(alias);
		addParam(String.valueOf(data.length));

		headers = new Hashtable();
		body = new StringBuffer();

		BufferedReader rd = new BufferedReader(new StringReader(new String(data)));

		try
		{
			// extract the MIME headers
			String line = rd.readLine();
			while(line != null && !line.equals(""))
			{
				int index = line.indexOf(':');
				if(index != -1)
					headers.put(line.substring(0, index).trim(), line.substring(index + 1).trim());
				line = rd.readLine();
			}

			// the rest is the body part
			int count;
			do
			{
				char[] buf = new char[100];
				count = rd.read(buf, 0, 100);
				if(count != -1)
					body.append(buf, 0, count);
			} while(count != -1);
		}
		catch(IOException e)
		{
			// We are reading from a StringReader. there is no chance of
			// an IOException.
		}
	}

	/**
	 * Constructor for outgoing messages.
	 *
	 * @param font font for this message.
	 * @param color color of this message.
	 * @param text text representation of this message.
	 */
	MsnMessage(Font font, Color color, String text)
	{
		super("MSG");
		addParam("N"); // We do not need message acknowledgements

		this.headers = new Hashtable();
		this.body = new StringBuffer(text);

		headers.put("MIME-Version", "1.0");
		headers.put("Content-Type", "text/plain; charset=UTF-8");

		String format = new String("FN=");
		if(font != null)
		{
			format = Util.urlEncode(font.getFontName()) + ";";
			format += " EF=";
			if(font.isBold())
				format += 'B';
			if(font.isItalic())
				format += 'I';
		}
		format += ';';
		if(font == null)
			format += " EF=;";

		if(color != null)
		{
			int blue = color.getBlue();
			int green = color.getGreen();
			int red = color.getRed();
			format += (blue > 15 ? " CO=" : " CO=0") + Integer.toHexString(blue).toUpperCase();
			format += (green > 15 ? "0" : "") + Integer.toHexString(green).toUpperCase(); 
			format += (red > 15 ? "0" : "") + Integer.toHexString(red).toUpperCase() + "; CS=0; PF=0"; 
		}
		else
			format += " CO=0; CS=0; PF=0";
			
		headers.put("X-MMS-IM-Format", format);
		
		addParam(Integer.toString(getPayloadString().length()));
	}

	/**
	 * Returns a string representation of this message. The returned string is
	 * composed by appending the following components separated by space character.
	 *
	 * <ul>
	 * 	<li>Command type (MSG).</li>
	 * 	<li>All the parameters separated by space characters.</li>
	 * 	<li>The headers of the message.</li>
	 * 	<li>A blank line.</li>
	 * 	<li>The body of the message.</li>
	 * </ul>
	 *
	 * The string is not terminated by a CRLF.
	 *
	 * @return string representation of this message
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer(super.toString());
		ret.append("\r\n");
		ret.append(getPayloadString());
		return ret.toString();
	}

	/**
	 * Returns the payload of this message as a string.
	 *
	 * @return the string representation of this message's payload 
	 */
	private String getPayloadString()
	{
		StringBuffer ret = new StringBuffer();
		Enumeration keys = headers.keys();
		while(keys.hasMoreElements())
		{
			String key = (String) keys.nextElement();
			ret.append(key);
			ret.append(": ");
			ret.append(headers.get(key));
			ret.append("\r\n");
		}
		ret.append("\r\n");
		ret.append(body);	
		return ret.toString();
	}

	/**
	 * Returns the value of a header of this message.
	 *
	 * @param fieldName the name of the field.
	 * @return the value of the field, or <code>null</code> if not found.
	 */
	String getHeaderField(String fieldName)
	{
		return (String) headers.get(fieldName);
	}

	/**
	 * Returns the body part of this message as a string.
	 */
	String getBody()
	{
		return this.body.toString();
	}
}
