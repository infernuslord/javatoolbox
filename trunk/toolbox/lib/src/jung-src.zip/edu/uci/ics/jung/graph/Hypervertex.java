/*
 * Created on Dec 28, 2003
 */
package edu.uci.ics.jung.graph;


/**
 * created Dec 28, 2003
 * @author danyelf
 */
public interface Hypervertex extends ArchetypeVertex {

}
