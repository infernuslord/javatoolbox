/**
 * L2FProd.com Common Components 0.1-dev License.
 *
 * Copyright 2004 L2FProd.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.l2fprod.common.swing.plaf;

import com.l2fprod.common.swing.plaf.windows.WindowsClassicLookAndFeelAddons;
import com.l2fprod.common.swing.plaf.windows.WindowsLookAndFeelAddons;
import com.l2fprod.common.util.OS;

import javax.swing.UIManager;

/**
 * Provides additional pluggable UI for new components added by the
 * library. By default, the library uses the pluggable UI returned by
 * {@link #getSystemAddonClassName()}.
 * <p>
 * The default addon can be configured using the
 * <code>swing.addon</code> system property as follow:
 * <ul>
 * <li>on the command line,
 * <code>java -Dswing.addon=ADDONCLASSNAME ...</code></li>
 * <li>at runtime and before using the library components
 * <code>System.getProperties().put("swing.addon", ADDONCLASSNAME);</code>
 * </li>
 * </ul>
 * <p>
 * The addon can also be installed directly by calling the
 * {@link #setAddon(String)()}method. For example, to install the
 * Windows addons, add the following statement
 * <code>LookAndFeelAddons.setAddon("com.l2fprod.common.swing.plaf.windows.WindowsLookAndFeelAddons");</code>.
 */
public class LookAndFeelAddons {

  static {
    // load the default addon
    String addonClassname = System.getProperty("swing.addon",
        getSystemAddonClassName());
    try {
      setAddon(addonClassname);
    } catch (InstantiationException e) {
      e.printStackTrace();
    } catch (IllegalAccessException e) {
      e.printStackTrace();
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    }
  }

  public void initialize() {
  }

  public void uninitialize() {
  }

  protected void loadDefaults(Object[] keysAndValues) {
    for (int i = 0, c = keysAndValues.length; i < c; i = i + 2) {
      UIManager.put(keysAndValues[i], keysAndValues[i + 1]);
    }
  }

  public static void setAddon(String addonClassName)
      throws InstantiationException, IllegalAccessException,
      ClassNotFoundException {
    setAddon(Class.forName(addonClassName));
  }

  public static void setAddon(Class addonClass) throws InstantiationException,
      IllegalAccessException {
    LookAndFeelAddons addon = (LookAndFeelAddons)addonClass.newInstance();
    addon.initialize();
  }

  public static String getSystemAddonClassName() {
    String addon = WindowsClassicLookAndFeelAddons.class.getName();

    if (OS.isMacOSX()) {
      // on Mac OS X, use the class Windows style. This one does not
      // have the bug where "special" TaskPaneGroups are not
      // correctly painted.
      addon = WindowsClassicLookAndFeelAddons.class.getName();
    } else if (OS.isWindows()) {
      // see whether of not visual styles are used
      if (OS.isUsingWindowsVisualStyles()) {
        addon = WindowsLookAndFeelAddons.class.getName();
      } else {
        addon = WindowsClassicLookAndFeelAddons.class.getName();
      }
    }

    return addon;
  }

}
