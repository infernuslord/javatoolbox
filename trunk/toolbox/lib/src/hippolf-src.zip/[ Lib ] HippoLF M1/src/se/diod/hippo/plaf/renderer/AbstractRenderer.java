/*
 * 
 * Created on 2004-jul-25
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.renderer;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Rectangle;

import javax.swing.JTabbedPane;
import javax.swing.UIManager;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-25
 *
 */
public abstract class AbstractRenderer {
	protected static final Insets EMPTY_INSETS = new Insets(  0, 0, 0, 0 );
	protected static final Insets NORTH_INSETS = new Insets(  2, 0, 0, 0 );
	protected static final Insets WEST_INSETS  = new Insets(  0, 2, 0, 0 );
	protected static final Insets SOUTH_INSETS = new Insets(  0, 0, 2, 0 );
	protected static final Insets EAST_INSETS  = new Insets(  0, 0, 0, 2 );

	protected final JTabbedPane tabPane;

	protected Color colShadow;
	protected Color colSelectHighlight;




	/**
	 * 
	 * 
	 */
	public AbstractRenderer( JTabbedPane tabPane ) {
		this.tabPane		= tabPane;
	}




	/**
	 * 
	 * 
	 */
	public static AbstractRenderer createRenderer( JTabbedPane tabbedPane ) {
		switch (tabbedPane.getTabPlacement()) {
			case JTabbedPane.TOP:		return new TabRendererTop( tabbedPane );
			case JTabbedPane.BOTTOM:	return new TabRendererBottom( tabbedPane );
			case JTabbedPane.LEFT:		return new TabRendererLeft( tabbedPane );
			case JTabbedPane.RIGHT:		return new TabRendererRight( tabbedPane );
			default:					return new TabRendererTop( tabbedPane );
		}
	}




	/**
	 * 
	 *
	 */
	private void initColors() {
		colShadow			= UIManager.getColor( "TabbedPane.shadow" );
		colSelectHighlight	= UIManager.getColor( "TabbedPane.selectHighlight" );
	}




	/**
	 * 
	 * 
	 */
	public Insets getContentBorderInsets( Insets defaultInsets ) {
		return defaultInsets;
	}




	/**
	 * 
	 * 
	 */
	abstract public void paintFocusIndicator( Graphics g, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected);




	/**
	 * 
	 * Fills the background of the given tab to make sure overlap of 
	 * tabs is handled correctly.
	 * 
	 */
	abstract public void paintTabBackground( Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected );




	/**
	 * 
	 * Paints the border around the given tab
	 * 
	 */
	abstract public void paintTabBorder( Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected );




	///////////////////////////////////////////
	//          Helper methods               //
	///////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	protected boolean isTabFirstDisplayed( int tabIndex ) {
		return tabIndex == 0;
	}
}
