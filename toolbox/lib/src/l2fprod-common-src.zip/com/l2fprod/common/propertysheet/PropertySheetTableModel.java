/** ===================================================================
 *
 * @PROJECT.FULLNAME@ @VERSION@ License.
 *
 * Copyright (c) @YEAR@ L2FProd.com.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by L2FProd.com
 *        (http://www.L2FProd.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "@PROJECT.FULLNAME@", "@PROJECT.SHORTNAME@" and "L2FProd.com" must not
 *    be used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact info@L2FProd.com.
 *
 * 5. Products derived from this software may not be called "@PROJECT.SHORTNAME@"
 *    nor may "@PROJECT.SHORTNAME@" appear in their names without prior written
 *    permission of L2FProd.com.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL L2FPROD.COM OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package com.l2fprod.common.propertysheet;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.table.AbstractTableModel;

/**
 * PropertySheetTableModel. <br>
 *  
 */
public class PropertySheetTableModel extends AbstractTableModel {

  private List model;

  private List publishedModel;

  private Property[] properties;

  private int mode;

  private Object object;

  public PropertySheetTableModel() {
    model = new ArrayList();
    publishedModel = new ArrayList();
    mode = PropertySheet.VIEW_AS_FLAT_LIST;
  }

  public void setProperties(Property[] properties) {
    this.properties = properties;
    buildModel();
  }

  public Property[] getProperties() {
    return properties;
  }

  public void setMode(int mode) {
    if (this.mode == mode) {
      return;
    }

    this.mode = mode;
    buildModel();
  }

  public int getMode() {
    return mode;
  }

  public Class getColumnClass(int columnIndex) {
    return super.getColumnClass(columnIndex);
  }

  public int getColumnCount() {
    return 2;
  }

  public int getRowCount() {
    return publishedModel.size();
  }

  public Object getPropertySheetElement(int rowIndex) {
    return publishedModel.get(rowIndex);
  }

  public Object getValueAt(int rowIndex, int columnIndex) {
    Object o = getPropertySheetElement(rowIndex);
    if (o instanceof Property) {
      switch (columnIndex) {
        case 0 :
          return o;
        case 1 :
          try {
            return ((Property)o).getValue();
          } catch (Exception e) {
            e.printStackTrace();
            return null;
          }
        default :
          // will not happen
      }
    } else if (o instanceof Category) {
      return o;
    }
    return null;
  }

  public void setValueAt(Object value, int rowIndex, int columnIndex) {
    Object o = getPropertySheetElement(rowIndex);
    if (o instanceof Property) {
      if (columnIndex == 1) {
        try {
          ((Property)o).setValue(value);
        } catch (Exception e) {
          e.printStackTrace();
        }
      }
    }
  }

  public void setObject(Object object) {
    this.object = object;
    fireTableDataChanged();
  }

  private void categoryVisibilityChanged() {
    publishedModel.clear();

    Category currentCategory = null;
    for (Iterator iter = model.iterator(); iter.hasNext();) {
      Object o = iter.next();
      if (o instanceof Category) {
        currentCategory = (Category)o;
        publishedModel.add(o);
      } else if (currentCategory != null && currentCategory.isVisible()) {
        publishedModel.add(o);
      }
    }

    fireTableDataChanged();
  }

  private void buildModel() {
    model.clear();

    if (properties == null || properties.length == 0) {
      return;
    }

    if (PropertySheet.VIEW_AS_FLAT_LIST == mode) {
      for (int i = 0, c = properties.length; i < c; i++) {
        model.add(properties[i]);
      }
    } else if (PropertySheet.VIEW_AS_CATEGORIES == mode) {
      // build the list of unique categories
      List differentCategories = new ArrayList();
      for (int i = 0, c = properties.length; i < c; i++) {
        if (!differentCategories.contains(properties[i].getCategory())) {
          differentCategories.add(properties[i].getCategory());
        }
      }

      String[] categories =
        (String[])differentCategories.toArray(new String[0]);
      for (int i = 0, c = categories.length; i < c; i++) {
        model.add(new Category(categories[i]));
        for (int j = 0, d = properties.length; j < d; j++) {
          if ((properties[j].getCategory() == null
            ? categories[i] == null
            : properties[j].getCategory().equals(categories[i]))) {
            model.add(properties[j]);
          }
        }
      }
    }

    publishedModel.clear();
    publishedModel.addAll(model);

    fireTableDataChanged();
  }

  public class Category {
    private String name;
    private boolean visible = true;
    public Category(String name) {
      this.name = name;
    }
    public String getName() {
      return name;
    }
    public void toggle() {
      visible = !visible;
      categoryVisibilityChanged();
    }
    public boolean isVisible() {
      return visible;
    }
  }

}
