// Beta
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	XP Look and Feel                                                       *
*                                                                              *
*  (C) Copyright 2002, by Stefan Krause                                        *
*                                                                              *
*                                                                              *
*   This library is free software; you can redistribute it and/or modify it    *
*   under the terms of the GNU Lesser General Public License as published by   *
*   the Free Software Foundation; either version 2.1 of the License, or (at    *
*   your option) any later version.                                            *
*                                                                              *
*   This library is distributed in the hope that it will be useful,            *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of             *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                       *
*   See the GNU Lesser General Public License for more details.                *
*                                                                              *
*   You should have received a copy of the GNU General Public License along    *
*   with this program; if not, write to the Free Software Foundation, Inc.,    *
*   59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.                    *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package com.stefankrause.xplookandfeel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;

import javax.swing.JComponent;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.metal.MetalSeparatorUI;

public class XPPopupMenuSeparatorUI extends MetalSeparatorUI {
    public static ComponentUI createUI( JComponent c )
    {
        return new XPPopupMenuSeparatorUI();
    }

    /** paint the seperator manually */
    public void paint( Graphics g, JComponent c )
    {
        Dimension s = c.getSize();
		JComponent p = (JComponent) c.getParent();
		Integer maxValueInt = (Integer) p.getClientProperty(XPMenuItemUI.MAX_ICON_WIDTH);
		int maxValue = maxValueInt == null ? 16 : maxValueInt.intValue();

		g.setColor(Color.white); 
		g.fillRect(0 
		, 0, s.width 
		, s.height);

		Rectangle rect = new Rectangle(0, 0, maxValue + XPMenuItemUI.defaultTextIconGap, s.height);
		g.setColor(new Color(238,238,230));  
		g.fillRect(rect.x, rect.y, rect.width, rect.height);
		
		g.drawLine(rect.width+15,1,s.width,1);
    }

    public Dimension getPreferredSize( JComponent c )
    { 
        return new Dimension( 0, 4 );
    }
}