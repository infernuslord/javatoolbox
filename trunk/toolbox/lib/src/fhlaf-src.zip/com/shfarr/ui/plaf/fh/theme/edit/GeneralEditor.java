/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh.theme.edit;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Iterator;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.shfarr.ui.layouts.QueueLayout;


public class GeneralEditor extends JPanel implements ActionListener, ChangeListener{
    private JComboBox generalCombo = null;
    private JPanel editor = null;
    private JLabel sampleLabel = null;
    private JPanel sidePanel = null;
    private JCheckBox italicCheckBox = null;
    private JCheckBox boldCheckBox = null;
    private JPanel centerPanel = null;
    private JComboBox namesCombo = null;
    private JSpinner sizeSpinner = null;
    private JComboBox colorsCombo = null;
    
    public GeneralEditor(){
        super(new BorderLayout());
        setBorder(new EmptyBorder(10, 4, 4, 0));
        
        add(getSidePanel(), "East");
        add(getCenterPanel(), "Center");
    }

    protected JPanel getCenterPanel(){
        if(centerPanel == null){
            centerPanel = new JPanel(new BorderLayout(4, 4));
            centerPanel.setBorder(new EmptyBorder(0, 0, 0, 4));

            JPanel aPanel = new JPanel(new QueueLayout(4, QueueLayout.HORIZONTAL, QueueLayout.STRECH_COMPONENTS));
            aPanel.add(new JLabel("   Mapping key"));
            aPanel.add(getNamesCombo());
            
            centerPanel.add(aPanel, "North");
            centerPanel.add(getEditor(), "Center");
        }
    
        return centerPanel;
    }

    protected JCheckBox getBoldCheckBox(){
        if(boldCheckBox == null){
            boldCheckBox = new JCheckBox("Bold");
            boldCheckBox.addActionListener(this);
        }
    
        return boldCheckBox;
    }    
    
    protected JCheckBox getItalicCheckBox(){
        if(italicCheckBox == null){
            italicCheckBox = new JCheckBox("Italic");
            italicCheckBox.addActionListener(this);
        }
    
        return italicCheckBox;
    }    

    protected JComboBox getColorsCombo(){
        if(colorsCombo == null){
            colorsCombo = new JComboBox();

            for(int i = -10; i < 21; i++) colorsCombo.addItem("" +i);
            for(Iterator i = ThemeEditor.instance().getEditedTheme().colorPalette().keySet().iterator(); i.hasNext(); ) colorsCombo.addItem(i.next());

            colorsCombo.addActionListener(this);
        }
    
        return colorsCombo;
    }

    protected JComboBox getNamesCombo(){
        if(namesCombo == null){
            namesCombo = new JComboBox();
            
            for(Iterator i = ThemeEditor.instance().getEditedTheme().metaPalette().keySet().iterator(); i.hasNext(); ) namesCombo.addItem(i.next());

            namesCombo.setSelectedIndex(0);

            namesCombo.addActionListener(this);
            
            updateEditor();
        }
    
        return namesCombo;
    }

    protected JSpinner getSizeSpinner(){
        if(sizeSpinner == null){
            sizeSpinner = new JSpinner(new SpinnerNumberModel(0, -10000, 10000, 1));
            sizeSpinner.addChangeListener(this);
        }
    
        return sizeSpinner;
    }
    
    protected JPanel getEditor(){
        if(editor == null){
            editor = new JPanel(new QueueLayout(4, QueueLayout.VERTICAL, QueueLayout.STRECH_COMPONENTS));
        }
    
        return editor;
    }
    
    protected JPanel getSidePanel(){
        if(sidePanel == null){
            sidePanel = new JPanel(new QueueLayout(4, QueueLayout.VERTICAL, QueueLayout.STRECH_COMPONENTS));
            sidePanel.setBorder(new EmptyBorder(0, 4, 4, 4));
            
            JButton save = new JButton("Save");
            save.addActionListener(this);
            
            JButton revert = new JButton("Revert");
            revert.addActionListener(this);
            
            sidePanel.add(save);
            sidePanel.add(revert);
        }
    
        return sidePanel;
    }

    public void actionPerformed(ActionEvent e){
        if(e.getActionCommand().equals("Save")){
            ThemeEditor.instance().getEditedTheme().saveMeta();
        }
        else if(e.getActionCommand().equals("Revert")){
            ThemeEditor.instance().getEditedTheme().loadMeta();
            updateEditor();
        }
        else if(e.getSource() == getNamesCombo()) updateEditor();
        else if(e.getSource() == getColorsCombo()){
            ThemeEditor.instance().getEditedTheme().metaPalette().put(getNamesCombo().getSelectedItem(), getColorsCombo().getSelectedItem());
        }
        else if(e.getSource() instanceof JCheckBox) {
            ThemeEditor.instance().getEditedTheme().metaPalette().put(getNamesCombo().getSelectedItem(), new Boolean(((JCheckBox)e.getSource()).isSelected()));
        }
    }
    
    public void stateChanged(ChangeEvent e){
        ThemeEditor.instance().getEditedTheme().metaPalette().put(getNamesCombo().getSelectedItem(), getSizeSpinner().getValue());
    }
    
    protected void updateEditor() {
        getEditor().removeAll();
            
        String key = (String)getNamesCombo().getSelectedItem();
        Object val = ThemeEditor.instance().getEditedTheme().metaPalette().get(key);
        JPanel p = new JPanel(new QueueLayout(4, QueueLayout.HORIZONTAL, QueueLayout.STRECH_COMPONENTS));
            
        JComponent c = null;

        if(val instanceof String){
            if(key.toLowerCase().indexOf("background") != -1 ||
               key.toLowerCase().indexOf("foreground") != -1 ||
               key.toLowerCase().indexOf("highlight") != -1 ||
               key.toLowerCase().indexOf("shadow") != -1) {
                   c = getColorsCombo();
                   getColorsCombo().setSelectedItem(val);
            }
            else{
                final JTextField field = new JTextField((String)val);
                field.addKeyListener(new KeyAdapter() {
                    public void keyTyped(KeyEvent e){
                        ThemeEditor.instance().getEditedTheme().metaPalette().put(getNamesCombo().getSelectedItem(), field.getText());
                    }
                });
                
                c = field;
            }

            c.setPreferredSize(new Dimension(Math.max(c.getPreferredSize().width, getNamesCombo().getPreferredSize().width), c.getPreferredSize().height));
        }
        else if(val instanceof Number){
            c = getSizeSpinner();
            getSizeSpinner().setValue((Number)val);
            c.setPreferredSize(new Dimension(Math.max(c.getPreferredSize().width, 70), c.getPreferredSize().height));
        }
        else if(val instanceof Boolean){
            c = new JCheckBox("", Boolean.TRUE.equals(val));
            ((JCheckBox)c).addActionListener(this);
            c.setPreferredSize(new Dimension(Math.max(c.getPreferredSize().width, getNamesCombo().getPreferredSize().width), c.getPreferredSize().height));
        }
            
        p.add(new JLabel("Mapping value"));
        p.add(c);

        getEditor().add(p);
        
        if(getEditor().getParent() != null) {
            ((JComponent)getEditor().getParent()).invalidate();
            ((JComponent)getEditor().getParent()).validate();
            ((JComponent)getEditor().getParent()).repaint();
        }    
    }
}
