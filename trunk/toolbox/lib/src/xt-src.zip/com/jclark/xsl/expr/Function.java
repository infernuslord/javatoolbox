// $Id: Function.java,v 1.1 2002/04/25 18:07:19 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

/**
 * all functions have the method: "makeCallExpr( ... ) "
 */
interface Function 
{
    ConvertibleExpr makeCallExpr(ConvertibleExpr[] args, Node exprNode) 
	throws ParseException;
}
