/*
 * Created on Apr 29, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package com.shfarr.jsp;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;

/**
 * @author Stefan Harsan Farr
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class JSPTable{
    private String name = null;
    private Collection columnNames = null;
    private Collection selection = null;
    private TreeMap data = null;
    
    public JSPTable(String name, Collection columnNames){
        super();
        this.name = name;
        this.data = new TreeMap();
        this.columnNames = columnNames;
    }
    
    public void add(Object[] rowData){
        int k = 0;
        for(Iterator i = columnNames.iterator(); i.hasNext(); ){
            String column = (String)i.next();
            ArrayList columnData = (ArrayList)data.get(column);
            
            if(columnData == null){
                columnData = new ArrayList();
                data.put(column, columnData);
            }
            
            columnData.add(rowData[k]);
            
            k++;
        }
    }

    public void set(String column, int row, Object cellData){
        ArrayList columnData = (ArrayList)data.get(column);
        
        if(columnData == null){
            columnData = new ArrayList();
            data.put(column, columnData);
        }
        
        columnData.set(row, cellData);
    }

    public Object get(String column, int row){
        return ((ArrayList)data.get(column)).get(row);
    }
    
    public String toString(){
        int rowCount = -1;
        
        StringBuffer buffer = new StringBuffer("<!-- " + name + "-->\r\n");
        
        // begin table
        buffer.append("<table width=100% name=" + name + " class=default_table >\r\n");
        
        // add table header
        buffer.append("    <tr>\r\n");
        for(Iterator i = columnNames.iterator(); i.hasNext(); ){
            String column = (String)i.next();
            if(rowCount == -1) rowCount = data.isEmpty() ? 0 : ((List)data.get(column)).size();
            
            String cls = "default_table_header" + (i.hasNext() ? "" : "_right"); 
            buffer.append("        <td class=" + cls + ">" + column + "</td>\r\n");
        }
        buffer.append("    </tr>");
        
        // add table rows
        for(int k = 0; k < rowCount; k++){
            buffer.append("    <tr>\r\n");
            for(Iterator i = columnNames.iterator(); i.hasNext(); ){
                String column = (String)i.next();
                String cls = (selection != null && selection.contains(new Integer(k)) ? "default_table_selected_cell" : "default_table_cell") + (k == rowCount -1 ? "_bottom" : "") + (i.hasNext() ? "" : "_right"); 
                buffer.append("        <td class=" + cls + ">" + ((List)data.get(column)).get(k) + "</td>\r\n");
            }
            buffer.append("    </tr>");
        }
        
        // close table
        buffer.append("</table>");
        
        return buffer.toString();
    }
	
    public Collection getSelection(){
		return selection;
	}
	
    public void setSelection(Collection selection){
		this.selection = selection;
	}
}
