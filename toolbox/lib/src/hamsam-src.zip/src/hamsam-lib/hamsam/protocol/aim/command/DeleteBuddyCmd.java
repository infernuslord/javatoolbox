/*
 *
 * Hamsam - Instant Messaging API
 *
 * Copyright (C) 2003 Mike Miller <mikemil@users.sourceforge.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 */
 
package hamsam.protocol.aim.command;

import hamsam.api.Buddy;
import hamsam.protocol.aim.flap.FlapConstants;
import hamsam.protocol.aim.flap.FlapHeader;
import hamsam.protocol.aim.snac.SNACConstants;
import hamsam.protocol.aim.snac.SNACPacket;
import hamsam.protocol.aim.util.ByteUtils;

import java.io.IOException;
import java.io.OutputStream;

/**
 * @author mike
 */
public class DeleteBuddyCmd extends Command {

    String buddyName;

    /**
     * Constructor
     * 
     * @param seqNum sequence number for the FlapHeader
     * @param buddy Buddy to be deleted
     */
    public DeleteBuddyCmd(int seqNum, Buddy buddy) {
        flapHdr        = new FlapHeader(FlapConstants.FLAP_CHANNEL_SNAC, seqNum);
        snacPacket     = new SNACPacket(SNACConstants.SNAC_FAMILY_BUDDY_LIST_MANAGEMENT, 
                                        SNACConstants.SNAC_SUBTYPE_DEL_BUDDY);
                            
        buddyName = buddy.getUsername();
    }


    /**
     * Write command data to the output stream 
     * 
     * @param os output stream for the command 
     * @see hamsam.protocol.aim.command.Command#writeCommandData(java.io.OutputStream)
     */
    public void writeCommandData(OutputStream os) throws IOException {
        os.write(buddyName.length());
        os.write(ByteUtils.getBytes(buddyName));
    }

}
