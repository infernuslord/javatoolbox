/*
 * Hamsam - Instant Messaging API
 * Copyright (C) 2003 Raghu K
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package hamsam.protocol.msn;

/**
 * A query command is used to answer challenges raised by MSN server. A challenge
 * is a ping from notification server.
 */
class MsnQuery extends AbstractCommand
{
	/**
	 * Payload for query is stored here.
	 */
	private String payload;

	/**
	 * Constructor for outgoing queries.
	 *
	 * @param payload payload to be sent to the server.
	 */
	MsnQuery(String payload)
	{
		super("QRY");
		addParam("msmsgs@msnmsgr.com");
		addParam("32");

		this.payload = payload;
	}

	/**
	 * Returns a string representation of this query. The returned string is
	 * composed by appending the following components.
	 *
	 * <ul>
	 * 	<li>Command type (QRY).</li>
	 * 	<li>A space character.</li>
	 * 	<li>Transaction ID, if available.</li>
	 * 	<li>A space character.</li>
	 * 	<li>All the parameters separated by space characters.</li>
	 * 	<li>A CRLF.</li>
	 * 	<li>The payload of this query.</li>
	 * </ul>
	 *
	 * The string is not terminated by a CRLF.
	 *
	 * @return string representation of this query.
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer(super.toString());
		ret.append("\r\n");

		ret.append(payload);

		return ret.toString();
	}
}
