/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh.textures;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;

import javax.swing.JComponent;

import com.shfarr.ui.plaf.fh.theme.Theme;
import com.shfarr.ui.plaf.fh.theme.ThemeManager;


public abstract class Texture{
    public static final byte GRADIENT_TEXTURE_FAMILY = 0;
    public static final byte IMAGE_TEXTURE_FAMILY = 1;
    
    public static final int ROTATE_0 = 0;
    public static final int ROTATE_90 = 1;
    public static final int ROTATE_180 = 2;
    public static final int ROTATE_270 = 3;

    protected int naturalRotation = ROTATE_0;
    protected int rotation = ROTATE_0;
    protected Theme theme = null;
     
    public Texture(){
        theme = ThemeManager.instance().getCurrentTheme();
    }

    public void setTheme(Theme theme){
        this.theme = theme;
    }

    public void apply(Shape s, Graphics2D g2D, JComponent c){
        apply(s, null, g2D, c);
    }
    
	public abstract void apply(Shape s, Rectangle clip, Graphics2D g2D, JComponent c);
    public abstract void parse(String str);

    public int getNaturalRotation(){
        return naturalRotation;
    }

    public void setNaturalRotation(int naturalRotation){
        this.naturalRotation = naturalRotation;
    }

    protected int getRotation(){
        return rotation;
    }

    protected int actualRotation(){
        return (getNaturalRotation() +getRotation())%4;
    }
    
    public void rotate(int rotation){
        this.rotation += rotation; 
    }
}
