/*
 *
 * Hamsam - Instant Messaging API
 *
 * Copyright (C) 2003 Mike Miller <mikemil@users.sourceforge.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 */

package hamsam.protocol.aim.flap;

/**
 * @author mikem
 */
public class FlapConstants {

    //~ Static fields/initializers -----------------------------------------------------------------


    // 1st byte of every flap 
    public static byte FLAP_PREAMBLE           = 0x2a;

    // flap channel values
    public static byte FLAP_CHANNEL_CONNECT    = 0x01;
    public static byte FLAP_CHANNEL_SNAC       = 0x02;
    public static byte FLAP_CHANNEL_ERROR      = 0x03;
    public static byte FLAP_CHANNEL_DISCONNECT = 0x04;
    public static byte FLAP_CHANNEL_KEEP_ALIVE = 0x05;
    
    // max length of a FLAP Packet
    public static int FLAP_MAX_DATA_LENGTH     = 0xffff;
    
    
}


