/**
 * @(#)JCmdMain.java
 *
 * JReversePro - Java Decompiler / Disassembler.
 * Copyright (C) 2000 2001 Karthik Kumar.
 * EMail: akkumar@users.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it , under the terms of the GNU General Public License as published
 * by the Free Software Foundation; either version 2 of the License,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program.If not, write to
 *  The Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330,
 *  Boston, MA 02111-1307, USA.
 *
 **/
package jreversepro;

import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.File;
import java.io.IOException;
import java.io.FileNotFoundException;

import java.util.StringTokenizer;
import java.util.List;
import java.util.Enumeration;
import java.util.ArrayList;

import java.net.URL;

import jreversepro.parser.JClassParser;
import jreversepro.parser.ClassParserException;
import jreversepro.revengine.RevEngineException;

import jreversepro.common.Helper;
import jreversepro.common.AppConstants;

import jreversepro.reflect.JConstantPool;
import jreversepro.reflect.JClassInfo;
import jreversepro.revengine.JSerializer;

/**
 * @author Karthik Kumar.
 * @version 1.3
 **/
public class JCmdMain 
    implements AppConstants 
{

    static final String CMD_PROMPT      = "\n(jrevpro)";
    static final String CMD_EXIT        = "exit";
    static final String CMD_DISASSEMBLE = "disassemble";
    static final String CMD_DA          = "da";
    static final String CMD_DEBUG       = "debug";
    static final String CMD_DECOMPILE   = "decompile";
    static final String CMD_DC          = "dc";
    static final String CMD_VIEWPOOL    = "viewpool";
    static final String CMD_VP          = "vp";
    static final String CMD_SWING       = "g";
    static final String CMD_AWT         = "u";
    static final String CMD_HELP        = "help";
    static final String CMD_INTERACTIVE = "i";
    static final String HELP_MSG;

    /**
     * Command-line options.
     **/
    static final String CMD_OPTIONS =
                        "Syntax: jrevpro -i|-da|-dc|-vp <Class File>" +
                         "\n -i Interactive" + "\n -da disassemble" +
                         "\n -dc Decompile" + "\n -vp View ConstantPool" ;

    static final List listCommands;

    /**
     * Class Parser invoked.
     **/
    private static JSerializer mSerializer;

    static {
        mSerializer = new JSerializer();

        StringBuffer sb =  new StringBuffer();

        sb.append( CMD_DISASSEMBLE + " | " + CMD_DA +
                " [<OutputFile>] \t" +
                                            "Disassemble file\n");

        sb.append( CMD_DECOMPILE + " | " + CMD_DC +
                " [ <OutputFile> ] \t" +
                                            "Decompile file\n");
        sb.append( CMD_VIEWPOOL + " | " + CMD_VP +
                " [ <ConstantPoolIndex> ] \t" +
                                          "View ConstantPool\n");
        sb.append( CMD_DEBUG +  "\t\t\t\t\t" + "Toggle debug mode\n");
        sb.append( CMD_HELP +  "\t\t\t\t\t" + "Print this menu\n");
        sb.append( CMD_EXIT +   "\t\t\t\t\t" + "Exit");

        HELP_MSG = sb.toString();

        listCommands =  new ArrayList();
        listCommands.add(CMD_DA);
        listCommands.add(CMD_DC);
        listCommands.add(CMD_VP);
        listCommands.add(CMD_INTERACTIVE);
        listCommands.add(CMD_DISASSEMBLE);
        listCommands.add(CMD_DECOMPILE);
        listCommands.add(CMD_VIEWPOOL);
        listCommands.add(CMD_SWING);
        listCommands.add(CMD_AWT);
        listCommands.add(CMD_DEBUG);
        listCommands.add(CMD_HELP);
    }


    /**
     * Driving the application.
     * @param aArgs Argument to Main.
     **/
    public static void main(String [] aArgs) {
        System.out.println(GPL_INFO);

        if (!Helper.versionCheck()) {
            System.exit(1);
        }
        if (aArgs.length > 0 && aArgs.length < 4) {
            JCmdMain main = new JCmdMain();
            main.process(aArgs);

        } else {
            System.err.println(CMD_OPTIONS + "\n");
            System.exit(1);
        }
    }

    public void process(String[] aArgs) {
        String cmd = aArgs[0].substring(1);

        if (!listCommands.contains(cmd)) {
            System.err.println(CMD_OPTIONS + "\n");
            System.exit(1);
        }

        if (cmd.equals(CMD_SWING)) {
            (new JMainFrame()).setVisible(true);
            return;
        } else if ( cmd.equals(CMD_AWT) ) {
            (new JAwtFrame()).setVisible(true);
            return;
        }

        JClassInfo inf = loadClass(aArgs[1]);
        if (cmd.equals(CMD_INTERACTIVE)) {
            if (aArgs.length == 2) {
                listen(inf, aArgs[1]);
            }
        } else {
            StringBuffer sb = new StringBuffer();
            sb.append(cmd);
            
            for (int i=2; i<aArgs.length; i++) {
                sb.append(" " + aArgs[i]);
            }
            process(inf, sb.toString());
        }
    }

    public void listen(JClassInfo mInfoClass, String inputFile) {
        if ( mInfoClass == null ) {
            return;
        }

        try {
            System.out.println("Type '" + CMD_HELP + "' to get started...");
            BufferedReader br
              = new BufferedReader(
                    new InputStreamReader(System.in));
            boolean status = true;
            while ( status ) {
                System.out.print(CMD_PROMPT);
                String cmd = br.readLine();
                status = process(mInfoClass, cmd);
            }
        } catch ( IOException ioex ) {
        //Extreme case.
        }
   }

   private JClassInfo loadClass(String inputFile ) {
       JClassInfo mInfoClass = null;

       try {
           File file = new File(inputFile);

           if (!file.exists()) {
               URL url = new URL(inputFile);
               mInfoClass = mSerializer.loadClass(url);
           } else {
               mInfoClass = mSerializer.loadClass(file);
           }

           Helper.log("Successfully loaded class : " + inputFile );
       } catch (ClassParserException cpex) {
           System.err.println("Failed to load class : " + inputFile );
           System.err.println(cpex);
       } catch (IOException ioex) {
           // Extreme case.
           System.err.println("Failed to load class : " + inputFile );
       }

       return mInfoClass;
   }

   private boolean process(JClassInfo aInfoClass,
                           String cmd ) 
    {
        if ( aInfoClass == null ) {
            return false;
        }

        StringTokenizer strTok =  new StringTokenizer(cmd);
        ArrayList       tokens =  new ArrayList();
        while ( strTok.hasMoreTokens() ) {
            tokens.add (strTok.nextToken());
        }
        tokens.trimToSize();
        int size = tokens.size();
        if ( size != 0 ) {
            String opcode = (String)tokens.get(0);
            if ( opcode.equals(CMD_EXIT) ) {
                return false;
            }
            else if ( opcode.equals(CMD_DEBUG)  ) {

                boolean flag = Helper.toggleDebug();
                System.out.println("Debug mode is " + flag );
                return true;
            }
            else if ( opcode.equals(CMD_DISASSEMBLE) ||
                        opcode.equals(CMD_DA) ) {
                try {
                    String output = null;
                    if ( size > 2 ) {
                        System.err.println("disassemble [ <outputfile>] ");
                        return true;
                    }
                    else if ( size == 2 ) {
                        output = (String) tokens.get(1);
                    }
                    String result = mSerializer.reverseEngineer(false);
                    PrintStream ps;
                    if ( output != null ) {
                        ps = new PrintStream(
                                    new FileOutputStream( output) );
                    } else {
                        ps = System.out;
                    }
                    ps.print(result);
                    if ( !ps.equals(System.out) ) {
                        ps.close();
                        Helper.log("Output successfully written to "  + output );
                    }
                } catch ( Exception ex ) {
                    System.out.println( ex );
                }
                return true;
            }
            else if ( opcode.equals(CMD_DECOMPILE) ||
                        opcode.equals(CMD_DC) ) {
                try {
                    String output= null;
                    if ( size > 2 ) {
                        System.err.println("decompile [ <outputfile>] ");
                        return true;
                    }
                    else if ( size == 2 ) {
                        output = (String) tokens.get(1);
                    }
                    String result = mSerializer.reverseEngineer(true);
                    PrintStream ps;
                    if ( output != null ) {
                        ps = new PrintStream(
                                    new FileOutputStream( output) );
                    } else {
                        ps = System.out;
                    }
                    ps.print(result);
                    if ( !ps.equals(System.out) ) {
                        ps.close();
                        Helper.log("Output successfully written to "  + output );
                    }
                } catch ( Exception ex ) {
                    System.out.println ( ex );
                }
                return true;
            }
            else if ( opcode.equals(CMD_VIEWPOOL) ||
                      opcode.equals(CMD_VP) ) {
            String msg = "Syntax : viewpool [ <ConstantPoolIndex No> ] ";
            if ( size == 1 ) {
                msg = aInfoClass.
                    getConstantPool().getEntryInfo();
            } else if ( size == 2 ) {
                try {
                    int lIndex = Integer.parseInt(
                                (String) tokens.get(1) );
                    msg = aInfoClass.
                        getConstantPool().getEntryInfo(lIndex);
                } catch ( NumberFormatException nfe ) {
                }
            }
            System.out.println ( msg );
                return true;
            }
            else if ( opcode.equals(CMD_HELP) ) {
                System.out.println( HELP_MSG );
                return true;
            }
            else {
                System.err.println("Unknown Command");
                return true;
            }
        }
        else {
            return true;
        }
    }
}
