package tool.doc;

import java.io.*;
import java.awt.Point;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.MalformedURLException;
import java.util.Iterator;

import multivalent.*;
import multivalent.node.FixedI;
import multivalent.node.LeafText;

import phelps.io.FileList;
import phelps.io.InputStreamCached;
import phelps.lang.Integers;
import phelps.util.Units;
import phelps.util.Arrayss;
import phelps.net.URIs;



/**
	Extract Unicode text from any supported document type: PDF, HTML, man pages, DVI, Plucker, ....
	Documents can be flowed for fixed, single page or multiple page.
	Use either as {@link #main(String[]) command line tool} or method {@link #extract(URI, String)} from another program.

<!--<p>Done as test for and example of {@link MediaAdaptor#parse(INode)}. -->

	@see java.text.BreakIterator

	@version $Revision: 1.13 $ $Date: 2004/03/12 02:53:28 $
*/
public class ExtractText {
  static final boolean DEBUG = true;

  public static final String USAGE = "java tool.doc.ExtractText [-page <range>] [-separator <string>] <file...>";
  public static final String VERSION = "1.1.1 of $Date: 2004/03/12 02:53:28 $";	// 1.1 = -layout, 1.1.1 = refined sub/sup detection

  //static final int SUBSUP_OVERLAP = 5;
  static String PAGE_DIVIDER = "==============================================";


  private String range_;
  private boolean flayout_;
  private String sep_;
  private boolean fverbose_, fquiet_;

  public ExtractText() {
	defaults();
  }

  public void defaults() {
	range_ = null;
	flayout_ = false;
	sep_ = PAGE_DIVIDER;

	fverbose_ = false; fquiet_ = true;
  }

  public void setVerbose(boolean b) { fverbose_ = b; }
  public void setQuiet(boolean b) { fquiet_ = b; }
  public void setRange(String range) { range_ = range; }
  public void setLayout(boolean b) { flayout_ = b; }



  /**
	Return {@link java.lang.StringBuffer} with text of document at <var>uri</var>.
	@return <code>null</code> if document of unknown type

	@param mimeType     mimeType of document, or <code>null</code> if not known
	@param uri          URI of document, local file or network
  */
  public String extract(URI uri, String mimeType) throws Exception {
	if (!fquiet_) System.err.println(uri);
	StringBuffer sb = new StringBuffer(20 * 1000);

	Document doc = new Document("top", null, null);
	Cache cache = Multivalent.getInstance().getCache();
	String genre = cache.getGenre(mimeType, uri.toString(), null);
	if ("RawImage".equals(genre) || genre == "ASCII"/*null*/) return null;  // defaulted to intern()'ed ASCII

	// media adaptors are obligated to perform outside of a browser context too
	MediaAdaptor ma = (MediaAdaptor)Behavior.getInstance(genre, genre, null, null, null);
	//File file = "file".equals(uri.getScheme())? new File(uri.getPath()): null;
	//InputStream is = new InputStreamCached(URIs.toURL(uri).openStream(), file, null);
	InputStream is = new InputStreamCached(URIs.toURL(uri).openStream(), new File(uri.getPath()), null);
	ma.setInputStream(is);
	ma.setHints(MediaAdaptor.HINT_NO_IMAGE | MediaAdaptor.HINT_NO_SHAPE | MediaAdaptor.HINT_EXACT | MediaAdaptor.HINT_NO_TRANSCLUSIONS);    // only want text

	ma.docURI = uri;
	ma.parse(doc);


	// Extract body text with extractBody(doc),
	// and extract metadata with doc.getAttr(<var>key</var>), where <var>key</var> is <code>title</code>, <code>author</code>.

	int page = Math.max(1, Integers.parseInt(doc.getAttr(Document.ATTR_PAGE), -1)), pagecnt = Integers.parseInt(doc.getAttr(Document.ATTR_PAGECOUNT), -1);
	if (pagecnt<=0) {   // single long scroll
		/*if (flayout_) extractLayout(doc, sb)--not for flowed yet; else*/ extractFlow(doc, sb);

	} else {
		for (int i: Units.parseRange(range_, 1,pagecnt)) {    // multipage
			if (fverbose_) System.err.print(" "+i);
			//doc.removeAllChildren();
			doc.clear();
			doc.putAttr(Document.ATTR_PAGE, Integer.toString(i));
			doc.putAttr(Document.ATTR_PAGECOUNT, Integer.toString(pagecnt));    // zapped by doc.clear()
			//makeDoc(mimeType, uri, doc);
			ma.parse(doc);
			if (flayout_) extractLayout(doc, sb); else extractFlow(doc, sb);

			if (i+1 < pagecnt && sep_.length()>0) sb.append("\n\n").append(sep_);
			sb.append("\n\n");
		}
		if (fverbose_) System.err.println();
	}

	ma.closeInputStream();


	return sb.toString();
  }



  /**
	Traverse document tree and extract text.
  */
  public void extractFlow(Node top, StringBuffer sb) {
	if (top==null) return;    // in case of bug in media adaptor

	Node n = top.getFirstLeaf();
	if (n.bbox.width!=0 || n.bbox.height!=0) extractFlowFixed(top, sb); else extractFlowStruct(top, sb);
  }


  /** Extract text by following structure in document tree, which is apt for HTML. */
  public static void extractFlowStruct(Node n, StringBuffer sb) {
	if (n.breakBefore()) sb.append("\n");

	if (n.isLeaf()) {
		if (n instanceof LeafText) sb.append(n.getName());

	} else { assert n.isStruct();
		INode p = (INode)n;
		for (int i=0,imax=p.size(); i<imax; i++) {
			extractFlowStruct(p.childAt(i), sb);
			sb.append(" ");
		}
	}

	if (n.breakAfter()) sb.append("\n");
  }


  /** Extract text in same flow as document tree but track coordinates, which is apt for PDF. */
  public static void extractFlowFixed(Node top, StringBuffer sb) {
	Point abs=null, absprev=new Point(Integer.MAX_VALUE, Integer.MAX_VALUE);
	for (Node n=top.getFirstLeaf(),end=top.getLastLeaf().getNextLeaf(), prev=null;  n!=end && n!=null;  prev=n, absprev=abs, n=n.getNextLeaf()) {
//System.out.println(n.getClass().getName()+" / "+n.getName());
		if (!(n instanceof LeafText)) continue;

		// linebreaking
		abs = n.getAbsLocation();
//System.out.println(n.getName()+" "+abs);

		boolean fsameline = true;
		if (prev!=null) {	// concat or start new line
			int y=abs.y, h=n.bbox.height,  yprev=absprev.y, hprev=prev.bbox.height;
//System.out.println(n.bbox.y+"->"+y+" + "+h+", "+prev.bbox.y+"->"+yprev+" + "+hprev+" @ "+n.getName());
			if (yprev + hprev /* - SUBSUP_OVERLAP*/ <= y + h/3) { sb.append(y - (yprev+hprev) < Math.min(h,hprev)? "\n": "\n\n"); fsameline=false; }	// subscript?
			else if (y+h /*- SUBSUP_OVERLAP*/ <= yprev + h/3) { sb.append(yprev - (y+h) < Math.min(h,hprev)? "\n": "\n\n"); fsameline=false; }	// superscript?
			//else same line, maybe paste tokens back together into bigger word

			if (fsameline) {
				int x=abs.x, w=n.bbox.width,  xprev=absprev.x, wprev=prev.bbox.width;
//System.out.println(xprev+" + "+wprev+" => "+x+", "+(x-(xprev+wprev)));
				if (x - (xprev + wprev) > 0) sb.append(' ');
			}
		}

		sb.append(n.getName());     // if -ascii, strain out Unicode (>=256? >=128?)
	}
  }

  /**
	Preserve layout as much as possible in straight ASCII.  Currently available for PDF and DVI.
  */
  public static void extractLayout(Node top, StringBuffer sb) {
	int pagewidth = 640/2, pageheight = 480/2;	// zeros?

	final int HMAX=1000; int[] hhist = new int[HMAX];
	// 1. (a) estimate body text height and (b) expand pagewidth and pageheight if necessary
	int chcnt = 0;
	for (Node n=top.getFirstLeaf(),end=top.getLastLeaf().getNextLeaf(); n!=end && n!=null; n=n.getNextLeaf()) {
		if (!(n instanceof LeafText)) continue;
		int cc = n.getName().length();
		int h = n.bbox.height; hhist[h<HMAX? h: HMAX-1] += cc;

		Point abs = n.getAbsLocation();
		if (pagewidth < abs.x + n.bbox.width) pagewidth = abs.x + n.bbox.width;
		if (pageheight < abs.y + n.bbox.height) pageheight = abs.y + n.bbox.height;

		chcnt += cc;
	}
	if (chcnt==0) { sb.append("\n\n\n"); return; }	// empty page

	int body = -1, threshold = chcnt/4;
	for (int i=0+1, rc=hhist[0]; i<HMAX; i++) { rc+=hhist[i]; if (rc>=threshold) { body=i; break; } }
//System.out.println("chcnt = "+chcnt+", threshold = "+threshold+", body = "+body);
	int rows = Math.max(24, pageheight / body * 5/4);
	int cols = Math.max(40, pagewidth / body * 7/2);	// average width much less than height: 'i', 'j', 't'
//System.out.println("mode = "+mode+", rows="+rows+", cols="+cols+", pagewidth="+pagewidth+", pageheight="+pageheight);
	pageheight++;	// make sure "x / pageheight" gives 0..rows-1

	// 2. poke words into grid
	char[][] grid = new char[rows][cols];
	for (Node n=top.getFirstLeaf(),end=top.getLastLeaf().getNextLeaf(); n!=end && n!=null; n=n.getNextLeaf()) {
		if (!(n instanceof LeafText)) continue;
		Point abs = n.getAbsLocation();
		
		int r = ((abs.y + n.bbox.height) * rows) / pageheight, c = (abs.x * cols) / pagewidth;
		String txt = n.getName();
//System.out.println("poking '"+txt+" from "+abs.x+","+abs.y+" into "+c+","+r);
		char[] row = grid[r];
		/*		// LATER: handle overlapping text
		if (row[c]!='\0') {
			for (int cmax=row.length; c<cmax && row[c]!='\0'; c++) {}
			c++;	// space between
		}*/
		int cend = c + txt.length();
		if (cend > row.length) row = grid[r] = Arrayss.resize(row, cend);
		for (int i=0,imax=txt.length(); i<imax; i++) row[c+i] = txt.charAt(i);		
	}

	// 3. write out grid
	//boolean ffirst = true;
	for (int r=0; r<rows; r++) {
		char[] row = grid[r];
		// find last char on line
		int last = -1;
		for (int c=cols-1; c>=0; c--) if (row[c]!='\0') { last=c+1; break; }

		for (int c=0; c<last; c++) {
			char ch = row[c];
			sb.append(ch!='\0'? ch: ' ');
		}
		if (last>0 /*|| !ffirst*/) { sb.append("\n"); /*ffirst=false;*/ }
	}
  }



  private int commandLine(String[] argv) {
	fquiet_ = false;
	int argi=0, argc=argv.length;

	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.startsWith("-page") || arg.equals("-range")) range_ = argv[++argi];
		else if (arg.startsWith("-lay"/*out*/) || arg.startsWith("-form"/*at*/)) flayout_ = true;
		else if (arg.startsWith("-flow")) flayout_ = false;
		else if (arg.startsWith("-sep"/*arator*/)) sep_ = argv[++argi];
		//else if (arg.startsWith("-label")) flabel_ = true;	// enable grep over PDF, slowly
		// -row, -col
		//else if (arg.equals("-mime")) mime = argv[++argi];
		//else if (arg.startsWith("-meta"/*data*/)) fmeta = true;
		// -unicode, -ascii, -xml, -html -xhtml

		else if (arg.startsWith("-verb"/*ose*/)) fverbose_ = true;
		else if (arg.startsWith("-q"/*uiet*/)) {}
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.equals("-help")) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	if (argi == argc) { System.err.println(USAGE); System.exit(0); }

	return argi;
  }

  public static void main(String[] argv) throws IOException {
	ExtractText et = new ExtractText();
	int argi = et.commandLine(argv);

	for (Iterator<File> i = new FileList(argv, argi, null).iterator(); i.hasNext() ; ) {
	//final URI BASE = new File(".").getCanonicalFile().toURI();	// extract text over network with "http://..." => not from command line
	//for (int argc=argv.length; argi < argc; ) {
		//String suri = argv[argi++];
		File file = i.next();
		try {
			//URI uri = BASE.resolve(suri);
			//String txt = et.extract(uri, null);
			String txt = et.extract(file.toURI(), null);
			System.out.println(txt);

		} catch (Exception e) {
			System.out.println(file+": "+e);
			e.printStackTrace();    // media adaptors shouldn't rely on Root, Browser, ...
		}
	}

	System.exit(0);	// may have started up graphics event loop
  }
}
