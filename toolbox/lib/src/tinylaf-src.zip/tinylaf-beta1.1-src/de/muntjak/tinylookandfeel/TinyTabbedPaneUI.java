/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	Tiny Look and Feel                                                         *
*                                                                              *
*  (C) Copyright 2003, Hans Bickel                                             *
*                                                                              *
*   For licensing information and credits, please refer to the                 *
*   comment in file de.muntjak.tinylookandfeel.TinyLookAndFeel                 *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package de.muntjak.tinylookandfeel;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicTabbedPaneUI;

import de.muntjak.tinylookandfeel.controlpanel.*;

/**
 * TinyTabbedPaneUI
 * 
 * @version 1.0
 * @author Hans Bickel
 */
public class TinyTabbedPaneUI extends BasicTabbedPaneUI {

	/**
	 * The outer highlight color of the border.
	 */
	private Color outerHighlight = TinyDefaultTheme.tabbedPaneBorderColor;
	
	/**
	 * Creates the UI delegate for the given component.
	 *
	 * @param mainColor The component to create its UI delegate.
	 * @return The UI delegate for the given component.
	 */
	public static ComponentUI createUI(JComponent c) {
		return new TinyTabbedPaneUI();
	}

	int rollover = -1;

	protected void installListeners() {
		super.installListeners();
		tabPane.addMouseMotionListener((MouseMotionListener) mouseListener);
	}
	
	protected void installDefaults() {
		super.installDefaults();
		
		if(!ControlPanel.isInstantiated) return;
		
		tabPane.setForeground(Theme.tabFontColor[Theme.style].getColor());
	}
	
	protected MouseListener createMouseListener() {
		return new MyMouseHandler();
	}
	
	private void ensureCurrentLayout() {
		if (!tabPane.isValid()) {
			tabPane.validate();
		}
		/* If tabPane doesn't have a peer yet, the validate() call will
		 * silently fail.  We handle that by forcing a layout if tabPane
		 * is still invalid.  See bug 4237677.
		 */
		if (!tabPane.isValid()) {
			TabbedPaneLayout layout = (TabbedPaneLayout) tabPane.getLayout();
			layout.calculateLayoutInfo();
		}
	}
	
	private int getTabAtLocation(int x, int y) {
		ensureCurrentLayout();

		int tabCount = tabPane.getTabCount();
		for (int i = 0; i < tabCount; i++) {
			if (rects[i].contains(x, y)) {
				return i;
			}
		}
		return -1;
	}
	
	public class MyMouseHandler implements MouseListener, MouseMotionListener {
		public void mousePressed(MouseEvent e) {
			if (!tabPane.isEnabled()) {
				return;
			}
			int tabIndex = getTabAtLocation(e.getX(), e.getY());
			if (tabIndex >= 0 && tabPane.isEnabledAt(tabIndex)) {
				if (tabIndex == tabPane.getSelectedIndex()) {
					if (tabPane.isRequestFocusEnabled()) {
						tabPane.requestFocus();
						tabPane.repaint(getTabBounds(tabPane, tabIndex));
					}
				} else {
					tabPane.setSelectedIndex(tabIndex);
				}
			}
		}
		public void mouseEntered(MouseEvent e) {
		}

		public void mouseExited(MouseEvent e) {
			if (rollover != -1) {
				tabPane.repaint(getTabBounds(tabPane, rollover));
				rollover = -1;
			}
		}

		public void mouseClicked(MouseEvent e) {
		}

		public void mouseReleased(MouseEvent e) {
		}

		public void mouseDragged(MouseEvent e) {
		}

		public void mouseMoved(MouseEvent e) {
			if (tabPane == null)
				return;
			if (!tabPane.isEnabled()) {
				return;
			}
			int tabIndex = getTabAtLocation(e.getX(), e.getY());
			if (tabIndex != rollover && rollover != -1) { // Update old rollover
				tabPane.repaint(getTabBounds(tabPane, rollover));
				if (tabIndex == -1)
					rollover = -1;
			}
			if (tabIndex >= 0 && tabPane.isEnabledAt(tabIndex)) {
				if (tabIndex == rollover) { // Paint new rollover
				} else {
					rollover = tabIndex;
					tabPane.repaint(getTabBounds(tabPane, tabIndex));
				}
			}
		}
	}

	/**
	 * Paints the backround of a given tab.
	 *
	 * @param g The graphics context.
	 * @param tabPlacement The placement of the tab to paint.
	 * @param tabIndex The index of the tab to paint.
	 * @param x The x coordinate of the top left corner.
	 * @param y The y coordinate of the top left corner.
	 * @param w The width.
	 * @param h The height.
	 * @param isSelected True if the tab to paint is selected otherwise false.
	 */
	protected void paintTabBackground(Graphics g, int tabPlacement,
		int tabIndex, int x, int y, int w, int h, boolean isSelected)
	{
		if(isSelected) {		
			g.setColor(Theme.tabSelectedColor[Theme.style].getColor());
		}
		else {
			g.setColor(Theme.tabNormalColor[Theme.style].getColor());
		}
		
		switch(tabPlacement) {
			case LEFT:
				g.fillRect(x + 1, y + 1, w - 1, h - 3);
				break;
			case RIGHT:
				g.fillRect(x, y + 1, w - 1, h - 3);
				break;
			case BOTTOM:
				g.fillRect(x + 1, y, w - 3, h - 1);
				break;
			case TOP:
			default:
				g.fillRect(x + 1, y + 1, w - 3, h - 1);
		}
	}

	/**
	 * Paints the border of a given tab.
	 *
	 * @param g The graphics context.
	 * @param tabPlacement The placement of the tab to paint.
	 * @param selectedIndex The index of the selected tab.
	 */
	protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex) {}
	
	/**
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#paintFocusIndicator(Graphics, int, Rectangle[], int, Rectangle, Rectangle, boolean)
	 */
	protected void paintFocusIndicator(
		Graphics g,
		int tabPlacement,
		Rectangle[] rects,
		int tabIndex,
		Rectangle iconRect,
		Rectangle textRect,
		boolean isSelected)
	{
		if(!Theme.tabFocus[Theme.style]) return;
		
		super.paintFocusIndicator(g, 
			tabPlacement,
			rects,
			tabIndex,
			iconRect,
			textRect,
			isSelected);
	}

	/**
	 * Draws the border around each tab.
	 *
	 * @param g The graphics context.
	 * @param tabPlacement The placement of the tabs.
	 * @param tabIndex The index of the tab to paint.
	 * @param x The x coordinate of the top left corner.
	 * @param y The y coordinate of the top left corner.
	 * @param w The width.
	 * @param h The height.
	 * @param isSelected True if the tab to paint is selected otherwise false.
	 */
	protected void paintTabBorder(Graphics g, int tabPlacement, int tabIndex, int x, int y,
		int w, int h, boolean isSelected)
	{
		boolean isEnabled = tabPane.isEnabledAt(tabIndex);
		boolean isRollover = (rollover == tabIndex);
		
		switch(Theme.derivedStyle[Theme.style]) {
			case Theme.TINY_STYLE:
				drawTinyTabBorder(g, tabPlacement, x, y, w, h, isSelected, isEnabled, isRollover);
				break;
			case Theme.WIN_STYLE:
				drawWinTabBorder(g, tabPlacement, x, y, w, h, isSelected, isEnabled, isRollover);
				break;
			case Theme.XP_STYLE:
				drawXpTabBorder(g, tabPlacement, x, y, w, h, isSelected, isEnabled, isRollover);
				break;
		}
	}
	
	private void drawTinyTabBorder(Graphics g, int tabPlacement, int x, int y,
		int w, int h, boolean isSelected, boolean isEnabled, boolean isRollover)
	{
		
	}
	
	private void drawWinTabBorder(Graphics g, int tabPlacement, int x, int y,
		int w, int h, boolean isSelected, boolean isEnabled, boolean isRollover)
	{
		g.setColor(Theme.tabLightColor[Theme.style].getColor());
		
		switch (tabPlacement) {
			case SwingConstants.LEFT :
				g.drawLine(x + 2, y, x + w - 1, y);
				g.drawLine(x + 1, y + 1, x + 1, y + 1);
				g.drawLine(x, y + 2, x, y + h - 3);
				
				g.setColor(Theme.tabDarkColor[Theme.style].getColor());
				g.drawLine(x + 2, y + h - 2, x + w - 1, y + h - 2);
				
				g.setColor(Theme.tabBorderColor[Theme.style].getColor());
				g.drawLine(x + 2, y + h - 1, x + w - 1, y + h - 1);
				g.drawLine(x + 1, y + h - 2, x + 1, y + h - 2);
				break;
			case SwingConstants.RIGHT :
				g.drawLine(x + w - 3, y, x, y);
				g.drawLine(x + w - 2, y + 1, x + w - 2, y + 1);
				g.drawLine(x + w - 1, y + 2, x + w - 1, y + h - 3);
				
				g.setColor(Theme.tabDarkColor[Theme.style].getColor());
				g.drawLine(x + w - 3, y + h - 2, x, y + h - 2);
				
				g.setColor(Theme.tabBorderColor[Theme.style].getColor());
				g.drawLine(x + w - 3, y + h - 1, x, y + h - 1);
				g.drawLine(x + w - 2, y + h - 2, x + w - 2, y + h - 2);
				break;
			case SwingConstants.BOTTOM :
				g.drawLine(x + 2, y + h - 1, x + w - 3, y + h - 1);
				g.drawLine(x, y + h - 3, x, y);
				g.drawLine(x + 1, y + h - 2, x + 1, y + h - 2);
			
				g.setColor(Theme.tabDarkColor[Theme.style].getColor());
				g.drawLine(x + w - 2, y + h - 3, x + w - 2, y);

				g.setColor(Theme.tabBorderColor[Theme.style].getColor());
				g.drawLine(x + w - 1, y + h - 3, x + w - 1, y);
				g.drawLine(x + w - 2, y + h - 2, x + w - 2, y + h - 2);
				break;
			case SwingConstants.TOP :
			default :
				g.drawLine(x + 2, y, x + w - 3, y);
				g.drawLine(x, y + 2, x, y + h - 1);
				g.drawLine(x + 1, y + 1, x + 1, y + 1);
			
				g.setColor(Theme.tabDarkColor[Theme.style].getColor());
				g.drawLine(x + w - 2, y + 2, x + w - 2, y + h - 1);

				g.setColor(Theme.tabBorderColor[Theme.style].getColor());
				g.drawLine(x + w - 1, y + 2, x + w - 1, y + h - 1);
				g.drawLine(x + w - 2, y + 1, x + w - 2, y + 1);
		}
	}
	
	private void drawXpTabBorder(Graphics g, int tabPlacement, int x, int y,
		int w, int h, boolean isSelected, boolean isEnabled, boolean isRollover)
	{
		if(!isEnabled) {
			DrawRoutines.drawXpTabBorder(
				g, Theme.tabBorderColor[Theme.style].getColor(), x, y, w, h, tabPlacement);    
		}
		else if(isSelected) {
			DrawRoutines.drawSelectedXpTabBorder(
				g, Theme.tabBorderColor[Theme.style].getColor(), x, y, w, h, tabPlacement);
		}
		else if(isRollover && Theme.tabRollover[Theme.style]) {
			DrawRoutines.drawSelectedXpTabBorder(
				g, Theme.tabBorderColor[Theme.style].getColor(), x, y, w, h, tabPlacement);
		}
		else {
			DrawRoutines.drawXpTabBorder(
				g, Theme.tabBorderColor[Theme.style].getColor(), x, y, w, h, tabPlacement);
		}
	}

	/**
	 * Paint the border and then call paint().
	 */
	public void update(Graphics g, JComponent c) {
		Insets insets = tabPane.getInsets();
		int x = insets.left;
		int y = insets.top;
		int w = tabPane.getWidth() - insets.right - insets.left;
		int h = tabPane.getHeight() - insets.top - insets.bottom;

		if (c.isOpaque()) {
			g.setColor(Theme.backColor[Theme.style].getColor());
			g.fillRect(0, 0, c.getWidth(), c.getHeight());
		}
		
		int tabPlacement = tabPane.getTabPlacement();
		switch (tabPlacement) {
			case LEFT :
				x += calculateTabAreaWidth(tabPlacement, runCount, maxTabWidth);
				w -= (x - insets.left);
				break;
			case RIGHT :
				w -= calculateTabAreaWidth(tabPlacement, runCount, maxTabWidth);
				break;
			case BOTTOM :
				h -= calculateTabAreaHeight(tabPlacement, runCount, maxTabHeight);
				break;
			case TOP :
			default :
				y += calculateTabAreaHeight(tabPlacement, runCount, maxTabHeight);
				h -= (y - insets.top);
		}
		
		switch(Theme.derivedStyle[Theme.style]) {
			case Theme.TINY_STYLE:
				drawTinyContentBorder(g, x, y, w, h);
				break;
			case Theme.WIN_STYLE:
				drawWinContentBorder(g, x, y, w, h);
				break;
			case Theme.XP_STYLE:
				drawXpContentBorder(g, x, y, w, h);
				break;
		}

		paint(g, c);		
	}
	
	private void drawTinyContentBorder(Graphics g, int x, int y, int w, int h) {
		
	}
	
	private void drawWinContentBorder(Graphics g, int x, int y, int w, int h) {
		g.setColor(Theme.tabPaneLightColor[Theme.style].getColor());
		g.drawLine(x + 1, y, x + w - 2, y); // top
		g.drawLine(x, y, x, y + h - 2); // left
				
		g.setColor(Theme.tabPaneDarkColor[Theme.style].getColor());
		g.drawLine(x + 1, y + h - 2, x + w - 2, y + h - 2); // bottom
		g.drawLine(x + w - 2, y + 1, x + w - 2, y + h - 2); // right	
		
		g.setColor(Theme.tabPaneBorderColor[Theme.style].getColor());
		g.drawLine(x, y + h - 1, x + w - 2, y + h - 1); // bottom
		g.drawLine(x + w - 1, y, x + w - 1, y + h - 1); // right	
	}
	
	private void drawXpContentBorder(Graphics g, int x, int y, int w, int h) {
		g.setColor(Theme.tabPaneBorderColor[Theme.style].getColor());
		g.drawRect(x, y, w - 3, h - 3);
		
		// Shadow
		g.setColor(ColorRoutines.darken(Theme.backColor[Theme.style].getColor(), 15));
		g.drawLine(x + w - 2, y + 1, x + w - 2, y + h - 2); // right
		g.drawLine(x + 1, y + h - 2, x + w - 3, y + h - 2); // bottom
	}
	
    protected int getTabLabelShiftX(int tabPlacement, int tabIndex, boolean isSelected) {
        Rectangle tabRect = rects[tabIndex];
        int nudge = 0;
        switch(tabPlacement) {
          case LEFT:
              nudge = isSelected? -1 : 1;
              break;
          case RIGHT:
              nudge = isSelected? 1 : -1;
              break;
          case BOTTOM:
          case TOP:
          default:
              nudge = 0;
        }
        return nudge;
    }

    protected int getTabLabelShiftY(int tabPlacement, int tabIndex, boolean isSelected) {
        Rectangle tabRect = rects[tabIndex];
        int nudge = 0;
        switch(tabPlacement) {
           case BOTTOM:
              nudge = isSelected? 1 : -1;
              break;
          case LEFT:
          case RIGHT:
              nudge = tabRect.height % 2;
              break;
          case TOP:
          default:
              nudge = isSelected? -1 : 1;
        }
        return nudge;
    }  	
}