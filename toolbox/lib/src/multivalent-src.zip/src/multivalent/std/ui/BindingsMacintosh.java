package multivalent.std.ui;

import java.awt.*;
import java.awt.event.*;
import java.awt.datatransfer.*;

import multivalent.*;


/**
	<i>Placeholder</i>
	Pluggable events duplicating some Macintosh key bindings.

	@see multivalent.std.ui.BindingsDefault
	@see multivalent.std.ui.BindingsTk

	@version $Revision$ $Date$
*/
public class BindingsMacintosh extends Behavior implements EventListener {
  public void buildAfter(Document doc) {
	doc.getRoot().addObserver(this);    // catch keys in tree
  }

  /**
	Where possible, convert into a standard key and let BindingsDefault catch it;
	for example, M-v => ACTION_PASTE.
  */
  public boolean eventAfter(AWTEvent e, Point rel, Node obsn) {
	int eid=e.getID();
	Browser br = getBrowser();
	//CursorMark cur = br.getCursorMark();

	if (eid==KeyEvent.KEY_PRESSED) {
		//if (siezed) br.setGrab(this);   // so get key up
	}
	return false;
  }

  public void event(AWTEvent e) {
	if (e.getID()==KeyEvent.KEY_RELEASED) getBrowser().releaseGrab(this);
  }
}
