/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	Tiny Look and Feel                                                         *
*                                                                              *
*  (C) Copyright 2003, Hans Bickel                                             *
*                                                                              *
*   For licensing information and credits, please refer to the                 *
*   comment in file de.muntjak.tinylookandfeel.TinyLookAndFeel                 *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package de.muntjak.tinylookandfeel;

import java.awt.*;
import javax.swing.*;
import javax.swing.plaf.*;
import javax.swing.plaf.basic.*;

import de.muntjak.tinylookandfeel.controlpanel.*;

/**
 * TinyTableHeaderUI
 * 
 * @version 1.0
 * @author Hans Bickel
 */
public class TinyTableHeaderUI extends BasicTableHeaderUI {
	
	JComponent header;
	
	public TinyTableHeaderUI() {
		super();
	}
	
	public TinyTableHeaderUI(JComponent header) {
		super();
		this.header = header;
	}
	
	public static ComponentUI createUI(JComponent header) {
		return new TinyTableHeaderUI(header);
	}
	
	protected void installDefaults() {
		super.installDefaults();
		
		if(!ControlPanel.isInstantiated) return;
		
		header.setForeground(Theme.tableHeaderFontColor[Theme.style].getColor());
		header.setBackground(Theme.tableHeaderBackColor[Theme.style].getColor());
	}
}
