package com.shfarr.ui.wizards;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import com.shfarr.ui.layouts.*;
import com.shfarr.ui.*;
import java.awt.event.*;
import java.awt.*;

/**
 * Insert the type's description here.
 * Creation date: (7/23/01 3:59:27 PM)
 * @author: 
 */
public abstract class AbstractWizard implements ActionListener, Wizard{
    public static final String[] BASIC_ACTIONS = {"Previous", "Next", "Cancel"};

    protected _WizardLabel messageArea = null;
    protected JPanel buttonSupport = null;
    protected JPanel workPanel = null;
    private int stepCount = 1;
    private int currentStep = 1;
    protected JButton[] buttons_ = null;

    protected Component[] editors = null;
    private JFrame frame = null;
    private JDialog dialog = null;

    protected Object userObject = null;
    protected Component caller = null;
    protected boolean busy = false;
    protected JOptionPane op = null;
    
    private boolean wasCentered = false;
    private boolean wasResized = false;
    private int width = 0;
    private int height = 0;
    
    /**
     * GenericWizard constructor comment.
     */
    public AbstractWizard(){
    }

    public AbstractWizard(int stepCount){
        this.stepCount = stepCount;
    }
    
    protected JButton[] getButtons(){
    	if(buttons_ == null) buttons_ = UIUtils.createSimpleButtonSet(BASIC_ACTIONS, this);
    	return buttons_;
    }
    
    protected JOptionPane getOptionArea(){
        if(op == null){
            // create optionPane for the maintainer

//            op = new JOptionPane(){
//                public Object[] getOptions(){
//                	if (AbstractWizard.this == null) return null;
//                	if (buttons_ == null) buttons_ = UIUtils.createSimpleButtonSet(BASIC_ACTIONS, AbstractWizard.this);
//                    return buttons_;
////                	return UIUtils.createSimpleButtonSet(BASIC_ACTIONS, AbstractWizard.this);
//                }
//                
//                public Color getBackground(){
//                    return UIManager.getColor("Wizard.background");
//                }
//            };
        	op = new AnOptionPane(getButtons());
            
            op.setBorder(new EmptyBorder(0, 0, 8, 0));
            op.setMessage(getWorkPanel());
            op.setIcon(null);
        }
        
        return op;
    }
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getActionCommand().equalsIgnoreCase("next")){
            if(currentStep == getStepCount()){
                if(commit()){
                    if (dialog != null) dialog.dispose();
                    if (frame != null) frame.dispose();
                    busy = false;
                }
            }
            else{
                nextStep();
                evaluateActions();
                evaluateCurrentStep();
            }
        }
        else if(ae.getActionCommand().equalsIgnoreCase("previous")){
            previousStep();
            evaluateActions();
            evaluateCurrentStep();
        }
        else if(ae.getActionCommand().equalsIgnoreCase("cancel")){
            rollBack();
            if (dialog != null) dialog.dispose();
            if (frame != null) frame.dispose();
            busy = false;
        }
    }

    protected abstract boolean commit();

    public void evaluateActions(){
        ((JButton[]) getOptionArea().getOptions())[0].setEnabled(false);
        ((JButton[]) getOptionArea().getOptions())[1].setEnabled(false);
        ((JButton[]) getOptionArea().getOptions())[2].setEnabled(true);

        ((JButton[]) getOptionArea().getOptions())[1].setText(getCurrentStep() == getStepCount() ? "Finish" : "Next");
        ((JButton[]) getOptionArea().getOptions())[1].setActionCommand("Next");
        
        try{
        	((JButton[]) getOptionArea().getOptions())[1].setIcon(new ImageIcon(ClassLoader.getSystemResource("cres/actions/" +
        			((JButton[]) getOptionArea().getOptions())[1].getText().toLowerCase() + ".png")));
        }
        catch (Exception e){
        }

        setForwardAllowed(getCurrentStep() <= getStepCount());
        setBackwardAllowed(getCurrentStep() > 1);

        if (width == 0 && height == 0) {
            if (dialog != null) getDialog().pack();
            if (frame != null) getFrame().pack();
        } else {
            if (!wasResized) {
                if (dialog != null) dialog.setSize(width, height);
                if (frame != null) frame.setSize(width, height);
                wasResized = !wasResized;
            }
        }
    }

    protected abstract void evaluateCurrentStep();

    /**
     * Insert the method's description here. Creation date: (7/23/01 4:17:48 PM)
     * 
     * @return int
     */
    public int getCurrentStep(){
        return currentStep;
    }

    protected JFrame getFrame() {
        if(frame == null){
            Window parent = null;
            frame = new JFrame("Wizard");
        }
            
        frame.setContentPane(new JPanel(new BorderLayout(6, 6)){
            public String getUIClassID(){
                return "WizardUI";
            }
        });

        ((JComponent)frame.getContentPane()).setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, frame.getContentPane().getBackground()));

        frame.getContentPane().add(getMessageArea(), "North");
        frame.getContentPane().add(getOptionArea(), "Center");
            

        frame.getRootPane().setDefaultButton(((JButton[]) getOptionArea().getOptions())[2]);

        return frame;
    }
    
    protected JDialog getDialog(){
        if(dialog == null){
            Window parent = null;
            if (caller != null) {
                parent = SwingUtilities.windowForComponent(caller);
                dialog = parent instanceof Frame ? new JDialog((Frame)parent, "Wizard", true) : new JDialog((Dialog)parent, "Wizard", true);
            } else {
                dialog = new JDialog();
                dialog.setTitle("Wizard");
                dialog.setModal(true);
            }
            
            dialog.setContentPane(new JPanel(new BorderLayout(6, 6)){
                    public String getUIClassID(){
                        return "WizardUI";
                    }
                });

            ((JComponent)dialog.getContentPane()).setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, dialog.getContentPane().getBackground()));

            dialog.getContentPane().add(getMessageArea(), "North");
            dialog.getContentPane().add(getOptionArea(), "Center");
            

            dialog.getRootPane().setDefaultButton(((JButton[]) getOptionArea().getOptions())[2]);
        }

        return dialog;
    }

    protected _WizardLabel getMessageArea(){
        if(messageArea == null){
            messageArea = new _WizardLabel();
        }
        return messageArea;
    }

    protected abstract Object getResult();

    /**
     * Insert the method's description here. Creation date: (7/23/01 4:17:24 PM)
     * 
     * @return int
     */
    public int getStepCount(){
        return stepCount;
    }
    
    public void setStepCount(int stepCount) {
        this.stepCount = stepCount;
    }
    
    public int getWindowWidth() {
        return width;
    }
    
    public void setWindowWidth(int width) {
        this.width = width;
    }
    
    public int getWindowHeight() {
        return height;
    }
    
    public void setWindowHeight(int height) {
        this.height = height;
    }

    protected JPanel getWorkPanel(){
        if(workPanel == null){
            workPanel = new JPanel(new QueueLayout(4, QueueLayout.VERTICAL, QueueLayout.STRECH_COMPONENTS));
            workPanel.setBorder(new EmptyBorder(0, 5, 0, 5));
            workPanel.setOpaque(false);
        }
        
        return workPanel;
    }

    public boolean isBusy(){
        return busy;
    }

    /**
     * launchWizard method comment.
     */
    public Object launchWizard(Object object, String message, Component caller){
        this.busy = true;

        this.dialog = null;
        this.currentStep = 1;
        reset();

        this.caller = caller;
        this.userObject = object;
        getMessageArea().setText(message);

        evaluateActions();
        evaluateCurrentStep();

        return getResult();
    }

    protected void nextStep(){
        currentStep++;
    }

    protected void previousStep(){
        currentStep--;
    }

    protected abstract void reset();

    protected abstract void rollBack();

    protected void setBackwardAllowed(boolean b){
    	((JButton[]) getOptionArea().getOptions())[0].setEnabled(b);
    }

    protected boolean isBackwardAllowed() {
    	return ((JButton[]) getOptionArea().getOptions())[0].isEnabled();
    }
    
    protected void setForwardAllowed(boolean b){
    	((JButton[]) getOptionArea().getOptions())[1].setEnabled(b);
    }
    
    protected boolean isForwardAllowed() {
    	return ((JButton[]) getOptionArea().getOptions())[1].isEnabled();
    }
    
    protected void centerDialog(){
        if (!wasCentered) {
            Component parentWindow = (caller != null) ? SwingUtilities.windowForComponent(caller) : null;
        
            if (parentWindow != null) {
                if (dialog != null) getDialog().setLocation((int)(parentWindow.getLocation().getX() +
                                                            (parentWindow.getWidth() -getDialog().getWidth())/2), 
                                                            (int)(parentWindow.getLocation().getY() +
                                                            (parentWindow.getHeight() -getDialog().getHeight())/2));
                if (frame != null) getFrame().setLocation((int)(parentWindow.getLocation().getX() +
                                                            (parentWindow.getWidth() -getFrame().getWidth())/2), 
                                                            (int)(parentWindow.getLocation().getY() +
                                                            (parentWindow.getHeight() -getFrame().getHeight())/2));
            } else {
                if (dialog != null) getDialog().setLocation(Toolkit.getDefaultToolkit().getScreenSize().width/2 - getDialog().getWidth()/2,
                                                            Toolkit.getDefaultToolkit().getScreenSize().height/2 - getDialog().getHeight()/2);
                if (frame != null) getFrame().setLocation(Toolkit.getDefaultToolkit().getScreenSize().width/2 - getFrame().getWidth()/2,
                                                            Toolkit.getDefaultToolkit().getScreenSize().height/2 - getFrame().getHeight()/2);
            }
            wasCentered = !wasCentered;
        }
    }

    protected static class AnOptionPane extends JOptionPane{
    	protected JButton[] buttons = null;

		public AnOptionPane(JButton[] buttons) {
			this.buttons = buttons;
		}
		
        public Object[] getOptions(){
            return buttons;
        }
        
        public Color getBackground(){
            return UIManager.getColor("Wizard.background");
        }
    }
}