package multivalent.std.adaptor;

import java.io.*;
import java.net.URI;
//import java.net.MalformedURLException;
import java.util.zip.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Enumeration;	// as of 1.3 zip doesn't use Iterator

import multivalent.*;
//import multivalent.std.adaptor.ArchiveMediaAdaptor;
import phelps.util.Units;
import phelps.util.Dates;



/**
	Media adaptor for Zip files.  Makes a table of contents, which a general behavior can sort.

	<p>To do:
	<ul>
	<li>option to save .zip to another location (already cached when reach here)
	<li>show contents in table, add links to within, update Cache to open zip's if necessary
	</ul>

	@version $Revision: 1.2 $ $Date: 2001/10/27 04:22:26 $
*/
public class Zip extends ArchiveMediaAdaptor {
  static final boolean DEBUG = false;

  //public void buildBefore(Document doc) {throw new java.lang.UnsupportedOperationException("Use the class java.util.ZipFile to parse");}
  public Object parse(INode parent) throws Exception {
	Document doc = parent.getDocument();
	URI uri = doc.getURI();

	//br.eventq(TableSort.MSG_ASCENDING, doc.findDFS("File")); -- retain natural order

	return parseHelper(toHTML(uri), "HTML", getLayer(), parent);
  }


  public String toHTML(URI uri) {
	String urifile = uri.getPath();
//System.out.println(uri+" / "+urifile);
	//File f;
	boolean localZip = "file".equals(uri.getScheme());	// can't see internals of .zip until round-robin DocInfo InputStream setting
	//localZip=true;
//if (localZip) System.out.println("*** "+new File(urifile)+"  vs  "+cache.mapTo(uri,null, Cache.COMPUTE));
	//if (localZip) f = new File(urifile); else f = cache.mapTo(uri, null, Cache.COMPUTE);
	Cache cache = getGlobal().getCache();
	File f = cache.mapTo(uri, null, Cache.COMPUTE);

	ZipFile zf; try { zf = new ZipFile(f); } catch (Exception e) { return "Can't make parse Zip: "+e; }


	//Document doc = new Document("ZIP",null, root);
	long now = System.currentTimeMillis();

	// make an HTML table -- make HTML table nodes public
	StringBuffer sb = new StringBuffer((int)f.length());

	sb.append("<html>\n<head>");
	sb.append("\t<title>").append("Contents of zip file ").append(urifile).append("</title>\n");
	sb.append("\t<base href='").append(uri).append("/'>\n");	// .zip as if directory!
	sb.append("</head>\n");
	sb.append("<body>\n");

	int filesi=sb.length(), filecnt=0;
	sb.append(" files, ");
	int sizei=sb.length(); long sizeun=0, sizec=0;
	//<h3>Contents of zip file ").append(urifile).append("</h3>\n"); => apparent in URI entry
	//zhsb.append("<p>").append(dirlist.length).append(" file"); if (dirlist.length!=1) hsb.append('s');
	sb.append("\n<table width='90%'>\n");

	// headers.  click to sort
	sb.append("<tr><span Behavior='ScriptSpan' script='event tableSort <node>'  title='Sort table'>");
	sb.append("<th align='left'>File / <b>Directory<th align='right'>Compressed<th align='right'>Size<th align='right'>Method<th align='right'>Last Modified</b></span>\n");

	// element list -- not necessarily sorted any particular way
	for (Enumeration e=zf.entries(); e.hasMoreElements(); ) {
		ZipEntry ze = (ZipEntry)e.nextElement();
		filecnt++;
		String name=ze.getName();	// should use casify, but only bad old MS-DOS would benefit
		//boolean isdir = ze.isDirectory();
//System.out.println(name+" "+ze.getTime()+" "+ze.getCompressedSize()+"/"+ze.getSize()+" "+ze.getExtra());

		sb.append("<tr>");
		// icon
		//hsb.append("<td><img src='systemresource:/images/").append(isDir?"file_dir":"file").append(".xbm'>");
		// filename and size
		if (ze.isDirectory()) {
			sb.append("<td><b>").append(name).append("</b></td>");
			sb.append("<td align='right'><span Behavior='ElideSpan'>0</span> --<td align='right'><span Behavior='ElideSpan'>0</span> --");
		} else {
			if (localZip) sb.append("<td><a href='").append(name).append("'>").append(name).append("</a>"); else sb.append("<td>").append(name);
			sb.append("<td align='right'>").append(Long.toString(ze.getCompressedSize())).append("<td align='right'>").append(Long.toString(ze.getSize()));
			sizec+=ze.getCompressedSize(); sizeun += ze.getSize();
		}
		// compression
		sb.append("<td align='right'>").append(ze.getMethod()==ZipEntry.DEFLATED?"deflated":"STORED");
		// last mod
		long lastmod = ze.getTime();
		sb.append("<td align='right'><span Behavior='ElideSpan'>").append(lastmod).append("</span> ").append(Dates.relative(lastmod, now));
		// comment
		if (ze.getComment()!=null) sb.append("<td>").append(ze.getComment());

		//ze.getComment(); ze.getSize(); ze.getCompressedSize(); ze.getMethod(); name; ze.getTime(); ze.getExtra();
	}
	sb.insert(sizei, Units.prettySize(sizec)+" / "+Units.prettySize(sizeun));
	sb.insert(filesi, filecnt);
	sb.append("</table>\n</body></html>\n");
	//new LeafAscii("ZIPPY",null, doc);
	try { zf.close(); } catch (IOException dontcare) {}

	return sb.toString();
  }


  protected String[] getPatterns() { String[] pat = { ".zip/", ".jar/" }; return pat; }

  public List<ArchiveFileEntry> getCatalog(File archive) throws IOException {
	List<ArchiveFileEntry> files = new ArrayList<ArchiveFileEntry>(500);
	ZipFile zf = new ZipFile(archive);
	for (Enumeration e=zf.entries(); e.hasMoreElements(); ) {
		ZipEntry ze = (ZipEntry)e.nextElement();
		//String zfname = ze.getName();
		files.add(new ArchiveFileEntry(ze.getName(), -1, null, ze.getSize(), ze.getCompressedSize(), -1, ze.getTime(), ze.getTime()));
	}
	return files;
  }


//	public InputStream getInputStream(File archive, String filename) throws IOException {
  public File extractFile(File archive, String filename, File outdir) throws IOException {
	File newfile = null;

	ZipFile zf = new ZipFile(archive);
//	Cache cache = getGlobal().getCache();
//	URI zipuri = zf.toURI();
	for (Enumeration e=zf.entries(); e.hasMoreElements(); ) {
		ZipEntry ze = (ZipEntry)e.nextElement();
		String zfname = ze.getName();
//System.out.println("*** comparing "+filename+" with "+ze.getName());
		if (filename==ALLFILES || filename.equals(zfname)) {
			int inx=zfname.lastIndexOf('/'); if (inx!=-1) zfname=zfname.substring(inx+1);
			newfile = new File(outdir, zfname);
			//newfile.getParentFile().mkdirs();
if (DEBUG) System.out.println("*** extract");
			InputStream in = new BufferedInputStream(zf.getInputStream(ze));	// buffered make any difference in this case?
if (DEBUG) System.out.println("*** in = "+in);
if (DEBUG) System.out.println("*** out = "+newfile);
			OutputStream out = new BufferedOutputStream(new FileOutputStream(newfile));
if (DEBUG) System.out.println("*** out = "+out);
			long len = phelps.io.Streams.copy(in, out);
if (DEBUG) System.out.println("*** "+len);
			out.close(); in.close();
			if (filename!=ALLFILES) break;
		}
	}
	zf.close();
	return newfile;
  }
}
