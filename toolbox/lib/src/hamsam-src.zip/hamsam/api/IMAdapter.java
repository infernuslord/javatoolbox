/*
 * Hamsam - Instant Messaging API
 * Copyright (C) 2003 Raghu K
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package hamsam.api;

import hamsam.protocol.Protocol;

import java.io.Serializable;
import java.util.Date;

/**
 * An abstract adapter class receiving instant messaging events.
 *
 * <p>
 * The class that is interested in processing an instant
 * messaging event either extends this class (overriding
 * only the methods of interest) or implements the
 * <code>IMListener</code> interface (and all the methods
 * it contains).
 *
 * <p>
 * The listener object created from that class is then registered with
 * the instant messaging framework using the
 * {@link hamsam.protocol.ProtocolManager#setIMListener(IMListener)
 * ProtocolManager.setIMListener(IMListener)} method.
 *
 * @author  Raghu
 * @see IMListener IMListener
 */
public abstract class IMAdapter implements IMListener, Serializable
{
	/**
	 * Default constructor.
	 */
	protected IMAdapter()
	{
	}

	/**
	 * Invoked when a protocol attempts start up.
	 *
	 * @param protocol the protocol which is starting up.
	 */
	public void connecting(Protocol protocol)
	{
	}

	/**
	 * Invoked when a protocol completes the start up successfully.
	 *
	 * @param protocol the protocol which was started up.
	 */
	public void connected(Protocol protocol)
	{
	}

	/**
	 * Invoked when a protocol failed during the start up.
	 *
	 * @param protocol the protocol which failed.
	 * @param reasonMessage the reason for the failure as a string.
	 */
	public void connectFailed(Protocol protocol, String reasonMessage)
	{
	}

	/**
	 * Invoked when a protocol is disconnected.
	 *
	 * @param protocol the protocol which is disconnected.
	 */
	public void disconnected(Protocol protocol)
	{
	}

	/**
	 * Invoked when a buddy wants to add you to his / her buddy list.
	 * The listener can decide whether to allow or disallow this
	 * request. The listener method overriding this method must return
	 * a <code>Response</code> object which describes whether the request
	 * was allowed or disallowed, and if it was disallowed, an explanation
	 * for that.
	 * <p>
	 * Not all protocols notify the user when somebody adds him / her to
	 * their buddy list. In that case this method will not be invoked.
	 * To check whether a protocol supports this, use
	 * {@link Protocol#isBuddyAddRequestSupported() Protocol.isBuddyAddRequestSupported()}
	 * method.
	 *
	 * @param buddy the buddy who is trying to add you.
	 * @param myself the buddy object corresponding to this user.
	 * @param message the message sent along with this request.
	 *
	 * @return the response for this request.
	 */
	public Response buddyAddRequest(Buddy buddy, Buddy myself, String message)
	{
		return new Response("");
	}

	/**
	 * Invoked when a buddy was successfully added to your buddy list.
	 *
	 * @param buddy the buddy who was added to your buddy list.
	 */
	public void buddyAdded(Buddy buddy)
	{
	}

	/**
	 * Invoked when an attempt to add a buddy failed because the buddy
	 * rejected your request.
	 *
	 * @param buddy the buddy whom you tried to add to your buddy list.
	 * @param reasonMessage the explanation provided by the buddy. If the
	 *                      buddy did not provide any explanation, this
	 *                      will be null.
	 */
	public void buddyAddRejected(Buddy buddy, String reasonMessage)
	{
	}

	/**
	 * Invoked when an attempt to add a buddy failed.
	 *
	 * @param buddy the buddy whom you tried to add to your buddy list.
	 * @param reasonMessage the reason for the failure as a string.
	 */
	public void buddyAddFailed(Buddy buddy, String reasonMessage)
	{
	}

	/**
	 * Invoked when a buddy was successfully deleted from your buddy list.
	 *
	 * @param buddy the buddy who was deleted from your buddy list.
	 */
	public void buddyDeleted(Buddy buddy)
	{
	}

	/**
	 * Invoked when an attempt to delete a buddy failed.
	 *
	 * @param buddy the buddy whom you tried to delete from your buddy list.
	 * @param reasonMessage the reason for the failure as a string.
	 */
	public void buddyDeleteFailed(Buddy buddy, String reasonMessage)
	{
	}

	/**
	 * Invoked when a buddy was successfully ignored. Ignored buddies cannot
	 * send messages to you.
	 * <p>
	 * Not all protocols support ignoring buddies. If a specific protocol
	 * does not support ignoring, this method will not be invoked. To
	 * identify whether this method is supported, use
	 * {@link Protocol#isIgnoreSupported() Protocol.isIgnoreSupported()}
	 * method.
	 *
	 * @param buddy the buddy who was ignored.
	 */
	public void buddyIgnored(Buddy buddy)
	{
	}

	/**
	 * Invoked when an attempt to ignore a buddy failed. Ignored buddies cannot
	 * send messages to you.
	 * <p>
	 * Not all protocols support ignoring buddies. If a specific protocol
	 * does not support ignoring, this method will not be invoked. To
	 * identify whether this method is supported, use
	 * {@link Protocol#isIgnoreSupported() Protocol.isIgnoreSupported()}
	 * method.
	 *
	 * @param buddy the buddy whom you tried to ignore.
	 * @param reasonMessage the reason for the failure as a string.
	 */
	public void buddyIgnoreFailed(Buddy buddy, String reasonMessage)
	{
	}

	/**
	 * Invoked when a buddy was successfully unignored. Unignoring a 
	 * previously ignored buddy permits him / her to send messages to you.
	 * <p>
	 * Not all protocols support ignoring buddies. If a specific protocol
	 * does not support ignoring, this method will not be invoked. To
	 * identify whether this method is supported, use
	 * {@link Protocol#isIgnoreSupported() Protocol.isIgnoreSupported()}
	 * method.
	 *
	 * @param buddy the buddy who was unignored.
	 */
	public void buddyUnignored(Buddy buddy)
	{
	}

	/**
	 * Invoked when an attempt to unignore a buddy failed. Unignoring a 
	 * previously ignored buddy permits him / her to send messages to you.
	 * <p>
	 * Not all protocols support ignoring buddies. If a specific protocol
	 * does not support ignoring, this method will not be invoked. To
	 * identify whether this method is supported, use
	 * {@link Protocol#isIgnoreSupported() Protocol.isIgnoreSupported()}
	 * method.
	 *
	 * @param buddy the buddy whom you tried to add to your buddy list.
	 * @param reasonMessage the reason for the failure as a string.
	 */
	public void buddyUnignoreFailed(Buddy buddy, String reasonMessage)
	{
	}

	/**
	 * Invoked when the status information of a buddy is changed. The
	 * new status can be accessed using the
	 * {@link Buddy#getStatus() getStatus()} method on the buddy
	 * object.
	 *
	 * @param buddy the buddy whose status information was changed.
	 */
	public void buddyStatusChanged(Buddy buddy)
	{
	}

	/**
	 * Invoked when an instant message is received.
	 *
	 * @param buddy the buddy who sent this message.
	 * @param message the message that was received.
	 */
	public void instantMessageReceived(Buddy buddy, Message message)
	{
	}

	/**
	 * Invoked when your buddy list is received after a successful login.
	 * If this method is not invoked, the listener can assume that the
	 * buddy list is empty.
	 *
	 * @param protocol the underlying protocol from which this notification
	 *                 was originated.
	 * @param buddies  the list of buddies.
	 */
	public void buddyListReceived(Protocol protocol, Buddy[] buddies)
	{
	}

	/**
	 * Invoked when a list of buddies whom you have ignored is received,
	 * after a successful login. If this method is not invoked, the listener
	 * can assume that the ignore list is empty.
	 * <p>
	 * Not all protocols support ignoring buddies. If a specific protocol
	 * does not support ignoring, this method will not be invoked. To
	 * identify whether this method is supported, use
	 * {@link Protocol#isIgnoreSupported() Protocol.isIgnoreSupported()}
	 * method.
	 *
	 * @param protocol the underlying protocol from which this notification
	 *                 was originated.
	 * @param buddies  the list of buddies who are in your ignore list.
	 */
	public void ignoreListReceived(Protocol protocol, Buddy[] buddies)
	{
	}

	/**
	 * Invoked when an offline message is received. Not all protocols
	 * support offline messages. If a specific protocol does not
	 * support offline messages, this method will not be invoked. To
	 * check whether a protocol supports offline messages or not,
	 * use the {@link Protocol#isOfflineMessageSupported() Protocol.isOfflineMessageSupported()}
	 * method.
	 *
	 * @param buddy the buddy who sent this message.
	 * @param time the time when this message was sent by the buddy.
	 * @param message the message that was received.
	 */
	public void offlineMessageReceived(Buddy buddy, Date time, Message message)
	{
	}

	/**
	 * Invoked when the underlying protocol system sends a notification to
	 * the user.
	 * 
	 * @param protocol the underlying protocol from which this notification
	 *                 was originated.
	 * @param message the message that was received.
	 */
	public void protocolMessageReceived(Protocol protocol, Message message)
	{
	}

	/**
	 * Invoked when a buddy starts typing. Not all protocols support
	 * typing notifications. If a specific protocol does not support
	 * typing notifications, this method will not be invoked. To check
	 * whether a protocol supports typing notifications or not, use
	 * {@link Protocol#isTypingNotifySupported() Protocol.isTypingNotifySupported()}
	 * method.
	 * 
	 * @param buddy the buddy who started typing.
	 */
	public void typingStarted(Buddy buddy)
	{
	}

	/**
	 * Invoked when a buddy stops typing. Not all protocols support
	 * typing notifications. If a specific protocol does not support
	 * typing notifications, this method will not be invoked. To check
	 * whether a protocol supports typing notifications or not, use
	 * {@link Protocol#isTypingNotifySupported() Protocol.isTypingNotifySupported()}
	 * method.
	 * 
	 * @param buddy the buddy who stopped typing.
	 */
	public void typingStopped(Buddy buddy)
	{
	}

	/**
	 * Invoked when a buddy invites you for a conference. The listener
	 * method overriding this method must return a <code>Response</code>
	 * object which describes whether the request was allowed or disallowed,
	 * and if it was disallowed, an explanation for that.
	 *
	 * <p>
	 * Not all protocols support conferences. If a specific protocol does not
	 * support conferences, this method will not be invoked. To check whether
	 * a protocol supports conferences or not, use
	 * {@link Protocol#isConferenceSupported() Protocol.isConferenceSupported()}
	 * method.
	 *
	 * @param conf     an object representing this conference.
	 * @param message  an invitation message from the host.
	 */
	public Response conferenceInvitationReceived(Conference conf, String message)
	{
		return new Response("");
	}

	/**
	 * Invoked when a buddy declines a conference invitation. Not all protocols
	 * support conferences. If a specific protocol does not support conferences,
	 * this method will not be invoked. To check whether a protocol supports
	 * conferences or not, use
	 * {@link Protocol#isConferenceSupported() Protocol.isConferenceSupported()}
	 * method.
	 *
	 * @param conf     an object representing this conference.
	 * @param buddy    the buddy who declined.
	 * @param message  a message from the buddy explaining why (s)he did not join.
	 */
	public void conferenceInvitationDeclined(Conference conf, Buddy buddy, String message)
	{
	}

	/**
	 * Invoked when a buddy accepts a conference invitation. This indicates that
	 * this buddy has joined the conference.
	 *
	 * <p>
	 * Not all protocols support conferences. If a specific protocol does not
	 * support conferences, this method will not be invoked. To check whether
	 * a protocol supports conferences or not, use
	 * {@link Protocol#isConferenceSupported() Protocol.isConferenceSupported()}
	 * method.
	 *
	 * @param conf     an object representing this conference.
	 * @param buddy    the buddy who accepeted the invitation.
	 */
	public void conferenceInvitationAccepted(Conference conf, Buddy buddy)
	{
	}

	/**
	 * Invoked when an instant message arrives at a conference. Not all protocols
	 * support conferences. If a specific protocol does not support conferences,
	 * this method will not be invoked. To check whether a protocol supports
	 * conferences or not, use
	 * {@link Protocol#isConferenceSupported() Protocol.isConferenceSupported()}
	 * method.
	 *
	 * @param conf     an object representing this conference.
	 * @param buddy    the buddy who sent this message.
	 * @param message  the instant message that was received.
	 */
	public void conferenceMessageReceived(Conference conf, Buddy buddy, Message message)
	{
	}

	/**
	 * Invoked when a buddy joins a conference. Not all protocols support conferences.
	 * If a specific protocol does not support conferences, this method will not be
	 * invoked. To check whether a protocol supports conferences or not, use
	 * {@link Protocol#isConferenceSupported() Protocol.isConferenceSupported()}
	 * method.
	 *
	 * @param conf     an object representing this conference.
	 * @param buddy    the buddy who joined the conference.
	 */
	public void conferenceParticipantJoined(Conference conf, Buddy buddy)
	{
	}

	/**
	 * Invoked when a buddy leaves from a conference. Not all protocols
	 * support conferences. If a specific protocol does not support conferences,
	 * this method will not be invoked. To check whether a protocol supports
	 * conferences or not, use
	 * {@link Protocol#isConferenceSupported() Protocol.isConferenceSupported()}
	 * method.
	 *
	 * @param conf     an object representing this conference.
	 * @param buddy    the buddy who left the conference.
	 */
	public void conferenceParticipantLeft(Conference conf, Buddy buddy)
	{
	}

	/**
	 * Invoked when an e-mail notification arrives. Many protcols have associated
	 * e-mail accounts. When an e-mail arrives in that account, a notification is
	 * sent. If a specific protocol does not support e-mail notifications, this
	 * method will not be invoked. To check wheter a protocol supports e-mail
	 * notifications, use {@link Protocol#isMailNotifySupported()
	 * Protocol.isMailNotifySupported()} method.
	 *
	 * <p>
	 * The parameter <code>count</code> specifies the number of mails. If this
	 * is -1, it means that the number of mails is not known. The parameter
	 * <code>from</code> is a list of e-mail addresseswho are the senders of each
	 * e-mail message, in order. The parameter <code>subject</code> is the
	 * subject line of each e-mail message, in order. Both these parameters can
	 * be null, indicating that the from addresses or subject lines are not
	 * known.
	 *
	 * @param protocol the underlying protocol from which this notification
	 *                 was originated.
	 * @param count    the number of e-mails received. If this is -1, the number
	 *                 of e-mails is not known.
	 * @param from     the senders' e-mail addresses. If this is null, the
	 *                 sender addresses are unknown.
	 * @param subject  the subject lines of the e-mails. If this is null, the
	 *                 subject lines are unknown.
	 */
	public void mailNotificationReceived(Protocol protocol, int count, String[] from, String[] subject)
	{
	}

	/**
	 * Invoked when a conference session is closed, either by the protocol or
	 * by a buddy who is authorized to do so. Who all can close a conference session
	 * is protocol dependant. 
	 *
	 * @param conf the conference that is closed.
	 */
	public void conferenceClosed(Conference conf)
	{
	}
}
