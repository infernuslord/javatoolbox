/*
 * 
 * Created on 2004-jul-25
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.renderer;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Rectangle;

import javax.swing.JTabbedPane;
import javax.swing.UIManager;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-25
 *
 */
public class TabRendererBottom extends AbstractRenderer {




	/**
	 * 
	 * 
	 */
	public TabRendererBottom( JTabbedPane tabPane ) {
		super( tabPane );
	}




	/**
	 * 
	 * 	 minimal decoration is really minimal: noFocus
	 * 
	 */
	public void paintFocusIndicator( Graphics g, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected) {}




	/**
	 * 
	 * 
	 */
	public Insets getContentBorderInsets( Insets defaultInsets ) {
		return SOUTH_INSETS;
	}




	/**
	 * 
	 * 
	 */
	public void paintTabBackground(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected) {
		if( isSelected ) {
			//g.setColor( new java.awt.Color( 158, 179, 193 ) );
			g.setColor( new java.awt.Color( 198, 209, 223 ) );  // TODO FIXED COLOR, BIG NONO!
		} else {
			g.setColor( UIManager.getColor("TabbedPane.background") );
		}

		g.fillRect(x, y, w + 1, h);
	}




	/**
	 * 
	 * 
	 */
	public void paintTabBorder(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected) {
		int bottom = h;
		int right = w + 1;

		g.setColor( Color.GRAY );  // TODO FIXED COLOR, BIG NONO!

		g.translate(x, y);
		if( isTabFirstDisplayed( tabIndex ) ) {
			if( isSelected ) {
				// selected and first in line
				g.fillRect(right, 0, 1, bottom);					// Right
				g.fillRect(0, 0, 1, bottom);						// Left
				g.fillRect(0, h-1, right, 1);							// Bottom
			} else {}
		} else {
			if( isSelected ) {
				//selected and not first in line
				g.fillRect(right, 0, 1, bottom);					// Right
				g.fillRect(0, 0, 1, bottom);						// Left
				g.fillRect(0, h-1, right, 1);							// Bottom
			} else {
				g.setColor( new java.awt.Color( 120, 120, 120 ) );  // TODO FIXED COLOR, BIG NONO!
				g.fillRect( 0, 4, 1, bottom - bottom / 2 );

			}
		}
		g.translate( -x, -y );
	}
}
