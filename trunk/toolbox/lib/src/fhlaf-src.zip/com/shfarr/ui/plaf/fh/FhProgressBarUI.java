/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh;

import javax.swing.*;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Rectangle;
import javax.swing.plaf.*;
import javax.swing.plaf.basic.BasicProgressBarUI;

import com.shfarr.ui.*;
import com.shfarr.ui.plaf.fh.textures.Texture;
import com.shfarr.ui.plaf.fh.theme.ThemeManager;


public class FhProgressBarUI extends BasicProgressBarUI{
    public static final BasicStroke fakeStroke = new BasicStroke(0f);
    
	/**
	 * FhSeparatorUI constructor comment.
	 */
	public FhProgressBarUI() {
		super();
	}
	
	
	public static ComponentUI createUI(JComponent c) {
	    return new FhProgressBarUI();
	}
	
	
	public void paint(Graphics g, JComponent c) {
        ThemeManager.instance().probeAntialiasing(g);

	  super.paint(g, c);

      Graphics2D g2D = (Graphics2D) g;
     
      Insets ins = progressBar.getBorder()!=null ? progressBar.getBorder().getBorderInsets(progressBar) : new Insets(0, 0, 0, 0);
      Dimension dim = progressBar.getSize();
 
 	  BoundedRangeModel model = progressBar.getModel();

      int amountFull = 0,
          lineSX = 0,
          lineEX = 0,
          lineSY = 0,
          lineEY = 0;
      
      Rectangle rectFilled = new Rectangle(),
                rectUnfilled = new Rectangle(),
                strippedBounds = new Rectangle(ins.left, ins.top, dim.width -ins.left -ins.right, dim.height -ins.top -ins.bottom);
     
      if((model.getMaximum() - model.getMinimum()) != 0){
         if(progressBar.getOrientation() == JProgressBar.HORIZONTAL) amountFull = (int)Math.round((dim.width -ins.left -ins.right)*progressBar.getPercentComplete());
         else amountFull = (int)Math.round((dim.height -ins.top -ins.bottom)*progressBar.getPercentComplete());
      }

	  Texture[] textures = {(Texture)UIManager.getDefaults().get("ProgressBar.uncompletedAreaTexture"),
	                        (Texture)UIManager.getDefaults().get("ProgressBar.completedAreaTexture"),
	                        (Texture)UIManager.getDefaults().get("ProgressBar.texture")
	                        };

      if(progressBar.getOrientation()==JProgressBar.HORIZONTAL){
         rectFilled.setBounds(ins.left, ins.top, amountFull, dim.height -ins.top -ins.bottom);
         rectUnfilled.setBounds(ins.left +amountFull, ins.top, dim.width -ins.left -ins.right -amountFull, dim.height -ins.top -ins.bottom);
         
         lineSX = ins.left +amountFull;
         lineSY = ins.top;
         lineEX = ins.left +amountFull;
         lineEY = dim.height -ins.bottom;
      }
      else{
           rectFilled.setBounds(ins.left, dim.height -ins.bottom -amountFull, dim.width -ins.left -ins.right, amountFull);
           rectUnfilled.setBounds(ins.left, ins.top, dim.width -ins.left -ins.right, dim.height -ins.bottom -amountFull);
           lineSX = ins.left;
           lineSY = dim.height -ins.bottom -amountFull;
           lineEX = dim.width -ins.right;
           lineEY = dim.height -ins.bottom -amountFull;
         
          if(ThemeManager.instance().probeSmallTextures()) for(int i=0; i < textures.length; i++) textures[i].rotate(Texture.ROTATE_90);
      }

      if(ThemeManager.instance().probeSmallTextures()){
    	  if(textures[0]!=null) textures[0].apply(rectUnfilled, g2D, c);
    	  if(textures[1]!=null) textures[1].apply(rectFilled, g2D, c);
    	  if(textures[2]!=null) textures[2].apply(strippedBounds, g2D, c);
      }
      
      g.setColor(new Color(GraphicsUtils.darker(progressBar.getForeground().getRGB(), 0.2f)));
      
      ((Graphics2D)g).setStroke(fakeStroke);

      g.drawLine(lineSX, lineSY, lineEX, lineEY);

      if(progressBar.getOrientation()==JProgressBar.VERTICAL){
          if(ThemeManager.instance().probeSmallTextures()) for(int i=0; i < textures.length; i++) textures[i].rotate(-Texture.ROTATE_90);
      }
    }
}
