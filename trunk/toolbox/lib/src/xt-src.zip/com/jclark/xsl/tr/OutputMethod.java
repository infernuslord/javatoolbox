// $Id: OutputMethod.java,v 1.1 2002/04/25 18:18:35 bill Exp $

package com.jclark.xsl.tr;

import com.jclark.xsl.om.*;

/**
 * collects the attributes on the xsl:stylesheet element
 * which determine the type of output we are to produce
 */
public interface OutputMethod
{
    Name getName();
    String getAttributeValue(Name name);
    Name[] getAttributeNames();
    Name[] getCdataSectionElements();
    NameTable getNameTable();
}
