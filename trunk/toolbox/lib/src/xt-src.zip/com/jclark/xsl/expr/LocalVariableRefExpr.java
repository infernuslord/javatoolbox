// $Id: LocalVariableRefExpr.java,v 1.1 2002/04/25 18:08:30 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

class LocalVariableRefExpr extends ConvertibleVariantExpr {
    private final Name name;

    LocalVariableRefExpr(Name name) {
        this.name = name;
    }

    public Variant eval(Node node, ExprContext context) throws XSLException {
        return context.getLocalVariableValue(name);
    }
}
