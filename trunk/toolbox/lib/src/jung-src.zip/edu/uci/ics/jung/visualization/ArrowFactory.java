/*
 * Created on Oct 19, 2004
 *
 * Copyright (c) 2004, the JUNG Project and the Regents of the University 
 * of California
 * All rights reserved.
 *
 * This software is open-source under the BSD license; see either
 * "license.txt" or
 * http://jung.sourceforge.net/license.txt for a description.
 */
package edu.uci.ics.jung.visualization;

import java.awt.geom.GeneralPath;

/**
 * 
 * @author Joshua O'Madadhain
 */
public class ArrowFactory
{
    public static GeneralPath getWedgeArrow(int width, int length)
    {
        GeneralPath arrow = new GeneralPath();
        arrow.moveTo(0,0);
        arrow.lineTo( - length, width/2.0f);
        arrow.lineTo( - length, -width/2.0f);
        arrow.lineTo( 0, 0 );
        return arrow;
    }

    public static GeneralPath getNotchedArrow(int width, int length, int notch_depth)
    {
        GeneralPath arrow = new GeneralPath();
        arrow.moveTo(0,0);
        arrow.lineTo(-length, width/2.0f);
        arrow.lineTo(-(length - notch_depth), 0);
        arrow.lineTo(-length, -width/2.0f);
        arrow.lineTo(0,0);
        return arrow;
    }
}
