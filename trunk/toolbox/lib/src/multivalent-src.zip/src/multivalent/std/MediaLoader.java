package multivalent.std;	// multivalent.std.adaptor ?

import java.io.File;
import java.io.InputStream;
import java.io.IOException;
import java.net.URI;
import java.util.Iterator;
import java.util.Map;

import com.pt.io.*;
import com.pt.net.MIME;

import multivalent.*;
import multivalent.node.LeafUnicode;



/**
	Load documents in a new thread so GUI and other documents are still live.
	Presently not in same thread, however.

	<!-- deprecated  Functionality to be split between {@link multivalent.Browser} and {@link multivalent.MediaAdaptor}. -->

	@version $Revision: 1.8 $ $Date: 2005/01/21 19:06:03 $
*/
public class MediaLoader extends Behavior /*implements Runnable*/ {
  DocInfo di_ = null;
  boolean stop_ = false;
  boolean loading_ = false;


  public void setDocInfo(DocInfo loadme) { di_=loadme; }

  /**
	When run in a thread, parse as usual (while checking asynchronous stop flag),
	then build with document-specific behaviors, finally call repaint() and send "fullformattedDocument" event.
  */
  //public void run() { load(); }

  public void load() { load(false); }
  public void load(boolean bootstrap) {
	DocInfo di = di_; if (di==null) return;

	Multivalent v = getGlobal();
	Document doc = di.doc;
/*
	Layer dsl = doc.getLayers();
	dsl.addBehavior(this);	// guard partial loads
	loading_ = true;
*/


	// 1. Get InputStream.  Cache computes genre from headers or guesses based or suffix.
//	basein = di.in; => maybe pass in DocInfo, and if null take from cache?
//System.out.println("ml uri="+di.uri);
	InputUni iu;
	URI uri = di.uri;
	String scheme = uri.getScheme();
	if ("file".equals(scheme) && !new File(uri.getPath()).exists()) {
		iu = new InputUniString("File Not Found "+uri, MIME.TYPE_TEXT_PLAIN, uri, null);
	} else {
		iu = InputUni.getInstance(uri, null, v.getCache());

		for (Iterator<Map.Entry<String,String>> i = di.headers.entrySet().iterator(); i.hasNext(); ) { Map.Entry<String,String> e = i.next(); iu.putAttr(e.getKey(), e.getValue()); }

	}/* catch (Exception e) {
		doc.clear();	// LATER: fail without zapping current page
		new LeafUnicode("Can't getInputStream() from cache for "+uri+": "+e,null, doc);
		e.printStackTrace();
		return;
	}*/

	if (stop_) { getLayer().removeBehavior(this); return; }	// stop after HTTP connect to preserve current
	if (di.genre!=null) iu.setContentType(di.genre);


	// 2. Instantiate media adaptor for genre
	uri = iu.getURI();//di.uri;	// may have received a redirect
	String genre = v.getGenre(iu.getContentType(), uri.getPath());
//System.out.println("*** genre = "+genre+", url="+uri+", Content-Type=|"+iu.getContentType()+"|");
	Browser br = getBrowser();
	//remove();	// remove self from system layers right after using hooks
	//if (!uri.isOpaque() && "".equals(uri.getPath())) uri = uri.resolve("/");    // URI.create("http://java.sun.com").resolve("relative/path.html") => "http://java.sun.comrelative/path.html" -- no "/" between "...com" and "relative"
	// (3) when good chance that it's going to work (made connection to InputStream, instantiated classes), kill old document and establish new
	loading_ = true;
	//doc.clear();	// removes this too.  problem if in middle of paint and remove all observers?
/*
	Document ndoc = new Document(doc.getName(),null, null);
	ndoc.bbox.setBounds(doc.bbox); ndoc.wcalc = doc.wcalc; ndoc.hcalc=doc.hcalc;
	INode p = doc.getParentNode();
	p.setChildAt(ndoc, doc.childNum());
	doc = ndoc;
	di.doc = doc;	// reset to replacement doc
	doc.clear();	// sets up br_
	//doc.remove();
*/
	doc.clear();

	doc.putAttr(Document.ATTR_GENRE, genre);
	//doc.putVar(Document.VAR_HEADERS, di.headers);
	doc.uri = uri;
	doc.putAttr(Document.ATTR_URI, uri.toString());	// make available to scripts -- null==reload
//System.out.println("ml "+uri+" => "+uri.getPath()+" in "+doc.hashCode());
	String title=uri.getPath(); int inx=title.lastIndexOf('/'); if (inx!=-1 && inx<title.length()-1) title=title.substring(inx+1);
	doc.putAttr(Document.ATTR_TITLE, title);	// default title

//System.out.println("br="+br+", layer="+this.getLayer()+", doc="+doc+", root="/*+doc.getRoot()*/);
	br.setCurDocument(doc);

	Layer dsl = doc.getLayers();
	dsl.addBehavior(this);	// guard partial loads
	//Layer baseLayer = (Layer)Behavior.getInstance(Layer.BASE,"Layer",null, dsl);
	Layer baseLayer = dsl.getInstance(Layer.BASE);
	MediaAdaptor base=null;
//System.out.println("*** Media loader making base for genre "+di.genre);
	try {
		base = (MediaAdaptor)Behavior.getInstance(genre,genre,null, baseLayer);
	} catch (ClassCastException cce) {
		new LeafUnicode(genre+": genre mapped to non-MediaAdaptor class",null, doc);
		//System.out.println("can't make base "+cce);
		//cce.printStackTrace();
		return;
	}

	// AS WELL in order to track changes in system's
	// user's can use DeleteBehaviors to zap system behaviors from this layer
	// ...

//System.out.println("MediaLoader: uri <= "+uri);
	doc.setMediaAdaptor(base);
	base.putAttr("uri", uri.toString());

	float zoom = 1;
	try { zoom = Float.parseFloat(Multivalent.getInstance().getPreference(genre+"-zoom", "1")); } catch (NumberFormatException nfe) {}
//System.out.println(genre+" => "+zoom);
	//X if (zoom==-1) zoom = /*java.awt.GraphicsEnvironment.isHeadless()=>not in MediaLoader? 1f:*/ java.awt.Toolkit.getDefaultToolkit().getScreenResolution() / 72f; => fonts in points (not pixels) so double zoom
	base.setZoom(zoom);

	// => send event
	//Layer genrelayer = Layer.getInstance/*br.loadLayer*/(/*base.! -- but how to link back to core hubs?*/getClass().getResource("/sys/hub/"+doc.getAttr(Document.ATTR_GENRE)+".hub"), /*Color.MAGENTA, /*true,*/ dsl);
//System.out.println("doc="+doc.getName()+", dsl.size="+dsl.size()+", root.getLayers().size()="+getRoot().getLayers().size());
	//Layer genrelayer =
//if (bootstrap) System.out.println("skip "+doc.getAttr(Document.ATTR_GENRE)+"?");
	//if (!bootstrap) dsl.getInstance(getClass().getResource("/sys/hub/"+doc.getAttr(Document.ATTR_GENRE)+".hub"));
	if (!bootstrap) dsl.getInstance(doc.getAttr(Document.ATTR_GENRE));
//System.out.println("hub = /sys/hub/"+doc.getAttr(Document.ATTR_GENRE)+".hub");


  /**
	BUILD
	Iterate through all behaviors, in high-to-low then low-to-high priority.
	(Note that can't be tree walk protocol, 'cause ain't no tree yet!
  */

	// (3) build doc tree
	doc.putAttr(Document.ATTR_LOADING, "loading");
//System.out.println(uri+" => "+basein);
	try {
		base.setInput(iu);
		//doc.removeAllChildren(); -- already done in clear
		/*if (!bootstrap)*/ br.event/*no q*/(new SemanticEvent(this, Document.MSG_BUILD, di));
//System.out.println("before ml dsl.buildBA");
//dsl.Verbose=true;
//dsl.dump();
		dsl.buildBeforeAfter(doc);
//dsl.Verbose=true;
//System.out.println("after ml dsl.buildBA");
	} catch (Exception e) {
		try { base.close(); } catch (IOException ioe) {}
		new LeafUnicode("COULDN'T RESTORE BASE "+e, null, doc);
		e.printStackTrace();
	}


	// finish up
	if (stop_) {
		doc.putAttr(Document.ATTR_STOP, "STOP"/*MediaAdaptor.DEFINED*/);
		// "Transfer interrupted" -- but in medium-specific way(?)
	} else {
		doc.removeAttr(Document.ATTR_LOADING);
		loading_ = false;
		//br.eventq(Document.MSG_OPENED, ci);
		/*if (!bootstrap)*/ br.event/*not q, now!*/(new SemanticEvent(this, Document.MSG_OPENED, di));
		br.setCurDocument(doc);
//System.out.println("repaint "+(bootstrap? 0: 100)+" doc.valid = "+doc.isValid()+", leaf = "+doc.getFirstLeaf()+" .. "+doc.getLastLeaf());
		//br.repaint(bootstrap? 0: 100);	//-- on different event queue?
if (bootstrap) System.out.println("* bootstrap -- repainting fullscreen");
		if (bootstrap) br.repaint();
		//br.eventq(Document.MSG_FORMATTED, ci);
	}
  }

  /** If didn't finish loading, don't save annotations.
  public boolean semanticEventBefore(SemanticEvent se, String msg) {
	/*if (("saveDocument"==msg || Document.MSG_CLOSE==msg) &&
	if (se.getArg()==getDocument() &&
	if (loading_) {
		return true;
	}* /
	if (super.semanticEventBefore(se,msg)) return true;
	else if (loading_ && Document.MSG_STOP!=msg && Document.MSG_CLOSE!=msg && se.getArg()==getDocument()) return true;
	//return loading_;
	return false;
  }

  /** Can stop loading immediately after HTTP connect to preserve current document. * /
  public boolean semanticEventAfter(SemanticEvent se, String msg) {
	if ((Document.MSG_STOP==msg || Document.MSG_CLOSE==msg) && se.getArg()==getDocument()) {
		stop_ = true;
	}
	return super.semanticEventAfter(se,msg);
  }
*/
/*
  public void run2() {	// => move to outtakes.java
//	vlayer_.clear();
	//sharedBe.clear();
	// reset globals_ completely?
	//putGlobal(Document.VAR_ANCHORS, new HashMap(10)); => moved to Document
	//availableColors_.clear(); for (int i=0,imax=annoColors_.length; i<imax; i++) availableColors_.add(annoColors_[i]);
//	  attr_.remove(Document.ATTR_GENRE);
//not yet	attr_.clear();	// document-specific attributes cleared, but not window settings in globals
	//attr_.remove(Fixed.ATTR_REFORMATTED);	// take out when attr_.clear() above

// moved into open()
	//URL uri = di.uri;
//	if (uri!=null) doc.putAttr("uri", uri.toString());	// make available to scripts -- null==reload

//System.out.println("protocol=|"+uri.getProtocol()+"|");
//	  if ("generate".equals(uri.getProtocol())) return;	// generate's aren't sent to restore()
//System.out.println("after protocol=|"+uri.getProtocol()+"|");

	// clean up
	//doc.removeAllChildren();
//	Layer dsl = doc.getLayers(); => done in load thread
//System.out.println("dsl = "+dsl.getName());
//	sharedLayer.clear();
//	scratchLayer.clear();


	// should just load SYSTEM once, reset() and reuse afterward
	/* <SYSTEM> first for base level function
	now load up system behaviors as defined by another hub, such as StandardFile StandardEdit, BindingsDefault
	=> personal pan-doc: and a personal, pan-document list, such as EmacsEvents, ...
	* /
	// system pan-document -- lowest priority -- should load only once for entire run, not once per document
	//if (systemLayer==null) systemLayer=
//		in = getClass().getResourceAsStream("/sys/hub/"+filename);
  //public Layer loadLayer(URL url, Color annocolor, boolean system) {

	//if (systemLayer==null) systemLayer=loadLayer(getClass().getResource("/sys/hub/System.mvd"), Color.CYAN, true);
	//else
	//systemLayer.restore(null,null,null);
	// ... all as different layers
	// ... so document hub minimal, just describing ways it differs


//***
	//Layer baseLayer = new Layer(Layer.BASE, this, Color.MAGENTA, true);
	Layer baseLayer = (Layer)Behavior.getInstance(Layer.BASE,"Layer",null, dsl);
	//sharedLayer = (Layer)Behavior.getInstance(Layer.SHARED,"Layer",null, syslayer_);	// clear behavior list
//System.out.println("baseLayer's group = "+baseLayer.getLayer()+", ==? "+(baseLayer.getLayer()==dsl));
	//addLayer(baseLayer);
	//pushLayer(baseLayer);
	//putGlobal("HOTSPOT", new HotSpotSpan(null,0, baseLayer));	// point to layer, but layer doesn't point back
//OK	putGlobal("HOTSPOT", new HotSpotSpan());	//null,0, baseLayer));	// point to layer, but layer doesn't point back
//	putGlobal("HOTSPOT", Behavior.getInstance("multivalent.Browser$HotSpotSpan", null, baseLayer));	// point to layer, but layer doesn't point back


	// (1) build ESIS tree of hub document

	// map to genre -- should use MIME typing as reported by server rather than deciding here

	String
	overridemsg = null;
	MediaAdaptor base=null;
	InputStream basein=null;
	//URLConnection urlc=null;	// available to try and catch

	//DocInfo di = new DocInfo(uri);
	Cache cache = getControl().getCache();
//	basein = di.in;

	try {
		// move HTTP connect() into load thread... but have to get genre, possibly from returned headers, before know type of behavior to instantiate!
		basein = cache.getInputStream(ci, null, Cache.COMPUTE);
	} catch (Exception e) {
		overridemsg = "RESTORE "+e.toString();
		//try { urlc.getInputStream().close(); } catch (Exception ignore) {}
		return;
	}

/* => moved to multivalent.std.adaptor.PersonalAnnos
	File oldhub = cache.mapTo(uri, "hub.mvd", Cache.USER);
System.out.println("checking old hub "+oldhub+" => "+oldhub.exists());
	if (oldhub.exists()) {
//	byte[] oldhub=null;
//	try { oldhub = cache.get(uri, "hub.mvd", Cache.USER); } catch (IOException nohub) {}
//	if (oldhub!=null) {
		// set base, basein
		try {
//System.out.println("from saved hub"); System.out.println(control_.getCache(uri));
			//base = (MediaAdaptor)Class.forName("multivalent.MultivalentAdaptor").newInstance();
			base = (MediaAdaptor)getBehaviorInstance("multivalent.MultivalentAdaptor",null,  dsl/*baseLayer* /);
//			basein = new StringBufferInputStream(new String(oldhub));
			basein = new FileInputStream(oldhub);
		} catch (Exception shouldnthappen) { System.out.println("problem loading old hub: "+shouldnthappen); }
	} else {* /
		URL uri = di.uri;	// may have received a redirect
		doc.putAttr(Document.ATTR_GENRE, di.genre);
System.out.println("*** genre = "+di.genre+", url="+di.uri);
		try { base = (MediaAdaptor)getBehaviorInstance(di.genre,null, baseLayer); } catch (ClassCastException cce) { overridemsg = "class not of type MediaAdaptor"; return; }
	//}
//System.out.println("*** "+getURI().toString()+" => ");
//System.out.println("\t"+Cache.mapURL(getURI(), null, Cache.ARCHIVE));


	// return code 200, we have liftoff

	//if (basein!=null) {
	//base.restore(null, null, baseLayer); -- done in getBehaviorInstance now
	//base.addToLayer();

	// validate URL of data -- may not be any data
	base.uri = uri;
	base.putAttr("uri", uri.toString());
	doc.putGlobal("headers", di.headers);

	// LATER: check for hubs in user space
	Layer genrelayer = loadLayer(getClass().getResource("/sys/hub/"+doc.getAttr(Document.ATTR_GENRE)+".hub"), Color.MAGENTA, true, dsl);

	// (2) load document in separate thread, which as final step builds with document-specific behaviors

	// (2) build doc tree
	base.setInputStream(basein);
	try {
/* => in Thread
System.out.println("base = "+base.getClass().getName()+", basein="+basein);
		//base.restore(basein);
		// kinda kludgey

		dsl.buildBeforeAfter(doc);

		//basein.close(); =>
		base.closeInputStream();
* /
System.out.println("base = "+base.getClass().getName()+", basein="+basein);
		//base.restore(basein);
		// kinda kludgey

		new Thread(base).start();
		//dsl.buildBeforeAfter(doc); => in Thread

		//basein.close(); =>
		//base.closeInputStream();
	} catch (Exception e) {
		//basein.close();
		overridemsg = "COULDN'T RESTORE BASE "+e.toString();
			//if (overridemsg!=null) //{
		//new LeafUnicode(overridemsg, null, docroot_);
		new LeafUnicode(overridemsg, null, doc);

		return;
	} //finally { basein.close();--throws Exception of its own }

//	  try { uri = new URL(base.getAttr("uri")); } catch (Exception badbase) {}
	//}

	//popLayer();	// BASE



	// personal pan-document -- highest priority (or hub?) => pp-d is copied+modified system hub
	/*
	Layer personalLayer = getLayer(Layer.PERSONAL);
	if (personalLayer==null) {
System.out.println("*** creating new Personal layer");
		personalLayer = new Layer(Layer.PERSONAL, this, getAnnoColor(), false);
	}*/


	// should just GENRE if GENRE has changed, otherwise reset() and reuse afterward
	// genre template -- should load only entering new genre
	/*
	String att;
	if ((att=getAttr(Document.ATTR_GENRE))!=null) {
		if (genreLayer==null || !att.equalsIgnoreCase(genreName)) {
			genreName = att;
			genreLayer = loadLayer(getClass().getResource("/sys/hub/"+att+".hub"), Color.ORANGE, true);
		} else /*if (genreLayer!=null)* / {
			genreLayer.restore(null,null,null);
		}
	}

	setCurrentLayer(personalLayer);	// add personal annotation as expected interation as much as browsing itself
* /

	// do a join on threads before returning (and moving on to build phase)
	// just iterate over them.	have to have all, so doesn't matter what order they complete

	// no return value, but as side effect accumulated list of restored behaviors

	// parse root (proot) thrown away now.	individual behaviors can keep handles to it if interested
//	if (prof) { profs[RESTORECNT]++; profs[RESTORETIME] += System.currentTimeMillis()-timein; }
  }
*/
}
