package phelps.lang;



/**
	Extensions to {@link java.lang.Byte}.

	@version $Revision$ $Date$
*/
public class Bytes {
  public static final byte[] ARRAY0 = new byte[0];

  private Bytes() {}
}
