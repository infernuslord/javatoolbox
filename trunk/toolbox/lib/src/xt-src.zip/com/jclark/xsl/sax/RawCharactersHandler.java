// $Id: RawCharactersHandler.java,v 1.1 2002/04/25 18:16:06 bill Exp $

package com.jclark.xsl.sax;

public interface RawCharactersHandler 
{
    void rawCharacters(String chars) throws org.xml.sax.SAXException;
}
