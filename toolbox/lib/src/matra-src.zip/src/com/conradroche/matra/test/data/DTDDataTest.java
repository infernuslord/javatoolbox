/*
 *   The contents of this file are subject to the Mozilla Public License
 *   Version 1.1 (the "License"); you may not use this file except in
 *   compliance with the License. You may obtain a copy of the License at
 *   http://www.mozilla.org/MPL/
 *
 *   Software distributed under the License is distributed on an "AS IS"
 *   basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 *   License for the specific language governing rights and limitations
 *   under the License.
 *
 *   The Original Code is Matra - the DTD Parser.
 *
 *   The Initial Developer of the Original Code is Conrad S Roche.
 *   Portions created by Conrad S Roche are Copyright (C) Conrad 
 *   S Roche. All Rights Reserved.
 *
 *   Alternatively, the contents of this file may be used under the terms
 *   of the GNU GENERAL PUBLIC LICENSE Version 2 or any later version
 *   (the  "[GPL] License"), in which case the
 *   provisions of GPL License are applicable instead of those
 *   above.  If you wish to allow use of your version of this file only
 *   under the terms of the GPL License and not to allow others to use
 *   your version of this file under the MPL, indicate your decision by
 *   deleting  the provisions above and replace  them with the notice and
 *   other provisions required by the GPL License.  If you do not delete
 *   the provisions above, a recipient may use your version of this file
 *   under either the MPL or the GPL License."
 *
 *   [NOTE: The text of this Exhibit A may differ slightly from the text of
 *   the notices in the Source Code files of the Original Code. You should
 *   use the text of this Exhibit A rather than the text found in the
 *   Original Code Source Code for Your Modifications.]
 *
 * Created: Conrad S Roche <derupe at users.sourceforge.net>,  09-Aug-2003
 */
package com.conradroche.matra.test.data;

import java.util.ArrayList;

import com.conradroche.matra.data.DTDData;
import com.conradroche.matra.test.util.DataValues;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * JUnit test to test the functionality of
 * the class DTDData.
 *
 * @author Conrad Roche
 */
public class DTDDataTest extends ParseableDataTest {

	/**
	 * The DTDData object being tested.
	 */
	private DTDData dData;
	
	/**
	 * DTDData object containing null String value.
	 */
	private DTDData nullData;
	
//	private String DTDString = "";

	private ArrayList includeSectPrefix;
	private ArrayList ignoreSectPrefix;
	private static final String condSectSuffix = "]]>";
	
	private static final String[] nmTokens = DataValues.getInstance().getNmTokenValues();
	
	private static final String[] names = DataValues.getInstance().getNameValues();

	/**
	 * Constructor for DTDDataTest.
	 * @param arg0
	 */
	public DTDDataTest(String arg0) {
		super(arg0);
	}

	/**
	 * Returns a test suite with DTDDataTest.
	 * 
	 * @see com.conradroche.matra.test.data.DataTest#suite()
	 * 
	 * @return
	 */
	public static Test suite() {

		TestSuite suite = new TestSuite();

		suite.addTestSuite(DTDDataTest.class);

		return suite;
	}

	/**
	 * Setup the data for testing.
	 */
	protected void setUp() {
		super.setUp();
		data = new DTDData(strData);
		dData = (DTDData) data;
		nullData = new DTDData(null);
	}

	/**
	 * Build various permutations of the conditional
	 * section prefix.
	 */
	private void buildSectPrefixes() {
//		[62] includeSect ::= '<![' S? 'INCLUDE' S? '[' extSubsetDecl ']]>'
//		[63] ignoreSect ::= '<![' S? 'IGNORE' S? '[' ignoreSectContents* ']]>'

		final String[] S = DataValues.getInstance().getSValues();
		final String condSectPrefix = "<![";
		
		includeSectPrefix = new ArrayList();
		ignoreSectPrefix = new ArrayList();
		 
		for(int i = 0; i < S.length; i++) {
			for(int j = 0; j < S.length; j++) {
				includeSectPrefix.add(condSectPrefix + S[i] + "INCLUDE"+ S[j] + "["); //'<![' S? 'INCLUDE' S? '['
				ignoreSectPrefix.add(condSectPrefix + S[i] + "IGNORE"+ S[j] + "["); //'<![' S? 'IGNORE' S? '['
			}
		}
	}
	
	/**
	 * Test a simple non-nested conditional section.
	 * 
	 * @param data The data to be kept in the conditional section.
	 */
	private void simpleReadConditionalSect(String data) {

		//INCLUDEs followed by INCLUDEs with the same data between them 
		StringBuffer sb = new StringBuffer("");
		for(int i = 0; i < includeSectPrefix.size(); i++) {
			//includeSect
			sb.append((String) includeSectPrefix.get(i))
				.append(data)
				.append(condSectSuffix);
		}
		
		//IGNOREs followed by IGNOREs with the same data between them 
		for(int i = 0; i < ignoreSectPrefix.size(); i++) {
			//ignoreSect
			sb.append((String) ignoreSectPrefix.get(i))
				.append(data)
				.append(condSectSuffix);
		}
		
		dData = new DTDData(sb.toString()); //includeSect* ignoreSect*
		
		DTDData condSect;
		
		//read and validate the INCLUDEs
		for(int i = 0; i < includeSectPrefix.size(); i++) {
			dData.skipChars(2); //'<!'
			condSect = dData.readConditionalSect();
			Assert.assertEquals(((String) includeSectPrefix.get(i)).substring(2) + data + condSectSuffix, 
						condSect.toString());
		}
		
		//read and validate the IGNOREs
		for(int i = 0; i < ignoreSectPrefix.size(); i++) {
			dData.skipChars(2); //'<!'
			condSect = dData.readConditionalSect();
			Assert.assertEquals(((String) ignoreSectPrefix.get(i)).substring(2) + data + condSectSuffix, 
						condSect.toString());
		}
	}
	
	/**
	 * Test nested conditional section with the specified
	 * conditional section prefixes.
	 *  
	 * @param sectPrefix The condtional section prefixes to be used.
	 * @param data The data to be kept within the sections.
	 */
	private void nestedSectTest(ArrayList sectPrefix, String data) {
		
		//nested INCLUDEs/IGNOREs with data only in the innermost section
		StringBuffer sb = new StringBuffer("");
		
		for(int i = 0; i < sectPrefix.size(); i++) {
			sb.append((String) sectPrefix.get(i));
		}
		
		sb.append(data);
		
		for(int i = 0; i < sectPrefix.size(); i++) {
			sb.append(condSectSuffix);
		}
		dData = new DTDData(sb.toString());

		dData.skipChars(2); //'<!'
		DTDData condSect = dData.readConditionalSect();
		for(int i = 0; i < sectPrefix.size() - 1; i++) {
			condSect.skipChars(((String) sectPrefix.get(i)).length()); //'[' S? 'INCLUDE' S? '[' '<!'
			condSect = condSect.readConditionalSect();
			//too complex to assert the value for each instance
		}
		Assert.assertEquals(
			((String) sectPrefix.get(sectPrefix.size() - 1)).substring(2) + 
			data + condSectSuffix, condSect.toString());
	}
	
	/**
	 * Test the  DTDData::readConditionalSect() method
	 */
	public void testReadConditionalSect() {
//		[62] includeSect ::= '<![' S? 'INCLUDE' S? '[' extSubsetDecl ']]>'
//		[63] ignoreSect ::= '<![' S? 'IGNORE' S? '[' ignoreSectContents* ']]>'
		

		buildSectPrefixes();
		
		String data = "<!-- this is the data within the various sections -->\n";
		String dtdData = "<!-- this is the data within the various sections -->\n" +
						 "<!ENTITY % content \"d+, e+\">\n<!ELEMENT c (%content;)>\n" +
						 "<!ELEMENT d EMPTY>\n<!ELEMENT e EMPTY>";
		
		//test the simple case
		simpleReadConditionalSect(data);
		simpleReadConditionalSect(dtdData);
		
		//simple case with no data in it.
		simpleReadConditionalSect("");
		
		//simple case with blank data in it.
		simpleReadConditionalSect(" \t\n");

		//read nested sections
		
		//nested INCLUDEs with data only in the innermost section
		nestedSectTest(includeSectPrefix, data);
		nestedSectTest(includeSectPrefix, dtdData);
		nestedSectTest(includeSectPrefix, "");
		nestedSectTest(includeSectPrefix, " \n\t");
		
		//nested IGNOREs with data only in the innermost section
		nestedSectTest(ignoreSectPrefix, data);
		nestedSectTest(ignoreSectPrefix, dtdData);
		nestedSectTest(ignoreSectPrefix, "");
		nestedSectTest(ignoreSectPrefix, "\n \t");
		
		//nested INCLUDEs and IGNOREs with data only in the innermost section
		StringBuffer sb = new StringBuffer("");
		for(int i = 0; i < ignoreSectPrefix.size(); i++) {
			sb.append((String) includeSectPrefix.get(i));
			sb.append((String) ignoreSectPrefix.get(i));
		}
		sb.append(data);
		for(int i = 0; i < ignoreSectPrefix.size(); i++) {
			sb.append(condSectSuffix); //close the ignore
			sb.append(condSectSuffix); //close the include
		}
		dData = new DTDData(sb.toString());

		DTDData condSect = dData;
		condSect.skipChars(2); // '<!'
		for(int i = 0; i < ignoreSectPrefix.size(); i++) {
			condSect = condSect.readConditionalSect(); //read the include
			condSect.skipChars(((String) includeSectPrefix.get(i)).length()); //'[' S? 'INCLUDE' S? '[' '<!'
			condSect = condSect.readConditionalSect(); //read the ignore
			condSect.skipChars(((String) ignoreSectPrefix.get(i)).length()); //'[' S? 'IGNORE' S? '[' '<!'
			//too complex to assert the value for each instance
		}
		Assert.assertEquals(
			((String) ignoreSectPrefix.get(ignoreSectPrefix.size() - 1)).substring(2) + 
			data + condSectSuffix, condSect.toString());
	}

	/**
	 * Create a DTDData with the tokens specified - 
	 * each delimted by space chars.
	 * 
	 * @param tokens The toekns using which to build the DTDData object.
	 */
	private void loadTokens(String[] tokens) {
		
		StringBuffer sb = new StringBuffer("");				 
		for(int i = 0; i < tokens.length; i++) {
			sb.append(tokens[i]).append("\t\n\r ");
		}
		dData = new DTDData(sb.toString());
	}
	
	/**
	 * Test the  DTDData::getNextNmToken() method
	 */
	public void testGetNextNmToken() {
		//[4]    NameChar    ::=    Letter | Digit | '.' | '-' | '_' | ':' | CombiningChar | Extender 
		//[7]    Nmtoken    ::=    (NameChar)+ 

		loadTokens(nmTokens);
		for(int i = 0; i < nmTokens.length; i++) {
			Assert.assertEquals(nmTokens[i], dData.getNextNmToken());
			dData.skipWhiteSpace();
		}
		
		//CR: TODO: Check with unicode chars too after adding support for unicode

		//blank data
		dData.reset();
		Assert.assertNull(dData.getNextNmToken());
		
		//null Data
		Assert.assertNull(nullData.getNextNmToken());
		
		//invalid Data
		dData = new DTDData("([])");
		Assert.assertNull(dData.getNextNmToken());

		//beginning with spaces		
		dData = new DTDData("  nmtoken");
		Assert.assertNull(dData.getNextNmToken());
	}

	/**
	 * Test the  DTDData::getNextNmTokens() method
	 */
	public void testGetNextNmTokens() {
		//[4]    NameChar    ::=    Letter | Digit | '.' | '-' | '_' | ':' | CombiningChar | Extender 
		//[7]    Nmtoken    ::=    (NameChar)+ 
		//[8]    Nmtokens    ::=    Nmtoken (S Nmtoken)*  

		loadTokens(nmTokens);

		String[] tokens = dData.getNextNmTokens();
		
		for(int i = 0; i < nmTokens.length; i++) {
			Assert.assertEquals(nmTokens[i], tokens[i]);		
		}
		
		//blank data
		dData.reset();
		Assert.assertNull(dData.getNextNmTokens());
		
		//null Data
		Assert.assertNull(nullData.getNextNmTokens());
		
		//invalid Data
		dData = new DTDData("([])");
		Assert.assertNull(dData.getNextNmTokens());

		//beginning with spaces		
		dData = new DTDData("  nmtoken");
		Assert.assertNull(dData.getNextNmTokens());
	}

	/**
	 * Test the  DTDData::getNextName() method
	 */
	public void testGetNextName() {
		//[4]    NameChar    ::=    Letter | Digit | '.' | '-' | '_' | ':' | CombiningChar | Extender 
		//[5]    Name    ::=    (Letter | '_' | ':') (NameChar)* 
		
		loadTokens(names);

		for(int i = 0; i < names.length; i++) {
			Assert.assertEquals(names[i], dData.getNextName());
			dData.skipWhiteSpace();
		}
		
		//CR: TODO: Check with unicode chars too after adding support for unicode

		//blank data
		dData.reset();
		Assert.assertNull(dData.getNextName());
		
		//null Data
		Assert.assertNull(nullData.getNextName());
		
		//Invalid data
		dData = new DTDData("123");
		Assert.assertNull(dData.getNextName());
		
		//beginning with spaces		
		dData = new DTDData("  name");
		Assert.assertNull(dData.getNextName());
	}

	/**
	 * Test the  DTDData::getNextNames() method
	 */
	public void testGetNextNames() {
		//[4]    NameChar    ::=    Letter | Digit | '.' | '-' | '_' | ':' | CombiningChar | Extender 
		//[5]    Name    ::=    (Letter | '_' | ':') (NameChar)* 
		//[6]    Names    ::=    Name (S Name)* 

		loadTokens(names);

		String[] tokens = dData.getNextNames();
		
		for(int i = 0; i < names.length; i++) {
			Assert.assertEquals(names[i], tokens[i]);		
		}
		
		//blank data
		dData.reset();
		Assert.assertNull(dData.getNextNames());
		
		//null Data
		Assert.assertNull(nullData.getNextNames());
		
		//invalid Data
		dData = new DTDData("([])");
		Assert.assertNull(dData.getNextNames());
		
		//beginning with spaces		
		dData = new DTDData("  name");
		Assert.assertNull(dData.getNextNames());
	}
}
