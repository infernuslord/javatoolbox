/*
 * Copyright (c) 2003, the JUNG Project and the Regents of the University of
 * California All rights reserved.
 * 
 * This software is open-source under the BSD license; see either "license.txt"
 * or http://jung.sourceforge.net/license.txt for a description.
 */
package edu.uci.ics.jung.graph.impl;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import edu.uci.ics.jung.exceptions.FatalException;
import edu.uci.ics.jung.graph.ArchetypeEdge;
import edu.uci.ics.jung.graph.ArchetypeVertex;
import edu.uci.ics.jung.graph.Edge;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.graph.predicates.*;
import edu.uci.ics.jung.graph.predicates.EdgePredicate;
import edu.uci.ics.jung.graph.predicates.NotInGraphEdgePredicate;
import edu.uci.ics.jung.graph.predicates.NotInGraphVertexPredicate;
import edu.uci.ics.jung.utils.Pair;
import edu.uci.ics.jung.utils.PredicateUtils;

/**
 * This class provides a skeletal implementation of the <code>Graph</code>
 * interface to minimize the effort required to implement this interface. This
 * graph implementation stores vertices and edges in Sets. It is appropriate
 * for sparse graphs (those in which each vertex has only a few neighbors). For
 * dense graphs (those in which each vertex is connected to most other
 * vertices), a different implementation (for example, one which represents a
 * graph via a matrix) may be more appropriate.
 * 
 * <P>Currently, the addition and removal methods will notify their arguments that
 * they have been added to or removed from this graph only if they are
 * instances of <code>AbstractSparseVertex</code> or <code>AbstractSparseEdge</code>.</p>
 * 
 * <P>This class extends <code>UserData</code>, which provides storage and
 * retrieval mechanisms for user-defined data for each graph instance. This
 * allows users to attach data to graphs without having to extend this class.</p>
 * 
 * <p>Constraints imposed by this class:
 * <ul>
 * <li/><b>system</b> (invisible, unmodifiable) constraints: 
 * <code>NotInGraphVertexPredicate</code>, <code>NotInGraphEdgePredicate</code>
 * <li/><b>user</b> (visible, modifiable via <code>getEdgeConstraints</code>): none
 * </ul></p>

 * @author Scott D. White
 * @author Danyel Fisher
 * @author Joshua O'Madadhain
 */
public abstract class AbstractSparseGraph
	extends AbstractArchetypeGraph
	implements Graph, Cloneable {

    /**
     * The set of vertices registered with the graph.
     */
    protected Set mVertices;

    /**
     * The set of edges registered with the graph.
     */
    protected Set mEdges;

    /**
	 * ID -> Vertex lookup table.
	 */
	protected Map mVertexIDs;

	/**
	 * ID -> Edge lookup table.
	 */
	protected Map mEdgeIDs;


	//------------------------- CONSTRUCTION -----------------

	/**
	 * Creates an instance of a sparse graph. Invokes <code>initialize()</code>
	 * to set up the local data structures.
	 * 
	 * @see #initialize()
	 */
	public AbstractSparseGraph() {
        super();
	}

    protected void initialize()
    {
        super.initialize();
        mVertices = new HashSet();
        mEdges = new HashSet();
        EdgePredicate ep = new NotInGraphEdgePredicate(this);
        edge_requirements.add( ep );
//        system_edge_requirements.add(ep);
        ep.isInitializationPredicate = true;
        VertexPredicate vp = new NotInGraphVertexPredicate(this);
        vertex_requirements.add( vp );
//        system_vertex_requirements.add(vp);
        vp.isInitializationPredicate = true;
        mVertexIDs = new HashMap();
        mEdgeIDs = new HashMap();
    }

    /**
     * Returns an unmodifiable set view of the vertices in this graph. Will
     * reflect changes made to the graph after the view is generated.
     * 
     * @see ArchetypeGraph#getVertices()
     * @see java.util.Collections#unmodifiableSet(java.util.Set)
     */
    public Set getVertices() {
        return Collections.unmodifiableSet(mVertices);
    }

    /**
     * Returns an unmodifiable set view of the edges in this graph. Will
     * reflect changes made to the graph after the view is generated.
     * 
     * @see ArchetypeGraph#getEdges()
     * @see java.util.Collections#unmodifiableSet(java.util.Set)
     */
    public Set getEdges() {
        return Collections.unmodifiableSet(mEdges);
    }



	// --------------------------- ADDERS

    /**
     * @see edu.uci.ics.jung.graph.Graph#addEdge(edu.uci.ics.jung.graph.Edge)
     */
    public Edge addEdge(Edge e)
    {
        // needs to happen before ase.addGraph_internal() so
        // that test for e.getGraph() will be valid
//        validateEdge(e);
        validate(e, edge_requirements);
        
        if (e instanceof AbstractSparseEdge) 
        {
            AbstractSparseEdge ase = (AbstractSparseEdge) e;
            Integer newIndex = new Integer(ase.getID());
            if (mEdgeIDs.containsKey(newIndex))
                throw new IllegalArgumentException("An equivalent edge already exists in this graph");
            mEdgeIDs.put(newIndex, ase);
            ase.addGraph_internal(this);
        }
        mEdges.add(e);
        mGraphListenerHandler.handleAdd( e );
        return e;
    }

    /**
     * 
     * @see edu.uci.ics.jung.graph.Graph#addVertex(edu.uci.ics.jung.graph.Vertex)
     */
    public Vertex addVertex(Vertex v) 
    {
        // needs to happen before asv.addGraph_internal() so
        // that test for v.getGraph() will be valid
//        validateVertex(v);
        validate(v, vertex_requirements);
        
        if (v instanceof AbstractSparseVertex) 
        {
            AbstractSparseVertex asv = (AbstractSparseVertex) v;
            Integer newIndex = new Integer(asv.getID());
            // this is not subsumed by the contains() check done in the
            // validation step, because contains depends on equals() ->
            // getEquivalentVertex() -> getGraph()...which returns null 
            // because asv.addGraph_internal has not yet been called.
            // So this really is the only way we can tell, at this point
            // in the method, whether there's an equivalent vertex.
            if (mVertexIDs.get(newIndex) != null)
                throw new IllegalArgumentException("An equivalent vertex already exists in this graph");
            mVertexIDs.put(newIndex, asv);
            asv.addGraph_internal(this);
        }
        mVertices.add(v);
        mGraphListenerHandler.handleAdd( v );
        return v;
    }


	// ---------------------------- ACCESSORS ---------------------------


	/**
	 * Returns the vertex associated with the specified ID, or null if there is
	 * no such vertex. Not intended for user access.
	 */
	ArchetypeVertex getVertexByID(int id) {
		return (ArchetypeVertex) mVertexIDs.get(new Integer(id));
	}

	/**
	 * Returns the vertex associated with the specified ID, or null if there is
	 * no such vertex. Not intended for user access.
	 */
	ArchetypeEdge getEdgeByID(int id) {
		return (ArchetypeEdge) mEdgeIDs.get(new Integer(id));
	}


	/**
	 * Removes all edges adjacent to the specified vertex, removes the vertex,
	 * and notifies the vertex that it has been removed. <b>Note</b>: the
	 * vertex will not be notified unless it is an instance of <code>AbstractSparseVertex</code>.
	 */
	public void removeVertex(Vertex v) {
		removeEdges(v.getIncidentEdges());
		mVertices.remove(v);
		if (v instanceof AbstractSparseVertex) {
			AbstractSparseVertex asv = (AbstractSparseVertex) v;
			asv.removeGraph_internal();
			mVertexIDs.remove(new Integer(asv.getID()));
		}
		mGraphListenerHandler.handleRemove( v );
	}

	/**
	 * Removes the edge from the graph, and notifies that the edge and its
	 * incident vertices that it has been removed. <b>Note</b>: the edge
	 * will not be notified unless it is an instance of <code>AbstractSparseEdge</code>,
	 * and the incident vertices will not be notified unless they are instances
	 * of <code>AbstractSparseVertex</code>.
	 */
	public void removeEdge(Edge e) {
		if (e.getGraph() != this)
			throw new IllegalArgumentException("This edge is not in this graph");
		if (!mEdges.contains(e)) {
			throw new IllegalArgumentException("Internal error: edge not registered in this graph");
		}

		Pair endpoints = e.getEndpoints();
		Vertex from = (Vertex) endpoints.getFirst();
		Vertex to = (Vertex) endpoints.getSecond();

		if ((from.getNeighbors().contains(to))
			&& (to.getNeighbors().contains(from))) {
			if (from instanceof AbstractSparseVertex)
				((AbstractSparseVertex) from).removeNeighbor_internal(e, to);
			if (to instanceof AbstractSparseVertex)
				((AbstractSparseVertex) to).removeNeighbor_internal(e, from);
		} else {
			throw new FatalException(
				"Internal error: neighborhood relation "
					+ "between "
					+ from
					+ " and "
					+ to
					+ " is not symmetric");
		}

		if (e instanceof AbstractSparseEdge) {
			AbstractSparseEdge ase = (AbstractSparseEdge) e;
			ase.removeGraph_internal();
			mEdgeIDs.remove(new Integer(ase.getID()));
		}

		mEdges.remove(e);
		mGraphListenerHandler.handleRemove( e );
	}

	/**
	 * Removes all vertices in the specified set from this graph. Syntactic
	 * sugar for a loop that calls <code>removeVertex</code> on all elements
	 * of the set.
	 * 
	 * @see ArchetypeGraph#removeVertices(java.util.Set)
	 */
	public void removeVertices(Set vertices) {
		for (Iterator iter = new HashSet(vertices).iterator();
			iter.hasNext();
			) {
			Vertex v = (Vertex) iter.next();
			removeVertex(v);
		}
	}

	/**
	 * Removes all edges in the specified set from this graph. Syntactic sugar
	 * for a loop that calls <code>removeEdge</code> on all elements of the
	 * set.
	 * 
	 * @see ArchetypeGraph#removeEdges(java.util.Set)
	 */
	public void removeEdges(Set edges) {
		for (Iterator iter = new HashSet(edges).iterator(); iter.hasNext();) {
			Edge e = (Edge) iter.next();
			removeEdge(e);
		}
	}

	/**
	 * Removes all vertices (and, therefore, all edges) from this graph.
	 * Syntactic sugar for a loop that calls <code>removeVertex</code> on all
	 * vertices of this graph.
	 * 
	 * @see ArchetypeGraph#removeAllVertices()
	 */
	public void removeAllVertices() {
		removeVertices(new HashSet(getVertices()));
	}

	/**
	 * Removes all edges from this graph. Syntactic sugar for a loop that calls
	 * <code>removeEdge</code> on all edges of this graph.
	 * 
	 * @see ArchetypeGraph#removeAllEdges()
	 */
	public void removeAllEdges() {
		for (Iterator iter = new HashSet(mEdges).iterator(); iter.hasNext();) {
			Edge e = (Edge) iter.next();
			removeEdge(e);
		}
	}
    
    /**
     * @see Graph#isDirected()
     * @deprecated As of version 1.4, the semantics of this method have 
     * changed; it no longer returns a boolean value that is hardwired into 
     * the class definition, but checks to see whether one of the 
     * requirements of this graph is that it only accepts directed edges.
     * 
     */
    public boolean isDirected()
    {
        return PredicateUtils.enforcesDirected(this);
    }

}
