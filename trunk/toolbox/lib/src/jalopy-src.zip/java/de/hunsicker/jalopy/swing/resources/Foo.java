//---------------------------------------------------------------------------
// Filename:        $Source:  $
// Revision:        $Revision: $
// Last edited by:  $Author:  $ on $Date:  $
// � James Richardson International Limited, 2005
//---------------------------------------------------------------------------
package de.hunsicker.jalopy.swing.resources;
// ====================================================================
//
// The Rochester Group
// 600 Park Ave
// Rochester, NY 14607
// Copyright 2005
//
// ====================================================================


/**
 * DOCUMENT ME!
 *
 * @author
 * @version
 */
public class Foo
{
  /**
   * DOCUMENT ME!
  public void bar ()
  {
    System.err.println("Stuff2");

    for (int i = 0, j = 10; i < 10; i++, j *= 2)
    {
      this.baz("stuff" + "dlkjaskjldsalkjdsalkj" + " /" + "daskjkdsalk",
        "dsajalskdjsak" + "jdsakldakdsalkj " + "dskjsdlkdjkdsa \" djjkdaslds",
        this + "doiaodsadl");
    }
  }
   */

  /**
   * DOCUMENT ME!
   *
   * @param o1 DOCUMENT ME!
   * @param o2 DOCUMENT ME!
   * @param o3 DOCUMENT ME!
   */
  public void baz (Object o1, Object o2, Object o3)
  {
  }
}


// ====================================================================
// $Id: trg.xml,v 1.2 2005/10/07 18:15:00 jsunday Exp $
// ====================================================================
