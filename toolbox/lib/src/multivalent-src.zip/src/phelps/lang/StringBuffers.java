package phelps.lang;



/**
	Extensions to {@link java.lang.StringBuffer}, which is <code>final</code>.

	<ul>
	<li>
	<li>translate/convert/format:
		{@link #getBytes(StringBuffer)} without character set encoding,
		{@link #valueOf(byte[])}
	</ul>

	@version $Revision: 1.1 $ $Date: 2003/05/10 01:52:54 $
*/
public class StringBuffers {
  /** Converts from StringBuffer to byte[].  Java's String.getBytes() changes bytes vis-a-vis an encoding. */
  public static byte[] getBytes(StringBuffer sb) {
	assert sb!=null;
	byte[] b = new byte[sb.length()];
	for (int i=0,imax=sb.length(); i<imax; i++) b[i] = (byte)sb.charAt(i); //& 0xff);
	return b;
  }

  /** Converts from byte[] to StringBuffer.  Java's String.getBytes() changes bytes vis-a-vis an encoding. */
  public static StringBuffer valueOf(byte[] b) {
	assert b!=null;
	StringBuffer sb = new StringBuffer(b.length);
	for (int i=0,imax=b.length; i<imax; i++) sb.append((char)(b[i] & 0xff));
	return sb;
  }
}
