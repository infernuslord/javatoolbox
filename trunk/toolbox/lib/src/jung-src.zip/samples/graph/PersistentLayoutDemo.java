package samples.graph;

import java.awt.BorderLayout;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.Collections;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.graph.impl.DirectedSparseEdge;
import edu.uci.ics.jung.graph.impl.DirectedSparseGraph;
import edu.uci.ics.jung.graph.impl.DirectedSparseVertex;
import edu.uci.ics.jung.visualization.GraphDraw;
import edu.uci.ics.jung.visualization.Layout;
import edu.uci.ics.jung.visualization.SpringLayout;
import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.contrib.PersistentLayout;
import edu.uci.ics.jung.visualization.contrib.PersistentLayoutImpl;

/**
 * Demonstrates the use of: <p>
 * <ul>
 * <li>PersistentLayout
 * <li>PersistentLayoutImpl
 * </ul>
 * This demo also shows ToolTips on graph vertices.
 * 
 * @author Tom Nelson - RABA Technologies
 * 
 */
public class PersistentLayoutDemo {

    /**
     * the graph
     */
    Graph graph;

    /**
     * the name of the file where the layout is saved
     */
    String fileName;

    /**
     * the visual component of the graph visualization viewer
     */
    GraphDraw gd;

    /**
     * the visual component and renderer for the graph
     */
    VisualizationViewer vv;

    /**
     * create an instance of a simple graph with controls to
     * demo the persistence and zoom features.
     * 
     * @param fileName where to save/restore the graph positions
     */
    public PersistentLayoutDemo(final String fileName) {
        this.fileName = fileName;
        
        // create a simple graph for the demo
        graph = new DirectedSparseGraph();
        Vertex[] v = createVertices(10);
        createEdges(v);
        gd = new GraphDraw(graph);

        // the PersistentLayout delegates to another GraphLayout until you
        // perform a 'restore' 
        final PersistentLayout layout = new PersistentLayoutImpl(new SpringLayout(
                graph));
        gd.setGraphLayout(layout);
        
        vv = gd.getVisualizationViewer();
        
        // add my listener for ToolTips
        vv.setToolTipListener(new VertexListener(gd, 5.0));
        
        // turn on antialiasing
        vv.setRenderingHints(Collections.singletonMap(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON));

        // create a frome to hold the graph
        final JFrame frame = new JFrame();
        frame.getContentPane().add(gd);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // create a control panel and buttons for demo
        // functions
        JPanel p = new JPanel();
        
        JButton persist = new JButton("Save Layout");
        // saves the graph vertex positions to a file
        persist.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                PersistentLayout pl = (PersistentLayout) gd.getGraphLayout();
                try {
                    pl.persist(fileName);
                } catch (IOException e1) {
                    System.err.println("got "+e1);
                }
            }
        });
        p.add(persist);

        JButton restore = new JButton("Restore Layout");
        // restores the graph vertex positions from a file
        // if new vertices were added since the last 'persist',
        // they will be placed at random locations
        restore.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                PersistentLayout pl = (PersistentLayout) gd.getGraphLayout();
                try {
                    pl.restore(fileName);
                    gd.repaint();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });
        p.add(restore);

        frame.getContentPane().add(p, BorderLayout.SOUTH);
        frame.setSize(600, 600);
        frame.show();
    }

    /**
     * create some vertices
     * @param count how many to create
     * @return the Vertices in an array
     */
    private Vertex[] createVertices(int count) {
        Vertex[] v = new Vertex[count];
        for (int i = 0; i < count; i++) {
            v[i] = graph.addVertex(new DirectedSparseVertex());
        }
        return v;
    }

    /**
     * create edges for this demo graph
     * @param v an array of Vertices to connect
     */
    void createEdges(Vertex[] v) {
        graph.addEdge(new DirectedSparseEdge(v[0], v[1]));
        graph.addEdge(new DirectedSparseEdge(v[2], v[3]));
        graph.addEdge(new DirectedSparseEdge(v[0], v[4]));
        graph.addEdge(new DirectedSparseEdge(v[4], v[5]));
        graph.addEdge(new DirectedSparseEdge(v[3], v[9]));
        graph.addEdge(new DirectedSparseEdge(v[6], v[2]));
        graph.addEdge(new DirectedSparseEdge(v[7], v[1]));
        graph.addEdge(new DirectedSparseEdge(v[8], v[2]));
        graph.addEdge(new DirectedSparseEdge(v[3], v[8]));
        graph.addEdge(new DirectedSparseEdge(v[6], v[7]));
        graph.addEdge(new DirectedSparseEdge(v[7], v[5]));
        graph.addEdge(new DirectedSparseEdge(v[0], v[9]));
    }

    /**
     * A nested class to demo ToolTips
     */
    static class VertexListener implements VisualizationViewer.ToolTipListener {
        
        /**
         * how close to the vertex in order to fire the tooltip
         */
        double proximity;

        /**
         * the visual component holding the graph's rendering engine
         */
        GraphDraw gd;

        /**
         * create an instance with passed parameters
         * @param gd the GraphDraw for this graph
         * @param proximity how close to the vertex
         */
        public VertexListener(GraphDraw gd, double proximity) {
            this.gd = gd;
            this.proximity = proximity;
        }

        /**
         * Evaluate the mouse event position and prepare a ToolTip
         * for the Vertex that is within 'proximity' of the event.
         * @param event the MouseEvent where the mouse pointer is dwelling
         */
        public String getToolTipText(MouseEvent event) {
            Layout layout = gd.getGraphLayout();
            VisualizationViewer vv = gd.getVisualizationViewer();
            double scalex = vv.getScaleX();
            double scaley = vv.getScaleY();
            double offsetx = vv.getOffsetX();
            double offsety = vv.getOffsetY();
            Vertex v = layout.getVertex(event.getX()/scalex+offsetx, event.getY()/scaley+offsety, proximity);
            if (v != null) {
                return "tool tip for " + v;
            } else {
                return null;
            }
        }
    }

    /**
     * a driver for this demo
     * @param args should hold the filename for the persistence demo
     */
    public static void main(String[] args) 
    {
        String filename;
        if (args.length >= 1)
            filename = args[0];
        else
            filename = "PersistentLayoutAndZoomDemoLayout.out";
        new PersistentLayoutDemo(filename);
    }
}

