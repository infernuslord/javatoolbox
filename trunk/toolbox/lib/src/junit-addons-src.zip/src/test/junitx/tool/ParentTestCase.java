package junitx.tool;

import junit.framework.TestCase;

/**
 * @version $Revision: 1.1 $ $Date: 2002/09/22 22:19:34 $
 * @author <a href="mailto:benoitx@users.sourceforge.net">Benoit Xhenseval</a>
 */
public class ParentTestCase
        extends TestCase {

    public ParentTestCase(String name) {
        super(name);
    }

    public void atestMistake() {
    }

}
