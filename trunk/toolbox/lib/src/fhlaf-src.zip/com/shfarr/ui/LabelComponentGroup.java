/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui;

import javax.swing.*;
import java.awt.*;
import com.shfarr.ui.layouts.*;


public class LabelComponentGroup extends JPanel{
	public static final int LEFT = 0;
	public static final int RIGHT = 1;
	public static final int TOP = 2;
	public static final int BOTTOM = 3;
	
	
	/**
	 * LabelEditorGroup constructor comment.
	 */
	public LabelComponentGroup(String[] names, Component[] components, int orientation){
	  super(orientation < 2 ? (LayoutManager)new FlexibleGridLayout(names.length, 2, 4, 4) : (LayoutManager)new QueueLayout(4, QueueLayout.VERTICAL, QueueLayout.STRECH_COMPONENTS));
	  
      setOpaque(false);
      
      int maxWidth = 0;
      
      JLabel[] labels = new JLabel[names.length];
      
	  for(int i=0; i < names.length; i++){
		  labels[i] = new JLabel(names[i]);
          labels[i].setOpaque(false);
	
		  switch(orientation){
		         case   LEFT : labels[i].setHorizontalTextPosition(JLabel.RIGHT);
		                       labels[i].setHorizontalAlignment(JLabel.RIGHT);
		                       labels[i].setVerticalTextPosition(JLabel.CENTER);
							   break;
	
		         case    TOP : labels[i].setHorizontalTextPosition(JLabel.LEFT);
		                       labels[i].setVerticalTextPosition(JLabel.BOTTOM);
		                       break;
	
		         case BOTTOM : labels[i].setHorizontalTextPosition(JLabel.RIGHT);
		                       labels[i].setHorizontalAlignment(JLabel.LEFT);
		                       labels[i].setVerticalTextPosition(JLabel.TOP);
		                       break;
	
		         case  RIGHT : labels[i].setHorizontalTextPosition(JLabel.LEFT);
		                       labels[i].setVerticalTextPosition(JLabel.CENTER);
		                       break;
		  }
	
	      add(orientation%2 == 0 ? labels[i] : components[i]);
	      add(orientation%2 == 0 ? components[i] : labels[i]);
          
          maxWidth = Math.max(maxWidth, labels[i].getPreferredSize().width); 
	  }
      
      for(int i=0; i < names.length; i++) labels[i].setPreferredSize(new Dimension(maxWidth, labels[i].getPreferredSize().height));
	}
}
