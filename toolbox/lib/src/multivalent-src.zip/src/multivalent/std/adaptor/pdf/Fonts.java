package multivalent.std.adaptor.pdf;

import java.awt.Font;
import java.awt.FontFormatException;
import java.io.InputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.regex.*;

import static multivalent.std.adaptor.pdf.COS.*;
import phelps.awt.NFont;
import static phelps.awt.NFont.*;
import phelps.awt.font.*;
import phelps.io.InputStreams;
import phelps.util.Arrayss;



/**
	Font creation, from PDF description to {@link phelps.awt.NFont}.

	@version $Revision: 1.30 $ $Date: 2004/02/07 03:16:55 $
*/
public class Fonts {
  static final boolean DEBUG = !false && multivalent.Multivalent.DEVEL;

  private static final String[] CORE14 = {
	"Times-Roman", "Times-Bold", "Times-Italic", "Times-BoldItalic",
	"Helvetica", "Helvetica-Bold", "Helvetica-Oblique",  "Helvetica-BoldOblique",
	"Courier", "Courier-Bold", "Courier-Oblique", "Courier-BoldOblique",
	"Symbol",
	"ZapfDingbats"
  };
  static { Arrays.sort(CORE14); }

  private static final String[][] EQ_ = {	// PDF Reference 1.4, p.795.  ordered to increasing specialization.  position 0 hold canonical name.
	{ "Times-Roman",  /*unofficial:*/"Times", /*unofficial:*/"Times New Roman","TimesNewRoman",  "TimesNewRomanPS",  "TimesNewRomanPSMT" }, 
	{ "Times-Bold",  "TimesNewRoman,Bold","TimesNewRoman-Bold",  "TimesNewRomanPS-Bold",  "TimesNewRomanPS-BoldMT" },
	{ "Times-Italic", "TimesNewRoman,Italic","TimesNewRoman-Italic",  "TimesNewRomanPS-Italic",  "TimesNewRomanPS-ItalicMT" },
	{ "Times-BoldItalic",  "TimesNewRoman,BoldItalic","TimesNewRoman-BoldItalic",  "TimesNewRomanPS-BoldItalic",  "TimesNewRomanPS-BoldItalicMT" },
	{ "Helvetica",  "Arial",  "ArialMT" },
	{ "Helvetica-Bold","Helvetica,Bold",  "Arial,Bold","Arial-Bold",  "Arial-BoldMT" },
	{ "Helvetica-Oblique", "Helvetica,Italic","Helvetica-Italic",  "Arial,Italic","Arial-Italic",  "Arial-ItalicMT" },
	{ "Helvetica-BoldOblique", "Helvetica,BoldItalic","Helvetica-BoldItalic",  "Arial,BoldItalic","Arial-BoldItalic",  "Arial-BoldItalicMT" },
	{ "Courier",  "CourierNew",  "CourierNewPSMT" },
	{ "Courier-Bold","Courier,Bold",  "CourierNew,Bold","CourierNew-Bold",  "CourierNewPS-BoldMT" },
	{ "Courier-Oblique",  "Courier,Italic", "CourierNew-Italic","CourierNew,Italic",  "CourierNewPS-ItalicMT" },
	{ "Courier-BoldOblique", "Courier,BoldItalic",  "CourierNew-BoldItalic","CourierNew,BoldItalic",  "CourierNewPS-BoldItalicMT" },
	{ "Symbol" }, 
	{ "ZapfDingbats", /*unofficial:*/"Zapf-Dingbats", /*unofficial (URW)*/"Dingbats", /*OS X "ZapfDingbatsITC matched by NFontManger's fuzzy",*/ /*"NOT Monotype Sorts", NOT "Wingdings" -- different characters*/ }
  };

  /** Map named CMap to Unicode mapping.  */
  private static final String[][] TOUNICODE = {
	// format: <canonical> <map1> <map2> ...
	// Chinese (Simplified)
	{ "GBpc-EUC-UCS2",/*"GBpc-EUC-UCS2C",*/  "GBpc-EUC-H", "GBpc-EUC-V" },
	{ "GBK-EUC-UCS2",  "GBK-EUC-H", "GBK-EUC-V" },
	{ "UniGB-UCS2-H",  "GB-EUC-H", "GBT-EUC-H", "GBK2K-H", "GBKp-EUC-H" },
	{ "UniGB-UCS2-V",  "GB-EUC-V", "GBT-EUC-V", "GBK2K-V", "GBKp-EUC-V" },

	// Chinese (Traditional)
	{ "B5pc-UCS2",/*"B5pc-UCS2C",*/  "B5pc-H", "B5pc-V" },
	{ "ETen-B5-UCS2",  "ETen-B5-H", "ETen-B5-V", "ETenms-B5-H", "ETenms-B5-V" },
	{ "UniCNS-UCS2-H",  "HKscs-B5-H", "CNS-EUC-H" },
	{ "UniCNS-UCS2-V",  "HKscs-B5-V", "CNS-EUC-V" },

	// Japanese
	{ "90pv-RKSJ-UCS2",/*"90pv-RKSJ-UCS2C",*/  "90pv-RKSJ-H", "83pv-RKSJ-H" },
	{ "90ms-RKSJ-UCS2",  "90ms-RKSJ-H", "90ms-RKSJ-V", "90msp-RKSJ-H", "90msp-RKSJ-V" },
	{ "UniJIS-UCS2-H",  "Ext-RKSJ-H", "H", "Add-RKSJ-H", "EUC-H" },
	{ "UniJIS-UCS2-V",  "Ext-RKSJ-V", "V", "Add-RKSJ-V", "EUC-V" },
	//{ "UniJIS-UCS2-HW-H" },
	//{ "UniJIS-UCS2-HW-V" },

	// Korean
	{ "KSCms-UHC-UCS2",  "KSCms-UHC-H", "KSCms-UHC-V", "KSCms-UHC-HW-H", "KSCms-UHC-HW-V" },
	{ "KSCpc-EUC-UCS2",/*"KSCpc-EUC-UCS2C",*/  "KSCpc-EUC-H" },
	{ "UniKS-UCS2-H",  "KSC-EUC-H" },
	{ "UniKS-UCS2-V",  "KSC-EUC-V" },
	//{ "UniKS-UTF16-H", "UniKS-UTF16-V" }, => special case

	/* distributed with Acrobat but not defined in PDF Reference
"Adobe-CNS1-3", 
"Adobe-CNS1-UCS2", 

"Adobe-GB1-4", 
"Adobe-GB1-UCS2", 

"Adobe-Japan1-4", 
"Adobe-Japan1-UCS2", 

"Adobe-Korea1-2", 
"Adobe-Korea1-UCS2", 
*/
  };

  private static final Matcher SUBSET = Pattern.compile("[A-Z][A-Z][A-Z][A-Z][A-Z][A-Z]\\+.+").matcher("");	// naming convenetion:"SIXCAP+..."


  public static boolean isCore14(String name) { return Arrays.binarySearch(CORE14, name)>=0; }

  /** Returns canonical name of font in core 14 font set, or <code>null</code> if none. */
  public static String getCanonical(String name) {
	for (int i=0,imax=EQ_.length; i<imax; i++) {
		String[] eq = EQ_[i];
		int inx = Arrayss.indexOf(eq, name);
		if (inx != -1) return eq[0];
	}
	return null;
  }

  public static boolean isSubset(String name) {
	return name!=null && SUBSET.reset(name).matches();
  }

  
  /**
	Constructs {@link java.awt.Font} based on font dictionary, scaled to <var>size</var> pixels.
  */
  public static NFont createFont(Dict fd, PDFReader pdfr, PDF pdf) throws IOException {
	assert fd!=null; //&& size>=0f /*&& size<200f*/: fd+", size="+size;    // ==0f seen in riggs.pdf page 20
	assert "Font".equals(fd.get("Type")) || null==fd.get("Type");

	//PDFReader pdfr = pdf.getReader();
	NFontManager fm = NFont.getFontManager();
	NFont font = null;

	String subtype = (String)pdfr.getObject(fd.get("Subtype"));
	String basefont = (String)pdfr.getObject(fd.get("BaseFont"));
//System.out.println("createFont: fd = "+fd+", subtype="+subtype);
	Dict fdesc = (Dict)pdfr.getObject(fd.get("FontDescriptor"));
	if (fdesc==null && basefont!=null/*Type 3, Type 0*/) fdesc = Core14AFM.getFontDescriptor(basefont);
	//if ((pdf.getFlags() & MediaAdaptor.FLAG_DISPLAY) == 0) ... don't need actual font, just metrics
	Object o = fdesc!=null? fdesc.get("Flags"): null;
	int flags = o!=null? pdfr.getObjInt(o): FLAG_NONE;

	CMap touni = pdfr.getCMap(fd.get("ToUnicode"));
//if (DEBUG && touni!=null) System.out.println("unicode: "+touni);

	// 1. instantiate basic font
	Object emref;
	boolean fembedded = false;
	// a. guaranteed embedded: Type 3 and Type 0
	if ("Type3".equals(subtype)) {
		assert pdf!=null;
		font = new NFontType3(fd, pdf);
		//font = (NFontAWT)NFont.getInstance("Times", flags, 1f);	// sometimes look better if ignore Type 3?

	} else if ("Type0".equals(subtype)) {
		o = fd.get("Encoding"); Object o2 = pdfr.getObject(o);	// required in Type 0
		Class cl = o2.getClass();
if (DEBUG) System.out.println("Type 0 "+basefont+", encoding = "+o2);
		CMap e2c = CLASS_NAME==cl? CMap.getInstance((String)o2):
			CLASS_DICTIONARY==cl? new CMap(pdfr.getInputStream(o)):
			null;

		if (touni==null && CLASS_NAME==cl) {
			String e = (String)o2; //int bl = e.length();
			if ("Identity-H".equals(e) || "Identity-V".equals(e) || "Identity".equals(e)) touni = e2c;
			else if (e.indexOf("UCS2")>0) touni = CMap.IDENTITY_H;	// UCS2 is from Unicode to CID so already in Unicode
			else if (e.indexOf("UTF16")>0) touni = CMap.IDENTITY_UTF16BE;
			else {	// else pick UCS2 from base
				for (String[] eqclass: TOUNICODE) {
					for (String eq: eqclass) if (eq.equals(e)) { touni = CMap.getInstance(eqclass[0]); System.out.println(e+" => Uni "+eqclass[0]); break; }
				}
			}
			// else translate via java.nio.charset.Charset, hopefully
				// somehow map named encoding to font cmap (PDF Ref: "The means by which this is accomplished are implementation-dependent.")
			/*else if (bl>=3 && base.charAt(bl-2)=='-') {	// ends with "-[HV1234]"
				String u = base.substring(0, bl-2);
				if (u.endsWith("-HW")) u = u.substring(0, u.length()-3);
				if (u.length() > 1) touni = CMap.getInstance(u + "-UCS2");
			}*/
//System.out.println("compute toUnicode from "+o2);
		}
			/* Mac OS X lots:
Big5
Big5-HKSCS
EUC-CN
EUC-JP
euc-jp-linux
EUC-KR
EUC-TW
GB18030
GBK
ISCII91
ISO-2022-CN-CNS
ISO-2022-CN-GB
ISO-2022-KR
ISO-8859-1
ISO-8859-13
ISO-8859-15
ISO-8859-2
ISO-8859-3
ISO-8859-4
ISO-8859-5
ISO-8859-6
ISO-8859-7
ISO-8859-8
ISO-8859-9
JIS0201
JIS0208
JIS0212
Johab
KOI8-R
MacRoman
Shift_JIS
TIS-620
US-ASCII
UTF-16
UTF-16BE
UTF-16LE
UTF-8
windows-1250
windows-1251
windows-1252
windows-1253
windows-1254
windows-1255
windows-1256
windows-1257
windows-1258
windows-936
windows-949
windows-950
			 */

		Object[] oa = (Object[])pdfr.getObject(fd.get("DescendantFonts")); assert oa.length==1;
		//NFont[] dfs = new NFont[oa.length];
		//for (int i=0,imax=dfs.length; i<imax; i++) dfs[i] = createFont((Dict)pdfr.getObject(oa[i]), pdf);
		Dict dfdict = (Dict)pdfr.getObject(oa[0]);
		NFont[] dfs = new NFont[] { createFont(dfdict, pdfr, pdf) };

		Dict dfdesc = (Dict)pdfr.getObject(dfdict.get("FontDescriptor"));
		if (dfdesc.get("FontFile")==null && dfdesc.get("FontFile2")==null && dfdesc.get("FontFile3")==null) {	// if not embedded, no CID: translate everything to Unicode
			// b. update e2c to forget about CID and go directly to Unicode, which we always compute anyway
			// good luck: source in Unicode, and rely on TrueType font's default Unicode CMap (almost always have Unicode CMap)
			if (touni != null) e2c = touni;
			// we're probably screwed, but give it a try
			else e2c = touni = CMap.IDENTITY_H;
		}

		NFontType0 t0 = new NFontType0(basefont, dfs);
		font = t0.deriveFont(e2c, touni);

	// b. possibly embedded
	} else if ("Type1".equals(subtype) || "MMType1".equals(subtype) || "CIDFontType0".equals(subtype)) {
		if (fdesc!=null/*core 14*/ && ((emref=fdesc.get("FontFile"))!=null || (emref=fdesc.get("FontFile3"))!=null)) {	// Type 1 or Multiple Master instance or CFF
//if (DEBUG) System.out.println("embedded "+subtype+": "+basefont);
			InputStream in = pdfr.getInputStream(emref);
			try { font = new NFontType1(InputStreams.toByteArray(in, 10*1024), null); fembedded = true; }
			catch (FontFormatException failed) { System.err.println("embedded Type 1:" +failed); }
			catch (Error e) { e.printStackTrace(); }
			finally { in.close(); }
//if (DEBUG) System.out.println("embedded "+subtype+": "+basefont);
		}

	} else if ("TrueType".equals(subtype) || "CIDFontType2".equals(subtype)) {
		if (fdesc!=null && (emref = fdesc.get("FontFile2"))!=null) {
if (DEBUG) System.out.println("embedded "+subtype+": "+basefont);
			InputStream in = pdfr.getInputStream(emref);
			try { font = new NFontTrueType(InputStreams.toByteArray(in, 10*1024)); fembedded = true; }
//if (DEBUG) System.out.println("created new TrueType font from embedded stream, name = "+basefont+", "+font.getName());
			catch (FontFormatException failed) { System.err.println("embedded "+subtype+" "+basefont+": "+failed); }
			finally { in.close(); }
		}

	} else assert false: "unknown font type on "+basefont+": "+subtype;

	// X c. if (core14 && URW) use URW version so can shape by per-glyph widths
	// => now OS fonts under our control too

	// d. exact name
	//&& basefont!=null -- only Type 3 and Type 0, but those guaranteed
	if (font==null && fm.isAvailableName(basefont)) try { font = fm.getInstance(basefont); } catch (Exception fail) {}

	// e. canonicalized to core 14
	if (font==null) {
		String canon = getCanonical(basefont);
		if (canon!=null) for (int i=0,imax=EQ_.length; i<imax; i++) if (EQ_[i][0]==canon) {
			String[] eq = EQ_[i];
			for (int j=eq.length-1; j>=0; j--) if (fm.isAvailableName(eq[j])) try { font = fm.getInstance(eq[j]); break; } catch (Exception fail) {}	// tries all in equivalence class until one exists and not bad data
//System.out.println(basefont+" => core14 "+canon+" / font="+font);
			break;
		}
	}

	// f. same family
	//if (font==null) String family = NFontManager.guessFamily(basefont);
	// ...

	// g. unembedded CID: match based on /Ordering
	if (font==null && ("CIDFontType0".equals(subtype) || "CIDFontType2".equals(subtype))) {
		Dict sysinfo = (Dict)pdfr.getObject(fd.get("CIDSystemInfo"));
		String e = pdfr.getObject(sysinfo.get("Ordering")).toString();

if (DEBUG) System.out.println("CID not embedded, /Ordering = "+e);//+", ToUnicode = "+touni);
		String fam = null;
		// pick CJK font, if known.  Could scan fonts for characters in Unicode range, but very few Asian fonts because they're so big, so we can enumerate them.
		if (e.startsWith("Ident")) {	// who knows?  maybe even Hebrew or Arabic
		} else if  (e.startsWith("Japan")) {	// Japanese
			fam = // getPreference("pdf.font.japanese")!=null? xxx:
				//fm.isAvailableFamily("Kozuka Mincho Pro Acro")? "Kozuka Mincho Pro Acro":	// Adobe language kit => only licensed for use with Adobe Reader
				fm.isAvailableFamily("Hiragino Mincho Pro")? "Hiragino Mincho Pro":	// OS X
				fm.isAvailableFamily("Kochi Mincho")? "Kochi Mincho":	// 15572 glyphs -- free font
				fm.isAvailableFamily("MS Mincho") && (FLAG_FIXEDPITCH&flags)!=0? "MS Mincho":	// Doze XP -- preferred over MingLiU
				fm.isAvailableFamily("MS PMincho")? "PMincho":	// Doze XP
				fm.isAvailableFamily("MingLiU") && (FLAG_FIXEDPITCH&flags)!=0? "MingLiU":	// Doze Multilingual User Interface Pack -- more common?
				fm.isAvailableFamily("PMingLiU")? "PMingLiU":
				fm.isAvailableFamily("Arial Unicode MS")? "Arial Unicode MS":	// Doze Office XP
				null;
		} else if (e.startsWith("GB")) {	// Chinese (simplified)
			fam = // Preferences.txt
				//fm.isAvailableFamily("MSung Std Acro Light")? "MSung Std Acro Light":	// Adobe language kit
				fm.isAvailableFamily("STFangsong")? "STFangsong":	// OS X
				fm.isAvailableFamily("Watanabe Mincho")? "Watanabe Minchoo":	// free
				fm.isAvailableFamily("NSimSun") && (FLAG_FIXEDPITCH&flags)!=0? "NSimSun":	// Doze XP
				fm.isAvailableFamily("SimSun")? "NSimSun":	// Doze XP
				fm.isAvailableFamily("MingLiU") && (FLAG_FIXEDPITCH&flags)!=0? "MingLiU":
				fm.isAvailableFamily("PMingLiU")? "PMingLiU":
				fm.isAvailableFamily("Arial Unicode MS")? "Arial Unicode MS":
				null;
		} else if (e.startsWith("Korea")) {	// Korean
			fam = // Preferences.txt
				//fm.isAvailableFamily("HY Shin Myeongjo Std Acro")? "HY Shin Myeongjo Std Acro":	// Adobe language kit
				fm.isAvailableFamily("AppleMyungjo")? "AppleMyungjo":	// OS X
				// free
				fm.isAvailableFamily("BatangChe") && (FLAG_FIXEDPITCH&flags)!=0? "BatangChe":	// Doze XP
				fm.isAvailableFamily("Batang")? "Batang":	// Doze XP
				fm.isAvailableFamily("Gulim")? "Gulim":	// Doze Multilingual User Interface Pack
				fm.isAvailableFamily("Arial Unicode MS")? "Arial Unicode MS":
				null;
		} else {	//"CNS"	// Chinese (traditional)
			fam = // Preferences.txt
				//fm.isAvailableFamily("STSong Std Acro")? "STSong Std Acro":	// Adobe language kit
				fm.isAvailableFamily("BiauKai")? "BiauKai":	// OS X
				fm.isAvailableFamily("Kochi Mincho")? "Kochi Mincho":	// free
				fm.isAvailableFamily("NSimSun") && (FLAG_FIXEDPITCH&flags)!=0? "NSimSun":	// Doze XP
				fm.isAvailableFamily("SimSun")? "SimSun":	// Doze XP
				fm.isAvailableFamily("MingLiU") && (FLAG_FIXEDPITCH&flags)!=0? "MingLiU":
				fm.isAvailableFamily("PMingLiU")? "PMingLiU":
				fm.isAvailableFamily("Arial Unicode MS")? "Arial Unicode MS":
				null;
		}
		if (fam!=null) font =  NFont.getInstance(fam, NFontManager.guessWeight(basefont), flags, 1f);
	}

	// h. based on family and flags -- GUARANTEED
	if (font==null) {
		String fam = fdesc!=null? (String)pdfr.getObject(fdesc.get("Family")): null;	// could have missing core 14 w/o fdesc
		if (fam==null) fam = NFontManager.guessFamily(basefont);

//System.out.print("NFont.getInstance("+fam+", "+Integer.toBinaryString(flags)+", 1f)");
		int weight = fdesc!=null && ((o = pdfr.getObject(fdesc.get("FontWeight"))) instanceof Number)? ((Number)o).intValue(): NFontManager.guessWeight(basefont);
		// extended flags
		o = fdesc!=null? fdesc.get("FontStretch"): null;
		if (basefont.indexOf("Cond")>/*=*/0) flags |= FLAG_CONDENSED;

		font = NFont.getInstance(fam, weight, flags, 1f);
//System.out.println(" => "+font.getName());
	}


	// 2. customize: encoding and widths
	if ("Type3".equals(subtype) || "Type1".equals(subtype) || "TrueType".equals(subtype)) {
		NFontSimple fs = (NFontSimple)font;
		fs = setEncoding(fs, fd, touni, pdfr);
		/*if (!fembedded)--needed by symbol in PDF Ref 1.4*/ fs = setWidths(fs, fd, fs.getEncoding(), pdfr);	// PDF Reference 1.5 implementation note 53: "If ... embedded ... widths should exactly match the widths in the font dictionary."
		/*else { // verify that widths all the same
			System.out.println("embedded "+java.util.Arrays.asList((Object[])pdfr.getObject(fd.get("Widths"))));
			int firstch = pdfr.getObjInt(fd.get("FirstChar")), lastch = pdfr.getObjInt(fd.get("LastChar"));
			Object[] oa = (Object[])pdfr.getObject(fd.get("Widths"));
			System.out.println(basefont+" /Widths "+firstch+".."+lastch);
			if (oa.length != lastch - firstch + 1) System.out.println("/Widths length = "+oa.length+" vs last-first="+(lastch-firstch));
			for (int i=firstch,imax=lastch+1; i<imax; i++) {
				double in = font.echarWidth((char)i), em = ((Number)oa[i-firstch]).doubleValue() / 1000.0;
//System.out.println("   "+in+"  vs   "+em);
				if (Math.abs(in - em) > 0.001 && em!=0.0) System.out.println("widths mismatch "+basefont+" @ "+i+": "+in+" => "+em);	// sometimes put 0 in /Widths to fill slot if don't use character(?), sometimes have width for char not in subset
			}
		}*/
		font = fs;

	} else if ("CIDFontType0".equals(subtype) || "CIDFontType2".equals(subtype)) {
		//if (!fembedded) t0 = t0.setWidths(...);

		if (!fembedded) {
			// keep Unicode

		} else if ("CIDFontType2".equals(subtype)) {
			o = fd.get("CIDToGIDMap");
			if (o==null || "Identity".equals(o)) {
				font = ((NFontTrueType)font).deriveFont(CMap.IDENTITY, CMap.IDENTITY);

			} else try {
				StringBuffer sb = new StringBuffer(200);
				InputStream in = pdfr.getInputStream(o); for (int c; (c=in.read())!=-1; ) sb.append((char)((c<<8) | in.read())); in.close();
				char[] cmap = new char[sb.length()]; for (int i=0,imax=cmap.length; i<imax; i++) cmap[i]=sb.charAt(i);
//if (cmap[i]!=0) System.out.print(" "+i+"->"+(int)cmap[i]);}
				font = ((NFontTrueType)font).deriveFont(new CMap(cmap).reverse(), CMap.IDENTITY);
			} catch (IOException ioe) {}	// don't let error here kill whole font
			// c [w1 w2 .. wn]
			// cfirst clast w

		} else { assert "CIDFontType0".equals(subtype);
			// Type 0 maps to CID, which CIDFont maps to GID
		}
	}

	if (DEBUG) System.out.println(basefont+" / "+NFont.strFlags(flags)+" => "+font/*+"/"+font.hashCode()/*+", encoding="+font.getEncoding()*/+" / "+font.getFormat()+" / "+NFont.strFlags(font.getFlags())+", spacech = "+(int)font.getSpaceChar());
	return font;
  }

  private static NFontSimple setEncoding(NFontSimple font,  Dict fd, CMap touni, PDFReader pdfr) throws IOException {
	String basefont = (String)pdfr.getObject(fd.get("BaseFont"));
	Object enobj = pdfr.getObject(fd.get("Encoding"));

	Encoding en;
	if (enobj==null) {
		en = null;	// "built-in encoding" of font -- null means try 8-bit encoding
		// XEP assumes /StandardEncoding (on core 14 only?) -- which is wrong.
	} else if (CLASS_NAME==enobj.getClass()) {
		en = "ZapfDingbats".equals(basefont)? Encoding.ZAPF_DINGBATS: "Symbol".equals(basefont)? Encoding.SYMBOL:	// FOP buggy and asserts /StandardEncoding
			Encoding.getInstance((String)enobj);
	} else { assert CLASS_DICTIONARY==enobj.getClass();   // differences
		Dict emap = (Dict)enobj;
		String base = (String)pdfr.getObject(emap.get("BaseEncoding"));
		en = base!=null? Encoding.getInstance(base): 
			basefont==null? Encoding.ADOBE_STANDARD:
			basefont.startsWith("ZapfD")? Encoding.ZAPF_DINGBATS:
			basefont.startsWith("Symbol")? Encoding.SYMBOL:
			Encoding.ADOBE_STANDARD;	// NOT font.getEncoding()
//System.out.println(emap.get("BaseEncoding")+" ->  "+en+" + "+emap.get("Differences"));
		en = new Encoding(en, (Object[])pdfr.getObject(emap.get("Differences")));
	}

	font = font.deriveFont(en, touni);
	return font;
  }

  private static NFontSimple setWidths(NFontSimple font,  Dict fd, Encoding en, PDFReader pdfr) throws IOException {
	//if (fdesc!=null) System.out.println(basefont+": FontBBox = "+array2Rectangle((Object[])fdesc.get("FontBBox"), IDENTITY_TRANSFORM)+" vs "+font.getMaxCharBounds(new FontRenderContext(IDENTITY_TRANSFORM, false, false)));
	Object o = pdfr.getObject(fd.get("Widths"));
	//if (o==null) return font;	// temporary, for Type 0 -- as in RESIDU p51

	int[] widths; int firstch;
	if (o!=null && o.getClass()==CLASS_ARRAY) {
		Object[] wo = (Object[])o;
		widths = new int[wo.length];
		for (int i=0,imax=wo.length; i<imax; i++) widths[i] = pdfr.getObjInt(wo[i]);
		firstch = (o = fd.get("FirstChar"))!=null? pdfr.getObjInt(o): 0;  // required

	} else { assert o==null: o;   // core 14, which don't have /Widths
		widths = Core14AFM.getWidths(getCanonical((String)fd.get("BaseFont")));
		firstch = 32;   // happens to be 32 for entire core 14

		// core widths in AdobeStandard
		if (widths == null) {}	// bad PDF: not core 14 and no widths (see Bagley6.pdf)
		else if (Encoding.ADOBE_STANDARD == en) {}	// matches (rare)
		else {	// sort widths to match font encoding
			int[] ewidths = new int[256-firstch];
			//for (int i=0+firstch,imax=256; i<imax; i++) {
			for (int i=0,imax=256-firstch; i<imax; i++) {
				String cname = en.getName((char)(i+firstch));
				int std = Encoding.ADOBE_STANDARD.getChar(cname) - firstch;
				if (0 <= std&&std < widths.length) ewidths[i] = widths[std];
			}
			widths = ewidths;
		}
	}

/*if (widths!=null && widths.length > firstch+0x92) {
	System.out.println(font.getName()+": font intrinsic encoding = "+font.getEncoding()+" / w0x92 = "+font.charAdvance((char)0x92)+", name = "+font.getEncoding().getName((char)0x92));
	System.out.println("/Widths encoding = "+en+" / Width[0x92] = "+widths[0x92-firstch]+", name = "+en.getName((char)0x92));
}*/
//if (DEBUG) System.out.println("widths for core "+(o = fd.get("BaseFont"))+"/"+getCanonical((String)o)+" = "+widths);

	//else if ("AvgWidth")int AvgWidth = (desc!=null && (o=desc.get("AvgWidth"))!=null? pdfr.getObjInt(o): 0);
	// "FixedPitch"/FLAG_FIXEDPITCH
	// FLAG_ALLCAP just measure uppercase

	//int lastch = ((o = fd.get("LastChar"))!=null? pdfr.getObjInt(o): firstch_ + widths_.length);  // required
	// error: some PDFs don't give /Widths and not standard
	return widths!=null? font.deriveFont(widths, firstch): font;
  }
}
