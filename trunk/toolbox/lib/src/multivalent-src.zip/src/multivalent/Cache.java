package multivalent;

import java.io.*;
import java.util.Map;
import java.util.HashMap;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.net.URLConnection;
import java.net.HttpURLConnection;
import java.util.Date;
import java.util.StringTokenizer;
import java.util.Iterator;
import java.util.regex.*;

import phelps.Utility;
import phelps.io.Files;
import phelps.io.InputStreams;
import phelps.io.InputStreamCached;
import phelps.net.RobustHyperlink;
import phelps.net.URIs;



/**
	Cache ("a secure place of storage") holds not just set of recently seen pages,
	but important information such as Preferences and perhaps sole copy of automatically saved annotations.

	<p>Types of caches:
	<ul>
<!--	<li>DONTCACHE - for streaming media (otherwise non-local files cached upon reference)-->
	<li>General - for run-of-the-mill pages, purged LRU
	<li>Archive - for more or less regenerable information with guaranteed availability, such as annotated web pages.
		Also, associated information: HTTP headers, cookies, .xdc, hygiene-type, RCS?
	<li>User - for irreplacable information, such as Preferences, bookmarks, annotations, customized hubs,
		page visitation log, patterns determining whether site/page/subtree in General or Archive
	</ul>

	<p>Later: check modification time of cached vs. original.
	If would go into general cache and didn't take long to fetch, maybe not cache at all.

<!--
	<p>TO DO:
	LATER: just a behavior (that sets InputStream) so can decide to have cache or not or different ones.
	Need to keep a master list in memory of checksum=>URL so can tell when an annotated page has moved
	clients should be able to get File and byte[] as well as InputStream

	Cache group decided without explicit flag:
	if filename starts with ~, take from USER
	if filename in table, ARCHIVE
	if working offline flag, CACHEONLY
	if 'http: ... ?' query or "file:/..." or ..., DONTCACHE
	otherwise, GENERAL

-->

	@see DocInfo

	@version $Revision: 1.10 $ $Date: 2003/06/02 05:00:11 $
*/
public class Cache {
  static final boolean DEBUG = !false && Multivalent.DEVEL;

  public static final int DONTCACHE=-1, GENERAL=0, ARCHIVE=1, USER=2, COMPUTE=3, CACHEONLY=4;

  /** File name of associated file that holds a document's HTTP headers. */
  static final String HEADERS = "headers.txt";

  static final String THISRUN = new String();

  public static final Pattern HTTP_OLD_STATUS = Pattern.compile("^HTTP\\s+\\d\\d\\d.*");

  //static DateFormat headerDateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz");     // don't try to parse LastModified, since servers not consistent
  static {
	//headerDateFormat.setLenient(true);
	java.net.HttpURLConnection.setFollowRedirects(false);	// a Java 1.1 surprise
  }

  static Map<String,String> seen_ = new HashMap<String,String>(100);	// use balanced tree instead?


  File userdir_=null, tmpdir_=null;
  //public File getBaseDir() { return tmpdir_; }
  String username_ = (String)System.getProperties().get("user.name");
  CHashMap<String> genremap_;
  int redirectcnt_ = 0;
  //private Map auth = new HashMap(); // realm/auth map


  public Cache(String userdir, String tmpdir, CHashMap<String> genremap) {
	genremap_ = genremap;

	File dir = userdir_ = new File(userdir);
	if (!dir.exists()) {	// create if necessary
		if (!dir.mkdirs()) Utility.error("Couldn't create "+userdir_+" for permanent files");
	} else if (!dir.canRead()) Utility.error("Can't read "+userdir_);

	dir = tmpdir_ = new File(tmpdir);
	if (!dir.exists()) {	// create if necessary
		if (!dir.mkdirs()) Utility.error("Couldn't create cache at "+tmpdir_);
	} else if (!dir.canRead()) Utility.error("Can't read "+tmpdir_);

	//restoreCookies();
  }


/*
  public String getGenre(String fname, URLConnection urlc) {
	String type = null;

//System.out.println("fname="+fname);
	int sfxi = fname.lastIndexOf('.');
	if (sfxi==-1 || (type=(String)adaptor.get(fname.substring(sfxi+1)))==null) {
		if (urlc==null || (type=(String)adaptor.get(urlc.getContentType()))==null /*&&(type=URLConnection.guessContentType(urlc))==null -- maybe add this* /) {
			type="ASCII";
		}
	}
	return type;
  }
*/
  public String getGenre(String contenttype, String filename, InputStream is) {
//System.out.println("getGenre("+contenttype+", "+filename+")");
	String type = null;

	// 0. guess at Content-Type
	if (contenttype==null && is!=null) try { contenttype = URLConnection.guessContentTypeFromStream(is); } catch (IOException ignore) {}    // XML, HTML, gif, xbm, png, jpeg

	if (contenttype==null && is!=null && is.markSupported()) { // guess from content...
/*		byte[] b = new byte[100]; int len = 0;
		is.mark(100); for (int imax=b.length, c; len<imax && (c=is.read())!=-1; len++) b[len] = (byte)c; is.reset();

		// various probes
*/
	}

	// 1. trust MIME Content-Type first
	if (contenttype!=null) {
		int inx = contenttype.indexOf(';'); if (inx!=-1) contenttype = contenttype.substring(0,inx).trim();
		type = genremap_.get(contenttype);

	}

	// 2. try suffix
	// supposed to trust content-type, but my mappings are more specific
	if (type==null || "ASCII".equals(type)/*can make more specific*/) {
		if (Files.isCompressed(filename)) filename = filename.substring(0,filename.lastIndexOf('.'));
		if (filename.indexOf('?')!=-1) filename = filename.substring(0, filename.indexOf('?'));
		int sufi = filename.lastIndexOf('.');
		// later patterns more sophisticated than just suffixes (such as */man/man*/*.* for man page)
		String suffix = (sufi!=-1 && sufi>filename.lastIndexOf('/')? filename.substring(sufi+1): null);
		if (suffix!=null) {
			String override = genremap_.get(suffix);    //filename.substring(filename.lastIndexOf('.')+1));
			if (override!=null) type = override;
		}
	}

	//if (type==null) type = (suffix!=null? "Unsupported": "ASCII");
	if (type==null) type = "ASCII";
//System.out.println("getGenre("+contenttype+", "+filename+") => "+type);

	return type;
  }


  /**
	Return InputStream that stores in cache, perhaps decompressing,
	retrieving from network if not in cache.  The InputStream is buffered.
	Compressed files of type gzip (indicated by suffix .gz, .Z, or .z) are automatically
	uncompressed in stream and the suffix is stripped from the returned, normalized URL.
	Client does Reader, Pushback as needed.

	<!--Return: data stream, headers, genre, actual URL in case of redirect; throws IOException if error (404, ...)-->

	@param type Type of cache

	@exception IOException (404, ...)
	@exception FileNotFoundException
  */
  public InputStream getInputStream(URI uri) throws IOException,FileNotFoundException {
	redirectcnt_=0;
	return getInputStream(new DocInfo(uri), null, COMPUTE);
  }

  /**
	First normalizes URI.
	Client probably wants to wrap returned InputStream in a BufferedInputStream.

	May mutate {@link DocInfo#uri} if redirects or lexical signature; original/requested URI available in {@link DocInfo#uriin}.
  */
  /*public InputStream getInputStream(DocInfo di, String filename, int type) throws IOException, UnknownHostException, FileNotFoundException {
	InputStream in = getInputStream(ci, filename, type);
	if (di.returncode!=200 && di.returncode!=304) setSeen(surl, false);
	return in;
  }*/
  public InputStream getInputStream(DocInfo di, String related, int type) throws IOException, UnknownHostException, FileNotFoundException {
	///*di.returncode=-1;*/ di.in = null;

	URI uri = di.uri, uri0=uri;  assert uri!=null: di;
//System.out.println("URI = "+uri);
	//URL url = Utility.robustURI(di.url);	// uncanonicalized URL that points to actual data
	String urifile = (di.uri==null? "": di.uri.getSchemeSpecificPart()/*getPath()*/);//, nurlfile=urlfile;
	//String protocol = (uri==null?"":uri.getScheme());

	// while almost all servers accept (ignore) signature extension, strip it here just to be safe
	String signature = RobustHyperlink.getSignature(urifile);
	urifile = RobustHyperlink.stripSignature(urifile);
	if (signature!=null) try { di.uri = uri = uri.resolve("".equals(urifile)?"/":urifile); } catch (IllegalArgumentException ignore) {};
	URI uriunsig = uri;

	boolean isScript = (urifile.indexOf('?')!=-1 || urifile.indexOf('&')!=-1) || di.attrs.get("POST")!=null;    // '&' because of "http://ads.cahners.net/html.ng/adtype=ljbanner&layout=sectionsMain&industry=Digital+Libraries&site=lj&position=2&transactionid=3740632809069312&ipaddress=12.232.183.180"
//System.out.println("script "+urifile+" "+isScript);
	//boolean isScript = uri.getQuery() != null;

/*	if (Files.isCompressed(nurifile)) {
		nurifile = nurifile.substring(0,nurifile.lastIndexOf('.'));
		try { di.uri = new URL(di.uri, nurifile); } catch (IllegalArgumentException shouldnthappen) {}  // canonicalize URi
	}*/

	File mapto = mapTo(uri,related, type);
	//System.out.println(uri+" // "+related+" => "+mapto);

//System.out.println("*** protocol = "+protocol+", file="+urifile+", uriin="+uri+" => "+mapto);
//if (DEBUG) System.out.println("getInputStream	"+uri+" + "+related+" => "+mapto);
	InputStream is;
	//boolean fcache = false;
	/*if (di.is != null) {

	} else*/ if ((is = readLocal(di, related, type, mapto)) != null) {

	} else if (!isScript && /*-- with and without lex-sig */ (is = readCache(di, type, mapto)) != null) {
	}

	// record as seen -- whether successful or not -- after checking cache, but before network
	// LATER: can extract things from .zip too
	// LATER: add to visitation log (if turned on)
	//if (type!=USER) setSeen(url.toString());	 // whether successful or not -- auxiliary pages not marked
	String suri = uri.toString();
//System.out.println("type="+type+", seen_.put("+suri);
	if (type!=USER) seen_.put(suri, THISRUN); else seen_.remove(suri); //-- why not mark USER? just background/system so don't waste space?
	//if (type!=USER) seen_.put(uri.toString(), Utility.DEFINED); //  -- auxiliary pages not marked


	if (is!=null) {
	} else if ((is = readNetwork(di, related, type)) != null) {
		//fcache = true;

	} else is = new ByteArrayInputStream(("can't find "+di.uri).getBytes());

	if ("systemresource".equals(di.uri.getScheme())) mapto = null;  // should be ok without, but fails mysteriously
	else mapto = mapTo(di.uri,related, type);    // may have a redirect


	if (is instanceof InputStreamCached) return is; // recursed, so don't wrap twice


	boolean ffile = is instanceof FileInputStream || "file".equals(uri.getScheme());
//System.out.println("in = "+in+", mapto="+mapto);
	//if (in instanceof java.io.JarURLConnection) mapto = null;
	is = new BufferedInputStream(is, 8*1024);

	// Compute genre from headers or suffix (later: or first few bytes of file)
	// (always compute genre, rather than storing, in case add more refined genres)
	String path = uri.getPath();
	if (di.genre==null) di.genre = getGenre((String)di.headers.get("content-type"/*"Content-Type"*/), related==null? path: related, is);
//System.out.println(path+" / "+di.headers.get("Content-Type")+" => genre = "+di.genre);

	// compressed?  .gz or content-encoding
	InputStream uis = contentEncoding(is, (String)di.headers.get("content-encoding"/*"Content-Encoding"*/));
	is = uis!=is? uis: InputStreams.uncompress(is, path);


	// encryption
	// ...
	// if encrypted set outfile to deleteOnExit()

	// InputStreamCached for stream or file
	//if (ffile) { in = new InputStreamCached(mapto); System.out.println("C file-based"); }
	//else { in = new InputStreamCached(in, fcache? mapto: null); System.out.println("stream-based"); }
	is = new InputStreamCached(is, ffile? mapto: null, /*isScript--must cache for PDF returned by script||*/ ffile/* || source compress or encrypted*/? null: mapto);

	if (di.uri==uriunsig) di.uri=uri0;  // restore lex sig

	return is;
  }

  /** Returns true iff resource is (locally available) || (cached and up-to-date). */
  private InputStream readLocal(DocInfo di, String related, int type, File mapto) throws IOException {
	URI uri = di.uri;
	String protocol = uri.getScheme();
	InputStream is;

	if ("systemresource".equals(protocol) && related==null) { // obsoleted by jar:file ? no, systemresource always refers to base Multivalent.jar
		//di.clear();
		di.returncode = 200;
//System.out.println("getting system resource "+di.uri);
		is = getClass().getResourceAsStream(uri.getPath());   // returns null if no such resource -- "systemresource" refers to base browser JAR
		if (is==null) throw new IOException("No such resource: "+uri);
		//is = new InputStreamCached(is, null);   // not available as a file

	} else if ("jar".equals(protocol)) {    // should be "jar:file", but Java has a bug that returns just "jar"
//System.out.println("openStream on "+di.uri);
		is = URIs.toURL(uri).openStream();
//		String frag = di.uri.getFragment()==null? "": "#"+di.uri.getFragment();
//System.out.println("local url = "+new URL("jar:file:" + di.uri.getSchemeSpecificPart() + frag));
//		is = new URL("jar:file:" + di.uri.getSchemeSpecificPart() + frag).openStream();

	} else if ("file".equals(protocol) && related==null) {  // simple file
		File f = mapto;
		if (!f.canRead()) { f = Files.getFuzzyFile(null, f.getPath()); di.uri = f.toURI(); }

		// mock up headers, return code
		di.headers.clear();
		if (f.canRead()) {
			di.headers.put("Length", Long.toString(f.length()));
			di.headers.put("Last-Modified", new Date(f.lastModified()).toString());
			di.returncode = 200;

			if (f.isDirectory()) {	// LATER have LocalDirectory behavior claim openDocument <uri>/<DocInfo> event
				if (di.genre==null) di.genre = "LocalDirectory";
				is = new ByteArrayInputStream(f.toString().getBytes());	 // => StringReader.  something non-null, but not this
			} else is = new FileInputStream(f);
//System.out.println("file in on "+f+" = "+is);
//System.out.println("new Reader"); try { for (int i=0; i<100; i++) System.out.print((char)is.read()); } catch (IOException ioe) {}; System.out.println();

		} else {
			di.returncode = 404;
			di.genre = "HTML";
			is = new ByteArrayInputStream(("<p><b>Can't read "+uri+"</b>").getBytes()); // StringBufferInputStream is deprecated
		}


	} else if (type==USER || related!=null) {   // specific cache or related file
		di.headers.clear();
		if (mapto.canRead()) is = new FileInputStream(mapto);
		else throw new FileNotFoundException(uri.toString());

	} else return null;    // not local

	return is;
  }

  private InputStream readCache(DocInfo di, int type, File mapto) throws IOException {
	if (!mapto.canRead()) return null; // cached http or ftp
//System.out.println("readcache on "+di.uri); if (di.uri.getQuery()!=null) System.exit(1);

	File head = mapTo(di.uri,HEADERS, type);
	Map<String,String> headers = new HashMap<String,String>(13);
	if (head.exists()) {
		BufferedReader headin = new BufferedReader(new FileReader(head));
		String line = headin.readLine();
		try { di.returncode = Integer.parseInt(line); } catch (NumberFormatException nfe) { di.returncode=200; }
		while ((line=headin.readLine())!=null) {
			int split = line.indexOf(':');
			String key=line.substring(0,split), value=line.substring(split+1+1);	// normalized when written out
//System.out.println("\t"+key+": "+value);
			headers.put(key,value);
		}
		headin.close();
	}

	String suri = di.uri.toString();
//System.out.println("seen_.get("+suri);
	String policy = "once"; //getPreferences("cachecheck");
	// ALSO check Expires header
/*	if ("ON".equalsIgnoreCase(getBrowser().getAttr("offline"))) {
		if (mapto.exists()) {
			di.headers = headers;
			di.genre = getGenre((String)di.headers.get("Content-Type"), urifile);
			in = new FileInputStream(mapto);
		} else in = new StringBufferInputStream("<html>\n<head><title>NOT CACHED</title></head>\n<body>\n<p><b>Page not cached.</b>\n<p>You're browsing offline and the page isn't cached.\n</body>\n</html>\n");
//	} else* / if ("always".equals(policy) || ("once".equals(policy) && !isSeen(uri))) {
	} else*/ if ("always".equals(policy) || ("once".equals(policy) && THISRUN!=seen_.get(suri))) {
		// CHECKME
		// flush cache for page and reload
		// HTTP 1.1 spec specifically advises sending exact Last-Modified string reported by server
		// besides, Java can't parse server dates and servers probably can't parse Java's -- di.headers.put("If-Modified-Since", DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.FULL).format(new Date(mapto.lastModified())));
		String lastmod = headers.get("Last-Modified");
		// LATER: con.setIfModifiedSince();
		if (lastmod!=null) di.headers.put("If-Modified-Since", lastmod);
if (DEBUG) System.out.println(">if modified since "+lastmod);

		return null;

	} else {
		// headers
		di.headers.clear(); di.headers.putAll(headers);

if (DEBUG) System.out.println("cache return code = "+di.returncode);
		if (di.returncode!=200 && di.returncode!=304) setSeen(suri, false);
if (DEBUG) System.out.println("returning cached");
		return new FileInputStream(mapto);
	}
  }

  private InputStream readNetwork(DocInfo di, String related, int type) throws IOException {
	// wasn't local or cached, or it's a script, so have to read from network over http/https/ftp
if (DEBUG) System.out.println("*** opening URI: "+di.uri);
	InputStream is;

	// 1. set request parameters
	URI uri = di.uri;
	URL url = URIs.toURL(uri);
	URLConnection con = url.openConnection();
	if (con==null) return null; // must be new protocol that's not supposed to be opened
	con.setUseCaches(false);	// we handle our own caches
	con.setDoInput(true);
	con.setAllowUserInteraction(false);

	// headers
	//getCookies(url, di); => cookies behavior
	di.headers.put("Host", uri.getHost());
	for (Iterator<Map.Entry<String,String>> enu=di.headers.entrySet().iterator(); enu.hasNext(); ) {
		Map.Entry<String,String> e = enu.next();
		String key=e.getKey(), value=e.getValue();
if (DEBUG) System.out.println(">"+key+": "+value);
		con.setRequestProperty(key, value);	// => addRequest so can have multiple "Cookie"
	}

	// method: get / post / ...
	String method = "GET";
	if (con instanceof HttpURLConnection) {
		HttpURLConnection hcon = (HttpURLConnection)con;
System.out.println("proxy = "+hcon.usingProxy());

		if ("POST".equalsIgnoreCase(di.method)) {
			Object o = di.attrs.get("POST");    // data under POST key
System.out.println("POST "+o);
			if (o instanceof String) {
				method="POST";
				con.setDoOutput(true);
				hcon.setRequestMethod("POST");
if (DEBUG) System.out.println("getRequestMethod = "+hcon.getRequestMethod());
				con.setRequestProperty("Content-Length", Integer.toString(((String)o).length()));
if (DEBUG) System.out.println("writeBytes "+di.attrs.get("POST")+": "+((String)o).length());
			}
		} //else if ("DELETE"....
	}

/*
	if (con instanceof HttpsURLConnection) {
		HttpsURLConnection https = (HttpsURLConnection)con;
		SSLSocketFactory sslf = https.getSSLSocketFactory();
	}
*/


	// 2. make connection
System.out.println("trying to connect");
	try {
		con.connect();
	} catch (UnknownHostException badcon) {
		//if (signature!=null) { di.genre="HTML"; return new StringBufferInputStream(robustSearch(badcon.toString(), url, signature)); }
		di.returncode = 404;
		di.genre="ASCII";
		return new ByteArrayInputStream(badcon.toString().getBytes());

	} catch (IOException badcon) { // e.g., java.security.cert.CertificateException
		di.returncode = 401;  // unauthorized
		di.genre="ASCII";
		return new ByteArrayInputStream(badcon.toString().getBytes());
	}
System.out.println("connected, class="+con.getClass().getName());


	int code = -1;
	if (con instanceof HttpURLConnection /*includes HTTPS*/) {
System.out.println("HTTP connection, getting response");
		if ("POST"==method) {
System.out.println("writeBytes "+di.attrs.get("POST"));
			//isScript = true;

			// write data before expecting input response back
			DataOutputStream dos = new DataOutputStream(new BufferedOutputStream(con.getOutputStream()));
			dos.writeBytes((String)di.attrs.get("POST"));
			dos.close();

			// don't cache
			//di.genre="HTML";    // FIX
			//di.genre = getGenre(con.getContentType(), di.uri.toString());
			//return (in = new BufferedInputStream(con.getInputStream()));

		} //else if ("DELETE"....
		// fall through to read response


		HttpURLConnection hcon = (HttpURLConnection)con;
		code = 200; try { code = hcon.getResponseCode(); } catch (IOException bade) { code=404; System.err.println("i/o: "+bade); } // hangs on dlp.cs.berkeley.edu/cgi-bin/post.tcl
System.out.println("HTTP connection, code="+code+" vs "+con.getHeaderFieldKey(0)+", method="+method);

		if (code==-1) { // very old HTTP?
			DataInputStream fixis = new DataInputStream(con.getInputStream());
			String line = fixis.readLine();
System.out.println("|"+line+"| "+HTTP_OLD_STATUS.matcher(line).matches());
			if (line!=null && HTTP_OLD_STATUS.matcher(line).matches()) {         // the very old NCSA/1.5.2 gives invalid status line: "HTTP 200 Document follows" -- needs version for Java's parser
System.out.println("very old HTTP: "+line);
				code = Integer.parseInt(line.substring("HTTP ".length(), "HTTP nnn".length()));
				while ((line=fixis.readLine())!=null && line.length()>0) {
					//int inx = line.indexOf(':');
					//if (inx!=-1) con.setRequestProperty(line.substring(0,inx), line.substring(inx+1));  // can't setRequestProperty after connecting
				}
				// just read blank line so positioned correctly for body
			}
			//fixis.close(); -- leave open
		}
		//if ("Content-Type"==null) String guessContentTypeFromStream(InputStream is)

	//} else if (con instanceof sun.net.www.protocol.ftp.FtpURLConnection) {    can't reference class

	} else if (con instanceof URLConnection) {
		URLConnection ucon = (URLConnection)con;
System.out.println("connection type: "+ucon);
		code = 200;     // hope connection is ok
		if (di.genre==null && uri.getPath().endsWith("/")) {       // should allow cacheing this
			di.genre = "FTPDirectory";
			//return new InputStreamCached(con.getInputStream(), null);
			return con.getInputStream();
		}

	} else assert false: con;   // report unfamiliar connection
	if (code==-1) return null;


	// 3. read data
	di.returncode = code;

	//if (code==304 && redirectcnt_>0) System.exit(1);
	if (code!=301 && code!=302) redirectcnt_=0;
	// always see what server says.  can do other things too
	switch (code) { // could use HttpURLConnection constants for these
	case 301:
	case 302:
		redirectcnt_++;
System.out.println("redirecting to "+((HttpURLConnection)con).getHeaderField("Location"));
		if (redirectcnt_>10) { redirectcnt_=0; throw new IOException("Too many redirects"); }
		con.getInputStream().close();
		di.uri = uri.resolve(con.getHeaderField("Location"));
		is = getInputStream(di, related, type);
		break;

	case 304:	// not modified (sent "If-Modified-Since")
		con.getInputStream().close();
		is = getInputStream(di, related, type);
		//is = readCache(di, type, mapto);
		break;

	case 200:
	//case 403:	// show server messages for these
	default:
		// write headers to cache
		BufferedWriter headout = new BufferedWriter(new OutputStreamWriter(getOutputStream(di.uri,HEADERS, COMPUTE, null)));
		di.headers.clear();
		headout.write(Integer.toString(code)); headout.newLine();
		for (int i=1; ; i++) {	// 0th field is return code
			String key=con.getHeaderFieldKey(i);
//System.out.println("head "+i+" = "+key);
			if (key==null) break;
			//if (/*key==null ||*/ value==null || key.startsWith("<")) break; -- don't ask for both at once as Java will overshoot end of headers
			String value=con.getHeaderField(i);
			if (/*key==null ||*/ value==null || key.startsWith("<")) break;
//if (DEBUG)
System.out.println("<header |"+key+"| = |"+value+"|");
			// "set-cookie" explicitly not saved -- can have multiple set-cookie headers, grr
			if (di.headers.get(key)!=null) {	// duplicate headers, which is OK for cookies, at least
				for (int j=1; ; j++) {
					String altkey = key + ("0"+j);
					if (di.headers.get(altkey)==null) { key=altkey; break; }
				}
			}
			di.headers.put(key, value);

			//if ("set-cookie".equalsIgnoreCase(key)) putCookie(url.getHost(), value); else {
			// DON'T CACHE UNTIL get openedDocument
			if (!"set-cookie".equalsIgnoreCase(key)) { headout.write(key); headout.write(": "); headout.write(value); headout.newLine(); }
			//}
			//di.headers.put(key,value);
		}
		headout.close();


		// cache data
		// later, cache as compressed
//System.out.println("writing to "+mapto);
System.out.println("con.getInputStream");
		try {
			is = con.getInputStream();
		} catch (IOException e) {
			di.genre = "HTML";
System.err.println(e);
			is = new ByteArrayInputStream(("<p><b>"+code+" Could not connect to "+uri).getBytes());
		}

		// in the background compute signature and attach to headers.txt
if (code!=200) System.out.println("*** ret="+code);
		// at this point possible that copy.available()==0, as when reading directories.  I guess some servers send headers--without Content-Length, which would be incorrect?--and then compute text.
	}

	return is;
  }

  private InputStream contentEncoding(InputStream is, String ce) throws IOException {
	if (ce!=null) {
//System.out.println("\007"+ce);
		for (StringTokenizer e = new StringTokenizer(ce, ", \t\n\r"); e.hasMoreTokens(); ) {
			StringTokenizer params = new StringTokenizer(e.nextToken(), "; \t\n\r");
			String en = params.nextToken().toLowerCase();

//System.out.println(en);
			is = InputStreams.uncompress(is, en);
			if ("gzip".equals(en)) is = new java.util.zip.GZIPInputStream(is);
			else if ("deflate".equals(en)) is = new java.util.zip.InflaterInputStream(is);
		}
	}
//System.out.println("<= ce");
	return is;
  }




  /**
	Return OutputStream that stores in cache, perhaps compressing.
	(Data automatically added to cache when getInputStream.)
	@param type Type of cache
  */
  public File getOutputFile(URI uri, String related, int type, Map<String,String> headers) throws IOException {
	// maybe later upload to a server
	File mapto = mapTo(uri,related, type);
	if (!mapto.exists()) {
		File dir = new File(mapto.getParent());
		if (!dir.exists() && !dir.mkdirs()) throw new IOException("Can't make parent directories: "+dir);
	}
	return mapto;
  }

  public OutputStream getOutputStream(URI uri, String related, int type, Map<String,String> headers) throws IOException {
	return new FileOutputStream(getOutputFile(uri, related, type, headers));
  }


  public void delete(URI uri, String related, int type) {
	// so can zap empty hubs
	File mapto = mapTo(uri,related, type);
	if (!mapto.exists() || !mapto.canWrite()) return;

	File parent = new File(mapto.getParent());
	if (type==USER) {
		if (mapto.isFile()) mapto.delete();
	} else {
		parent = new File(mapto.getParent());
		if (parent.exists() && parent.canWrite()) {
			String[] list = parent.list();
			for (int i=0,imax=list.length; i<imax; i++) {
				new File(list[i]).delete();
			}
			//parent.delete(); -- done below
		}
	}

	// if enclosing directory is now empty, delete that too, and recursively upward
	for ( ; parent.list().length==0/*more efficient way*/; parent=new File(parent.getParent())) {
		parent.delete();
	}
  }

/*
  public void flush() {
	for (Iterator<> e = seen_.entrySet().iterator(); e.hasNext(); ) {
		URI uri = (URI)e.next();
		remove(uri,null, COMPUTE);
	}
  }*/

  public void flushAll() {
	// rm -rf GENERAL ARCHIVE ?
  }


  public boolean isCached() {
	return false;
  }

  /**
	This ties whether seen page to whether it's in the cache, which can be wrong after cache is flushed.
  */
  public boolean isSeen(URI uri) {
	if (uri==null) return false;
	//if (seen_.get(uri)!=null) return true;
	//URI nuri = Utility.robustURI(uri);	// normalize
	URI nuri = uri;
	String suri = RobustHyperlink.stripSignature(nuri.toString());	 // signature irrelevant
	//if (surl.indexOf('#')) -- let anchor slide
	return isSeen(suri);
  }

  public boolean isSeen(String suri) {
	return (seen_.get(suri)!=null);

/* documents that are on local file system not marked as seen when startup but remote URLs are
	// compute GENERAL or ARCHIVE based on patterns -- quicker just to try both
	File f = mapTo(url, null, COMPUTE);
	if (f.exists()) {
		try { seen_.put(new URL("file", "", f.toString()), Multivalent.DEFINED); } catch (MalformedURLException canthappen) {}
		return true;
	} else return false;
*/
  }
  public void setSeen(String suri) { setSeen(suri, true); }
  public void setSeen(String suri, boolean seen) {
	if (seen) seen_.put(suri, suri); else seen_.remove(suri);
  }


  public void flushCache(int type) {
  }

  public void addArchivePattern(String pattern) {
  }


  /**
	Can't overload return types to have a get retrun String too so caller should use
	String constructor with return value.
  */
/*
  public byte[] get(URL url, String related, int type, Map headers) throws IOException {
	// if coming from cache, know exactly how big
	File mapto = mapTo(url,related, type);
	int estimate = (mapto.exists() && mapto.isFile()? (int)mapto.length(): 10*1024);
	return get(url,related, type, estimate, headers);
  }*/
/*
  protected byte[] get(URL url, String related, int type, int expectedsize) {
	byte[] data = get2(url, related, type, expectedsize);

	// yet another copy into array of exactly right size -- but Image and String can handle offset,length
	if (off!=data.length) {
		byte[] newdata = new byte[off];
		System.arraycopy(data,0, newdata,0, off);
		data = newdata;
	}
	return data;
  }
*/
/*
  public byte[] get(URL url, String related, int type, int expectedsize, Map headers) throws IOException {
	byte[] data = new byte[expectedsize];

	// SOON -- always read through cache, so know exactly how much to read
	InputStream in = new BufferedInputStream(getInputStream(url,related, type, headers));
	int HUNK=1024;
	int off=0, len=-1;
	do {
		if (off+HUNK > data.length) {
			byte[] newdata = new byte[2*data.length];
			System.arraycopy(data,0, newdata,0, data.length);
			data = newdata;
		}
		try { len = in.read(data, off, HUNK); } catch (IOException ioe) { return null; }
		off += len;
	} while (len!=-1);
	in.close();

	// yet another copy into array of exactly right size -- but Image and String can handle offset,length
	if (off!=data.length) {
		byte[] newdata = new byte[off];
		System.arraycopy(data,0, newdata,0, off);
		data = newdata;
	}

	return data;
  }*/

  public void put(URI uri, String related, int type, byte[] data) {
  }

  public void put(URI uri, String related, int type, String data, Map<String,String> headers) throws IOException {
	Writer out = new BufferedWriter(new OutputStreamWriter(getOutputStream(uri,related, type, headers)));
	out.write(data, 0, data.length());
	out.close();
	//put(uri, related, type, data.toByteArray());
  }

  public void changeStatus(URI uri, String related, int fromtype, int totype) {
	// can only go GENERAL<=>ARCHIVE
  }


  /**
	Canonicalize related vis-a-vis cache by stripping compression and backup suffixes.
  protected static String[] csuffixes = { ".gz", ".Z", ".z", "~", ".bkup", ".bak"/*, NOT .zip* / };
  public String canonicalizeFile(String related) {
	int tail = related.lastIndexOf('/')+1;
	int end = related.length()-1;

	// chop from end
	//if (related.charAt(end)=='~') end--; // special case for Emacs
	for (boolean chop=true; chop; ) {
		for (int i=0,imax=csuffixes.length; i<imax; i++) {
			String suffix = csuffixes[i];
			int len = suffix.length();
			if (suffix.regionMatches(true, 0, related,end-len,len)) {
				end -= len;
				chop=true;
				break;
			}
		}
	}

	// return what's left
	return related.substring(0,end+1);
  }
  */


  /**
	Maps
	<tt>http://www.cs.berkeley.edu/~phelps/tcltk/index.html</tt>
	to
	<tt><i>basedir</i>/edu/berkeley/cs/www/~phelps/tcltk/index.html/index.html<tt>

	@param uri		 URI of base document (if null, use URI of cache)
	@param related  Name of related file, such as "headers.txt" (if null, file is base document)
  */
  public File mapTo(URI uri, String related, int type) {
	StringBuffer sb = new StringBuffer(tmpdir_.toString());
//System.out.println("mapTo<= |"+uri+"|  +	|"+related+"|");

	if (type==COMPUTE) {
		// later: determine GENERAL or ARCHIVE based on user's patterns of what to archive
		sb.append('/').append("GENERAL");
	} else if (type==GENERAL || type==CACHEONLY) {
		sb.append('/').append("GENERAL");
	} else if (type==ARCHIVE) {
		// LATER: take from preferences
		sb.append('/').append("ARCHIVE");
	} else if (type==USER) {
		// add properties.user
		sb.setLength(0);
		sb.append(userdir_.toString());
		//sb.append('/').append(username_);
	} // else (arbitrary) as "index" for full-text indexes, so take String for type?
	// USER with reluri==null special case: use default in getResourceAsStream instead

	if (uri!=null) {
		//URL nurl = Utility.robustURI(url);	// normalize URL
		URI nuri = uri;
		String protocol=nuri.getScheme(), host=nuri.getAuthority(), path=nuri.getPath();    // == null if undefined
		//if (path!=null && path.indexOf('?')!=-1) path = path.substring(0, related.indexOf('?'));     // for now punt on query
		int porti = (host!=null? host.lastIndexOf(':'): -1); if (porti!=-1) host = host.substring(0,porti);
		//if (protocol==null) protocol=""; if (host==null) host="";
		if (path==null || path.length()==0) path="/";   // undefined or empty
		int port = nuri.getPort();
//System.out.println("host = "+host+", port="+port);
		boolean isFile = "file".equals(protocol);
//		path = RobustHyperlink.stripSignature(path);
//System.out.println("path = |"+path+"|");

		// protocol-based canonicalizations
//System.out.println(uri+", protocol = "+protocol);
		if ("jar".equals(protocol)) {   // actually "jar:file" but Java bug
			String ss = uri.getSchemeSpecificPart();
			if (ss.startsWith("file:")) path = ss.substring("file:".length());
			/*protocol = "systemresource";*/ host=null;
			// considered opaque URI so no path
			//path=path.substring(path.indexOf('!')+1);
			// let JARs be installed anywhere: strip out "...!"
//System.out.println(uri+" *jar* path="+path+", ssi= "+uri.getSchemeSpecificPart());
			int bangi = path.indexOf('!'), slashi = path.lastIndexOf('/', bangi);   // no bang
			path = path.substring(slashi+1, bangi)+ "/" + path.substring(bangi+1);
			if (related==null) return null;	// maybe set to "index.html"

		} else if (isFile) {
			if (related==null && type!=CACHEONLY) {
				File already = new File(path);
				if (already.exists()) return already;
			}
			if (path.endsWith("/")) related = "DIRECTORY";

		} else {
			// strip cgi params (including signature, though shouldn't be caching script results)
			int inx=-1;
			if ((inx=(path.indexOf('?')))!=-1) path=path.substring(0,inx);

			if (path.endsWith("/")) path+="index.html";

			if ("http".equals(protocol) && port!=80 && port!=-1) host = port + "." + host; //+= ":"+nuri.getPort();
//System.out.println("host = "+host);
		}

		if (related==null) related = path.substring(path.lastIndexOf('/')+1);
//System.out.println("*** protocol="+protocol+", path="+path+", type="+type+", exists="+new File(path).exists());

		// compression scheme not relevant to canonical cache path
		if (Files.isCompressed(path)) path = path.substring(0, path.lastIndexOf('.'));

		if (isFile) {
			// use File.toURI() as handles MS-DOS bogus drive letters and directory separators. (but piece of shit Visual Cafe can't be updated to JDK1.3)
			try {
				path=new File(path).getCanonicalPath();
				if (path.length()>=2 && Character.isUpperCase(path.charAt(0)) && path.charAt(1)==':') path = "/"+path.charAt(0)+path.substring(2);	// stupid MS-DOS drive letter
			} catch (IOException ignore) {}
		}

//System.out.println("protocol = "+protocol);
		//String machine = (isFile? "file": ("systemresource".equals(protocol)? "resource": host.substring(0,host.indexOf('.'))));
//System.out.println("here2, host=|"+host+"|, len="+host.length());
		String machine = (host==null? protocol: host.indexOf('.')==-1? host: host.substring(0,host.indexOf('.')).toLowerCase()/*normalize to lc*/);
		int queryi = path.indexOf('?');
		if (queryi!=-1) {		// later special QUERY directory and map
		}
		// don't cache local files, local hosts, queries => make that decision elsewhere
		//if ((isFile && related!=null) || (host.length()>0 && host.indexOf('.')==-1) || path.indexOf('?')!=-1) return null;

		if (host!=null) for (int i,lasti=host.length(); (i=host.lastIndexOf('.',lasti-1))!=-1; lasti=i) {
			sb.append('/').append(host.substring(i+1,lasti));
		}
		// Add the "www" of "www.nytimes.com"?	May be mirrored (www2/www3/...) or be a real host (elib.cs.berkeley.edu)
		//String machine = host.substring(host.indexOf('.'));
		int machlen = machine.length();
		if (!machine.equals("www") && !machine.equals("http") && !(machlen>=4 && machine.startsWith("www") && Character.isDigit(machine.charAt(3)))) sb.append('/').append(machine); // or maybe should axe trailing numbers instead

		//if ("/".equals(path)) path="/index.html"; //else if (path.endsWith("/")) sb.append("index.html");
		sb./*append('/').*/append(path);	// already starts with slash
		//if (path.endsWith("/")) sb.append("index.html");
	}

	sb.append('/').append(related);
	// getPort?


	// URIs and all good OSes use '/' as directory separator, stupid MS-DOS doesn't
	// => replace with File.toURI?
	char sep = File.separatorChar;
	if (sep!='/') {
		for (int i=0,imax=sb.length(); i<imax; i++) if (sb.charAt(i)=='/') sb.setCharAt(i, sep);
	}


	File mapFile = new File(sb.substring(0));
	//if (uri!=null && "file".equals(uri.getProtocol()) && type!=CACHEONLY && !mapFile.exists()) mapFile=new File(urifile);
//System.out.println(uri+" + "+related+" => "+sb.substring(0));
	return mapFile;
  }
}
