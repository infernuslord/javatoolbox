package multivalent.std.ui;

import java.awt.dnd.*;
import java.awt.datatransfer.*;
import java.util.Map;
import java.net.URL;
import java.io.IOException;

import multivalent.*;



/**
	Drag and drop URLs into Browser window to open page on that URL.

	@version $Revision$ $Date$
*/
public class DnD extends Behavior implements DropTargetListener {
/*  static /*final* / DataFlavor DATAFLAVOR_URL = null;
  static {
	try {
		DATAFLAVOR_URL = new DataFlavor("application/x-java-url; class = java.net.URL");    // java.net.URL.class, "URL");
	} catch (Exception e) { System.err.println("shouldn't happen "+e); }
  }
*/
  DropTarget dt_ = null;


  public void dragEnter(DropTargetDragEvent dtde) {
//System.out.println("DnD enter");
  }
  public void dragOver(DropTargetDragEvent dtde) {
//System.out.println("DnD over");
  }
  public void dropActionChanged(DropTargetDragEvent dtde) {
//System.out.println("DnD action");
  }
  public void dragExit(DropTargetEvent dte) {
//System.out.println("DnD exit");
  }

  /** Translate DnD event into Document.MSG_OPEN, <txt>. */
  public void drop(DropTargetDropEvent dtde) {
	dtde.acceptDrop(DnDConstants.ACTION_LINK);

	Transferable tr = dtde.getTransferable();
	DataFlavor[] df = tr.getTransferDataFlavors();
	//for (int i=0,imax=df.length; i<imax; i++) System.out.println(df[i]);

//System.out.println("DnD drop");
	try {
		Browser br = getBrowser();
		//Object o = tr.getTransferData(DATAFLAVOR_URL);
		Object o = tr.getTransferData(DataFlavor.stringFlavor);
//System.out.println("data = "+o);
		br.eventq(Document.MSG_OPEN, o);
		dtde.dropComplete(true);
	} catch (IOException ioe) {
		dtde.dropComplete(false);
//System.out.println(ioe);
	} catch (UnsupportedFlavorException ufe) {
		dtde.dropComplete(false);
//System.out.println(ufe);
	}
  }




  public void restore(ESISNode n, Map<String,Object> attr, Layer layer) {
	super.restore(n, attr, layer);

	// activate on Browser
	Browser br = getBrowser();
	dt_ = new DropTarget(br, DnDConstants.ACTION_LINK, this);
	// other actions for ACTION_MOVE / ACTION_COPY ?
  }

  public void destroy() {
	super.destroy();
	// deactive from Browser
	dt_.setComponent(null); // ?
  }
}
