package multivalent;

import java.io.*;
import java.net.URI;
import java.util.*;

import multivalent.node.LeafAscii;



/**
	Superclass for behaviors that parse some concrete document format and build a document tree.
	As much as possible, errors in the input document should be corrected and old constructs modernized
	so that all the many behaviors that operate on the document tree benefit.
	Media adaptors should include in the tree complete data,
	so that a document in the original format can be reconstructed without loss of information.
	This will not necessarily produce an identical file, after error corrrection during read and pretty printing on write.
	<!-- Maybe someday require everybody to generate XML, in addition to whatever native. -->

	<p>New media adaptors can be linked in with the core system by associating
	a MIME Content-Type header and/or file suffix with the class name in
	{@link Multivalent#FILENAME_PREFERENCES Preferences}.

	<p>Media adaptors by default display a document accurately,
	with perfect fidelity sacrificed only if very expensive to do so.
	Applications not requiring this can speed execution by declaring <dfn>hints</dfn>.
	For example, {@link #HINT_NO_IMAGE} which suggests to a media adaptor that images won't be needed
	and so it can operate faster by not creating them.  Media adaptors are free to ignore hints.

	<h2 id='external'>External Use</h2>

	To extract text,
	determine layout coordinates,
	convert to another document format,
	convert the document to an image by painting onto the image's Graphics2D,
	and other uses.

	<p>Parsing
	<ol>
	<li>Create instance: <code>MediaAdaptor ma = (MediaAdaptor){@link Behavior#getInstance(String, String, Map, Layer)}</code>
	<li>optionally set {@link #docURI} field (required if document contains relative references)
	<li>{@link #setInputStream(InputStream)}.
		Subclasses can take also {@link multivalent.std.adaptor.MediaAdaptorChar#setReader(java.io.Reader)} or
		{@link multivalent.std.adaptor.MediaAdaptorRandom#setFile(java.io.File)}.
	<li>{@link #parse(INode)} to obtain a document tree,
		which can be inspected (e.g., to extract text), formatted (e.g., to obtain the layout geometry of HTML),
		painted (e.g., to convert a PDF page into an image and save that disk), ...
	<li>{@link #closeInputStream()}
	</ol>


	<p>Formatting
	...


	<p>Painting on screen or image ({@link java.awt.Graphics2D})
	...


	<p>Examples: {@link tool.doc.ExtractText}
	Often String toHTML() method defined.


	@version $Revision: 1.8 $ $Date: 2003/06/02 05:08:46 $
*/
public abstract class MediaAdaptor extends Behavior implements Runnable {
  /** Results should not include text. */
  public static final int HINT_NO_TEXT=1<<0;
  /** Results should not include images, so there is no need to create them. */
  public static final int HINT_NO_IMAGE=1<<1;
  /** Results should not include drawn shapes (rectangles, ellipses, splines). */
  public static final int HINT_NO_SHAPE=1<<2;
  /**
	Require exact display no matter the computation cost.
	Content is put into the document tree, even if it is not visible.
	Use this flag if the tree is the basic for translation to another format.
  */
  public static final int HINT_EXACT=1<<3;
  /** Favor fast display at possible expense of some accuracy. */
  public static final int HINT_FAST=1<<4;
  /** Document tree will not be displayed (formatted or painted). */
  public static final int HINT_NO_DISPLAY=1<<5;
  /** Show metadata (HTML META, PDF /Info, image WxH & bit depth & format, ...). */
  //public static final int HINT_DISPLAY_METADATA=1<<6;
  /** Plain text only -- no bold, colors, hyperlinks, ... */    // saves hyperlink seen check, but Span creation per se probably cheap
  //public static final int HINT_TEXT_PLAIN=1<<7;
  /** Do not incorporate transclusions.  Useful for full-text indexing that scans each file. */
  public static final int HINT_NO_TRANSCLUSIONS=1<<8;

  /** By default all hints are off: display complete document with perfect fidelity. */
  public static final int HINT_DEFAULTS = 0;


  /** By default, all flags turned on. */
  private int hints_ = HINT_DEFAULTS;

  public int getHints() { return hints_; }
  /** Set document tree construction hints for media adaptor to bit-wise OR of {@link #HINT_NO_TEXT hint flags}. */
  public void setHints(int hints) {
	// check validity of flags?
	hints_ = hints;
  }



  private InputStream is_ = null;

  //protected int linenum=-1; // for reporting line number of parse errors


  // ML helper methods need InputStream as instance variable to avoid passing as parameter all the time
  public/*grumble*/ URI docURI = null;	// should set this in constructor LATER => take from DocInfo

  /** Close media adaptor, freeing any resources. => Behavior.destroy
  public void close() {
  }*/


  public void setInputStream(InputStream is) { is_=is; }  // almost abstract, but Generate and RawImage don't have InputStream's
  public void setInputStream(String txt) { setInputStream(new ByteArrayInputStream(txt.getBytes())); }

  protected InputStream getInputStream() { return is_; }

  public void closeInputStream() throws IOException {
//System.out.println("MA closeInputStream() "+is_);
//new Exception().printStackTrace(); System.exit(1);
	if (is_!=null) { is_.close(); is_=null; }
  }

  //** Return next line from input source. */ => can't unread if see \r not-\n
  //public abstract String readLine() throws IOException;

  /**
	Flush all resources used by current page.
	If medium has more subresources, as HTML has images, then this should be overridden to delete them too.
  public void flush() {
	File f = getControl().getCache().mapTo(docURI, null, Cache.COMPUTE);
	if (f.exists()) f.delete();
  }
  */


  /**
	Translate from a document's data format into a document tree,
	with structure represented in internal nodes and content (text, images, video, ...) at the leaves.

	<p>Before using, invoke {@link #setInputStream(InputStream)}.
	The newly constructed document tree should attach to <var>parent</var>.
	The <var>parent</var> is usually but not necessarily a {@link multivalent.Document}.
	Paginated documents should build the current page only, as indicated by the attribute {@link multivalent.Document#ATTR_PAGE}, and report their page count to {@link multivalent.Document#ATTR_PAGECOUNT}.
	Metadata, such as author and dates, should be stored in the closed containing {@link multivalent.Document}.
	If encountering an unfixable/unrecoverable <em>parsing</em> error, usually due to an invalid data format, throw a {@link multivalent.ParseException}.
	(This does not supercede {@link java.io.IOException}.)

	<p>Subclasses should not rely on being able to obtain a {@link multivalent.node.Root}, {@link multivalent.Browser}, or {@link multivalent.Multivalent};
	in such cases it is acceptable to reduce functionality.

	@return whatever Object is appropriate to the media adaptor.
	For HTML it is the root of the HTML tree (which has name "html"),
	for documents with no single root it can be <var>parent</var>,
	for an image constuctor it could be an {@link java.awt.Image}.
	However, the primary job of a media adaptor is to add content to the document tree.

	@see Span#open(Node) for a convenient way to attach spans
  */
  public abstract Object parse(INode parent) throws Exception;  // only IOException and ParseException?


  /**
	It is recommended that media adaptors construct document trees that directly and fully represent the document format.
	However, it can be expedient to write a quick-and-dirty converter into another a document format, such as Perl POD to HTML.
	In that case, the converter can generated the target format and throw it to this method convert that to a document tree.
  */
  //protected /*static for History, multivalent.net.Robust?*/ Object parseHelper(String txt, String adaptor, INode parent) /*throws IOException--data local*/ {
  public static Object parseHelper(String txt, String adaptor, Layer layer, INode parent) /*throws IOException--data local*/ {
	MediaAdaptor helper = (MediaAdaptor)Behavior.getInstance("helper",adaptor,null, layer);
	Node root = null;
	try {
		helper.setInputStream(txt);
		//help.docURI =  set URI so can resolve references
		root = (Node)helper.parse(parent);
	} catch (Exception e) {
		new LeafAscii("ERROR "+e,null, parent);
		e.printStackTrace();
	} finally {
		try { helper.closeInputStream(); } catch (IOException ioe) {}
	}

	return root;
  }


  public boolean isAuthorized() { return true; }

  public void setPassword(String pw) {}



  /**
	{@link #parse(INode)} concrete document format and put into tree.
	Subclasses should set their style sheets, then parse document body, so can progressively render page, if applicable.
  */
  public void buildBefore(Document doc) {
	try {
		parse(doc);
	} catch (Exception e) {
		new LeafAscii("build before "+e, null, doc);
		//System.out.println("build before "+e);
		//close(); / destroy();
		e.printStackTrace();
	}
  }

  public void buildAfter(Document doc) {
	// also closes in MediaAdaptorChar, which presumably has alread closed with a getFile(), but this enforces closing
	try { closeInputStream(); } catch (IOException ioe) {}
  }

  /**
	On {@link Document#MSG_STOP}, set stop flag, which subclass has to check for periodically.
  */
  public boolean semanticEventAfter(SemanticEvent se, String msg) {
	if (Document.MSG_STOP==msg && se.getArg()==getDocument()) {
		stop();
//*if (DEBUG)*/ System.out.println("*** stopping "+getClass().getName());
	}

	return super.semanticEventAfter(se, msg);
  }



  // notes for upcoming loading of document in own thread.

  // => attributes?
  volatile boolean shown_ = false;
  volatile boolean loading_ = true;
  private boolean stop_ = false;  // don't access directly because changes in one thread much be synchronized to show up in another

  public void run() {
	loading_=true; stop_=shown_=false;

	Object root = new LeafAscii("failed",null, null);
	try {
	root = parse(null/* no args because don't attach to tree during parse*/);
	} catch (Exception e) {}
	loading_ = false;   // done loading because (1) completed successfully (stop_==false), (2) had error (stop_==false), (3) user requested stop (stop_==true)

/*
		br.event/*not q, now!* /(new SemanticEvent(this, Document.MSG_OPENED, di));
		br.setCurDocument(doc);
		br.repaint(bootstrap? 0: 100); //-- on different event queue?
*/

	show(root);
  }

  /**
	Attaches tree for document being parsed to main.
	Either (1) done building and ready to show, or (2) incremental partial show.
  */
  void show(Object root) {
	Document doc = getDocument();

	if (!shown_) {      // could have had earlier incremental
		shown_ = true;
		if (root!=null) {   // stop before reading anything
			doc.clear();

/* set Document's DocInfo
	doc.putAttr(Document.ATTR_GENRE, di.genre);     // => DocInfo
	doc.putVar(Document.VAR_HEADERS, di.headers);   // => DocInfo
	doc.uri = docURI;
	doc.putAttr(Document.ATTR_URI, docURI.toString());	 // make available to scripts -- null==reload => DocInfo
//System.out.println("ml "+docURI+" => "+docURI.getPath());
	String title=docURI.getPath(); int inx=title.lastIndexOf('/'); if (inx!=-1 && inx<title.length()-1) title=title.substring(inx+1);
	doc.putAttr(Document.ATTR_TITLE, title);	// default title
*/

			doc.appendChild((Node)root);
		}
	}

	doc.repaint(100);
  }

  public synchronized/*for communicating across threads*/ boolean isStopped() { return stop_; }
  public synchronized void stop() {
	if (isStopped() && loading_) {
		stop_ = true;
		getDocument().putAttr(Document.ATTR_STOP, Document.ATTR_STOP);  // signal to other behaviors
		//closeInputStream() ?
		//thread.stop();  -- NO.  Media adaptor should periodically check isStopped() and return if true
	}
  }
}
