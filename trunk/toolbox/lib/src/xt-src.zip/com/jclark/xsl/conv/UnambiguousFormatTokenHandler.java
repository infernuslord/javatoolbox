// $Id: UnambiguousFormatTokenHandler.java,v 1.1 2002/04/25 18:03:01 bill Exp $

package com.jclark.xsl.conv;

abstract class UnambiguousFormatTokenHandler implements NumberFormat, FormatTokenHandler
{
    public NumberFormat getFormat(String lang, String letterValue)
    {
        return this;
    }
}
