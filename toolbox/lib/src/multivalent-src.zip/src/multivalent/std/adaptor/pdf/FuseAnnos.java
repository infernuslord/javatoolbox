package multivalent.std.adaptor.pdf;

import multivalent.*;
import multivalent.gui.VMenu;
import multivalent.gui.VCheckbox;
import multivalent.std.ui.StandardFile;



/**
	UNDER DEVELOPMENT.
	Fuse Multivalent annotations to PDF.

	<ul>
	<li>scan annotations on page converting from Multivalent to PDF format
	<li>incrementally update PDF file
	<li>Undo feature to remove last incremental update
	<li>convert from PDF to Multivalent (update PDF) so can edit PDF annos
	</ul>

	@version $Revision: 1.3 $ $Date: 2002/01/07 23:07:55 $
*/
public class FuseAnnos extends Behavior {
  /**
	Convert Multivalent annotations to PDF equivalents (as much as possible) and write new PDF file.
	<p><tt>"pdfFuseAnnos"</tt>
  */
  public static final String MSG_FUSE = "pdfFuseAnnos";

  /**
	For current page only, convert Multivalent annotations to PDF equivalents (as much as possible) and write new PDF file.
	<p><tt>"pdfFuseAnnos"</tt>
  */
  public static final String MSG_FUSE_1 = "pdfFuseAnnos1";


  void v2pdf() {
	Document doc = getDocument();

	// for all annotations in Layer.PERSONAL, convert to PDF equivalent
	Layer personal = doc.getLayer(Layer.PERSONAL), pdflayer = doc.getLayer(Anno.LAYER);
	for (int i=0,imax=personal.size(); i<imax; i++) {
		Behavior be = personal.getBehavior(i);

	}

	// add new objects to xref

	// add to page's /Annots

	// incrementally update PDF file => wait for save
	//PDFWriter ...
  }

  void pdf2V() {
  }



  /** "Dump PDF to temp dir" in Debug menu. */
  public boolean semanticEventBefore(SemanticEvent se, String msg) {
	if (super.semanticEventBefore(se,msg)) return true;
	else if (VMenu.MSG_CREATE_FILE==msg) {
		createUI("button", "Fuse annos to PDF This Page", "event "+MSG_FUSE, (INode)se.getOut(), StandardFile.MENU_CATEGORY_SAVE, true);
		createUI("button", "Fuse annos to PDF All Pages", "event "+MSG_FUSE, (INode)se.getOut(), StandardFile.MENU_CATEGORY_SAVE, true);
		//VCheckbox cb = (VCheckbox)
		//cb.setState(false);
	}
	return false;
  }


  /** Implements {@link #MSG_FUSE}. */
  public boolean semanticEventAfter(SemanticEvent se, String msg) {
	Object arg = se.getArg();

	if (MSG_FUSE==msg) {
	}

	return super.semanticEventAfter(se,msg);
  }
}
