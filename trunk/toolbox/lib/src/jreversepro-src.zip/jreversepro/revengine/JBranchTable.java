/**
  * @(#)JBranchTable.java
  * JReversePro - Java Decompiler / Disassembler.
  * Copyright (C) 2000 2001 Karthik Kumar.
  * EMail: akkumar@users.sourceforge.net
  *
  * This program is free software; you can redistribute it and/or modify
  * it , under the terms of the GNU General Public License as published
  * by the Free Software Foundation; either version 2 of the License,
  * or (at your option) any later version.
  *
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  * See the GNU General Public License for more details.
  * You should have received a copy of the GNU General Public License
  * along with this program.If not, write to
  *  The Free Software Foundation, Inc.,
  *  59 Temple Place - Suite 330,
  *  Boston, MA 02111-1307, USA.
  **/

package jreversepro.revengine;

import java.util.*;
import java.io.IOException;

import jreversepro.reflect.JInstruction;
import jreversepro.reflect.JException;

import jreversepro.common.Helper;
import jreversepro.common.KeyWords;
import jreversepro.common.JJvmOpcodes;

import jreversepro.runtime.JOperandStack;
import jreversepro.runtime.Operand;

import jreversepro.parser.ClassParserException;

/**
 * JBranchTable manages the objects of JGotoEntry and JBranchEntry.
 *
 * @author Karthik Kumar
 * @version 1.3
 **/
public class JBranchTable implements BranchConstants, JJvmOpcodes {


    List Branches;//Vector of JBranchEntry
    Map Gotos;//Vector of JGotoEntry
    List switches; // List of switch instructions - JInstruction.

    Vector mJSRTarget; // Vector of JSR instruction targetPC.
    Map mMonitor; //Map of monitor instructions.

    public JBranchTable() {
        mJSRTarget = new Vector();
        mMonitor =  new HashMap();
        Branches =  new Vector();
        switches  = new Vector();
    }

    public void setTables(List aBranches) {
        Branches.addAll(aBranches);
    }

    public void setGotoTable(Map aGotos ) {
        Gotos = aGotos;
    }

    protected void finalize() {
        Branches  = null;
        Gotos  = null;
    }

    public void add(JBranchEntry ent) {
        Branches.add(ent);
    }

    public boolean isJSRTarget( int currPc ) {
        return mJSRTarget.contains(new Integer(currPc));
    }

    public void addJSRPc( int targetPc ) {
        Integer intPc = new Integer(targetPc);
        if ( !mJSRTarget.contains( intPc) ) {
            mJSRTarget.add ( intPc );
        }
    }

    public void addRetPc( int RetPc ) {
        Object obj = mJSRTarget.lastElement();
        int StartPc = ((Integer)obj).intValue();
        Branches.add( new JBranchEntry( StartPc,
                            StartPc,
                            RetPc,
                            TYPE_JSR, "", "", "" ) );
    }

    public void sort() {
        Collections.sort(Branches,  new JBranchComparator() );
    }

    public void addMonitorPc ( int aMonitorPc, String  aMonObject ) {
        mMonitor.put( new Integer(aMonitorPc), aMonObject );
    }

    public final String doesMonitorBegin( int MonitorBeginPc ) {
        return (String)mMonitor.get( new Integer(MonitorBeginPc) );
    }

    public void identifyMoreBranches()
        throws RevEngineException {

        for ( int i = 0 ; i < Branches.size() ; i++ ) {
            JBranchEntry jbe = ( JBranchEntry )Branches.get(i);
            int gotoStartPc = jbe.getEndBlockPc() - 3;
            int gotoNextPc = gotoStartPc + 3;
            Object obj = Gotos.get( new  Integer(gotoStartPc) );
            switch( jbe.getType() ) {
                case TYPE_IF:
                case TYPE_ELSE_IF:
                    if ( obj != null ) {
                        //Before adding else, check for else if.
                        int gotoTargetPc = ((Integer)obj).intValue();
                        if ( gotoTargetPc - gotoStartPc == 3 ) {
                           break;
                        }
                        JBranchEntry elsif =
                                    contains( startsWith(gotoNextPc),
                                                      TYPE_IF);

                        if ( elsif == null ) {
                            JBranchEntry caseEntry =
                                contains( startsWith(gotoNextPc),
                                                    TYPE_CASE );
                            if ( caseEntry == null ) {
                                JBranchEntry elseEntry =
                                    new JBranchEntry(gotoNextPc,
                                                gotoNextPc,
                                                gotoTargetPc,
                                                TYPE_ELSE,
                                                jbe.Opr1,
                                                jbe.Opr2,
                                                    jbe.Operator );
                                Branches.add(elseEntry);
                            }
                        }
                        else {
                            elsif.setType( TYPE_ELSE_IF );
                        }
                    }
                    break;
                case TYPE_DO_WHILE:
                    if ( Gotos.containsValue( new Integer(jbe.StartPc)) ) {
                        jbe.Type = TYPE_WHILE;
                    }
                    break;
            }
        }
    }

    public void addSwitch( JSwitchTable switchEntry  ) {
        int defaultByte = switchEntry.getDefaultByte();
        int maxTarget = defaultByte;
        List enumCases = switchEntry.getCases();

        for ( int j = 0 ; j < enumCases.size() ; j++ ) {
            JCaseEntry singleCase = ( JCaseEntry ) enumCases.get(j);
            int caseTarget = singleCase.getTarget();
            int endCase =  singleCase.getEndTarget();

            Object obj = Gotos.get( new Integer(endCase - 3) );
            if ( obj != null ) {
                int tempVal = ((Integer)obj).intValue();
                maxTarget = (maxTarget > tempVal) ? maxTarget : tempVal;
            }
            List caseValues =  singleCase.getValues();
            StringBuffer sb =  new StringBuffer();
            for ( int k = 0 ; k < caseValues.size() ; k++ ) {
                sb.append(caseValues.get(k) + ",");
            }
            JBranchEntry ent = new JBranchEntry(
                                caseTarget,
                                caseTarget,
                                endCase,
                                TYPE_CASE,
                                sb.toString(),
                                "","");
            Branches.add( ent );
        }
        Helper.log("maxTarget " + maxTarget );
        Helper.log("defaultByte " + defaultByte );
        if ( maxTarget > defaultByte ) {
            JBranchEntry defaultEnt =
                        new JBranchEntry(
                            defaultByte,
                            defaultByte,
                            maxTarget,
                            TYPE_CASE,
                            KeyWords.DEFAULT,"","");
            Branches.add( defaultEnt );
        }
        Branches.add( switchEntry.getBranchEntry(maxTarget) );
        //To add a switch branch.
    }

    /**
     * List of JException entries.
     **/
    public void addTryBlocks( List ExcTryTable ) {
        for ( int i = 0 ; i < ExcTryTable.size(); i++ ) {
            JException exc = ( JException )ExcTryTable.get(i);
            int insIndex = exc.getStartPc();
            if ( insIndex == -1 ) continue;

            int endPc = exc.getEndPc();
            String SyncLock = doesMonitorBegin(insIndex -1);
            if ( SyncLock != null ) {
                Branches.add (new JBranchEntry (
                                    insIndex,
                                    insIndex,
                                    endPc,
                                    TYPE_SYNC,
                                    SyncLock, "", "" ));
            } else {
                Branches.add (new JBranchEntry (
                                    insIndex,
                                    insIndex,
                                    endPc,
                       (exc.isAny()) ? TYPE_TRY_ANY : TYPE_TRY,
                                     "", "", "" ));
            }
        }
    }

    public int findGotoTarget(int aStartPc ) {
        Integer gotoStartPc = new Integer(aStartPc);
        Object obj = Gotos.get( gotoStartPc );
        if ( obj == null ) {
            return  -1;
        } else {
            return ((Integer)obj).intValue();
        }
    }

    public List startsWith(int aInsIndex)
                   throws RevEngineException {

        List branchEntries = new Vector();
        for ( int i = 0 ; i < Branches.size() ; i++ ) {
            JBranchEntry jbe = ( JBranchEntry) Branches.get(i);
            if( jbe.doesStartWith(aInsIndex) ) {
                branchEntries.add( jbe );
            }
        }
        return branchEntries;
    }

    public void deleteElse( int startElse ) {
        for ( int i = 0 ; i < Branches.size() ; i++ ) {
            JBranchEntry jbe = ( JBranchEntry) Branches.get(i);
            if ( jbe.getType() == TYPE_ELSE &&
                    jbe.getStartPc() == startElse ) {
                Branches.remove(i);
            }
        }
    }

    public static JBranchEntry contains ( List listBranchEntries,
                                            int aType ) {
        if ( listBranchEntries.size() == 0 ) return null;
        for ( int i = 0 ; i < listBranchEntries.size() ; i++ ) {
            JBranchEntry ent = ( JBranchEntry ) listBranchEntries.get(i);
            if ( ent.getType() == aType ) {
                return ent;
            }
        }
        return null;
    }

    private JInstruction getNextGoto(List ByteIns) {
        return null;
    }

    public JInstruction findGotoIns(List ByteIns, int start, int end) {
        int i;
        for (i = 0; i < ByteIns.size(); i++) {
            if (((JInstruction)ByteIns.get(i)).index == start)
                break;
        }
        JInstruction Ins = (JInstruction)ByteIns.get(i);
        while (Ins != null
                && Ins.opcode != OPCODE_GOTO
                && Ins.opcode != OPCODE_GOTOW) {
            if (Ins.index == end) {
                Ins = null;
                break;
            } else if (Ins.opcode == OPCODE_RETURN) {
                Ins = (JInstruction)ByteIns.get(Ins.position + 1);
                break;
            }
            Ins = (JInstruction)ByteIns.get(Ins.position + 1);
        }
        return Ins;
    }

    public void setEndTryCatch(List ByteIns) {

        if (Branches.size() == 0) return;

        JTryCatchFinally tree = new JTryCatchFinally(ByteIns, this);
        sort();
        Helper.log( this.BranchesToString() );
        for (int i = 0; i < Branches.size(); i++) {
            JBranchEntry jbe = (JBranchEntry) Branches.get(i);
            boolean flag = false;
            switch (jbe.getType()) {
                case TYPE_TRY_ANY :
                    flag = true;
                case TYPE_TRY :
                    tree.tryEnt(jbe,
                        (flag) ? TYPE_CATCH_ANY : TYPE_CATCH ,
                        (flag) ? TYPE_JSR : -1);
                    break;
                case TYPE_CATCH :
                case TYPE_CATCH_ANY :
                    tree.catchEnt(jbe);
                    break;
                case TYPE_JSR :
                    tree.jsrEnt(jbe);
                    break;
            }
        }
        tree.end();
    }

    public String BranchesToString() {
        StringBuffer sb = new StringBuffer("");
        int Size = Branches.size();
        if (Size > 0) {
            sb.append("Branches:\n");
            for (int i = 0; i < Size; i++) {
                sb.append((JBranchEntry) Branches.get(i) + "\n");
            }
        }
        return sb.toString();
    }

    public String toString() {
        StringBuffer sb =  new StringBuffer("");
        sb.append(BranchesToString());
        int Size = Gotos.size();
        if (Size > 0) {
            sb.append("Gotos:\n");
            Iterator it = Gotos.entrySet().iterator();
            for (int i = 0; i < Size; i++) {
                sb.append(it.next() + "\n");
            }
        }
        Size = mJSRTarget.size();
        if (Size > 0) {
            sb.append("JSRTargets:\n");
            for( int i = 0; i < Size; i++ ) {
                sb.append( mJSRTarget.get(i) + "\n");
            }
        }
        return sb.toString();
    }

}
