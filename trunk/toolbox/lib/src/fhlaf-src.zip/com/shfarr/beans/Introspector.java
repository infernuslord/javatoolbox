/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.beans;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.shfarr.patterns.Cache;

public class Introspector extends Cache{
    public static final Object[] EMPTY_ARGS = {};
    public static final Class[] EMPTY_PARAMS = {};

    protected static Introspector instance = null;
    
    protected Introspector(){
        super(50);
    }

    public HeavyweightProperty getProperty(Class type, String property){
        List pds = getProperties(type);
        for (int i = 0; i < pds.size(); i++) if(((Property)pds.get(i)).getName().equals(property)) return (HeavyweightProperty)pds.get(i);

        return null;
    }

    public List getProperties(Class type){
        List descriptors = (List)locate(type.getName());

        if (descriptors == null){
            descriptors = introspect(type);
            cache(descriptors, type.getName());
        }

        return descriptors;
    }

    public List introspect(Class type){
        ArrayList properties = new ArrayList();
        int level = 0;

        do{
            introspect(type, level, properties);
            level++;
            type = type.getSuperclass();
        }
        while(type != null);

        Collections.sort(properties);
        
        return properties;
    }

    protected static void introspect(Class c, int level, Collection propertyDescriptors){
        Method[] methods = c.getDeclaredMethods();

        for(int i = 0; i < methods.length; i++){
            if(Modifier.isPublic(methods[i].getModifiers())){
                String name = methods[i].getName();

                if(name.startsWith("set") && methods[i].getParameterTypes().length == 1 && methods[i].getReturnType().equals(void.class)){
////                    String propertyName = BasicUtils.changeCase(methods[i].getName().substring(3), BasicUtils.NON_CAPITAL_CASE);
                    String propertyName = BeanUtils.unpackPropertyName(methods[i].getName().substring(3));
                    HeavyweightProperty descriptor = findDescriptorFor(propertyName, propertyDescriptors);
                    
                    if(descriptor == null){
                        descriptor = new HeavyweightProperty(propertyName, level, null, methods[i]);
                        propertyDescriptors.add(descriptor);
                    }
                    else descriptor.setWriteMethod(methods[i]);
                }
                else if(name.startsWith("is") && methods[i].getParameterTypes().length == 0){
                    // String propertyName = BasicUtils.changeCase(methods[i].getName().substring(2), BasicUtils.NON_CAPITAL_CASE);
                    String propertyName = BeanUtils.unpackPropertyName(methods[i].getName().substring(2));
                    HeavyweightProperty descriptor = findDescriptorFor(propertyName, propertyDescriptors);
                    
                    if(descriptor == null){
                        descriptor = new HeavyweightProperty(propertyName, level, methods[i], null);
                        propertyDescriptors.add(descriptor);
                    }
                    else descriptor.setReadMethod(methods[i]);
                }
                else if(name.startsWith("get") && methods[i].getParameterTypes().length == 0){
                    // String propertyName = BasicUtils.changeCase(methods[i].getName().substring(3), BasicUtils.NON_CAPITAL_CASE);
                    String propertyName = BeanUtils.unpackPropertyName(methods[i].getName().substring(3));
                    HeavyweightProperty descriptor = findDescriptorFor(propertyName, propertyDescriptors);
                    
                    if(descriptor == null){
                        descriptor = new HeavyweightProperty(propertyName, level, methods[i], null);
                        propertyDescriptors.add(descriptor);
                    }
                    else descriptor.setReadMethod(methods[i]);
                }
            }
        }
    }

    protected static HeavyweightProperty findDescriptorFor(String propertyName, Collection propertyDescriptors){
        for(Iterator iter = propertyDescriptors.iterator(); iter.hasNext();){
            HeavyweightProperty element = (HeavyweightProperty)iter.next();
            if(element.getName().equals(propertyName)) return element;
        }

        return null;
    }
    
    public static Introspector instance(){
        if(instance == null) instance = new Introspector();
        return instance;
    }
}