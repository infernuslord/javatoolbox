/*
  Copyright (C) 2003-2004 Robert F. Beeger (robert at beeger dot net)
  Licensed under the Academic Free License version 2.1
  OSI Certified Open Source Software

  Visit http://squareness.sourceforge.net/ for new releases of Squareness Look And Feel and other
  skins from the Squareness series.
*/
package net.beeger.squareness.delegate;

import java.awt.ComponentOrientation;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyVetoException;
import javax.swing.JComponent;
import javax.swing.JInternalFrame;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicInternalFrameUI;

import net.beeger.squareness.util.SquarenessTitlePane;

/**
 * The Squareness Internal Frame UI delegate.
 */
public class SquarenessInternalFrameUI extends BasicInternalFrameUI
{
  /**
   * Create the UI delegate for the given component
   * 
   * @param component The component for which to create the ui delegate
   * @return The created ui delegate
   */
  public static ComponentUI createUI (JComponent component)
  {
    return new SquarenessInternalFrameUI((JInternalFrame) component);
  }

  

  /**
   * Create the UI delegate.
   *
   * @param internalFrame The internal frame this delegate will be used for.
   */
  public SquarenessInternalFrameUI (JInternalFrame internalFrame)
  {
    super(internalFrame);
  }

  /**
   * Create the title bar of the internal frame.
   *
   * @param internalFrame The internalframe for which to create the title bar.
   * @return The created title bar.
   */
  protected JComponent createNorthPane (JInternalFrame internalFrame)
  {
    _titlePane = new SquarenessInternalFrameTitlePane(internalFrame);
    return _titlePane;
  }

  /**
   * The class for title bars of internal frames.
   */
  protected static class SquarenessInternalFrameTitlePane extends SquarenessTitlePane
  {
    public SquarenessInternalFrameTitlePane (JInternalFrame frame)
    {
      _frame = frame;
      _frame.addPropertyChangeListener(new PropertyChangeListener()
      {
        public void propertyChange (PropertyChangeEvent evt)
        {
          update();
          _frame.revalidate();
          _frame.repaint();
        }
      });
    }

    public boolean isLeftToRight ()
    {
      return _frame.getComponentOrientation().isLeftToRight();
    }

    protected boolean isIconifiable ()
    {
      return _frame.isIconifiable();
    }

    protected boolean isMaximizable ()
    {
      return _frame.isMaximizable();
    }

    protected boolean isClosable ()
    {
      return _frame.isClosable();
    }

    protected void close ()
    {
      if (isClosable())
      {
        _frame.doDefaultCloseAction();
      }
    }

    protected void iconify ()
    {
      if (isIconifiable())
      {
        if (!isIconified())
        {
          try
          {
            _frame.setIcon(true);
          }
          catch (PropertyVetoException e1)
          {
          }
        }
        else
        {
          try
          {
            _frame.setIcon(false);
          }
          catch (PropertyVetoException e1)
          {
          }
        }
      }
    }

    protected void maximize ()
    {
      if (isMaximizable())
      {
        if (!isMaximized())
        {
          try
          {
            _frame.setMaximum(true);
          }
          catch (PropertyVetoException e5)
          {
          }
        }
        else
        {
          try
          {
            _frame.setMaximum(false);
          }
          catch (PropertyVetoException e6)
          {
          }
        }
      }
    }

    protected void restore ()
    {
      if (isMaximizable() && isMaximized())
      {
        try
        {
          _frame.setMaximum(false);
        }
        catch (PropertyVetoException e4)
        {
        }
      }
      else if (isIconifiable() && isIconified())
      {
        try
        {
          _frame.setIcon(false);
        }
        catch (PropertyVetoException e4)
        {
        }
      }
    }

    protected boolean isMaximized ()
    {
      return _frame.isMaximum();
    }

    protected boolean isIconified ()
    {
      return _frame.isIcon();
    }

    protected String getTitle ()
    {
      return _frame.getTitle();
    }

    private JInternalFrame _frame;
  }

  private SquarenessInternalFrameTitlePane _titlePane;
}

/*
  $Log: SquarenessInternalFrameUI.java,v $
  Revision 1.7  2004/09/18 17:30:47  rbeeger
  * Updated copyright block and license file. Squareness Look And Feel is now licensed under Academic Free License 2.1
  * Added themepack.

  Revision 1.6  2004/09/10 17:29:28  rbeeger
  * title pane now works for internal frame ui and root pane ui
  * SquarenessRootPaneUI is mostly a copy of MetalRootPaneUI. The only difference: the title pane.
  * Fixed bug [ 1017901 ] An undecorated frame doesn't update properly with 1.1.1: An empty border in the frame border that worked ok in internal frames, didn't work on JFrames at all.
  * Added documentation in some places.

  Revision 1.5  2004/03/08 23:01:33  rbeeger
  Optimized imports.

  Revision 1.4  2004/03/08 22:53:11  rbeeger
  Fixed placement of frame buttons and painting of frame borders.

  Revision 1.3  2004/03/08 15:12:26  rbeeger
  Added and enhanced comments.
  Simplified code.

  Revision 1.2  2004/02/14 19:12:34  rbeeger
  Updated copyright statement
  Added cvs log directive at the end of each file
  Optimized imports
  Reformated code

 */
