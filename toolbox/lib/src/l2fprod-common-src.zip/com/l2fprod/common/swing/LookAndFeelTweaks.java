/** ===================================================================
 *
 * @PROJECT.FULLNAME@ @VERSION@ License.
 *
 * Copyright (c) @YEAR@ L2FProd.com.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by L2FProd.com
 *        (http://www.L2FProd.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "@PROJECT.FULLNAME@", "@PROJECT.SHORTNAME@" and "L2FProd.com" must not
 *    be used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact info@L2FProd.com.
 *
 * 5. Products derived from this software may not be called "@PROJECT.SHORTNAME@"
 *    nor may "@PROJECT.SHORTNAME@" appear in their names without prior written
 *    permission of L2FProd.com.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL L2FPROD.COM OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package com.l2fprod.common.swing;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JEditorPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.text.View;
import javax.swing.text.html.HTMLDocument;

/**
 * LookAndFeelTweaks. <br>
 *  
 */
public class LookAndFeelTweaks {

  public final static Border PANEL_BORDER =
    BorderFactory.createEmptyBorder(3, 3, 3, 3);
  
  public final static Border WINDOW_BORDER =
    BorderFactory.createEmptyBorder(4, 10, 10, 10);
  
  public static void tweak() {
    UIManager.put("Table.font", UIManager.get("List.font"));
    UIManager.put("ToolTip.font", UIManager.get("List.font"));
    UIManager.put("TextField.font", UIManager.get("List.font"));
    UIManager.put("FormattedTextField.font", UIManager.get("List.font"));
    UIManager.put("Viewport.background", "Table.background");
  }

  public static PercentLayout createVerticalPercentLayout() {
    return new PercentLayout(PercentLayout.VERTICAL, 8);
  }
  
  public static PercentLayout createHorizontalPercentLayout() {
    return new PercentLayout(PercentLayout.HORIZONTAL, 8);
  }
  
  public static ButtonAreaLayout createButtonAreaLayout() {
    return new ButtonAreaLayout(6);
  }
  
  public static BorderLayout createBorderLayout() {
    return new BorderLayout(8, 8);
  }
  
  public static void setBorder(JComponent component) {
    if (component instanceof JPanel) {
      component.setBorder(PANEL_BORDER);
    }
  }

  public static void setBorderLayout(Container container) {
    container.setLayout(new BorderLayout(3, 3));
  }

  public static void makeBold(JComponent component) {
    component.setFont(component.getFont().deriveFont(Font.BOLD));
  }

  public static void makeMultilineLabel(JTextArea area) {
    area.setWrapStyleWord(true);
    area.setEditable(false);
    area.setOpaque(false);
    area.setLineWrap(true);
  }
  
  public static void htmlize(JComponent component) {
    Font defaultFont = UIManager.getFont("Button.font");

    String stylesheet =
      "body { margin-top: 0; margin-bottom: 0; margin-left: 0; margin-right: 0; font-family: "
        + defaultFont.getName()
        + "; font-size: "
        + defaultFont.getSize()
        + "pt;	}"
        + "a, p, li { margin-top: 0; margin-bottom: 0; margin-left: 0; margin-right: 0; font-family: "
        + defaultFont.getName()
        + "; font-size: "
        + defaultFont.getSize()
        + "pt;	}";

    try {
      HTMLDocument doc = null;
      if (component instanceof JEditorPane) {
        doc = (HTMLDocument) ((JEditorPane)component).getDocument();
      } else {
        View v =
          (View)component.getClientProperty(
            javax.swing.plaf.basic.BasicHTML.propertyKey);
        if (v != null) {
          doc = (HTMLDocument)v.getDocument();
        }
      }
      if (doc != null) {
        doc.getStyleSheet().loadRules(
          new java.io.StringReader(stylesheet),
          null);
      } // end of if (doc != null)
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static Border addMargin(Border border) {
    return new CompoundBorder(border, PANEL_BORDER);
  }

}
