// Beta
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	XP Look and Feel                                                       *
*                                                                              *
*  (C) Copyright 2002, by Stefan Krause                                        *
*                                                                              *
*                                                                              *
*   This library is free software; you can redistribute it and/or modify it    *
*   under the terms of the GNU Lesser General Public License as published by   *
*   the Free Software Foundation; either version 2.1 of the License, or (at    *
*   your option) any later version.                                            *
*                                                                              *
*   This library is distributed in the hope that it will be useful,            *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of             *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                       *
*   See the GNU Lesser General Public License for more details.                *
*                                                                              *
*   You should have received a copy of the GNU General Public License along    *
*   with this program; if not, write to the Free Software Foundation, Inc.,    *
*   59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.                    *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package com.stefankrause.xplookandfeel;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;

import javax.swing.JComponent;
import javax.swing.JRadioButton;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.metal.MetalRadioButtonUI;

public class XPRadioButtonUI extends MetalRadioButtonUI {
	/** the only instance of the radiobuttonUI */
	private static final XPRadioButtonUI metouiaRadioButtonUI = new XPRadioButtonUI();
	/* the only instance of the stroke for the focus */
	private static BasicStroke focusStroke = new BasicStroke(1.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 1.0f, new float[] { 1.0f, 1.0f }, 0.0f);
	/* the only instance of the radiobutton icon*/
	private static XPRadioButtonIcon skinnedIcon;

	/**
	 * Creates the singleton for the UI
	 * @see javax.swing.plaf.ComponentUI#createUI(JComponent)
	 */
	public static ComponentUI createUI(JComponent c) {
		if (c instanceof JRadioButton) {
			JRadioButton jb = (JRadioButton) c;
			jb.setRolloverEnabled(true);
		}
		return metouiaRadioButtonUI;
	}

	/**
	 * Installs the icon for the UI
	 * @see javax.swing.plaf.ComponentUI#installUI(JComponent)
	 */
	public void installUI(JComponent arg0) {
		super.installUI(arg0);
		icon = getSkinnedIcon();
	}
	
	/**
	 * Returns the skinned Icon 
	 * @return XPRadioButtonIcon
	 */
	protected XPRadioButtonIcon getSkinnedIcon()
	{
		if (skinnedIcon==null)
			skinnedIcon = new XPRadioButtonIcon();
		return skinnedIcon;
	}


	/**
	 * Paints the focus for the radiobutton
	 * @see javax.swing.plaf.metal.MetalRadioButtonUI#paintFocus(java.awt.Graphics, java.awt.Rectangle, java.awt.Dimension)
	 */
	protected void paintFocus(Graphics g, Rectangle t, Dimension arg2) {
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor(Color.black);

		g2d.setStroke(focusStroke);
		g2d.drawLine(t.x -1, 			 t.y -1, 		       t.x -1 + t.width+1,  t.y -1);
		g2d.drawLine(t.x -1, 			 t.y -1 + t.height+1,    t.x -1 + t.width+1,  t.y -1 + t.height+1);
		g2d.drawLine(t.x -1,   t.y -1, 			   t.x -1, 				 t.y -1 + t.height+1);
		g2d.drawLine(t.x -1 + t.width+1,   t.y -1, 			   t.x -1 + t.width+1, 	 t.y -1 + t.height+1);
	}
}