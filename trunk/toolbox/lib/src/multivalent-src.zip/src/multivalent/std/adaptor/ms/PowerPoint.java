package multivalent.std.adaptor.ms;

import java.io.*;
import java.net.URL;
import java.net.MalformedURLException;
import java.awt.*;

import multivalent.*;
import multivalent.node.LeafAscii;



/**
	UNDER DEVELOPMENT.
	PowerPoint, based on spec at <a href='http://www.microsoft.com/'>Microsoft</a>.

	@version $Revision: 1.3 $ $Date: 2002/02/02 12:54:05 $
*/
public class PowerPoint extends multivalent.std.adaptor.MediaAdaptorRandom {
  static final boolean DEBUG = true;
  boolean test = false;

  public Object parse(INode parent) throws IOException {
	// = new DataInputStream(new BufferedInputStream(in));

	return null;
  }


//	Font defaultFont = new Font("Serif", Font.PLAIN, 12);	   // => take from doc
  public void buildBefore(Document doc) {
	doc.appendChild(new LeafAscii("don't handle PowerPoint yet", null, null));
  }
}
