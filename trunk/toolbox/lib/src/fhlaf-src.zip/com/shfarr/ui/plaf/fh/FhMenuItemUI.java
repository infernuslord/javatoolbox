/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh;

import java.awt.*;
import javax.swing.*;
import javax.swing.plaf.*;
import javax.swing.plaf.basic.*;

import com.shfarr.ui.plaf.fh.borders.FHMultiMatrixBorder;
import com.shfarr.ui.plaf.fh.textures.Texture;
import com.shfarr.ui.plaf.fh.theme.ThemeManager;

public class FhMenuItemUI extends BasicMenuItemUI{

    public FhMenuItemUI(){
        super();
    }

    public static ComponentUI createUI(JComponent cmp){
        return new FhMenuItemUI();
    }

    public Dimension getPreferredSize(JComponent c){
        if(c instanceof AbstractButton){
            Dimension d = new Dimension(super.getPreferredSize(c).width, (int)(c.getFont().getSize() * 1.5));

            if(((AbstractButton)c).getIcon() != null) d.height = Math.max(d.height, (int)(((AbstractButton)c).getIcon().getIconHeight() * 1.5));

            Insets bi = c.getBorder() != null ? c.getBorder().getBorderInsets(c) : new Insets(0, 0, 0, 0);
            Insets i = ((AbstractButton)c).getMargin();

            d.width += i.left + i.right + bi.left + bi.right;
            d.height += i.top + i.bottom + bi.bottom + bi.top;

            return d;
        }
        else return super.getPreferredSize(c);
    }

    public void paint(Graphics g, JComponent c){
        ThemeManager.instance().probeAntialiasing(g);

        if(c instanceof JMenuItem && c.getBorder() instanceof FHMultiMatrixBorder){
            String key = ((AbstractButton)c).getModel().isArmed() ? "armed" : ((AbstractButton)c).getModel().isPressed() ? "pressed" : "normal";
            ((FHMultiMatrixBorder)c.getBorder()).selectMatrix(key);
        }

        super.paint(g, c);

        Texture texture = (Texture)UIManager.getDefaults().get("MenuItem.texture");
        if(texture != null && ThemeManager.instance().probeSmallTextures() && ((AbstractButton)c).getModel().isArmed())
                texture.apply(new Rectangle(0, 0, c.getSize().width, c.getSize().height), (Graphics2D)g, c);
    }
}