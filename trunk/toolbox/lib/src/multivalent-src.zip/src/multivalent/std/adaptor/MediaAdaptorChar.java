package multivalent.std.adaptor;

import java.io.*;
import java.util.*;

import multivalent.MediaAdaptor;



/**
	Superclass for character stream-based document formats,	such as HTML.
	Have this in subclass so don't have to convert to InputStream, just to go back to Reader.

	@see multivalent.std.adaptor.HTML
	@see multivalent.std.adaptor.Zip

	@version $Revision: 1.3 $ $Date: 2002/10/16 09:17:37 $
*/
public abstract class MediaAdaptorChar extends MediaAdaptor {
  //protected PushbackReader ir_ = null; //-- subclasses can make one if they want
  private Reader ir_ = null;

  //public Object/*ESISNode*/ parse(InputStream urlin) throws Exception { return parse(urlin, null); }

/*
  public Object parse(String txt, URI uri, INode parent) throws Exception {
	this.docURI = uri;
	setReader(new StringReader(txt));     // don't need to wrap in BufferedReader
	return parse(parent);
  }
*/

  /** Same as <code>setReader(new InputStreamReader(<var>is</var>)</code>. */
  public void setInputStream(InputStream is) {
	//linenum=-1;
	// it's really important to use a BufferedReader, but let client do it himself => assume InputStream is buffered (BufferedIS / ByteArrayIS, StringIS), which is enough
//System.out.println("new Reader"); try { for (int i=0; i<100; i++) System.out.print((char)is.read()); } catch (IOException ioe) {}; System.out.println();
	//super.setInputStream(is);
	setReader(new InputStreamReader(is));
  }
  /** Same as <code>setReader(new StringReader(<var>txt</var>)</code>. */
  public void setInputStream(String txt) { setReader(new StringReader(txt)); }

  /** Same as {@link #closeReader()}. */
  public void closeInputStream() throws IOException { closeReader(); }

  public void setReader(Reader r) {
	if (ir_==null) ir_ = r;
  }
  protected Reader getReader() { return ir_; }

  public void closeReader() throws IOException {
	if (ir_!=null) try { ir_.close(); } finally { ir_ = null; }
  }


  /** Read through end of line, throwing away content.
  protected void eatLine() throws IOException {
	int ch;
	while ((ch=ir_.read())!='\n' && ch!='\r' && ch!=-1) {/*eat* /}
	if (ch=='\r' && (ch=ir_.read())!='\n') ir_.unread(ch);
  }*/

  /** Read through end of line, returning content (w/o ending newline) as String. */
//  protected String readLine() throws IOException {    // like that found in BufferedReader, except that we've got a generic Reader
}
