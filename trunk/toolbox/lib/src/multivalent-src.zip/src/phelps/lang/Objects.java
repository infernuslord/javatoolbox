package phelps.lang;



/**
	Extensions to {@link java.lang.Object}.

	<ul>
	<li>
	</ul>

	@version $Revision$ $Date$
*/
public class Objects {
  public static Object[] ARRAY0 = new Object[0];

  private Objects() {}
}
