/*
 * Hamsam - Instant Messaging API
 * Copyright (C) 2003 Raghu K
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package hamsam.util.net.ssl;

import hamsam.exception.IllegalStateException;
import hamsam.net.ProxyInfo;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/**
 * A factory class that creates SSL sockets that may tunnel through a proxy.
 *
 * @author Raghu
 */
class SSLTunnelSocketFactory extends SSLSocketFactory
{
	/**
	 * The HamsamHttpsConnection object associated with this factory.
	 */
	private HamsamHttpsConnection conn;

	/**
	 * The default factory used by system. We first create a tunnelling socket
	 * through the proxy and delegate it to this factory for overlaying
	 * SSL on it.
	 */
	private SSLSocketFactory factory;

	/**
	 * The proxy to be used for tunnelling.
	 */
	private ProxyInfo info;

	/**
	 * Constructs a new tunnelling SSL socket factory by specifying the proxy
	 * information and a factory to overlay SSL on the tunnel.
	 *
	 * @param factory The default factory used by system. We first create a
	 *                tunnelling socket through the proxy and delegate it to
	 *                this factory for overlaying SSL on it.
	 * @param info    The proxy to be used for tunnelling.
	 */
	public SSLTunnelSocketFactory(SSLSocketFactory factory, ProxyInfo info)
	{
		this.info = info;
		this.factory = factory;
	}

	public Socket createSocket(String host, int port) throws IOException, UnknownHostException
	{
		return createSocket(null, host, port, true);
	}
	
	public Socket createSocket(String host, int port, InetAddress clientHost, int clientPort) throws IOException,UnknownHostException
	{
		return createSocket(null, host, port, true);
	}
	
	public Socket createSocket(InetAddress host, int port) throws IOException
	{
		return createSocket(null, host.getHostName(), port, true);
	}
	
	public Socket createSocket(InetAddress address, int port, InetAddress clientAddress, int clientPort) throws IOException
	{
		return createSocket(null, address.getHostName(), port, true);
	}
	
	public Socket createSocket(Socket s, String host, int port, boolean autoClose) throws IOException,UnknownHostException
	{
		Socket tunnel;
		try
		{
			tunnel = this.info.getConnection(host, port).getSocket();
		}
		catch (IllegalStateException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

		SSLSocket result = (SSLSocket) this.factory.createSocket(tunnel, host, port, autoClose);
		result.addHandshakeCompletedListener(new HamsamHandshakeCompletedListener(this.conn));
		return result;
	}

	public String[] getDefaultCipherSuites()
	{
		return this.factory.getDefaultCipherSuites();
	}
	
	public String[] getSupportedCipherSuites()
	{
		return this.factory.getSupportedCipherSuites();
	}

	/**
	 * Sets the Hamsam HTTPS connection associated with this factory.
	 *
	 * @param conn The Hamsam HTTPS connection associated with this factory.
	 */
	public void setConnection(HamsamHttpsConnection conn)
	{
		this.conn = conn;
	}
}