package multivalent;	// want default package so simple no import, but doesn't work in practice

public class Meta {
  /* * * CHANGE THIS BEFORE A RELEASE * * */
  public static final boolean DEVEL = !true;
  /* * * END CHANGE * * */

  /** General monitoring flag.  <code>true</code> while developing, <code>false</code> when compile for distribution to users. */
  public static final boolean MONITOR = true && DEVEL;


  private static String lastmsg = null;
  public static void sampledata(String msg) {
	if (DEVEL && msg != lastmsg) { System.err.println("SAMPLE DATA: "+msg); lastmsg = msg; }
  }
  public static void unsupported(String msg) {
	if (DEVEL && msg != lastmsg) { System.err.println("UNSUPPORTED: "+msg); lastmsg = msg; }
  }

}
