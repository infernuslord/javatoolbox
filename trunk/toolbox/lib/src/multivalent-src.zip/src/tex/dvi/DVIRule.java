package tex.dvi;

import java.awt.*;
import java.util.Map;

import multivalent.Context;
import multivalent.INode;
import multivalent.node.Fixed;
import multivalent.Leaf;


/**
	Draw TeX rules (rectangles).
	Nothing special about this; should make multivalent.node.FixedLeafRule / Box

	@see tex.dvi.DVI

	@version $Revision: 1.5 $ $Date: 2002/10/09 08:47:06 $
*/
public class DVIRule extends Leaf implements Fixed {
  Rectangle ibbox = new Rectangle();	// initial bbox -- for scanned pages, always need so can find word in image

  public DVIRule(String name,Map<String,Object> attrs, INode parent) { super(name,attrs, parent); }

  public Rectangle getIbbox() { return ibbox; }


  public boolean formatNodeContent(Context cx, int start, int end) {
	if (start==0) bbox.setBounds(ibbox); else bbox.setBounds(ibbox.x,ibbox.y, 0,0);
	return false;
  }


  // draw from ibbox to bbox
  public boolean paintNodeContent(Context cx, int start, int end) {
	Graphics2D g = cx.g;
	g.setColor(cx.foreground);
	g.fillRect(0,0, bbox.width,bbox.height);
	return false;
  }

  public int subelementHit(Point rel) { if (rel.x > bbox.width/3) return size(); else return 0; }
}
