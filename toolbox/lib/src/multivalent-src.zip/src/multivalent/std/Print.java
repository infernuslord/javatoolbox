package multivalent.std;

import multivalent.*;



/**
	STATUS: just defines PRINT semantic event --
	no implementation yet.

	@version $Revision$ $Date$
*/
public class Print extends Behavior {
  /**
	Print document, asking for page range of multipage document.
	<p><tt>"print"</tt>.
  */
  public static final String MSG_PRINT = "print";
}
