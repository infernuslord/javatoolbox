package multivalent.std;

import java.awt.RenderingHints;
import java.util.Map;

import multivalent.*;
import multivalent.gui.VMenu;
import multivalent.gui.VCheckbox;

import phelps.lang.Booleans;



/**
	Font rendering control: antialiasing and fractional metrics.
	Enforce on or off for particular media adaptor, or ask user in a menu.

	Ideally we'd want antialiasing and fractional metrics on everywhere always.
	However, Java's antialiasing is broken and it slows rendering performance.
	It's desperately needed for PDF and DVI, so selectively turn on.
	@deprecated will vanish when it's <a href='http://developer.java.sun.com/developer/bugParade/bugs/4508344.html'>fixed in Java 1.5</a>.

	@version $Revision: 1.3 $ $Date: 2003/06/02 05:46:55 $
*/
public class FontRender extends Behavior {
  /**
	Toggle antialiasing.
	<p><tt>"antialias"</tt>
  */
  public static final String MSG_ANTIALIAS = "antialias";

  public static final String MSG_FRACTIONAL_METRICS = "fractional_metrics";

  //cx.g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_NORMALIZE);  -- lots slower


  public static final String ATTR_ANTIALIASING = "antialiasing";
  public static final String ATTR_FRACTIONAL_METRICS = "fractional-metrics";

  /** Title string to use for antialiasing menu item. */
  public static final String ATTR_AATITLE = "title";

  public static final String VALUE_FORCE_ON = "force-on";
  public static final String VALUE_FORCE_OFF = "force-off";
  public static final String VALUE_USER_ON = "user-on";
  public static final String VALUE_USER_OFF = "user-off";
  /** Same effect as {@link #VALUE_USER_OFF}. */
  public static final String VALUE_USER = "user";
  public static final String VALUE_UNSET = "unset";

  static final String AATITLE_DEFAULT = "Antialiasing";


  /** Control: invalid / force / user. */
  String acont_ = VALUE_UNSET, fcont_ = VALUE_UNSET;    // true; -- off = faster, on = better looking!

  /** Setting: off/on. */
  boolean anti_ = false, fract_ = false;    // true; -- off = faster, on = better looking!

  /** Stashed values outside of current paintBefore/paintAfter. */
  private Object aain_ = null, fmin_ = null;

  String aatitle_;


  public void buildBefore(Document doc) {
	super.buildBefore(doc);

	if (acont_!=VALUE_UNSET || fcont_!=VALUE_UNSET) getDocument().addObserver(this);
//System.out.println("build.  add? "+(acont_!=VALUE_UNSET || fcont_!=VALUE_UNSET));
  }



  public boolean semanticEventBefore(SemanticEvent se, String msg) {
	if (super.semanticEventBefore(se, msg)) return true;
	else if (VMenu.MSG_CREATE_VIEW==msg) {
		INode menu = (INode)se.getOut();
		Browser br = getBrowser();
		if (acont_==VALUE_USER_ON || acont_==VALUE_USER_OFF) {
			SemanticEvent seout = new SemanticEvent(br, MSG_ANTIALIAS, null, this, null);
			// when antialiasing performance on full-screen on our graphics cards/drivers is better, change back accepting sem ev from any source and hardcode title
			VCheckbox cb = (VCheckbox)createUI("checkbox", aatitle_, seout, menu, "View", false);
			cb.setState(anti_);
		}

		if (fcont_==VALUE_USER_ON || fcont_==VALUE_USER_OFF) {
			SemanticEvent seout = new SemanticEvent(br, MSG_FRACTIONAL_METRICS, null, this, null);
			VCheckbox cb = (VCheckbox)createUI("checkbox", "Fractional Metrics", seout, menu, "View", false);
			cb.setState(fract_);
		}
	}
	return false;
  }

  public boolean semanticEventAfter(SemanticEvent se, String msg) {
	if (aatitle_!=AATITLE_DEFAULT && se.getIn()!=this) {
		// ignore messages from other FontRender instances

	} else if (MSG_ANTIALIAS==msg) {
		if (acont_==VALUE_USER_ON || acont_==VALUE_USER_OFF) {
			anti_ = Booleans.parseBoolean(se.getArg(), !anti_);
			getBrowser().repaint();
		}

	} else if (MSG_FRACTIONAL_METRICS==msg) {
		if (fcont_==VALUE_USER_ON || fcont_==VALUE_USER_OFF) {
			fract_ = Booleans.parseBoolean(se.getArg(), !fract_);
			getBrowser().repaint();
		}
	}
	return super.semanticEventAfter(se, msg);
  }



  public boolean paintBefore(Context cx, Node node) {
	if (super.paintBefore(cx, node)) return true;

	//else if (java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getFullScreenWindow() != null) {}  // full screen is wacky enough as is

	else {
		aain_ = cx.g.getRenderingHint(RenderingHints.KEY_ANTIALIASING);
		if (acont_!=VALUE_UNSET) cx.g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, anti_? RenderingHints.VALUE_ANTIALIAS_ON: RenderingHints.VALUE_ANTIALIAS_OFF);

		fmin_ = cx.g.getRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS);
		if (fcont_!=VALUE_UNSET) cx.g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, fract_? RenderingHints.VALUE_FRACTIONALMETRICS_ON: RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
	}
	return false;
  }

  public boolean paintAfter(Context cx, Node node) {
	if (acont_!=VALUE_UNSET) cx.g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, aain_);
	if (fcont_!=VALUE_UNSET) cx.g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, fmin_);
	return super.paintAfter(cx, node);
  }



  public void restore(ESISNode n, Map<String,Object> attr, Layer layer) {
	super.restore(n, attr, layer);

	String o = getAttr(ATTR_ANTIALIASING, VALUE_UNSET).intern(); if (o==VALUE_USER) o=VALUE_USER_ON;
//System.out.println("aa = "+o);
	acont_ = o;
	anti_ = (VALUE_FORCE_ON==o || VALUE_USER_ON==o);

	o = getAttr(ATTR_FRACTIONAL_METRICS, VALUE_UNSET).intern(); if (o==VALUE_USER) o=VALUE_USER_ON;
	fcont_ = o;
	fract_ = (VALUE_FORCE_ON==o || VALUE_USER_ON==o);
//System.out.println("fm = "+o);

	aatitle_ = getAttr(ATTR_AATITLE, AATITLE_DEFAULT);
  }
}
