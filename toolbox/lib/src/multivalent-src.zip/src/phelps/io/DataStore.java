package phelps.io;

import java.io.IOException;
import java.io.RandomAccessFile;

//import phelps.io.BufferedRandomAccessFile; -- shouldn't have many disk accesses so shouldn't make much difference



/**
	Data is stored in a continuous stream, with new data appended.
	A data segment starts with a signature ('jdbm'), followed by the size of the current data, followed by the size of the original data, followed by the raw data.
	If new data has overwritten the old in place, and the new data is shorter than the old,
	then the segment length will be greater than the original size.
	A current length of -1L indicates deleted data.

	@see FileHash
	@see KeyStore
*/
class DataStore {
  //public static final String SIGNATURE = "jdbm";    // for crash recovery and debugging -- kill this 4-bytes per datum overhead?  set to 0-length so can change mind?
  static final int INT_LENGTH = 4, LONG_LENGTH = 8;
  static final int HEADER_LENGTH = /*countUTF(SIGNATURE) +*/ LONG_LENGTH * 2;    // lengths stored at 8-byte binary numbers, even though Java won't allocate arrays that large yet.

  class Rec {
	long offset;
	//String sig;
	long curlen, origlen;
	//byte[] data;
	Rec(long offset, /*String sig,*/ long curlen, long origlen) {
		this.offset=offset; /*this.sig=sig;*/ this.curlen=curlen; this.origlen=origlen;
	}
  }

  /*Buffered*/RandomAccessFile raf_;
  int cnt_;

  public DataStore(String filename) throws IOException {
	//raf_ = new /*Buffered*/RandomAccessFile(filename, "rw");

	if (raf_!=null && raf_.length() > 0) {   // already exists, read old state
		// # records -- must match with keystore's

		//RandomAccessFile free = new BufferedRandomAccessFile(filename+".data", "r");
		//free.close();

	} else {    // init new
		cnt_ = 0;
	}

  }


  /**
	Write data record at <var>posn</var>.
	Record format: signature (UTF string), current length of data (8 byte binary number), original length of data (8 byte binary number).
	@param posn     position of record to replace (overwrite if possible or append if not), or -1 to append

	@return posn of new record
  */
  public long writeRecord(long posn,  byte[] data, int offset, int length) throws IOException {
	assert data!=null;
	assert offset+length <= data.length;
	assert posn==FileHash.NO_RECORD || (posn>=0L && posn <= raf_.length()): posn;

	long newposn = FileHash.NO_RECORD, oldlength = length;     // assume appending new record

	// replacing existing record?
	if (posn >= 0L) try {
		Rec rec = readHeader(posn);
		if (length <= rec.origlen) {
			newposn = posn;
			oldlength = rec.origlen;     // overwrite old data, wasting excess

		} else {
			// else check free list
			//newposn = some other old data; oldlength = ...

			// delete old record
			writeRecordRaw(posn, null,0,-1, rec.origlen);
			// add old to free list...
		}
	} catch (InstantiationException ignore) {}

	if (newposn == FileHash.NO_RECORD) newposn = raf_.length();    // append, because no such key or new data doesn't fit


	writeRecordRaw(newposn, data, offset, length, oldlength);

	return newposn;
  }

  /**
	Write data record at current file position.
	All lowest level record writing done here to ensure uniformity.
	No error checking is done in parameters.
  */
  void writeRecordRaw(long posn, byte[] data, int offset, int length, long oldlength) throws IOException {
	raf_.seek(posn);

	//raf_.writeUTF(SIGNATURE);
	raf_.writeLong(length); raf_.writeLong(oldlength);
	if (length>=0) raf_.write(data, offset, length);
  }

  public void removeRecord(long posn) throws IOException {
	if (posn >= 0L) try {
		Rec rec = readHeader(posn);
		writeRecordRaw(posn, null,0,-1, rec.origlen);
	} catch (InstantiationException ignore) {}
  }

  /**
	Read data header.
	Leaves data file position at start of data.
  */
  Rec readHeader(long posn) throws InstantiationException, IOException {
	assert posn <= raf_.length() + HEADER_LENGTH;
	raf_.seek(posn);

	//String sig = raf_.readUTF();
	//if (!SIGNATURE.equals(sig)) throw new InstantiationException("invalid signature on data record @ "+posn);

	long curlen = raf_.readLong(), seglen = raf_.readLong();
	assert curlen <= seglen: curlen+" > "+seglen;

	// leave file position at start of data

	return new Rec(posn, /*sig,*/ curlen, seglen);
  }

  /**
	Read data record at <var>posn</var>.
	@throws {@link java.lang.InstantiationException} if not at record boundary or data corrupted.
  */
  public byte[] readRecord(long posn) throws InstantiationException, IOException {
	Rec rec = readHeader(posn);

	byte[] data = new byte[(int)rec.curlen];
	raf_.read(data);
	return data;
  }

  /**
	Read as much of data record at <var>posn</var> into range of passed bytes array.
	@throws {@link java.lang.InstantiationException} if not at record boundary or data corrupted.
  */
  public byte[] readRecord(long posn,  byte[] b, int offset, int length) throws InstantiationException, IOException {
	Rec rec = readHeader(posn);

	raf_.read(b, offset, Math.min(length, (int)rec.curlen));
	return b;
  }


  public void flush() throws IOException {
	//raf_.flush();
  }

  public void close() throws IOException {
	flush();
	raf_.close();
  }
}
