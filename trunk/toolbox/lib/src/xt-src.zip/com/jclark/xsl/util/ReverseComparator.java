// $Id: ReverseComparator.java,v 1.1 2002/04/25 18:20:44 bill Exp $

package com.jclark.xsl.util;

public class ReverseComparator implements Comparator 
{
    private Comparator cmp;

    public ReverseComparator(Comparator cmp) 
    {
        this.cmp = cmp;
    }

    public int compare(Object o1, Object o2) 
    {
        return -cmp.compare(o1, o2);
    }
}
