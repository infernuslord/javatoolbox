package multivalent.std.adaptor.pdf;

import java.awt.Color;

import multivalent.*;

import phelps.awt.Colors;
import phelps.awt.NFont;



/**
	A span that can set any PDF graphic state attribute: stroke color, fill color, font, Tr.

	@version $Revision: 1.3 $ $Date: 2003/08/29 04:14:35 $
*/
public class SpanPDF extends Span {
  public Color stroke=Context.COLOR_INVALID, fill=Context.COLOR_INVALID;
  public NFont font=null;
  public int Tr = -1;

/* doesn't add to layer...
  public SpanPDF(SpanPDF copyme) {
	stroke = copyme.stroke;
	fill = copyme.fill;
	font = copyme.font;
	Tr = copyme.Tr;
  }*/

  public boolean appearance(Context cx, boolean all) {
	if (stroke!=Context.COLOR_INVALID) { cx.strokeColor=stroke; }
	if (fill!=Context.COLOR_INVALID) { cx.foreground=fill; }
	if (font!=null) {
		/*		if (font instanceof phelps.awt.font.NFontAWT) {
//System.out.println("SpanPDF "+font.getFamily()+" "+font.getSize()+" "+font.getStyle());
			cx.family=font.getFamily(); cx.size=(float)font.getSize(); cx.style=font.getStyle();
		} else*/ cx.spot = font;
	}

	// PDF-specific
	//PDFContext pcx = (PDFContext)cx;

	/*
	0 Fill text [usual]
	1 Stroke text [outline]
	2 Fill, then stroke, text
	3 Neither fill nor stroke text (invisible) [used in scanned paper]
	4 Fill text and add to path for clipping (see above)
	5 Stroke text and add to path for clipping
	6 Fill, then stroke, text and add to path for clipping
	7 Add text to path for clipping
	*/
	if (Tr==3) cx.foreground = Colors.TRANSPARENT;

	return false;
  }

  public String toString() {
	StringBuffer sb = new StringBuffer(20);
	sb.append(getName());
	if (font!=null) sb.append(font.getFamily()).append(':').append(font.getSize()).append('/').append(font.getWeight()).append('/').append(Integer.toHexString(font.getFlags()));
	if (fill!=Context.COLOR_INVALID) sb.append("/F");
	if (stroke!=Context.COLOR_INVALID) sb.append("/S");
	return sb.toString();
  }
}
