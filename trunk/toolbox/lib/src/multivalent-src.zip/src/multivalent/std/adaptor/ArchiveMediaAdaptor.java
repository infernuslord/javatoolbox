package multivalent.std.adaptor;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.net.URI;

import multivalent.*;
//import multivalent.std.adaptor.MediaAdaptorByte;
import multivalent.gui.VMenu;
import multivalent.gui.VRadiobox;
import multivalent.gui.VRadiogroup;


// SHOULD BE INTERFACE + SEPARATE SHARED BEHAVIOR IN HUB


/**
	Superclass for archive media adaptors, such as zip/jar, sit, tar, do/dsk, po/raw.

	<p>Common services:
	<ul>
	<li>reporting catalog (LATER: common/standard and specific)
	<li>extraction of file (LATER: even if archive is remote)
	<li>reporting file suffixes and MIME types understood (put this in MediaAdaptor?)
	<li>Types if display: standard (UNIX <tt>ls</tt> style), verbose (all information, including checksum), fulltext (for full-text indexing).
	</ul>

	<p>Maybe later define additional file operations, such as delete, rename, add, ....

	@version $Revision: 1.2 $ $Date: 2002/02/01 08:55:52 $
*/
public abstract class ArchiveMediaAdaptor extends MediaAdaptorByte {
  static final boolean DEBUG=false;

  public static final String MSG_SORTBY = "DirectoryMediaAdaptor/SortBy";

  public static final String PREF_SORTBY = "DirectoryMediaAdaptor/SortBy";
  public static final String FILENAME = "filename", LENGTH = "length", LASTMOD = "lastModified", NONE = "none";

  public static final String ALLFILES = new String();


  //boolean verbose = false;  -- class-visible variables not inherited!
  protected boolean verbose = false;
  protected boolean fulltext = false;
  protected boolean standard = false;


  public abstract File extractFile(File archive, String filename, File outdir) throws IOException;
  //public abstract InputStream getInputStream(File archive, String filename) throws IOException;

  protected abstract String[] getPatterns();

  public abstract List<ArchiveFileEntry> getCatalog(File archive) throws IOException;

  /**
	If {@link Document#MSG_OPEN} on a file within the archive (not in file system),
	and up to arg instanceof DocInfo stage,
	and file not in cache,
	then sneak it (so eventBefore) into cache so whatever media adaptor can find it.
	On remote http, server doesn't know about treating .zip as a special file system directory,
	so it works best on the local file system -- until we move to Cache as ordinary behavior among others that can set InputStream.
	<b>Put this in System.hub so works on all URIs, not just from within .zip directory listing.</b>
  */
  public boolean semanticEventBefore(SemanticEvent se, String msg) {
	if (super.semanticEventAfter(se, msg)) return true;

	Object arg = se.getArg();
	if (Document.MSG_OPEN==msg && arg instanceof DocInfo) {
		DocInfo di = (DocInfo)arg;
		URI uri = di.uri;
//if (DEBUG) System.out.println("*** examining "+uri);
		String filename=uri.getPath(), lcfile=filename.toLowerCase();
		// iterator over suffixes, set length of suffix that matches
		String[] pat = getPatterns();
		int inx=-1;
		for (int i=0,imax=(pat!=null?pat.length:0); i<imax; i++) if ((inx=lcfile.indexOf(pat[i]))!=-1) { inx+=pat[i].length(); break; }
		if (inx==-1) return false;

		Cache cache = getGlobal().getCache();
		URI zipuri=null; try { zipuri=uri.resolve(filename.substring(0,inx-1)); } catch (IllegalArgumentException male) { System.out.println("bad URI: "+male); }
if (DEBUG) System.out.println("zipuri = "+zipuri);
		// LATER: if no .zip and remote URI, fetch it
		File zipf;
		if (inx!=-1 && "file".equals(uri.getScheme())/*<-- for now*/ && (zipf=cache.mapTo(zipuri,null, Cache.COMPUTE)).exists() && !zipf.isDirectory()) {
if (DEBUG) System.out.println("*** yep");
			try {
				File f = cache.getOutputFile(uri, null, Cache.CACHEONLY, null);
if (DEBUG) System.out.println("*** looking in cache at "+f);
				if (!f.exists()) {
if (DEBUG) System.out.println("*** not found in cache, searching in zip");
					// LATER: keep count and when have asked for n or n%, extract entire archive so don't have to paw over directory all the time
					String tail = filename.substring(inx);
					extractFile(zipf, tail, f.getParentFile()); //cache.getOutputFile(zipuri, null, Cache.CACHEONLY, null));
				}
			} catch (IOException ioe) {
if (DEBUG) System.out.println("*** error: "+ioe);
			}
//System.exit(0);
		}
	}
	return false;
  }

  public boolean semanticEventAfter(SemanticEvent se, String msg) {
	if (VMenu.MSG_CREATE_VIEW==msg) {
		String type = getPreference(PREF_SORTBY, FILENAME);
		String[] titles = { "Default Sort by Filename", "Default Sort by Length", "Default Sort by Last Modified", "Natural Ordering (No Sorting)" };
		String[] vals = { FILENAME, LENGTH, LASTMOD, NONE };
		VRadiogroup rg = new VRadiogroup();
		Browser br = getBrowser();
		for (int i=0,imax=titles.length; i<imax; i++) {
			VRadiobox radio = (VRadiobox)createUI("radiobox", titles[i], new SemanticEvent(br, PREF_SORTBY, vals[i]), (INode)se.getOut(), "SortBy", false);
			radio.setRadiogroup(rg);
			if (type.equals(vals[i])) rg.setActive(radio);
//System.out.println("state = "+type.equals(vals[i])+"/"+radio.getState());
		}

	} else if (MSG_SORTBY==msg) {
		String type = getPreference(PREF_SORTBY, FILENAME);
		Object o = se.getArg();
		if (o instanceof String) {
			String newtype = ((String)o).intern();
			if (newtype!=type && (newtype==FILENAME || newtype==LENGTH || newtype==LASTMOD || newtype==NONE)) {
				putPreference(PREF_SORTBY, newtype);
				getBrowser().eventq(Document.MSG_RELOAD, null);  // more efficient way, but don't know details of subclass field ordering (which might adhere to the native display)
			}
		}
	}

	return super.semanticEventAfter(se,msg);
  }
}


/*
if (DEBUG) System.out.println("*** write to "+cache.getOutputStream(uri, null, Cache.CACHEONLY, null));
					OutputStream out = new BufferedOutputStream(cache.getOutputStream(uri, null, Cache.CACHEONLY, null));
if (DEBUG) System.out.println("*** write to "+out);
					//InputStream in = new BufferedInputStream(zf.getInputStream(ze));
					InputStream in = new BufferedInputStream(getInputStream(f, tail)); phelps.io.Streams.copy(in, out); in.close();
if (DEBUG) System.out.println("*** read from "+in);
					out.close();
if (DEBUG) System.out.println("*** extracted");
*/
