/*
 * Created on Feb 17, 2004
 */
package edu.uci.ics.jung.visualization;

import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import edu.uci.ics.jung.graph.Vertex;

/**
 * This class translates mouse clicks into vertex clicks
 * 
 * @author danyelf
 */
public class MouseListenerTranslator extends MouseAdapter {

	private VisualizationViewer vv;
	private GraphMouseListener gel;

	/**
	 * @param gel
	 * @param vv
	 */
	public MouseListenerTranslator(GraphMouseListener gel, VisualizationViewer vv) {
		this.gel = gel;
		this.vv = vv;
	}

	/**
	 * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
	 */
	public void mouseClicked(MouseEvent e) {
	    // adjust for scale and offset in the VisualizationViewer
	    Point p = new Point((int)(e.getX()/vv.scalex+vv.offsetx), (int)(e.getY()/vv.scaley+vv.offsety));
		Vertex v = vv.layout.getVertex(p.getX(), p.getY());
		if ( v != null ) {
			gel.graphClicked(v, e );
		}
	}

	/**
	 * @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
	 */
	public void mousePressed(MouseEvent e) {
	    // adjust for scale and offset in the VisualizationViewer
	    Point p = new Point((int)(e.getX()/vv.scalex+vv.offsetx), (int)(e.getY()/vv.scaley+vv.offsety));
		Vertex v = vv.layout.getVertex(p.getX(), p.getY());
		if ( v != null ) {
			gel.graphPressed(v, e );
		}
	}

	/**
	 * @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
	 */
	public void mouseReleased(MouseEvent e) {
	    // adjust for scale and offset in the VisualizationViewer
	    Point p = new Point((int)(e.getX()/vv.scalex+vv.offsetx), (int)(e.getY()/vv.scaley+vv.offsety));
		Vertex v = vv.layout.getVertex(p.getX(), p.getY());
		if ( v != null ) {
			gel.graphReleased(v, e );
		}
	}
}
