package phelps.text;

import java.awt.geom.Rectangle2D;
import java.util.Calendar;
import java.text.DateFormat;
import java.text.ParseException;



/**
	Pretty printing.

	<ul>
	<li>pretty printing: {@link #relativeDate(long,long)} / {@link #relativeDate(long) (long)},
		{@link #prettySize(long)}, {@link #pretty(Rectangle2D)}.

		Additional pretty printing available in other classes:
		{@link phelps.net.URIs#relativeURL(URL, URL)},
		{@link phelps.io.Files#relative(File, File)},
		{@link phelps.lang.Integers#toRomanString(int)},
		{@link phelps.lang.Integers#toRange(int[])}
	</ul>

	@version $Revision: 1.4 $ $Date: 2003/07/26 02:14:32 $
*/
public class Formats {
  private static final long SECOND=1, MINUTE=60*SECOND, HOUR=60*MINUTE, DAY=24*HOUR, WEEK=7*DAY;
	// => take these from DateFormatSymbols
  private static final String[] int2dayOfWeek = { "XXX", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
  private static final String[] int2day = { "XXX", "Sun", "Mon", "Tues", "Wed", "Thu", "Fri", "Sat" };
  private static final String[] int2month = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
  private static final String[] int2mon = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
  private static final String[] ampm = { "am", "pm" };


  private static DateFormat dateFormat_ = null;     // create on demand
  private static Calendar cal_ = null;

  private Formats() {}


  /**
	Parse <var>sdate</var> and pass on to {@link #relativeDate(long)}.
	<var>sdate</var> can either be a number, in the standard Java milliseconds since 1970,
	or a human-readable date that was produced by {@link java.util.Date#toString()}.
  */
  public static long parseDate(String sdate) throws ParseException {
	long date=-1;

	try {
		long idate = Long.parseLong(sdate);
		//return relativeDate(idate);
		return idate;
	} catch (NumberFormatException nfe) {}

	if (dateFormat_==null) dateFormat_ = DateFormat.getDateTimeInstance();   // should use static copy
	dateFormat_.setLenient(true);
	try {
		date = dateFormat_.parse(sdate).getTime();
	} catch (ParseException pe) {
		System.out.println("old date parsing: "+sdate); //-- always seems to be old
		//date = new Date(sdate);	// try old Date class -- I know it's deprecated
	}

	if (date == -1) throw new ParseException("can't parse  date as either number or humand readable: "+sdate, -1);

	return date;
	//return relativeDate(date);
  }

  /** Display <var>date</var> {@link #relativeDate(long,long) relative} to now. */
  public static String relativeDate(long date) { return relativeDate(date, System.currentTimeMillis()); }

  /**
	Display <var>date</var>, in the standard Java milliseconds since 1970, relative to <var>relativeTo</var>,
	using relations like "yesterday" and "3 hours ago".
  */
  public static String relativeDate(long date, long relativeTo) { //return relativeDate(new Date(date), new Date(relativeTo)); }
	long diffsec=(relativeTo-date)/1000; boolean future=(diffsec<0);
	String ago = " ago";
	if (future) { diffsec=-diffsec; ago=""; }	// => should leave "+/-" and "...ago" to caller

	if (diffsec<2*MINUTE) return (future?"+":"")+diffsec+" seconds"+ago;
	else if (diffsec<2*HOUR) return (future?"+":"")+(diffsec/MINUTE)+" minutes"+ago;
	else if (diffsec<24*HOUR) return (future?"+":"")+(diffsec/HOUR)+" hours"+ago;

	// should take output format from a preference pattern
	if (cal_==null) cal_=Calendar.getInstance();
	Calendar cal = cal_;
	cal.setTimeInMillis(date);
	int hour=cal.get(Calendar.HOUR_OF_DAY), min=cal.get(Calendar.MINUTE), month=cal.get(Calendar.MONTH);
	if (diffsec<2*DAY) return hour+":"+(min<10?"0":"")+min+(future? " tomorrow":" yesterday");
	else if (diffsec<WEEK) return hour+":"+(min<10?"0":"")+min+" "+int2dayOfWeek[cal.get(Calendar.DAY_OF_WEEK)];
	else if (diffsec<45*WEEK) return cal.get(Calendar.DAY_OF_MONTH)+" "+int2month[month];
	return cal.get(Calendar.DAY_OF_MONTH)+" "+int2month[month]+" "+cal.get(Calendar.YEAR);
  }



  private static final String[] KSUFFIX = { "bytes", "KB", "MB", "GB", "TB", "EB" };
  /** Given a byte count, returns a string in more human-readable form; e.g., 13*1024*1024 => "13MB". */
  public static String prettySize(long bytes) {
	if (bytes==0) return "0 bytes"; else if (bytes==1) return "1 byte"; else if (bytes==-1) return "-1 byte";	 // special cases

	long sign = (bytes>=0? 1: -1);
	bytes = Math.abs(bytes);
	long K = 1024, div=0, rem=0;
	int sfxi = 0;
	while (bytes > K && sfxi+1<KSUFFIX.length) {
		div=bytes/K; rem=bytes - div*K;
		bytes = div;
		sfxi++;
	}
	return Long.toString(sign*bytes)+(rem>0?".":"")+(bytes<=10 && rem>0? Long.toString((rem*10)/K): "")+" "+KSUFFIX[sfxi];
  }

  // parseSize(String) ...


  /** Compact output for a Rectangle: <var>width</var>x<var>height</var> @ (<var>x</var>,<var>y</var>). */
  public static String pretty(Rectangle2D r) { return ""+r.getWidth()+"x"+r.getHeight()+"@("+r.getX()+","+r.getY()+")"; }

  //public static String prettyMillis(long millis) {}

  /** Formats <var>sec</var>onds as <code>days/HH:MM:SS</code>. */  // d h m s more understandable than colons?
  public static String prettySeconds(int sec) {
	int mins = sec/60; sec -= mins*60;
	int hours = mins/60; mins -= hours*60;
	int days = hours/24; hours -= days*24;
	//int months = days/30;
	//int years = days / 365;

	StringBuffer sb = new StringBuffer(100);
	boolean ffill = false;
	//if (hours>0) sb.append(hours).append(" hour").append(hours>1? "s": "");
	if (days>0) { sb.append(days).append("/"); ffill=true; }
	if (hours>0) { sb.append(hours).append(":"); ffill=true; }
	if (mins>0 || ffill) { sb.append(mins<10 && ffill? "0": "").append(mins).append(":"); ffill=true; }
	/*if (true)*/ sb.append(sec<10 && ffill? "0": "").append(sec);

	return sb.toString();
  }
}
