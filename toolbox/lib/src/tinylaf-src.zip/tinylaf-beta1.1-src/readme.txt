TinyLaF beta 1.1
================


Please read the file license.txt for license information.

----------------------------------------------------------------------------------

Required JRE: 1.4.0 or later.

----------------------------------------------------------------------------------

To start the control panel, double-click tinylaf.jar or execute:

java -jar tinylaf.jar

----------------------------------------------------------------------------------

To make TinyLaF the current L&F for your application, include this line:

UIManager.setLookAndFeel("de.muntjak.tinylookandfeel.HBLookAndFeel");

at the beginning of your main method. (You will have to catch any exceptions).

If a default theme file (file name: 'Default.theme') exists in the user directory
of your application , this file will be loaded at startup.

(Additional ways to define the L&F can be found in the API docs: api/javax/swing/UIManager.html)

----------------------------------------------------------------------------------

To try the 'Decorated Frames' feature, include the following two lines (or maybe
just one) in your source code BEFORE THE FIRST FRAME IS MADE VISIBLE:

JFrame.setDefaultLookAndFeelDecorated(true);	// to decorate frames
JDialog.setDefaultLookAndFeelDecorated(true);	// to decorate dialogs

The flicker which appears when resizing a decorated frame is not supposed to
be a bug, but I'd be VERY happy, if someone could tell me, how to prevent it.

----------------------------------------------------------------------------------

Changes since Beta 1:

	Fixed: JProgressBar.getFont() returning null. Aditionally one can set the font for JProgressBar now.
	Fixed: JProgressBar now displays strings even when in indeterminate mode.
	Fixed: Defining TinyLaF as the standard L&F in swing.properties threw exceptions (PanelUI not found).
		This is fixed.
	Fixed: ButtonUI now honours isBorderPainted and isContentAreaFilled properties.
	Fixed: Border of JToolBar now isn't painted if set to null or isBorderPainted resolves to false.
	Fixed: Border of JTextField and JComboBox now isn't painted if set to null.
	Fixed: Due to a bug in BasicProgressBarUI (unfortunately in a private method, caused by a private
		member) sometimes a NullPointerException was thrown soon after the ControlPanel started.
		Because this exception is harmless, I decided to catch it.

	Changed: Removed Popup Font.
	Changed: Added ProgressBar Font together with two additional text colors in Decoration/ProgressBar.
	Changed: File format changed slightly due to previous changes. 1.0-themes can still be loaded, but
		saved themes are not compatible with TinyLaF-1.0


----------------------------------------------------------------------------------

I hope, this files will be useful for you and have fun, creating your own themes.

9.6.2003   Hans Bickel

----------------------------------------------------------------------------------

The latest version of TinyLaF can be found at:

http://www.muntjak.de/hans/java/tinylaf/

Please send bug-reports, suggestions, feedback to: hb@muntjak.de
