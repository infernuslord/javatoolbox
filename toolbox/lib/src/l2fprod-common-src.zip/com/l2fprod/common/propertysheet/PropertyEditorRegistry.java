/** ===================================================================
 *
 * @PROJECT.FULLNAME@ @VERSION@ License.
 *
 * Copyright (c) @YEAR@ L2FProd.com.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by L2FProd.com
 *        (http://www.L2FProd.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "@PROJECT.FULLNAME@", "@PROJECT.SHORTNAME@" and "L2FProd.com" must not
 *    be used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact info@L2FProd.com.
 *
 * 5. Products derived from this software may not be called "@PROJECT.SHORTNAME@"
 *    nor may "@PROJECT.SHORTNAME@" appear in their names without prior written
 *    permission of L2FProd.com.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL L2FPROD.COM OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package com.l2fprod.common.propertysheet;

import com.l2fprod.common.beans.editor.BooleanAsCheckBoxPropertyEditor;
import com.l2fprod.common.beans.editor.ColorPropertyEditor;
import com.l2fprod.common.beans.editor.DoublePropertyEditor;
import com.l2fprod.common.beans.editor.FilePropertyEditor;
import com.l2fprod.common.beans.editor.FloatPropertyEditor;
import com.l2fprod.common.beans.editor.IntegerPropertyEditor;
import com.l2fprod.common.beans.editor.LongPropertyEditor;
import com.l2fprod.common.beans.editor.ShortPropertyEditor;
import com.l2fprod.common.beans.editor.StringPropertyEditor;

import java.awt.Color;
import java.beans.PropertyEditor;
import java.beans.PropertyEditorManager;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * PropertyEditorRegistry. <br>Mapping between Properties, Property Types and
 * Property Editors.
 */
public class PropertyEditorRegistry {

  private Map typeToEditor;
  private Map propertyToEditor;

  public PropertyEditorRegistry() {
    typeToEditor = new HashMap();
    propertyToEditor = new HashMap();
    initialize();
  }

  public synchronized PropertyEditor getEditor(Property property) {
    PropertyEditor editor = null;
    Class editorClass = (Class)propertyToEditor.get(property);
    if (editorClass == null) {
      editor = getEditor(property.getType());
    } else {
      try {
        editor = (PropertyEditor)editorClass.newInstance();
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return editor;
  }

  public synchronized PropertyEditor getEditor(Class type) {
    PropertyEditor editor = null;
    Class editorClass = (Class)typeToEditor.get(type);
    try {
      editor = (PropertyEditor)editorClass.newInstance();
    } catch (Exception e) {
      e.printStackTrace();
    }
    return editor;
  }

  public synchronized void registerEditor(Class type, Class editorClass) {
    typeToEditor.put(type, editorClass);
  }

  public synchronized void unregisterEditor(Class type) {
    typeToEditor.remove(type);
  }
  
  public synchronized void registerEditor(
    Property property,
    Class editorClass) {
    propertyToEditor.put(property, editorClass);
  }

  public synchronized void unregisterEditor(Property property) {
    propertyToEditor.remove(property);
  }
  
  /**
   * Adds default editors
   */
  private void initialize() {
    // our editors
    registerEditor(String.class, StringPropertyEditor.class);

    registerEditor(double.class, DoublePropertyEditor.class);
    registerEditor(Double.class, DoublePropertyEditor.class);
    
    registerEditor(float.class, FloatPropertyEditor.class);
    registerEditor(Float.class, FloatPropertyEditor.class);
    
    registerEditor(int.class, IntegerPropertyEditor.class);
    registerEditor(Integer.class, IntegerPropertyEditor.class);
    
    registerEditor(long.class, LongPropertyEditor.class);
    registerEditor(Long.class, LongPropertyEditor.class);

    registerEditor(short.class, ShortPropertyEditor.class);
    registerEditor(Short.class, ShortPropertyEditor.class);
    
    registerEditor(boolean.class, BooleanAsCheckBoxPropertyEditor.class);
    registerEditor(Boolean.class, BooleanAsCheckBoxPropertyEditor.class);
    
    registerEditor(Color.class, ColorPropertyEditor.class);
    
    registerEditor(File.class, FilePropertyEditor.class);
    
    // sun editors from PropertyEditorManager
    registerEditor(
      byte.class,
      PropertyEditorManager.findEditor(byte.class).getClass());
  }
}
