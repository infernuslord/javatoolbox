/*
 * Sun Public License Notice The contents of this file are subject to the Sun
 * Public License Version 1.0 (the "License"). You may not use this file except
 * in compliance with the License. A copy of the License is available at
 * http://www.sun.com/ The Original Code is the Jemmy library. The Initial
 * Developer of the Original Code is Alexandre Iline. All Rights Reserved.
 * Contributor(s): Alexandre Iline. $Id: MenuDriver.java,v 1.4 2003/02/19
 * 04:07:09 jemmy Exp $ $Revision: 1.4 $ $Date: 2003/02/19 04:07:09 $
 */

package org.netbeans.jemmy.drivers;

import org.netbeans.jemmy.operators.ComponentOperator;

/**
 * Defines how to work with manus.
 * 
 * @author Alexandre Iline (alexandre.iline@sun.com)
 */
public interface MenuDriver
{

    /**
     * Pushes menu.
     * 
     * @param oper Menu operator.
     * @param chooser Object defining menupath.
     * @return a result of menu pushing. It could be last pushed menuitem or
     *         anything else.
     */
    public Object pushMenu(ComponentOperator oper, PathChooser chooser);
}