// $Id: LastFunction.java,v 1.1 2002/04/25 18:08:19 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

class LastFunction extends Function0 {
    ConvertibleExpr makeCallExpr() {
        return new ConvertibleNumberExpr() {
                public double eval(Node node, ExprContext context) throws XSLException {
                    return context.getLastPosition();
                }
            };
    }
}
