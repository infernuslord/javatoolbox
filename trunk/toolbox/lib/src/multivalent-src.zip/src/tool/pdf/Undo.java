package tool.pdf;

import java.io.File;
import java.io.RandomAccessFile;
import java.io.IOException;
import java.io.PrintStream;

import multivalent.ParseException;
import multivalent.std.adaptor.pdf.PDFReader;
import multivalent.std.adaptor.pdf.COS;
import multivalent.std.adaptor.pdf.Dict;

import phelps.io.Files;
import phelps.io.RandomAccess;



/**
	Undo last incremental update.

	@version $Revision: 1.1 $ $Date: 2003/08/09 08:25:46 $
*/
public class Undo {
  static final boolean DEBUG = true;

  public static final String VERSION = "1.0 of $Date: 2003/08/09 08:25:46 $";
  public static final String USAGE = "java tool.pdf.Undo [-inplace] <PDF-file>";

  private boolean finplace_;
  private boolean fverbose_, fquiet_;
  private PrintStream out_;


  public Undo() {
	defaults();
  }

  public void defaults() {
	fverbose_ = false;
	out_ = phelps.io.PrintStreams.DEVNULL;
  }

  //public void setInplace(boolean b) { finplace_ = b; } => null for fileout


  /** Returns true iff PDF successfully undone.  If <var>fileout</var> is <code>null</code> compute a name. */
  public boolean undo(File filein, File fileout) throws IOException, ParseException {
	if (fverbose_) System.out.println(filein);
    assert filein!=null && filein.exists();

	if (fileout==null) {
		String path = filein.getPath();
		String pathout = (path.toLowerCase().endsWith(".pdf")? path.substring(0,path.length()-".pdf".length()): path) + "-undo.pdf";
		fileout = new File(pathout);
	}

	PDFReader pdfr = null;
	try { 
		pdfr = new PDFReader(filein);
	} catch (ParseException pe) {
		System.err.println("Can't open "+filein); throw pe;
	} catch (IOException ioe) {
		System.err.println("Can't open "+filein); throw ioe;
	} 
	pdfr.setExact(true);	// incremental on /Compact

	// if startxref points to xref that's last in file and there's a /Prev to leave behind, the ok to chop
	// (Linearized have two xrefs but startxref points to first in file.)
	long startxref = pdfr.getStartXRef();
	Dict trailer = pdfr.getTrailer();
	Object o = trailer.get("Prev");
	if (o == null) {
		if (fverbose_) System.out.println("no incremental update");
		return false;
	}

	RandomAccess ra = pdfr.getRAF();
	// chase down /Prev to last in file before current last
	long prev0 = ((Number)o).longValue(), prev = 0L, prevmax = 0L;
	while (o!=null) {
		prev = ((Number)o).longValue();
		if (prev > prevmax) prevmax = prev;
		ra.seek(prev);
		trailer = pdfr.readXref(false);
		o = trailer.get("Prev");
	}

//System.out.println(startxref+", "+prevmax);
	if (startxref < prevmax) {
		if (fverbose_) System.out.println("no incremental update (Linearized)");
		return false;
	}

	if (prev != prevmax) { ra.seek(prevmax); pdfr.readXref(false); }
	long truncate = ra.getFilePointer();

	pdfr.close();


	// truncate
	if (!filein.getCanonicalPath().equals(fileout.getCanonicalPath())) Files.copy(filein, fileout);	// could just copy what's needed rather than copy everything and throw away

	RandomAccessFile raf = new RandomAccessFile(fileout, "rw");
	raf.setLength(truncate);
	raf.seek(truncate);
	raf.writeBytes("startxref\n"+prev0+"\n"+COS.EOF+"\n");
	raf.close();
	if (fverbose_) out_.println("truncated @ "+truncate);

	return true;
  }



  private int commandLine(String[] argv) {
	out_ = System.out;

	int argi = 0, argc = argv.length;
	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.equals("-inplace")) finplace_ = true;

		else if (arg.startsWith("-verb")) fverbose_ = true;
		else if (arg.startsWith("-q"/*uiet*/)) fquiet_ = true;
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.startsWith("-h"/*"elp"*/)) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	return argi;
  }

  public static void main(String[] argv) {
	Undo undo = new Undo();
    int argi = undo.commandLine(argv), argc = argv.length;

	// one file only
	if (argi+1 != argc) { System.err.println(USAGE); System.exit(0); }

	File file = new File(argv[argi]);
	try {
		undo.undo(file, undo.finplace_? file: null);
	} catch (Exception ioe) {
		System.err.println(file+": "+ioe);
		if (DEBUG) ioe.printStackTrace();
	}
  }
}
