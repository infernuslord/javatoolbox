// $Id: BooleanExpr.java,v 1.1 2002/04/25 18:04:59 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

public interface BooleanExpr
{
    boolean eval(Node node, ExprContext context) throws XSLException;
}
