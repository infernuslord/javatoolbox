package phelps.io;

import java.io.*;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Arrays;
import java.util.Comparator;
//import java.util.zip.*;
//import java.util.Enumeration;



/**
	Operations on a list of files.

	<ul>
	<li>iterators/collection: {@link #interator()}, {@link #depthFirstIterator()}, {@link #breadthFirstIterator()}, {@link #listFiles()}
	<li>group operations: {@link #delete()}, {@link #copy(File)},
		<!--{link #grep()}, {link #massRename()}-->
	<li>summary: {@link #length()}
	<!--li>min/max: {link #lastModified()}-->
	</ul>

	Writing a Unix <code>find</code> is just some tests inside an iterator loop.


	@see java.io.File
	@see phelps.io.FileFilterPattern

	@version $Revision: 1.11 $ $Date: 2003/08/07 03:27:42 $
*/
public class FileList /*implements java.lang.Iterable*/ {
  static final boolean DEBUG = false;

  //static final Pattern ZIP = Pattern.compile("(?i)[^/]\\.(zip|jar)$");


  FileFilter filter_;
  List<File> base_;
  //boolean fshowdir_ = true;
  //boolean fzip_ = false;
  boolean fsort_ = true;
  boolean fdirsfirst_ = false;


  public FileList(String base, FileFilter filter) {
	this(new String[] { base }, filter);
  }

  public FileList(String[] base, FileFilter filter) {
	this(base, 0, filter);
  }
  /**
	Part of <var>base</var> starting from <var>start</var>,
	for use by command-line commands that process the rest of <code>String[] argv</code> after options.
  */
  public FileList(String[] base, int start, FileFilter filter) {
	this(s2f(base, start), filter);
  }
  private static File[] s2f(String[] s, int start) {
	assert s!=null && start>=0;
	File[] f = new File[s.length - start];
	for (int i=start,imax=s.length; i<imax; i++) f[i-start] = Files.getFile(/*".",--implicit*/ s[i]); 
	return f;
   }

  public FileList(File base, FileFilter filter) {
	this(new File[] { base }, filter);
  }

  public FileList(File[] base, FileFilter filter) {
	base_ = Arrays.asList((File[])base.clone());   // don't filter base files(?).  If later decide to filter them, do so here, so iterators don't each have to consider.
	filter_ = filter;
  }

  public void addFile(File f) {
	assert f!=null;
	base_.add(f);
  }

  /** Include directories in file operations, including iterators.  Defaults to true.
  public boolean includeDirectories(boolean b) { fshowdir_ = b; }   // => could do with FileFilter
*/

  /** If <code>true</code> sorts filenames, per directory, in {@link Strings#DICTIONARY_CASE_INSENSITIVE_ORDER case-insensitive dictionary order}. */
  public void setSorted(boolean b) { fsort_ = b; }
  /** If <code>true</code>, reports, per directory, all the subdirectories then the rest of the files. */
  public void setDirsFirst(boolean b) { fdirsfirst_ = b; }
  /* * If <code>true</code>, recurses through directories to collect files.
  public void setRecuse(boolean b) { frecurse_ = b; }*/

/*
  // relative or absolute paths?  implicit: passed relative or absolute
  public void setCanonical(boolean b) {
	if (b) for (int i=0,imax=base_.length; i<imax; i++) {
		try { base_[i] = base_[i].getCanonicalFile(); } catch (IOException skip) {}
	}
  }

  public void setFilter(FileFilter filter) {
  }
  public void setFilter(Pattern regexp) {
	filter_ = new FileFilerPattern(regexp);
  }

  within a directory, not globally (which would require reading entire directory hierarchy)
  public void setDirectoriesFirst(boolean b) {
  }

  public void setReadable | setWriteable | setExist

*/
  /**
	Set to <code>true</code> to expand file iteration
	to include the entries of <code>.zip</code> and <code>.jar</code> files.
	Filters must only look at parts of files that are common to both {@link java.io.File} and {@link java.util.zip.ZipEntry},
	viz: length(), getPath()?, lastModified(), isDirectory(), exists() (returns true for ZipEntryFile), canRead(), canWrite()
	FileFilter must only use the methods
	FilenameFilter has no restrictions.

  public void openZip(boolean b) { fzip_ = b; }


  private class ZipEntryFile extends File {
	ZipEntry z_;
	ZipEntryFile(ZipEntry z) { z_ = z; }
	public String getName() {
	}
	public String getPath() {
	}
	//public String getParent() ?
	public boolean canRead() { return true; }
	public boolean canWrite() { return false; }
	public boolean exists() { return true; }
	public boolean isDirectory() { return z_.isDirectory(); }
	public boolean isFile() { return !isDirectory(); }
	public boolean isHidden() { return false; }
	public long lastModified() { return z_.getTime(); }
	public long length() { return z_.getSize(); }

	public boolean isAbsolute() {
	}
	public String getAbsolutePath() {
	}
	public String getCanonicalPath() throws IOException {
	}

	// could implement but don't
	public URL toURL() throws MalformedURLException {
	}
	public URI toURI() {
	}

	// unsupported operation exception / fail
	public File getAbsoluteFile() { unsupported(); return null; }
	public String getParentFile() { unsupported(); return null; }
	public File getCanonicalFile() throws IOException { unsupported(); return null; }
	public boolean delete() { return false; }
	public String[] list() { unsupported(); return null; }
	public String[] list(FilenameFilter filter) { unsupported(); return null; }
	public File[] listFiles() { unsupported(); return null; }
	public File[] listFiles(FilenameFilter filter) { unsupported(); return null; }
	public File[] listFiles(FileFilter filter) { unsupported(); return null; }
	public boolean mkdir() { return false; }
	public boolean mkdirs() { return false; }
	public boolean renameTo(File dest) { return false; }
	public boolean setLastModified(long time) { return false; }
	public boolean setReadOnly() { return false; }
	public void deleteOnExit() { unsupported(); }
	private void unsupported() { throw new java.lang.UnsupportedOperationException(); }

	/* not needed since not exposed
	public int compareTo(File pathname)
	public int compareTo(Object o)
	public boolean equals(Object obj)
	public int hashCode()
	public String toString()
	public static File[] listRoots()
	public static File createTempFile(String prefix, String suffix, File directory) throws IOException
	public static File createTempFile(String prefix, String suffix) throws IOException
	* /
  }*/

  private boolean accept(File f) {
	return filter_==null || filter_.accept(f);
	/*return (fnfilter_==null && ffilter_==null)
		|| (fnfilter_!=null && fnfilter_.accept(f.getPath()))
		|| (ffilter_!=null && ffilter_.accept(f));*/
  }

  private class FileOrder implements Comparator<File> {
	private boolean fsort_, fdir_;
	FileOrder(boolean fsort, boolean fdir) { fsort_=fsort; fdir_=fdir; }
	public int compare(File f1, File f2) {
		if (fdir_) {
			boolean d1 = f1.isDirectory(), d2 = f2.isDirectory();
			if (d1 && !d2) return -1; else if (!d1 && d2) return 1;
		}

		if (fsort_) return phelps.lang.Strings.DICTIONARY_CASE_INSENSITIVE_ORDER.compare(f1.getName(), f2.getName());

		return 0;
	}
  };

  private class dfs implements Iterator<File> {
	List<File> q_ = new ArrayList<File>(100);    // add and remove to end for efficiency
	File next_ = null;
	Comparator<File> comp_ = new FileOrder(fsort_, fdirsfirst_);

	dfs() {
		for (int i=base_.size()-1; i>=0; i--) q_.add(base_.get(i));
	}

	public boolean hasNext() {
		//<Matcher m = ZIP.matcher("");
		while (q_.size() > 0 && next_ == null) {
			File f = q_.remove(q_.size()-1);
			/*Object o = q_.remove(q_.size()-1);
			if (o instanceof ZipFile) { ((ZipFile)o).close(); continue; }
			File f = (File)o;*/

			if (f.isDirectory()) {
				if (f.canRead()) {
					File[] files = f.listFiles();
					Arrays.sort(files, comp_);
					for (int i=files.length-1; i>=0; i--) {
						File sub = files[i];
						if (accept(sub) || sub.isDirectory()) q_.add(sub);
					}
				}
				if (accept(f)) next_ = f;

			//} else if (fzip_ && m.reset(f.getPath()).find() && collectJar(f)) {

			} else next_ = f;   // only added initial and acceptable
		}

		return next_ != null;
	}

	/** If <var>file</var> is a zip/jar, add contents and return true, else return false.
	private boolean collectJar(File file, boolean reverse) {
		try {
			ZipFile zip = new ZipFile(file);

			if (!reverse) {
				for (Enumeration e = zip.entries(); e.hasMoreElements(); ) {
					ZipEntry z = (ZipEntry)e.nextElement();

					if (filter_==null || filter_.accept(new ZipEntryFile(z))) q_.add(z);
				}
				q_.add(zip);    // add self so can close when see again

			} else {
				List<> l = java.util.Collections.list(e);
				//for (int i=l.size()-1; i>=0; i--)
			}
		} catch (IOException ioe) {
			return false;   // not a zip or other other problem
		}

		return true;
	}*/


	public File next() {
		if (!hasNext()) throw new java.util.NoSuchElementException();
		File f = next_;
		next_ = null;
		return f;
	}

	public void remove() { throw new UnsupportedOperationException(); }
  }

  /** The iterator for {@link java.lang.Iterable} and the enchanced for loop is {@link #depthFirstIterator()}. */
  public Iterator<File> iterator() { return depthFirstIterator(); }

  /**
	Iterates over all passed files and recursively all files in base directories in depth-first order.
	This method is memory efficient: it does <i>not</i> first build up a list of all files.
	There can be any number of iterators active at once on the same <code>FileList</code> object.
   */
  public Iterator<File> depthFirstIterator() {
	return new dfs();
  }

  //** Iterator over files.  Traversal order unspecified, but in fact, in current implementation, a convenience method for depthFirstIterator(). */
  //public Iterator<File> iterator() { return depthFirstIterator(); }

  private class bfs implements Iterator<File> {
	List<File> q_ = new LinkedList<File>();
	File next_ = null;
	Comparator<File> comp_ = new FileOrder(fsort_, fdirsfirst_);

	bfs() {
		q_.addAll(base_);
	}

	public boolean hasNext() {
		while (q_.size() > 0 && next_ == null) {
			File f = q_.remove(0);
			if (f.isDirectory()) {
				if (f.canRead()) {
					File[] files = f.listFiles();
					Arrays.sort(files, comp_);
					for (int i=0,imax=files.length; i<imax; i++) {
						File sub = files[i];
						if (accept(sub) || sub.isDirectory()) q_.add(sub);
					}
				}
				if (accept(f)) next_ = f;

			} else next_ = f;
		}

		return next_!=null;
	}

	public File next() {
		if (!hasNext()) throw new java.util.NoSuchElementException();
		File f = next_;
		next_ = null;
		return f;
	}

	public void remove() { throw new UnsupportedOperationException(); }
  }

  /**
	Iterates over all passed files and recursively all files in base directories in breadth-first order.
	This method is memory efficient: it does <i>not</i> first build up a list of all files.
	There can be any number of iterators active at once on the same <code>FileLists</code> object.
   */
  public Iterator<File> breadthFirstIterator() {
	return new bfs();
  }


  public File[] listFiles() {
	List<File> l = new ArrayList<File>(100);
	for (Iterator<File> i = iterator(); i.hasNext(); ) l.add(i.next());

	File[] fl=new File[l.size()]; l.toArray(fl);
	return fl;
  }



  /**
	Returns total length of files in group.
  */
  public long length() {
	long len = 0L;

	for (Iterator<File> i = iterator(); i.hasNext(); ) {
		File f = i.next();
		if (f.isFile()) len += f.length();
	}

	return len;
  }

  /** Returns most recently modified file in group.
  public File lastModified() {
	File lastf = null;
	long lastmod = 0L;

	for (Iterator<File> i = iterator(); i.hasNext(); ) {
		File f = i.next();
		long mod = f.lastModified();
		if (f.isFile() && mod > lastmod) { lastf=f; lastmod=mod; }
	}

	return lastf;
  }*/



  /**
	Delete all files.
	@return true if successfully deleted all files
  */
  public boolean delete() {
	boolean ok = true;
	for (Iterator<File> i = iterator(); i.hasNext(); ) {    // files before directories
		File f = i.next();
		ok = f.delete() && ok;
	}
	return ok;
  }

  /**
	Copy all files to destination directory <var>dirout</var>.
  */
  public void copy(File dirout) throws IOException {
	//if (!dir.isDirectory() || dir.canWrite()) return false;

	for (Iterator<File> i = iterator(); i.hasNext(); ) {    // files before directories
		File f = i.next();
		File outf = new File(dirout, f.getPath());
		Files.copy(f, outf);
	}
  }

  /* * => Streams.copy(in, new FileOutputStream(out))
	Read all data from <var>in</var> and write to file named <var>out</var>.
	@return {@link java.io.File} created
  public static void copy(InputStream in, File out) throws IOException {
	File f = new File(out);
  }
  */

  /* *
	Like Unix <code>grep</code>, searchs content of files for <var>regexp</var>, and returns lines or files that match.
	Since the caller would have to iterate over the results anyhow, the method is an iterator.
	=> caller in control of iteration over files to handle -H/-h/-L/-l/-c
	   + grep on single file returning matches/-v/-b/-n and maybe -B/-A/-#/-C

	<p><var>flags</var> is a set of letters taken from the following (based on GNU <code>grep</code>):
	<ul>
	</ul>

  -v, --revert-match        select non-matching lines

<!-- relevant options from GNU grep:
Output control:
  -b, --byte-offset         print the byte offset with output lines
  -n, --line-number         print line number with output lines
  -H, --with-filename       print the filename for each match => at head of list
  -h, --no-filename         suppress the prefixing filename on output => ignore head of list
  -L, --files-without-match only print FILE names containing no match => flag
  -l, --files-with-matches  only print FILE names containing matches => default
  -c, --count               only print a count of matching lines per FILE => easy to compute

Context control:
  <li>-B, --before-context=NUM  print NUM lines of leading context
  <li>-A, --after-context=NUM   print NUM lines of trailing context
  <li>-NUM                      same as both -B NUM and -A NUM
  <li>-C, --context             same as -2
-->

	flags: -v, -l, -b, -n, -c

	@see <a href='http://jakarta.apache.org/lucene/docs/index.html'>Lucene</a> search engine
  public List<> grep(Pattern regexp, String flags) {
	Matcher m = regexp.matcher("");
	//java.util.Collections.EMPTY_LIST;

	boolean v = false, l = false;
	for (Iterator<File> i = iterator(); i.hasNext(); ) {
		File f = (File)i.next();

		int n = 1;
		try {
			BufferedReader r = new BufferedReader(new FileReader(f));
			for (String line; (line = r.readLine()) != null; n++) {
				if (m.reset(line).find() ^ v) {

				if (l) {
					//
				} else {
					// result string: (filename)(line number)(line)
				}
			}
			}

			r.close();
		} catch (IOException ioe) {
			// keep on truckin'
		}
	}
  }

  private class grep implements Iterator {
	Matcher m_;
	Iterator<File> i_;
	List<> next_;
	boolean v_, L_;

	grep(Pattern p, boolean v, boolean L) {
		m_ = p.matcher("");
		i_ = iterator();
	}

	public boolean hasNext() {


	}

	public Object next() {
		if (!hasNext()) throw new java.util.NoSuchElementException();
		List<> l = next_;
		next_ = null;
		return l;
	}

	public void remove() { throw new UnsupportedOperationException(); }
  }
  */





  //public static List<> find(File f, FileFilter filter, List<> hits) => FileFilter



  /* => tool? doesn't fit in document-related tools
	Rename all files matching one pattern to another pattern.
	For example, rename all *.htm files to same name but with .html suffix,
	"img101", "img102", "img103" to "yosemite101", "yosemite102", "yosemite103"
	all-uppercase names to lowercase, ....
	<var>from</var> is a regular expression that identifies files to rename,
	and matching parts, or <dfn>groups</dfn>, that can be incorporated in <var>to</var>.
	<var>to</var> is the new filename pattern, with the escape codes replaced as follows:

	<table>
	<tr><td><code>\<var>n</var></code> (n: 0..9)   <td>replaced by the corresponding group in <var>from</var>
	<tr><td><code>\#</code>     <td>sequence number
	<tr><td><code>\l</code>     <td>lowercase result
	<tr><td><code>\\u</code>     <td>uppercase result
	<tr><td><code>\i</code>     <td>uppercase first letter of result, lowercase rest
	<tr><td>otherwise: <code>\<var>c</var></code>  <td>literal <var>c</var>
	</table>

	@see java.util.regex.Matcher#group(int)
  * /
  public void rename(Pattern from, String to) {
	//assert to.indexOf('\\')!=-1: to;  // I guess it's possible you'd want to rename everything to the same filename.
	int num = 1;
	for (Iterator<File> i = iterator(); i.hasNext(); num++) {
		File f = i.next();
		Matcher m = from.matcher(f.getPath());  // getName()?

		if (m.matches()) {
			// construct new name
			StringBuffer sb = new StringBuffer(20);
			for (int j=0,jmax=to.length(); j<jmax; j++) {
				char ch = to.charAt(j);
				if (ch == '\\' && j+1<jmax) {
					char op = to.charAt(++j);
					switch (op) {
					case '0': case '1': case '2': case '3': case '4':
					case '5': case '6': case '7': case '8': case '9':
						int group = to.charAt(++j) - '0';
						if (group <= m.groupCount()) sb.append(m.group());
						break;

					case '#': sb.append(num); break;

					default: // literal
						sb.append(op);
					}

				} else sb.append(ch);
			}

			File tofile = new File(f, sb.toString());   // almost always in same directory; not sure if define to move to different directory
			boolean ok = f.renameTo(tofile);
		}
	}
  }
  //*/


  /**
	UNIX utilities and syntax?  cp, rm, grep, ... crossplatform.  pipes?
  public static void main(String[] argv) {
  }*/
}
