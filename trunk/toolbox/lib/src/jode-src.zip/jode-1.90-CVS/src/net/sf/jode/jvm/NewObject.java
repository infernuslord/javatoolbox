/* NewObject Copyright (C) 1999-2002 Jochen Hoenicke.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; see the file COPYING.LESSER.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * $Id: NewObject.java,v 1.3 2002/05/29 12:06:36 hoenicke Exp $
 */

package net.sf.jode.jvm;

/**
 * This class represents a new object, that may not be initialized yet.
 *
 * @author Jochen Hoenicke
 */
class NewObject {
    Object instance;
    String type;

    public NewObject(String type) {
	this.type = type;
    }

    public String getType() {
	return type;
    }

    public void setObject(Object obj) {
	instance = obj;
    }

    public Object objectValue() {
	return instance;
    }

    public String toString() {
	if (instance == null)
	    return "new "+type;
	else
	    return instance.toString();
    }
}

