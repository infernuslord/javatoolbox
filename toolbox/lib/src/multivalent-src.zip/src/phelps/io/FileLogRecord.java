package phelps.io;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.URI;
import java.security.*;

import phelps.net.URIs;



/**
	Database record for {@link FileLog}.
	It is passed to clients, which can mutate the fields.
	It can be created by clients and added to the database.
*/
public class FileLogRecord {
  public final String path;	// can have Unicode in path
  public long length;
  public long mod;
  public long hash;
  public String data;	// byte[]?

  //private static final Matcher V1 = new Pattern("(.+)\s+()\s+(.*)").matcher("");

  public FileLogRecord(String path, long length, long mod, long hash, String data) {
	this.path=path; assert path!=null && path.indexOf('\t')==-1: path;
	this.length=length; this.mod=mod; this.hash=hash;
	this.data = data==null? "": data;
  }

  public FileLogRecord(File file) {
	path = file.toString();
	length = file.length();
	mod = file.lastModified();
	hash = -1L;	// up to user to compute
	data = "";
  }

  public void computeHash() throws IOException {
	File f = new File(path);
	if (f.isDirectory()) return;
	MessageDigest md5 = null; try { md5 = MessageDigest.getInstance("MD5"); } catch (NoSuchAlgorithmException builtin) {}

	RandomAccessFile raf = new RandomAccessFile(f, "r");
	byte[] b = new byte[8*1024];
	for (int hunk; (hunk = raf.read(b)) >= 0; ) md5.update(b, 0, hunk);
	raf.close();
	byte[] g = md5.digest();

	for (int i=0; i<8; i++) hash = (hash<<8) | (g[i]&0xff);
  }

  /*package-private*/ FileLogRecord(String line, int version) throws Exception {
	if (version==1) {	// v1 format: "<path> <length> <mod-date> <hash (or x)> <rest of line is data-string>"
		int inx=line.indexOf('\t'), inx2=line.indexOf('\t', inx+1), inx3=line.indexOf('\t',inx2+1), inx4=line.indexOf('\t',inx3+1);
		if (inx==-1 || inx2==-1 || inx3==-1 || inx4==-1) System.err.println("invalid record format: "+line);
		path = URIs.decode(line.substring(0,inx));	// not new URI(...).getPath() because may have Unicode
		length = Long.parseLong(line.substring(inx+1,inx2));
		mod = Long.parseLong(line.substring(inx2+1,inx3));
		hash = Long.parseLong(line.substring(inx3+1,inx4));
		data = URIs.decode(line.substring(inx4+1));
	//} else if (version==2) {
	} else throw new Exception("unknown version "+version+", latest known = 1");
  }

  public String toString() { return URIs.encode(path)+"\t"+length+"\t"+mod+"\t"+hash+"\t"+URIs.encode(data); }
}
