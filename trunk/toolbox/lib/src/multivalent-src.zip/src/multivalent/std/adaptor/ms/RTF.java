package multivalent.std.adaptor.ms;

import java.io.*;
import java.util.Map;
import java.util.HashMap;
import java.net.URI;
import java.awt.*;

import multivalent.*;

import phelps.Utility;



/**
	Media adaptor for Rich Text Format (RTF) files
	  spec at http://www.microsoft.com/...
	The RTF spec is 248 pages; this implementation ignores most commands and shows lightly formatted text.
	Good enough to read simple formatted text.

	<p>Since nobody uses RTF anymore, write translation to HTML (later, XML).

	@version $Revision: 1.2 $ $Date: 2002/02/01 08:26:18 $
*/
public class RTF extends multivalent.std.adaptor.MediaAdaptorByte/*not Reader because not Unicode*/ {
  static final boolean DEBUG=true;

  static final int RTF=256,
	ANSI=RTF+1, MAC=ANSI+1, PC=ANSI+2, PCA=ANSI+3, ANSICPG=ANSI+4,
	UPR=ANSICPG+1, UD=UPR+1, U=UD+1, UC=U+1,
	FONTTBL=UC+1, F=FONTTBL+1, FNIL=F+1, FROMAN=FNIL+1, FSWISS=FNIL+2, FMODERN=FNIL+3, FSCRIPT=FNIL+4, FDECOR=FNIL+5, FTECH=FNIL+6, FBIDI=FNIL+7,
	FCHARSET=FBIDI+1, FPQR=FCHARSET+1, PANOSE=FPQR+1, FNAME=PANOSE+1, FBIAS=FNAME+1, FALT=FBIAS+1, FONTEMB=FALT+1, FTNIL=FONTEMB+1, FTTRUETYPE=FTNIL+1, FONTFILE=FTTRUETYPE+1, CPG=FONTFILE+1,
	COLORTBL=CPG+1, RED=COLORTBL+1, GREEN=COLORTBL+2, BLUE=COLORTBL+3,
	STYLESHEET=BLUE+1, CS=STYLESHEET+1, S=CS+1, DS=S+1, ADDITIVE=DS+1, SBASEDON=ADDITIVE+1, SNEXT=SBASEDON+1, SAUTOUPD=SNEXT+1, SHIDDEN=SAUTOUPD+1, SPERSONAL=SHIDDEN+1, SCOMPOSE=SPERSONAL+1, SREPLY=SCOMPOSE+1,
	KEYCODE=SREPLY+1, ALT=KEYCODE+1, SHIFT=ALT+1, CTRL=ALT+2, FN=ALT+3,
	INFO=FN+1, TITLE=INFO+1, SUBJECT=INFO+2, AUTHOR=INFO+3, MANAGER=INFO+4, COMPANY=INFO+5, OPERATOR=INFO+6, CATEGORY=INFO+7, KEYWORDS=INFO+8, COMMENT=INFO+9,
	DOCCOMM=COMMENT+1, HLINKBASE=DOCCOMM+1,
	CREATIM=HLINKBASE+1, REVTIM=CREATIM+1, PRINTIM=CREATIM+2, BUPTIM=CREATIM+3, YR=BUPTIM+1, MO=YR+1, DY=YR+2, HR=YR+3, MIN=YR+4, SEC=YR+5,
	DOCVAR=SEC+1,

	FS=DOCVAR+1,
	PAR=FS+1, PARD=PAR+1, PAGE=PARD+1, LINE=PAGE+1,
	TAB=LINE+1, LQUOTE=TAB+1, RQUOTE=LQUOTE+1, LDBLQUOTE=RQUOTE+1, RDBLQUOTE=LDBLQUOTE+1,

	PLAIN=RDBLQUOTE+1, B=PLAIN+1, I=B+1, SUB=B+2, SUP=B+3, STRIKE=B+4,
	UL=B+5, ULD=UL+1, ULDASH=UL+2, ULDASHD=UL+3, ULDASHDD=UL+4, ULDB=UL+5, ULHWAVE=UL+6, ULLDASH=UL+7,
	ULTH=UL+8, ULTHD=UL+9, ULTHDASH=UL+10, ULTHDASHD=UL+11, ULTHDASHDD=UL+12, ULTHLDASH=UL+13,
	ULULDBWAVE=UL+14, ULW=UL+15, ULWAVE=UL+16,
	ULNONE=UL+17,

	HEADER=ULNONE+1, HEADERL=HEADER+1, HEADERR=HEADER+2, HEADERF=HEADER+3, FOOTER=HEADER+4, FOOTERL=FOOTER+1, FOOTERR=FOOTER+2, FOOTERF=FOOTER+3,
	BIN=FOOTERF+1,
	HL=BIN+1, HLLOC=HL+1, HLSRC=HL+2, HLFR=HL+3
	;

  protected static Map<String,Integer> keyword2int_;
  static {
	String[] keywords = {
	// commands supported
	"rtf",

	"ansi", "mac", "pc", "pca", "ansicpg",
	"upr", "ud", "u", "uc",

	"fonttbl", "f", "fnil", "froman", "fswiss", "fmodern", "fscript", "fdecor", "ftech", "fbidi",
	"fcharset", "fpqr", "panose", "fname", "fbias", "falt", "fontemb", "ftnil", "fttruetype", "fontfile", "cpg",

	"colortbl", "red", "green", "blue",

	"stylesheet", "cs", "s", "ds", "additive", "sbasedon", "snext", "sautoupd", "shidden", "spersonal", "scompose", "sreply",
	"keycode", "alt", "shift", "ctrl", "fn",

	"info", "title", "subject", "author", "manager", "company", "operator", "category", "keywords", "comment", "doccomm", "hlinkbase",
	"creatim", "revtim", "printim", "buptim", "yr", "mo", "dy", "hr", "min", "sec",

	"docvar",

	"fs",
	"par", "pard", "page", "line",
	"tab", "lquote", "rquote", "ldblquote", "rdblquote",
	"plain", "b", "i", "sub", "sup", "strike",
	"ul", "uld", "uldash", "uldashd", "uldashdd", "uldb", "ulhwave", "ulldash", "ulth", "ulthd", "ulthdash", "ulthdashd", "ulthdashdd", "ulthldash", "ululdbwave", "ulw", "ulwave", "ulnone",

	"header", "headerl", "headerr", "headerf", "footer", "footerl", "footerr", "footerf",

	"bin",
	"hl", "hlloc", "hlsrc", "hlfr",

	// later
	"filetbl", "file", "fid", "frelative", "fosnum", "fvalidmac", "fvaliddos", "fvalidntfs", "fvalidhpfs", "fnetwork",

	"listtable", "listid", "listtemplateid", "listsimple", "listhybrid", "listrestarthdn", "listname",
	"levelstartat", "levelnfc", "leveljc", "levelnfcn", "leveljcn", "levelold", "levelprev", "levelprevspace", "levelindent", "levelspace", "leveltext", "level numbers", "levelfollow", "levellegal", "levelnorestart",
	"listoverridecount", "ls", "listoverridestartat", "listoverrideformat",

	"revtbl",

	"userprops", "propname", "proptype", "statival", "linkval",
	"nofpages", "nofwords", "nofchars", "nofcharsws", "id",

	"deftab", "hyphhotz", "hyphconsec", "hyphcaps", "hyphauto", "linestart", "fracwidth", "nextfile", "template", "makebackup", "defformat",
	"psover", "doctemp", "deflang", "deflangfe", "windowcaption", "doctype", "fromtext", "fromhtml", "horzdoc", "vertdoc",
	"jcompress", "jexpand", "lnongrid",

	"viewkind", "viewscale", "viewzk", "private",

	"fet", "ftnsep", "ftnsepc", "fftncn", "aftnsep", "aftnsepc", "aftncn", "endnotes", "enddoc", "ftntj", "ftnbj", "aendnotes", "aenddoc",
	"aftnbj", "aftntj", "ftnstart", "aftnstart",
	"ftnrstpg", "ftnrestart", "ftnrstcont", "aftnrestart", "aftrnrstcont", "ftnnar", "ftnnalc", "ftnnauc", "ftnnrlc", "ftnnruc", "ftnnchi", "ftnnchosung", "ftnncnum",
	"ftnndbnum", "ftnndbnumd", "ftnndbnumt", "ftnndbnumk", "ftnndbar", "ftnnganada", "ftnngbnum", "ftnngbnumd", "ftnngbnuml", "ftnngbnumk", "ftnnzodiac", "ftnnzodiacd", "ftnzodiacl",
	"aftnnar", "aftnnalc", "aftnnauc", "aftnnrlc", "aftnnruc", "aftnnchi", "aftnnchosung", "aftnncnum", "aftnndbnum", "aftnndbnumd", "aftnndbnumt",
	"aftnndbnumk", "aftnndbar", "aftnnganada", "aftnngbnum", "aftnngbnumd", "aftnngbnuml", "aftnngbnumk", "aftnnzodiac", "aftnnzodiacd", "aftnnzodiacl",

	"paperw", "paperh", "psz", "margl", "margr", "margt", "margb", "facingp", "gutter", "rtlgutter", "gutterprl", "margmirror", "landscape", "pgnstart", "windowctrl", "twoonone",
	"linkstyles",
	"notabind", "wraptrsp", "prcolbl", "noextrasprl", "nocolbal", "cvmme", "sprstsp", "sprsspbf", "otblrul", "transmf", "swpbdr",
	"brkfrm", "sprslnsp", "subfontbysize", "truncatefontheight", "trunex", "bdbfhdr", "dntblnsbdb", "expshrtn", "lytexcttp",
	"lytprtmet", "msmcap", "nolead", "nospaceforul", "noultrlspc", "noxlattoyen", "oldlinewrape", "sprsbsp", "sprstsm", "wpjst",
	"wpsp", "wptab", "splytwnine", "ftnlytwnine", "htmautsp", "useltbaln", "alntblind", "lytcalctblwd",
	"lyttblrtgr", "oldas", "lnbrkrule", "bdrrlswsix", "nolnhtadjtbl",

	"formprot", "allprot", "formshade", "formdisp", "printdata",
	"revprot", "revisions", "revprop", "revbar", "annotprot",
	"rtldoc",
	};

	keyword2int_ = new HashMap<String,Integer>(2 * keywords.length);
	for (int i=0,imax=keywords.length; i<imax; i++) {
		String kw=keywords[i];
		assert keyword2int_.get(kw)==null;  // duplicate keyword
		keyword2int_.put(kw, new Integer(i+RTF));
	}

	assert keyword2int_.get("fonttbl").intValue() == FONTTBL;
	assert keyword2int_.get("fcharset").intValue() == FCHARSET;
	assert keyword2int_.get("info").intValue() == INFO;
	assert keyword2int_.get("par").intValue() == PAR;
  }

  public void setInputStream(InputStream is) {
	super.setInputStream(new PushbackInputStream(new BufferedInputStream(is, phelps.io.Files.BUFSIZ), 1024));
  }

  public Object parse(INode parent) throws IOException {
	//URL url = br.getCurDocument().getURI();	// should fetch this from... something else
	//Document doc = parent.getDocument();
	//URI uri = doc.getURI();

	return parseHelper(toHTML(), "HTML", getLayer(), parent);
  }


  /** Return HTML translation of document. */
  public String toHTML() throws IOException {
	PushbackInputStream pis = (PushbackInputStream)getInputStream();

	StringBuffer docsb = new StringBuffer(100000);	// take from file size, if available
	StringBuffer sb = docsb;
	StringBuffer ssb = new StringBuffer(1000);	 // for collecting words, args
	sb.append("<html>\n<head>\n");
//	sb.append("\t<title>").append(url.getFile()).append("  (RTF)").append("</title>\n");
//	sb.append("\t<base href='").append(url).append("'>\n");
	sb.append("\t<style>\n");
	//int stylesheeti = sb.length();
	//sb.append("\t\tp { margin-top: 0pt; }");
	sb.append("\t</style>\n");
	sb.append("</head>\n");
	sb.append("<body>\n");

	String[] tagstack = new String[1000];
	int[] levstack = new int[tagstack.length];
	int[] groupstack = new int[tagstack.length];
	int stacki=0, level=0;

	int skipto=Integer.MAX_VALUE;	// eventually won't need this as will implement those commands
	boolean fignorable = false;	// exclude text if destination not understood
	boolean found=false;
	int c;
//int debugcnt=0;

	//List<> fontTable=new ArrayList<>(100), colorTable=new ArrayList<>(100);	// not array because get big disconnected numbers such as 2001
	String[] fontTable=new String[100];
	Color[] colorTable=new Color[100]; int colori=0;
	int fontnum=-1, fontfamily=-1;	String deffontfamily=null;
	int parseposn=-1;
	int red=-1, green=-1, blue=-1;
	CLGeneral curstyle = null;


	while ((c=pis.read())!=-1) {
		int cmd=-1, dnum=-1; String scmd=null;

		// "hunk" within group
		if (c==';' && stacki>0 && (cmd=groupstack[stacki-1])!=-1) { // -1 should be ok as whole documenet within \rtf group
			boolean cont=true;
			switch (cmd) {
			case FONTTBL:
				String fontname = sb.substring(parseposn,sb.length()).trim();
				sb.setLength(parseposn);
//System.out.println("font #"+fontnum+", name="+fontname);
				//fontTable.set(fontnum, fontname);
				if (fontnum > fontTable.length) {
					String[] newft = new String[fontnum+20];
					System.arraycopy(fontTable,0, newft,0, fontTable.length);
					fontTable = newft;
				}
				fontTable[fontnum] = fontname;
				break;
			case COLORTBL:
				if (red!=-1) {
//System.out.println("color #"+colori+": "+red+", "+green+", "+blue);
					colorTable[colori++] = new Color(red,green,blue);
				}
				break;
			default:
				cont=false;
			}
			if (cont) continue;
		}

		// command
		if (c=='\\') {
			// collect command
			c = pis.read();
			if (c>='a' && c<='z') {
				ssb.setLength(0); ssb.append((char)c);
				while (((c=pis.read())>='a' && c<='z') || (c>='A' && c<='Z')) ssb.append((char)c);	// supposed to be all-lowercase, but buggy Word 97 & 2000
				scmd = ssb.substring(0);
				Integer o = keyword2int_.get(scmd);
				if (o!=null) cmd=o.intValue();
//if (debugcnt++<30) System.out.println("cmd = "+ssb.substring(0)+" => "+icmd);

				// collect delimiter/numeric argument (only for alpha commands?)
				dnum = 0;
				long sign=1;
				if (c=='-') { sign=-1; c=pis.read(); }
				if (c>='0' && c<='9') dnum=0;
				while (c>='0' && c<='9') { dnum=dnum*10 + c-'0'; c=pis.read(); }
				dnum *= sign;
				if (c!=' ' && c!='\n' && c!='\t' && c!='\r') pis.unread(c);	// never unread?

			} else {	// non-alpha command
				cmd = c;
				//c = pis.read();
			}


			// ignore most commands
			String sout=null, tagout=null;	int groupid=-1;
			if (cmd>=0 && skipto>level) switch (cmd) {
				case '*': fignorable=true; break;  // next command is ignorable

				case '\\': sout="\\"; break;
				case '{': sout="{"; break;
				case '}': sout="}"; break;
				case '~': sout="&nbsp;"; break;
				case '_': sout="-"; break;
				case '-':	// non-breaking hyphen
					// ignore
					break;
				case '\'':	// char as hex value
					int h1=pis.read(), h2=pis.read();
//System.out.println("hex: "+(char)h1+" "+(char)h2);
					if (h1>='0' && h1<='9') h1-='0'; else h1=Character.toLowerCase((char)h1)-'a'+10;
					if (h2>='0' && h2<='9') h2-='0'; else h2=Character.toLowerCase((char)h2)-'a'+10;
//System.out.println((h1*16+h2));
					int charval = h1*16+h2;
					if (charval==147) charval='`'; else if (charval==148) charval='\'';    // stupid single curly quotes
					sb.append("&#").append(charval).append(';');	// let HTML deal with invalid values
					break;

				case PAR: sout="\n<p>"; break;
				case PAGE: sout="\n<hr>\n"; break;	// ?
				case LINE: sout="<br>\n"; break;
				case TAB: sout="&nbsp;&nbsp;&nbsp;"; break;
				case LQUOTE: sout="`"; break;
				case RQUOTE: sout="'"; break;
				case LDBLQUOTE: sout="&quot;"; break;
				case RDBLQUOTE: sout="&quot;"; break;


				case F:
					found=false;
					// in definition phase?
					for (int i=stacki-1; i>=0; i--) {
						if (groupstack[i]==FONTTBL) { found=true; break; }
					}
					if (found) {	// def
						fontnum = dnum;
						//groupid=F;
						parseposn = sb.length();	// collect font name
					} else {		// use
						groupid=F;
//System.out.println("dnum = "+dnum);
						//sb.append("<font face='").append(fontTable[dnum]).append("'>");
					}
					break;	// font number (from font table) -- can appear in font table building or as reference
				case FS:	// font size in half-points
					if (curstyle!=null) {
						// add
					} else {
						groupid=FS;
						//sb.append("<font size=").append(dnum/2).append('>');
					}
					break;
				case FNIL: deffontfamily="Times"; fontfamily=cmd; break;
				case FROMAN: deffontfamily="Times"; fontfamily=cmd; break;
				case FSWISS: deffontfamily="Helvetica"; fontfamily=cmd; break;
				case FMODERN: deffontfamily="Courier"; fontfamily=cmd; break;
				case FSCRIPT: deffontfamily="Cursive"; fontfamily=cmd; break;
				case FDECOR: deffontfamily="Old English"; fontfamily=cmd; break;
				case FTECH: deffontfamily="Symbol"; fontfamily=cmd; break;
				case FBIDI: deffontfamily=null; fontfamily=cmd; break;

				case RED: red=dnum; break;
				case GREEN: green=dnum; break;
				case BLUE: blue=dnum; break;

				case CS:	// character style
				case S:	// paragraph style
				case DS:	// section style
				case SBASEDON:
				case SNEXT:

				case B: tagout="b"; break;
				case I: tagout="i"; break;
				case SUB: tagout="sub"; break;
				case SUP: tagout="sup"; break;
				case STRIKE: tagout="strike"; break;
				case ULD: case ULDASH: case ULDASHD: case ULDASHDD: case ULDB: case ULHWAVE: case ULLDASH:
				case ULTH: case ULTHD: case ULTHDASH: case ULTHDASHD: case ULTHDASHDD: case ULTHLDASH:
				case ULULDBWAVE: case ULW: case ULWAVE:
				case UL:
					tagout="u"; // for now, all underlines look the same
					break;
				case ULNONE:
					for (int i=stacki-1; i>=0; i--) {
						if (tagstack[stacki]=="u") { sb.append("</u>"); tagstack[stacki]=null; }
					}
					break;
				case PLAIN:
					while (--stacki >= 0) {
						if (tagstack[stacki]!=null) sb.append("</").append(tagstack[stacki]).append('>');
					}
					stacki=0;
					break;

				case BIN: pis.skip(dnum); break;

				// for now, skip these commands that have content in their group
				case FONTTBL:
				case COLORTBL:
					groupid=cmd;
					break;
				case STYLESHEET:
				case PANOSE:
				case INFO:
				case DOCVAR:
				//case CREATIM: case REVTIM: case PRINTIM: case BUPTIM:

				case HEADER: case HEADERL: case HEADERR: case HEADERF: case FOOTER: case FOOTERL: case FOOTERR: case FOOTERF:
					skipto=level;
					break;

				//default: -- ignore
			}
			if (sout!=null) sb.append(sout);
			if (tagout!=null) {
				sb.append('<').append(tagout).append('>');
				tagstack[stacki] = tagout;
				levstack[stacki] = level;
				groupstack[stacki] = -1;
				stacki++;
			}
			if (groupid!=-1) {
				groupstack[stacki]=groupid;		// mark group; also callback at end to define font
				tagstack[stacki]=null;
				levstack[stacki]=level;
				stacki++;
			}

		// new group
		} else if (c=='{') {
			level++;

		// end group
		} else if (c=='}') {
			// close up open tags
			while (stacki>0 && levstack[stacki-1]==level) {
				stacki--;
				if (skipto>level) {
					if (tagstack[stacki]!=null) sb.append("</").append(tagstack[stacki]).append('>');

					switch (groupstack[stacki]) {
					/*case F: // define font
						String fontname = sb.substring(parseposn,sb.length()-1);
						sb.setLength(parseposn);
						System.out.println("font #"+fontnum+", name="+fontname);
						break;*/
					case F:
					case FS:
						//sb.append("</font>");
						break;
					}
				}
			}
			// done ignoring?
			if (skipto==level) skipto=Integer.MAX_VALUE;

			level--;

		// if nothing else, content
		} else if (skipto>level) {				// content
			if (c=='<') sb.append("&lt;"); else if (c=='>') sb.append("&gt;"); else if (c=='"') sb.append("&quot;"); else if (c=='&') sb.append("&amp;");
			else if (c!='\n' && c!='\r') sb.append((char)c);
		}
	}


	sb.append("\n</body></html>\n");
if (DEBUG) System.out.println(sb.substring(0,2*1024));


	return sb.substring(0);
  }
}
