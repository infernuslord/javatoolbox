// Beta
/* * ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	XP Look and Feel														   *
*															                   *
*  (C) Copyright 2002, by Stefan Krause, Taufik Romdhane and Contributors      *
*                                                                              *
*                                                                              *
* The XP Look and Feel started as as extension to the Metouia Look and Feel.   *
* The original header of this file was:                                        *
** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*        Metouia Look And Feel: a free pluggable look and feel for java        *
*                         http://mlf.sourceforge.net                           *
*          (C) Copyright 2002, by Taoufik Romdhane and Contributors.           *
*                                                                              *
*   This library is free software; you can redistribute it and/or modify it    *
*   under the terms of the GNU Lesser General Public License as published by   *
*   the Free Software Foundation; either version 2.1 of the License, or (at    *
*   your option) any later version.                                            *
*                                                                              *
*   This library is distributed in the hope that it will be useful,            *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of             *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                       *
*   See the GNU Lesser General Public License for more details.                *
*                                                                              *
*   You should have received a copy of the GNU General Public License along    *
*   with this program; if not, write to the Free Software Foundation, Inc.,    *
*   59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.                    *
*                                                                              *
*   Original Author:  Taoufik Romdhane                                         *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


package com.stefankrause.xplookandfeel;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.TexturePaint;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

import javax.swing.JComponent;
import javax.swing.JProgressBar;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicProgressBarUI;

import com.stefankrause.xplookandfeel.skin.Skin;
import com.stefankrause.xplookandfeel.skin.SkinImageCache;

/**
 * This class represents the UI delegate for the JProgressBar component.
 *
 * @author Taoufik Romdhane
 */
public class XPProgressBarUI extends BasicProgressBarUI {
	/**
	 * The skin that paint the progress bar if it's a horizontal one
	 */
	static Skin skinHorizontal;
	/**
	 * The skin that paint the progress bar if it's a vertical one
	 */
	static Skin skinVertical;
	
	/*
	 * The offset of the filled bar. This amount of space will be added on the left and right of the progress bar
	 * to its borders.
	 */
	int offset=4;

	/**
	 * Creates the UI delegate for the given component.
	 *
	 * @param c The component to create its UI delegate.
	 * @return The UI delegate for the given component.
	 */
	public static ComponentUI createUI(JComponent c) {
		return new XPProgressBarUI();
	}

	protected void paintDeterminate(Graphics g, JComponent c) {
		if (!(g instanceof Graphics2D)) {
			return;
		}

		Insets b = progressBar.getInsets(); // area for border
		int barRectWidth = progressBar.getWidth() - (b.right + b.left);
		int barRectHeight = progressBar.getHeight() - (b.top + b.bottom);

		int cellLength = getCellLength();
		int cellSpacing = getCellSpacing();
		// amount of progress to draw

		Graphics2D g2 = (Graphics2D) g; 
		//		g2.setColor(progressBar.getForeground());

		if (progressBar.getOrientation() == JProgressBar.HORIZONTAL) {
			int amountFull = getAmountFull(b, barRectWidth - 2 * offset, barRectHeight);

			getSkinHorizontal().draw(g, 0, barRectWidth, barRectHeight);
			g.translate(offset,0);
			BufferedImage img=SkinImageCache.getInstance().getBufferedImage("XPProgressIndicatorHoriz.res");
			amountFull = (amountFull /img.getWidth() ) * img.getWidth();
			TexturePaint tp=new TexturePaint(img,new Rectangle2D.Float(0.0f,0.0f,img.getWidth(),barRectHeight-1) );
			g2.setPaint(tp);
			g2.fillRect(0,0,amountFull,barRectHeight);
			g.translate(-offset,0);
			// Deal with possible text painting
			if (progressBar.isStringPainted()) {
				paintString(g, b.left, b.top, barRectWidth, barRectHeight, amountFull, b);
			}

		} else { // VERTICAL
			int amountFull = getAmountFull(b, barRectWidth, barRectHeight- 2 * offset);
			
			getSkinVertical().draw(g, 0, barRectWidth, barRectHeight);
			BufferedImage img=SkinImageCache.getInstance().getBufferedImage("XPProgressIndicatorVert.res");
			amountFull = (amountFull /img.getHeight() ) * img.getHeight();
			TexturePaint tp=new TexturePaint(img,new Rectangle2D.Float(0.0f,0.0f /*barRectHeight-offset+offset*/, barRectWidth-1, img.getHeight() ) );
			g.translate(0,barRectHeight-offset);
			g2.setPaint(tp);
			g2.fillRect(0,-amountFull,barRectWidth, amountFull);
			g.translate(0,-(barRectHeight-offset) );
			// Deal with possible text painting
			if (progressBar.isStringPainted()) {
				paintString(g, b.left, b.top, barRectWidth, barRectHeight, amountFull, b);
			}
		}
	}
	
    protected void paintIndeterminate(Graphics g, JComponent c) {
        if (!(g instanceof Graphics2D)) {
            return;
        }
		Graphics2D g2 = (Graphics2D) g;

		Insets b = progressBar.getInsets(); // area for border
		int barRectWidth = progressBar.getWidth() - (b.right + b.left);
		int barRectHeight = progressBar.getHeight() - (b.top + b.bottom);

        Rectangle boxRect = getBox(null);
		if (progressBar.getOrientation() == JProgressBar.HORIZONTAL) {

			getSkinHorizontal().draw(g, 0, barRectWidth, barRectHeight);
			g.translate(boxRect.x,boxRect.y);
			BufferedImage img=SkinImageCache.getInstance().getBufferedImage("XPProgressIndicatorHoriz.res");
			TexturePaint tp=new TexturePaint(img,new Rectangle2D.Float(0.0f,0.0f,img.getWidth(),barRectHeight-1) );
			g2.setPaint(tp);
			int w=boxRect.width / img.getWidth() * img.getWidth();
			g2.fillRect(0,0,w,boxRect.height);
			g.translate(-offset,0);
						
		} else {
			getSkinVertical().draw(g, 0, barRectWidth, barRectHeight);


			g.translate(boxRect.x,boxRect.y);
			BufferedImage img=SkinImageCache.getInstance().getBufferedImage("XPProgressIndicatorVert.res");
			TexturePaint tp=new TexturePaint(img,new Rectangle2D.Float(0.0f,0.0f, barRectWidth-1, img.getHeight() ) );
			g2.setPaint(tp);
			int h=boxRect.height / img.getHeight() * img.getHeight();
			g2.fillRect(0,0,boxRect.width,h);
			g.translate(-boxRect.x,-boxRect.y );			
		}

//        // Paint the bouncing box.
//        if (boxRect != null) {
//            g2.setColor(progressBar.getForeground());
//            g2.fillRect(boxRect.x, boxRect.y,
//                       boxRect.width, boxRect.height);
//        } 
    }	
	
	/**
	 * @see javax.swing.plaf.ComponentUI#update(java.awt.Graphics, javax.swing.JComponent)
	 */
	public void update(Graphics g, JComponent c) {
		paint(g, c);
	}
    protected void installDefaults() {
    }
	/**
	 * Returns the skinHorizontal.
	 * @return SkinGenericButton
	 */
	public static Skin getSkinHorizontal() {
		if (skinHorizontal == null) {
			skinHorizontal = new Skin("XPProgressBorderHoriz.res", 1,   4, 0, 4, 0);

		}

		return skinHorizontal;
	}

	/**
	 * Returns the skinVerticale.
	 * @return Skin
	 */
	public static Skin getSkinVertical() {
		if (skinVertical == null) {
			skinVertical = new Skin("XPProgressBorderVert.res", 1,   0, 4, 0, 4);

		}

		return skinVertical;
	}

//	/**
//	 * Returns the fillTextureHorizontal.
//	 * @return TexturePaint
//	 */
//	public static TexturePaint getFillTextureHorizontal() {
//		if (fillTextureHorizontal == null) {
//			fillTextureHorizontal = new TexturePaint(SkinImageCache.getInstance().getBufferedImage("XPProgressIndicatorHoriz.res") arguments,);
//			
//		}
//
//		return fillTextureHorizontal;
//	}
//
//	/**
//	 * Returns the fillTextureVertical.
//	 * @return TexturePaint
//	 */
//	public static TexturePaint getFillTextureVertical() {
//		if (fillTextureVertical == null) {
//			fillTextureVertical = new type(arguments);
//			
//		}
//
//		return fillTextureVertical;
//	}

}