package tex.dvi;

import java.awt.Rectangle;
import java.util.Map;

import multivalent.*;
import multivalent.gui.VMenu;
import multivalent.gui.VScrollbar;
import multivalent.gui.VRadiobox;
import multivalent.gui.VRadiogroup;
import multivalent.std.ui.Multipage;

import phelps.util.Units;



/**
	<code>papersize</code> TeX special.

	<p>From the dvips manual:

	<blockquote>
	Since the intended paper size is a document design decision, and not a
	decision that is made at printing time, such information should be
	given in the TeX file and not on the dvips command line. For this
	reason, dvips supports a `papersize' special. It is hoped that this
	special will become standard over time for TeX previewers and other
	printer drivers.

	<p>The format of the `papersize' special is
	\special{papersize=8.5in,11in}

	<p>where the dimensions given above are for a standard letter sheet. The
	first dimension given is the horizontal size of the page, and the
	second is the vertical size. The dimensions supported are the same as
	for TeX; ...
	</blockquote>

	@see tex.dvi.DVI

	@version $Revision: 1.7 $ $Date: 2003/06/01 07:45:06 $
*/
public class SpecialPaperSize extends Behavior {
  /** Menu category (<code>papersize</code>) for papersize-related settings. */
  public static final String MENU_CATEGORY = "papersize";

  /**
	Set paper size, e.g., to A4.
	<p><tt>"DVIPaperSize"</tt>: <tt>arg=</tt> {@link java.lang.String} <var>paper-size</var>.
  */
  public static final String MSG_PAPERSIZE = "DVIPaperSize";

  /** DVI special handled by this behavior. */
  public static final String SPECIAL_PAPERSIZE = "papersize=";

  public static final String PREF_PAPERSIZE = "DVIPAPERSIZE";

  /** List of paper sizes in the following format: <name>=<number><dimension>[;<name>=<number><dimension...]. */
  public static final String ATTR_PAPERSIZES = "papersizes";


  static String[] titles_;
  static int[] widths_, heights_;

  String special_=null;
  boolean first_ = true;
  int paperwidth_=0, paperheight_=0;
  INode dvip_ = null;


  /** Hook onto "dvi" node for expanding, to doc for scrolling past margins. */
  public void buildAfter(Document doc) {
//System.out.println("PaperSize buildafter");
	for (INode p=doc; true/*p.size()==1*/; ) {
//System.out.println(p.getName());
		if ("dvi".equals(p.getName())) {
			dvip_ = p;
			dvip_.addObserver(this);    // expand size
			doc.addObserver(this);  // bypass margins
//System.out.println("registered on "+p);
			break;
		} else if (p.childAt(0) instanceof INode) {
			p = (INode)p.childAt(0);
		} else break;
	}
  }


  /**
	Expand node bbox to paper size, moving content to 1in x 1in.
  */
  public boolean formatAfter(Node node) {
//System.out.println("formatAfter");
	int off = (int)Units.getLength("1in", "px");

	if (node==dvip_) {
		/*
		From xdvi man page: "By decree of the Stanford \*(Te\& Project,
		the default \*(Te\& page origin is always 1 inch over and down from
		the top-left page corner, even when non-American paper sizes are used."
		*/
		for (int i=0,imax=dvip_.size(); i<imax; i++) dvip_.childAt(i).bbox.translate(off,off);  // multiple children when have rules

		// papersize
		Rectangle bbox = dvip_.bbox;

		if (first_) {
			paperwidth_ = paperheight_ = 0;

			// "\special{papersize=8.5in,11in}"
			if (special_!=null) {	// if papersize special, use that
				int inx = special_.indexOf(',');
				if (inx!=-1) {
					paperwidth_ = (int)Units.getLength(special_.substring(0,inx), "px");
					paperheight_ = (int)Units.getLength(special_.substring(inx+1), "px");
//System.out.println("papersize="+special_);
				}
			}

			// else if auto, try letter, landscape, A4, then scan for one that fits
			// else take set letter, landscape, A4, ...
			if (paperwidth_==0 || paperheight_==0) {
				String defpapersize = getPreference(PREF_PAPERSIZE, titles_[0]);
//System.out.println("default = "+defpapersize);
				for (int i=0,imax=titles_.length; i<imax; i++) {
					if (defpapersize.equalsIgnoreCase(titles_[i])) {
//System.out.println("found @ "+i+": "+widths_[i]+"x"+heights_[i]);
						paperwidth_=widths_[i]; paperheight_=heights_[i];
						break;
					}
				}
			}

			// if all else fails, content size + margins
			if (paperwidth_==0 || paperheight_==0) {
				//neww=(int)Units.getLength("8in", "px"); newh=(int)Units.getLength("11in", "px");
//System.out.println("content + margins");
				paperwidth_ = bbox.width+off*2; paperheight_ = bbox.height+off*2;
			}
		}

		bbox.setBounds(0,0, paperwidth_,paperheight_);

	} else { // on Document
		// scroll to bypass empty top and left margins
		if (first_) {
			Document doc = getDocument();
			VScrollbar sb=doc.getVsb(); if (sb.getValue()==sb.getMin()) sb.setValue(off-10);
			sb=doc.getHsb(); if (sb.getValue()==sb.getMin()) sb.setValue(off-10);
			first_ = false;
		}
	}

	return false;
  }


  /** Get event from DVI parser. */
  public boolean semanticEventBefore(SemanticEvent se, String msg) {
	if (super.semanticEventBefore(se,msg)) return true;
	else if (DVI.MSG_SPECIAL==msg && se.getOut()!=null/*scanning*/) {
		Object arg = se.getArg();
		if (arg instanceof String) {
			String scmp = ((String)arg).toLowerCase();
			if (scmp.startsWith(SPECIAL_PAPERSIZE)) special_ = scmp.substring(SPECIAL_PAPERSIZE.length());
//System.out.println("papersize = "+special_);
		}

	} else if (VMenu.MSG_CREATE_VIEW==msg) {
		INode menu = (INode)se.getOut();
		VRadiogroup rg = new VRadiogroup();
		String defpapersize = getPreference(PREF_PAPERSIZE, titles_[0]);
//System.out.println("def in menu = "+defpapersize);
		for (int i=0,imax=titles_.length; i<imax; i++) {
			VRadiobox ui = (VRadiobox)createUI("radiobox", titles_[i], "event "+MSG_PAPERSIZE+" "+titles_[i], menu, MENU_CATEGORY, false);
			ui.setRadiogroup(rg);
			if (defpapersize.equalsIgnoreCase(titles_[i])) rg.setActive(ui);
		}
	}
	return false;
  }


  /** Catch MSG_PAPERSIZE and set preferences. */
  public boolean semanticEventAfter(SemanticEvent se, String msg) {
	if (MSG_PAPERSIZE==msg) {
		Object arg = se.getArg();
		for (int i=0,imax=titles_.length; i<imax; i++) {
			if (arg instanceof String) {
				String size = (String)arg;
				if (titles_[i].equalsIgnoreCase(size)) {
					Browser br = getBrowser();
					putPreference(PREF_PAPERSIZE, titles_[i]);
					br.eventq(Document.MSG_RELOAD, null);
					break;
				}
			}
		}
	} else if (Multipage.MSG_OPENPAGE==msg) {
		first_ = true;
//System.out.println("openpage");
	}
	return super.semanticEventAfter(se,msg);
  }


  /** Take paper sizes from 'papersizes' attribute. */
  public void restore(ESISNode n, Map<String,Object> attr, Layer layer) {
	super.restore(n,attr, layer);

	// always recompute so can reload a page and get edited settings
	// xdvi page size: us (8.5x11in), usr (11x8.5in), legal (8.5x14in), foolscap (13.5x17in), as well as the ISO sizes a1 - a7 , b1 - b7 , c1 - c7 , a1r - a7r ( a1 - a7 rotated), etc. The default size is 21 x 29.7 cm (A4 size)
	String[] sizes = getAttr(ATTR_PAPERSIZES, /*"Auto=0,0;*/"Letter=8.5in,11in;Landscape=11in,8.5in;Legal=8.5in,14in;A1=594mm,841mm;A4=210mm,297mm").split("\\s*;\\s*");
	int len = sizes.length;
	titles_=new String[len]; widths_=new int[len]; heights_=new int[len];
	for (int i=0; i<len; /*i++ -- only on success*/) {
		String size = sizes[i];
		int inx=size.indexOf('=');
		if (inx!=-1) {
			titles_[i] = size.substring(0,inx);
			int inx2 = size.indexOf(',', inx+1);
			if (inx2!=-1) {
				widths_[i] = (int)Units.getLength(size.substring(inx+1,inx2), "px");
				heights_[i] = (int)Units.getLength(size.substring(inx2+1), "px");
//System.out.println(titles_[i]+" = "+widths_[i]+"x"+heights_[i]);
				i++;    // successful entry
			}
		}
	}
  }
}
