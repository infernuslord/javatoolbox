/*
 * Copyright (c) 2005, the JUNG Project and the Regents of the University of
 * California All rights reserved.
 *
 * This software is open-source under the BSD license; see either "license.txt"
 * or http://jung.sourceforge.net/license.txt for a description.
 *
 * Created on Aug 26, 2005
 */

package edu.uci.ics.jung.visualization.control;

import java.awt.event.InputEvent;

/**
 * a version of the DefaultModalGraphMouse that includes plugins for
 * manipulating a view that is using a HyperbolicTransformer.
 * 
 * @author Tom Nelson - RABA Techologies
 *
 */
public class ModalHyperbolicGraphMouse extends DefaultModalGraphMouse implements
        ModalGraphMouse {

	/**
	 * not included in the base class
	 */
    protected HyperbolicMagnificationGraphMousePlugin magnificationPlugin;
    
    public ModalHyperbolicGraphMouse() {
        this(1.1f, 09.f);
    }

    public ModalHyperbolicGraphMouse(float in, float out) {
        super(in, out);
    }
    
    protected void loadPlugins() {
        pickingPlugin = new PickingGraphMousePlugin();
        animatedPickingPlugin = new AnimatedPickingGraphMousePlugin();
        translatingPlugin = new HyperbolicTranslatingGraphMousePlugin(InputEvent.BUTTON1_MASK);
        scalingPlugin = new ScalingGraphMousePlugin();
        magnificationPlugin = new HyperbolicMagnificationGraphMousePlugin();
        rotatingPlugin = new RotatingGraphMousePlugin();
        shearingPlugin = new ShearingGraphMousePlugin();
        
        add(scalingPlugin);
        add(magnificationPlugin);
        
        setMode(Mode.TRANSFORMING);
    }

}
