// $Id: CharsAction.java,v 1.1 2002/04/25 18:17:15 bill Exp $

package com.jclark.xsl.tr;

import com.jclark.xsl.om.*;

/**
 * character data
 */
class CharsAction implements Action
{
    private String chars;
    CharsAction(String chars)
    {
        this.chars = chars;
    }

    public void invoke(ProcessContext context, Node sourceNode, 
                       Result result) throws XSLException
    {
        result.characters(chars);
    }
}

