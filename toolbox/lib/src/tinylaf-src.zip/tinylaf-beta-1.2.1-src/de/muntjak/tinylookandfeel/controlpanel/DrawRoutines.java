/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	Tiny Look and Feel                                                         *
*                                                                              *
*  (C) Copyright 2003, Hans Bickel                                             *
*                                                                              *
*                                                                              *
*   This library is free software; you can redistribute it and/or modify it    *
*   under the terms of the GNU Lesser General Public License as published by   *
*   the Free Software Foundation; either version 2.1 of the License, or (at    *
*   your option) any later version.                                            *
*                                                                              *
*   This library is distributed in the hope that it will be useful,            *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of             *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                       *
*   See the GNU Lesser General Public License for more details.                *
*                                                                              *
*   You should have received a copy of the GNU General Public License along    *
*   with this program; if not, write to the Free Software Foundation, Inc.,    *
*   59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.                    *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package de.muntjak.tinylookandfeel.controlpanel;

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;

import de.muntjak.tinylookandfeel.Theme;

/**
 * DrawRoutines
 * 
 * @version 1.0
 * @author Hans Bickel
 */
public class DrawRoutines {
	
	static GraphicsConfiguration conf;
	
	static {
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		conf = ge.getDefaultScreenDevice().getDefaultConfiguration();
	}
	
	public static Color lightenColor0 = new Color(255, 255, 255, 219);
	public static Color lightenColor1 = new Color(255, 255, 255, 168);
	public static Color lightenColor2 = new Color(255, 255, 255, 132);
	public static Color lightenColor3 = new Color(255, 255, 255, 61);
	
	protected static Color rolloverColor1 = new Color(229, 151, 0);
	protected static Color rolloverColor2 = new Color(248, 179, 48);
	
	public static void drawBorder(Graphics g, Color c, int x, int y, int w, int h) {
		g.setColor(c);
		g.drawRect(x, y, w-1, h - 1);
	}
	
	public static void drawEditableComboBorder(
		Graphics g, Color c, int x, int y, int w, int h)
	{
		g.setColor(c);
		// left
		g.drawLine(x, y, x, h - 1);
		// top
		g.drawLine(x, y, w-1, y);
		// bottom
		g.drawLine(x, h - 1, w-1, h - 1);
	}
	
	public static void drawRoundedBorder(Graphics g, Color c, int x, int y, int w, int h) {
		g.setColor(c);
		// rect
		g.drawLine(x + 2, y, x + w - 3, y);
		g.drawLine(x + 2, y + h - 1, x + w - 3, y + h - 1);
		g.drawLine(x, y + 2, x, y + h - 3);
		g.drawLine(x + w - 1, y + 2, x + w - 1, y + h - 3);
			
		// ecken
		Color ecken = new Color(c.getRed(), c.getGreen(), c.getBlue(), 56);
		g.setColor(ecken);
		// lo
		g.drawLine(x, y, x, y);
		// ro
		g.drawLine(x + w - 1, y, x + w - 1, y);
		// lu
		g.drawLine(x, y + h - 1, x, y + h - 1);
		// ru
		g.drawLine(x + w - 1, y + h - 1, x + w - 1, y + h - 1);
			
		// ecken verl�ngerungen
		ecken = new Color(c.getRed(), c.getGreen(), c.getBlue(), 183);
		g.setColor(ecken);
		// oben
		g.drawLine(x + 1, y, x + 1, y);
		g.drawLine(x + w - 2, y, x + w - 2, y);
		// links
		g.drawLine(x, y + 1, x, y + 1);
		g.drawLine(x, y + h - 2, x, y + h - 2);
		// unten
		g.drawLine(x + 1, y + h - 1, x + 1, y + h - 1);
		g.drawLine(x + w - 2, y + h - 1, x + w - 2, y + h - 1);
		// rechts
		g.drawLine(x + w - 1, y + 1, x + w - 1, y + 1);
		g.drawLine(x + w - 1, y + h - 2, x + w - 1, y + h - 2);
			
		// ecken innen
		ecken = new Color(c.getRed(), c.getGreen(), c.getBlue(), 76);
		g.setColor(ecken);
		// lo
		g.drawLine(x + 1, y + 1, x + 1, y + 1);
		// ro
		g.drawLine(x + w - 2, y + 1, x + w - 2, y + 1);
		// lu
		g.drawLine(x + 1, y + h - 2, x + 1, y + h - 2);
		// ru
		g.drawLine(x + w - 2, y + h - 2, x + w - 2, y + h - 2);
	}
	
	public static synchronized void drawProgressBarBorder(
		Graphics g, Color c, int x, int y, int w, int h)
	{
		g.setColor(c);
		// rect
		g.drawLine(x + 1, y, x + w - 2, y);
		g.drawLine(x + 1, y + h - 1, x + w - 2, y + h - 1);
		g.drawLine(x, y + 1, x, y + h - 2);
		g.drawLine(x + w - 1, y + 1, x + w - 1, y + h - 2);

		// ecken innen
		// lo
		g.drawLine(x + 1, y + 1, x + 1, y + 1);
		// ro
		g.drawLine(x + w - 2, y + 1, x + w - 2, y + 1);
		// lu
		g.drawLine(x + 1, y + h - 2, x + 1, y + h - 2);
		// ru
		g.drawLine(x + w - 2, y + h - 2, x + w - 2, y + h - 2);
	}
	
	public static void drawRolloverBorder(Graphics g, Color c, int x, int y, int w, int h) {
		g.setColor(c);
		// re
		g.drawLine(x + w - 2, y + 2, x + w - 2, y + h - 3);
		// un
		g.drawLine(x + 2, y + h - 2, x + w - 3, y + h - 2);

		g.setColor(ColorRoutines.lighten(c, 30));
		g.drawRect(x + 2, y + 2, w - 5, h - 5);
		
		g.setColor(Theme.backColor[Theme.style].getColor());
		// ob
		g.drawLine(x + 2, y + 1, x + w - 3, y + 1);
		
		g.setColor(ColorRoutines.lighten(c, 60));
		// li
		g.drawLine(x + 1, y + 2, x + 1, y + h - 3);
	}
	
	public static void drawDefaultBorder(Graphics g, Color c, int x, int y, int w, int h) {
		g.setColor(c);
		// re
		g.drawLine(x + w - 2, y + 2, x + w - 2, y + h - 3);
		// li
		g.drawLine(x + 1, y + 2, x + 1, y + h - 3);
		// Rect innen
		g.drawRect(x + 2, y + 2, w - 5, h - 5);
		
		g.setColor(ColorRoutines.lighten(c, 30));
		// ob
		g.drawLine(x + 2, y + 1, x + w - 3, y + 1);

		g.setColor(ColorRoutines.darken(c, 30));
		// un
		g.drawLine(x + 2, y + h - 2, x + w - 3, y + h - 2);
	}
	
	public static void drawRolloverCheckBorder(Graphics g, Color c, int x, int y, int w, int h) {
		g.setColor(Theme.buttonRolloverColor[Theme.style].getColor());
		// re
		g.drawLine(x + w - 2, y + 1, x + w - 2, y + h - 2);
		// un
		g.drawLine(x + 1, y + h - 2, x + w - 3, y + h - 2);

		g.setColor(ColorRoutines.lighten(Theme.buttonRolloverColor[Theme.style].getColor(), 30));
		// rect innen
		g.drawRect(x + 2, y + 2, w - 5, h - 5);

		g.setColor(ColorRoutines.lighten(Theme.buttonRolloverColor[Theme.style].getColor(), 60));
		// li
		g.drawLine(x + 1, y + 2, x + 1, y + h - 3);
		// ob
		g.drawLine(x + 1, y + 1, x + w - 3, y + 1);
	}
	
	public static void drawSelectedXpTabBorder(
		Graphics g, Color c, int x, int y, int w, int h, int tabPlacement)
	{
		Color c2 = SBChooser.getAdjustedColor(Theme.tabRolloverColor[Theme.style].getColor(), 20, -30);
		g.setColor(c2);
		Color ecken = ColorRoutines.getAverage(Theme.backColor[Theme.style].getColor(), c2);
		switch (tabPlacement) {
			case SwingConstants.LEFT :
				h -= 1;
				
				g.drawLine(x, y + 2, x, y + h - 3);
				// ecken
				g.drawLine(x + 1, y + 1, x + 1, y + 1);
				g.drawLine(x + 1, y + h - 2, x + 1, y + h - 2);
				g.drawLine(x + 2, y, x + 2, y);
				g.drawLine(x + 2, y + h - 1, x + 2, y + h - 1);
				
				g.setColor(Theme.tabRolloverColor[Theme.style].getColor());
				g.drawLine(x + 1, y + 2, x + 1, y + h - 3);
				g.drawLine(x + 2, y + 1, x + 2, y + h - 2);
				
				// ecken
				g.setColor(ecken);				
				// lo
				g.drawLine(x, y + 1, x, y + 1);
				g.drawLine(x + 1, y, x + 1, y);
				// lu
				g.drawLine(x, y + h - 2, x, y + h - 2);
				g.drawLine(x + 1, y + h - 1, x + 1, y + h - 1);
				
				// seiten
				g.setColor(c);	
				g.drawLine(x + 3, y, x + w - 2, y);
				g.drawLine(x + 3, y + h - 1, x + w - 2, y + h - 1);
				break;
			case SwingConstants.RIGHT :
				h -= 1;
				
				g.drawLine(x + w - 1, y + 2, x + w - 1, y + h - 3);
				// ecken
				g.drawLine(x + w - 2, y + 1, x + w - 2, y + 1);
				g.drawLine(x + w - 2, y + h - 2, x + w - 2, y + h - 2);
				g.drawLine(x + w - 3, y, x + w - 3, y);
				g.drawLine(x + w - 3, y + h - 1, x + w - 3, y + h - 1);
				
				g.setColor(Theme.tabRolloverColor[Theme.style].getColor());
				g.drawLine(x + w - 2, y + 2, x + w - 2, y + h - 3);
				g.drawLine(x + w - 3, y + 1, x + w - 3, y + h - 2);
				
				// ecken
				g.setColor(ecken);	
				// ro
				g.drawLine(x + w - 1, y + 1, x + w - 1, y + 1);
				g.drawLine(x + w - 2, y, x + w - 2, y);
				// ru
				g.drawLine(x + w - 1, y + h - 2, x + w - 1, y + h - 2);
				g.drawLine(x + w - 2, y + h - 1, x + w - 2, y + h - 1);
				
				// seiten
				g.setColor(c);	
				g.drawLine(x, y, x + w - 4, y);
				g.drawLine(x, y + h - 1, x + w - 4, y + h - 1);
				break;
			case SwingConstants.BOTTOM :
				w -= 1;
				g.drawLine(x + 2, y + h - 1, x + w - 3, y + h - 1);
				// ecken
				g.drawLine(x + 1, y + h - 2, x + 1, y + h - 2);
				g.drawLine(x + w - 2, y + h - 2, x + w - 2, y + h - 2);
				g.drawLine(x, y + h - 3, x, y + h - 3);
				g.drawLine(x + w - 1, y + h - 3, x + w - 1, y + h - 3);
				g.setColor(Theme.tabRolloverColor[Theme.style].getColor());
				g.drawLine(x + 2, y + h - 2, x + w - 3, y + h - 2);
				g.drawLine(x + 1, y + h - 3, x + w - 2, y + h - 3);
				
				// seiten
				g.setColor(c);	
				g.drawLine(x, y, x, y + h - 4);
				g.drawLine(x + w - 1, y, x + w - 1, y + h - 4);
			
				// ecken
				g.setColor(ecken);
				// lu
				g.drawLine(x + 1, y + h - 1, x + 1, y + h - 1);
				g.drawLine(x, y + h - 2, x, y + h - 2);
				// ru
				g.drawLine(x + w - 2, y + h - 1, x + w - 2, y + h - 1);
				g.drawLine(x + w - 1, y + h - 2, x + w - 1, y + h - 2);
				break;
			case SwingConstants.TOP :
			default :
				w -= 1;
				g.drawLine(x + 2, y, x + w - 3, y);
				// ecken
				g.drawLine(x + 1, y + 1, x + 1, y + 1);
				g.drawLine(x + w - 2, y + 1, x + w - 2, y + 1);
				g.drawLine(x, y + 2, x, y + 2);
				g.drawLine(x + w - 1, y + 2, x + w - 1, y + 2);
				g.setColor(Theme.tabRolloverColor[Theme.style].getColor());
				g.drawLine(x + 2, y + 1, x + w - 3, y + 1);
				g.drawLine(x + 1, y + 2, x + w - 2, y + 2);
				
				// ecken
				g.setColor(ecken);
				// lo
				g.drawLine(x + 1, y, x + 1, y);
				g.drawLine(x, y + 1, x, y + 1);
				// ro
				g.drawLine(x + w - 2, y, x + w - 2, y);
				g.drawLine(x + w - 1, y + 1, x + w - 1, y + 1);
				
				// seiten
				g.setColor(c);				
				g.drawLine(x, y + 3, x, y + h - 1);
				g.drawLine(x + w - 1, y + 3, x + w - 1, y + h - 1);
		}
	}
	
	public static void drawXpTabBorder(
		Graphics g, Color c, int x, int y, int w, int h, int tabPlacement)
	{
		Color ecken = null;
		g.setColor(c);
		
		switch (tabPlacement) {
			case SwingConstants.LEFT :
				h -= 1;
				g.drawLine(x + 2, y, x + w - 1, y);
				g.drawLine(x + 2, y + h - 1, x + w - 1, y + h - 1);
				g.drawLine(x, y + 2, x, y + h - 3);
			
				// ecken
				ecken = new Color(c.getRed(), c.getGreen(), c.getBlue(), 56);
				g.setColor(ecken);
				// lo
				g.drawLine(x, y, x, y);
				// lu
				g.drawLine(x, y + h - 1, x, y + h - 1);
			
				// ecken verl�ngerungen
				ecken = new Color(c.getRed(), c.getGreen(), c.getBlue(), 183);
				g.setColor(ecken);
				// oben
				g.drawLine(x + 1, y, x + 1, y);
				// links
				g.drawLine(x, y + 1, x, y + 1);
				g.drawLine(x, y + h - 2, x, y + h - 2);
				// unten
				g.drawLine(x + 1, y + h - 1, x + 1, y + h - 1);
			
				// ecken innen
				ecken = new Color(c.getRed(), c.getGreen(), c.getBlue(), 76);
				g.setColor(ecken);
				// lo
				g.drawLine(x + 1, y + 1, x + 1, y + 1);
				// lu
				g.drawLine(x + 1, y + h - 2, x + 1, y + h - 2);
				break;
			case SwingConstants.RIGHT :
				h -= 1;
				g.drawLine(x, y, x + w - 3, y);
				g.drawLine(x, y + h - 1, x + w - 3, y + h - 1);
				g.drawLine(x + w - 1, y + 2, x + w - 1, y + h - 3);
			
				// ecken
				ecken = new Color(c.getRed(), c.getGreen(), c.getBlue(), 56);
				g.setColor(ecken);
				// ro
				g.drawLine(x + w - 1, y, x + w - 1, y);
				// ru
				g.drawLine(x + w - 1, y + h - 1, x + w - 1, y + h - 1);
			
				// ecken verl�ngerungen
				ecken = new Color(c.getRed(), c.getGreen(), c.getBlue(), 183);
				g.setColor(ecken);
				// oben
				g.drawLine(x + w - 2, y, x + w - 2, y);
				// unten
				g.drawLine(x + w - 2, y + h - 1, x + w - 2, y + h - 1);
				// rechts
				g.drawLine(x + w - 1, y + 1, x + w - 1, y + 1);
				g.drawLine(x + w - 1, y + h - 2, x + w - 1, y + h - 2);
			
				// ecken innen
				ecken = new Color(c.getRed(), c.getGreen(), c.getBlue(), 76);
				g.setColor(ecken);
				// ro
				g.drawLine(x + w - 2, y + 1, x + w - 2, y + 1);
				// ru
				g.drawLine(x + w - 2, y + h - 2, x + w - 2, y + h - 2);
				break;
			case SwingConstants.BOTTOM :
				w -= 1;
				g.drawLine(x + 2, y + h - 1, x + w - 3, y + h - 1);
				g.drawLine(x, y, x, y + h - 3);
				g.drawLine(x + w - 1, y, x + w - 1, y + h - 3);
			
				// ecken
				ecken = new Color(c.getRed(), c.getGreen(), c.getBlue(), 56);
				g.setColor(ecken);
				// lu
				g.drawLine(x, y + h - 1, x, y + h - 1);
				// ru
				g.drawLine(x + w - 1, y + h - 1, x + w - 1, y + h - 1);
			
				// ecken verl�ngerungen
				ecken = new Color(c.getRed(), c.getGreen(), c.getBlue(), 183);
				g.setColor(ecken);
				// links
				g.drawLine(x, y + h - 2, x, y + h - 2);
				// unten
				g.drawLine(x + 1, y + h - 1, x + 1, y + h - 1);
				g.drawLine(x + w - 2, y + h - 1, x + w - 2, y + h - 1);
				// rechts
				g.drawLine(x + w - 1, y + h - 2, x + w - 1, y + h - 2);
			
				// ecken innen
				ecken = new Color(c.getRed(), c.getGreen(), c.getBlue(), 76);
				g.setColor(ecken);
				// lu
				g.drawLine(x + 1, y + h - 2, x + 1, y + h - 2);
				// ru
				g.drawLine(x + w - 2, y + h - 2, x + w - 2, y + h - 2);
				break;
			case SwingConstants.TOP :
			default :
				w -= 1;
				g.drawLine(x + 2, y, x + w - 3, y);
				g.drawLine(x, y + 2, x, y + h - 1);
				g.drawLine(x + w - 1, y + 2, x + w - 1, y + h - 1);
			
				// ecken
				ecken = new Color(c.getRed(), c.getGreen(), c.getBlue(), 56);
				g.setColor(ecken);
				// lo
				g.drawLine(x, y, x, y);
				// ro
				g.drawLine(x + w - 1, y, x + w - 1, y);
			
				// ecken verl�ngerungen
				ecken = new Color(c.getRed(), c.getGreen(), c.getBlue(), 183);
				g.setColor(ecken);
				// oben
				g.drawLine(x + 1, y, x + 1, y);
				g.drawLine(x + w - 2, y, x + w - 2, y);
				// links
				g.drawLine(x, y + 1, x, y + 1);
				// rechts
				g.drawLine(x + w - 1, y + 1, x + w - 1, y + 1);
			
				// ecken innen
				ecken = new Color(c.getRed(), c.getGreen(), c.getBlue(), 76);
				g.setColor(ecken);
				// lo
				g.drawLine(x + 1, y + 1, x + 1, y + 1);
				// ro
				g.drawLine(x + w - 2, y + 1, x + w - 2, y + 1);
		}
	}
	
	public static void drawWinTabBorder(
		Graphics g, Color c, int x, int y, int w, int h, int tabPlacement)
	{
		Color ecken = null;
		g.setColor(Color.WHITE);
		
		switch (tabPlacement) {
			case SwingConstants.LEFT :
				g.drawLine(x + 2, y, x + w - 1, y);
				g.drawLine(x + 1, y + 1, x + 1, y + 1);
				g.drawLine(x, y + 2, x, y + h - 3);
				
				g.setColor(c);
				g.drawLine(x + 2, y + h - 2, x + w - 1, y + h - 2);
				
				g.setColor(ColorRoutines.darken(c, 50));
				g.drawLine(x + 2, y + h - 1, x + w - 1, y + h - 1);
				g.drawLine(x + 1, y + h - 2, x + 1, y + h - 2);
				break;
			case SwingConstants.RIGHT :
				g.drawLine(x + w - 3, y, x, y);
				g.drawLine(x + w - 2, y + 1, x + w - 2, y + 1);
				g.drawLine(x + w - 1, y + 2, x + w - 1, y + h - 3);
				
				g.setColor(c);
				g.drawLine(x + w - 3, y + h - 2, x, y + h - 2);
				
				g.setColor(ColorRoutines.darken(c, 50));
				g.drawLine(x + w - 3, y + h - 1, x, y + h - 1);
				g.drawLine(x + w - 2, y + h - 2, x + w - 2, y + h - 2);
				break;
			case SwingConstants.BOTTOM :
				g.drawLine(x + 2, y + h - 1, x + w - 3, y + h - 1);
				g.drawLine(x, y + h - 3, x, y);
				g.drawLine(x + 1, y + h - 2, x + 1, y + h - 2);
			
				g.setColor(c);
				g.drawLine(x + w - 2, y + h - 3, x + w - 2, y);

				g.setColor(ColorRoutines.darken(c, 50));
				g.drawLine(x + w - 1, y + h - 3, x + w - 1, y);
				g.drawLine(x + w - 2, y + h - 2, x + w - 2, y + h - 2);
				break;
			case SwingConstants.TOP :
			default :
				g.drawLine(x + 2, y, x + w - 3, y);
				g.drawLine(x, y + 2, x, y + h - 1);
				g.drawLine(x + 1, y + 1, x + 1, y + 1);
			
				g.setColor(c);
				g.drawLine(x + w - 2, y + 2, x + w - 2, y + h - 1);

				g.setColor(ColorRoutines.darken(c, 50));
				g.drawLine(x + w - 1, y + 2, x + w - 1, y + h - 1);
				g.drawLine(x + w - 2, y + 1, x + w - 2, y + 1);
		}
	}
	
	public static void drawXpRadioRolloverBorder(Graphics g, Color c, int x, int y, int w, int h) {
		g.setColor(c);
		g.drawLine(x + 6, y, x + 6, y);
		g.drawLine(x + 6, y + h - 1, x + 6, y + h - 1);
		g.drawLine(x, y + 6, x, y + 6);
		g.drawLine(x + w - 1, y + 6, x + w - 1, y + 6);
		
		g.setColor(ColorRoutines.lighten(c, 4));
		g.drawLine(x + 5, y, x + 5, y);
		g.drawLine(x + 7, y, x + 7, y);
		g.drawLine(x, y + 5, x, y + 5);
		g.drawLine(x, y + 7, x, y + 7);
		g.drawLine(x + 5, y + h - 1, x + 5, y + h - 1);
		g.drawLine(x + 7, y + h - 1, x + 7, y + h - 1);
		g.drawLine(x + w - 1, y + 5, x + w - 1, y + 5);
		g.drawLine(x + w - 1, y + 7, x + w - 1, y + 7);
		
		g.drawLine(x + 3, y + 1, x + 3, y + 1);
		g.drawLine(x + 2, y + 2, x + 2, y + 2);
		g.drawLine(x + 1, y + 3, x + 1, y + 3);
		
		g.drawLine(x + 1, y + 9, x + 1, y + 9);
		g.drawLine(x + 2, y + 10, x + 2, y + 10);
		g.drawLine(x + 3, y + 11, x + 3, y + 11);
		
		g.drawLine(x + 11, y + 9, x + 11, y + 9);
		g.drawLine(x + 10, y + 10, x + 10, y + 10);
		g.drawLine(x + 9, y + 11, x + 9, y + 11);
		
		g.drawLine(x + 9, y + 1, x + 9, y + 1);
		g.drawLine(x + 10, y + 2, x + 10, y + 2);
		g.drawLine(x + 11, y + 3, x + 11, y + 3);
		
		//g.setColor(ColorRoutines.lighten(c, 52));
		g.setColor(ColorRoutines.getAlphaColor(c, 122));
		g.drawLine(x + 3, y, x + 3, y);
		g.drawLine(x + 9, y, x + 9, y);
		g.drawLine(x, y + 3, x, y + 3);
		g.drawLine(x, y + 9, x, y + 9);
		
		g.drawLine(x + 3, y + h - 1, x + 3, y + h - 1);
		g.drawLine(x + 9, y + h - 1, x + 9, y + h - 1);
		g.drawLine(x + w - 1, y + 3, x + w - 1, y + 3);
		g.drawLine(x + w - 1, y + 9, x + w - 1, y + 9);
		
		//g.setColor(ColorRoutines.lighten(c, 24));
		g.setColor(ColorRoutines.getAlphaColor(c, 194));
		g.drawLine(x + 4, y, x + 4, y);
		g.drawLine(x + 8, y, x + 8, y);
		g.drawLine(x, y + 4, x, y + 4);
		g.drawLine(x, y + 8, x, y + 8);
		
		g.drawLine(x + 4, y + h - 1, x + 4, y + h - 1);
		g.drawLine(x + 8, y + h - 1, x + 8, y + h - 1);
		g.drawLine(x + w - 1, y + 4, x + w - 1, y + 4);
		g.drawLine(x + w - 1, y + 8, x + w - 1, y + 8);
		
		g.drawLine(x + 2, y + 1, x + 2, y + 1);
		g.drawLine(x + 1, y + 2, x + 1, y + 2);
		g.drawLine(x + 1, y + 10, x + 1, y + 10);
		g.drawLine(x + 2, y + 11, x + 2, y + 11);
		
		g.drawLine(x + 10, y + 1, x + 10, y + 1);
		g.drawLine(x + 11, y + 2, x + 11, y + 2);
		g.drawLine(x + 11, y + 10, x + 11, y + 10);
		g.drawLine(x + 10, y + 11, x + 10, y + 11);
		
		//g.setColor(ColorRoutines.lighten(Theme.disColor[Theme.style].getColor(), 22));
		g.setColor(ColorRoutines.getAlphaColor(Theme.buttonRolloverColor[Theme.style].getColor(), 199));
		g.drawLine(x + 3, y + 2, x + 3, y + 2);
		g.drawLine(x + 2, y + 3, x + 2, y + 3);
		g.drawLine(x + 2, y + 9, x + 2, y + 9);
		g.drawLine(x + 3, y + 10, x + 3, y + 10);
		
		g.drawLine(x + 9, y + 2, x + 9, y + 2);
		g.drawLine(x + 10, y + 3, x + 10, y + 3);
		g.drawLine(x + 9, y + 10, x + 9, y + 10);
		g.drawLine(x + 10, y + 9, x + 10, y + 9);
		
		g.drawLine(x + 6, y + 1, x + 6, y + 1);
		g.drawLine(x + 6, y + 11, x + 6, y + 11);
		g.drawLine(x + 1, y + 6, x + 1, y + 6);
		g.drawLine(x + 11, y + 6, x + 11, y + 6);
	
		//g.setColor(ColorRoutines.lighten(Theme.disColor[Theme.style].getColor(), 30));
		g.setColor(ColorRoutines.getAlphaColor(Theme.buttonRolloverColor[Theme.style].getColor(), 178));
		g.drawLine(x + 4, y + 1, x + 5, y + 1);
		g.drawLine(x + 7, y + 1, x + 8, y + 1);
		g.drawLine(x + 4, y + 11, x + 5, y + 11);
		g.drawLine(x + 7, y + 11, x + 8, y + 11);
		
		g.drawLine(x + 1, y + 4, x + 1, y + 5);
		g.drawLine(x + 1, y + 7, x + 1, y + 8);
		g.drawLine(x + 11, y + 4, x + 11, y + 5);
		g.drawLine(x + 11, y + 7, x + 11, y + 8);
		
		//g.setColor(ColorRoutines.lighten(Theme.disColor[Theme.style].getColor(), 36));
		g.setColor(ColorRoutines.getAlphaColor(Theme.buttonRolloverColor[Theme.style].getColor(), 163));
		g.drawLine(x + 3, y + 3, x + 3, y + 3);
		g.drawLine(x + 9, y + 3, x + 9, y + 3);
		g.drawLine(x + 3, y + 9, x + 3, y + 9);
		g.drawLine(x + 9, y + 9, x + 9, y + 9);
		
		//g.setColor(ColorRoutines.lighten(Theme.disColor[Theme.style].getColor(), 34));
		g.setColor(ColorRoutines.getAlphaColor(Theme.buttonRolloverColor[Theme.style].getColor(), 168));
		g.drawLine(x + 4, y + 2, x + 5, y + 2);
		g.drawLine(x + 7, y + 2, x + 8, y + 2);
		g.drawLine(x + 2, y + 4, x + 2, y + 5);
		g.drawLine(x + 10, y + 4, x + 10, y + 5);
		
		g.drawLine(x + 4, y + 10, x + 5, y + 10);
		g.drawLine(x + 7, y + 10, x + 8, y + 10);
		g.drawLine(x + 2, y + 7, x + 2, y + 8);
		g.drawLine(x + 10, y + 7, x + 10, y + 8);
		
		//g.setColor(ColorRoutines.lighten(Theme.disColor[Theme.style].getColor(), 30));
		g.setColor(ColorRoutines.getAlphaColor(Theme.buttonRolloverColor[Theme.style].getColor(), 178));
		g.drawLine(x + 6, y + 2, x + 6, y + 2);
		g.drawLine(x + 6, y + 10, x + 6, y + 10);
		g.drawLine(x + 2, y + 6, x + 2, y + 6);
		g.drawLine(x + 10, y + 6, x + 10, y + 6);
		
		//g.setColor(ColorRoutines.lighten(Theme.disColor[Theme.style].getColor(), 46));
		g.setColor(ColorRoutines.getAlphaColor(Theme.buttonRolloverColor[Theme.style].getColor(), 138));
		g.drawLine(x + 4, y + 3, x + 4, y + 3);
		g.drawLine(x + 8, y + 3, x + 8, y + 3);
		g.drawLine(x + 3, y + 4, x + 3, y + 4);
		g.drawLine(x + 9, y + 4, x + 9, y + 4);
		
		g.drawLine(x + 4, y + 9, x + 4, y + 9);
		g.drawLine(x + 8, y + 9, x + 8, y + 9);
		g.drawLine(x + 3, y + 8, x + 3, y + 8);
		g.drawLine(x + 9, y + 8, x + 9, y + 8);
		
		//g.setColor(ColorRoutines.lighten(Theme.disColor[Theme.style].getColor(), 56));
		g.setColor(ColorRoutines.getAlphaColor(Theme.buttonRolloverColor[Theme.style].getColor(), 112));
		g.drawLine(x + 5, y + 3, x + 5, y + 3);
		g.drawLine(x + 7, y + 3, x + 7, y + 3);
		g.drawLine(x + 3, y + 5, x + 3, y + 5);
		g.drawLine(x + 9, y + 5, x + 9, y + 5);
		
		g.drawLine(x + 5, y + 9, x + 5, y + 9);
		g.drawLine(x + 7, y + 9, x + 7, y + 9);
		g.drawLine(x + 3, y + 7, x + 3, y + 7);
		g.drawLine(x + 9, y + 7, x + 9, y + 7);
	}
	
	public static void drawXpRadioBorder(Graphics g, Color c, int x, int y, int w, int h) {
		g.setColor(c);
		g.drawLine(x + 6, y, x + 6, y);
		g.drawLine(x + 3, y + 1, x + 3, y + 1);
		g.drawLine(x + 9, y + 1, x + 9, y + 1);
		g.drawLine(x + 1, y + 3, x + 1, y + 3);
		g.drawLine(x + 11, y + 3, x + 11, y + 3);
		g.drawLine(x, y + 6, x, y + 6);
		g.drawLine(x + 12, y + 6, x + 12, y + 6);
		g.drawLine(x + 1, y + 9, x + 1, y + 9);
		g.drawLine(x + 11, y + 9, x + 11, y + 9);
		g.drawLine(x + 3, y + 11, x + 3, y + 11);
		g.drawLine(x + 9, y + 11, x + 9, y + 11);
		g.drawLine(x + 6, y + 12, x + 6, y + 12);
		
		g.setColor(ColorRoutines.getAlphaColor(c, 193));
		g.drawLine(x + 5, y, x + 5, y);
		g.drawLine(x + 7, y, x + 7, y);
		g.drawLine(x + 4, y + 1, x + 4, y + 1);
		g.drawLine(x + 8, y + 1, x + 8, y + 1);
		g.drawLine(x + 2, y + 2, x + 2, y + 2);
		g.drawLine(x + 10, y + 2, x + 10, y + 2);
		g.drawLine(x + 1, y + 4, x + 1, y + 4);
		g.drawLine(x + 11, y + 4, x + 11, y + 4);
		g.drawLine(x, y + 5, x, y + 5);
		g.drawLine(x + 12, y + 5, x + 12, y + 5);
		g.drawLine(x, y + 7, x, y + 7);
		g.drawLine(x + 12, y + 7, x + 12, y + 7);
		g.drawLine(x + 1, y + 8, x + 1, y + 8);
		g.drawLine(x + 11, y + 8, x + 11, y + 8);
		g.drawLine(x + 2, y + 10, x + 2, y + 10);
		g.drawLine(x + 10, y + 10, x + 10, y + 10);
		g.drawLine(x + 4, y + 11, x + 4, y + 11);
		g.drawLine(x + 8, y + 11, x + 8, y + 11);
		g.drawLine(x + 5, y + 12, x + 5, y + 12);
		g.drawLine(x + 7, y + 12, x + 7, y + 12);
		
		g.setColor(ColorRoutines.getAlphaColor(c, 110));
		g.drawLine(x + 4, y, x + 4, y);
		g.drawLine(x + 8, y, x + 8, y);
		g.drawLine(x + 2, y + 1, x + 2, y + 1);
		g.drawLine(x + 10, y + 1, x + 10, y + 1);
		g.drawLine(x + 5, y + 1, x + 5, y + 1);
		g.drawLine(x + 7, y + 1, x + 7, y + 1);
		g.drawLine(x + 1, y + 2, x + 1, y + 2);
		g.drawLine(x + 11, y + 2, x + 11, y + 2);
		g.drawLine(x + 3, y + 2, x + 3, y + 2);
		g.drawLine(x + 9, y + 2, x + 9, y + 2);
		g.drawLine(x, y + 4, x, y + 4);
		g.drawLine(x + 12, y + 4, x + 12, y + 4);
		g.drawLine(x, y + 8, x, y + 8);
		g.drawLine(x + 12, y + 8, x + 12, y + 8);
		g.drawLine(x + 2, y + 9, x + 2, y + 9);
		g.drawLine(x + 10, y + 9, x + 10, y + 9);
		g.drawLine(x + 1, y + 10, x + 1, y + 10);
		g.drawLine(x + 11, y + 10, x + 11, y + 10);
		g.drawLine(x + 3, y + 10, x + 3, y + 10);
		g.drawLine(x + 9, y + 10, x + 9, y + 10);
		g.drawLine(x + 2, y + 11, x + 2, y + 11);
		g.drawLine(x + 10, y + 11, x + 10, y + 11);
		g.drawLine(x + 5, y + 11, x + 5, y + 11);
		g.drawLine(x + 7, y + 11, x + 7, y + 11);
		g.drawLine(x + 4, y + 12, x + 4, y + 12);
		g.drawLine(x + 8, y + 12, x + 8, y + 12);
		
		g.setColor(ColorRoutines.getAlphaColor(c, 43));
		g.drawLine(x + 3, y, x + 3, y);
		g.drawLine(x + 9, y, x + 9, y);
		g.drawLine(x, y + 3, x, y + 3);
		g.drawLine(x + 12, y + 3, x + 12, y + 3);
		g.drawLine(x, y + 9, x, y + 9);
		g.drawLine(x + 12, y + 9, x + 12, y + 9);
		g.drawLine(x + 3, y + 12, x + 3, y + 12);
		g.drawLine(x + 9, y + 12, x + 9, y + 12);
	}
	
	public static ImageIcon colorize(Image img, Color c) {
		ColorRoutines nc = new ColorRoutines(c);
		
		int w = img.getWidth(null);
		int h = img.getHeight(null);
		
		BufferedImage bufferedImg = conf.createCompatibleImage(w, h, Transparency.TRANSLUCENT);
		
		int[] pixels = new int[w * h];
		PixelGrabber grabber = new PixelGrabber(img, 0, 0, w, h, pixels, 0, w);

		try {
			grabber.grabPixels();
		} catch (InterruptedException e) {
			System.err.println("PixelGrabber interrupted waiting for pixels");
		}
		
		if((grabber.getStatus() & ImageObserver.ABORT) != 0) {
			System.err.println("Image fetch aborted or errored.");
		}
		else {
			for(int y = 0; y < h; y++) {
				for(int x = 0; x < w; x++) {
					bufferedImg.setRGB(x, y, colorize(pixels[y * w + x], nc));
				}
			}
		}
		
		return new ImageIcon(bufferedImg);
	}
	
	protected static int colorize(int px, ColorRoutines nc) {
		int a = (px >> 24) & 0xff;
		if(a == 0) return px;
		
		int r = (px >> 16) & 0xff;
		int g = (px >> 8) & 0xff;
		int b = px & 0xff;
		
		if(r == g && r == b) return px;
		
		return nc.colorize(r, g, b, a);
	}
	
	public static BufferedImage getBufferedImage(Image img) {
		if (img instanceof BufferedImage) {
			return (BufferedImage) img;
		}

		int w = img.getWidth(null);
		int h = img.getHeight(null);

		BufferedImage img2 = conf.createCompatibleImage(w, h);
		Graphics g = img2.getGraphics();
		
		g.drawImage(img, 0, 0, w, h, 0, 0, w, h, null);

		return img2;
	}
}
