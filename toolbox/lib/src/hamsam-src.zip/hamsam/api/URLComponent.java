/*
 * Hamsam - Instant Messaging API
 * Copyright (C) 2003 Raghu K
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package hamsam.api;

import java.net.URL;

/**
 * A component to represent URLs in instant messages.
 *
 * A URL is special in that clients may want to show it as a "web link" rather than
 * plain text. The URL component allows this by providing a link text and link URL.
 * The link text is plain text that needs to be displayed to the user, while
 * the link URL is a URL to which the user may connect to.
 */
public class URLComponent implements MessageComponent
{
	/**
	 * The text to be displayed to the user.
	 */
	private String linkText;

	/**
	 * The URL of this component.
	 */
	private URL linkURL;

	/**
	 * Construct a url component with a link text and link url.
	 *
	 * @param linkText the link text for this component.
	 * @param linkURL  the link URL for this component.
	 */
	public URLComponent(String linkText, URL linkURL)
	{
		this.linkText = linkText;
		this.linkURL = linkURL;
	}

	/**
	 * Returns the link text asociated with this URL component.
	 *
	 * @return the link text of this URL component.
	 */
	public String getLinkText()
	{
		return linkText;
	}

	/**
	 * Returns the link URL asociated with this URL component.
	 *
	 * @return the link URL of this URL component.
	 */
	public URL getLinkURL()
	{
		return linkURL;
	}
}
