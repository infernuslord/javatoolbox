/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh.ext;

import javax.swing.UIDefaults;

import com.shfarr.BasicUtils;
import com.shfarr.ui.plaf.fh.theme.ThemeManager;

//import com.shfarr.BasicUtils;

public class FhUIDefaults extends UIDefaults{

    public Object get(Object o){
        Object c = o.toString().toLowerCase().endsWith("texture") ? ThemeManager.instance().getCurrentTheme().getTexture(o.toString())
                                                                 : super.get(o);

        if(c == null){
            String[] packet = BasicUtils.unpack(o.toString(), '.');
            // String str = packet[0];
            packet[0] = substitute(packet[0]);
            c = super.get(BasicUtils.pack(packet, "."));
            // System.out.println("(" + o.toString() + ") got: [" +
            // (BasicUtils.pack(packet, ".")) + "] = " + c);
        }

        return c;
    }

    protected String substitute(String name){
        if(name.indexOf("Text") != -1 || name.indexOf("Editor") != -1 || name.indexOf("Password") != -1 || name.indexOf("List") != -1
                || name.indexOf("Table") != -1 || name.indexOf("Tree") != -1 || name.indexOf("ComboBox") != -1 || name.indexOf("Spinner") != -1)
                return "EditableComponent";

        if(name.indexOf("CheckBoxMenuItem") != -1 || name.indexOf("MenuItem") != -1 || name.indexOf("RadioButtonMenuItem") != -1) return "Menu";

        if(name.indexOf("Wizard") != -1) return "Panel";

        return "Component";
    }
}
