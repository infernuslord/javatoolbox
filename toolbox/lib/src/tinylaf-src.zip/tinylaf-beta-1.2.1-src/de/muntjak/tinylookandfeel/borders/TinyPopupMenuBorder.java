/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	Tiny Look and Feel                                                         *
*                                                                              *
*  (C) Copyright 2003, Hans Bickel                                             *
*                                                                              *
*   For licensing information and credits, please refer to the                 *
*   comment in file de.muntjak.tinylookandfeel.TinyLookAndFeel                 *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package de.muntjak.tinylookandfeel.borders;

import java.awt.*;

import javax.swing.border.AbstractBorder;
import javax.swing.plaf.UIResource;

import de.muntjak.tinylookandfeel.*;
import de.muntjak.tinylookandfeel.controlpanel.*;

/**
 * TinyPopupMenuBorder
 * 
 * @version 1.0
 * @author Hans Bickel
 */
public class TinyPopupMenuBorder extends AbstractBorder implements UIResource {
	
  /**
   * Draws a simple 3d border for the given component.
   *
   * @param mainColor The component to draw its border.
   * @param g The graphics context.
   * @param x The x coordinate of the top left corner.
   * @param y The y coordinate of the top left corner.
   * @param w The width.
   * @param h The height.
   */
  public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {  	
  		switch(Theme.derivedStyle[Theme.style]) {
			case Theme.TINY_STYLE:
				drawTinyBorder(g, w, h);
				break;
			case Theme.WIN_STYLE:
				drawWinBorder(g, w, h);
				break;
			case Theme.XP_STYLE:
				drawXpBorder(g, w, h);
				break;
		}
  }
  
	private void drawTinyBorder(Graphics g, int w, int h) {
  	
	}
  
	private void drawWinBorder(Graphics g, int w, int h) {
  		// Inner highlight:
    	g.setColor(Color.WHITE);
    	g.drawLine(1, 1, w - 2, 1);
    	g.drawLine(1, 1, 1, h - 2);

    	// Inner shadow:
    	g.setColor(Theme.menuBorderColor[Theme.style].getColor());
    	g.drawLine(w - 2, 2, w - 2, h - 2);
    	g.drawLine(2, h - 2, w - 2, h - 2);

    	// Outer highlight:
    	g.setColor(Theme.menuBarColor[Theme.style].getColor());
    	g.drawLine(0, 0, w - 2, 0);
    	g.drawLine(0, 0, 0, h - 1);

    	// Outer shadow:
    	g.setColor(ColorRoutines.darken(Theme.menuBorderColor[Theme.style].getColor(), 50));
    	g.drawLine(w - 1, 0, w - 1, h - 1);
    	g.drawLine(0, h - 1, w - 1, h - 1);
	}
  
	private void drawXpBorder(Graphics g, int w, int h) {
		// Inner highlight:
    	g.setColor(TinyLookAndFeel.getPrimaryControlHighlight());
    	g.drawLine(1, 1, w - 2, 1);
    	g.drawLine(1, 1, 1, h - 2);

    	// Inner shadow:
    	g.setColor(TinyLookAndFeel.getDesktopColor());
    	g.drawLine(w - 2, 2, w - 2, h - 2);
    	g.drawLine(2, h - 2, w - 2, h - 2);

    	// Outer highlight:
    	g.setColor(Theme.menuBorderColor[Theme.style].getColor());
    	g.drawLine(0, 0, w - 2, 0);
    	g.drawLine(0, 0, 0, h - 1);

    	// Outer shadow:
    	g.setColor(TinyLookAndFeel.getControlDarkShadow());
    	g.drawLine(w - 1, 0, w - 1, h - 1);
    	g.drawLine(0, h - 1, w - 1, h - 1);
	}

  /**
   * Gets the border insets for a given component.
   *
   * @param mainColor The component to get its border insets.
   * @return Always returns the same insets as defined in <code>insets</code>.
   */
  public Insets getBorderInsets(Component c)
  {
    return Theme.menuBorderInsets[Theme.style];
  }
}