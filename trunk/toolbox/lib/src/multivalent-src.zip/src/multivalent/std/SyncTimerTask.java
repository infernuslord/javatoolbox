package multivalent.std;

import java.util.TimerTask;
import java.util.Observable;



/**
	{@link java.util.TimerTask} that notifies all of its {@link java.util.Observable}s
	every time it is {@link java.util.TimerTask#run()}.
	Alternatively sends as <var>arg</var> {@link java.lang.Boolean#TRUE} and {@link java.lang.Boolean#FALSE}.

	@version $Revision: 1.2 $ $Date: 2002/01/16 05:08:16 $
*/
public class SyncTimerTask extends TimerTask {
  private Boolean state = Boolean.TRUE;

  Observable o = new Observable() {
	public void notifyObservers(Object arg) { setChanged(); super.notifyObservers(arg); }
  };


  //public SyncTimerTask() {}
  //public SyncTimerTask(Observer first) { o.addObserver(first); }

  public Observable getObservable() { return o; }

  public void run() {
	state = (state==Boolean.TRUE? Boolean.FALSE: Boolean.TRUE);
	o.notifyObservers(state);
  }
}
