package com.shfarr.ui.wizards;

import java.util.Vector;

public class WizardManager{
  protected static WizardManager currentManager = null;
  protected Vector pool = null;
  protected int poolSize = 10;
/**
 * WizardManager constructor comment.
 */
protected WizardManager(){
  pool = new Vector();

}
protected Wizard createWizard(String job){
  try{
	  return (Wizard)Class.forName(System.getProperty("ui.wizardry.jobs." + job)).newInstance();
  }
  catch(Exception e){
  }

  return null;
}
public static WizardManager getCurrentManager(){
  if(currentManager==null){
	 currentManager = new WizardManager();
  }

  return currentManager;
}
/**
 * Insert the method's description here.
 * Creation date: (11/7/01 2:02:05 PM)
 * @return int
 */
public int getPoolSize() {
	return poolSize;
}
public Wizard hireWizard(String job){
  Wizard wizard = null;

  for(int i=0; i<pool.size(); i++){
	  if(((Wizard)pool.get(i)).canDo(job) && !((Wizard)pool.get(i)).isBusy()){
		 wizard = (Wizard)pool.get(i);
		 break;
	  }
  }
  
  if(wizard==null){
	 wizard = createWizard(job);
     if(wizard!=null){
	    for(int i=0; i < pool.size() && pool.size() < getPoolSize() -1; i++){
		    if(!((Wizard)pool.get(i)).isBusy()){
			   pool.remove(i);
			   i--;
		    }
	    }

	    pool.add(wizard);
     }
  }

  return wizard;
}
/**
 * Insert the method's description here.
 * Creation date: (11/7/01 2:02:05 PM)
 * @param newPoolSize int
 */
public void setPoolSize(int newPoolSize) {
	poolSize = newPoolSize;
}
}
