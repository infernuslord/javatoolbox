
package hamsam.protocol.aim.command;

public class ServerContactListCmd
{
}
