/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh.ext;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Rectangle;

import javax.swing.UIManager;
import javax.swing.table.DefaultTableCellRenderer;

import com.shfarr.ui.plaf.fh.textures.Texture;
import com.shfarr.ui.plaf.fh.theme.ThemeManager;

public class FhTableHeaderCellRenderer extends DefaultTableCellRenderer implements javax.swing.plaf.UIResource{
	protected int crow = 0;
    protected int ccol = 0;

	public FhTableHeaderCellRenderer() {
		super();
        setOpaque(true);
        setHorizontalAlignment(CENTER);
	}

    public Font getFont(){
        return UIManager.getFont("TableHeader.font");
    }

    public Color getBackground(){
        return UIManager.getColor("TableHeader.cellBackground");
    }

    public Rectangle getVisibleRect(){
        return new Rectangle(0, 0, getWidth(), getHeight());
    }
    
    public Dimension getPreferredSize(){
        Dimension d = super.getPreferredSize();
        
        if(getBorder() != null){
            Insets i = getBorder().getBorderInsets(this);
            
            d.width += i.left + i.right;
            d.height += i.top + i.bottom;
        }
        
        return d;
    }
	
    public java.awt.Component getTableCellRendererComponent(javax.swing.JTable table, Object value, boolean selected, boolean hasFocus, int row, int col){
	    this.crow = row;
        this.ccol = col;
        
//	    if(table != null) return super.getTableCellRendererComponent(table, value, selected, hasFocus, row, col);
//        return this;
        return super.getTableCellRendererComponent(table, value, selected, hasFocus, row, col);
	}

	public void paint(Graphics g){
        g.setFont(UIManager.getFont("TableHeader.font"));
        
        setOpaque(true);
        Color prevFore = getForeground();
        setForeground(Color.white);
        g.translate(1, 1);

        super.paint(g);

        Texture texture = (Texture)UIManager.getDefaults().get("TableHeader.texture");
        if(texture != null && ThemeManager.instance().probeSmallTextures()) texture.apply(new Rectangle(0, 0, getWidth() -1, getHeight()), (Graphics2D)g, this);

        g.translate(-1, -1);
        
        setForeground(prevFore);
        setOpaque(false);

        super.paint(g);

        UIManager.getBorder("TableHeader.cellBorder").paintBorder(this, g, 0, 0, getWidth(), getHeight());
        
        g.setColor(UIManager.getColor("Viewport.background"));
        g.setColor(Color.red);
        g.drawLine(getWidth(), 0, getWidth(), getHeight());
	}
}