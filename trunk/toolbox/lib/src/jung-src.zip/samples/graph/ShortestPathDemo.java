/*
 * Created on Jan 2, 2004
 */
package samples.graph;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;

import javax.swing.*;

import edu.uci.ics.jung.algorithms.connectivity.BFSDistanceLabeler;
import edu.uci.ics.jung.graph.Edge;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.graph.decorators.EdgeColorFunction;
import edu.uci.ics.jung.graph.decorators.EdgeThicknessFunction;
import edu.uci.ics.jung.graph.decorators.StringLabeller;
import edu.uci.ics.jung.graph.decorators.VertexColorFunction;
import edu.uci.ics.jung.graph.decorators.StringLabeller.UniqueLabelException;
import edu.uci.ics.jung.random.generators.EppsteinPowerLawGenerator;
import edu.uci.ics.jung.visualization.FRLayout;
import edu.uci.ics.jung.visualization.GraphDraw;

/**
 * @author danyelf
 */
public class ShortestPathDemo extends JPanel {

    boolean isBlessed( Edge e ) {
		Vertex v1= (Vertex) e.getEndpoints().getFirst()	;
		Vertex v2= (Vertex) e.getEndpoints().getSecond() ;
		return mPred.contains(v1) && mPred.contains( v2 );
/*		int blessed = 0;
		blessed += mPred.contains(v1) ? 1 : 0;
		blessed += mPred.contains(v2) ? 1 : 0;
//		blessed += (mFrom == v1 || mFrom == v2) ? 1 : 0;
//		blessed += (mTo == v1 || mTo == v2) ? 1 : 0;
		return blessed == 2;       
*/    }
    
	/**
	 * @author danyelf
	 */
	public class MyEdgeColorFunction implements EdgeColorFunction {
	    
		/**
		 * @see edu.uci.ics.jung.graph.decorators.EdgeColorFunction#getEdgeColor(edu.uci.ics.jung.graph.Edge)
		 */
		public Color getEdgeColor(Edge e) {
			if ( mPred == null || mPred.size() == 0) return Color.BLACK;
			if( isBlessed( e )) {
				return Color.BLUE;
			} else {
				return Color.LIGHT_GRAY;
			}
		}
	}
	
	public class MyEdgeThicknessFunction implements EdgeThicknessFunction {

        public float getEdgeThickness(Edge e) {
			if ( mPred == null || mPred.size() == 0) return 1;
			if (isBlessed( e ) ) {
			    return 3;
			} else 
			    return 1;
        }
	    
	}
	
	/**
	 * @author danyelf
	 */
	public class MyVertexColorFunction implements VertexColorFunction {

		public Color getForeColor(Vertex v) {
			return Color.black;
		}
		
		public Color getBackColor( Vertex v ) {
			if ( v == mFrom) {
				return Color.BLUE;
			}
			if ( v == mTo ) {
				return Color.BLUE;
			}
			if ( mPred == null ) {
				return Color.LIGHT_GRAY;
			} else {
				if ( mPred.contains(v)) {
					return Color.RED;
				} else {
					return Color.LIGHT_GRAY;
				}
			}
		}

	}

	/**
	 * Starting vertex
	 */
	private Vertex mFrom;

	/**
	 * Ending vertex
	 */	
	private Vertex mTo;
	private Graph mGraph;
	private GraphDraw mGD;
	private Set mPred;

	/**
	 * @param g
	 */
	public ShortestPathDemo(Graph g) {
		this.mGraph = g;
		setBackground(Color.WHITE);
		// show graph
		mGD = new GraphDraw(g);
		mGD.setBackground(Color.WHITE);
		
		mGD.hideStatus();
		mGD.setGraphLayout(new FRLayout(g));
		mGD.setVertexColorFunction(new MyVertexColorFunction());
		mGD.setEdgeColorFunction(new MyEdgeColorFunction());
		mGD.setEdgeThicknessFunction(new MyEdgeThicknessFunction());
		
		setLayout(new BorderLayout());
		add(mGD, BorderLayout.CENTER);
		// set up controls
		add(setUpControls(), BorderLayout.SOUTH);
	}

	/**
	 *  
	 */
	private JPanel setUpControls() {
		JPanel jp = new JPanel();
		jp.setBackground(Color.WHITE);
		jp.setLayout(new BoxLayout(jp, BoxLayout.PAGE_AXIS));
		jp.setBorder(BorderFactory.createLineBorder(Color.black, 3));		
		jp.add(
			new JLabel("Select a pair of vertices to calculate a shortest path"));
		JPanel jp2 = new JPanel();
		jp2.add(new JLabel("vertex from", SwingConstants.LEFT));
		jp2.add(getSelectionBox(true));
		jp2.setBackground(Color.white);
		JPanel jp3 = new JPanel();
		jp3.add(new JLabel("vertex to", SwingConstants.LEFT));
		jp3.add(getSelectionBox(false));
		jp3.setBackground(Color.white);
		jp.add( jp2 );
		jp.add( jp3 );
		return jp;
	}

	/**
	 * @param g
	 * @param from
	 * @return
	 */
	private Component getSelectionBox(final boolean from) {
		StringLabeller sl = StringLabeller.getLabeller(mGraph);
		Set s = new TreeSet();
		
		for (Iterator iter = mGraph.getVertices().iterator();
			iter.hasNext();
			) {
			s.add(sl.getLabel((Vertex) iter.next()));
		}
		final JComboBox choices = new JComboBox(s.toArray());
		choices.setSelectedIndex(-1);
		choices.setBackground(Color.WHITE);
		choices.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				StringLabeller sl = StringLabeller.getLabeller(mGraph);
				Vertex v = sl.getVertex((String) choices.getSelectedItem());
				if (from) {
					mFrom = v;
					System.out.println("Assigned mFrom!");
				} else {
					mTo = v;
					System.out.println("Assigned mTo!");
				}
				drawShortest();
				repaint();				
			}

		});
		return choices;
	}

	/**
	 *  
	 */
	protected void drawShortest() {
		if (mFrom == null || mTo == null) {
			return;
		}
		BFSDistanceLabeler bdl = new BFSDistanceLabeler();
		bdl.labelDistances(mGraph, mFrom);
		mPred = new HashSet();
		
		StringLabeller sl = StringLabeller.getLabeller(mGraph);
		
		// grab a predecessor
		Vertex v = mTo;
		Set prd = bdl.getPredecessors(v);
		mPred.add( mTo );
		while( prd != null && prd.size() > 0) {
			System.out.print("Preds of " + sl.getLabel(v) + " are: ");
			for (Iterator iter = prd.iterator(); iter.hasNext();) {
				Vertex x = (Vertex) iter.next();
				System.out.print( sl.getLabel(x) +" " );
			}
			System.out.println();
			v = (Vertex) prd.iterator().next();
			mPred.add( v );
			if ( v == mFrom ) return;
			prd = bdl.getPredecessors(v);
		}
	}

	public static void main(String[] s) {
		Graph g = getGraph();
		JFrame jf = new JFrame();
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.getContentPane().add(new ShortestPathDemo(g));
		jf.pack();
		jf.show();
	}

	/**
	 * @return
	 */
	static Graph getGraph() {
		//		return TestGraphs.getDemoGraph();
		Graph g =
			(Graph) new EppsteinPowerLawGenerator(26, 50, 50).generateGraph();
		Set removeMe = new HashSet();
		for (Iterator iter = g.getVertices().iterator(); iter.hasNext();) {
            Vertex v = (Vertex) iter.next();
            if ( v.degree() == 0 ) {
                removeMe.add( v );
            }
        }
		g.removeVertices(removeMe);
		StringLabeller sl = StringLabeller.getLabeller(g);
		char c = 0;
		for (Iterator iter = g.getVertices().iterator(); iter.hasNext();) {
			Vertex v = (Vertex) iter.next();
			try {
				sl.setLabel(v, "" + (char) (c + 'a'));
			} catch (UniqueLabelException e) {
			}
			c++;
		}
		return g;
	}

}
