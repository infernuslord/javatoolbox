/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.beans;

import javax.xml.parsers.*;
import org.xml.sax.*;

import java.io.*;
import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Comparator;
import java.util.Map;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.Stack;

import org.xml.sax.helpers.*;

import sun.misc.BASE64Decoder;

public class XMLDecoder implements ObjectDecoder{
    protected SAXParser parser = null;
    protected ObjectDecoder decoder = null;
    protected InputStream in = null;
    protected Object result = null;

    public XMLDecoder(InputStream in) throws IOException {
        this(in, null);
    }

    public XMLDecoder(InputStream in, ObjectDecoder decoder) throws IOException {
        this.in = in;
        this.decoder = decoder;

        SAXParserFactory factory = SAXParserFactory.newInstance();

        try{
            parser = factory.newSAXParser();
        }
        catch (Exception e) {
            throw new Error("Nested exception [" + e.getMessage() + "]");
        }
    }

    public void close() throws IOException{
        in.close();
    }

    public ObjectDecoder getDecoder() {
        return decoder != null ? decoder : this;
    }

    public synchronized Object readObject() throws IOException, SAXException{
//        try{
            parser.parse(in, new BeanReconstrictionHandler());
//        }
//        catch(Exception e){
//            handleException(e);
//            throw new Error("Nested exception [" + e.getMessage() + "]");
//        }

        return result;
    }

    public Object decodeObject(String value, Class c){
        if(c.equals(boolean.class) || c.equals(Boolean.class)) return new Boolean(value);
        if(c.equals(byte.class) || c.equals(Byte.class)) return new Byte(value);
        if(c.equals(char.class) || c.equals(Character.class)) return new Character(value.charAt(0));
        if(c.equals(short.class) || c.equals(Short.class)) return new Short(value);
        if(c.equals(int.class) || c.equals(Integer.class)) return new Integer(value);
        if(c.equals(long.class) || c.equals(Long.class)) return new Long(value);
        if(c.equals(float.class) || c.equals(Float.class)) return new Float(value);
        if(c.equals(double.class) || c.equals(Double.class)) return new Double(value);
        if(c.equals(byte[].class)){
            try{
                return new BASE64Decoder().decodeBuffer(value);
            }
            catch(Exception e){
                handleException(e);
            }
        }
        if(c.equals(java.math.BigDecimal.class)) return new java.math.BigDecimal(value);
        if(c.equals(java.math.BigInteger.class)) return new java.math.BigInteger(value);
        if(c.equals(String.class)) return value;

        return null;
    }

    protected synchronized void setResult(Object o) {
        result = o;
    }

    protected static Class decodeType(String str) {
        Class c = null;
        boolean isArray = false;
        
        if(str.endsWith("[]")){
            str = str.substring(0, str.length() -2);
            isArray = true;
        }
        
        if (str.equals("byte")) c = byte.class;
        else if (str.equals("int")) c = int.class;
        else if (str.equals("long")) c = long.class;
        else if (str.equals("short")) c = short.class;
        else if (str.equals("float")) c = float.class;
        else if (str.equals("double")) c = double.class;
        else if (str.equals("char")) c = char.class;
        else if (str.equals("boolean")) c = boolean.class;
        else{
            try{
                c = Class.forName(str);
            }
            catch(Exception e){
            }
        }

        return isArray ? Array.newInstance(c, 0).getClass() : c;
    }

    protected static void handleException(Exception e) {
        System.out.println("Minor error parsing xml!");
        e.printStackTrace();
    }

    public class BeanReconstrictionHandler extends DefaultHandler {
        protected StringBuffer value = null;
        protected Stack objectStack = null;
        protected Stack mapStack = null;
        protected Stack indexStack = null;

        public BeanReconstrictionHandler(){
            super();

            objectStack = new Stack();
            mapStack = new Stack();
            indexStack = new Stack();

            value = new StringBuffer();
        }

        public void characters(char[] ch, int start, int length){
            value.append(new String(ch, start, length));
        }

        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            value.delete(0, value.length());
            Class type = null;
            
            if(attributes.getValue("type") == null){
                // type attribute is null it means
                // we are not dealing with a property but an object

                //put together the type of the object 
                String className = attributes.getValue("package") +
                                   (attributes.getValue("package") != null && !attributes.getValue("package").equals("") ? "." : "") +
                                   (attributes.getValue("type") == null ? qName : attributes.getValue("type"));

                type = decodeType(className);

                if(attributes.getValue("extent") != null){
                    // when extent is not null we have an array
                    // so we instantiate an array with the specified length
                    // and add it to the object stack
                    String[] dimStrs = attributes.getValue("extent").split("x");

                    int[] dimensions = new int[dimStrs.length];
                    for(int i = 0; i < dimensions.length; i++) dimensions[i] = Integer.parseInt(dimStrs[i]);
                    
                    objectStack.push(Array.newInstance(type, dimensions));
                    
                    indexStack.push(new Integer(0));
                }
                else{
                    // else we try to regulary instatiate the object
                    // using reflection
                    try{
                        // if it works it we consider it a bean object
                        // and add the bean to the stack
                        if((SortedSet.class.isAssignableFrom(type) || SortedMap.class.isAssignableFrom(type)) && attributes.getValue("comparator") != null){
                            objectStack.push(type.getConstructor(new Class[]{Comparator.class}).newInstance(new Object[]{Class.forName(attributes.getValue("comparator")).newInstance()}));
                        }
                        else objectStack.push(type.newInstance());
                        
                        if(objectStack.peek() instanceof Map) mapStack.push(new Stack());
                    }
                    catch(Exception e){
                        // e.printStackTrace();
                        // if it doesn't work, we are definitely not dealing
                        // with a bean and we add the class itself to the stack and attempt to instatiate
                        // it when we have a value
                        objectStack.push(type);
                    }
                }
            }
            else{
                // type attribute is not null it means
                // we are dealing with a property
                // to which we try to find out the type of the value of the property
                // rather then the type of the property (property type maybe Object)
                // and it's value any type. We need this type to be able to instatiate
                String typeName = attributes.getValue("enclosed");

                if(typeName != null){
                    type = decodeType(typeName.endsWith("[]") ? typeName.substring(0, typeName.length() -2) : typeName);
                    if(typeName.endsWith("[]")) type = Array.newInstance(type, 0).getClass();
                }

                try{
                    // if we are able to create the handler
                    // we add it to the stack
                    PropertyHandler handler = new PropertyHandler(Introspector.instance().getProperty(objectStack.peek().getClass(), BeanUtils.unpackPropertyName(qName)), objectStack.peek());
                    if(type != null) handler.setEnclosedType(type);
                    objectStack.push(handler);
                }
                catch(Exception e){
                      handleException(e);
                }
            }
        }

        public void endElement(String uri, String localName, String qName) throws SAXException{
            Object object = objectStack.pop();
            if(object.getClass().isArray()) indexStack.pop(); // remove trash index stack
            if(object instanceof Map) mapStack.pop(); // remove trash map stack

            if(object instanceof PropertyHandler){
                // when elemnt is a property handler
                // it means that a primitive value is storred within the property
                if("null".equals(value)) ((PropertyHandler)object).setValue(null);

                Class type = ((PropertyHandler)object).getEnclosedType();
                if(type == null) type = ((PropertyHandler)object).getProperty().getType();
                
                Object decodedObject = getDecoder().decodeObject(value.toString(), type);
                if(decodedObject != null) ((PropertyHandler)object).setValue(decodedObject);
            }
            else{
                // otherwise
                Object decodedObject = value == null ? null : getDecoder().decodeObject(value.toString(), object instanceof Class ? (Class)object : object.getClass());
                Object parent = objectStack.isEmpty() ? null : objectStack.peek();

                if(decodedObject != null) object = decodedObject;
                if(Void.class.equals(object)) object = null;

                if(parent != null){
                    if(parent instanceof PropertyHandler){
                        // parent is a property handler
                        // when the object is the value of the property
                        ((PropertyHandler)parent).setValue(object);
                    }
                    else if(parent.getClass().isArray()){
                        // parent is an array
                        // so the current object is the value of one of the cells
                        int cIndex = ((Integer)indexStack.pop()).intValue();
                        Array.set(parent, cIndex, object);
                        indexStack.push(new Integer(cIndex +1));
                    }
                    else if(parent instanceof Map){
                        // parent is a map (key, value) pairs
                        // key is buffered then when value is found they are added together
                        Stack stack = (Stack)mapStack.peek();

                        if(stack.isEmpty()) stack.push(object);
                        else ((Map)parent).put(stack.pop(), object);
                    }
                    else if(parent instanceof Collection){
                        // parent is a collection
                        // so the current object is a member of the collection
                        ((Collection)parent).add(object);
                    }
                }
                else{
                    if(object instanceof Class){
                        try{
                            result = ((Class)object).newInstance();
                        }
                        catch(Exception e){
                            throw new Error(e);
                        }
                    }
                    else result = object;
                }
            }
        }

    }
}
