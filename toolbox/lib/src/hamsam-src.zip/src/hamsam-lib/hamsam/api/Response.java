/*
 * Please see COPYING for license details
 *
 * Copyright (C) 2003 Raghu K, All rights reserved.
 */

package hamsam.api;

import java.io.Serializable;

/**
 * A response to allow or disallow a user request.
 *
 * There are scenarios where the user is asked to allow or
 * disallow a request that came from another user. Some
 * examples are request to add a user to another user's
 * buddy list, an invitation for conference, and request for
 * file transfer. If they disallow such requests, they are requested
 * to give an explanation why they chose to disallow the
 * request. This class encapsulates the choice that the user
 * made as well as the explanation they gave, if any.
 *
 * @author Raghu
 */
public class Response implements Serializable
{
	/**
	 * Does this Response accept the request?
	 */
	private boolean accept;

	/**
	 * The explanation for rejection.
	 */
	private String message;

	/**
	 * Creates a response which accepts the request involved.
	 */
	public Response()
	{
		this.accept = true;
	}

	/**
	 * Creates a response which rejects the request involved.
	 *
	 * @param message the explanation for the rejection.
	 */
	public Response(String message)
	{
		this.accept = false;
		this.message = new String(message);
	}

	/**
	 * Determines if this response accepts the request involved.
	 *
	 * @return <code>true</code> if the response accepts request involved,
	 *         <code>false</code> otherwise.
	 */
	public boolean isAccepted()
	{
		return accept;
	}

	/**
	 * Returns the explanation for rejection of the request involved.
	 *
	 * @return the explanation message if the request was rejected,
	 *         <code>null</code> otherwise.
	 */
	public String getMessage()
	{
		return message;
	}
}
