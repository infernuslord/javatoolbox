/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh;

import java.awt.*;
import java.awt.image.BufferedImage;

import javax.swing.*;
import javax.swing.plaf.*;
import javax.swing.border.*;
import javax.swing.plaf.basic.*;
import java.beans.*;

import com.shfarr.DevUtils;
import com.shfarr.ui.*;
import com.shfarr.ui.ChannelImageFilter;
import com.shfarr.ui.GraphicsUtils;
import com.shfarr.ui.plaf.fh.ext.*;
import com.shfarr.ui.plaf.fh.textures.*;
import com.shfarr.ui.plaf.fh.theme.*;


public class FhComboBoxUI extends BasicComboBoxUI{
    private static ChannelImageFilter fadeFilter = new ChannelImageFilter(0.1, 0, 0, 0);
    
    private static final Animator animator = new Animator();
    
    private static class Animator implements Runnable{
        private Graphics ag = null;
        private BufferedImage img = null;
        private Component c = null;
        
        public void animate(Graphics g, BufferedImage img, Component c){
            this.ag = g;
            this.img = img;
            this.c = c;
        }
        
        public void run(){
            Image faded = GraphicsUtils.applyFilter(img, fadeFilter);

            for(int i = 0; i < 10; i++){
                ag.drawImage(faded, 0, 0, null);
                
                try{
                	synchronized(this){
                        wait(10);
                    }
                }
                catch(InterruptedException e){
                    DevUtils.handleException("(shfarr :: FhComboBoxUI.java)", e);
                }
            }

            ag.drawImage(img, 0, 0, null);
        }
    };
    
	protected Border popupBorder = null;

	public FhComboBoxUI(){
	  super();
	}


	public void configureEditor() {
	  super.configureEditor();
	}


	protected JButton createArrowButton() {
	  JButton button = new FhComboBoxButton();
	  return button;
	}


	protected LayoutManager createLayoutManager() {
	  return new FhComboBoxLayoutManager();
	}


	protected ComboPopup createPopup(){
      BasicComboPopup popup = new BasicComboPopup(comboBox){
          public String getUIClassID(){
              return "ComboPopupUI";
          }
          
          protected void configurePopup(){
              super.configurePopup();
              setBorder(null);
          }
      };
      
      popup.getAccessibleContext().setAccessibleParent(comboBox);

//      popup.setBorder(null);
//      LookAndFeel.installBorder(popup, "ComboBox.popupBorder");
//      LookAndFeel.installColors(popup, "ComboBox.popupBackground", "PopupMenu.foreground");
      
	  return popup;
	}


	public PropertyChangeListener createPropertyChangeListener() {
	    return new PropertyChangeHandler(){
	        public void propertyChange(PropertyChangeEvent e) {
	            super.propertyChange(e);
	            String propertyName = e.getPropertyName();
	
	            if (propertyName.equals("editable")) {
	                FhComboBoxButton button = getArrowButton();
	                //button.setIconOnly(getComboBox().isEditable());
	                getComboBox().repaint();
	            }
	            else if (propertyName.equals("background")) {
	                Color color = (Color) e.getNewValue();
	                getArrowButton().setBackground(color);
	                getListBox().setBackground(color);
	
	            }
	            else if (propertyName.equals("foreground")) {
	                Color color = (Color) e.getNewValue();
	                getArrowButton().setForeground(color);
	                getListBox().setForeground(color);
	            }
	        }
	    };
	}


	public static ComponentUI createUI(JComponent c) {
	  return new FhComboBoxUI();
	}


	public FhComboBoxButton getArrowButton(){
	  return (FhComboBoxButton)arrowButton;
	}


	protected JComboBox getComboBox(){
	  return comboBox;
	}


	public Component getEditor(){
	  return editor;
	}


	protected JList getListBox(){
	  return listBox;
	}


	public Dimension getMinimumSize(JComponent c){
        Insets i = c.getBorder() != null ? c.getBorder().getBorderInsets(c) : new Insets(0, 0, 0, 0);
	    
        int mh = (int)(c.getFont().getSize()*1.5) +i.top +i.bottom;

        if(ThemeManager.instance().getPreferences().isBordersDoubled()) mh = (int)(mh*1.5);
        
        return new Dimension(getListBox().getPreferredSize().width +mh +3, mh);
	}


	public void installUI(JComponent jc){
	  super.installUI(jc);
	  ((JComboBox)jc).setLightWeightPopupEnabled(true);
	}
	
	
	public void paint(Graphics g, JComponent c){
      ThemeManager.instance().probeAntialiasing(g);
      
      super.paint(g, c);

      Rectangle r = rectangleForCurrentValue();
	
	  g.setColor((Color)UIManager.getDefaults().get("EditableComponent.background"));
	  g.drawRect(r.x +r.width -1, r.y, c.getSize().width -getInsets().right -(r.x +r.width), r.height -1);
	
	  g.setColor(UIManager.getColor("Component.moderatedShadow"));
	  g.drawLine(r.x +r.width -2, r.y, r.x +r.width -2, r.height +1);
	
   	  Texture texture = (Texture)UIManager.getDefaults().get("Field.inactiveTexture");
	  if(texture != null && ThemeManager.instance().probeSmallTextures()) texture.apply(r, (Graphics2D)g, c);
	}
	
	
	public Rectangle rectangleForCurrentValue(){
	    int width = comboBox.getWidth();
	    int height = comboBox.getHeight();
	
	    Insets insets = getInsets();
	
	    int buttonSize = height - (insets.top + insets.bottom);
	
	    if (arrowButton != null) {
	        buttonSize = arrowButton.getWidth();
	    }
	
	    if (comboBox.getComponentOrientation().isLeftToRight()) {
	        return new Rectangle(insets.left, insets.top, width - (insets.left + insets.right + buttonSize) -1, height - (insets.top + insets.bottom));
	    }
	    else return new Rectangle(insets.left + buttonSize, insets.top, width - (insets.left + insets.right + buttonSize), height - (insets.top + insets.bottom));
	}


	public void unconfigureEditor() {
		super.unconfigureEditor();
	}


   /**
    * @version test 1.0
    * @author Stefan H. Farr
    * This software is published under the terms of General Public License
    */
	protected class FhComboBoxButton extends FhSysButton{
	
		public FhComboBoxButton(){
		  super(FhSysButton.ARROW_SOUTH, 0);
		  
		  DefaultButtonModel model = new DefaultButtonModel() {
		     public void setArmed( boolean armed ) {
		       super.setArmed( isPressed() ? true : armed );
		     }
		  };
		}
		
		protected int getExtraInset(){
		  return Math.max((int)((float)Math.min(getSize().width, getSize().height)*(float)5/(float)15) -4, 0);
		}
	}


	/**
	 * @version test 1.0
	 * @author Stefan H. Farr
	 * This software is published under the terms of General Public License
	 */
	protected class FhComboBoxLayoutManager implements LayoutManager{

		public FhComboBoxLayoutManager() {
			super();
		}


		public void addLayoutComponent(String name, Component comp) {}


		public void layoutContainer(Container parent) {
		    JComboBox cb = (JComboBox) parent;
		    int width = cb.getWidth();
		    int height = cb.getHeight();
		
		    Insets insets = cb.getInsets();
		    int buttonSize = height - (insets.top + insets.bottom);
		    Rectangle cvb;
		
		    if(((FhComboBoxUI)cb.getUI()).getArrowButton()!= null) {
		       if(cb.getComponentOrientation().isLeftToRight()){
		          ((FhComboBoxUI)cb.getUI()).getArrowButton().setBounds(width - (insets.right + buttonSize) -1, insets.top +1, buttonSize, buttonSize -2);
		       }
		       else((FhComboBoxUI)cb.getUI()).getArrowButton().setBounds(insets.left, insets.top, buttonSize, buttonSize);
		    }
		
		    if(((FhComboBoxUI)cb.getUI()).getEditor()!=null) {
		        cvb = ((FhComboBoxUI)cb.getUI()).rectangleForCurrentValue();
		        ((FhComboBoxUI)cb.getUI()).getEditor().setBounds(cvb);
		    }
		}


		public Dimension minimumLayoutSize(Container parent){
		  JComboBox cb = (JComboBox)parent;
		  return parent.getMinimumSize();
		}


		public Dimension preferredLayoutSize(Container parent){
		    JComboBox cb = (JComboBox)parent;
		    return parent.getPreferredSize();
		}


		public void removeLayoutComponent(Component comp) {}
	}
}
