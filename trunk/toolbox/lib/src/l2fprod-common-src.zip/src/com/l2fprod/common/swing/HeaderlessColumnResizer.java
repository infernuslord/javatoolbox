/** ===================================================================
 *
 * L2FProd.com Common Components 0.1-dev License.
 *
 * Copyright (c) 2004 L2FProd.com.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by L2FProd.com
 *        (http://www.L2FProd.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "L2FProd.com Common Components", "l2fprod-common" and "L2FProd.com" must not
 *    be used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact info@L2FProd.com.
 *
 * 5. Products derived from this software may not be called "l2fprod-common"
 *    nor may "l2fprod-common" appear in their names without prior written
 *    permission of L2FProd.com.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL L2FPROD.COM OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package com.l2fprod.common.swing;

import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JViewport;
import javax.swing.event.MouseInputAdapter;
import javax.swing.table.TableColumn;

/**
 * HeaderlessColumnResizer. <br>
 * 
 * Allows table columns to be resized not only using the header but from any
 * rows. Based on the BasicTableHeaderUI code.
 */
public class HeaderlessColumnResizer extends MouseInputAdapter {

  private static Cursor resizeCursor =
    Cursor.getPredefinedCursor(Cursor.E_RESIZE_CURSOR);

  private int mouseXOffset;
  private Cursor otherCursor = resizeCursor;

  private JTable table;

  public HeaderlessColumnResizer(JTable table) {
    this.table = table;
    table.addMouseListener(this);
    table.addMouseMotionListener(this);
  }

  private boolean canResize(TableColumn column) {
    return (column != null)
      && table.getTableHeader().getResizingAllowed()
      && column.getResizable();
  }

  private TableColumn getResizingColumn(Point p) {
    return getResizingColumn(p, table.columnAtPoint(p));
  }

  private TableColumn getResizingColumn(Point p, int column) {
    if (column == -1) {
      return null;
    }
    int row = table.rowAtPoint(p);
    Rectangle r = table.getCellRect(row, column, true);
    r.grow(-3, 0);
    if (r.contains(p)) {
      return null;
    }
    int midPoint = r.x + r.width / 2;
    int columnIndex;
    if (table.getTableHeader().getComponentOrientation().isLeftToRight()) {
      columnIndex = (p.x < midPoint) ? column - 1 : column;
    } else {
      columnIndex = (p.x < midPoint) ? column : column - 1;
    }
    if (columnIndex == -1) {
      return null;
    }
    return table.getTableHeader().getColumnModel().getColumn(columnIndex);
  }

  public void mousePressed(MouseEvent e) {
    table.getTableHeader().setDraggedColumn(null);
    table.getTableHeader().setResizingColumn(null);
    table.getTableHeader().setDraggedDistance(0);

    Point p = e.getPoint();

    // First find which header cell was hit
    int index = table.columnAtPoint(p);

    if (index != -1) {
      // The last 3 pixels + 3 pixels of next column are for resizing
      TableColumn resizingColumn = getResizingColumn(p, index);
      if (canResize(resizingColumn)) {
        table.getTableHeader().setResizingColumn(resizingColumn);
        if (table.getTableHeader().getComponentOrientation().isLeftToRight()) {
          mouseXOffset = p.x - resizingColumn.getWidth();
        } else {
          mouseXOffset = p.x + resizingColumn.getWidth();
        }
      }
    }
  }

  private void swapCursor() {
    Cursor tmp = table.getCursor();
    table.setCursor(otherCursor);
    otherCursor = tmp;
  }

  public void mouseMoved(MouseEvent e) {
    if (canResize(getResizingColumn(e.getPoint()))
      != (table.getCursor() == resizeCursor)) {
      swapCursor();
    }
  }

  public void mouseDragged(MouseEvent e) {
    int mouseX = e.getX();

    TableColumn resizingColumn = table.getTableHeader().getResizingColumn();

    boolean headerLeftToRight =
      table.getTableHeader().getComponentOrientation().isLeftToRight();

    if (resizingColumn != null) {
      int oldWidth = resizingColumn.getWidth();
      int newWidth;
      if (headerLeftToRight) {
        newWidth = mouseX - mouseXOffset;
      } else {
        newWidth = mouseXOffset - mouseX;
      }
      resizingColumn.setWidth(newWidth);

      Container container;
      if ((table.getTableHeader().getParent() == null)
        || ((container = table.getTableHeader().getParent().getParent()) == null)
        || !(container instanceof JScrollPane)) {
        return;
      }

      if (!container.getComponentOrientation().isLeftToRight()
        && !headerLeftToRight) {
        if (table != null) {
          JViewport viewport = ((JScrollPane)container).getViewport();
          int viewportWidth = viewport.getWidth();
          int diff = newWidth - oldWidth;
          int newHeaderWidth = table.getWidth() + diff;

          /* Resize a table */
          Dimension tableSize = table.getSize();
          tableSize.width += diff;
          table.setSize(tableSize);

          /*
           * If this table is in AUTO_RESIZE_OFF mode and has a horizontal
           * scrollbar, we need to update a view's position.
           */
          if ((newHeaderWidth >= viewportWidth)
            && (table.getAutoResizeMode() == JTable.AUTO_RESIZE_OFF)) {
            Point p = viewport.getViewPosition();
            p.x =
              Math.max(0, Math.min(newHeaderWidth - viewportWidth, p.x + diff));
            viewport.setViewPosition(p);

            /* Update the original X offset value. */
            mouseXOffset += diff;
          }
        }
      }
    }
  }

  public void mouseReleased(MouseEvent e) {
    //setDraggedDistance(0, viewIndexForColumn(header.getDraggedColumn()));

    table.getTableHeader().setResizingColumn(null);
    table.getTableHeader().setDraggedColumn(null);
  }

  public void mouseEntered(MouseEvent e) {
  }

  public void mouseExited(MouseEvent e) {
  }

}
