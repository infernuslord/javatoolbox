package multivalent.std.span;

import java.awt.Color;
import java.util.Map;

import multivalent.*;
import multivalent.std.ui.DocumentPopup;

import phelps.awt.Colors;



/**
	Background span with editable color.

	@version $Revision: 1.3 $ $Date: 2002/02/02 13:16:26 $
*/
public class BackgroundSpan extends Span {
  /**
	Change the color to <tt>arg</tt>, which can be {@link java.lang.String} or {@link java.awt.Color}.
	<p><tt>"changeColor"</tt>: <tt>arg=</tt> <var>color, as String or Color</var>.
  */
  public static final String MSG_CHANGE = "changeColor";

  /**
	Pop up dialog asking user color choice.
	<p><tt>"editColor"</tt>.
  */
  public static final String MSG_EDIT = "editColor";


  /** List of color names, separated by spaces, such as "Yellow Orange Green Blue". */
  public static final String ATTR_COLORS = "colors";

  /** Color of background. */
  public static final String ATTR_COLOR = "color";


  static String[] choices_ = null;
  static String oldchoices_ = null;
  static Color defaultColor_ = Color.YELLOW; //Context.COLOR_INVALID;


  Color color_ = defaultColor_;


  /** Set to {@link Context#COLOR_INVALID} to invalidate, null for transparent. */
  public void setColor(Color color) { color_=color; }

  public Color getColor() { return color_; }

  public boolean appearance(Context cx, boolean all) { if (color_!=Context.COLOR_INVALID) cx.background=color_; return false; }


  public boolean semanticEventBefore(SemanticEvent se, String msg) {
	if (super.semanticEventBefore(se,msg)) return true;
	if (this!=se.getIn()) return false;     // quick exit

	if (DocumentPopup.MSG_CREATE_DOCPOPUP==msg && isEditable()) {
		INode menu = (INode)se.getOut();
		Browser br = getBrowser();

		// be responsive to change in preferences
		String curchoices = getPreference(ATTR_COLORS, "Yellow Orange Green Blue");
		if (!curchoices.equals(oldchoices_)) {
			choices_ = curchoices.split("\\s+");
			oldchoices_ = curchoices;
		}

		//createUI("button", "Edit Color...", new SemanticEvent(br, MSG_EDIT, null, this, null), menu, "EDIT", false);
		for (int i=0, imax=choices_.length; i<imax; i++) {
			String co = choices_[i];
			createUI("button", co, new SemanticEvent(br, MSG_CHANGE, co, this, null), menu, "EDIT", false); // true if same color
		}
	}

	//return super.semanticEventBefore(se,msg);  // local menu items go first -- unusual
	return false;   // try the other way
  }


  public boolean semanticEventAfter(SemanticEvent se, String msg) {
	if (this!=se.getIn()) {
		// catch super.sEA() at bottom
	} else if (MSG_CHANGE==msg) {
		Object arg = se.getArg();
		Color newcolor = null;

		if (arg==null) {
			// ask user => null is valid
		} else if (arg instanceof Color) newcolor=(Color)arg;
		else if (arg instanceof String) newcolor = Colors.getColor((String)arg);

		if (newcolor!=null) {
			defaultColor_ = color_ = newcolor;
			repaint();  // don't need getBrowser().repaint();
		}

	} else if (MSG_EDIT==msg) {
		// dialog
	}

	return super.semanticEventAfter(se,msg);
  }


  public ESISNode save() {
	if (color_==null /*|| it's the system default */) removeAttr(ATTR_COLOR);
	else putAttr(ATTR_COLOR, Colors.getName(color_));
	return super.save();
  }


  public void restore(ESISNode n, Map<String,Object> attr, Layer layer) {
	super.restore(n,attr,layer);
	color_ = Colors.getColor(getAttr(ATTR_COLOR), defaultColor_);
  }


  public String toString() {
	//return getName();//+"{"+start+".."+end+"}";
	return "background="+color_;
  }
}
