/*
 *
 * Hamsam - Instant Messaging API
 *
 * Copyright (C) 2003 Mike Miller <mikemil@users.sourceforge.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 */

package hamsam.protocol.aim.command;

import hamsam.api.Buddy;
import hamsam.api.IMListener;
import hamsam.api.Message;

/**
 * @author mikem
 */
public interface CommandHandler {

    /**
     * Handles the AIM Command
     * @param evt
     */
    public void handleCommand(CommandEvent evt);

    /**
     * @param buddy
     * @param message
     */
    public void sendInstantMessage(Buddy buddy, Message message);

    /**
     * @param buddy
     */
    public void addToBuddyList(Buddy buddy);

    /**
     * @param buddy
     */
    public void deleteFromBuddyList(Buddy buddy);

    /**
     * @param buddy
     */
    public void ignoreBuddy(Buddy buddy);

    /**
     * @param buddy
     */
    public void unIgnoreBuddy(Buddy buddy);

    /**
     * @param buddy
     */
    public void typingStarted(Buddy buddy);

    /**
     * @param buddy
     */
    public void typingStopped(Buddy buddy);

    /**
     * @param listener
     */
    public void setListener(IMListener listener);

    /**
     * @param statusFlag
     */
    public void changeStatus(Integer statusFlag);

}
