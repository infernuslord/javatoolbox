/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	Tiny Look and Feel                                                         *
*                                                                              *
*  (C) Copyright 2003, Hans Bickel                                             *
* 																			   *
*   For licensing information and credits, please refer to the                 *
*   comment in file de.muntjak.tinylookandfeel.TinyLookAndFeel                 *
*                                                                              *
*   This library is free software; you can redistribute it and/or modify it    *
*   under the terms of the GNU Lesser General Public License as published by   *
*   the Free Software Foundation; either version 2.1 of the License, or (at    *
*   your option) any later version.                                            *
*                                                                              *
*   This library is distributed in the hope that it will be useful,            *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of             *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                       *
*   See the GNU Lesser General Public License for more details.                *
*                                                                              *
*   You should have received a copy of the GNU General Public License along    *
*   with this program; if not, write to the Free Software Foundation, Inc.,    *
*   59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.                    *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package de.muntjak.tinylookandfeel.controlpanel;

import java.awt.*;
import java.awt.event.*;
import java.beans.PropertyVetoException;
import java.io.File;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.plaf.*;
import javax.swing.plaf.basic.BasicPopupMenuUI;
import javax.swing.table.AbstractTableModel;
import javax.swing.text.Position;

import de.muntjak.tinylookandfeel.Theme;
import de.muntjak.tinylookandfeel.TinyDefaultTheme;


/**
 * ControlPanel
 * 
 * @version 1.1
 * @author Hans Bickel
 */
public class ControlPanel {
	private JFrame theFrame;
	private static final String WINDOW_TITLE = "TinyLaF 1.2.1 Controlpanel";
	private static final int PLAIN_FONT = 	1;
	private static final int BOLD_FONT = 	2;
	private static final int SPECIAL_FONT =	3;
	public static boolean isInstantiated = false;
	
	private String currentFileName;
	private ActionListener checkAction = new CheckAction();
	private ActionListener iconCheckAction = new IconCheckAction();
	private ChangeListener updateAction = new UpdateAction();
	
	private boolean resistUpdate = false;
	
	private JMenu themesMenu;
	private ActionListener selectThemeAction = new SelectThemeAction();
	private JTabbedPane mainTab, compTab;
	private JButton updateThemeButton;
	private JCheckBoxMenuItem customStyle;
	private FontPanel plainFontPanel, boldFontPanel, specialFontPanel;
	private JComboBox fontCombo;
	private JRadioButton isPlainFont, isBoldFont;
	private ColoredFont[] selectedFont;
	private ExamplePanel examplePanel;
	private JButton exampleButton, exampleDisabledButton;
	private JToggleButton exampleToggleButton;
	private Icon buttonIcon;
	private JPopupMenu thePopup;
	private JInternalFrame internalFrame, palette;
	private JPopupMenu hsbPopup;
	private ButtonsCP buttonsCP;
	private ScrollsCP scrollsCP;
	private TabsCP tabsCP;
	private ComboCP comboCP;
	private MenuCP menuCP;
	private ListCP listCP;
	private SliderCP sliderCP;
	private SpinnerCP spinnerCP;
	private ProgressCP progressCP;
	private TextCP textCP;
	private TreeCP treeCP;
	private ToolCP toolCP;
	private TableCP tableCP;
	private FrameCP frameCP;
	private IconCP iconCP;
	private TipCP tipCP;
	private MiscCP miscCP;
	private JSlider vertSlider, horzSlider;	
	private HSBField selectedHSBField, colorizeField;
	private HSBField mainField, rollField, backField, frameField,
		sub1Field, sub2Field, sub3Field, sub4Field,
		sub5Field, sub6Field, sub7Field, sub8Field;
	
// buttonCP
	private HSBField buttonNormalBg, buttonRolloverBg, buttonPressedBg, buttonDisabledBg;
	private HSBField buttonBorder, buttonDark, buttonLight;
	private HSBField buttonRollover, buttonDefault, buttonCheck, buttonCheckDisabled;
	private HSBField buttonDisabledBorder, buttonDisabledDark, buttonDisabledLight;
    private HSBField buttonDisabledFg, checkDisabledFg, radioDisabledFg;
	
	SpreadPanel buttonSpreadLight, buttonSpreadLightDisabled;
	SpreadPanel buttonSpreadDark, buttonSpreadDarkDisabled;

// textCP
	private HSBField textBg, textSelectedBg, textDisabledBg;
    private HSBField textBorder, textBorderDisabled;
    private HSBField textDark, textDisabledDark, textLight, textDisabledLight;
    private BlackWhitePanel textText, textSelectedText;
    
// comboCP
    private HSBField comboBorder, comboBorderDisabled, comboSelectedBg;
    private HSBField comboDark, comboDisabledDark, comboLight, comboDisabledLight;
    private HSBField comboArrowField, comboArrowDisabled;
    private HSBField comboButt, comboButtRollover, comboButtPressed, comboButtDisabled;
    private HSBField comboButtBorder, comboButtDark, comboButtLight;
    private HSBField comboButtBorderDisabled, comboButtDarkDisabled, comboButtLightDisabled;
    private BlackWhitePanel comboSelectedText;
    
    SpreadPanel comboSpreadLight, comboSpreadLightDisabled;
    SpreadPanel comboSpreadDark, comboSpreadDarkDisabled;

// menuCP
	private HSBField menuRolloverField, menuSepDark, menuSepLight;
	private HSBField menuBar, menuItemRollover, menuPopup;
	private HSBField menuBorder, menuDark, menuLight;
	private HSBField menuIcon, menuIconRollover, menuIconDisabled, menuIconShadow;	
	private BlackWhitePanel menuSelectedText;
	
// listCP
	private HSBField listSelectedBg;
	private BlackWhitePanel listSelectedText;
		
// tabsCP
	private HSBField tabNormalBg, tabSelectedBg, tabRoll;
	private HSBField tabBorder, tabDark, tabLight;
	private HSBField tabPaneBorder, tabPaneDark, tabPaneLight;
	
// scrollsCP
	private HSBField scrollThumbField, scrollButtField, scrollArrowField, trackField,
		scrollThumbRolloverBg, scrollThumbPressedBg, scrollThumbDisabledBg,
		scrollButtRolloverBg, scrollButtPressedBg, scrollButtDisabledBg,
		trackDisabled, trackBorder, trackBorderDisabled, scrollArrowDisabled,
		scrollGripDark, scrollGripLight, scrollPane,
		scrollBorder, scrollDark, scrollLight,
		scrollBorderDisabled, scrollDarkDisabled, scrollLightDisabled;
		
	SpreadPanel scrollSpreadLight, scrollSpreadLightDisabled;
	SpreadPanel scrollSpreadDark, scrollSpreadDarkDisabled;
    
// sliderCP
    private HSBField sliderThumbRolloverBg, sliderThumbPressedBg, sliderThumbDisabledBg;
    private HSBField sliderBorder, sliderDark, sliderLight, sliderThumbField;
	private HSBField sliderDisabledBorder, sliderDisabledDark, sliderDisabledLight;
	private HSBField sliderTrack, sliderTrackBorder, sliderTrackDark, sliderTrackLight;
	private HSBField sliderTick, sliderTickDisabled;
    
// spinnerCP
	private HSBField spinnerButtField, spinnerArrowField;
    private HSBField spinnerButtRolloverBg, spinnerButtPressedBg, spinnerButtDisabledBg;
    private HSBField spinnerBorder, spinnerDark, spinnerLight, spinnerArrowDisabled;
	private HSBField spinnerDisabledBorder, spinnerDisabledDark, spinnerDisabledLight;
	
	SpreadPanel spinnerSpreadLight, spinnerSpreadLightDisabled;
	SpreadPanel spinnerSpreadDark, spinnerSpreadDarkDisabled;
    
// progressCP
    private javax.swing.Timer progressTimer;
	private JProgressBar horzProgressBar, vertProgressBar;
	private HSBField progressField, progressTrack;
	private HSBField progressBorder, progressDark, progressLight;
	private HSBField progressSelectFore, progressSelectBack;
    
// treeCP
    private HSBField treeBg, treeTextBg, treeSelectedBg;
    private BlackWhitePanel treeText, treeSelectedText;
    
// toolCP
	private HSBField toolBar, toolBarDark, toolBarLight;
	private HSBField toolButt, toolButtRollover, toolButtPressed;
	private HSBField toolBorder, toolBorderPressed, toolBorderSelected;
	private HSBField toolBorderDark, toolBorderLight;
	
// frameCP
    private HSBField frameCaption, frameCaptionDisabled;
    private HSBField frameBorder, frameDark, frameLight;
    private HSBField frameBorderDisabled, frameDarkDisabled, frameLightDisabled;
    private HSBField frameTitle, frameTitleDisabled;
    private HSBField frameButt, frameButtRollover, frameButtPressed, frameButtDisabled;
    SpreadPanel frameButtSpreadLight, frameButtSpreadLightDisabled;
	SpreadPanel frameButtSpreadDark, frameButtSpreadDarkDisabled;
    private HSBField frameButtClose, frameButtCloseRollover, frameButtClosePressed, frameButtCloseDisabled;
    SpreadPanel frameButtCloseSpreadLight, frameButtCloseSpreadLightDisabled;
	SpreadPanel frameButtCloseSpreadDark, frameButtCloseSpreadDarkDisabled;
    private HSBField frameButtBorder, frameButtDark, frameButtLight;
    private HSBField frameButtBorderDisabled, frameButtDarkDisabled, frameButtLightDisabled;
    private HSBField frameButtCloseBorder, frameButtCloseDark, frameButtCloseLight;
    private HSBField frameButtCloseBorderDisabled, frameButtCloseDarkDisabled, frameButtCloseLightDisabled;
    private HSBField frameSymbol, frameSymbolPressed, frameSymbolDisabled;
    private HSBField frameSymbolDark, frameSymbolLight;
    private HSBField frameSymbolClose, frameSymbolClosePressed, frameSymbolCloseDisabled;
    private HSBField frameSymbolCloseDark, frameSymbolCloseLight;
    
    SpreadPanel frameSpreadDark, frameSpreadLight, frameSpreadDarkDisabled, frameSpreadLightDisabled;
    
// iconCP
	private CheckedIcon[] iconChecks = new CheckedIcon[17];
    private HSBField frameIcon, fileViewIcon, fileChooserIcon, optionPaneIcon, treeIcon;
    
// tableCP
	private HSBField tableBack, tableHeaderBack, tableGrid;
	private HSBField tableSelectedBack;
	
	private BlackWhitePanel tableSelectedFore;
	
// tipCP
	private HSBField tipBg, tipBorder;
	
// miscCP
	private HSBField titledBorderColor;

	public ControlPanel() {
		createFrame();

		//showUIVariables("Color");
		//showUIValues("167");
		//showSystemProperties();
	}

	private void createFrame() {
		if(Theme.frameIsDecorated[Theme.style]) {
			JFrame.setDefaultLookAndFeelDecorated(true);
			JDialog.setDefaultLookAndFeelDecorated(true);
		}
		else {
			JFrame.setDefaultLookAndFeelDecorated(false);
			JDialog.setDefaultLookAndFeelDecorated(false);
		}
		
		Toolkit.getDefaultToolkit().setDynamicLayout(false);
		
		theFrame = new JFrame(WINDOW_TITLE);
		//theFrame.setContentPane(new GoodContentPane());
		theFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		boolean isCustomEnabled = false, isCustomSelected = false;
		if(customStyle != null) {
			isCustomEnabled = customStyle.isEnabled();
			isCustomSelected = customStyle.isSelected();
		}
		setupUI();
		
		customStyle.setEnabled(isCustomEnabled);
		customStyle.setSelected(isCustomSelected);
		createHSBPopup();
		initColors();
		initPanels();
		updateThemeButton.setEnabled(false);
		startProgressTimer();
	}
	
	private void startProgressTimer() {
		if(progressTimer == null) {
			progressTimer = new javax.swing.Timer(500, new ProgressAction());
		}

		vertProgressBar.setIndeterminate(true);
		progressTimer.start();
	}
	
	private void stopProgressTimer() {
		if(progressTimer == null) return;

		progressTimer.stop();
		horzProgressBar.setIndeterminate(false);
		vertProgressBar.setIndeterminate(false);
	}
	
	private void showUIVariables() {
    	UIDefaults defaults = UIManager.getDefaults();

    	String key;
    	int c = 0;
    	TreeMap map = new TreeMap();
    
    	Enumeration e = defaults.keys();
    	while(e.hasMoreElements()) {
      		key = e.nextElement().toString();
      		map.put(key, defaults.get(key));
    	}
    
    	Iterator ii = map.keySet().iterator();
    	while(ii.hasNext()) {
      		key = ii.next().toString();
        	System.out.print("#" + (c++) + " : " + key);
        	System.out.println(" = " + map.get(key));
    	}
    	
    	System.out.println();
	}
	
	private void showUIVariables(String inString) {
    	UIDefaults defaults = UIManager.getDefaults();

    	String key;
    	int c = 0;
    	TreeMap map = new TreeMap();
    
    	Enumeration e = defaults.keys();
    	while(e.hasMoreElements()) {
      		key = e.nextElement().toString();
      		if(key.indexOf(inString) != -1) {
      			map.put(key, defaults.get(key));
      		}
    	}
    
    	Object val;
    	
    	Iterator ii = map.keySet().iterator();
    	while(ii.hasNext()) {
      		key = ii.next().toString();
      		val = map.get(key);
      		
        	System.out.print("#" + (c++) + " : " + key);
        	System.out.println(" = " + map.get(key));
    	}
	}
	
	private void showUIValues(String val) {
    	UIDefaults defaults = UIManager.getDefaults();

    	String key;
    	int c = 0;
    	TreeMap map = new TreeMap();
    
    	Enumeration e = defaults.keys();
    	while(e.hasMoreElements()) {
      		key = e.nextElement().toString();
      		map.put(key, defaults.get(key));
    	}
    
    	Object value;
    	Iterator ii = map.keySet().iterator();
    	while(ii.hasNext()) {
      		key = ii.next().toString();
      		value = map.get(key);
      		if(value != null && value.toString().indexOf(val) != -1) {
        		System.out.print("#" + (c++) + " : " + key);
        		System.out.println(" = " + value);
      		}
    	}
    	
    	System.out.println();
	}
	
	private void showInsets() {
    	UIDefaults defaults = UIManager.getDefaults();

		Object val;
    	String key;
    	int c = 0;
    	TreeMap map = new TreeMap();
    
    	Enumeration e = defaults.keys();
    	while(e.hasMoreElements()) {
      		key = e.nextElement().toString();
      		val = defaults.get(key);
      		if(val instanceof Insets) {
      			map.put(key, val);
      		}
    	}

    	Iterator ii = map.keySet().iterator();
    	while(ii.hasNext()) {
      		key = ii.next().toString();
        	System.out.print("#" + (c++) + " : " + key);
        	System.out.println(" = " + map.get(key));
    	}
    	
    	System.out.println();
	}
		
	private void showSystemProperties() {
		Object key, value;
		Enumeration e = System.getProperties().keys();
		while(e.hasMoreElements()) {
			key = e.nextElement();
			value = System.getProperty(key.toString());
			System.out.println(key.toString() + " : " + value.toString());
		}
	}
	
	private void showMessageDialog() {
		JOptionPane.showMessageDialog(theFrame, "No messages today.");
	}
	
	private void showConfirmationDialog() {
		JOptionPane.showConfirmDialog(theFrame, "Do you really have a choice?");
	}
	
	private void showWarningDialog() {
		JOptionPane.showMessageDialog(theFrame,
			"You have been warned!", "Warning", JOptionPane.WARNING_MESSAGE);
	}
	
	private void showErrorDialog() {
		JOptionPane.showMessageDialog(theFrame,
			"Unknown software error. Panic!", "Error", JOptionPane.ERROR_MESSAGE);
	}
	
	private void showInternalWarningDialog(String msg) {
		JOptionPane.showMessageDialog(theFrame,
			msg, "Warning", JOptionPane.WARNING_MESSAGE);
	}
	
	private void setupUI() {
		// menu bar
		JMenuBar menuBar = new JMenuBar();
    	menuBar.add(createFileMenu());
    	menuBar.add(createThemeMenu());
    	menuBar.add(createStyleMenu());
    	menuBar.add(createDisabledMenu());
    	menuBar.add(createCheckBoxMenu());
    	menuBar.add(createRadioButtonMenu());
    	
    	theFrame.setJMenuBar(menuBar);
    	
    	JPanel p0 = new JPanel(new BorderLayout());
    	JPanel p1 = new JPanel(new BorderLayout());
    	
    	p1.add(createToolBar(), BorderLayout.NORTH);
    	
    	// Colors/Fonts/Dekoration
    	mainTab = new JTabbedPane(JTabbedPane.LEFT);
    	mainTab.add("Color", createColorPanel());
    	mainTab.add("Font", createFontPanel());
    	mainTab.add("Decoration", createDecorationPanel());
    	
    	p1.add(mainTab, BorderLayout.CENTER);
    	
    	p0.add(p1, BorderLayout.NORTH);
    	
    	// Apply/Init Settings
    	p1 = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 4));
      	updateThemeButton = new JButton("Apply Settings");
      	theFrame.getRootPane().setDefaultButton(updateThemeButton);
      	updateThemeButton.addActionListener(new SetThemeAction());
      	p1.add(updateThemeButton);

      	p0.add(p1, BorderLayout.SOUTH);
    	theFrame.getContentPane().add(p0, BorderLayout.NORTH);
    	
    	examplePanel = new ExamplePanel();
    	p0 = new JPanel(new BorderLayout());
		p0.setBorder(new TitledBorder("Examples"));
		p0.add(examplePanel, BorderLayout.CENTER);
    	theFrame.getContentPane().add(p0, BorderLayout.CENTER);

    	int w = 960, h = 752;
    	Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    	
      	theFrame.setSize(w, h);
		theFrame.setLocation((d.width - w) / 2, (d.height - h) / 3);
		theFrame.setVisible(true);
	}
	
	private void decorateFrame(boolean b) {
		theFrame.dispose();
		
		Theme.frameIsDecorated[Theme.style] = b;
		
		createFrame();
		mainTab.setSelectedComponent(compTab);
		compTab.setSelectedComponent(frameCP);
	}
	
	private JPanel createColorPanel() {
		JPanel p0 = new JPanel(new BorderLayout());		
		JPanel p1 = new JPanel(new GridBagLayout());
		GridBagConstraints gc = new GridBagConstraints();
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(2, 4, 0, 4);

		
		p1.add(new JLabel("Main Color"), gc);
		gc.gridx ++;
		
		gc.insets = new Insets(2, 8, 0, 4);
		p1.add(new JLabel("Background Color"), gc);
		gc.gridx ++;
		
		p1.add(new JLabel("Disabled Color"), gc);
		gc.gridx ++;
		
		p1.add(new JLabel("Frame Color"), gc);
		
		gc.gridx = 0;
		gc.gridy ++;
		gc.insets = new Insets(2, 4, 8, 4);

		mainField = new HSBField(Theme.mainColor, 24);
		p1.add(mainField, gc);
		gc.gridx ++;
		
		gc.insets = new Insets(2, 8, 8, 4);
		backField = new HSBField(Theme.backColor, 24);
		p1.add(backField, gc);
		gc.gridx ++;
		
		rollField = new HSBField(Theme.disColor, 24);
		p1.add(rollField, gc);
		gc.gridx ++;
		
		frameField = new HSBField(Theme.frameColor, 24);
		p1.add(frameField, gc);
		
		gc.gridx = 0;
		gc.gridy ++;
		gc.insets = new Insets(2, 4, 0, 4);
		p1.add(new JLabel("Sub1 Color"), gc);
		gc.gridx ++;
		
		gc.insets = new Insets(2, 8, 0, 4);
		p1.add(new JLabel("Sub2 Color"), gc);
		gc.gridx ++;
		
		p1.add(new JLabel("Sub3 Color"), gc);
		gc.gridx ++;
		
		p1.add(new JLabel("Sub4 Color"), gc);

		gc.gridx = 0;
		gc.gridy ++;
		gc.insets = new Insets(2, 4, 8, 4);
		sub1Field = new HSBField(Theme.sub1Color, true);
		p1.add(sub1Field, gc);
		gc.gridx ++;
		
		gc.insets = new Insets(2, 8, 8, 4);
		sub2Field = new HSBField(Theme.sub2Color, true);
		p1.add(sub2Field, gc);
		gc.gridx ++;
		
		sub3Field = new HSBField(Theme.sub3Color, true);
		p1.add(sub3Field, gc);
		gc.gridx ++;
		
		sub4Field = new HSBField(Theme.sub4Color, true);
		p1.add(sub4Field, gc);
		
		gc.gridx = 0;
		gc.gridy ++;
		gc.insets = new Insets(2, 4, 0, 4);
		p1.add(new JLabel("Sub5 Color"), gc);
		gc.gridx ++;
		
		gc.insets = new Insets(2, 8, 0, 4);
		p1.add(new JLabel("Sub6 Color"), gc);
		gc.gridx ++;
		
		p1.add(new JLabel("Sub7 Color"), gc);
		gc.gridx ++;
		
		p1.add(new JLabel("Sub8 Color"), gc);

		gc.gridx = 0;
		gc.gridy ++;
		gc.insets = new Insets(2, 4, 8, 4);
		sub5Field = new HSBField(Theme.sub5Color, true);
		p1.add(sub5Field, gc);
		gc.gridx ++;
		
		gc.insets = new Insets(2, 8, 8, 4);
		sub6Field = new HSBField(Theme.sub6Color, true);
		p1.add(sub6Field, gc);
		gc.gridx ++;
		
		sub7Field = new HSBField(Theme.sub7Color, true);
		p1.add(sub7Field, gc);
		gc.gridx ++;
		
		sub8Field = new HSBField(Theme.sub8Color, true);
		p1.add(sub8Field, gc);

		JPanel p2 = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 12));
		p2.add(p1);
		
		p0.add(p2, BorderLayout.NORTH);
		
		return p0;
	}
	
	private JToolBar createToolBar() {
		JToolBar tb = new JToolBar();
		
		ButtonGroup group = new ButtonGroup();
		JToggleButton b = null;
		
		for(int i = 0; i < 6; i++) {
			b = new JToggleButton("");
			group.add(b);
			b.setIcon(new ToolButtonIcon(b));
			tb.add(b);
		}
		
		tb.addSeparator();
		
		for(int i = 0; i < 5; i++) {
			b = new JToggleButton("");
			group.add(b);
			b.setIcon(new ToolButtonIcon(b));
			tb.add(b);
		}
		
		tb.addSeparator();
		
		for(int i = 0; i < 4; i++) {
			b = new JToggleButton("");
			group.add(b);
			b.setIcon(new ToolButtonIcon(b));
			tb.add(b);
		}
		
		b = new JToggleButton("TB_Button");
		group.add(b);
		tb.add(b);
		
		return tb;
	}
	
	private JPopupMenu createHSBPopup() {
		if(hsbPopup != null) return hsbPopup;
		
		ActionListener hsbPopupAction = new HSBPopupAction();
		hsbPopup = new JPopupMenu();
		
		JMenuItem item = new JMenuItem("Absolute Color");
		item.setActionCommand("1");
		item.addActionListener(hsbPopupAction);
		hsbPopup.add(item);
		
		hsbPopup.addSeparator();
		
		item = new JMenuItem("Derive from Main Color");
		item.setActionCommand("2");
		item.addActionListener(hsbPopupAction);
		hsbPopup.add(item);
		
		item = new JMenuItem("Derive from Back Color");
		item.setActionCommand("3");
		item.addActionListener(hsbPopupAction);
		hsbPopup.add(item);
		
		item = new JMenuItem("Derive from Disabled Color");
		item.setActionCommand("4");
		item.addActionListener(hsbPopupAction);
		hsbPopup.add(item);
		
		item = new JMenuItem("Derive from Frame Color");
		item.setActionCommand("5");
		item.addActionListener(hsbPopupAction);
		hsbPopup.add(item);
		
		item = new JMenuItem("Derive from Sub1 Color");
		item.setActionCommand("6");
		item.addActionListener(hsbPopupAction);
		hsbPopup.add(item);
		
		item = new JMenuItem("Derive from Sub2 Color");
		item.setActionCommand("7");
		item.addActionListener(hsbPopupAction);
		hsbPopup.add(item);
		
		item = new JMenuItem("Derive from Sub3 Color");
		item.setActionCommand("8");
		item.addActionListener(hsbPopupAction);
		hsbPopup.add(item);
		
		item = new JMenuItem("Derive from Sub4 Color");
		item.setActionCommand("9");
		item.addActionListener(hsbPopupAction);
		hsbPopup.add(item);
		
		item = new JMenuItem("Derive from Sub5 Color");
		item.setActionCommand("10");
		item.addActionListener(hsbPopupAction);
		hsbPopup.add(item);
		
		item = new JMenuItem("Derive from Sub6 Color");
		item.setActionCommand("11");
		item.addActionListener(hsbPopupAction);
		hsbPopup.add(item);
		
		item = new JMenuItem("Derive from Sub7 Color");
		item.setActionCommand("12");
		item.addActionListener(hsbPopupAction);
		hsbPopup.add(item);
		
		item = new JMenuItem("Derive from Sub8 Color");
		item.setActionCommand("13");
		item.addActionListener(hsbPopupAction);
		hsbPopup.add(item);
		
		return hsbPopup;
	}
	
	private void updateHSBPopupIcons() {
		MenuElement[] me = hsbPopup.getSubElements();
		
		((JMenuItem)me[0]).setIcon(ColorReference.getAbsoluteIcon());
		((JMenuItem)me[1]).setIcon(Theme.mainColor[Theme.style].getIcon());
		((JMenuItem)me[2]).setIcon(Theme.backColor[Theme.style].getIcon());
		((JMenuItem)me[3]).setIcon(Theme.disColor[Theme.style].getIcon());
		((JMenuItem)me[4]).setIcon(Theme.frameColor[Theme.style].getIcon());
		((JMenuItem)me[5]).setIcon(Theme.sub1Color[Theme.style].getIcon());
		((JMenuItem)me[6]).setIcon(Theme.sub2Color[Theme.style].getIcon());
		((JMenuItem)me[7]).setIcon(Theme.sub3Color[Theme.style].getIcon());
		((JMenuItem)me[8]).setIcon(Theme.sub4Color[Theme.style].getIcon());
		((JMenuItem)me[9]).setIcon(Theme.sub5Color[Theme.style].getIcon());
		((JMenuItem)me[10]).setIcon(Theme.sub6Color[Theme.style].getIcon());
		((JMenuItem)me[11]).setIcon(Theme.sub7Color[Theme.style].getIcon());
		((JMenuItem)me[12]).setIcon(Theme.sub8Color[Theme.style].getIcon());

		for(int i = 0; i < 13; i++) {
			((JMenuItem)me[i]).setSelected(false);
		}
		
		for(int i = 5; i < 13; i++) {
			((JMenuItem)me[i]).setEnabled(true);
		}
	}
	
	private void showHSBPopup(HSBField cf) {
		updateHSBPopupIcons();
		
		selectedHSBField = cf;
		int index = cf.getColorReference().getReference() - 1;
		MenuElement[] me = hsbPopup.getSubElements();
		
		((JMenuItem)me[index]).setSelected(true);
		
		if(cf.equals(sub1Field)) {
			((JMenuItem)me[5]).setEnabled(false);
		}
		else if(cf.equals(sub2Field)) {
			((JMenuItem)me[6]).setEnabled(false);
		}
		else if(cf.equals(sub3Field)) {
			((JMenuItem)me[7]).setEnabled(false);
		}
		else if(cf.equals(sub4Field)) {
			((JMenuItem)me[8]).setEnabled(false);
		}
		else if(cf.equals(sub5Field)) {
			((JMenuItem)me[9]).setEnabled(false);
		}
		else if(cf.equals(sub6Field)) {
			((JMenuItem)me[10]).setEnabled(false);
		}
		else if(cf.equals(sub7Field)) {
			((JMenuItem)me[11]).setEnabled(false);
		}
		else if(cf.equals(sub8Field)) {
			((JMenuItem)me[12]).setEnabled(false);
		}
		
		hsbPopup.show(cf, 0, cf.getHeight() + 2);
	}
	
	private JPanel createFontPanel() {
		JPanel p1 = new JPanel(new GridBagLayout());
		GridBagConstraints gc = new GridBagConstraints();
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(4, 2, 4, 2);
		
		plainFontPanel = new FontPanel(PLAIN_FONT);
      	p1.add(plainFontPanel, gc);
      	gc.gridy ++;
      	
      	boldFontPanel = new FontPanel(BOLD_FONT);
      	p1.add(boldFontPanel, gc);
      	gc.gridy ++;

		gc.insets = new Insets(11, 2, 0, 2);
		JPanel p2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
      	p2.add(createFontCombo());
      	
      	p2.add(new JLabel("    "));
      	isPlainFont = new JRadioButton("is Plain Font");
      	isPlainFont.addActionListener(new DerivedFontAction());
      	p2.add(isPlainFont);
      	
      	p2.add(new JLabel("    "));
      	isBoldFont = new JRadioButton("is Bold Font");
      	isBoldFont.addActionListener(new DerivedFontAction());
      	p2.add(isBoldFont);
      	
      	p1.add(p2, gc);
      	gc.gridy ++;
      	
      	gc.insets = new Insets(2, 2, 0, 2);      	
      	specialFontPanel = new FontPanel(SPECIAL_FONT);
      	specialFontPanel.init(selectedFont[Theme.style]);
      	p1.add(specialFontPanel, gc);

		return p1;
	}
	
	private JComboBox createFontCombo() {
		Vector items = new Vector();

		items.add("Button Font");
		items.add("CheckBox Font");
		items.add("ComboBox Font");
		items.add("Label Font");
		items.add("List Font");
		items.add("Menu Font");
		items.add("MenuItem Font");
		items.add("Password Font");
		items.add("RadioButton Font");
		items.add("Table Font");
		items.add("TableHeader Font");
		items.add("TextArea Font");
		items.add("TextField Font");
		items.add("TextPane Font");
		items.add("TitledBorder Font");
		items.add("ToolTip Font");
		items.add("Tree Font");
		items.add("TabbedPane Font");
		items.add("EditorPane Font");
		items.add("FrameTitle Font");
		items.add("ProgressBar Font");
		
		Collections.sort(items);
		
		fontCombo = new JComboBox(items);
		fontCombo.addActionListener(new SelectSpecialFontAction());
		
		selectedFont = Theme.buttonFont;
		
		return fontCombo;
	}
	
	private JTabbedPane createDecorationPanel() {
		compTab = new JTabbedPane();
		
		buttonsCP = new ButtonsCP();
		compTab.add("Button", buttonsCP);
		
		comboCP = new ComboCP();
		compTab.add("ComboBox", comboCP);
		
		frameCP = new FrameCP();
		compTab.add("Frame", frameCP);
		
		iconCP = new IconCP();
		compTab.add("Icons", iconCP);
		
		listCP = new ListCP();
		compTab.add("List", listCP);

		menuCP = new MenuCP();
		compTab.add("Menu", menuCP);
		
		miscCP = new MiscCP();
		compTab.add("Miscellaneous", miscCP);
		
		progressCP = new ProgressCP();
		compTab.add("ProgressBar", progressCP);
		
		scrollsCP = new ScrollsCP();
		compTab.add("ScrollBar", scrollsCP);
		
		sliderCP = new SliderCP();
		compTab.add("Slider", sliderCP);
		
		spinnerCP = new SpinnerCP();
		compTab.add("Spinner", spinnerCP);
		
		tabsCP = new TabsCP();
		compTab.add("TabbedPane", tabsCP);
		
		tableCP = new TableCP();
		compTab.add("Table", tableCP);
		
		textCP = new TextCP();
		compTab.add("Text", textCP);
		
		toolCP = new ToolCP();
		compTab.add("ToolBar", toolCP);
		
		tipCP = new TipCP();
		compTab.add("ToolTip", tipCP);
		
		treeCP = new TreeCP();
		compTab.add("Tree", treeCP);
		
		return compTab;
	}
	
	private JMenu createFileMenu() {
    	JMenu menu = new JMenu("File");

    	JMenuItem item = new JMenuItem("Open Theme...");
    	item.addActionListener(new ActionListener() {
      		public void actionPerformed(ActionEvent e) {
        		openTheme();
      		}
    	});
		item.setMnemonic(KeyEvent.VK_O);
    	item.setAccelerator(
      		KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
    	menu.add(item);
    	
    	menu.addSeparator();
    	
    	item = new JMenuItem("Save");
    	item.addActionListener(new ActionListener() {
      		public void actionPerformed(ActionEvent e) {
        		saveTheme(false);
      		}
    	});
		item.setMnemonic(KeyEvent.VK_S);
    	item.setAccelerator(
      		KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.CTRL_MASK));
    	menu.add(item);
    	
    	item = new JMenuItem("Save as Default");
    	item.addActionListener(new ActionListener() {
      		public void actionPerformed(ActionEvent e) {
        		saveDefaults();
      		}
    	});
    	menu.add(item);
    	
    	item = new JMenuItem("Save as...");
    	item.addActionListener(new ActionListener() {
      		public void actionPerformed(ActionEvent e) {
        		saveTheme(true);
      		}
    	});
		//item.setMnemonic(KeyEvent.VK_A);
    	item.setAccelerator(
      		KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.CTRL_MASK | ActionEvent.SHIFT_MASK));
    	menu.add(item);

    	menu.addSeparator();
    	
    	item = new JMenuItem("Disabled Menu Item");
    	item.setEnabled(false);
    	menu.add(item);
    	
    	menu.addSeparator();

    	item = new JMenuItem("Quit");
    	item.addActionListener(new ActionListener() {
      		public void actionPerformed(ActionEvent e) {
        		System.exit(0);
      		}
    	});
    	item.setAccelerator(
      		KeyStroke.getKeyStroke(KeyEvent.VK_Q, ActionEvent.CTRL_MASK));
    	menu.add(item);
    	
    	menu.addSeparator();
    	menu.addSeparator();
    	menu.addSeparator();
    	
    	return menu;
  	}
  	
  	private Vector loadThemes() {
  		Vector names = new Vector();
  		
  		File f = new File(System.getProperty("user.dir"));
  		File[] files = f.listFiles();
  		
  		for(int i = 0; i < files.length; i++) {
  			if(files[i].getName().endsWith(Theme.FILE_EXTENSION)) {
  				names.add(files[i].getName());
  			}
  		}
  		
  		return names;
  	}
  	
  	private JMenu createThemeMenu() {
    	themesMenu = new JMenu("Themes");

    	JMenuItem item = null;
    	String fn = null;
    	Iterator ii = loadThemes().iterator();
    	while(ii.hasNext()) {
    		fn = (String)ii.next();
    		item = new JMenuItem(fn.substring(0, fn.lastIndexOf(".")));
    		item.addActionListener(selectThemeAction);
    		themesMenu.add(item);
    	}

    	return themesMenu;
  	}
  	
  	private void updateThemeMenu() {
    	themesMenu.removeAll();

    	JMenuItem item = null;
    	String fn = null;
    	Iterator ii = loadThemes().iterator();
    	while(ii.hasNext()) {
    		fn = (String)ii.next();
    		item = new JMenuItem(fn.substring(0, fn.lastIndexOf(".")));
    		item.addActionListener(selectThemeAction);
    		themesMenu.add(item);
    	}
  	}
  	
  	private JMenu createStyleMenu() {
    	JMenu menu = new JMenu("Style");

		ButtonGroup group = new ButtonGroup();
    	JCheckBoxMenuItem item = new JCheckBoxMenuItem("Tiny",
    		(Theme.style == Theme.TINY_STYLE));
    	group.add(item);
    	item.setEnabled(false);
    	item.addActionListener(new ActionListener() {
      		public void actionPerformed(ActionEvent e) {
        		updateStyle(Theme.TINY_STYLE);
      		}
    	});
    	//menu.add(item);
    	
    	item = new JCheckBoxMenuItem("Windows 98",
    		(Theme.style == Theme.WIN_STYLE));
    	group.add(item);
    	item.addActionListener(new ActionListener() {
      		public void actionPerformed(ActionEvent e) {
        		updateStyle(Theme.WIN_STYLE);
      		}
    	});
    	menu.add(item);
    	
    	item = new JCheckBoxMenuItem("Windows XP",
    		(Theme.style == Theme.XP_STYLE));
    	group.add(item);
    	item.addActionListener(new ActionListener() {
      		public void actionPerformed(ActionEvent e) {
        		updateStyle(Theme.XP_STYLE);
      		}
    	});
    	menu.add(item);
    	
    	customStyle = new JCheckBoxMenuItem("Custom", false);
    	customStyle.setEnabled(false);
    	group.add(customStyle);
    	customStyle.addActionListener(new ActionListener() {
      		public void actionPerformed(ActionEvent e) {
      			updateStyle(Theme.CUSTOM_STYLE);
      		}
    	});
    	menu.add(customStyle);

    	return menu;
  	}
  	
  	private JMenu createDisabledMenu() {
    	JMenu menu = new JMenu("DisabledMenu");
    	
		menu.setEnabled(false);
 
    	return menu;
  	}
  	
  	private JMenu createCheckBoxMenu() {
    	JMenu menu = new JMenu("JCheckBoxMenuItems");
    	
		JCheckBoxMenuItem item = new JCheckBoxMenuItem("Item 1", true);
		menu.add(item);
		item = new JCheckBoxMenuItem("Item 2", false);
		menu.add(item);
		item = new JCheckBoxMenuItem("Item 3", true);
		menu.add(item);
		item = new JCheckBoxMenuItem("Item 4", false);
		menu.add(item);
		item = new JCheckBoxMenuItem("Disabled Item 5", true);
		item.setEnabled(false);
		menu.add(item);
		item = new JCheckBoxMenuItem("Disabled Item 6", false);
		item.setEnabled(false);
		menu.add(item);
 
    	return menu;
  	}
  	
  	private JMenu createRadioButtonMenu() {
    	JMenu menu = new JMenu("JRadioButtonMenuItems");
    	
    	ButtonGroup group = new ButtonGroup();
		JRadioButtonMenuItem item = new JRadioButtonMenuItem("Item 1");
		group.add(item);
		menu.add(item);
		item = new JRadioButtonMenuItem("Item 2");
		group.add(item);
		menu.add(item);
		item = new JRadioButtonMenuItem("Item 3", true);
		group.add(item);
		menu.add(item);
		item = new JRadioButtonMenuItem("Item 4");
		group.add(item);
		menu.add(item);
		item = new JRadioButtonMenuItem("Disabled Item 5", true);
		item.setEnabled(false);
		menu.add(item);
		item = new JRadioButtonMenuItem("Disabled Item 6", false);
		item.setEnabled(false);
		menu.add(item);
 
    	return menu;
  	}
  	
  	private void addButtonIcons(boolean b) {
  		if(b && exampleButton.getIcon() == null) {
  			if(buttonIcon == null) {
  				buttonIcon = new ImageIcon(
					ClassLoader.getSystemResource(
					"de/muntjak/tinylookandfeel/icons/theIcon.gif"));
  			}
  			exampleButton.setIcon(buttonIcon);
  			exampleDisabledButton.setIcon(buttonIcon);
  			exampleToggleButton.setIcon(buttonIcon);
  		}
  		else if(!b && exampleButton.getIcon() != null) {
  			exampleButton.setIcon((Icon)null);
  			exampleDisabledButton.setIcon((Icon)null);
  			exampleToggleButton.setIcon((Icon)null);
  		}
  	}

  	private void updateFont(int type) {
  		if(type == PLAIN_FONT) {
  			Theme.plainFont[Theme.style].setFont(plainFontPanel.getCurrentFont());
  		}
  		else if(type == BOLD_FONT) {
  			Theme.boldFont[Theme.style].setFont(boldFontPanel.getCurrentFont());
  		}
  		else {
  			selectedFont[Theme.style].setFont(specialFontPanel.getCurrentFont());
  		}

  		examplePanel.update(true);
  	}
  	
  	/*
  	 * Alphabetical ordering!
  	 */
  	private void updateSpecialFont() {
  		int index = fontCombo.getSelectedIndex();
			
		switch(index) {
			case 0:
				selectedFont = Theme.buttonFont;
				break;
			case 1:
				selectedFont = Theme.checkFont;
				break;
			case 2:
				selectedFont = Theme.comboFont;
				break;
			case 3:
				selectedFont = Theme.editorFont;
				break;
			case 4:
				selectedFont = Theme.frameTitleFont;
				break;
			case 5:
				selectedFont = Theme.labelFont;
				break;
			case 6:
				selectedFont = Theme.listFont;
				break;
			case 7:
				selectedFont = Theme.menuFont;
				break;
			case 8:
				selectedFont = Theme.menuItemFont;
				break;
			case 9:
				selectedFont = Theme.passwordFont;
				break;
			case 10:
				selectedFont = Theme.progressBarFont;
				break;
			case 11:
				selectedFont = Theme.radioFont;
				break;
			case 12:
				selectedFont = Theme.tabFont;
				break;
			case 13:
				selectedFont = Theme.tableFont;
				break;
			case 14:
				selectedFont = Theme.tableHeaderFont;
				break;
			case 15:
				selectedFont = Theme.textAreaFont;
				break;
			case 16:
				selectedFont = Theme.textFieldFont;
				break;
			case 17:
				selectedFont = Theme.textPaneFont;
				break;
			case 18:
				selectedFont = Theme.titledBorderFont;
				break;
			case 19:
				selectedFont = Theme.toolTipFont;
				break;
			case 20:
				selectedFont = Theme.treeFont;
				break;
		}
			
		specialFontPanel.init(selectedFont[Theme.style]);
		
		// update all font colors
		Theme.buttonFontColor[Theme.style].update();
		Theme.labelFontColor[Theme.style].update();
		Theme.menuFontColor[Theme.style].update();
		Theme.menuItemFontColor[Theme.style].update();
		Theme.radioFontColor[Theme.style].update();
		Theme.checkFontColor[Theme.style].update();
		Theme.tableFontColor[Theme.style].update();
		Theme.tableHeaderFontColor[Theme.style].update();
		Theme.titledBorderFontColor[Theme.style].update();
		Theme.toolTipFontColor[Theme.style].update();
		Theme.tabFontColor[Theme.style].update();
  	}
  	
  	private void setTheme() {
  		updateTheme();
  		
  		LookAndFeel currentLookAndFeel = UIManager.getLookAndFeel();
  		try {
			UIManager.setLookAndFeel(currentLookAndFeel);
		} catch (UnsupportedLookAndFeelException e) {
			System.err.println(e.toString());
		}
		
  		SwingUtilities.updateComponentTreeUI(theFrame);
  		updateThemeButton.setEnabled(false);
  		iconCP.init(true);
  		theFrame.repaint(0);
  		
  		PSColorChooser.deleteInstance();
        SBChooser.deleteInstance();
        
        if(Theme.derivedStyle[Theme.style] == Theme.XP_STYLE &&
        	!System.getProperty("os.name").equals("Windows XP"))
        {
			showInternalWarningDialog(
				"From TinyLaF version 1.2 on you may use themes\n" +
				"derived from Windows XP Style only on Windows XP.");
		}
  	}
  	
  	private void updateTheme() {
  		Theme.mainColor[Theme.style].setColor(mainField.getBackground());
  		Theme.disColor[Theme.style].setColor(rollField.getBackground());
  		Theme.backColor[Theme.style].setColor(backField.getBackground());
  		Theme.frameColor[Theme.style].setColor(frameField.getBackground());
  		TinyDefaultTheme.secondary3 = new ColorUIResource(Theme.backColor[Theme.style].getColor());

  		updatePanels();
  		
  		UIDefaults table = UIManager.getDefaults();
  		table.put("Button.margin", buttonsCP.getButtonMargin());  		
  		table.put("TabbedPane.tabAreaInsets",new Insets(
  			6, tabsCP.getFirstTabDistance(), 0, 0));
  	}
  	
  	private void updatePanels() {
  		buttonsCP.updateTheme();
  		scrollsCP.updateTheme();
  		tabsCP.updateTheme();
  		comboCP.updateTheme();
  		listCP.updateTheme();
  		sliderCP.updateTheme();
  		spinnerCP.updateTheme();
  		progressCP.updateTheme();
  		menuCP.updateTheme();
  		textCP.updateTheme();
  		treeCP.updateTheme();
  		toolCP.updateTheme();
  		tableCP.updateTheme();
  		frameCP.updateTheme();
  		iconCP.updateTheme();
  		tipCP.updateTheme();
  		miscCP.updateTheme();
  	}
  	
  	private void updateStyle(int newStyle) {
  		stopProgressTimer();
  		Theme.style = newStyle;
 
  		initColors();
  		initPanels();
        setTheme();
 
        startProgressTimer();
  	}
  	
  	private String getDescription() {
  		if(Theme.style == Theme.CUSTOM_STYLE) {
  			return currentFileName;
  		}
  		else if(Theme.style == Theme.WIN_STYLE) {
  			return "Windows 98";
  		}
  		else if(Theme.style == Theme.XP_STYLE) {
  			return "Windows XP";
  		}
  		else if(Theme.style == Theme.TINY_STYLE) {
  			return "Tiny";
  		}
  		
  		return "";
  	}
  	
  	private void initPanels() {
  		resistUpdate = true;
  		
  		initColors();

  		buttonsCP.init(true);
  		scrollsCP.init(true);
  		tabsCP.init(true);
  		comboCP.init(true);
  		menuCP.init(true);
  		listCP.init(true);
  		sliderCP.init(true);
  		spinnerCP.init(true);
  		progressCP.init(true);
  		textCP.init(true);
  		treeCP.init(true);
  		toolCP.init(true);
  		tableCP.init(true);
  		frameCP.init(true);
  		iconCP.init(true);
  		tipCP.init(true);
  		miscCP.init(true);
  		
  		initFonts();
  		
  		resistUpdate = false;

  		theFrame.setTitle(WINDOW_TITLE + " - " + getDescription());
  	}
  	
  	private void initColors() {
  		mainField.setBackground(Theme.mainColor[Theme.style].getColor());
  		rollField.setBackground(Theme.disColor[Theme.style].getColor());
  		backField.setBackground(Theme.backColor[Theme.style].getColor());
  		frameField.setBackground(Theme.frameColor[Theme.style].getColor());
  		sub1Field.update();
  		sub2Field.update();
  		sub3Field.update();
  		sub4Field.update();
  		sub5Field.update();
  		sub6Field.update();
  		sub7Field.update();
  		sub8Field.update();
  	}
  	
  	private void initFonts() {
  		plainFontPanel.init(Theme.plainFont[Theme.style]);
  		boldFontPanel.init(Theme.boldFont[Theme.style]);
  		updateSpecialFont();
  	}
  	
  	private void openTheme() {
  		JFileChooser ch = new JFileChooser(System.getProperty("user.dir"));
  		ch.setFileFilter(new ThemeFileFilter());
  		int answer = ch.showOpenDialog(theFrame);
  		
  		if(answer == JFileChooser.CANCEL_OPTION) return;
  		
  		File f = ch.getSelectedFile();
  		
  		if(f == null) return;

  		if(!Theme.loadTheme(f, Theme.CUSTOM_STYLE)) {
  			JOptionPane.showMessageDialog(theFrame,
  				"This file is not a valid TinyLaF theme.",
  				"Error",
  				JOptionPane.ERROR_MESSAGE);

  			return;
  		}
  		
  		currentFileName = f.getAbsolutePath();
  		
  		customStyle.setEnabled(true);
  		customStyle.setSelected(true);
  		updateStyle(Theme.CUSTOM_STYLE);
  	}
  	
  	private void openTheme(String fn) {
  		File f = new File(fn);
  		
  		if(!Theme.loadTheme(f, Theme.CUSTOM_STYLE)) {
  			JOptionPane.showMessageDialog(theFrame,
  				"This file is not a valid TinyLaF theme.",
  				"Error",
  				JOptionPane.ERROR_MESSAGE);

  			return;
  		}
  		
  		currentFileName = fn;
  		
  		customStyle.setEnabled(true);
  		customStyle.setSelected(true);
  		updateStyle(Theme.CUSTOM_STYLE);
  	}
  	
  	private void saveTheme(boolean showFileChooser) {
  		if(currentFileName != null && !showFileChooser && Theme.style == Theme.CUSTOM_STYLE) {
  			Theme.saveTheme(currentFileName);
  			updateThemeMenu();
  			return;
  		}
  		
  		JFileChooser ch = new JFileChooser(System.getProperty("user.dir"));
  		ch.setFileFilter(new ThemeFileFilter());
  		ch.setSelectedFile(new File(
  			System.getProperty("user.dir") + File.separator + "Untitled.theme"));
  			
  		int answer = ch.showSaveDialog(theFrame);
  		
  		if(answer == JFileChooser.CANCEL_OPTION) return;
  		
  		File f = ch.getSelectedFile();
  		
  		if(f == null) return;

		currentFileName = createFileExtension(f, Theme.FILE_EXTENSION);
  		Theme.saveTheme(currentFileName);
  		updateThemeMenu();
  		
  		if(Theme.style != Theme.CUSTOM_STYLE) {
  			// load the previously saved file to make it custom
  			openTheme(currentFileName);
  		}
  		theFrame.setTitle(WINDOW_TITLE + " - " + getDescription());
  	}
  	
  	private String createFileExtension(File f, String ext) {
  		String fn = f.getAbsolutePath();
  		
  		if(fn.endsWith(ext)) return fn;
  		
  		if(fn.lastIndexOf(".") < fn.lastIndexOf(File.separator)) {
  			return fn + ext;
  		}
  		
  		return fn.substring(0, fn.lastIndexOf(".")) + ext;
  	}

  	private void saveDefaults() {
  		Theme.saveTheme(Theme.DEFAULT_THEME);
  		updateThemeMenu();
  	}
	
	public static void main(String[] args) {
		isInstantiated = true;
		
		// $JAVA_HOME/jre/lib/swing.properties:
		// swing.defaultlaf = de.muntjak.tinylookandfeel.TinyLookAndFeel
		// System.property: swing.defaultlaf
		
		// this also works:
		//System.setProperty("swing.defaultlaf", "de.muntjak.tinylookandfeel.TinyLookAndFeel");
		if(true) {
			try {
				UIManager.setLookAndFeel("de.muntjak.tinylookandfeel.TinyLookAndFeel");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		new ControlPanel();
	}
	
	class HSBField extends JPanel {
		
		private boolean forceUpdate = false;
		private Dimension size = new Dimension(64, 18);
		private ColorReference[] ref;
		
		HSBField(ColorReference[] ref) {
			this.ref = ref;
			
			setBorder(new LineBorder(Color.BLACK, 1));
			
			if(ref == null) return;
			
			update();
			addMouseListener(new Mousey());
		}
		
		HSBField(ColorReference[] ref, boolean forceUpdate) {
			this.ref = ref;
			this.forceUpdate = forceUpdate;
			
			setBorder(new LineBorder(Color.BLACK, 1));
			
			if(ref == null) return;
			
			update();
			addMouseListener(new Mousey());
		}
		
		HSBField(ColorReference[] ref, int height) {
			this.ref = ref;
			forceUpdate = true;
			size = new Dimension(64, height);
			
			setBorder(new LineBorder(Color.BLACK, 1));
			
			if(ref == null) return;
			
			update();
			addMouseListener(new Mousey());
		}
		
		public ColorReference getColorReference() {
			return ref[Theme.style];
		}
		
		public void resetReference() {
			if(ref == null) return;
			
			ref[Theme.style].reset();
		}
		
		public void update() {
			if(ref != null) {
				setBackground(ref[Theme.style].update());
			}
			repaint();
			updateTTT();
		}
		
		private void updateTTT() {
			if(ref == null) return;
			
			Color c = ref[Theme.style].getColor();
			StringBuffer buff = new StringBuffer();
			
			if(ref[Theme.style].isAbsoluteColor()) {
				buff.append("R:" + c.getRed());
				buff.append(" G:" + c.getGreen());
				buff.append(" B:" + c.getBlue());
			}
			else {
				buff.append("S:" + ref[Theme.style].getSaturation());
				buff.append(" B:" + ref[Theme.style].getBrightness());
				buff.append(" (" + ref[Theme.style].getReferenceString() + ")");
				buff.append(" R:" + c.getRed());
				buff.append(" G:" + c.getGreen());
				buff.append(" B:" + c.getBlue());
			}
			
			setToolTipText(buff.toString());
		}
		
		public void setColorReference(ColorReference[] ref) {
			this.ref = ref;
			update();
		}
		
		public Dimension getPreferredSize() {
			return size;
		}
		
		public void paint(Graphics g) {
			if(ref == null) {
				g.setColor(Theme.backColor[Theme.style].getColor());
				g.fillRect(0, 0, getWidth(), getHeight());
				return;
			}
			
			super.paint(g);
			
			if(ref[Theme.style].isLocked()) return;

			if(ref[Theme.style].isAbsoluteColor()) {
				int x = getWidth() - 19;
				float hue = 0.0f;
			
				g.setColor(Color.BLACK);
				g.drawLine(x - 1, 1, x - 1, getHeight() - 2);
			
				for(int i = 0; i < 18; i++) {
					g.setColor(Color.getHSBColor(hue, 0.5f, 1.0f));
					g.drawLine(x + i, 1, x + i, getHeight() - 2);
					hue += 1.0 / 19.0;
				}
			}
			else {
				int x = getWidth() - 19;
				int grey = 255;
			
				g.setColor(Color.BLACK);
				g.drawLine(x - 1, 1, x - 1, getHeight() - 2);
			
				for(int i = 0; i < 18; i++) {
					g.setColor(new Color(grey, grey, grey));
					g.drawLine(x + i, 1, x + i, getHeight() - 2);
					grey -= 255 / 18;
				}
			}
		}

		class Mousey extends MouseAdapter {

			public void mouseReleased(MouseEvent e) {
				if(e.isPopupTrigger() && !ref[Theme.style].isLocked()) {
					showHSBPopup((HSBField)e.getSource());
				}
			}
			
			public void mousePressed(MouseEvent e) {
				HSBField cf = (HSBField)e.getSource();
				cf.requestFocus();
				
				if(e.isPopupTrigger() && !ref[Theme.style].isLocked()) {
					showHSBPopup(cf);
					return;
				}
				else if(e.getX() > cf.getWidth() - 19 && !ref[Theme.style].isLocked()) {
					showHSBPopup(cf);
					return;
				}
				
				if(e.getButton() != MouseEvent.BUTTON1) return;

				Color newColor = null;
				
				if(ref[Theme.style].isAbsoluteColor()) {
					newColor =
						PSColorChooser.showColorChooser(theFrame, cf.getBackground());
						
					if(newColor == null) return;	// cancelled
					
					cf.getColorReference().setColor(newColor);
					cf.setBackground(newColor);
				}
				else {
					newColor = SBChooser.showSBChooser(theFrame, cf);
				
					if(newColor == null) return;	// cancelled
				
					cf.getColorReference().setColor(SBChooser.getSat(), SBChooser.getBri());
					cf.setBackground(newColor);
				}
				
				updateTTT();
				initPanels();
				examplePanel.update(forceUpdate);
			}
		}
	}
	
	class SelectSpecialFontAction implements ActionListener {

		public void actionPerformed(ActionEvent e) {
			updateSpecialFont();
		}
	}
	
	class DerivedFontAction implements ActionListener {

		public void actionPerformed(ActionEvent e) {
			if(resistUpdate) return;
			
			if(e.getSource().equals(isPlainFont)) {
				if(isPlainFont.isSelected()) {
					isBoldFont.setSelected(false);
					selectedFont[Theme.style].setPlainFont(true);
				}
				else {
					selectedFont[Theme.style].setPlainFont(false);
				}
			}
			else if(e.getSource().equals(isBoldFont)) {
				if(isBoldFont.isSelected()) {
					isPlainFont.setSelected(false);
					selectedFont[Theme.style].setBoldFont(true);
				}
				else {
					selectedFont[Theme.style].setBoldFont(false);
				}
			}
			
			specialFontPanel.init(selectedFont[Theme.style]);
			updateFont(SPECIAL_FONT);
		}
	}
	
	class HSBPopupAction implements ActionListener {

		public void actionPerformed(ActionEvent e) {
			int ref = Integer.parseInt(e.getActionCommand());
			
			selectedHSBField.getColorReference().setReference(ref);
			selectedHSBField.resetReference();
			selectedHSBField.update();
			initPanels();
			examplePanel.update(selectedHSBField.forceUpdate);
		}
	}
	
	class SetThemeAction implements ActionListener {

		public void actionPerformed(ActionEvent e) {
			setTheme();
		}
	}
	
	class FontPanel extends JPanel {
		
		private int type;
		private JComboBox fontFamilyCombo, fontSizeCombo;
		private JCheckBox bold;
		private HSBField colorField;
		
		FontPanel(int type) {
			this.type = type;
			
			setupUI();
		}
		
		private void setupUI() {
			ActionListener updateFontAction = new UpdateFontAction();
			
			Font theFont = null;			
			if(type == PLAIN_FONT) {
				theFont = Theme.plainFont[Theme.style].getFont();
			}
			else if(type == BOLD_FONT) {
				theFont = Theme.boldFont[Theme.style].getFont();
			}
			else {
				theFont = selectedFont[Theme.style].getFont();
			}
			
			setLayout(new FlowLayout(FlowLayout.LEFT, 3, 1));
			if(type == PLAIN_FONT) {
				setBorder(new TitledBorder("Plain Font"));
			}
			else if(type == BOLD_FONT) {
				setBorder(new TitledBorder("Bold Font"));
			}
			else {
				setBorder(new TitledBorder("Special Font"));
			}
			
			add(new JLabel("Family"));
			fontFamilyCombo = createSchriftarten(theFont);
			fontFamilyCombo.addActionListener(updateFontAction);
			add(fontFamilyCombo);
			
			add(new JLabel("  Size"));
			fontSizeCombo = createSchriftgroessen(theFont);
			fontSizeCombo.addActionListener(updateFontAction);
			add(fontSizeCombo);
			
			add(new JLabel("    "));
			bold = new JCheckBox("Bold", theFont.isBold());
			bold.addActionListener(updateFontAction);
			add(bold);
			
			if(type == SPECIAL_FONT) {
				colorField = new HSBField(selectedFont[Theme.style].getColorReference(), true);
				add(colorField);
			}
		}
		
		public String getFontFamily() {
			return (String)fontFamilyCombo.getSelectedItem();
		}
		
		public int getFontSize() {
			return Integer.parseInt(
				(String)fontSizeCombo.getSelectedItem());
		}
		
		public int getFontType() {
			if(bold.isSelected()) {
				return Font.BOLD;
			}
			
			return Font.PLAIN;
		}
		
		public FontUIResource getCurrentFont() {
			return new FontUIResource(getFontFamily(), getFontType(), getFontSize());
				
		}
		
		public void init(ColoredFont f) {
			resistUpdate = true;
			fontSizeCombo.setSelectedItem(String.valueOf(f.getFont().getSize()));
			fontFamilyCombo.setSelectedItem(f.getFont().getFamily(Locale.GERMANY));
			bold.setSelected(f.getFont().isBold());
			resistUpdate = false;

			if(colorField == null) return;

			resistUpdate = true;
			colorField.setColorReference(f.getColorReference());
			isPlainFont.setSelected(f.isPlainFont());
			isBoldFont.setSelected(f.isBoldFont());
			resistUpdate = false;
		}
		
		private JComboBox createSchriftarten(Font font) {
  			Font[] fonts = GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();
  			TreeSet family = new TreeSet();
  	
  			for(int i = 0; i < fonts.length; i++) {
  				family.add(fonts[i].getFamily(Locale.GERMANY));
  			}
  	
  			JComboBox box = new JComboBox(new Vector(family));
  			
  			for(int i = 0; i < box.getItemCount(); i++) {
  				if(box.getItemAt(i).equals(font.getFamily(Locale.GERMANY))) {
  					box.setSelectedIndex(i);
  					break;
  				}
  			}

  			return box;
  		}
  
  		private JComboBox createSchriftgroessen(Font font) {
  			String[] groessen = new String[5];
  			groessen[0] = "10";
  			groessen[1] = "11";
  			groessen[2] = "12";
  			groessen[3] = "13";
  			groessen[4] = "14";
  			JComboBox box = new JComboBox(groessen);
  			
  			switch(font.getSize()) {
  				case 10:
  					box.setSelectedIndex(0);
  					break;
  				case 11:
  					box.setSelectedIndex(1);
  					break;
  				case 12:
  					box.setSelectedIndex(2);
  					break;
  				case 13:
  					box.setSelectedIndex(3);
  					break;
  				case 14:
  					box.setSelectedIndex(4);
  					break;
  			}

  			return box;
  		}
  		
  		class UpdateFontAction implements ActionListener {
  			
			public void actionPerformed(ActionEvent e) {
				if(resistUpdate) return;
				
				if(type == SPECIAL_FONT) {
					selectedFont[Theme.style].setPlainFont(false);
					selectedFont[Theme.style].setBoldFont(false);
				}
				
				updateFont(type);
				
				specialFontPanel.init(selectedFont[Theme.style]);
			}
  		}
	}
	
	class ExamplePanel extends JPanel {

		ExamplePanel() {
			setupUI();
		}
		
		private void setupUI() {
			setLayout(new BorderLayout());
			JPanel p0 = new JPanel(new BorderLayout(4, 0));
			JPanel p1 = new JPanel(new GridLayout(2, 2, 4, 4));
			JPanel p2 = new JPanel(new BorderLayout(4, 4));
			
			// Scrollables
			SizedPanel sizey = new SizedPanel(70, 130);

			JScrollPane sp = new JScrollPane(sizey,
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			sp.setPreferredSize(new Dimension(96, 96));
			sp.getVerticalScrollBar().setUnitIncrement(4);
			sp.getHorizontalScrollBar().setUnitIncrement(4);
			p1.add(sp);
			
			sizey = new SizedPanel(130, 130);

			sp = new JScrollPane(sizey,
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			sp.setPreferredSize(new Dimension(96, 96));
			sp.getVerticalScrollBar().setUnitIncrement(4);
			sp.getHorizontalScrollBar().setUnitIncrement(4);
			p1.add(sp);
			
			// List
			JList list = createList();
			list.setSelectedIndex(1);
			list.setVisibleRowCount(4);
			sp = new JScrollPane(list,
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
			p1.add(sp);
			
			// TextArea
			JTextArea ta = new JTextArea("\n  JTextArea", 4, 4);
			sp = new JScrollPane(ta,
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
			p1.add(sp);			
			p2.add(p1, BorderLayout.CENTER);
			p0.add(p2, BorderLayout.WEST);
			
			// Buttons
			p1 = new JPanel(new GridBagLayout());
			GridBagConstraints gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.WEST;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(0, 2, 4, 2);

			exampleButton = new JButton("JButton");
			p1.add(exampleButton, gc);
			gc.gridx ++;
			exampleDisabledButton = new JButton("Disabled");
			exampleDisabledButton.setEnabled(false);
			p1.add(exampleDisabledButton, gc);
			
			// ToggleButton
			gc.gridx = 0;
			gc.gridy ++;
			exampleToggleButton = new JToggleButton("JToggleButton");
			p1.add(exampleToggleButton, gc);
			gc.gridx ++;
			JCheckBox ch = new JCheckBox("Buttons w/icon", false);
			ch.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					addButtonIcons(((AbstractButton)e.getSource()).isSelected());
				}
			});
			p1.add(ch, gc);

			// CheckBox
			gc.gridx = 0;
			gc.gridy ++;
			ch = new JCheckBox("JCheckBox", false);
			p1.add(ch, gc);
			gc.gridx ++;
			ch = new JCheckBox("Disabled", true);
			ch.setEnabled(false);
			p1.add(ch, gc);
			
			// Radio
			gc.gridx = 0;
			gc.gridy ++;
			gc.insets = new Insets(0, 2, 12, 2);
			JRadioButton rb = new JRadioButton("JRadioButton");
			p1.add(rb, gc);
			gc.gridx ++;
			rb = new JRadioButton("Disabled", true);
			rb.setEnabled(false);
			p1.add(rb, gc);
			
			// Combos
			gc.gridx = 0;
			gc.gridy ++;
			gc.insets = new Insets(0, 2, 4, 2);
			JComboBox cb = createCombo("JComboBox");
			p1.add(cb, gc);
			gc.gridx ++;
			cb = createCombo("Disabled");
			cb.setEnabled(false);
			p1.add(cb, gc);
			
			gc.gridx = 0;
			gc.gridy ++;
			cb = createCombo("Editable JComboBox");
			cb.setEditable(true);
			p1.add(cb, gc);
			gc.gridx ++;
			cb = createCombo("Disabled");
			cb.setEditable(true);
			cb.setEnabled(false);
			p1.add(cb, gc);
			
			// Text
			gc.gridx = 0;
			gc.gridy ++;
			JTextField tf = new JTextField("JTextField");
			p1.add(tf, gc);
			gc.gridx ++;
			tf = new JTextField("Disabled");
			tf.setEnabled(false);
			p1.add(tf, gc);
			gc.gridx = 0;
			gc.gridy ++;
			tf = new JTextField("Non-Editable Textfield");
			tf.setEditable(false);
			p1.add(tf, gc);
			
			// Popup trigger
			gc.gridx ++;
			PopupTrigger trigger = new PopupTrigger();
			p1.add(trigger, gc);
			
			// Spinners
			gc.gridx = 0;
			gc.gridy ++;
			gc.insets = new Insets(8, 2, 2, 2);
			p2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
			JSpinner spinn = new JSpinner(new SpinnerNumberModel(41, 0, 42, 1));
			p2.add(spinn);
			p2.add(new JLabel(" "));
			spinn = new JSpinner(new SpinnerDateModel());
			p2.add(spinn);
			p1.add(p2, gc);
			
			gc.gridx ++;
			p2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
			spinn = new JSpinner(new SpinnerNumberModel(42, 0, 42, 1));
			spinn.setEnabled(false);
			p2.add(spinn);
			p2.add(new JLabel(" "));
			spinn = new JSpinner(new SpinnerDateModel(
				new Date(), null, null, Calendar.DAY_OF_WEEK));
			spinn.setEnabled(false);
			p2.add(spinn);
			p1.add(p2, gc);
			p2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
			p2.add(p1);
			
			p0.add(p2, BorderLayout.CENTER);
			
			// Tree
			JPanel p3 = new JPanel(new BorderLayout());
			p2 = new JPanel(new GridLayout(1, 2));
			JTree tree = new JTree();
			tree.expandPath(tree.getNextMatch("sports", 0, Position.Bias.Forward));
			p2.add(tree);
			tree = new JTree();
			tree.expandPath(tree.getNextMatch("sports", 0, Position.Bias.Forward));
			tree.setEnabled(false);
			p2.add(tree);
			p3.add(p2, BorderLayout.CENTER);
			
			// Progressbar/Slider vert
			p1 = new JPanel(new BorderLayout(8, 0));
			p2 = new JPanel(new GridBagLayout());
			gc.anchor = GridBagConstraints.WEST;
			gc.fill = GridBagConstraints.VERTICAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(0, 2, 0, 2);
			
			vertProgressBar = new JProgressBar(JProgressBar.VERTICAL, 0, 20);
			vertProgressBar.setValue(0);
			vertProgressBar.setStringPainted(true);
			vertProgressBar.addMouseListener(new ProgressBarAction());
			vertProgressBar.setToolTipText("Click to start/stop");
			p2.add(vertProgressBar, gc);
			gc.gridx ++;
			
			vertSlider = new JSlider(JSlider.VERTICAL, 0, 30, 25);
			vertSlider.setPreferredSize(new Dimension(36, 130));
			vertSlider.setMajorTickSpacing(10);
			vertSlider.setMinorTickSpacing(5);
			vertSlider.setPaintTicks(true);
			p2.add(vertSlider, gc);
			p1.add(p2, BorderLayout.WEST);
			
			// Progressbar/Slider horz
			p2 = new JPanel(new GridBagLayout());
			gc.anchor = GridBagConstraints.WEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(2, 0, 2, 0);
			
			horzProgressBar = new JProgressBar(0, 20);
			horzProgressBar.setValue(0);
			horzProgressBar.setStringPainted(true);
			horzProgressBar.addMouseListener(new ProgressBarAction());
			horzProgressBar.setToolTipText("Click to start/stop");
			p2.add(horzProgressBar, gc);
			gc.gridy ++;
			horzSlider = new JSlider(JSlider.HORIZONTAL, 0, 30, 25);
			horzSlider.setPreferredSize(new Dimension(150, 36));
			horzSlider.setMajorTickSpacing(10);
			horzSlider.setMinorTickSpacing(5);
			horzSlider.setPaintTicks(true);
			p2.add(horzSlider, gc);
			p1.add(p2, BorderLayout.NORTH);
			
			// OptionPane Buttons
			p2 = new JPanel(new GridBagLayout());
			gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.WEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(3, 2, 3, 2);
			rb = new JRadioButton("Sliders Enabled", true);
			rb.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(horzSlider.isEnabled()) {
						horzSlider.setEnabled(false);
						vertSlider.setEnabled(false);
					}
					else {
						horzSlider.setEnabled(true);
						vertSlider.setEnabled(true);
					}
				}
			});
			p2.add(rb, gc);
			gc.gridy ++;
			JButton b = new JButton("MessageDialog");
			b.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					showMessageDialog();
				}
			});
			p2.add(b, gc);
			gc.gridy ++;
			b = new JButton("ConfirmDialog");
			b.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					showConfirmationDialog();
				}
			});
			p2.add(b, gc);
			gc.gridy ++;
			b = new JButton("WarningDialog");
			b.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					showWarningDialog();
				}
			});
			p2.add(b, gc);
			gc.gridy ++;
			b = new JButton("ErrorDialog");
			b.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					showErrorDialog();
				}
			});
			p2.add(b, gc);
			p1.add(p2, BorderLayout.CENTER);
			
			p3.add(p1, BorderLayout.EAST);
			
			p0.add(p3, BorderLayout.EAST);
			
			p2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
			p2.setBorder(new EtchedBorder());
			p2.add(p0);			
			add(p2, BorderLayout.NORTH);
			
			add(new Desktop(), BorderLayout.CENTER);
		}
		
		private JList createList() {
			String[] items = new String[7];
			items[0] = "A JList";
			items[1] = "can have";
			items[2] = "zero to";
			items[3] = "many items";
			items[4] = "and can be";
			items[5] = "scrolled";
			items[6] = "(or not)";
			
			return new JList(items);
		}
		
		private JComboBox createCombo(String s) {
			String[] items = new String[7];
			items[0] = s;
			items[1] = "can have";
			items[2] = "zero to";
			items[3] = "many items";
			items[4] = "and can be";
			items[5] = "triggered";
			items[6] = "many times";
			
			return new JComboBox(items);
		}
		
		public void update(boolean forceUpdate) {
			updateTheme();
			
			if(forceUpdate) {
				updateThemeButton.setEnabled(true);
			}
			repaint(0);
		}
		
		public void paint(Graphics g) {
			super.paint(g);
		}
		
		class Desktop extends JDesktopPane {
			
			Desktop() {
				this.setBackground(Color.GRAY);
				setupUI();
			}
			
			private void setupUI() {
				JPanel p0 = new JPanel();
				p0.setBounds(0, 0, 780, 160);
				
				// Table
				JTable table = new JTable(new SmallTableModel());
				table.setColumnSelectionAllowed(true);
							
				JScrollPane sp = new JScrollPane(table);
				sp.setBounds(10, 40, 192, 96);
				add(sp, JDesktopPane.DEFAULT_LAYER);
				
				// Internal Frame
				internalFrame = new JInternalFrame("JInternalFrame", true, true, true, true);
				internalFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			
				internalFrame.addInternalFrameListener(new InternalFrameAdapter() {				
					public void internalFrameClosing(InternalFrameEvent e) {
						String msg = "This internal frame cannot be closed.";
						JOptionPane.showMessageDialog(
							theFrame, msg, "Info", JOptionPane.INFORMATION_MESSAGE);
						e.getInternalFrame().show();
					}
				});
				internalFrame.getContentPane().add(new SizedPanel(200, 100));
				internalFrame.pack();
				Dimension frameSize = internalFrame.getPreferredSize();
				internalFrame.setBounds(400, 10, frameSize.width, frameSize.height);
				internalFrame.show();
				add(internalFrame, JDesktopPane.PALETTE_LAYER);
			
				// Palette
				palette = new JInternalFrame("Palette");
				palette.putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
				JPanel pp = new JPanel();
				pp.setBackground(Color.WHITE);
				palette.getContentPane().add(pp);
				palette.setBounds(400 + internalFrame.getWidth() + 2, 10, 80, 140);
				palette.show();
				add(palette, JDesktopPane.DRAG_LAYER);
			}
		}
	}
	
	class ScrollsCP extends JPanel {
		
		private JCheckBox rolloverEnabled;
		private boolean inited = false;
		
		ScrollsCP() {
			setupUI();
		}
		
		private void setupUI() {
			setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
			JPanel p1 = new JPanel(new GridBagLayout());
			GridBagConstraints gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(2, 4, 0, 4);
			
			// Thumb
			p1.add(new JLabel("Thumb Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			scrollThumbField = new HSBField(Theme.scrollThumbColor);
			p1.add(scrollThumbField, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Rollover Col"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			scrollThumbRolloverBg = new HSBField(Theme.scrollThumbRolloverColor);
			p1.add(scrollThumbRolloverBg, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Presssed Col"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			scrollThumbPressedBg = new HSBField(Theme.scrollThumbPressedColor);
			p1.add(scrollThumbPressedBg, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Disabled Col"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			scrollThumbDisabledBg = new HSBField(Theme.scrollThumbDisabledColor);
			p1.add(scrollThumbDisabledBg, gc);
			
			// Grip
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Grip Dark Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			scrollGripDark = new HSBField(Theme.scrollGripDarkColor);
			p1.add(scrollGripDark, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Grip Light Col"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			scrollGripLight = new HSBField(Theme.scrollGripLightColor);
			p1.add(scrollGripLight, gc);
			gc.gridy = 7;
			
			gc.insets = new Insets(0, 8, 0, 4);
			rolloverEnabled = new JCheckBox("Paint Rollover", false);
			rolloverEnabled.addActionListener(checkAction);
			p1.add(rolloverEnabled, gc);
			
			// Button
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Button Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			scrollButtField = new HSBField(Theme.scrollButtColor);
			p1.add(scrollButtField, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Rollover Col"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			scrollButtRolloverBg = new HSBField(Theme.scrollButtRolloverColor);
			p1.add(scrollButtRolloverBg, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Presssed Col"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			scrollButtPressedBg = new HSBField(Theme.scrollButtPressedColor);
			p1.add(scrollButtPressedBg, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Col"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			scrollButtDisabledBg = new HSBField(Theme.scrollButtDisabledColor);
			p1.add(scrollButtDisabledBg, gc);
			
			// Spread
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Spread Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			scrollSpreadLight = new SpreadPanel(Theme.scrollSpreadLight, 20);
			p1.add(scrollSpreadLight, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Spread Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			scrollSpreadDark = new SpreadPanel(Theme.scrollSpreadDark, 20);
			p1.add(scrollSpreadDark, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled S. Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			scrollSpreadLightDisabled = new SpreadPanel(Theme.scrollSpreadLightDisabled, 20);
			p1.add(scrollSpreadLightDisabled, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled S. Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			scrollSpreadDarkDisabled = new SpreadPanel(Theme.scrollSpreadDarkDisabled, 20);
			p1.add(scrollSpreadDarkDisabled, gc);
			
			// Border
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Border Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			scrollBorder = new HSBField(Theme.scrollBorderColor);
			p1.add(scrollBorder, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Border Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			scrollDark = new HSBField(Theme.scrollDarkColor);
			p1.add(scrollDark, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Border Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			scrollLight = new HSBField(Theme.scrollLightColor);
			p1.add(scrollLight, gc);

			// Border disabled
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Disabled Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			scrollBorderDisabled = new HSBField(Theme.scrollBorderDisabledColor);
			p1.add(scrollBorderDisabled, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			scrollDarkDisabled = new HSBField(Theme.scrollDarkDisabledColor);
			p1.add(scrollDarkDisabled, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			scrollLightDisabled = new HSBField(Theme.scrollLightDisabledColor);
			p1.add(scrollLightDisabled, gc);

			// Track
			gc.gridx ++;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Track Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			trackField = new HSBField(Theme.scrollTrackColor);
			p1.add(trackField, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Track Disabled"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			trackDisabled = new HSBField(Theme.scrollTrackDisabledColor);
			p1.add(trackDisabled, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Track Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			trackBorder = new HSBField(Theme.scrollTrackBorderColor);
			p1.add(trackBorder, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Border Disabled"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			trackBorderDisabled = new HSBField(Theme.scrollTrackBorderDisabledColor);
			p1.add(trackBorderDisabled, gc);
			
			// Arrow
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Arrow Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			scrollArrowField = new HSBField(Theme.scrollArrowColor);
			p1.add(scrollArrowField, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Arrow Disabled"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			scrollArrowDisabled = new HSBField(Theme.scrollArrowDisabledColor);
			p1.add(scrollArrowDisabled, gc);
			gc.gridy += 3;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Scrollpane Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			scrollPane = new HSBField(Theme.scrollPaneBorderColor);
			p1.add(scrollPane, gc);
			
			add(p1);
		}
		
		void init(boolean always) {
			if(inited && !always) return;

			rolloverEnabled.setSelected(Theme.scrollRollover[Theme.style]);
			
			scrollThumbField.update();
			scrollButtField.update();
			scrollArrowField.update();
			trackField.update();
			scrollThumbRolloverBg.update();
			scrollThumbPressedBg.update();
			scrollThumbDisabledBg.update();
			trackBorder.update();
			scrollButtRolloverBg.update();
			scrollButtPressedBg.update();
			scrollButtDisabledBg.update();
			trackDisabled.update();
			trackBorderDisabled.update();
			scrollArrowDisabled.update();
			scrollGripDark.update();
			scrollGripLight.update();
			scrollBorder.update();
			scrollDark.update();
			scrollLight.update();
			scrollBorderDisabled.update();
			scrollDarkDisabled.update();
			scrollLightDisabled.update();
			scrollPane.update();
			scrollSpreadDark.init();
			scrollSpreadLight.init();
			scrollSpreadDarkDisabled.init();
			scrollSpreadLightDisabled.init();

			inited = true;
		}
		
		void updateTheme() {	
			if(!inited || resistUpdate) return;
			
			Theme.scrollRollover[Theme.style] = rolloverEnabled.isSelected();
		}
	}
	
	class SliderCP extends JPanel {
		
		private JCheckBox rolloverEnabled;
		private boolean inited = false;
		
		SliderCP() {
			setupUI();
		}
		
		private void setupUI() {
			setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
			JPanel p1 = new JPanel(new GridBagLayout());
			//p1.setBorder(new EtchedBorder());
			GridBagConstraints gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(2, 4, 0, 4);
			
			// Thumb
			p1.add(new JLabel("Thumb Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			sliderThumbField = new HSBField(Theme.sliderThumbColor);
			p1.add(sliderThumbField, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Rollover Col"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			sliderThumbRolloverBg = new HSBField(Theme.sliderThumbRolloverColor);
			p1.add(sliderThumbRolloverBg, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Presssed Col"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			sliderThumbPressedBg = new HSBField(Theme.sliderThumbPressedColor);
			p1.add(sliderThumbPressedBg, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Disabled Col"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			sliderThumbDisabledBg = new HSBField(Theme.sliderThumbDisabledColor);
			p1.add(sliderThumbDisabledBg, gc);
			
			// border
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Border Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			sliderBorder = new HSBField(Theme.sliderBorderColor);
			p1.add(sliderBorder, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Dark Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			sliderDark = new HSBField(Theme.sliderDarkColor);
			p1.add(sliderDark, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Light Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			sliderLight = new HSBField(Theme.sliderLightColor);
			p1.add(sliderLight, gc);
			
			// disabled border
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Disabled Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			sliderDisabledBorder = new HSBField(Theme.sliderBorderDisabledColor);
			p1.add(sliderDisabledBorder, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Dark Disabled"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			sliderDisabledDark = new HSBField(Theme.sliderDarkDisabledColor);
			p1.add(sliderDisabledDark, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Light Disabled"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			sliderDisabledLight = new HSBField(Theme.sliderLightDisabledColor);
			p1.add(sliderDisabledLight, gc);
			gc.gridy += 2;
			
			gc.insets = new Insets(0, 8, 0, 4);
			rolloverEnabled = new JCheckBox("Paint Rollover", true);
			rolloverEnabled.addActionListener(checkAction);
			p1.add(rolloverEnabled, gc);
			
			// Track
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Track Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			sliderTrack = new HSBField(Theme.sliderTrackColor);
			p1.add(sliderTrack, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Track Border Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			sliderTrackBorder = new HSBField(Theme.sliderTrackBorderColor);
			p1.add(sliderTrackBorder, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Track Border Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			sliderTrackDark = new HSBField(Theme.sliderTrackDarkColor);
			p1.add(sliderTrackDark, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Track Border Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			sliderTrackLight = new HSBField(Theme.sliderTrackLightColor);
			p1.add(sliderTrackLight, gc);
			
			// Ticks
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Ticks Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			sliderTick = new HSBField(Theme.sliderTickColor);
			p1.add(sliderTick, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Ticks Disabled"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			sliderTickDisabled = new HSBField(Theme.sliderTickDisabledColor);
			p1.add(sliderTickDisabled, gc);
			
			add(p1);
		}
		
		void init(boolean always) {
			if(inited && !always) return;

			rolloverEnabled.setSelected(Theme.sliderRollover[Theme.style]);
			
			sliderThumbField.update();
			sliderThumbRolloverBg.update();
			sliderThumbPressedBg.update();
			sliderThumbDisabledBg.update();
			sliderBorder.update();
			sliderDark.update();
			sliderLight.update();
			sliderDisabledBorder.update();
			sliderDisabledDark.update();
			sliderDisabledLight.update();
			sliderTrack.update();
			sliderTrackBorder.update();
			sliderTrackDark.update();
			sliderTrackLight.update();
			sliderTick.update();
			sliderTickDisabled.update();

			inited = true;
		}
		
		void updateTheme() {	
			if(!inited || resistUpdate) return;

			Theme.sliderRollover[Theme.style] = rolloverEnabled.isSelected();
		}
	}
	
	class ToolCP extends JPanel {
		
		private JCheckBox focusEnabled;
		private boolean inited = false;
		
		ToolCP() {
			setupUI();
		}
		
		private void setupUI() {
			setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
			JPanel p1 = new JPanel(new GridBagLayout());
			GridBagConstraints gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(2, 4, 0, 4);
			
			// ToolBar
			p1.add(new JLabel("ToolBar Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			toolBar = new HSBField(Theme.toolBarColor, true);
			p1.add(toolBar, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("ToolBar Light Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			toolBarLight = new HSBField(Theme.toolBarLightColor, true);
			p1.add(toolBarLight, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("ToolBar Dark Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			toolBarDark = new HSBField(Theme.toolBarDarkColor, true);
			p1.add(toolBarDark, gc);
			
			// Button
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Button Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			toolButt = new HSBField(Theme.toolButtColor, true);
			p1.add(toolButt, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Button Rollover"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			toolButtRollover = new HSBField(Theme.toolButtRolloverColor, true);
			p1.add(toolButtRollover, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Button Pressed"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			toolButtPressed = new HSBField(Theme.toolButtPressedColor, true);
			p1.add(toolButtPressed, gc);
			
			// Border
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Border Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			toolBorder = new HSBField(Theme.toolBorderColor, true);
			p1.add(toolBorder, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Border Pressed"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			toolBorderPressed = new HSBField(Theme.toolBorderPressedColor, true);
			p1.add(toolBorderPressed, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Border Selected"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			toolBorderSelected = new HSBField(Theme.toolBorderSelectedColor, true);
			p1.add(toolBorderSelected, gc);

			// disabled border
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Border Dark Col"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			toolBorderDark = new HSBField(Theme.toolBorderDarkColor, true);
			p1.add(toolBorderDark, gc);			
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Border Light Col"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			toolBorderLight = new HSBField(Theme.toolBorderLightColor, true);
			p1.add(toolBorderLight, gc);
			gc.gridy += 2;
			
			gc.insets = new Insets(0, 8, 0, 4);
			gc.gridheight = 2;
			focusEnabled = new JCheckBox("Paint Focus", true);
			focusEnabled.addActionListener(checkAction);
			p1.add(focusEnabled, gc);
			
			add(p1);
		}
		
		void init(boolean always) {
			if(inited && !always) return;

			focusEnabled.setSelected(Theme.toolFocus[Theme.style]);
			
			toolBar.update();
			toolBarDark.update();
			toolBarLight.update();
			toolButt.update();
			toolButtRollover.update();
			toolButtPressed.update();
			toolBorder.update();
			toolBorderPressed.update();
			toolBorderSelected.update();
			toolBorderDark.update();
			toolBorderLight.update();

			inited = true;
		}
		
		void updateTheme() {
			if(!inited || resistUpdate) return;

    		Theme.toolFocus[Theme.style] = focusEnabled.isSelected();
		}
	}
	
	class TableCP extends JPanel {
		
		private JCheckBox focusEnabled;
		private boolean inited = false;
		
		TableCP() {
			setupUI();
		}
		
		private void setupUI() {
			setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
			JPanel p1 = new JPanel(new GridBagLayout());
			GridBagConstraints gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(2, 4, 0, 4);
			
			// Back
			p1.add(new JLabel("Background Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			tableBack = new HSBField(Theme.tableBackColor, true);
			p1.add(tableBack, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Header Background"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			tableHeaderBack = new HSBField(Theme.tableHeaderBackColor, true);
			p1.add(tableHeaderBack, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Grid Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			tableGrid = new HSBField(Theme.tableGridColor, true);
			p1.add(tableGrid, gc);

			// Selected
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Selected Cell Background"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			tableSelectedBack = new HSBField(Theme.tableSelectedBackColor, true);
			p1.add(tableSelectedBack, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Selected Cell Foreground"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			tableSelectedFore = new BlackWhitePanel(Theme.tableSelectedForeColor, true);
			p1.add(tableSelectedFore, gc);
			
			add(p1);
		}
		
		void init(boolean always) {
			if(inited && !always) return;

			tableBack.update();
			tableHeaderBack.update();
			tableGrid.update();
			tableSelectedBack.update();
			tableSelectedFore.update();

			inited = true;
		}
		
		void updateTheme() {}
	}
	
	class SpinnerCP extends JPanel {
		
		private JCheckBox rolloverEnabled;
		private boolean inited = false;
		
		SpinnerCP() {
			setupUI();
		}
		
		private void setupUI() {
			setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
			JPanel p1 = new JPanel(new GridBagLayout());
			GridBagConstraints gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(2, 4, 0, 4);
			
			// Button
			p1.add(new JLabel("Button Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			spinnerButtField = new HSBField(Theme.spinnerButtColor);
			p1.add(spinnerButtField, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Rollover Col"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			spinnerButtRolloverBg = new HSBField(Theme.spinnerButtRolloverColor);
			p1.add(spinnerButtRolloverBg, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Presssed Col"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			spinnerButtPressedBg = new HSBField(Theme.spinnerButtPressedColor);
			p1.add(spinnerButtPressedBg, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Disabled Col"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			spinnerButtDisabledBg = new HSBField(Theme.spinnerButtDisabledColor);
			p1.add(spinnerButtDisabledBg, gc);
			
			// Spread
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Spread Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			spinnerSpreadLight = new SpreadPanel(Theme.spinnerSpreadLight, 20);
			p1.add(spinnerSpreadLight, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Spread Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			spinnerSpreadDark = new SpreadPanel(Theme.spinnerSpreadDark, 20);
			p1.add(spinnerSpreadDark, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled S. Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			spinnerSpreadLightDisabled = new SpreadPanel(Theme.spinnerSpreadLightDisabled, 20);
			p1.add(spinnerSpreadLightDisabled, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled S. Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			spinnerSpreadDarkDisabled = new SpreadPanel(Theme.spinnerSpreadDarkDisabled, 20);
			p1.add(spinnerSpreadDarkDisabled, gc);
			
			// border
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Border Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			spinnerBorder = new HSBField(Theme.spinnerBorderColor);
			p1.add(spinnerBorder, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Dark Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			spinnerDark = new HSBField(Theme.spinnerDarkColor);
			p1.add(spinnerDark, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Light Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			spinnerLight = new HSBField(Theme.spinnerLightColor);
			p1.add(spinnerLight, gc);
			
			// disabled border
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Disabled Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			spinnerDisabledBorder = new HSBField(Theme.spinnerBorderDisabledColor);
			p1.add(spinnerDisabledBorder, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			spinnerDisabledDark = new HSBField(Theme.spinnerDarkDisabledColor);
			p1.add(spinnerDisabledDark, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			spinnerDisabledLight = new HSBField(Theme.spinnerLightDisabledColor);
			p1.add(spinnerDisabledLight, gc);

			// arrow
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Arrow Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			spinnerArrowField = new HSBField(Theme.spinnerArrowColor);
			p1.add(spinnerArrowField, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Arrow"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			spinnerArrowDisabled = new HSBField(Theme.spinnerArrowDisabledColor);
			p1.add(spinnerArrowDisabled, gc);
			gc.gridy += 2;
			
			gc.gridheight = 2;
			gc.insets = new Insets(0, 8, 0, 4);
			rolloverEnabled = new JCheckBox("Paint Rollover", true);
			rolloverEnabled.addActionListener(checkAction);
			p1.add(rolloverEnabled, gc);
			
			add(p1);
		}
		
		void init(boolean always) {
			if(inited && !always) return;

			rolloverEnabled.setSelected(Theme.spinnerRollover[Theme.style]);
			
			spinnerButtField.update();
			spinnerArrowField.update();
			spinnerButtRolloverBg.update();
			spinnerButtPressedBg.update();
			spinnerButtDisabledBg.update();
			spinnerBorder.update();
			spinnerDark.update();
			spinnerLight.update();
			spinnerDisabledBorder.update();
			spinnerDisabledDark.update();
			spinnerDisabledLight.update();
			spinnerArrowDisabled.update();
			spinnerSpreadDark.init();
			spinnerSpreadLight.init();
			spinnerSpreadDarkDisabled.init();
			spinnerSpreadLightDisabled.init();

			inited = true;
		}
		
		void updateTheme() {	
			if(!inited || resistUpdate) return;
			
			Theme.spinnerRollover[Theme.style] = rolloverEnabled.isSelected();
		}
	}
	
	class MenuCP extends JPanel {
		
		private JCheckBox rolloverEnabled;
		private boolean inited = false;
		
		MenuCP() {
			setupUI();
		}
		
		private void setupUI() {	
			setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
			JPanel p1 = new JPanel(new GridBagLayout());
			GridBagConstraints gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(2, 4, 0, 4);

			p1.add(new JLabel("MenuBar Background"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			menuBar = new HSBField(Theme.menuBarColor, true);
			p1.add(menuBar, gc);
			gc.gridy ++;

			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Menu Rollover Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			menuRolloverField = new HSBField(Theme.menuRolloverColor);
			p1.add(menuRolloverField, gc);
			gc.gridy += 2;
			
			gc.insets = new Insets(0, 4, 0, 4);
			gc.gridheight = 2;
			rolloverEnabled = new JCheckBox("Paint Rollover", true);
			rolloverEnabled.addActionListener(checkAction);
			p1.add(rolloverEnabled, gc);
			
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Popup Background"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			menuPopup = new HSBField(Theme.menuPopupColor);
			p1.add(menuPopup, gc);
			
			gc.gridx ++;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Border Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			menuBorder = new HSBField(Theme.menuBorderColor);
			p1.add(menuBorder, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Border Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			menuDark = new HSBField(Theme.menuDarkColor);
			p1.add(menuDark, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Border Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			menuLight = new HSBField(Theme.menuLightColor);
			p1.add(menuLight, gc);

			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Selected Background"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			menuItemRollover = new HSBField(Theme.menuItemRolloverColor);
			p1.add(menuItemRollover, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Selected Foreground"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			menuSelectedText = new BlackWhitePanel(Theme.menuSelectedTextColor);
			p1.add(menuSelectedText, gc);
			
			// Icon
			gc.gridx ++;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Icon Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			menuIcon = new HSBField(Theme.menuIconColor);
			p1.add(menuIcon, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Icon Rollover"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			menuIconRollover = new HSBField(Theme.menuIconRolloverColor);
			p1.add(menuIconRollover, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Icon Disabled"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			menuIconDisabled = new HSBField(Theme.menuIconDisabledColor);
			p1.add(menuIconDisabled, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Shadow"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			menuIconShadow = new HSBField(Theme.menuIconShadowColor);
			p1.add(menuIconShadow, gc);
			
			// Separator
			gc.gridx ++;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Separator Dark Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			menuSepDark = new HSBField(Theme.menuSepDarkColor);
			p1.add(menuSepDark, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Separator Light Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			menuSepLight = new HSBField(Theme.menuSepLightColor);
			p1.add(menuSepLight, gc);

			add(p1);
		}
		
		void init(boolean always) {
			if(inited && !always) return;
			
			menuSelectedText.update();
			menuRolloverField.update();
    		menuBar.update();
    		menuBorder.update();
    		menuDark.update();
    		menuLight.update();
    		menuPopup.update();
    		menuItemRollover.update();
    		menuIcon.update();
    		menuIconRollover.update();
    		menuIconDisabled.update();
    		menuIconShadow.update();
    		menuSepDark.update();
    		menuSepLight.update();

			rolloverEnabled.setSelected(Theme.menuRollover[Theme.style]);
					
			inited = true;
		}
		
		void updateTheme() {
			if(!inited || resistUpdate) return;
			
			Theme.menuRollover[Theme.style] = rolloverEnabled.isSelected();
		}
	}
	
	class TreeCP extends JPanel {
		
		private boolean inited = false;
		
		TreeCP() {
			setupUI();
		}
		
		private void setupUI() {
			setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
			JPanel p1 = new JPanel(new GridBagLayout());
			//p1.setBorder(new EtchedBorder());
			GridBagConstraints gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(2, 4, 0, 4);

			p1.add(new JLabel("Tree Background"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			treeBg = new HSBField(Theme.treeBgColor, true);
			p1.add(treeBg, gc);
			
			gc.gridx ++;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Text Background"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			treeTextBg = new HSBField(Theme.treeTextBgColor, true);
			p1.add(treeTextBg, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Text Foreground"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			treeText = new BlackWhitePanel(Theme.treeTextColor, true);
			p1.add(treeText, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Selected Text Bg"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			treeSelectedBg = new HSBField(Theme.treeSelectedBgColor, true);
			p1.add(treeSelectedBg, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Selected Foreground"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			treeSelectedText = new BlackWhitePanel(Theme.treeSelectedTextColor, true);
			p1.add(treeSelectedText, gc);
			gc.gridy ++;

			add(p1);
		}
		
		void init(boolean always) {
			if(inited && !always) return;
			
    		treeText.update();
    		treeSelectedText.update();   		
    		treeBg.update();
    		treeTextBg.update();
    		treeSelectedBg.update();

			inited = true;
		}
		
		void updateTheme() {}
	}
	
	class TabsCP extends JPanel {
		
		private JCheckBox rolloverEnabled, focusEnabled;
		private JSpinner firstTabDist;
		private boolean inited = false;
		
		TabsCP() {
			setupUI();
		}
		
		private void setupUI() {
			setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
			JPanel p1 = new JPanel(new GridBagLayout());
			GridBagConstraints gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(2, 4, 0, 4);

			// Pane Border
			p1.add(new JLabel("Pane Border Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			tabPaneBorder = new HSBField(Theme.tabPaneBorderColor, true);
			p1.add(tabPaneBorder, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);			
			p1.add(new JLabel("Pane Border Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			tabPaneDark = new HSBField(Theme.tabPaneDarkColor, true);
			p1.add(tabPaneDark, gc);			
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);			
			p1.add(new JLabel("Pane Border Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			tabPaneLight = new HSBField(Theme.tabPaneLightColor, true);
			p1.add(tabPaneLight, gc);
			
			// Tab
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Unselected Bg"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			tabNormalBg = new HSBField(Theme.tabNormalColor, true);
			p1.add(tabNormalBg, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Selected Bg"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			tabSelectedBg = new HSBField(Theme.tabSelectedColor, true);
			p1.add(tabSelectedBg, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);			
			p1.add(new JLabel("Rollover Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			tabRoll = new HSBField(Theme.tabRolloverColor, true);
			p1.add(tabRoll, gc);
			
			// Tab Border
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Tab Border Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			tabBorder = new HSBField(Theme.tabBorderColor, true);
			p1.add(tabBorder, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);			
			p1.add(new JLabel("Tab Border Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			tabDark = new HSBField(Theme.tabDarkColor, true);
			p1.add(tabDark, gc);			
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);			
			p1.add(new JLabel("Tab Border Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			tabLight = new HSBField(Theme.tabLightColor, true);
			p1.add(tabLight, gc);

			// first Tab Distance
			gc.gridx ++;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("First Tab Distance"), gc);
			gc.gridy ++;
			gc.gridheight = 2;
			firstTabDist = new JSpinner(new SpinnerNumberModel(2, 2, 12, 1));
			firstTabDist.addChangeListener(updateAction);
			p1.add(firstTabDist, gc);
			
			// Flags
			gc.gridy = 3;
			gc.gridheight = 3;		
			gc.insets = new Insets(0, 8, 0, 4);
			JPanel p2 = new JPanel(new GridLayout(2, 1));
			rolloverEnabled = new JCheckBox("Paint Rollover", true);
			rolloverEnabled.addActionListener(checkAction);
			p2.add(rolloverEnabled);
			
			focusEnabled = new JCheckBox("Paint Focus", true);
			focusEnabled.addActionListener(iconCheckAction);
			p2.add(focusEnabled);

			p1.add(p2, gc);
			
			add(p1);
		}
		
		void init(boolean always) {
			if(inited && !always) return;
					
			firstTabDist.setValue(new Integer(Theme.firstTabDistance[Theme.style]));

			rolloverEnabled.setSelected(Theme.tabRollover[Theme.style]);
			focusEnabled.setSelected(Theme.tabFocus[Theme.style]);

			tabPaneBorder.update();
			tabPaneDark.update();
			tabPaneLight.update();
			tabNormalBg.update();
			tabSelectedBg.update();
			tabBorder.update();
			tabDark.update();
			tabLight.update();
			tabRoll.update();
			
			inited = true;
		}
		
		void updateTheme() {
			if(!inited || resistUpdate) return;

			Theme.tabRollover[Theme.style] = rolloverEnabled.isSelected();
    		Theme.tabFocus[Theme.style] = focusEnabled.isSelected();
    		Theme.firstTabDistance[Theme.style] = getFirstTabDistance();
		}
		
		int getFirstTabDistance() {
			return ((Integer)firstTabDist.getValue()).intValue();
		}
	}
	
	class TextCP extends JPanel {
		private JSpinner mTop, mLeft, mBottom, mRight;
		private boolean inited = false;
		
		TextCP() {
			setupUI();
		}
		
		private void setupUI() {
			setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
			JPanel p1 = new JPanel(new GridBagLayout());
			//p1.setBorder(new EtchedBorder());
			GridBagConstraints gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.WEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(2, 4, 0, 4);

			// background
			p1.add(new JLabel("Text Background"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			textBg = new HSBField(Theme.textBgColor, true);
			p1.add(textBg, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Text Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			textText = new BlackWhitePanel(Theme.textTextColor, true);
			p1.add(textText, gc);

			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Selected Bg"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			textSelectedBg = new HSBField(Theme.textSelectedBgColor, true);
			p1.add(textSelectedBg, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Selected Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			textSelectedText = new BlackWhitePanel(Theme.textSelectedTextColor, true);
			p1.add(textSelectedText, gc);
			
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Disabled Bg"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			textDisabledBg = new HSBField(Theme.textDisabledBgColor);
			p1.add(textDisabledBg, gc);

			// Borders
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Border Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			textBorder = new HSBField(Theme.textBorderColor);
			p1.add(textBorder, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Border Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			textDark = new HSBField(Theme.textDarkColor);
			p1.add(textDark, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Border Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			textLight = new HSBField(Theme.textLightColor);
			p1.add(textLight, gc);
			
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Disabled Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			textBorderDisabled = new HSBField(Theme.textBorderDisabledColor);
			p1.add(textBorderDisabled, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			textDisabledDark = new HSBField(Theme.textDarkDisabledColor);
			p1.add(textDisabledDark, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			textDisabledLight = new HSBField(Theme.textLightDisabledColor);
			p1.add(textDisabledLight, gc);
			
			// Insets
			gc.gridx ++;
			gc.gridy = 0;
			gc.gridheight = 6;
			gc.insets = new Insets(2, 16, 0, 4);
			
			JPanel p2 = new JPanel(new GridBagLayout());
			GridBagConstraints gc2 = new GridBagConstraints();
			gc2.anchor = GridBagConstraints.NORTHWEST;
			gc2.fill = GridBagConstraints.HORIZONTAL;
			gc2.gridx = 0;
			gc2.gridy = 1;
			gc2.insets = new Insets(0, 2, 0, 2);
			
			mLeft = new JSpinner(new SpinnerNumberModel(16, 2, 24, 1));
      		mLeft.addChangeListener(updateAction);
			p2.add(mLeft, gc2);
			
			gc2.gridx ++;
			gc2.gridy = 0;
			mTop = new JSpinner(new SpinnerNumberModel(2, 1, 8, 1));
      		mTop.addChangeListener(updateAction);
			p2.add(mTop, gc2);
			gc2.gridy ++;
			p2.add(new JLabel("Insets"), gc2);
			gc2.gridy ++;
			mBottom = new JSpinner(new SpinnerNumberModel(3, 1, 8, 1));
      		mBottom.addChangeListener(updateAction);
			p2.add(mBottom, gc2);
			
			gc2.gridx ++;
			gc2.gridy = 1;
			mRight = new JSpinner(new SpinnerNumberModel(16, 2, 24, 1));
      		mRight.addChangeListener(updateAction);
			p2.add(mRight, gc2);
			
			p1.add(p2, gc);
			
			add(p1);
		}
		
		void init(boolean always) {
			if(inited && !always) return;
			
			textText.update();
			textSelectedText.update();

    		mTop.setValue(new Integer(Theme.textInsets[Theme.style].top));
    		mLeft.setValue(new Integer(Theme.textInsets[Theme.style].left));
    		mBottom.setValue(new Integer(Theme.textInsets[Theme.style].bottom));
    		mRight.setValue(new Integer(Theme.textInsets[Theme.style].right));
    		
    		textBg.update();
    		textSelectedBg.update();
    		textDisabledBg.update();
    		textBorder.update();
    		textDark.update();
    		textLight.update();
    		textDisabledDark.update();
    		textDisabledLight.update();
    		textBorderDisabled.update();
					
			inited = true;
		}
		
		void updateTheme() {
			if(!inited || resistUpdate) return;

    		Theme.textInsets[Theme.style] = new Insets(
    			((Integer)mTop.getValue()).intValue(),
    			((Integer)mLeft.getValue()).intValue(),
    			((Integer)mBottom.getValue()).intValue(),
    			((Integer)mRight.getValue()).intValue());
		}
	}
	
	class ListCP extends JPanel {
		private boolean inited = false;
		
		ListCP() {
			setupUI();
		}
		
		private void setupUI() {
			setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
			JPanel p1 = new JPanel(new GridBagLayout());
			GridBagConstraints gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.WEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(2, 4, 0, 4);

			p1.add(new JLabel("Selected Background"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			listSelectedBg = new HSBField(Theme.listSelectedBgColor, true);
			p1.add(listSelectedBg, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Selected Foreground"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			listSelectedText = new BlackWhitePanel(Theme.listSelectedTextColor, true);
			p1.add(listSelectedText, gc);
			
			add(p1);
		}
		
		void init(boolean always) {
			if(inited && !always) return;
			
			listSelectedText.update();
			listSelectedBg.update();

			inited = true;
		}
		
		void updateTheme() {}
	}
	
	class MiscCP extends JPanel {
		private boolean inited = false;
		
		MiscCP() {
			setupUI();
		}
		
		private void setupUI() {
			setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
			JPanel p1 = new JPanel(new GridBagLayout());
			GridBagConstraints gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.WEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(2, 4, 0, 4);

			p1.add(new JLabel("TitledBorder Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			titledBorderColor = new HSBField(Theme.titledBorderColor, true);
			p1.add(titledBorderColor, gc);
			
			add(p1);
		}
		
		void init(boolean always) {
			if(inited && !always) return;
			
			titledBorderColor.update();

			inited = true;
		}
		
		void updateTheme() {}
	}
	
	class TipCP extends JPanel {
		private boolean inited = false;
		
		TipCP() {
			setupUI();
		}
		
		private void setupUI() {
			setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
			JPanel p1 = new JPanel(new GridBagLayout());
			GridBagConstraints gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.WEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(2, 4, 0, 4);

			p1.add(new JLabel("Background Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			tipBg = new HSBField(Theme.tipBgColor);
			p1.add(tipBg, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Border Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			tipBorder = new HSBField(Theme.tipBorderColor);
			p1.add(tipBorder, gc);
			
			add(p1);
		}
		
		void init(boolean always) {
			if(inited && !always) return;
			
			tipBg.update();
			tipBorder.update();

			inited = true;
		}
		
		void updateTheme() {}
	}
	
	class IconCP extends JPanel {
		private boolean inited = false;
		private JCheckBox colorizeFrameIcon, colorizeFileViewIcon,
			colorizeFileChooserIcon, colorizeOptionPaneIcon, colorizeTreeIcon;
		
		IconCP() {
			setupUI();
		}
		
		private void setupUI() {
			setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
			JPanel p1 = new JPanel(new GridBagLayout());
			GridBagConstraints gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(2, 2, 0, 12);

			p1.add(new JLabel("Frame Icon"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 2, 0, 12);
			frameIcon = new HSBField(Theme.frameIconColor, true);
			p1.add(frameIcon, gc);
			gc.gridy ++;
			colorizeFrameIcon = new JCheckBox("Colorize");
			colorizeFrameIcon.addActionListener(iconCheckAction);
			p1.add(colorizeFrameIcon, gc);
			
			gc.gridy = 1;
			gc.gridx = 1;
			gc.gridheight = 2;
			gc.insets = new Insets(1, 2, 0, 2);
			iconChecks[0] = new CheckedIcon(true);
			p1.add(iconChecks[0], gc);
			
			gc.gridy = 3;
			gc.gridx = 0;
			gc.gridheight = 1;
			gc.insets = new Insets(12, 2, 0, 12);
			p1.add(new JLabel("Tree Icon"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 2, 0, 12);
			treeIcon = new HSBField(Theme.treeIconColor, true);
			p1.add(treeIcon, gc);
			gc.gridy ++;
			colorizeTreeIcon = new JCheckBox("Colorize");
			colorizeTreeIcon.addActionListener(iconCheckAction);
			p1.add(colorizeTreeIcon, gc);
			
			gc.gridy = 4;
			gc.gridx = 1;
			gc.gridheight = 2;
			gc.insets = new Insets(1, 2, 0, 2);
			JPanel p4 = new JPanel(new GridLayout(1, 5, 8, 0));
			for(int i = 1; i < 3; i++) {
				iconChecks[i] = new CheckedIcon(true);
				p4.add(iconChecks[i]);
			}
			p1.add(p4, gc);
			
			
			JPanel p2 = new JPanel(new BorderLayout(12, 0));
			JPanel p3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 2));
			p3.add(p1);
			p2.add(p3, BorderLayout.WEST);
			
			p1 = new JPanel(new GridBagLayout());
			gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(2, 2, 0, 12);
			
			p1.add(new JLabel("FileView Icon"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 2, 0, 12);
			fileViewIcon = new HSBField(Theme.fileViewIconColor, true);
			p1.add(fileViewIcon, gc);
			gc.gridy ++;
			colorizeFileViewIcon = new JCheckBox("Colorize");
			colorizeFileViewIcon.addActionListener(iconCheckAction);
			p1.add(colorizeFileViewIcon, gc);
			
			gc.gridy = 1;
			gc.gridx = 1;
			gc.gridheight = 2;
			gc.fill = GridBagConstraints.NONE;
			gc.insets = new Insets(1, 2, 0, 2);
			p4 = new JPanel(new GridLayout(1, 6, 8, 0));
			for(int i = 3; i < 8; i++) {
				iconChecks[i] = new CheckedIcon(true);
				p4.add(iconChecks[i]);
			}
			p1.add(p4, gc);
			
			gc.gridy = 3;
			gc.gridx = 0;
			gc.gridheight = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.insets = new Insets(12, 2, 0, 12);
			p1.add(new JLabel("FileChooser Icon"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 2, 0, 12);
			fileChooserIcon = new HSBField(Theme.fileChooserIconColor, true);
			p1.add(fileChooserIcon, gc);
			gc.gridy ++;
			colorizeFileChooserIcon = new JCheckBox("Colorize");
			colorizeFileChooserIcon.addActionListener(iconCheckAction);
			p1.add(colorizeFileChooserIcon, gc);
			
			gc.gridy = 4;
			gc.gridx = 1;
			gc.gridheight = 2;
			gc.insets = new Insets(1, 2, 0, 2);
			p4 = new JPanel(new GridLayout(1, 4, 8, 0));
			for(int i = 8; i < 13; i++) {
				iconChecks[i] = new CheckedIcon(true);
				p4.add(iconChecks[i]);
			}
			p1.add(p4, gc);
			
			p3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 2));
			p3.add(p1);
			p2.add(p3, BorderLayout.CENTER);
			
			p1 = new JPanel(new GridBagLayout());
			gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(2, 2, 0, 12);
			
			p1.add(new JLabel("OptionPane Icon"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 2, 0, 12);
			optionPaneIcon = new HSBField(Theme.optionPaneIconColor, true);
			p1.add(optionPaneIcon, gc);
			gc.gridy ++;
			colorizeOptionPaneIcon = new JCheckBox("Colorize");
			colorizeOptionPaneIcon.addActionListener(iconCheckAction);
			p1.add(colorizeOptionPaneIcon, gc);
			
			gc.gridy = 1;
			gc.gridx = 1;
			gc.gridheight = 2;
			gc.insets = new Insets(1, 2, 0, 2);
			p4 = new JPanel(new GridLayout(1, 4, 8, 0));
			for(int i = 13; i < 17; i++) {
				iconChecks[i] = new CheckedIcon(true);
				p4.add(iconChecks[i]);
			}
			p1.add(p4, gc);
			
			p3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 2));
			p3.add(p1);
			p2.add(p3, BorderLayout.EAST);
			
			add(p2);
		}
		
		void init(boolean always) {
			if(inited && !always) return;

			colorizeFrameIcon.setSelected(Theme.colorizeFrameIcon[Theme.style]);
			colorizeTreeIcon.setSelected(Theme.colorizeTreeIcon[Theme.style]);
			colorizeFileViewIcon.setSelected(Theme.colorizeFileViewIcon[Theme.style]);
			colorizeFileChooserIcon.setSelected(Theme.colorizeFileChooserIcon[Theme.style]);
			colorizeOptionPaneIcon.setSelected(Theme.colorizeOptionPaneIcon[Theme.style]);

			iconChecks[0].setIcon(UIManager.getIcon("InternalFrame.icon"));
			
			iconChecks[1].setIcon(UIManager.getIcon("Tree.closedIcon"));
			iconChecks[2].setIcon(UIManager.getIcon("Tree.openIcon"));
			
			iconChecks[3].setIcon(UIManager.getIcon("FileView.computerIcon"));
			iconChecks[4].setIcon(UIManager.getIcon("FileView.floppyDriveIcon"));
			iconChecks[5].setIcon(UIManager.getIcon("FileView.hardDriveIcon"));
			iconChecks[6].setIcon(UIManager.getIcon("FileView.directoryIcon"));
			iconChecks[7].setIcon(UIManager.getIcon("FileView.fileIcon"));
			
			iconChecks[8].setIcon(UIManager.getIcon("FileChooser.upFolderIcon"));
			iconChecks[9].setIcon(UIManager.getIcon("FileChooser.homeFolderIcon"));
			iconChecks[10].setIcon(UIManager.getIcon("FileChooser.newFolderIcon"));
			iconChecks[11].setIcon(UIManager.getIcon("FileChooser.listViewIcon"));
			iconChecks[12].setIcon(UIManager.getIcon("FileChooser.detailsViewIcon"));
			
			iconChecks[13].setIcon(UIManager.getIcon("OptionPane.informationIcon"));
			iconChecks[14].setIcon(UIManager.getIcon("OptionPane.questionIcon"));
			iconChecks[15].setIcon(UIManager.getIcon("OptionPane.warningIcon"));
			iconChecks[16].setIcon(UIManager.getIcon("OptionPane.errorIcon"));
			
			for(int i = 0; i < 17; i++) {
				iconChecks[i].setSelected(Theme.colorize[Theme.style][i]);
			}
			
			frameIcon.update();
			treeIcon.update();
			fileViewIcon.update();
			fileChooserIcon.update();
			optionPaneIcon.update();

			inited = true;
		}
		
		void updateTheme() {
			if(!inited || resistUpdate) return;

			Theme.colorizeFrameIcon[Theme.style] = colorizeFrameIcon.isSelected();
			Theme.colorizeTreeIcon[Theme.style] = colorizeTreeIcon.isSelected();
			Theme.colorizeFileViewIcon[Theme.style] = colorizeFileViewIcon.isSelected();
			Theme.colorizeFileChooserIcon[Theme.style] = colorizeFileChooserIcon.isSelected();
			Theme.colorizeOptionPaneIcon[Theme.style] = colorizeOptionPaneIcon.isSelected();
			
			for(int i = 0; i < 17; i++) {
				Theme.colorize[Theme.style][i] = iconChecks[i].isSelected();
			}
		}
	}
	
	class ProgressCP extends JPanel {
		private boolean inited = false;
		
		ProgressCP() {
			setupUI();
		}
		
		private void setupUI() {
			setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
			JPanel p1 = new JPanel(new GridBagLayout());
			//p1.setBorder(new EtchedBorder());
			GridBagConstraints gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.WEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(2, 4, 0, 4);

			p1.add(new JLabel("Track Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			progressTrack = new HSBField(Theme.progressTrackColor);
			p1.add(progressTrack, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Display Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			progressField = new HSBField(Theme.progressColor);
			p1.add(progressField, gc);
			
			// Border
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Border Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			progressBorder = new HSBField(Theme.progressBorderColor);
			p1.add(progressBorder, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Dark Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			progressDark = new HSBField(Theme.progressDarkColor);
			p1.add(progressDark, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Light Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			progressLight = new HSBField(Theme.progressLightColor);
			p1.add(progressLight, gc);
			
			// Text
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Text Forecolor"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			progressSelectFore = new HSBField(Theme.progressSelectForeColor);
			p1.add(progressSelectFore, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Text Backcolor"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			progressSelectBack = new HSBField(Theme.progressSelectBackColor);
			p1.add(progressSelectBack, gc);
			
			add(p1);
		}
		
		void init(boolean always) {
			if(inited && !always) return;
			
			progressField.update();
			progressTrack.update();
			progressBorder.update();
			progressDark.update();
			progressLight.update();
			progressSelectFore.update();
			progressSelectBack.update();

			inited = true;
		}
		
		void updateTheme() {}
	}
	
	class ComboCP extends JPanel {
		private JCheckBox paintFocus, rolloverEnabled;
		private JSpinner mTop, mLeft, mBottom, mRight;
		private boolean inited = false;
		
		ComboCP() {
			setupUI();
		}
		
		private void setupUI() {
			setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
			JPanel p1 = new JPanel(new GridBagLayout());
			GridBagConstraints gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.WEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(2, 4, 0, 4);

			// Background
			p1.add(new JLabel("Selected Background"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			comboSelectedBg = new HSBField(Theme.comboSelectedBgColor, true);
			p1.add(comboSelectedBg, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Selected Foreground"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			comboSelectedText = new BlackWhitePanel(Theme.comboSelectedTextColor, true);
			p1.add(comboSelectedText, gc);
			gc.gridy ++;
			
			// Insets
			gc.insets = new Insets(8, 4, 0, 4);
			gc.gridheight = 4;
			JPanel p2 = new JPanel(new GridBagLayout());
			GridBagConstraints gc2 = new GridBagConstraints();
			gc2.anchor = GridBagConstraints.WEST;
			gc2.fill = GridBagConstraints.HORIZONTAL;
			gc2.gridx = 0;
			gc2.gridy = 1;
			gc2.insets = new Insets(0, 2, 0, 2);
			
			mLeft = new JSpinner(new SpinnerNumberModel(16, 2, 24, 1));
      		mLeft.addChangeListener(updateAction);
			p2.add(mLeft, gc2);
			
			gc2.gridx ++;
			gc2.gridy = 0;
			mTop = new JSpinner(new SpinnerNumberModel(2, 1, 8, 1));
      		mTop.addChangeListener(updateAction);
			p2.add(mTop, gc2);
			gc2.gridy ++;
			p2.add(new JLabel("Insets"), gc2);
			gc2.gridy ++;
			mBottom = new JSpinner(new SpinnerNumberModel(3, 1, 8, 1));
      		mBottom.addChangeListener(updateAction);
			p2.add(mBottom, gc2);
			
			gc2.gridx ++;
			gc2.gridy = 1;
			mRight = new JSpinner(new SpinnerNumberModel(16, 2, 24, 1));
      		mRight.addChangeListener(updateAction);
			p2.add(mRight, gc2);
			
			p1.add(p2, gc);
			
			// Border
			gc.gridx ++;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Border Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			comboBorder = new HSBField(Theme.comboBorderColor);
			p1.add(comboBorder, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Border Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			comboDark = new HSBField(Theme.comboDarkColor);
			p1.add(comboDark, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Border Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			comboLight = new HSBField(Theme.comboLightColor);
			p1.add(comboLight, gc);

			// Border Disabled
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Disabled Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			comboBorderDisabled = new HSBField(Theme.comboBorderDisabledColor);
			p1.add(comboBorderDisabled, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			comboDisabledDark = new HSBField(Theme.comboDarkDisabledColor);
			p1.add(comboDisabledDark, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			comboDisabledLight = new HSBField(Theme.comboLightDisabledColor);
			p1.add(comboDisabledLight, gc);
			
			// Button
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Button Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			comboButt = new HSBField(Theme.comboButtColor);
			p1.add(comboButt, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Rollover Col"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			comboButtRollover = new HSBField(Theme.comboButtRolloverColor);
			p1.add(comboButtRollover, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Presssed Col"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			comboButtPressed = new HSBField(Theme.comboButtPressedColor);
			p1.add(comboButtPressed, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Col"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			comboButtDisabled = new HSBField(Theme.comboButtDisabledColor);
			p1.add(comboButtDisabled, gc);
			
			// Spread
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Spread Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			comboSpreadLight = new SpreadPanel(Theme.comboSpreadLight, 20);
			p1.add(comboSpreadLight, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Spread Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			comboSpreadDark = new SpreadPanel(Theme.comboSpreadDark, 20);
			p1.add(comboSpreadDark, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled S. Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			comboSpreadLightDisabled = new SpreadPanel(Theme.comboSpreadLightDisabled, 20);
			p1.add(comboSpreadLightDisabled, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled S. Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			comboSpreadDarkDisabled = new SpreadPanel(Theme.comboSpreadDarkDisabled, 20);
			p1.add(comboSpreadDarkDisabled, gc);
			
			// Button Border
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Border Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			comboButtBorder = new HSBField(Theme.comboButtBorderColor);
			p1.add(comboButtBorder, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Border Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			comboButtDark = new HSBField(Theme.comboButtDarkColor);
			p1.add(comboButtDark, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Border Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			comboButtLight = new HSBField(Theme.comboButtLightColor);
			p1.add(comboButtLight, gc);			
			
			// Border disabled
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Disabled Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			comboButtBorderDisabled = new HSBField(Theme.comboButtBorderDisabledColor);
			p1.add(comboButtBorderDisabled, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			comboButtDarkDisabled = new HSBField(Theme.comboButtDarkDisabledColor);
			p1.add(comboButtDarkDisabled, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			comboButtLightDisabled = new HSBField(Theme.comboButtLightDisabledColor);
			p1.add(comboButtLightDisabled, gc);

			// Arrow
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Arrow Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			comboArrowField = new HSBField(Theme.comboArrowColor);
			p1.add(comboArrowField, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Arrow"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			comboArrowDisabled = new HSBField(Theme.comboArrowDisabledColor);
			p1.add(comboArrowDisabled, gc);
			gc.gridy ++;
			
			// Flags
			gc.insets = new Insets(4, 8, 0, 4);
			gc.gridheight = 4;
			p2 = new JPanel(new GridLayout(2, 1, 0, 2));
			rolloverEnabled = new JCheckBox("Paint Rollover", true);
			rolloverEnabled.addActionListener(checkAction);
			p2.add(rolloverEnabled);
			paintFocus = new JCheckBox("Paint Focus");
			paintFocus.addActionListener(checkAction);
			p2.add(paintFocus);
			
			p1.add(p2, gc);
			
			add(p1);
		}
		
		void init(boolean always) {
			if(inited && !always) return;

			rolloverEnabled.setSelected(Theme.comboRollover[Theme.style]);
			paintFocus.setSelected(Theme.comboFocus[Theme.style]);
    		
    		comboSelectedText.update();
    		comboArrowField.update();
    		comboSelectedBg.update();
    		comboBorder.update();
    		comboDark.update();
    		comboLight.update();
    		comboBorderDisabled.update();
    		comboDisabledDark.update();
    		comboDisabledLight.update();
    		comboButt.update();
    		comboButtRollover.update();
    		comboButtDisabled.update();
    		comboButtPressed.update();
    		comboButtBorder.update();
    		comboButtDark.update();
    		comboButtLight.update();
    		comboButtBorderDisabled.update();
    		comboButtDarkDisabled.update();
    		comboButtLightDisabled.update();
    		comboArrowField.update();
    		comboArrowDisabled.update();
    		comboSpreadDark.init();
			comboSpreadLight.init();
			comboSpreadDarkDisabled.init();
			comboSpreadLightDisabled.init();
    		
    		mTop.setValue(new Integer(Theme.comboInsets[Theme.style].top));
    		mLeft.setValue(new Integer(Theme.comboInsets[Theme.style].left));
    		mBottom.setValue(new Integer(Theme.comboInsets[Theme.style].bottom));
    		mRight.setValue(new Integer(Theme.comboInsets[Theme.style].right));

			inited = true;
		}
		
		void updateTheme() {
			if(!inited || resistUpdate) return;

			Theme.comboRollover[Theme.style] = rolloverEnabled.isSelected();
			Theme.comboFocus[Theme.style] = paintFocus.isSelected();
    		 
    		Theme.comboInsets[Theme.style] = new Insets(
    			((Integer)mTop.getValue()).intValue(),
    			((Integer)mLeft.getValue()).intValue(),
    			((Integer)mBottom.getValue()).intValue(),
    			((Integer)mRight.getValue()).intValue());
		}
	}
	
	class ButtonsCP  extends JPanel {
		
		private JCheckBox rolloverEnabled, focusEnabled;
		private JSpinner mTop, mLeft, mBottom, mRight;
		private boolean inited = false;
		
		ButtonsCP() {
			setupUI();
		}
		
		private void setupUI() {
			setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
			JPanel p1 = new JPanel(new GridBagLayout());
			GridBagConstraints gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(2, 4, 0, 4);

			p1.add(new JLabel("Normal Bg"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			buttonNormalBg = new HSBField(Theme.buttonNormalColor);
			p1.add(buttonNormalBg, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Rollover Bg"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			buttonRolloverBg = new HSBField(Theme.buttonRolloverBgColor);
			p1.add(buttonRolloverBg, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Presssed Bg"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			buttonPressedBg = new HSBField(Theme.buttonPressedColor);
			p1.add(buttonPressedBg, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Disabled Bg"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			buttonDisabledBg = new HSBField(Theme.buttonDisabledColor);
			p1.add(buttonDisabledBg, gc);
			
			// Spread
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Spread Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			buttonSpreadLight = new SpreadPanel(Theme.buttonSpreadLight, 20);
			p1.add(buttonSpreadLight, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Spread Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			buttonSpreadDark = new SpreadPanel(Theme.buttonSpreadDark, 20);
			p1.add(buttonSpreadDark, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled S. Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			buttonSpreadLightDisabled = new SpreadPanel(Theme.buttonSpreadLightDisabled, 20);
			p1.add(buttonSpreadLightDisabled, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled S. Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			buttonSpreadDarkDisabled = new SpreadPanel(Theme.buttonSpreadDarkDisabled, 20);
			p1.add(buttonSpreadDarkDisabled, gc);
			
			// border
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Border Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			buttonBorder = new HSBField(Theme.buttonBorderColor);
			p1.add(buttonBorder, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Dark Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			buttonDark = new HSBField(Theme.buttonDarkColor);
			p1.add(buttonDark, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Light Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			buttonLight = new HSBField(Theme.buttonLightColor);
			p1.add(buttonLight, gc);			

			// disabled border
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Disabled Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			buttonDisabledBorder = new HSBField(Theme.buttonBorderDisabledColor);
			p1.add(buttonDisabledBorder, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			buttonDisabledDark = new HSBField(Theme.buttonDarkDisabledColor);
			p1.add(buttonDisabledDark, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			buttonDisabledLight = new HSBField(Theme.buttonLightDisabledColor);
			p1.add(buttonDisabledLight, gc);
			
			// disabled foreground
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Button Disabled Text"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			buttonDisabledFg = new HSBField(Theme.buttonDisabledFgColor, true);
			p1.add(buttonDisabledFg, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("CheckBox  Disabled T."), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			checkDisabledFg = new HSBField(Theme.checkDisabledFgColor, true);
			p1.add(checkDisabledFg, gc);
			
			gc.gridy ++;
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("RadioButton  Disabled T."), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			radioDisabledFg = new HSBField(Theme.radioDisabledFgColor, true);
			p1.add(radioDisabledFg, gc);
			
			// default/rollover
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Default Button Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			buttonDefault = new HSBField(Theme.buttonDefaultColor, true);
			p1.add(buttonDefault, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Rollover Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			buttonRollover = new HSBField(Theme.buttonRolloverColor);
			p1.add(buttonRollover, gc);
			
			// Flags
			gc.gridy = 5;
			gc.gridheight = 2;
			gc.insets = new Insets(0, 8, 0, 4);
			rolloverEnabled = new JCheckBox("Paint Rollover", true);
			rolloverEnabled.addActionListener(checkAction);
			p1.add(rolloverEnabled, gc);

			// checkmark
			gc.gridx ++;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Checkmark Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			buttonCheck = new HSBField(Theme.buttonCheckColor);
			p1.add(buttonCheck, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Check Disabled"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			buttonCheckDisabled = new HSBField(Theme.buttonCheckDisabledColor);
			p1.add(buttonCheckDisabled, gc);
			
			gc.gridy = 5;
			gc.gridheight = 2;	
			gc.insets = new Insets(0, 8, 0, 4);
			focusEnabled = new JCheckBox("Paint Focus", true);
			focusEnabled.addActionListener(checkAction);
			p1.add(focusEnabled, gc);

			// Margin
			gc.gridx ++;
			gc.gridy = 1;
			gc.gridheight = 7;
			gc.insets = new Insets(0, 16, 0, 4);
			
			JPanel p2 = new JPanel(new GridBagLayout());
			GridBagConstraints gc2 = new GridBagConstraints();
			gc2.anchor = GridBagConstraints.NORTHWEST;
			gc2.fill = GridBagConstraints.HORIZONTAL;
			gc2.gridx = 0;
			gc2.gridy = 1;
			gc2.insets = new Insets(0, 2, 0, 2);
			
			mLeft = new JSpinner(new SpinnerNumberModel(16, 2, 24, 1));
      		mLeft.addChangeListener(updateAction);
			p2.add(mLeft, gc2);
			
			gc2.gridx ++;
			gc2.gridy = 0;
			mTop = new JSpinner(new SpinnerNumberModel(2, 1, 8, 1));
      		mTop.addChangeListener(updateAction);
			p2.add(mTop, gc2);
			gc2.gridy ++;
			p2.add(new JLabel("Margin"), gc2);
			gc2.gridy ++;
			mBottom = new JSpinner(new SpinnerNumberModel(3, 1, 8, 1));
      		mBottom.addChangeListener(updateAction);
			p2.add(mBottom, gc2);
			
			gc2.gridx ++;
			gc2.gridy = 1;
			mRight = new JSpinner(new SpinnerNumberModel(16, 2, 24, 1));
      		mRight.addChangeListener(updateAction);
			p2.add(mRight, gc2);
			
			p1.add(p2, gc);
	
			add(p1);
		}
		
		void init(boolean always) {
			if(inited && !always) return;
			
			rolloverEnabled.setSelected(Theme.buttonRollover[Theme.style]);
			focusEnabled.setSelected(Theme.buttonFocus[Theme.style]);

			buttonNormalBg.update();
			buttonRolloverBg.update();
			buttonPressedBg.update();
			buttonDisabledBg.update();
			buttonBorder.update();
			buttonDark.update();
			buttonLight.update();
			buttonDisabledBorder.update();
			buttonDisabledDark.update();
			buttonDisabledLight.update();
			buttonDisabledFg.update();
			checkDisabledFg.update();
			radioDisabledFg.update();
			buttonRollover.update();
			buttonDefault.update();
			buttonCheck.update();
			buttonCheckDisabled.update();
			buttonSpreadDark.init();
			buttonSpreadLight.init();
			buttonSpreadDarkDisabled.init();
			buttonSpreadLightDisabled.init();

    		mTop.setValue(new Integer(Theme.buttonMarginTop[Theme.style]));
    		mLeft.setValue(new Integer(Theme.buttonMarginLeft[Theme.style]));
    		mBottom.setValue(new Integer(Theme.buttonMarginBottom[Theme.style]));
    		mRight.setValue(new Integer(Theme.buttonMarginRight[Theme.style]));
					
			inited = true;
		}
		
		InsetsUIResource getButtonMargin() {
			return new InsetsUIResource(
				((Integer)mTop.getValue()).intValue(),
				((Integer)mLeft.getValue()).intValue(),
				((Integer)mBottom.getValue()).intValue(),
				((Integer)mRight.getValue()).intValue());
		}
		
		void updateTheme() {
			if(!inited || resistUpdate) return;
			
			Theme.buttonRollover[Theme.style] = rolloverEnabled.isSelected();
			Theme.buttonFocus[Theme.style] = focusEnabled.isSelected();

    		Theme.buttonMarginTop[Theme.style] = ((Integer)mTop.getValue()).intValue();
    		Theme.buttonMarginLeft[Theme.style] = ((Integer)mLeft.getValue()).intValue();
    		Theme.buttonMarginBottom[Theme.style] = ((Integer)mBottom.getValue()).intValue();
    		Theme.buttonMarginRight[Theme.style] = ((Integer)mRight.getValue()).intValue();
		}
	}

	class FrameCP extends JPanel {

		private boolean inited = false;
		private CardLayout cardLayout;
		private JPanel cardPanel;
		
		FrameCP() {
			cardLayout = new CardLayout();

			setupUI();
		}
		
		private void setupUI() {
			setLayout(new BorderLayout());
			// Radios
			JPanel p1 = new JPanel(new GridLayout(5, 1, 0, 0));
			JPanel p2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 24, 8));
			ButtonGroup group = new ButtonGroup();
			JRadioButton radio = new JRadioButton("Frame", true);
			group.add(radio);
			radio.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					cardLayout.show(cardPanel, "Frame");
				}
			});
			p1.add(radio);
			radio = new JRadioButton("Iconify/Maximize Buttons");
			group.add(radio);
			radio.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					cardLayout.show(cardPanel, "FrameButtons");
				}
			});
			p1.add(radio);
			radio = new JRadioButton("Close Button");
			group.add(radio);
			radio.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					cardLayout.show(cardPanel, "FrameCloseButton");
				}
			});
			p1.add(radio);
			
			p1.add(new JLabel(""));
			
			JButton b = new JButton("Activate/Deactivate Frame");
			b.addActionListener(new DeactivateInternalFrameAction());
			p1.add(b);
			
			p2.add(p1);
			add(p2, BorderLayout.CENTER);
			
			// CardPanel
			cardPanel = new JPanel(cardLayout);
			cardPanel.add(new FrameFrameCP(), "Frame");
			cardPanel.add(new FrameButtonsCP(), "FrameButtons");
			cardPanel.add(new FrameCloseButtonCP(), "FrameCloseButton");
			cardLayout.layoutContainer(this);
			
			add(cardPanel, BorderLayout.WEST);
		}
		
		void init(boolean always) {
			if(inited && !always) return;

    		frameCaption.update();
    		frameCaptionDisabled.update();
    		frameBorder.update();
    		frameDark.update();
    		frameLight.update();
    		frameBorderDisabled.update();
    		frameDarkDisabled.update();
    		frameLightDisabled.update();
    		frameTitle.update();
    		frameTitleDisabled.update();
    		frameButt.update();
    		frameButtRollover.update();
    		frameButtPressed.update();
    		frameButtDisabled.update();
    		frameButtBorder.update();
    		frameButtDark.update();
    		frameButtLight.update();
    		frameButtBorderDisabled.update();
    		frameButtDarkDisabled.update();
    		frameButtLightDisabled.update();
    		frameButtSpreadDark.init();
			frameButtSpreadLight.init();
			frameButtSpreadDarkDisabled.init();
			frameButtSpreadLightDisabled.init();
    		frameButtClose.update();
    		frameButtCloseRollover.update();
    		frameButtClosePressed.update();
    		frameButtCloseDisabled.update();
    		frameButtCloseBorder.update();
    		frameButtCloseDark.update();
    		frameButtCloseLight.update();
    		frameButtCloseBorderDisabled.update();
    		frameButtCloseDarkDisabled.update();
    		frameButtCloseLightDisabled.update();
    		frameButtCloseSpreadDark.init();
			frameButtCloseSpreadLight.init();
			frameButtCloseSpreadDarkDisabled.init();
			frameButtCloseSpreadLightDisabled.init();
    		frameSymbol.update();
    		frameSymbolPressed.update();
    		frameSymbolDisabled.update();
    		frameSymbolDark.update();
    		frameSymbolLight.update();
    		frameSymbolClose.update();
    		frameSymbolClosePressed.update();
    		frameSymbolCloseDisabled.update();
    		frameSymbolCloseDark.update();
    		frameSymbolCloseLight.update();
    		frameSpreadDark.init();
    		frameSpreadLight.init();
    		frameSpreadDarkDisabled.init();
    		frameSpreadLightDisabled.init();
    		
			inited = true;
		}
		
		void updateTheme() {}
		
		class DeactivateInternalFrameAction implements ActionListener {
			
			public void actionPerformed(ActionEvent e) {
				try {
					internalFrame.setSelected(!internalFrame.isSelected());
				} catch (PropertyVetoException ignore) {}
			}
		}
	}
	
	class FrameFrameCP extends JPanel {
		
		FrameFrameCP() {
			setupUI();
		}
		
		private void setupUI() {    		
    		setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
			JPanel p1 = new JPanel(new GridBagLayout());
			GridBagConstraints gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(2, 4, 0, 4);

			p1.add(new JLabel("Caption Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			frameCaption = new HSBField(Theme.frameCaptionColor);
			p1.add(frameCaption, gc);
			gc.gridy ++;

			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Disabled Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			frameCaptionDisabled = new HSBField(Theme.frameCaptionDisabledColor);
			p1.add(frameCaptionDisabled, gc);
			
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Spread Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameSpreadDark = new SpreadPanel(Theme.frameSpreadDark, 10);
			p1.add(frameSpreadDark, gc);			
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Spread Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameSpreadLight = new SpreadPanel(Theme.frameSpreadLight, 10);
			p1.add(frameSpreadLight, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("S. Dark Disabled"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameSpreadDarkDisabled = new SpreadPanel(Theme.frameSpreadDarkDisabled, 10);
			p1.add(frameSpreadDarkDisabled, gc);gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("S. Light Disabled"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameSpreadLightDisabled = new SpreadPanel(Theme.frameSpreadLightDisabled, 10);
			p1.add(frameSpreadLightDisabled, gc);
			
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Border Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameBorder = new HSBField(Theme.frameBorderColor);
			p1.add(frameBorder, gc);
			gc.gridy ++;

			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Border Dark Col"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameDark = new HSBField(Theme.frameDarkColor);
			p1.add(frameDark, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Border Light Col"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameLight = new HSBField(Theme.frameLightColor);
			p1.add(frameLight, gc);
			gc.gridy += 2;
			
			gc.gridwidth = 3;
			gc.insets = new Insets(0, 8, 0, 4);
			JCheckBox check = new JCheckBox(
				"Decorated Frames (experimental, not saved)", Theme.frameIsDecorated[Theme.style]);
			check.addActionListener(new DecorateFrameAction());
			p1.add(check, gc);

			gc.gridx ++;
			gc.gridy = 0;
			gc.gridwidth = 1;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Disabled Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameBorderDisabled = new HSBField(Theme.frameBorderDisabledColor);
			p1.add(frameBorderDisabled, gc);
			gc.gridy ++;

			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Dark Col"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameDarkDisabled = new HSBField(Theme.frameDarkDisabledColor);
			p1.add(frameDarkDisabled, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Light Col"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameLightDisabled = new HSBField(Theme.frameLightDisabledColor);
			p1.add(frameLightDisabled, gc);
			
			gc.gridx ++;
			gc.gridy = 0;
			gc.gridwidth = 1;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Title Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameTitle = new HSBField(Theme.frameTitleColor);
			p1.add(frameTitle, gc);
			gc.gridy ++;

			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Title Disabled"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameTitleDisabled = new HSBField(Theme.frameTitleDisabledColor);
			p1.add(frameTitleDisabled, gc);
			
			add(p1);
		}
	}
	
	class FrameButtonsCP extends JPanel {
		
		FrameButtonsCP() {
			setupUI();
		}
		
		private void setupUI() {
    		setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
			JPanel p1 = new JPanel(new GridBagLayout());
			GridBagConstraints gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(2, 4, 0, 4);

			p1.add(new JLabel("Button Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			frameButt = new HSBField(Theme.frameButtColor);
			p1.add(frameButt, gc);
			gc.gridy ++;

			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Rollover Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			frameButtRollover = new HSBField(Theme.frameButtRolloverColor);
			p1.add(frameButtRollover, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Pressed Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			frameButtPressed = new HSBField(Theme.frameButtPressedColor);
			p1.add(frameButtPressed, gc);			
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Disabled Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			frameButtDisabled = new HSBField(Theme.frameButtDisabledColor);
			p1.add(frameButtDisabled, gc);

			// Spread
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Spread Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameButtSpreadLight = new SpreadPanel(Theme.frameButtSpreadLight, 20);
			p1.add(frameButtSpreadLight, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Spread Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameButtSpreadDark = new SpreadPanel(Theme.frameButtSpreadDark, 20);
			p1.add(frameButtSpreadDark, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled S. Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameButtSpreadLightDisabled = new SpreadPanel(Theme.frameButtSpreadLightDisabled, 20);
			p1.add(frameButtSpreadLightDisabled, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled S. Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameButtSpreadDarkDisabled = new SpreadPanel(Theme.frameButtSpreadDarkDisabled, 20);
			p1.add(frameButtSpreadDarkDisabled, gc);
			
			// Border
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Border Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameButtBorder = new HSBField(Theme.frameButtBorderColor);
			p1.add(frameButtBorder, gc);
			gc.gridy ++;

			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Border Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameButtDark = new HSBField(Theme.frameButtDarkColor);
			p1.add(frameButtDark, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Border Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameButtLight = new HSBField(Theme.frameButtLightColor);
			p1.add(frameButtLight, gc);

			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Disabled Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameButtBorderDisabled = new HSBField(Theme.frameButtBorderDisabledColor);
			p1.add(frameButtBorderDisabled, gc);
			gc.gridy ++;

			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameButtDarkDisabled = new HSBField(Theme.frameButtDarkDisabledColor);
			p1.add(frameButtDarkDisabled, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameButtLightDisabled = new HSBField(Theme.frameButtLightDisabledColor);
			p1.add(frameButtLightDisabled, gc);
			
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Symbol Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameSymbol = new HSBField(Theme.frameSymbolColor);
			p1.add(frameSymbol, gc);
			gc.gridy ++;

			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Pressed Symbol"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameSymbolPressed = new HSBField(Theme.frameSymbolPressedColor);
			p1.add(frameSymbolPressed, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Symbol"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameSymbolDisabled = new HSBField(Theme.frameSymbolDisabledColor);
			p1.add(frameSymbolDisabled, gc);
			
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Symbol Dark Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameSymbolDark = new HSBField(Theme.frameSymbolDarkColor);
			p1.add(frameSymbolDark, gc);
			gc.gridy ++;

			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Symbol Light Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameSymbolLight = new HSBField(Theme.frameSymbolLightColor);
			p1.add(frameSymbolLight, gc);
			
			add(p1);
		}
	}
	
	class FrameCloseButtonCP extends JPanel {
		
		FrameCloseButtonCP() {
			setupUI();
		}
		
		private void setupUI() {
			setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
			JPanel p1 = new JPanel(new GridBagLayout());
			GridBagConstraints gc = new GridBagConstraints();
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(2, 4, 0, 4);

			p1.add(new JLabel("Button Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			frameButtClose = new HSBField(Theme.frameButtCloseColor);
			p1.add(frameButtClose, gc);
			gc.gridy ++;

			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Rollover Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			frameButtCloseRollover = new HSBField(Theme.frameButtCloseRolloverColor);
			p1.add(frameButtCloseRollover, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Pressed Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			frameButtClosePressed = new HSBField(Theme.frameButtClosePressedColor);
			p1.add(frameButtClosePressed, gc);			
			gc.gridy ++;
			
			gc.insets = new Insets(4, 4, 0, 4);
			p1.add(new JLabel("Disabled Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 4, 0, 4);
			frameButtCloseDisabled = new HSBField(Theme.frameButtCloseDisabledColor);
			p1.add(frameButtCloseDisabled, gc);

			// Spread
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Spread Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameButtCloseSpreadLight = new SpreadPanel(Theme.frameButtCloseSpreadLight, 20);
			p1.add(frameButtCloseSpreadLight, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Spread Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameButtCloseSpreadDark = new SpreadPanel(Theme.frameButtCloseSpreadDark, 20);
			p1.add(frameButtCloseSpreadDark, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled S. Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameButtCloseSpreadLightDisabled = new SpreadPanel(Theme.frameButtCloseSpreadLightDisabled, 20);
			p1.add(frameButtCloseSpreadLightDisabled, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled S. Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameButtCloseSpreadDarkDisabled = new SpreadPanel(Theme.frameButtCloseSpreadDarkDisabled, 20);
			p1.add(frameButtCloseSpreadDarkDisabled, gc);
			
			// Border
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Border Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameButtCloseBorder = new HSBField(Theme.frameButtCloseBorderColor);
			p1.add(frameButtCloseBorder, gc);
			gc.gridy ++;

			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Border Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameButtCloseDark = new HSBField(Theme.frameButtCloseDarkColor);
			p1.add(frameButtCloseDark, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Border Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameButtCloseLight = new HSBField(Theme.frameButtCloseLightColor);
			p1.add(frameButtCloseLight, gc);

			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Disabled Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameButtCloseBorderDisabled = new HSBField(Theme.frameButtCloseBorderDisabledColor);
			p1.add(frameButtCloseBorderDisabled, gc);
			gc.gridy ++;

			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Dark"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameButtCloseDarkDisabled = new HSBField(Theme.frameButtCloseDarkDisabledColor);
			p1.add(frameButtCloseDarkDisabled, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Light"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameButtCloseLightDisabled = new HSBField(Theme.frameButtCloseLightDisabledColor);
			p1.add(frameButtCloseLightDisabled, gc);
			
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Symbol Color"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameSymbolClose = new HSBField(Theme.frameSymbolCloseColor);
			p1.add(frameSymbolClose, gc);
			gc.gridy ++;

			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Pressed Symbol"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameSymbolClosePressed = new HSBField(Theme.frameSymbolClosePressedColor);
			p1.add(frameSymbolClosePressed, gc);
			gc.gridy ++;
			
			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Disabled Symbol"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameSymbolCloseDisabled = new HSBField(Theme.frameSymbolCloseDisabledColor);
			p1.add(frameSymbolCloseDisabled, gc);
			
			gc.gridx ++;
			gc.gridy = 0;
			gc.insets = new Insets(2, 8, 0, 4);
			p1.add(new JLabel("Symbol Dark Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameSymbolCloseDark = new HSBField(Theme.frameSymbolCloseDarkColor);
			p1.add(frameSymbolCloseDark, gc);
			gc.gridy ++;

			gc.insets = new Insets(4, 8, 0, 4);
			p1.add(new JLabel("Symbol Light Border"), gc);
			gc.gridy ++;
			gc.insets = new Insets(1, 8, 0, 4);
			frameSymbolCloseLight = new HSBField(Theme.frameSymbolCloseLightColor);
			p1.add(frameSymbolCloseLight, gc);
			
			add(p1);
		}
	}
	
	class BlackWhitePanel extends JPanel {
		
		private boolean forceUpdate;
		private Dimension size = new Dimension(18, 18);
		private Font font = new Font("sansserif", Font.BOLD, 11);
		private String text = "Item text";
		private ColorReference[] ref;
		
		BlackWhitePanel(ColorReference[] ref) {
			this.ref = ref;
			setBorder(new LineBorder(Color.BLACK, 1));
			setBackground(ref[Theme.style].getColor());
			switchColors();
			addMouseListener(new Mousey());
		}
		
		BlackWhitePanel(ColorReference[] ref, boolean forceUpdate) {
			this.ref = ref;
			this.forceUpdate = forceUpdate;
			
			setBorder(new LineBorder(Color.BLACK, 1));
			setBackground(ref[Theme.style].getColor());
			switchColors();
			addMouseListener(new Mousey());
		}
		
		public Dimension getPreferredSize() {
			return size;
		}

		public void switchColors() {
			if(getBackground().equals(Color.BLACK)) {
				setBackground(Color.WHITE);
				ref[Theme.style].setColor(Color.BLACK);
			}
			else {
				setBackground(Color.BLACK);
				ref[Theme.style].setColor(Color.WHITE);
			}
		}
		
		public void setTextColor(Color c) {
			if(c.equals(Color.BLACK)) {
				setBackground(Color.WHITE);
			}
			else {
				setBackground(Color.BLACK);
			}
		}
		
		public void update() {
			if(ref[Theme.style].update().equals(Color.BLACK)) {
				setBackground(Color.WHITE);
			}
			else {
				setBackground(Color.BLACK);
			}
			repaint();
		}
		
		public void paint(Graphics g) {
			super.paint(g);
			
			if(getBackground().equals(Color.BLACK)) {
				g.setColor(Color.WHITE);
			}
			else {
				g.setColor(Color.BLACK);
			}

			g.setFont(font);
			
			int textWidth = g.getFontMetrics().stringWidth(text);
			
			int x = (getWidth() - textWidth) / 2;
			int y = getHeight() - 5;
			
			g.drawString(text, x, y);
		}
		
		class Mousey extends MouseAdapter {

			public void mousePressed(MouseEvent e) {
				switchColors();
				examplePanel.update(forceUpdate);
			}
		}
	}
	
	class SpreadPanel extends JPanel implements FocusListener {
		
		private int max = 20;
		private Dimension size = new Dimension(18, 18);
		private Font font = new Font("sansserif", Font.BOLD, 12);
		private int[] spreadRef;
		private boolean hasFocus = false;
		private int spread;
		private int x1 = 7, x2, paintX, y = 7;
		
		SpreadPanel(int[] spreadRef, int max) {
			this.spreadRef = spreadRef;
			this.max = max;
			
			addMouseListener(new Mousey());
			addMouseMotionListener(new MouseyMove());
			addKeyListener(new ArrowKeyAction());
			addFocusListener(this);
			init();
		}
		
		public void update(int spread) {
			this.spread = spread;
			spreadRef[Theme.style] = spread;
			repaint(0);
			
			if(internalFrame == null) return;
			
			internalFrame.repaint(0);
			examplePanel.repaint(0);
		}
		
		public void init() {
			paintX = -1;
			update(spreadRef[Theme.style]);
		}
		
		public Dimension getPreferredSize() {
			return size;
		}
		
		public void paint(Graphics g) {
			if(hasFocus) {
				g.setColor(Color.WHITE);
			}
			else {
				g.setColor(Theme.backColor[Theme.style].getColor());
			}
			g.fillRect(1, 1, getWidth() - 2, getHeight() - 2);
			
			g.setColor(Color.BLACK);
			g.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
			
			x2 = getWidth() - 24;
			// Track
			g.drawLine(x1, y - 3, x1, y + 3);
			g.drawLine(x2, y - 3, x2, y + 3);
			g.drawLine(x1, y, x2, y);
			
			// Thumb
			int x = paintX;
			if(x == -1) {
				x = spread * (x2 - x1) / max + x1;
			}
			g.drawLine(x, y + 2, x, y + 2);
			g.drawLine(x - 1, y + 3, x + 1, y + 3);
			g.drawLine(x - 2, y + 4, x + 2, y + 4);
			g.drawLine(x - 3, y + 5, x + 3, y + 5);
			g.drawLine(x - 4, y + 6, x + 4, y + 6);
			
			//Number
			g.setFont(font);
			FontMetrics fm = g.getFontMetrics();
			int xd = fm.stringWidth(String.valueOf(spread));
			g.drawString(String.valueOf(spread), getWidth() - xd - 3, getHeight() - 5);
		}

		public void focusGained(FocusEvent e) {
			hasFocus = true;
		}
		
		public void focusLost(FocusEvent e) {
			hasFocus = false;
			repaint(0);
		}
		
		class Mousey extends MouseAdapter {

			public void mousePressed(MouseEvent e) {
				if(SpreadPanel.this.equals(frameSpreadDark) ||
					SpreadPanel.this.equals(frameSpreadLight))
				{
					if(!internalFrame.isSelected()) {
						try {
							internalFrame.setSelected(true);
						} catch (PropertyVetoException ignore) {}
					}
				}
				else if(SpreadPanel.this.equals(frameSpreadDarkDisabled) ||
					SpreadPanel.this.equals(frameSpreadLightDisabled))
				{
					if(internalFrame.isSelected()) {
						try {
							internalFrame.setSelected(false);
						} catch (PropertyVetoException ignore) {}
					}
				}
				
				if(!hasFocus) {
					requestFocus();
					repaint(0);
				}
				else {
					int x = e.getX();
					if(x < x1) x = x1;
					if(x > x2) x = x2;
				
					int xd = (x - x1);
					paintX = x;
				
					update(xd * max / (x2 - x1));
				}
			}
			
			public void mouseReleased(MouseEvent e) {
				repaint(0);
				examplePanel.update(false);
			}
		}
		
		class MouseyMove extends MouseMotionAdapter {

			public void mouseDragged(MouseEvent e) {
				int x = e.getX();
				if(x < x1) x = x1;
				if(x > x2) x = x2;
				
				int xd = (x - x1);
				paintX = x;
				
				update(xd * max / (x2 - x1));
			}
		}
		
		class ArrowKeyAction extends KeyAdapter implements ActionListener {
		
		private javax.swing.Timer keyTimer;
		private int step;
		
		ArrowKeyAction() {
			keyTimer = new javax.swing.Timer(20, this);
		}
		
		public void keyPressed(KeyEvent e) {
			if(e.getKeyCode() == 38) {	// up => increase
				if(spread == max) return;
				
				step = 1;

				changeVal();
				keyTimer.setInitialDelay(300);
				keyTimer.start();
			}
			else if(e.getKeyCode() == 40) {	// up => decrease
				if(spread == 0) return;
				
				step = -1;

				changeVal();
				keyTimer.setInitialDelay(300);
				keyTimer.start();
			}
		}
		
		public void keyReleased(KeyEvent e) {
			keyTimer.stop();
		}
		
		// the keyTimer action
		public void actionPerformed(ActionEvent e) {
			changeVal();
		}
		
		private void changeVal() {
			if(spread + step < 0 || spread + step > max) return;
			
			spread += step;
			paintX = -1;
			update(spread);
		}
	}
	}
	
	class SizedPanel extends JPanel {
		
		private Dimension size;
		private Color grey = new Color(204, 204, 204);
		
		SizedPanel(int w, int h) {
			size = new Dimension(w, h);
			setBackground(Color.ORANGE);
		}
		
		public Dimension getPreferredSize() {
			return size;
		}
		
		public void paint(Graphics g) {
			
			int w = 8; int index = 0;
			int x = 0; int y = 0;		
			while(x < getWidth()) {
				y = 0;
				while(y < getHeight()) {
					if((index ++) % 2 == 0) {
						g.setColor(grey);
					}
					else {
						g.setColor(Color.WHITE);
					}
					g.fillRect(x, y, w, w);
					
					y += w;
				}
				
				x += w;
			}
		}
		
		public void update(Graphics g) {
			paint(g);
		}
	}
	
	class ProgressAction implements ActionListener {
		
		private int value = 0;
		
		public void actionPerformed(ActionEvent e) {			
			value ++;
			
			if(value > 20) {
				value = 0;
				horzProgressBar.setIndeterminate(!horzProgressBar.isIndeterminate());
				vertProgressBar.setIndeterminate(!vertProgressBar.isIndeterminate());
			}
			
			horzProgressBar.setValue(value);
			vertProgressBar.setValue(value);
			
			int v = value % 25;
			
			if(v < 8) {
				horzProgressBar.setString("Fun");
				vertProgressBar.setString("Fun");
			}
			else if(v < 16) {
				horzProgressBar.setString("with");
				vertProgressBar.setString("with");
			}
			else {
				horzProgressBar.setString("Swing");
				vertProgressBar.setString("Swing");
			}
		}
	}
	
	class ProgressBarAction extends MouseAdapter {

		public void mousePressed(MouseEvent e) {
			if(progressTimer.isRunning()) {
				stopProgressTimer();
			}
			else {
				startProgressTimer();
			}
		}
	}
	
	class SmallTableModel extends AbstractTableModel {
		
		private String[] colNames =
			{"Col1", "Col2", "Col3", "Col4"};
			
		private String[][] data =
			{{"E", "ne", "me", "ne"},
			{"mis", "te", "was", "rap"},
			{"pelt", "in", "der", "Kis"},
			{"te", ".", "E", "ne"},
			{"me", "ne", "meck", "und"},
			{"du", "bist", "weg", "."}};
			
		public int getColumnCount() {
			return colNames.length;
		}
		
		public int getRowCount() {
			return data.length;
		}
		
		public Object getValueAt(int row, int col) {
			return data[row][col];
		}

		public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
			data[rowIndex][columnIndex] = aValue.toString();
		}

		public String getColumnName(int col) {
			return colNames[col];
		}

		public boolean isCellEditable(int rowIndex, int columnIndex) {
			return false;
		}
	}
	
	class ThemeFileFilter extends javax.swing.filechooser.FileFilter {
		
		public boolean accept(File pathname) {
			if(pathname.isDirectory()) return true;
			if(pathname.getName().endsWith(Theme.FILE_EXTENSION)) return true;
			
			return false;
		}
		
		public String getDescription() {
			return Theme.FILE_EXTENSION;
		}
	}
	
	class SelectThemeAction implements ActionListener {

		public void actionPerformed(ActionEvent e) {				
			openTheme(((JMenuItem)e.getSource()).getText() + Theme.FILE_EXTENSION);
		}
	}
	
	class CheckedIcon extends JPanel {
		
		private JLabel iconLabel;
		private JCheckBox check;
		
		CheckedIcon(boolean b) {
			setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
			check = new JCheckBox("", b);
			check.addActionListener(iconCheckAction);
			add(check);
			iconLabel = new JLabel("");
			add(iconLabel);
		}
		
		public void setIcon(Icon i) {
			iconLabel.setIcon(i);
		}
		
		public void setSelected(boolean b) {
			check.setSelected(b);
		}
		
		public boolean isSelected() {
			return check.isSelected();
		}
	}
	
	class DecorateFrameAction implements ActionListener {

		public void actionPerformed(ActionEvent e) {				
			decorateFrame(((AbstractButton)e.getSource()).isSelected());
		}
	}
	
	class CheckAction implements ActionListener {

		public void actionPerformed(ActionEvent e) {				
			examplePanel.update(false);
		}
	}
	
	class UpdateAction implements ChangeListener {

		public void stateChanged(ChangeEvent e) {
			examplePanel.update(true);
		}
	}
	
	class IconCheckAction implements ActionListener {

		public void actionPerformed(ActionEvent e) {				
			examplePanel.update(true);
		}
	}
	
	class PopupTrigger extends JPanel implements MouseListener {
		
		PopupTrigger() {
			setLayout(new FlowLayout(FlowLayout.CENTER, 4, 2));
			setBackground(Color.ORANGE);
			JLabel l = new JLabel("Popup trigger");
			l.setForeground(Color.BLUE);
			add(l);
			addMouseListener(this);
		}

		// MouseListener implementation
		public void mousePressed(MouseEvent e) {
			if(thePopup != null && thePopup.isShowing()) return;
			
			thePopup = new JPopupMenu("Popup Menu");
			BasicPopupMenuUI ui = (BasicPopupMenuUI)thePopup.getUI();
			JMenuItem item = new JMenuItem("Popup item #1");
			thePopup.add(item);
			item = new JMenuItem("Popup item #2");
			thePopup.add(item);

			thePopup.addSeparator();
			
			item = new JMenuItem("Popup item #III");
			thePopup.add(item);
			item = new JMenuItem("Popup disabled item #IV");
			item.setEnabled(false);
			thePopup.add(item);
			
			thePopup.show(e.getComponent(), 0, -thePopup.getPreferredSize().height - 1);
		}
		
		public void mouseClicked(MouseEvent e) {}
		public void mouseReleased(MouseEvent e) {}
		public void mouseEntered(MouseEvent e) {}
		public void mouseExited(MouseEvent e) {}
	}
	
	class GoodFrame extends JFrame {
		
		private boolean resized = false;
		
		GoodFrame(String title) {
			super(title);
			addComponentListener(new ResizeListener());
		}
		
		protected JRootPane createRootPane() {
			return new GoodRootPane();
		}
		
		public void paint(Graphics g) {
			if(resized) {
				System.out.println("Frame.paint() " + System.currentTimeMillis());
				resized = false;
			}
			
			super.paint(g);
		}
		
		public void invalidate() {
			if(resized) {
				System.out.println("Frame.invalidate() " + System.currentTimeMillis());
			}
			
			super.invalidate();
		}
		
		public void validate() {
			if(resized) {
				System.out.println("Frame.validate() " + System.currentTimeMillis());
			}
			
			super.validate();
		}
		
		public void setBounds(int x, int y, int w, int h) {
			System.out.println("Frame.setBounds() " + System.currentTimeMillis());
			super.setBounds(x, y, w, h);
		}
		
		public void setBounds(Rectangle r) {
			System.out.println("Frame.setBounds() " + System.currentTimeMillis());
			super.setBounds(r);
		}
		
		public void setSize(Dimension d) {
			System.out.println("Frame.setSize() " + System.currentTimeMillis());
			super.setSize(d);
		}
		
		public void setSize(int w, int h) {
			System.out.println("Frame.setSize() " + System.currentTimeMillis());
			super.setSize(w, h);
		}
		
		class ResizeListener extends ComponentAdapter {

			public void componentResized(ComponentEvent e) {
				System.out.println("Frame.Event " + System.currentTimeMillis());
				resized = true;
			}
		}
	}
	
	class GoodLayeredPane extends JLayeredPane {
		
		private boolean resized = false;
		
		GoodLayeredPane() {
			super();
			addComponentListener(new ResizeListener());
		}
		
		public void paint(Graphics g) {
			if(resized) {
				System.out.println("LayeredPane.paint() " + System.currentTimeMillis());
				resized = false;
			}
			
			super.paint(g);
		}
		
		public void setBounds(int x, int y, int w, int h) {
			System.out.println("LayeredPane.setBounds() " + System.currentTimeMillis());
			super.setBounds(x, y, w, h);
		}
		
		public void setBounds(Rectangle r) {
			System.out.println("LayeredPane.setBounds() " + System.currentTimeMillis());
			super.setBounds(r);
		}
		
		public void setSize(Dimension d) {
			System.out.println("LayeredPane.setSize() " + System.currentTimeMillis());
			super.setSize(d);
		}
		
		public void setSize(int w, int h) {
			System.out.println("LayeredPane.setSize() " + System.currentTimeMillis());
			super.setSize(w, h);
		}
		
		public void invalidate() {
			if(resized) {
				System.out.println("LayeredPane.invalidate() " + System.currentTimeMillis());
			}
			
			super.invalidate();
		}
		
		public void validate() {
			if(resized) {
				System.out.println("LayeredPane.validate() " + System.currentTimeMillis());
			}
			
			super.validate();
		}
		
		class ResizeListener extends ComponentAdapter {

			public void componentResized(ComponentEvent e) {
				System.out.println("LayeredPane.Event " + System.currentTimeMillis());
				resized = true;
			}
		}
	}
	
	class GoodRootPane extends JRootPane {
		
		private boolean resized = false;
		
		GoodRootPane() {
			super();
			addComponentListener(new ResizeListener());
		}
		
		protected JLayeredPane createLayeredPane() {
        	JLayeredPane p = new GoodLayeredPane();
        	p.setName(this.getName()+".layeredPane");
        	return p;
    	}

		
		public void paint(Graphics g) {
			if(resized) {
				System.out.println("RootPane.paint() " + System.currentTimeMillis());
				resized = false;
				System.out.println(getUI().getClass().getName());
			}
			
			super.paint(g);
		}
		
		public void setBounds(int x, int y, int w, int h) {
			System.out.println("RootPane.setBounds() " + System.currentTimeMillis());
			super.setBounds(x, y, w, h);
		}
		
		public void setBounds(Rectangle r) {
			System.out.println("RootPane.setBounds() " + System.currentTimeMillis());
			super.setBounds(r);
		}
		
		public void setSize(Dimension d) {
			System.out.println("RootPane.setSize() " + System.currentTimeMillis());
			super.setSize(d);
		}
		
		public void setSize(int w, int h) {
			System.out.println("RootPane.setSize() " + System.currentTimeMillis());
			super.setSize(w, h);
		}
		
		public void invalidate() {
			if(resized) {
				System.out.println("RootPane.invalidate() " + System.currentTimeMillis());
			}
			
			super.invalidate();
		}
		
		public void validate() {
			if(resized) {
				System.out.println("RootPane.validate() " + System.currentTimeMillis());
			}
			
			super.validate();
		}
		
		class ResizeListener extends ComponentAdapter {

			public void componentResized(ComponentEvent e) {
				System.out.println("RootPane.Event " + System.currentTimeMillis());
				resized = true;
			}
		}
	}
	
	class GoodContentPane extends JPanel {
		
		private boolean resized = false;
		
		public Component add(Component comp) {
			super.add(comp);
			return comp;
		}
		
		public Component add(Component comp, int index) {
			super.add(comp, index);
			return comp;
		}
		
		public void add(Component comp, Object constraints) {
			super.add(comp, constraints);
		}
		
		GoodContentPane() {
			super(new BorderLayout());
			addComponentListener(new ResizeListener());
		}
		
		GoodContentPane(boolean isDoubleBuffered) {
			super(isDoubleBuffered);
			addComponentListener(new ResizeListener());
		}
		
		GoodContentPane(LayoutManager layout) {
			super(layout);
			addComponentListener(new ResizeListener());
		}
		
		GoodContentPane(LayoutManager layout, boolean isDoubleBuffered) {
			super(layout, isDoubleBuffered);
			addComponentListener(new ResizeListener());
		}
		
		public void paint(Graphics g) {
			if(resized) {
				System.out.println("ContentPane.paint() " + System.currentTimeMillis());
				resized = false;
			}
			
			super.paint(g);
		}
		
		public void invalidate() {
			if(resized) {
				System.out.println("ContentPane.invalidate() " + System.currentTimeMillis());
			}
			
			super.invalidate();
		}
		
		public void validate() {
			if(resized) {
				System.out.println("ContentPane.validate() " + System.currentTimeMillis());
			}
			
			super.validate();
		}
		
		class ResizeListener extends ComponentAdapter {

			public void componentResized(ComponentEvent e) {
				System.out.println("ContentPane.Event " + System.currentTimeMillis());
				resized = true;
			}
		}
	}
}
