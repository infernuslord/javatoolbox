/*
 * Hamsam - Instant Messaging API
 * Copyright (C) 2003 Raghu K
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package hamsam.protocol.yahoo;

/**
 * This interface defines various constants used by the Yahoo protocol.
 *
 * @author Raghu
 */
public interface Constants
{
	/**
	 * Status indicator for "I'm available".
	 */
	long STATUS_AVAILABLE = 0x00;

	/**
	 * Status indicator for "Be Right Back".
	 */
	long STATUS_BRB = 1;

	/**
	 * Status indicator for "Busy".
	 */
	long STATUS_BUSY = 2;

	/**
	 * Status indicator for "Not At Home".
	 */
	long STATUS_NOTATHOME = 3;

	/**
	 * Status indicator for "Not At My Desk".
	 */
	long STATUS_NOTATDESK = 4;

	/**
	 * Status indicator for "Not In The Office".
	 */
	long STATUS_NOTINOFFICE = 5;

	/**
	 * Status indicator for "On The Phone".
	 */
	long STATUS_ONPHONE = 6;

	/**
	 * Status indicator for "On Vacation".
	 */
	long STATUS_ONVACATION = 7;

	/**
	 * Status indicator for "Out To Lunch".
	 */
	long STATUS_OUTTOLUNCH = 8;

	/**
	 * Status indicator for "Stepped Out".
	 */
	long STATUS_STEPPEDOUT = 9;

	/**
	 * Status indicator for invisible mode.
	 */
	long STATUS_INVISIBLE = 12;

	/**
	 * Status indicator for going offline.
	 */
	long STATUS_OFFLINE = 0x5a55aa56;

	/**
	 * Status indicator for typing notifications.
	 */
	long STATUS_TYPING = 0x16;

	/**
	 * Status indicator that is used for custom status messages.
	 */
	long STATUS_CUSTOM = 99;

	/**
	 * Service type used to change from an available status to an away status.
	 */
	int SERVICE_ISAWAY = 0x03;

	/**
	 * Service type used to change from an away status to an available status.
	 */
	int SERVICE_ISBACK = 0x04;

	/**
	 * Indicates logon by a user.
	 */
	int SERVICE_LOGON = 0x01;

	/**
	 * Indicates logoff by a user.
	 */
	int SERVICE_LOGOFF = 0x02;

	/**
	 * Service type used to send and receive instant messages.
	 */
	int SERVICE_MESSAGE = 0x06;

	/**
	 * A yahoo ID is activated.
	 */
	int SERVICE_IDACT = 0x07;

	/**
	 * A yahoo ID got deactivated.
	 */
	int SERVICE_IDDEACT = 0x08;

	/**
	 * Indicates a change in status of a user.
	 */
	int SERVICE_USERSTAT = 0x0a;

	/**
	 * A new mail notification.
	 */
	int SERVICE_NEWMAIL = 0x0b;

	/**
	 * Indicates a change in buddy list.
	 */
	int SERVICE_NEWCONTACT = 0x0f;

	/**
	 * Used in keep alive packets.
	 */
	int SERVICE_PING = 0x12;

	/**
	 * A system message by Yahoo.
	 */
	int SERVICE_SYSMESSAGE = 0x14;

	/**
	 * Service type for inviting buddies to a conference.
	 */
	int SERVICE_CONFINVITE = 0x18;

	/**
	 * A buddy login to the a conference.
	 */
	int SERVICE_CONFLOGON = 0x19;

	/**
	 * A buddy decline to join a conference.
	 */
	int SERVICE_CONFDECLINE = 0x1a;

	/**
	 * Service type used to logoff from a conference.
	 */
	int SERVICE_CONFLOGOFF = 0x1b;

	/**
	 * Invitation for a conference.
	 */
	int SERVICE_CONFADDINVITE = 0x1c;

	/**
	 * An instant message for a conference.
	 */
	int SERVICE_CONFMSG = 0x1d;

	/**
	 * Service type used for typing notifications.
	 */
	int SERVICE_NOTIFY = 0x4b;

	/**
	 * Service for connection verification.
	 */
	int SERVICE_VERIFY = 0x4C;

	/**
	 * Yahoo responds to an authentication.
	 */
	int SERVICE_AUTHRESP = 0x54;

	/**
	 * Get the buddy list and ignore list.
	 */
	int SERVICE_LIST = 0x55;

	/**
	 * Yahoo requests for password authentication.
	 */
	int SERVICE_AUTH = 0x57;

	/**
	 * Service type used to add a buddy to the buddy list.
	 */
	int SERVICE_ADDBUDDY = 0x83;

	/**
	 * Service type used to remove a buddy from the buddy list.
	 */
	int SERVICE_REMBUDDY = 0x84;

	/**
	 * Service type used to ignore a buddy.
	 */
	int SERVICE_IGNOREBUDDY = 0x85;

	/**
	 * Service type used to reject a buddy add request.
	 */
	int SERVICE_REJECTCONTACT = 0x86;
}
