/*
 * Copyright (c) 2005, the JUNG Project and the Regents of the University of
 * California All rights reserved.
 *
 * This software is open-source under the BSD license; see either "license.txt"
 * or http://jung.sourceforge.net/license.txt for a description.
 *
 * Created on Jul 21, 2005
 */

package edu.uci.ics.jung.visualization.transform;

import java.awt.Dimension;

import edu.uci.ics.jung.visualization.PickSupport;
import edu.uci.ics.jung.visualization.ShapePickSupport;
import edu.uci.ics.jung.visualization.VisualizationViewer;
/**
 * A class to make it easy to add a Hyperbolic projection
 * examining lens to a jung graph application. See HyperbolicTransforerDemo
 * for an example of how to use it.
 * 
 * @author Tom Nelson - RABA Technologies
 *
 *
 */
public class HyperbolicLayoutLensSupport extends AbstractHyperbolicLensSupport 
    implements HyperbolicLensSupport {

    MutableTransformer savedViewTransformer;
    /**
     * create the base class, setting common members and creating
     * a custom GraphMouse
     * @param vv the VisualizationViewer to work on
     */
    public HyperbolicLayoutLensSupport(VisualizationViewer vv) {
        super(vv);
        hyperbolicTransformer = 
            new HyperbolicTransformer(vv, vv.getLayoutTransformer());

        Dimension d = vv.getSize();
        if(d.width <= 0 || d.height <= 0) {
            d = vv.getPreferredSize();
        }
        hyperbolicTransformer.setViewRadius(d.width/5);
   }
    
    public void activate() {
        lens = new Lens(hyperbolicTransformer);
        vv.setLayoutTransformer(hyperbolicTransformer);
        vv.setViewTransformer(new MutableAffineTransformer());
        vv.addPreRenderPaintable(lens);
        vv.setGraphMouse(hyperbolicGraphMouse);
        vv.setToolTipText(instructions);
        vv.repaint();
    }
    
    public void deactivate() {
        if(savedViewTransformer != null) {
            vv.setViewTransformer(savedViewTransformer);
        }
        if(hyperbolicTransformer != null) {
            vv.removePreRenderPaintable(lens);
            vv.setLayoutTransformer(hyperbolicTransformer.getDelegate());
        }
        vv.setToolTipText(defaultToolTipText);
        vv.setGraphMouse(graphMouse);
        vv.repaint();
    }
}
