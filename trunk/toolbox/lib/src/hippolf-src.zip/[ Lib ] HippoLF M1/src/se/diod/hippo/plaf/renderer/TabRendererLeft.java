/*
 * 
 * Created on 2004-jul-25
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.renderer;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Rectangle;

import javax.swing.JTabbedPane;
import javax.swing.UIManager;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-25
 *
 */
public class TabRendererLeft extends AbstractRenderer {




	/**
	 * 
	 * 
	 */
	public TabRendererLeft( JTabbedPane tabPane ) {
		super( tabPane );
	}




	/**
	 * 
	 * 
	 */
	public Insets getContentBorderInsets( Insets defaultInsets ) {
		return WEST_INSETS;
	}




	/**
	 * 
	 * minimal decoration is really minimal: no focus
	 * 
	 */
	public void paintFocusIndicator( Graphics g, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected ) {
	}




	/**
	 * 
	 * 
	 */
	public void paintTabBackground(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected) {
		if( isSelected ) {
			//g.setColor( new java.awt.Color( 158, 179, 193 ) );
			g.setColor( new java.awt.Color( 198, 209, 223 ) );  // TODO FIXED COLOR, BIG NONO!
		} else {
			g.setColor( UIManager.getColor("TabbedPane.background") );
		}

		g.fillRect(x, y, w, h);
	}




	/**
	 * 
	 * 
	 */
	public void paintTabBorder(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected) {
		int bottom = h;
		int right  = w;

		g.setColor( Color.GRAY );  // // TODO FIXED COLOR, BIG NONO!
		g.translate(x, y);

		if( isTabFirstDisplayed( tabIndex ) ) {
			if (isSelected) {
				// Selected and first in line
				g.fillRect( 0, 0, right, 1 );							// Top
				g.fillRect( 0, bottom, right, 1 );						// Bottom
				g.fillRect( 0, 0, 1, h );								// Left
			} else {}
		} else {
			if (isSelected) {
				// Selected but not first in line
				g.fillRect( 0, 0, right, 1 );							// Top
				g.fillRect( 0, bottom, right, 1 );						// Bottom
				g.fillRect( 0, 0, 1, h );								// Left
			} else {
				//g.setColor( new Color( 120, 120, 120 ) );
				//g.fillRect(right/2 - right/4, 0, right/2 + right/4, 1);
			}
		}

		g.translate(-x, -y);
	}
}
