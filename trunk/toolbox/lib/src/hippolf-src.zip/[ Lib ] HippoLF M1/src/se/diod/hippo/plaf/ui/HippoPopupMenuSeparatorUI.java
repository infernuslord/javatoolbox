/*
 * 
 * Created on 2004-jul-23
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.ui;

import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JComponent;
import javax.swing.UIManager;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicPopupMenuSeparatorUI;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-23
 *
 */
public class HippoPopupMenuSeparatorUI extends BasicPopupMenuSeparatorUI {
	private static final HippoPopupMenuSeparatorUI INSTANCE	= new HippoPopupMenuSeparatorUI();

	private static final int HEIGHT = 3;



	/**
	 * 
	 * Returns an instance of the UI delegate for the
	 * specified component. Each subclass must provide
	 * its own static createUI method that returns an
	 * instance of that UI delegate subclass.
	 * 
	 */
	public static ComponentUI createUI( JComponent c ) {
		return INSTANCE;
	}




	/**
	 * 
	 * Paints the specified component appropriate for
	 * the look and feel. This method is invoked from
	 * the ComponentUI.update method when the specified
	 * component is being painted.
	 * 
	 */
	public void paint( Graphics g, JComponent c ) {
		Graphics g2 = g.create();

		// Fill background..
		g2.setColor( UIManager.getColor( "Menu.background" ) );
		g2.fillRect( 0, 0, c.getWidth(), c.getHeight() );

		// Paint separator..
		g2.setColor( UIManager.getColor( "MenuItem.iconBackground" ) );
		g2.fillRect( 23, 1, c.getWidth(), 1 );

		// Draw icon background
		paintMenuItemIconBackground( g, c );
		g2.dispose();
	}




	/**
	 * 
	 * 
	 */
	private void paintMenuItemIconBackground( Graphics g, JComponent c ) {
		Graphics g2 = g.create();

		// Draw left gray border
		g2.setColor( UIManager.getColor( "MenuItem.iconBackground" ) );
		g2.fillRect(0, 0, 17, c.getHeight());

		g2.dispose();
	}




	/**
	 * 
	 * 
	 */
	public Dimension getPreferredSize( JComponent c ) { 
		return new Dimension( 0, HEIGHT ); 
	}
}
