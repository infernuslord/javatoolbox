/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	Tiny Look and Feel														   *
*															                   *
*  (C) Copyright 2003, by Hans Bickel									       *
*                                                                              *
*                                                                              *
* The starting point for Tiny Look and Feel was the XP Look and Feel written   *
* by Stefan Krause.  														   *
* The original header of this file was:                                        *
** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	XP Look and Feel														   *
*															                   *
*  (C) Copyright 2002, by Stefan Krause, Taufik Romdhane and Contributors      *
*                                                                              *
*                                                                              *
* The XP Look and Feel started as as extension to the Metouia Look and Feel.   *
* The original header of this file was:                                        *
** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*        Metouia Look And Feel: a free pluggable look and feel for java        *
*                         http://mlf.sourceforge.net                           *
*          (C) Copyright 2002, by Taoufik Romdhane and Contributors.           *
*                                                                              *
*   This library is free software; you can redistribute it and/or modify it    *
*   under the terms of the GNU Lesser General Public License as published by   *
*   the Free Software Foundation; either version 2.1 of the License, or (at    *
*   your option) any later version.                                            *
*                                                                              *
*   This library is distributed in the hope that it will be useful,            *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of             *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                       *
*   See the GNU Lesser General Public License for more details.                *
*                                                                              *
*   You should have received a copy of the GNU General Public License along    *
*   with this program; if not, write to the Free Software Foundation, Inc.,   *
*   59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.                    *
*                                                                              *
*   Original Author:  Taoufik Romdhane                                         *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package de.muntjak.tinylookandfeel;

import java.awt.*;
import java.io.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.InsetsUIResource;
import javax.swing.plaf.basic.BasicBorders;
import javax.swing.plaf.metal.MetalLookAndFeel;
import javax.swing.plaf.metal.MetalTheme;

import de.muntjak.tinylookandfeel.borders.*;
import de.muntjak.tinylookandfeel.controlpanel.*;
import de.muntjak.tinylookandfeel.skin.SkinImageCache;

/**
 * TinyLookAndFeel 
 * 
 * @version 1.0
 * @author Hans Bickel
 */
public class TinyLookAndFeel extends MetalLookAndFeel {

	protected static TinyDefaultTheme defaultTheme;

	/**
	 * The installation state of the Metouia Look and Feel.
	 */
	private static boolean isInstalled = false;

	/**
	 * The installation state of the Metouia Theme.
	 */
	private static boolean themeHasBeenSet = false;

	static {
		//System.out.println(System.getProperty("user.home"));
		// only if running without the control panel
		if (!ControlPanel.isInstantiated) {
			File themeFile = new File(System.getProperty("user.home") +
				File.separator + Theme.DEFAULT_THEME);
			String themePath = null;
			
			if(themeFile.exists()) {
				themePath = themeFile.getAbsolutePath();
			}
			else {
				// search user.dir
				themePath = Theme.DEFAULT_THEME;
			}
			
			if(Theme.loadTheme(themePath, Theme.CUSTOM_STYLE)) {
				Theme.style = Theme.CUSTOM_STYLE;
			}
		}
	}

	/**
	 * This constructor installs the Metouia Look and Feel with the default color
	 * theme.
	 */
	public TinyLookAndFeel() {
		if (!isInstalled) {
			isInstalled = true;
			UIManager.installLookAndFeel(new UIManager.LookAndFeelInfo("TinyLookAndFeel", "de.muntjak.tinylookandfeel.TinyLookAndFeel"));
		}
	}

	/**
	 * Return a string that identifies this look and feel.  This string
	 * will be used by applications/services that want to recognize
	 * well known look and feel implementations.  Presently
	 * the well known names are "Motif", "Windows", "Mac", "Metal".  Note
	 * that a LookAndFeel derived from a well known superclass
	 * that doesn't make any fundamental changes to the look or feel
	 * shouldn't override this method.
	 *
	 * @return The Metouia Look and Feel identifier.
	 */
	public String getID() {
		return "TinyLookAndFeel";
	}

	/**
	 * Return a short string that identifies this look and feel, e.g.
	 * "CDE/Motif".  This string should be appropriate for a menu item.
	 * Distinct look and feels should have different names, e.g.
	 * a subclass of MotifLookAndFeel that changes the way a few components
	 * are rendered should be called "CDE/Motif My Way"; something
	 * that would be useful to a user trying to select a L&F from a list
	 * of names.
	 *
	 * @return The look and feel short name.
	 */
	public String getName() {
		return "TinyLookAndFeel";
	}

	/**
	 * Return a one line description of this look and feel implementation,
	 * e.g. "The CDE/Motif Look and Feel".   This string is intended for
	 * the user, e.g. in the title of a window or in a ToolTip message.
	 *
	 * @return The look and feel short description.
	 */
	public String getDescription() {
		return "TinyLookAndFeel: Fun w/Swing.";
	}

	/**
	 * If the underlying platform has a "native" look and feel, and this
	 * is an implementation of it, return true.  For example a CDE/Motif
	 * look and implementation would return true when the underlying
	 * platform was Solaris.
	 */
	public boolean isNativeLookAndFeel() {
		return false;
	}

	/**
	 * Return true if the underlying platform supports and or permits
	 * this look and feel.  This method returns false if the look
	 * and feel depends on special resources or legal agreements that
	 * aren't defined for the current platform.
	 */
	public final boolean isSupportedLookAndFeel() {
		if (ControlPanel.isInstantiated)
			return true;
		//System.out.println(Theme.style == Theme.XP_STYLE);
		//System.out.println(Theme.derivedStyle[Theme.style] == Theme.XP_STYLE);
		if (Theme.derivedStyle[Theme.style] == Theme.XP_STYLE) {
			String osName = System.getProperty("os.name");
			if (!osName.equals("Windows XP")) {
				System.err.println("TinyLookAndFeel: You may run themes derived from the Windows XP Style only on Windows XP - sorry!");
			}
			return osName.equals("Windows XP");
		}

		return true;
	}

	public boolean getSupportsWindowDecorations() {
		return true;
	}

	/**
	 * Initializes the uiClassID to BasicComponentUI mapping.
	 * The JComponent classes define their own uiClassID constants. This table
	 * must map those constants to a BasicComponentUI class of the appropriate
	 * type.
	 *
	 * @param table The ui defaults table.
	 */
	protected void initClassDefaults(UIDefaults table) {
		super.initClassDefaults(table);

		table.putDefaults(new Object[] { "ButtonUI", "de.muntjak.tinylookandfeel.TinyButtonUI", "CheckBoxUI", "de.muntjak.tinylookandfeel.TinyCheckBoxUI", "TextFieldUI", "de.muntjak.tinylookandfeel.TinyTextFieldUI", "TextAreaUI", "de.muntjak.tinylookandfeel.TinyTextAreaUI", "FormattedTextFieldUI", "de.muntjak.tinylookandfeel.TinyTextFieldUI", "SliderUI", "de.muntjak.tinylookandfeel.TinySliderUI", "SpinnerUI", "de.muntjak.tinylookandfeel.TinySpinnerUI", "ToolBarUI", "de.muntjak.tinylookandfeel.TinyToolBarUI", "MenuBarUI", "de.muntjak.tinylookandfeel.TinyMenuBarUI", "MenuUI", "de.muntjak.tinylookandfeel.TinyMenuUI", "MenuItemUI", "de.muntjak.tinylookandfeel.TinyMenuItemUI", "CheckBoxMenuItemUI", "de.muntjak.tinylookandfeel.TinyCheckBoxMenuItemUI", "RadioButtonMenuItemUI", "de.muntjak.tinylookandfeel.TinyRadioButtonMenuItemUI", "ScrollBarUI", "de.muntjak.tinylookandfeel.TinyScrollBarUI", "TabbedPaneUI", "de.muntjak.tinylookandfeel.TinyTabbedPaneUI", "ToggleButtonUI", "de.muntjak.tinylookandfeel.TinyButtonUI", "ScrollPaneUI", "de.muntjak.tinylookandfeel.TinyScrollPaneUI", "ProgressBarUI", "de.muntjak.tinylookandfeel.TinyProgressBarUI", "InternalFrameUI", "de.muntjak.tinylookandfeel.TinyInternalFrameUI", "RadioButtonUI", "de.muntjak.tinylookandfeel.TinyRadioButtonUI", "ComboBoxUI", "de.muntjak.tinylookandfeel.TinyComboBoxUI", "PopupMenuSeparatorUI", "de.muntjak.tinylookandfeel.TinyPopupMenuSeparatorUI", "SplitPaneUI", "de.muntjak.tinylookandfeel.TinySplitPaneUI", "FileChooserUI", "de.muntjak.tinylookandfeel.TinyFileChooserUI", "ListUI", "de.muntjak.tinylookandfeel.TinyListUI", "TreeUI", "de.muntjak.tinylookandfeel.TinyTreeUI", "LabelUI", "de.muntjak.tinylookandfeel.TinyLabelUI", "TableUI", "de.muntjak.tinylookandfeel.TinyTableUI", "TableHeaderUI", "de.muntjak.tinylookandfeel.TinyTableHeaderUI", "ToolTipUI", "de.muntjak.tinylookandfeel.TinyToolTipUI", "RootPaneUI", "de.muntjak.tinylookandfeel.TinyRootPaneUI", });
	}

	/**
	 * Creates the default theme and installs it.
	 * The TinyDefaultTheme is used as default.
	 */
	protected void createDefaultTheme() {
		if (!themeHasBeenSet) {
			defaultTheme = new TinyDefaultTheme();
			setCurrentTheme(defaultTheme);
		}
	}

	/**
	 * Sets the current color theme.
	 * Warning: The them must be an instance of TinyDefaultTheme!
	 *
	 * @param theme The theme to install.
	 */
	public static void setCurrentTheme(MetalTheme theme) {
		MetalLookAndFeel.setCurrentTheme(theme);
		themeHasBeenSet = true;
	}

	/**
	 * Initializes the system colors.
	 *
	 * @param table The ui defaults table.
	 */
	protected void initSystemColorDefaults(UIDefaults table) {
		super.initSystemColorDefaults(table);
		table.put("textHighlight", getTextHighlightColor());
		//table.put("textHighlight", new ColorUIResource(99,144,175));
	}

	/**
	 * Initializes the default values for many ui widgets and puts them in the
	 * given ui defaults table.
	 * Here is the place where borders can be changed.
	 *
	 * @param table The ui defaults table.
	 */
	protected void initComponentDefaults(UIDefaults table) {
		super.initComponentDefaults(table);

		// Replace the Metal borders:
		Border border = new EmptyBorder(0, 0, 0, 0);
		table.put("Button.margin", new InsetsUIResource(Theme.buttonMarginTop[Theme.style], Theme.buttonMarginLeft[Theme.style], Theme.buttonMarginBottom[Theme.style], Theme.buttonMarginRight[Theme.style]));
		table.put("Button.border", new BasicBorders.MarginBorder());
		table.put("ToggleButton.margin", new InsetsUIResource(4, 16, 4, 16));
		table.put("ToggleButton.border", new BasicBorders.MarginBorder());
		table.put("TextField.border", new TinyTextFieldBorder());
		table.put("ComboBox.border", border);
		table.put("Spinner.border", new TinyTextFieldBorder(new Insets(2, 2, 2, 2)));

		border = new EmptyBorder(2, 2, 2, 2);
		table.put("ToolBar.border", border);
		table.put("InternalFrame.border", border);
		table.put("InternalFrame.paletteBorder", border);
		table.put("InternalFrame.optionDialogBorder", border);

		border = new EmptyBorder(2, 4, 2, 4);
		table.put("Menu.border", border);
		table.put("MenuItem.border", border);
		table.put("CheckBoxMenuItem.border", border);
		table.put("RadioButtonMenuItem.border", border);
		border = new TinyPopupMenuBorder();
		table.put("PopupMenu.border", border);

		table.put("ScrollPane.border", new TinyScrollPaneBorder());

		table.put("Slider.trackWidth", new Integer(4));

		// Tweak some subtle values:
		table.put("SplitPane.dividerSize", new Integer(6));
		table.put("InternalFrame.paletteTitleHeight", new Integer(10));
		table.put("InternalFrame.frameTitleHeight", new Integer(21));
		table.put("InternalFrame.normalTitleFont", new Font("dialog", Font.BOLD, 13));

		table.put("TabbedPane.tabInsets", new Insets(1, 6, 4, 6));
		table.put("TabbedPane.tabAreaInsets", new Insets(6, Theme.firstTabDistance[Theme.style], 0, 0));
		table.put("TabbedPane.selectedTabPadInsets", new Insets(2, 2, 1, 2));
		table.put("TabbedPane.contentBorderInsets", Theme.tabInsets[Theme.style]);
		table.put("TabbedPane.unselected", new ColorUIResource(0, 0, 0));

		table.put("PopupMenu.background", new Color(0, 255, 0));
		table.put("PopupMenu.foreground", new Color(255, 0, 0));

		table.put("TextField.selectionForeground", Color.white);
		table.put("TextField.selectionBackground", Theme.textSelectedBgColor[Theme.style]);
		table.put("TextArea.selectionForeground", Color.white);
		table.put("TextArea.selectionBackground", Theme.textSelectedBgColor[Theme.style]);

		table.put("TextField.background", Color.white);
		table.put("TextField.disabledBackground", Theme.textDisabledBgColor[Theme.style]);

		table.put("ComboBox.foreground", Color.black);
		table.put("ComboBox.background", Color.white);
		table.put("ComboBox.selectionForeground", Theme.comboSelectedTextColor[Theme.style]);
		table.put("ComboBox.selectionBackground", Theme.comboSelectedBgColor[Theme.style]);
		table.put("ComboBox.focusBackground", Theme.comboFocusBgColor[Theme.style]);

		table.put("InternalFrame.frameTitleHeight", new Integer(25));
		table.put("InternalFrame.paletteTitleHeight", new Integer(16));
		table.put("InternalFrame.icon", loadIcon("XPInternalFrameIcon.png", this));

		table.put("RootPane.colorChooserDialogBorder", TinyFrameBorder.getInstance());
		table.put("RootPane.errorDialogBorder", TinyFrameBorder.getInstance());
		table.put("RootPane.fileChooserDialogBorder", TinyFrameBorder.getInstance());
		table.put("RootPane.frameBorder", TinyFrameBorder.getInstance());
		table.put("RootPane.informationDialogBorder", TinyFrameBorder.getInstance());
		table.put("RootPane.plainDialogBorder", TinyFrameBorder.getInstance());
		table.put("RootPane.questionDialogBorder", TinyFrameBorder.getInstance());
		table.put("RootPane.warningDialogBorder", TinyFrameBorder.getInstance());

		table.put("ToolTip.background", new Color(255, 255, 225));
		table.put("ToolTip.foreground", new Color(0, 0, 0));
		table.put("ToolTip.font", Theme.toolTipFont[Theme.style]);
		table.put("ToolTip.border", new CompoundBorder(new LineBorder(Color.black, 1), new EmptyBorder(2, 2, 2, 2)));

		table.put("RadioButton.margin", new InsetsUIResource(0, 0, 0, 0));
		table.put("CheckBox.margin", new InsetsUIResource(0, 0, 0, 0));

		table.put("CheckBoxMenuItem.checkIcon", MenuItemIconFactory.getCheckBoxMenuItemIcon());
		table.put("RadioButtonMenuItem.checkIcon", MenuItemIconFactory.getRadioButtonMenuItemIcon());

		table.put("Tree.selectionForeground", Color.white);
		table.put("Tree.selectionBackground", Theme.comboSelectedBgColor[Theme.style]);
		table.put("Tree.textBackground", Theme.backColor[Theme.style]);

		table.put("Tree.expandedIcon", loadIcon("XPTreeMinus.png", this));
		table.put("Tree.collapsedIcon", loadIcon("XPTreePlus.png", this));
		table.put("Tree.openIcon", loadIcon("XPTreeFolderOpened.png", this));
		table.put("Tree.closedIcon", loadIcon("XPTreeFolderClosed.png", this));
		table.put("Tree.leafIcon", loadIcon("XPTreeLeaf.png", this));

		table.put("List.selectionForeground", Theme.listSelectedTextColor);
		table.put("List.selectionBackground", Theme.listSelectedBgColor);

		table.put("FileView.directoryIcon", loadIcon("XPFolderClosed.png", this));
		table.put("FileView.computerIcon", loadIcon("XPComputerIcon.png", this));
		table.put("FileView.fileIcon", loadIcon("XPDocument.png", this));
		table.put("FileView.floppyDriveIcon", loadIcon("XPFloppy.png", this));
		table.put("FileView.hardDriveIcon", loadIcon("XPHarddisk.png", this));

		table.put("FileChooser.detailsViewIcon", loadIcon("XPFileDetails.png", this));
		table.put("FileChooser.homeFolderIcon", loadIcon("XPDesktopIcon.png", this));
		table.put("FileChooser.listViewIcon", loadIcon("XPFileList.png", this));
		table.put("FileChooser.newFolderIcon", loadIcon("XPNewFolder.png", this));
		table.put("FileChooser.upFolderIcon", loadIcon("XPParentDirectory.png", this));

		table.put("OptionPane.errorIcon", loadIcon("XPError.png", this));
		table.put("OptionPane.informationIcon", loadIcon("XPInformation.png", this));
		table.put("OptionPane.warningIcon", loadIcon("XPWarning.png", this));
		table.put("OptionPane.questionIcon", loadIcon("XPQuestion.png", this));
	}

	/**
	 * Loads an image icon.
	 *
	 * @param file The image file name.
	 * @param invoker The refence of the invoking class, whose classloader will be
	 *                used for loading the image.
	 */
	public static ImageIcon loadIcon(final String file, final Object invoker) {
		// When we return an IconUIResource the disabled icon of a file chooser
		// won't be painted greyed out,
		// thus we simply stay with an icon
		return loadIconImmediately(file, invoker);
	}

	/**
	 * Loads an image icon immediately.
	 *
	 * @param file The image file name.
	 * @param invoker The refence of the invoking class, whose classloader will be
	 *                used for loading the image.
	 */
	public static ImageIcon loadIconImmediately(String file, Object invoker) {
		try {
			Image img = SkinImageCache.getInstance().getImage(file);

			ImageIcon icon = new ImageIcon(img);

			if (icon.getIconWidth() <= 0) {
				System.out.println("******************** File " + file + " not found. Exiting");
				System.exit(1);
			}
			return icon;
		} catch (Exception exception) {
			exception.printStackTrace();
			System.out.println("Error getting resource " + file);
			return null;
		}
	}

	public static Color getLightControl() {
		return defaultTheme.getControlHighlight();
	}
	
	/**
	 * @return
	 */
	public static ColorUIResource getControl() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * used for SliderUI Ticks
	 */
	public static Color getDarkControl() {
		return defaultTheme.getDarkControl();
	}
}