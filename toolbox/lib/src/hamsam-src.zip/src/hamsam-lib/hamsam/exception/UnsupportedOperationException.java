/*
 * Please see COPYING for license details
 *
 * Copyright (C) 2003 Raghu K, All rights reserved.
 */

package hamsam.exception;

/**
 * Thrown to indicate that the requested operation is not supported.
 */
public class UnsupportedOperationException extends HamsamException
{
	/**
	 * Constructs an <code>UnsupportedOperationException<code> with no detailed message.
	 */
	public UnsupportedOperationException()
	{
		super();
	}

	/**
	 * Constructs an <code>UnsupportedOperationException</code> with the specified detail
	 * message.
	 *
	 * @param message the detail message. The detail message is saved for later
	 *                retrieval by the Throwable.getMessage() method.
	 */
	public UnsupportedOperationException(String message)
	{
		super(message);
	}
}
