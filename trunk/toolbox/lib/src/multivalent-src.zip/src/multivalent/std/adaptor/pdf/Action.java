package multivalent.std.adaptor.pdf;

import java.awt.Point;
import java.net.URI;
import java.net.URISyntaxException;
import java.io.IOException;

import multivalent.Behavior;
//import multivalent.Layer;
import multivalent.Document;
//import multivalent.IScrollPane;
import multivalent.Browser;
import multivalent.SemanticEvent;
import multivalent.Node;
import multivalent.std.ui.Multipage;



/**
	Default implementations of PDF actions:
	GoTo, GoToR, Launch, Thread, URI, Sound, Movie, Hide, Named, SubmitForm, ResetForm, ImportData, JavaScript.
	At present, only GoTo, GoToR, and URI are implemented; and Named is ignored as there are no such actions defined by this viewer.

	@see "PDF Reference 1.4, page 518."

	@version $Revision: 1.5 $ $Date: 2003/06/01 06:55:27 $
*/
public class Action extends Behavior {
  /**
	Message of semantic event that announces a PDF action that some handler (another behavior) should execute.
	arg = action dictionary, in = handle to this behavior (for fetching component objects), out = root of PDF document tree.
  */
  public static final String MSG_EXECUTE = "pdfAction";



  //PDFReader pdfr_ = null;

/*
  public void buildAfter(Document doc) {
	// find corresponding media adaptor
	Layer l = getDocument().getLayer("base");
	for (int i=0,imax=l.size(); i<imax; i++) {
		Behavior be = l.getBehavior(i);
//System.out.println(be.getName());
		if (be instanceof PDF) { pdf_ = (PDF)be; break; }
	}
	assert pdf_!=null;
  }
*/

  /**
	Implement the PDF Action, as requested by {@link #MSG_EXECUTE}.
  */
  public boolean semanticEventAfter(SemanticEvent se, String msg) /*throws IOException*/ {
	Object arg = se.getArg();
//System.out.println("action: "+msg+", "+(arg.getClass()==PDF.DICTIONARY_CLASS)+", "+se.getIn()+", out="+se.getOut());
	if (msg==MSG_EXECUTE && arg!=null && arg.getClass()==COS.CLASS_DICTIONARY && se.getIn() instanceof PDF && se.getOut() instanceof Node) {
		Dict dict = (Dict)arg;
		PDF pdf = (PDF)se.getIn();  // same as getDocument().getMediaAdaptor()
		PDFReader pdfr = pdf.getReader();
		//PDFReader pdfr = (se.getIn() instanceof PDF? (PDF)se.getIn(): pdf_);
		Node out = (Node)se.getOut();

		try {   // not the OO way -- could use reflection
			String S = (String)pdfr.getObject(dict.get("S"));
System.out.println(S+" "+dict);

			if ("GoTo".equals(S)) gotol(dict, pdf, out);
			else if ("GoToR".equals(S)) gotor(dict, pdf, out);
			else if ("Launch".equals(S)) launch(dict, pdf, out);

			else if ("Thread".equals(S)) thread(dict, pdf, out);

			else if ("URI".equals(S)) uri(dict, pdf, out);
			else if ("Sound".equals(S)) sound(dict, pdf, out);
			else if ("Movie".equals(S)) movie(dict, pdf, out);

			else if ("Hide".equals(S)) hide(dict, pdf, out);

			else if ("Named".equals(S)) named(dict, pdf, out);

			else if ("SubmitForm".equals(S)) submitform(dict, pdf, out);
			else if ("ResetForm".equals(S)) resetform(dict, pdf, out);
			else if ("ImportData".equals(S)) importdata(dict, pdf, out);

			else if ("JavaScript".equals(S)) javascript(dict, pdf, out);

			else if ("SetOCGState".equals(S)) setOCGState(dict, pdf, out);
			else if ("Rendition".equals(S)) rendition(dict, pdf, out);

			else if (S==null && dict.get("D")!=null) gotol(dict, pdf, out);   // lone destination: implicit GoTo

			else System.err.println("unknown annotation: "+S+" -- ignored (if already handled, short-circuit)");

		} catch (IOException failed) {
			System.out.println(dict.get("S")+" failed: "+failed);
		}


		// chain to /AA tree
		// ...

	// standard URI anchor syntax from hyperlink annotation could refer to named destination
	} /*else if (msg==IScrollPane.MSG_SCROLL_TO && arg instanceof String) {
		// on right page, scroll to point in page

	//System.out.println("PDF Action on SCROLL_TO "+arg+", pdf="+pdf_);
		// if no such name on current page, check for named destination
		/*
		IScrollPane doc = (se.getIn() instanceof Node? ((Node)se.getIn()).getIScrollPane(): getBrowser().getCurDocument());
		int oldy = doc.getVsb().getValue();
		scrollTo(doc, (String)arg);
		if (doc.getVsb().getValue() == oldy) ...
*/
/*
		try {
			Object dest = resolveNamedDest(new StringBuffer((String)arg), pdf_);
			if (dest==null) resolveNamedDest((String)arg, pdf_);  // try old style
//System.out.println("=> "+dest);
			if (dest!=null) {
				gotoDest(dest, pdf_);
				return true;
			}
		} catch (Exception ignore) {}
*/
	//}

	return super.semanticEventAfter(se, msg);
  }

  /**
	"Go to a destination in the current document".
  */
  /*not protected because extend by intercepting event in different behvaior, not by subclassing and replacing*/ void gotol(Dict dict, PDF pdf, Node out) throws IOException {
	PDFReader pdfr = pdf.getReader();
	Object D = pdfr.getObject(dict.get("D"));
	Object dest = resolveNamedDest(D, pdfr);

//System.out.println("go to page "+dest);
	if (dest!=null && dest.getClass()==COS.CLASS_DICTIONARY) {  // extract from << /D [...] >>
		dest = pdfr.getObject(((Dict)dest).get("D"));
//System.out.println("=> "+dest);
	}

	if (dest!=null && dest.getClass()==COS.CLASS_ARRAY) {   // [page ... /XYZ left top zoom, /Fit, /FitH top, /FitV left, /FitR left bottom right top, /FitB, /FitBH top, /FitBV left
		Object[] pa = (Object[])dest;
		Object page = pdfr.getObject(pa[0]);
//System.out.println("page = "+pa[0]+" / "+page);
		if (/*page!=null &&*/ page.getClass()==COS.CLASS_DICTIONARY) {
			Browser br = getBrowser();
			br.eventq(Multipage.MSG_GOPAGE, String.valueOf(pdfr.getPageNum((Dict)page)));     // throws through Multipage so annotations get saved
			//br.eventq() ... /FitH and so on
			//br.eventq() ... scroll to point on page
		}
	}
  }

  public static Object resolveNamedDest(Object key, PDFReader pdfr) throws IOException {
	Object dest;
	if (key==null || key.getClass()==COS.CLASS_ARRAY || key.getClass()==COS.CLASS_DICTIONARY) {     // literal/direct
		dest = key;

	} else if (key.getClass()==COS.CLASS_NAME) {    // old style => shouldn't see this since PDFReader.updateDests
		Dict dests = (Dict)pdfr.getObject(pdfr.getCatalog().get("Dests"));
		dest = (dests!=null? pdfr.getObject(dests.get(key)): null/*error*/);
//System.out.println("old-style dest: "+key+" => "+dest);     // e.g., Thinking in Postscript
		//br.eventq(msg, new StringBuffer((String)arg));  // send around again rather than converting directly, since some listeners might check for type of arg

	} else { assert key.getClass() == COS.CLASS_STRING;
		Dict names = (Dict)pdfr.getObject(pdfr.getCatalog().get("Names"));
		Dict dests = (Dict)(names!=null? pdfr.getObject(names.get("Dests")): null);
		dest = pdfr.getObject(pdfr.findNameTree(dests, (StringBuffer)key));
	}

//System.out.println(key+" => "+dest);
	return dest;
  }



  /**
	"(�Go-to remote�) Go to a destination in another document".
  */
  void gotor(Dict dict, PDF pdf, Node out) throws IOException {
	PDFReader pdfr = pdf.getReader();
	Object D = pdfr.getObject(dict.get("D"));    // /Name, (String), [array w/int=pg no]
	if (D instanceof Object[]) D = "page="+((Object[])D)[0];
	Object F = pdfr.getObject(dict.get("F"));    // file
	Object NewWindow = pdfr.getObject(dict.get("NewWindow"));
	//br.eventq(Document.MSG_OPEN, F+"#"+D);
	//br.eventq("GoTo", ...);   // regular GoTo within new document
  }


  /**
	"Launch an application, usually to open a file".
  */
  void launch(Dict dict, PDF pdf, Node out) throws IOException {
	// URI.encode() on URI or else security hole
  }


  /**
	"Begin reading an article thread".
  */
  void thread(Dict dict, PDF pdf, Node out) throws IOException {
  }


  /**
	"Resolve a uniform resource identifier".
	<p>(Acrobat has a weblink plug-in that "adds the capability of linking to documents on the World Wide Web".
	We just have to throw a semantic event.)
  */
  void uri(Dict dict, PDF pdf, Node out) throws IOException {
	PDFReader pdfr = pdf.getReader();
	Browser br = getBrowser();
	String suri = pdfr.getObject(dict.get("URI")).toString();  // (String) => java.lang.String

	Boolean ismap = (Boolean)pdfr.getObject(dict.get("IsMap"));
	if (ismap!=null && ismap.booleanValue()) {
		Point pt = br.getCurScrn();
		// LATER: subtract off Rect
		suri += "?"+ pt.x + "," + pt.y; // don't add to StringBuffer, as that would mutate, though we are leaving this document...
	}

	Dict uridict = (Dict)pdfr.getObject(pdfr.getCatalog().get("URI"));
	StringBuffer base = (StringBuffer)(uridict!=null? pdfr.getObject(uridict.get("Base")): null);
	if (base!=null) try { suri = new URI(base.toString()).resolve(suri).toString(); } catch (URISyntaxException urie) { /*maybe /URI ok as is*/ }

	br.eventq(Document.MSG_OPEN, suri);
  }


  /**
	"Play a sound" (PDF 1.2).
  */
  void sound(Dict dict, PDF pdf, Node out) throws IOException {
  }


  /**
	"Play a movie" (PDF 1.2).
  */
  void movie(Dict dict, PDF pdf, Node out) throws IOException {
  }


  /**
	"Execute an action predefined by the viewer application" (PDF 1.2).
  */
  void named(Dict dict, PDF pdf, Node out) throws IOException {
	// No actions defined here.
  }


  /**
	"Set an annotation�s Hidden flag" (PDF 1.2).
  */
  void hide(Dict dict, PDF pdf, Node out) throws IOException {
  }


  /**
	"Send data to a uniform resource locator" (PDF 1.2).
  */
  void submitform(Dict dict, PDF pdf, Node out) throws IOException {
  }


  /**
	"Set fields to their default values" (PDF 1.2).
  */
  void resetform(Dict dict, PDF pdf, Node out) throws IOException {
  }


  /**
	"Import field values from a file" (PDF 1.2).
  */
  void importdata(Dict dict, PDF pdf, Node out) throws IOException {
  }


  /**
	"Execute a JavaScript script" (PDF 1.3).
  */
  void javascript(Dict dict, PDF pdf, Node out) throws IOException {
  }

  /**
	"Set the states of optional content groups" (PDF 1.5).
  */
  void setOCGState(Dict dict, PDF pdf, Node out) throws IOException {
  }

  /**
	"" (PDF 1.5).
  */
  void rendition(Dict dict, PDF pdf, Node out) throws IOException {
  }
}
