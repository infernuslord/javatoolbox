/*
 * 
 * Created on 2004-jul-23
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.ui;

import java.awt.Graphics;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicPanelUI;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-23
 *
 */
public class HippoPanelUI extends BasicPanelUI {
	private static final HippoPanelUI INSTANCE = new HippoPanelUI();




	/**
	 * 
	 * 
	 * 
	 */
	public static ComponentUI createUI( JComponent x ) {
		return INSTANCE;
	}




	/**
	 * 
	 * Replaces the <code>Border</code> if appropriate, then paints.
	 * 
	 */
	public void update( Graphics g, JComponent c ) {
		Graphics g2 = g.create();
		JPanel panel = (JPanel)c;


		g2.setColor( UIManager.getColor( "Panel.background") );
		g2.drawRect( 0, 0, panel.getWidth(), panel.getHeight() );

		g2.dispose();
		super.update(g, c);
	}
}
