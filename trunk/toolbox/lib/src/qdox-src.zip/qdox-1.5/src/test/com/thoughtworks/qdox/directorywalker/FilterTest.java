package com.thoughtworks.qdox.directorywalker;

import junit.framework.TestCase;

public class FilterTest extends TestCase {
    public FilterTest(String s) {
        super(s);
    }

    public void testFilterByTestCaseJavadoc() {
//        // create a directory scanner
//        DirectoryScanner scanner = new DirectoryScanner();
//
//        scanner.setFilter()
//
        // return a filtered list of java sources
    }

}
