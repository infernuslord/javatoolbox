package edu.emory.mathcs.util.concurrent.helpers;

import edu.emory.mathcs.util.concurrent.*;
import edu.emory.mathcs.util.concurrent.locks.*;

public class Utils {
    private Utils() {}

    /**
     * Emulation. Consider adding platform-specific hooks.
     */
    public static long nanoTime() {
        return System.currentTimeMillis() * 1000 * 1000;
    }

    /**
     * Warning; this method is rather inefficient and prone to inaccuracies
     * and truncation errors.
     */
    public static long awaitNanos(Condition cond, long nanos)
        throws InterruptedException
    {
        if (nanos <= 0) return nanos;
        long now = nanoTime();
        cond.await(nanos, TimeUnit.NANOSECONDS);
        return nanos - (nanoTime() - now);
    }
}