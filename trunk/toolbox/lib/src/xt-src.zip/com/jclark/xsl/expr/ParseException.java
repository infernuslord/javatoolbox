// $Id: ParseException.java,v 1.1 2002/04/25 18:10:35 bill Exp $

package com.jclark.xsl.expr;

class ParseException extends Exception {
    ParseException(String detail) {
        super(detail);
    }
}
