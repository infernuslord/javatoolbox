/** ===================================================================
 *
 * L2FProd.com Common Components 0.1-dev License.
 *
 * Copyright (c) 2004 L2FProd.com.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by L2FProd.com
 *        (http://www.L2FProd.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "L2FProd.com Common Components", "l2fprod-common" and "L2FProd.com" must not
 *    be used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact info@L2FProd.com.
 *
 * 5. Products derived from this software may not be called "l2fprod-common"
 *    nor may "l2fprod-common" appear in their names without prior written
 *    permission of L2FProd.com.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL L2FPROD.COM OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package com.l2fprod.common.swing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.Icon;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.text.JTextComponent;

/**
 * BannerPanel. <br>
 *  
 */
public class BannerPanel extends JPanel {

  private JLabel titleLabel;

  private JTextComponent subtitleLabel;

  private JLabel iconLabel;

  public BannerPanel() {
    setBorder(
      new CompoundBorder(new EtchedBorder(), LookAndFeelTweaks.PANEL_BORDER));

    setOpaque(true);
    setBackground(UIManager.getColor("Table.background"));

    titleLabel = new JLabel();
    titleLabel.setOpaque(false);

    subtitleLabel = new JEditorPane("text/html", "<html>");
    subtitleLabel.setFont(titleLabel.getFont());

    LookAndFeelTweaks.makeBold(titleLabel);
    LookAndFeelTweaks.makeMultilineLabel(subtitleLabel);
    LookAndFeelTweaks.htmlize(subtitleLabel);

    iconLabel = new JLabel();
    iconLabel.setPreferredSize(new Dimension(50, 50));

    setLayout(new BorderLayout());

    JPanel nestedPane = new JPanel(new BorderLayout());
    nestedPane.setOpaque(false);
    nestedPane.add("North", titleLabel);
    nestedPane.add("Center", subtitleLabel);
    add("Center", nestedPane);
    add("East", iconLabel);
  }

  public void setTitleColor(Color color) {
    titleLabel.setForeground(color);
  }

  public Color getTitleColor() {
    return titleLabel.getForeground();
  }
  
  public void setSubtitleColor(Color color) {
    subtitleLabel.setForeground(color);
  }
  
  public Color getSubtitleColor() {
    return subtitleLabel.getForeground();
  }
  
  public void setTitle(String title) {
    titleLabel.setText(title);
  }

  public String getTitle() {
    return titleLabel.getText();
  }
  
  public void setSubtitle(String subtitle) {
    subtitleLabel.setText(subtitle);
  }
  
  public String getSubtitle() {
    return subtitleLabel.getText();
  }
  
  public void setSubtitleVisible(boolean b) {
    subtitleLabel.setVisible(b);
  }
  
  public boolean isSubtitleVisible() {
    return subtitleLabel.isVisible();
  }
  
  public void setIcon(Icon icon) {
    iconLabel.setIcon(icon);
  }
  
  public Icon getIcon() {
    return iconLabel.getIcon();
  }
  
  public void setIconVisible(boolean b) {
    iconLabel.setVisible(b);
  }
  
  public boolean isIconVisible() {
    return iconLabel.isVisible();
  }
  
}
