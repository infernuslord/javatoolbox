package multivalent.std.adaptor;

/**
	@version $Revision: 1.2 $ $Date: 2002/02/01 08:56:39 $
*/
public class ArchiveFileEntry {
  public static final String UNKNOWN="???", DIR="dir", TXT="txt", BIN="bin";

  /** Filename as found in archive. */
  public String filename;

  /** Normalized filename -- no HTML meta characters (but space OK), perhaps suffix added if computed somehow. */
  public String normal;

  /** Type-dependent permissions. */
  public int permissions;

  /** File type, taken from constants in this class if possible. */
  public String type;

  /** Length in bytes. */
  public long length;

  /** Length in archive (often compressed). */
  public long alength;

  /** Byte offset of file within archive. */
  public long offset;

  /** Creation time in UNIX-style seconds since 1970.  -1 if not known. */
  public long create;

  /** Creation time in UNIX-style seconds since 1970.  -1 if not known. */
  public long lastmod;

  /** CRC or other checksum. */
  public long checksum;


  public ArchiveFileEntry(String filename, int permissions, String type, long length, long alength, long offset, long create, long lastmod) {
	this.filename=filename; this.permissions=permissions; this.type=type;
	this.length=length; this.alength=length; this.offset=offset;
	this.create=create; this.lastmod=lastmod;

	// strip HTML and UNIX meta
	StringBuffer fsb = new StringBuffer(filename);
	for (int i=0,imax=fsb.length(); i<imax; i++) {
		char ch=fsb.charAt(i);
		if (" '#&<>\"/".indexOf(ch)!=-1) fsb.setCharAt(i, '_');
	}
	//if (filename.indexOf('.')==-1 && type!=UNKNOWN) fsb.append('.').append(type); -- medium decides this
	normal = fsb.substring(0);
  }

  public String toString() {
	return filename;
  }
}
