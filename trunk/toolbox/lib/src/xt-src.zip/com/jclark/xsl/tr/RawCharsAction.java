// $Id: RawCharsAction.java,v 1.1 2002/04/25 18:18:59 bill Exp $

package com.jclark.xsl.tr;

import com.jclark.xsl.om.*;

/**
 *
 */
class RawCharsAction implements Action
{
    private String chars;
    RawCharsAction(String chars)
    {
        this.chars = chars;
    }

    public void invoke(ProcessContext context, 
                       Node sourceNode, Result result) 
        throws XSLException
    {
        result.rawCharacters(chars);
    }
}

