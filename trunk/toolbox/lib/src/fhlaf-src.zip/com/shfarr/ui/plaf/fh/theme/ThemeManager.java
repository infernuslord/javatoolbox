/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh.theme;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileSystemView;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Iterator;

import com.shfarr.io.IOUtils;
import com.shfarr.ui.LabelComponentGroup;
import com.shfarr.ui.layouts.MaxLayout;
import com.shfarr.ui.layouts.QueueLayout;
import com.shfarr.ui.plaf.fh.FhLookAndFeel;
import com.shfarr.ui.plaf.fh.FhRootPaneUI;
import com.shfarr.ui.plaf.fh.theme.edit.*;


public class ThemeManager implements ActionListener, ChangeListener{
    public static final String[] BUILT_IN_THEMES = {"Classic ( built in )", "Flat ( built in )", "Flat with shadows ( built in )"};
    
    protected static ThemeManager currentManager = null;

    protected JPanel contentPane = null;
    protected JPanel aboutPanel = null;
    protected JPanel generalPanel = null;
    protected Theme currentTheme = null;
    protected Preferences preferences = null; 
    private JTextField themeDirectoryField = null;
    private JComboBox themeCombo = null;
    private JCheckBox manageIconsCheck = null;
    private JCheckBox smoothText = null;
    private JCheckBox paintLargeTextures = null;
    private JCheckBox paintSmallTextures = null;
    private JPanel accessibility = null;
    private JSlider fontAdjustment = null;
    private JSlider brightnessAdjustment = null;
    private JSlider contrastAdjustment = null;
    private JSlider saturationAdjustment = null;
    private JCheckBox strengthenFonts = null;
    private JCheckBox strengthenBorders = null;
    private JPanel licensePanel = null;
    private JPanel helpPanel = null;
    private JTabbedPane tabPane = null;
    private JEditorPane editor = null;
    private JPanel adjustmentPanel = null;
    private JCheckBox usingCustomBaseColor = null; 
    private JPanel customColorChooser = null;
    private JButton customColorChooserButton = null;
    private JFrame frame = null;
    private JDialog dialog = null; 
    private String[] tabTitles = {"About", "General", "Behaviour", "Accessibility", "Theme Editor", "License"};
    private boolean updateNeeded = false;
    private JButton okButton = null;
    private JButton cancelButton = null;
    private JButton applyButton = null;
    
    private ThemeManager(){
    }
    
    protected JPanel getAboutPanel(){
      if(aboutPanel==null){
          aboutPanel = new JPanel(new BorderLayout(5, 5));
          aboutPanel.setOpaque(true);
          aboutPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
          aboutPanel.add(new JLabel(new ImageIcon(ClassLoader.getSystemResource("fhlaf resources/fhbig.png"))), "West");
      }
      
      return aboutPanel;
    }
  
    protected JPanel getHelpPanel(){
        if(helpPanel == null){
            helpPanel = new JPanel(new BorderLayout());
            helpPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            
            try{
                editor = new JEditorPane(ClassLoader.getSystemResource("fhlaf resources/help.html"));
                editor.setEditable(false);
                JScrollPane sp = new JScrollPane(editor);
                sp.setPreferredSize(new Dimension(100, 100));

                helpPanel.add(sp, "Center");
            }
            catch(Exception e){
            }
        }

        return helpPanel;
    }

    protected JPanel getLicensePanel(){
        if(licensePanel == null){
            licensePanel = new JPanel(new BorderLayout());
            licensePanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            
            try{
                editor = new JEditorPane(ClassLoader.getSystemResource("fhlaf resources/license.html"));
                editor.setEditable(false);
                JScrollPane sp = new JScrollPane(editor);
                sp.setPreferredSize(new Dimension(100, 100));

                licensePanel.add(sp, "Center");
            }
            catch(Exception e){
            }
        }

        return licensePanel;
    }
    
    protected JButton getOkButton(){
        if(okButton == null){
            okButton = new JButton("Ok");
            okButton.addActionListener(this);
            okButton.setDisplayedMnemonicIndex(0);
            okButton.setMnemonic('o');
        }
        
        return okButton;
    }
    
    protected JButton getApplyButton(){
        if(applyButton == null){
            applyButton = new JButton("Apply");
            applyButton.addActionListener(this);
            applyButton.setDisplayedMnemonicIndex(0);
            applyButton.setMnemonic('a');
        }
        
        return applyButton;
    }
    
    protected JButton getCancelButton(){
        if(cancelButton == null){
            cancelButton = new JButton("Cancel");
            cancelButton.addActionListener(this);
            cancelButton.setDisplayedMnemonicIndex(0);
            cancelButton.setMnemonic('c');
        }
        
        return cancelButton;
    }
    
    protected JComponent getContentPane(){
      if(contentPane==null){
         JPanel buttonPane = new JPanel(new QueueLayout(4, QueueLayout.HORIZONTAL, QueueLayout.STRECH_COMPONENTS));
            buttonPane.setBorder(new EmptyBorder(3, 3, 3, 2));
            buttonPane.add(getApplyButton(), QueueLayout.END);
            buttonPane.add(getOkButton(), QueueLayout.END);
          	buttonPane.add(getCancelButton(), QueueLayout.END);
         
         tabPane = new JTabbedPane();
         
         tabPane.addTab(tabTitles[0], getAboutPanel());
         tabPane.addTab(tabTitles[1], getGeneralPanel());
         tabPane.addTab(tabTitles[2], getAdJustmentPanel());
         tabPane.addTab(tabTitles[3], getAccessibility());
         tabPane.addTab(tabTitles[4], ThemeEditor.instance());
         tabPane.addTab(tabTitles[5], getLicensePanel());

         contentPane = new JPanel(new BorderLayout());
         contentPane.add(tabPane, "Center");
         contentPane.add(buttonPane, "South");
      }
      
      return contentPane;
    }

    protected JCheckBox getStrengthenFonts(){
        if(strengthenFonts == null){
            strengthenFonts = new JCheckBox("All fonts are bold", getPreferences().isStrengthenFonts());
            strengthenFonts.setBorder(new EmptyBorder(0, 1, 0, 0));
            strengthenFonts.setActionCommand("Change Occured");
            strengthenFonts.addActionListener(this);
        }
    
        return strengthenFonts;
    }
    
    protected JCheckBox getStrengthenBorders(){
        if(strengthenBorders == null){
            strengthenBorders = new JCheckBox("Duplicate borders", getPreferences().isBordersDoubled());
            strengthenBorders.setBorder(new EmptyBorder(0, 1, 0, 0));
        }
    
        return strengthenBorders;
    }

    protected JSlider getFontAdjustment(){
        if(fontAdjustment == null){
            fontAdjustment = new JSlider();
            fontAdjustment.setMinimum(0);
            fontAdjustment.setMajorTickSpacing(100);
            fontAdjustment.setMinorTickSpacing(5);
            fontAdjustment.setSnapToTicks(true);
            fontAdjustment.setPaintTicks(true);
            fontAdjustment.setPaintLabels(true);
            fontAdjustment.setMaximum(300);
            fontAdjustment.setValue(getPreferences().getFontSizeAdjustment());
            fontAdjustment.addChangeListener(this);
        }
    
        return fontAdjustment;
    }

    protected JSlider getContrastAdjustment(){
        if(contrastAdjustment == null){
            contrastAdjustment = new JSlider();
            contrastAdjustment.setMinimum(-50);
            contrastAdjustment.setMajorTickSpacing(25);
            contrastAdjustment.setMinorTickSpacing(5);
            contrastAdjustment.setSnapToTicks(true);
            contrastAdjustment.setPaintTicks(true);
            contrastAdjustment.setPaintLabels(true);
            contrastAdjustment.setMaximum(50);
            contrastAdjustment.setValue(getPreferences().getContrast());
            contrastAdjustment.addChangeListener(this);
        }
    
        return contrastAdjustment;
    }

    protected JSlider getBrightnessAdjustment(){
        if(brightnessAdjustment == null){
            brightnessAdjustment = new JSlider();
            brightnessAdjustment.setMinimum(-50);
            brightnessAdjustment.setMajorTickSpacing(25);
            brightnessAdjustment.setMinorTickSpacing(5);
            brightnessAdjustment.setSnapToTicks(true);
            brightnessAdjustment.setPaintTicks(true);
            brightnessAdjustment.setPaintLabels(true);
            brightnessAdjustment.setMaximum(50);
            brightnessAdjustment.setValue(getPreferences().getBrightness());
            brightnessAdjustment.addChangeListener(this);
        }
    
        return brightnessAdjustment;
    }
    
    protected JSlider getSaturationAdjustment(){
        if(saturationAdjustment == null){
            saturationAdjustment = new JSlider();
            saturationAdjustment.setMinimum(0);
            saturationAdjustment.setMajorTickSpacing(25);
            saturationAdjustment.setMinorTickSpacing(5);
            saturationAdjustment.setSnapToTicks(true);
            saturationAdjustment.setPaintTicks(true);
            saturationAdjustment.setPaintLabels(true);
            saturationAdjustment.setMaximum(100);
            saturationAdjustment.setValue(getPreferences().getSaturation());
            saturationAdjustment.addChangeListener(this);
        }
    
        return saturationAdjustment;
    }

    public JCheckBox getUsingCustomBaseColor() {
        if(usingCustomBaseColor == null) {
            usingCustomBaseColor = new JCheckBox("Use Custom Base Color", getPreferences().isUsingCustomBaseColor());
            usingCustomBaseColor.setBorder(new EmptyBorder(0, 1, 0, 0));
            usingCustomBaseColor.setActionCommand("use custom color");
            usingCustomBaseColor.addActionListener(this);
        }
        
        return usingCustomBaseColor;
    }

    protected JButton getCustomColorChooserButton(){
        if(customColorChooserButton == null){
            customColorChooserButton = new JButton("Select Custom Color");
            customColorChooserButton.addActionListener(this);
            customColorChooserButton.setActionCommand("choose custom color");
            customColorChooserButton.setRolloverEnabled(true);
            customColorChooserButton.setEnabled(getPreferences().isUsingCustomBaseColor());
        }
        
        if(getPreferences().getCustomBaseColor() != null) customColorChooser.setBackground(getPreferences().getCustomBaseColor());
            
        return customColorChooserButton;
    }

    protected JPanel getCustomColorChooser(){
        if(customColorChooser == null){
            customColorChooser = new JPanel();
            customColorChooser.setPreferredSize(new Dimension(100, 24));
            customColorChooser.setBorder(new CompoundBorder(new MatteBorder(0, 1, 0, 5, getContentPane().getBackground()), new MatteBorder(2, 2, 2, 2, Color.black)));
        }
        
        if(getPreferences().getCustomBaseColor() != null) customColorChooser.setBackground(getPreferences().getCustomBaseColor());
            
        return customColorChooser;
    }
    
    protected JPanel getAdJustmentPanel(){
        if(adjustmentPanel == null){
            adjustmentPanel = new JPanel(new BorderLayout());
            adjustmentPanel.setBorder(new EmptyBorder(30, 30, 30, 30));
            
            JPanel panel = new JPanel(new BorderLayout());
            panel.add(getCustomColorChooser(), "Center");
            panel.add(getCustomColorChooserButton(), "East");
            
            JPanel panelTop = new JPanel(new MaxLayout());
            panelTop.add(new LabelComponentGroup(new String[]{"", "", "", " Base Color Saturation", "", "", "", "", ""},
                                                 new Component[]{getUsingCustomBaseColor(), panel, new JLabel(), getSaturationAdjustment(), new JLabel(), getManageIconsCheck(), getSmoothText(), getPaintLargeTextures(), getPaintSmallTextures()},
                                                 LabelComponentGroup.TOP));

            adjustmentPanel.add(panelTop, "North");
        }
    
        return adjustmentPanel;
    }

    protected JPanel getAccessibility(){
        if(accessibility == null){
            accessibility = new JPanel(new BorderLayout());
            accessibility.setBorder(new EmptyBorder(30, 30, 30, 30));
            
            JPanel panel = new JPanel(new QueueLayout(4, QueueLayout.HORIZONTAL, QueueLayout.STRECH_COMPONENTS));
            // panel.add(getStrengthenBorders());
            panel.add(getStrengthenFonts());
            
            JPanel panelTop = new JPanel(new MaxLayout());
            panelTop.add(new LabelComponentGroup(new String[]{"", "", " Font Size Adjustment ( % )", "", " Brighness", " Contrast"},
                                                 new Component[]{panel , new JLabel(), getFontAdjustment(), new JLabel(), getBrightnessAdjustment(), getContrastAdjustment()},
                                                 LabelComponentGroup.TOP));

            accessibility.add(panelTop, "North");
        }
    
        return accessibility;
    }
    
    protected JCheckBox getPaintSmallTextures(){
        if(paintSmallTextures == null){
            paintSmallTextures = new JCheckBox("Paint Small Textures", getPreferences().isSmallTexturesPainted());
            paintSmallTextures.setBorder(new EmptyBorder(0, 1, 0, 0));
            paintSmallTextures.setActionCommand("Change Occured");
            paintSmallTextures.addActionListener(this);
        }
    
        return paintSmallTextures;
    }

    protected JCheckBox getPaintLargeTextures(){
        if(paintLargeTextures == null){
            paintLargeTextures = new JCheckBox("Paint Large Textures", getPreferences().isLargeTexturesPainted());
            paintLargeTextures.setBorder(new EmptyBorder(0, 1, 0, 0));
            paintLargeTextures.setActionCommand("Change Occured");
            paintLargeTextures.addActionListener(this);
        }
    
        return paintLargeTextures;
    }

    protected JCheckBox getSmoothText(){
        if(smoothText == null){
            smoothText = new JCheckBox("Smooth Text Edges", getPreferences().isAntialiasingTexts());
            smoothText.setBorder(new EmptyBorder(0, 1, 0, 0));
            smoothText.setActionCommand("Change Occured");
            smoothText.addActionListener(this);
        }
    
        return smoothText;
    }

    protected JCheckBox getManageIconsCheck(){
        if(manageIconsCheck == null){
            manageIconsCheck = new JCheckBox("Manage Button Icons", getPreferences().isManageButtonIcons());
            manageIconsCheck.setBorder(new EmptyBorder(0, 1, 0, 0));
            manageIconsCheck.setActionCommand("Change Occured");
            manageIconsCheck.addActionListener(this);
        }
    
        return manageIconsCheck;
    }
    
    protected JTextField getThemeDirectoryField(){
        if(themeDirectoryField == null){
            themeDirectoryField = new JTextField(getPreferences().getThemeDirectory());
        }
    
        return themeDirectoryField;
    }  

    protected JComboBox getThemeCombo(){
        if(themeCombo == null){
            themeCombo = new JComboBox();
            updateThemeCombo();
        }
    
        return themeCombo;
    }
    
    public void updateThemeCombo(){
        getThemeCombo().removeActionListener(this);
        
        getThemeCombo().removeAllItems();
        
        for(int i = 0; i < BUILT_IN_THEMES.length; i++) getThemeCombo().addItem(BUILT_IN_THEMES[i]);
        
        if(getPreferences().getThemeDirectory() != null){
            String[] themes = new File(getPreferences().getThemeDirectory()).list();
            
            if(themes != null){
                LOAD: for(int i = 0; i < themes.length; i++){
                    for(int k = 0; k < getThemeCombo().getItemCount(); k++) if(getThemeCombo().getItemAt(k).equals(themes[i])) continue LOAD;
                    getThemeCombo().addItem(themes[i]);
                }
            }
        }

        getThemeCombo().setSelectedItem(getPreferences().getCurrentTheme() == null ? themeCombo.getItemAt(0) : getPreferences().getCurrentTheme());
        getThemeCombo().setActionCommand("Change Theme");
        
        getThemeCombo().addActionListener(this);
    }
    
    protected JPanel getGeneralPanel(){
        if(generalPanel == null){
            generalPanel = new JPanel(new BorderLayout());
            generalPanel.setBorder(new EmptyBorder(30, 15, 15, 30));
            
            getThemeDirectoryField().setPreferredSize(new Dimension(200, getThemeDirectoryField().getPreferredSize().height));

            JPanel aPanel = new JPanel(new BorderLayout());
            aPanel.add(getThemeDirectoryField(), "Center");
            
            JButton button = new JButton("...");
            button.addActionListener(this);
            button.setActionCommand("browse theme dir");
            button.setMargin(new Insets(1, 1, 1, 1));
            button.setPreferredSize(new Dimension(getThemeDirectoryField().getPreferredSize().height +2, getThemeDirectoryField().getPreferredSize().height));
            aPanel.add(button, "East");
            
            JButton newTheme = new JButton("New Theme");
            newTheme.addActionListener(this);
            
            JButton customizeTheme = new JButton("Customize Theme");
            customizeTheme.addActionListener(this);
            
                        
            LabelComponentGroup group = new LabelComponentGroup(new String[]{"Extarnal Theme Directory", "", "Current Theme", "", "", "", "", "", "", ""},
                                                                new JComponent[]{aPanel, new JLabel(), getThemeCombo(), new JLabel(), new JLabel(getCurrentTheme().getDescription()), new JLabel("Version: " +getCurrentTheme().getVersion()), new JLabel("Author: " +getCurrentTheme().getAuthor()), new JLabel(), newTheme, customizeTheme},
                                                                LabelComponentGroup.LEFT);
            
            generalPanel.add(group, "North");
        }
    
        return generalPanel;
    }
    
    public static ThemeManager instance(){
        if(currentManager == null) currentManager = new ThemeManager();
        
        return currentManager;
    }
  
    public void launch(JComponent jc, JFrame frame){
        this.frame = frame;
        
        if(editor != null) editor.setPreferredSize(new Dimension(100, 100));
    
        getThemeCombo().setSelectedItem(getPreferences().getCurrentTheme() == null ? themeCombo.getItemAt(0) : getPreferences().getCurrentTheme());
        getSmoothText().setSelected(getPreferences().isAntialiasingTexts());
        getPaintSmallTextures().setSelected(getPreferences().isSmallTexturesPainted());
        getPaintLargeTextures().setSelected(getPreferences().isLargeTexturesPainted());
        getThemeDirectoryField().setText(getPreferences().getThemeDirectory());
        getManageIconsCheck().setSelected(getPreferences().isManageButtonIcons());
        getFontAdjustment().setValue(getPreferences().getFontSizeAdjustment());
        getBrightnessAdjustment().setValue(getPreferences().getBrightness());
        getContrastAdjustment().setValue(getPreferences().getContrast());
        getSaturationAdjustment().setValue(getPreferences().getSaturation());
        getStrengthenFonts().setSelected(getPreferences().isStrengthenFonts());
        getStrengthenBorders().setSelected(getPreferences().isBordersDoubled());
        getUsingCustomBaseColor().setSelected(getPreferences().isUsingCustomBaseColor());
        getCustomColorChooser().setEnabled(getUsingCustomBaseColor().isSelected());
      
        if(!getPreferences().isLicenseViewed()){
            tabPane.setSelectedIndex(tabTitles.length -1);
            tabPane.addChangeListener(this);
        }
        
        setUpdateNeeded(false);
        
        if(frame == null){
            final JDialog dialog = SwingUtilities.windowForComponent(jc) instanceof Frame ?
                                   new JDialog((Frame)SwingUtilities.windowForComponent(jc), " ::: L&F Control center :::", true) :
                                   new JDialog((Dialog)SwingUtilities.windowForComponent(jc), " ::: L&F Control center :::", true);

            dialog.setContentPane(getContentPane());
            dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

            dialog.pack();
            dialog.setLocationRelativeTo(SwingUtilities.windowForComponent(jc));
      
            dialog.setVisible(true);
        }
        else{
            frame.setContentPane(getContentPane());
            frame.pack();

            frame.setVisible(true);
        }
    }
  
    public Theme getCurrentTheme(){
        if(currentTheme == null){
            try{
                currentTheme = new Theme(getPreferences().getCurrentTheme() == null ? themeCombo.getItemAt(0).toString() : getPreferences().getCurrentTheme());
            }
            catch(Exception e){
                try{
                    currentTheme = new Theme(BUILT_IN_THEMES[BUILT_IN_THEMES.length -1]);
                    
                    getPreferences().setCurrentTheme(currentTheme.getName());
                    // System.out.println("Unable to load the specified theme! Will use one of the built in themes.");
                    // TODO Oct 29, 2003: logging
                }
                catch(Exception ex){
                    System.out.println("Unable to load the default theme! System exits.");
                    System.exit(1);
                }
            }

            currentTheme.addChangeListener(this);
        }
        
        return currentTheme;
    }

    public Preferences getPreferences(){
        if(preferences == null){
            try{
                ObjectInputStream stream = new ObjectInputStream(new FileInputStream(getDirectoryName() +"/.properties"));
                preferences = (Preferences)stream.readObject();
                stream.close();
            }
            catch(Exception e){
            }
            
            if(preferences == null) preferences = new Preferences();
        }

        return preferences;
    }
    
    protected static void customize(Theme theme, String name){
        new File(ThemeManager.instance().getPreferences().getThemeDirectory() + "/" + name + "/icons").mkdirs();

        try{
            for(Iterator iter = theme.themeFiles().iterator(); iter.hasNext(); ) {
            	String file = (String)iter.next();
                IOUtils.save(IOUtils.load(theme.getResourceURL(file)), ThemeManager.instance().getPreferences().getThemeDirectory() + "/" + name + "/" + file);
            }
        }
        catch(Exception e){
        	e.printStackTrace();
        }
    }
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getActionCommand().equals("Change Occured")){
            setUpdateNeeded(true);
        }
        
        if(ae.getActionCommand().equals("Change Theme")){
            getPreferences().setCurrentTheme(getThemeCombo().getSelectedItem().toString());
            setUpdateNeeded(true);
        }
        
        if(ae.getActionCommand().equals("New Theme")){
            String name = JOptionPane.showInputDialog(SwingUtilities.windowForComponent(((JButton)ae.getSource())), "Theme Name", "New Theme");

            if(name != null){
                String theme = (String)JOptionPane.showInputDialog(SwingUtilities.windowForComponent(((JButton)ae.getSource())), "Choose one of the built in themes as start", "New Theme", JOptionPane.QUESTION_MESSAGE, null, BUILT_IN_THEMES, BUILT_IN_THEMES[0]);
                
                if(theme != null){
                    try{
                        customize(new Theme(theme), name);
                    }
                    catch(Exception e){
                    }
                }
            }
            
            updateThemeCombo();
            
            getThemeCombo().setSelectedItem(name);
            setUpdateNeeded(true);
        }
        
        if(ae.getActionCommand().equals("Customize Theme")) {
            String input = JOptionPane.showInputDialog(SwingUtilities.windowForComponent(((JButton)ae.getSource())), "Theme Name", "New Theme based on " + currentTheme.getName());
            if(input != null) customize(currentTheme, input);
            
            updateThemeCombo();
            
            getThemeCombo().setSelectedItem(input);
            setUpdateNeeded(true);
        }

        if(ae.getActionCommand().equals("use custom color")){
            getCustomColorChooserButton().setEnabled(getUsingCustomBaseColor().isSelected());
            setUpdateNeeded(true);
        }

        if(ae.getActionCommand().equals("choose custom color")){
            Color c = JColorChooser.showDialog(SwingUtilities.windowForComponent(((JButton)ae.getSource())), "Custom Color", getPreferences().getCustomBaseColor());
            
            if(c != null){
                getPreferences().setCustomBaseColor(c);
                getCustomColorChooser().setBackground(c);
                setUpdateNeeded(true);
            }
        }
        
        if(ae.getActionCommand().equals("browse theme dir")){
            JFileChooser chooser = new JFileChooser(getPreferences().getThemeDirectory());
            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

            if(chooser.showOpenDialog(SwingUtilities.windowForComponent(((JButton)ae.getSource()))) == JFileChooser.APPROVE_OPTION) getThemeDirectoryField().setText(chooser.getSelectedFile().getPath());

            return;    
        }
        
        if(ae.getActionCommand().equals("Ok") || ae.getActionCommand().equals("Apply")){
            currentTheme = null;
            
            getPreferences().setCurrentTheme(getThemeCombo().getSelectedItem().toString());
            getPreferences().setAntialiasingTexts(getSmoothText().isSelected());
            getPreferences().setSmallTexturesPainted(getPaintSmallTextures().isSelected());
            getPreferences().setLargeTexturesPainted(getPaintLargeTextures().isSelected());
            getPreferences().setThemeDirectory(getThemeDirectoryField().getText());
            getPreferences().setManageButtonIcons(getManageIconsCheck().isSelected());
            getPreferences().setFontSizeAdjustment(getFontAdjustment().getValue());
            getPreferences().setBrightness(getBrightnessAdjustment().getValue());
            getPreferences().setContrast(getContrastAdjustment().getValue());
            getPreferences().setSaturation(getSaturationAdjustment().getValue());
            getPreferences().setStrengthenFonts(getStrengthenFonts().isSelected());
            getPreferences().setBordersDoubled(getStrengthenBorders().isSelected());
            getPreferences().setUsingCustomBaseColor(getUsingCustomBaseColor().isSelected());
            
            try{
                new File(getDirectoryName()).mkdirs();
                
                ObjectOutputStream stream = new ObjectOutputStream(new FileOutputStream(getDirectoryName() + "/.properties"));
                stream.writeObject(getPreferences());
                stream.close();
            
                currentTheme = null;
                getCurrentTheme();

                update();
                
                setUpdateNeeded(false);
            }
            catch(Exception e){
            }
        }
        
        if(ae.getActionCommand().equals("Ok") || ae.getActionCommand().equals("Cancel")){
            Window window = SwingUtilities.windowForComponent((Component)ae.getSource());
            window.dispose();
        
            setUpdateNeeded(false);
        }
    }
    
    protected String getDirectoryName(){
        File file = FileSystemView.getFileSystemView().getHomeDirectory();
        
        if(file.getName().equalsIgnoreCase("desktop")) return file.getParent() + "/.fhlaf";
        else return file + "/.fhlaf";
    }
    
    protected void update(){
        if(!updateNeeded) return;
        
        try{
            UIManager.setLookAndFeel(new FhLookAndFeel());
        }
        catch(Exception e){
        }
        
        for(Iterator i = FhRootPaneUI.registeredWindows.iterator(); i.hasNext(); ){
            Container w = rootContainerForComponent((Component)i.next());

            if(w != null) SwingUtilities.updateComponentTreeUI(w);
            else i.remove();
        }
    }
    
    protected static Container rootContainerForComponent(Component aComponent){
        while(aComponent.getParent() != null){
            aComponent = aComponent.getParent();
            
            if(aComponent instanceof Window || aComponent instanceof Dialog) break;
        }
        
        return (Container)aComponent;
    }
    
    protected void setUpdateNeeded(boolean val){
        updateNeeded = val;
        
        if(updateNeeded){
            getOkButton().setEnabled(true);
            getCancelButton().setEnabled(true);
            getApplyButton().setEnabled(true);
        }
        else{
            getOkButton().setEnabled(false);
            getCancelButton().setEnabled(true);
            getApplyButton().setEnabled(false);
        }
        
        if(tabPane != null) tabPane.setEnabledAt(4, getCurrentTheme().isEditable());
        getCustomColorChooser().setBorder(new CompoundBorder(new MatteBorder(0, 1, 0, 5, getContentPane().getBackground()), new MatteBorder(2, 2, 2, 2, Color.black)));
    }
    
    public boolean probeSmallTextures(){
        return getPreferences().isSmallTexturesPainted();
    }

    public boolean probeLargeTextures(){
        return getPreferences().isLargeTexturesPainted();
    }
    
    public void probeAntialiasing(Graphics g){
        if(getPreferences().isAntialiasingTexts()) ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        else ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
    }

    public void stateChanged(ChangeEvent e){
        if(e.getSource() == tabPane){
            if(!getPreferences().isLicenseViewed()){
                int ans = JOptionPane.showConfirmDialog(SwingUtilities.windowForComponent(((JComponent)e.getSource())), "I have understand and accept the terms of the license agreement.", "Confirmation", JOptionPane.YES_NO_OPTION);
                if(ans == 0) getPreferences().setLicenseViewed(true);
                else{
                    System.exit(0);
                }
                
                tabPane.removeChangeListener(this);
            }
        }
        else setUpdateNeeded(true);
    }

    public static void main(String[] arguments) {
        try{
            UIManager.setLookAndFeel(com.shfarr.ui.plaf.fh.FhLookAndFeel.class.getName());
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        JFrame frame = new JFrame(" ::: L&F Control center :::");

        frame.addWindowListener(new WindowAdapter(){
                                    public void windowClosing(WindowEvent we){
                                        System.exit(1);
                                    }
                                });

        ThemeManager.instance().launch(null, frame);
    }
}
