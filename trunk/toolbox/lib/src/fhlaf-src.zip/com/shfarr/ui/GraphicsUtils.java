/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.FilteredImageSource;
import java.awt.image.ImageProducer;
import java.awt.image.RGBImageFilter;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.UIManager;

public class GraphicsUtils{
    public static final int ROTATE_0 = 0;
    public static final int ROTATE_90 = 1;
    public static final int ROTATE_180 = 2;
    public static final int ROTATE_270 = 3;

    public static BufferedImage createTextureImage(int[][] matrix, int rotation){
        matrix = rotateClockwise(matrix, rotation);

        if(matrix.length == 0 || matrix[0].length == 0) matrix = new int[][]{ {0}};

        BufferedImage image = new BufferedImage(matrix[0].length, matrix.length, BufferedImage.TYPE_INT_ARGB);

        for(int i = 0; i < matrix.length; i++)
            image.setRGB(0, i, matrix[0].length, 1, matrix[i], 0, matrix[i].length);

        return image;
    }

    public static Icon createColorIcon(Color c, int width, int height){
        BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics g = img.createGraphics();

        g.setColor(Color.white);
        g.fillRect(0, 0, width, height);

        g.setColor(Color.gray);
        g.drawRect(0, 0, width - 1, height - 1);

        GraphicsUtils.paintTiledBackground(g, new Rectangle(3, 2, width - 6, height - 4), 5);
        g.drawImage(GraphicsUtils.createColorImage(c, width - 6, height - 4), 3, 2, null);

        return new ImageIcon(img);
    }

    public static BufferedImage createColorImage(Color c, int width, int height){
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);

        int ci = c != null ? c.getRGB() : 0x00FFFFFF;

        for(int i = 0; i < width; i++){
            for(int k = 0; k < height; k++){
                image.setRGB(i, k, ci);
            }
        }

        return image;
    }

    public static ImageIcon applyFilter(ImageIcon ic, RGBImageFilter filter){
        Image img = ic.getImage();
        
        ImageProducer prod = new FilteredImageSource(img.getSource(), filter);
        Image grayImage = Toolkit.getDefaultToolkit().createImage(prod);

        return new ImageIcon(grayImage);
    }

    public static Image applyFilter(BufferedImage img, RGBImageFilter filter){

        ImageProducer prod = new FilteredImageSource(img.getSource(), filter);
        Image grayImage = Toolkit.getDefaultToolkit().createImage(prod);

        return grayImage;
    }

    public static BufferedImage createFilteredString(JComponent jc, Rectangle2D size, String string, boolean vertical){
        BufferedImage dest = new BufferedImage((int)size.getWidth(), (int)size.getHeight(), BufferedImage.TYPE_INT_ARGB);

        int[] empty = new int[dest.getWidth() * dest.getHeight()];
        for(int i = 0; i < empty.length; i++) empty[i] = jc.getForeground().getRGB() & 0x00FFFFFF;
        dest.setRGB(0, 0, dest.getWidth(), dest.getHeight(), empty, 0, dest.getWidth());

        Graphics2D g = (Graphics2D)dest.createGraphics();
        g.setFont(jc.getFont());

        int fontY = g.getFontMetrics().getAscent();

        g.setColor(jc.getForeground());

        Vector lines = new Vector();
        StringTokenizer st = new StringTokenizer(string, "\r\n", false);
        while(st.hasMoreTokens())
            lines.addElement(st.nextToken().trim());

        for(int k = 0; k < lines.size(); k++){
            int fontX = (dest.getWidth() - (int)(g.getFontMetrics().getStringBounds(lines.elementAt(k).toString(), g).getWidth())) / 2;
            g.drawString(lines.elementAt(k).toString(), fontX, fontY + k * jc.getFont().getSize());
        }

        return vertical ? rotate90(dest, 1) : dest;
    }

    public static int alpha(int color, double amount){
        return (0x00FFFFFF & color) | (0xFF000000 & (((int)(((color >> 24) & 0xFF) * amount)) << 24));
    }

    public static int brighter(int color, double factor){
        return channel(color, factor, factor, factor);
    }

    public static int darker(int color, double factor){
        return channel(color, -factor, -factor, -factor);
    }

    public static int desaturate(int color, double amount){
        amount = 1 - amount;

        int a = (color >> 24) & 0xFF;

        int r = ((color >> 16) & 0xff);
        int g = ((color >> 8) & 0xff);
        int b = (color & 0xff);

        double gray = 1.4488 * r + 1.25 * g + 0.55 * b;

        gray = gray * (255f / 828f);

        if(gray < 0) gray = 0;
        if(gray > 255) gray = 255;

        r = (int)(r > gray ? gray + (r - gray) * amount : gray - (gray - r) * amount);
        g = (int)(g > gray ? gray + (g - gray) * amount : gray - (gray - g) * amount);
        b = (int)(b > gray ? gray + (b - gray) * amount : gray - (gray - b) * amount);

        return (a << 24) | (r << 16) | (g << 8) | (b << 0);
    }
    
    public static int blend(int color, int base, double opacity){
        int ca = ((color >> 24) & 0xff);
        int cr = ((color >> 16) & 0xff);
        int cg = ((color >> 8) & 0xff);
        int cb = (color & 0xff);

        int ba = ((base >> 24) & 0xff);
        int br = ((base >> 16) & 0xff);
        int bg = ((base >> 8) & 0xff);
        int bb = (base & 0xff);
        
        return Math.max(0, ba + (int)((ca -ba)*opacity)) << 24 |
               Math.max(0, br + (int)((cr -br)*opacity)) << 16 |
               Math.max(0, bg + (int)((cg -bg)*opacity)) << 8  |
               Math.max(0, bb + (int)((cb -bb)*opacity));
    }
    
    public static int channel(int color, double rFactor, double gFactor, double bFactor){
        int a = (color >> 24) & 0xFF;
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = (color >> 0) & 0xFF;

        if(rFactor > 0) r += Math.min(255 * rFactor, 255 - r);
        else if(rFactor < 0) r -= Math.min( -255 * rFactor, r);

        if(gFactor > 0) g += Math.min(255 * gFactor, 255 - g);
        else if(gFactor < 0) g -= Math.min( -255 * gFactor, g);

        if(bFactor > 0) b += Math.min(255 * bFactor, 255 - b);
        else if(bFactor < 0) b -= Math.min( -255 * bFactor, b);

        return a << 24 | r << 16 | g << 8 | b << 0;
    }

    public static void drawDashedLine(double xs, double ys, double xe, double ye, boolean[] sequence, Graphics g){
        double decay = 0;
        if(xe - xs == 0) decay = Math.PI / 2 * (ye - ys < 0 ? 3 : 1);
        else if(ye - ys == 0) decay = xe - xs < 0 ? Math.PI : 0;
        else decay = Math.atan((ye - ys) / (xe - xs));

        double length = Math.sqrt((ye - ys) * (ye - ys) + (xe - xs) * (xe - xs)), xDecay = Math.cos(decay), yDecay = Math.sin(decay);

        for(int i = 0; i < (int)length; i++)
            if(sequence[i % sequence.length])
                    g.drawLine((int)(xs + i * xDecay), (int)(ys + i * yDecay), (int)(xs + i * xDecay), (int)(ys + i * yDecay));
    }

    public static boolean isAntialiasingEnabled(){
        return UIManager.getDefaults().get("Text.antialias") != null
               && UIManager.getDefaults().get("Text.antialias").toString().equals("true");
    }

    public static BufferedImage rotate90(BufferedImage src, int times){
        int w = src.getWidth(), h = src.getHeight();

        BufferedImage dest = new BufferedImage(times % 2 == 0 ? w : h, times % 2 == 0 ? h : w, BufferedImage.TYPE_INT_ARGB);

        switch(times){
            case 1:
                for(int i = 0; i < w; i++)
                    for(int j = 0; j < h; j++)
                        dest.setRGB(j, w - i - 1, src.getRGB(i, j));
                break;
            case 2:
                for(int i = 0; i < w; i++)
                    for(int j = 0; j < h; j++)
                        dest.setRGB(h - i - 1, w - j - 1, src.getRGB(i, j));
                break;
            case 3:
                for(int i = 0; i < w; i++)
                    for(int j = 0; j < h; j++)
                        dest.setRGB(h - j - 1, i, src.getRGB(i, j));
                break;

            default:
                dest = src;
        }

        return dest;
    }

    public static int[][] rotateClockwise(int[][] matrix, int rotation){
        if(matrix.length == 0 || matrix[0].length == 0) return matrix;

        int[][] newMatrix = new int[rotation % 2 == 0 ? matrix.length : matrix[0].length][rotation % 2 == 0 ? matrix[0].length
                                                                                                           : matrix.length];

        if(rotation == ROTATE_0) for(int i = 0; i < matrix.length; i++)
            for(int k = 0; k < matrix[0].length; k++)
                newMatrix[i][k] = matrix[i][k];
        else if(rotation == ROTATE_90) for(int i = 0; i < matrix.length; i++)
            for(int k = 0; k < matrix[0].length; k++)
                newMatrix[k][newMatrix[0].length - 1 - i] = matrix[i][k];
        else if(rotation == ROTATE_180) for(int i = 0; i < matrix.length; i++)
            for(int k = 0; k < matrix[0].length; k++)
                newMatrix[newMatrix.length - 1 - i][newMatrix[0].length - 1 - k] = matrix[i][k];
        else if(rotation == ROTATE_270) for(int i = 0; i < matrix.length; i++)
            for(int k = 0; k < matrix[0].length; k++)
                newMatrix[newMatrix.length - 1 - k][i] = matrix[i][k];

        return newMatrix;
    }

    public static String[][] rotateClockwise(String[][] matrix, int rotation){
        if(matrix.length == 0 || matrix[0].length == 0) return matrix;

        String[][] newMatrix = new String[rotation % 2 == 0 ? matrix.length : matrix[0].length]
                                         [rotation % 2 == 0 ? matrix[0].length : matrix.length];

        if(rotation == ROTATE_0) for(int i = 0; i < matrix.length; i++)
            for(int k = 0; k < matrix[0].length; k++)
                newMatrix[i][k] = matrix[i][k];
        else if(rotation == ROTATE_90) for(int i = 0; i < matrix.length; i++)
            for(int k = 0; k < matrix[0].length; k++)
                newMatrix[k][newMatrix[0].length - 1 - i] = matrix[i][k];
        else if(rotation == ROTATE_180) for(int i = 0; i < matrix.length; i++)
            for(int k = 0; k < matrix[0].length; k++)
                newMatrix[newMatrix.length - 1 - i][newMatrix[0].length - 1 - k] = matrix[i][k];
        else if(rotation == ROTATE_270) for(int i = 0; i < matrix.length; i++)
            for(int k = 0; k < matrix[0].length; k++)
                newMatrix[newMatrix.length - 1 - k][i] = matrix[i][k];

        return newMatrix;
    }

    public static void paintTiledBackground(Graphics g, Rectangle r, int step){
        int[] xs = new int[4];
        int[] ys = new int[4];

        Color paleGreen = new Color(220, 255, 220);

        Rectangle cb = g.getClipBounds();
        g.setClip(r);

        for(int i = 0; i < r.getWidth(); i += 2 * step){
            for(int k = 0; k < r.getHeight(); k += 2 * step){
                xs[0] = r.x + i + step;
                xs[1] = r.x + i + 2 * step;
                xs[2] = r.x + i + step;
                xs[3] = r.x + i;
                ys[0] = r.y + k + 0;
                ys[1] = r.y + k + step;
                ys[2] = r.y + k + 2 * step;
                ys[3] = r.y + k + step;

                g.setColor(Color.white);
                g.fillRect(r.x + i, r.y + k, 2 * step, 2 * step);

                g.setColor(paleGreen);
                g.fillPolygon(xs, ys, 4);

                g.setColor(Color.darkGray);
                g.drawPolygon(xs, ys, 4);
            }
        }

        g.setClip(cb);
    }
}
