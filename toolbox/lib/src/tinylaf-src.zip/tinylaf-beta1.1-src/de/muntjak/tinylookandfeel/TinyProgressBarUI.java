/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	Tiny Look and Feel                                                         *
*                                                                              *
*  (C) Copyright 2003, Hans Bickel                                             *
*                                                                              *
*   For licensing information and credits, please refer to the                 *
*   comment in file de.muntjak.tinylookandfeel.TinyLookAndFeel                 *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package de.muntjak.tinylookandfeel;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

import javax.swing.*;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicProgressBarUI;

import de.muntjak.tinylookandfeel.controlpanel.*;

/**
 * TinyProgressBarUI
 * 
 * @version 1.1
 * @author Hans Bickel
 */
public class TinyProgressBarUI extends BasicProgressBarUI {
	
	/*
	 * The offset of the filled bar. This amount of space will be added on the left and right of the progress bar
	 * to its borders.
	 */
	int offset = 1;

	/**
	 * Creates the UI delegate for the given component.
	 *
	 * @param mainColor The component to create its UI delegate.
	 * @return The UI delegate for the given component.
	 */
	public static ComponentUI createUI(JComponent c) {
		return new TinyProgressBarUI();
	}

	protected void paintDeterminate(Graphics g, JComponent c) {
		Insets b = progressBar.getInsets(); // area for border
		int barRectWidth = progressBar.getWidth() - (b.right + b.left);
		int barRectHeight = progressBar.getHeight() - (b.top + b.bottom);

		if (progressBar.getOrientation() == JProgressBar.HORIZONTAL) {
			int amountFull = getAmountFull(b, barRectWidth - 2 * offset, barRectHeight);

			switch(Theme.derivedStyle[Theme.style]) {
				case Theme.TINY_STYLE:
					drawTinyHorzProgress(g, barRectWidth, barRectHeight, amountFull);
					break;
				case Theme.WIN_STYLE:
					drawWinHorzProgress(g, barRectWidth, barRectHeight, amountFull);
					break;
				case Theme.XP_STYLE:
					drawXpHorzProgress(g, barRectWidth, barRectHeight, amountFull);
					break;
			}

			// Deal with possible text painting
			if (progressBar.isStringPainted()) {
				g.setFont(c.getFont());
				paintString(g, b.left, b.top, barRectWidth, barRectHeight, amountFull, b);
			}

		} else { // VERTICAL
			int amountFull = getAmountFull(b, barRectWidth, barRectHeight- 2 * offset);
			
			switch(Theme.derivedStyle[Theme.style]) {
				case Theme.TINY_STYLE:
					drawTinyVertProgress(g, barRectWidth, barRectHeight, amountFull);
					break;
				case Theme.WIN_STYLE:
					drawWinVertProgress(g, barRectWidth, barRectHeight, amountFull);
					break;
				case Theme.XP_STYLE:
					drawXpVertProgress(g, barRectWidth, barRectHeight, amountFull);
					break;
			}
			
			// Deal with possible text painting
			if (progressBar.isStringPainted()) {
				g.setFont(c.getFont());
				paintString(g, b.left, b.top, barRectWidth, barRectHeight, amountFull, b);
			}
		}
	}
	
	private void drawTinyHorzProgress(
		Graphics g, int barRectWidth, int barRectHeight, int amountFull)
	{
		
	}
	
	private void drawWinBorder(Graphics g, int bWidth, int bHeight) {
		g.setColor(Theme.progressTrackColor[Theme.style].getColor());
		g.fillRect(1, 1, bWidth - 1, bHeight - 1);
		
		g.setColor(Theme.progressDarkColor[Theme.style].getColor());
		g.drawLine(0, 0, bWidth - 1, 0);
		g.drawLine(0, 1, 0, bHeight - 1);
		
		g.setColor(Theme.progressLightColor[Theme.style].getColor());
		g.drawLine(bWidth - 1, 1, bWidth - 1, bHeight - 1);
		g.drawLine(1, bHeight - 1, bWidth - 1, bHeight - 1);
	}
	
	private void drawWinHorzProgress(
		Graphics g, int barRectWidth, int barRectHeight, int amountFull)
	{
		drawWinBorder(g, barRectWidth, barRectHeight);
		
		g.setColor(Theme.progressColor[Theme.style].getColor());		
		int h = barRectHeight - 4;
		int x = 2;
		while(x < amountFull) {
			g.fillRect(x, 2, Math.min(6, barRectWidth - x - 3), h);
			x += 8;
		}
	}
	
	private void drawXPBorder(Graphics g, int bWidth, int bHeight) {
		g.setColor(Theme.progressTrackColor[Theme.style].getColor());
		g.fillRect(1, 1, bWidth - 1, bHeight - 1);	
			
		DrawRoutines.drawRoundedBorder(
			g, Theme.progressBorderColor[Theme.style].getColor(), 0, 0, bWidth, bHeight);
			
		DrawRoutines.drawRoundedBorder(
			g, Theme.progressDarkColor[Theme.style].getColor(),
			1, 1, bWidth - 2, bHeight - 2);
			
		DrawRoutines.drawRoundedBorder(
			g, Theme.progressLightColor[Theme.style].getColor(),
			2, 2, bWidth - 4, bHeight - 4);
	}
	
	private void drawXpHorzProgress(
		Graphics g, int barRectWidth, int barRectHeight, int amountFull)
	{
		drawXPBorder(g, barRectWidth, barRectHeight);

		g.setColor(Theme.progressColor[Theme.style].getColor());
		int y = (barRectHeight - 6) / 2;
		int x = 3;
		while(x < amountFull) {
			g.fillRect(x, y, Math.min(6, barRectWidth - x - 3), 6);
			x += 8;
		}
	}
	
	private void drawTinyVertProgress(
		Graphics g, int barRectWidth, int barRectHeight, int amountFull)
	{
		
	}
	
	private void drawWinVertProgress(
		Graphics g, int barRectWidth, int barRectHeight, int amountFull)
	{
		drawWinBorder(g, barRectWidth, barRectHeight);
		
		g.setColor(Theme.progressColor[Theme.style].getColor());
		int w = barRectWidth - 4;
		int y = 8;
		while(y < amountFull) {
			g.fillRect(2, barRectHeight - y, w, 6);
			y += 8;
		}		
	}
	
	private void drawXpVertProgress(
		Graphics g, int barRectWidth, int barRectHeight, int amountFull)
	{
		drawXPBorder(g, barRectWidth, barRectHeight);
		
		g.setColor(Theme.progressColor[Theme.style].getColor());
		int x = (barRectWidth - 6) / 2;
		int y = 9;
		while(y < amountFull) {
			g.fillRect(x, barRectHeight - y, 6, 6);
			y += 8;
		}		
	}
	
    protected void paintIndeterminate(Graphics g, JComponent c) {
		Insets b = progressBar.getInsets(); // area for border
		int barRectWidth = progressBar.getWidth() - (b.right + b.left);
		int barRectHeight = progressBar.getHeight() - (b.top + b.bottom);

		// this is a hack to hide a bug in BasicProgressBarUI
		Rectangle boxRect = null;
		try {
			boxRect = getBox(null);
		} catch(NullPointerException ex) {
			return;
		}
        
		if (progressBar.getOrientation() == JProgressBar.HORIZONTAL) {
			switch(Theme.derivedStyle[Theme.style]) {
				case Theme.TINY_STYLE:
					drawTinyHorzProgress(g, barRectWidth, barRectHeight, boxRect);
					break;
				case Theme.WIN_STYLE:
					drawWinHorzProgress(g, barRectWidth, barRectHeight, boxRect);
					break;
				case Theme.XP_STYLE:
					drawXpHorzProgress(g, barRectWidth, barRectHeight, boxRect);
					break;
			}
		} else {
			switch(Theme.derivedStyle[Theme.style]) {
				case Theme.TINY_STYLE:
					drawTinyVertProgress(g, barRectWidth, barRectHeight, boxRect);
					break;
				case Theme.WIN_STYLE:
					drawWinVertProgress(g, barRectWidth, barRectHeight, boxRect);
					break;
				case Theme.XP_STYLE:
					drawXpVertProgress(g, barRectWidth, barRectHeight, boxRect);
					break;
			}
		}
		
		// Deal with possible text painting
		if (progressBar.isStringPainted()) {
            if (progressBar.getOrientation() == JProgressBar.HORIZONTAL) {
                paintString(g, b.left, b.top,
                            barRectWidth, barRectHeight,
                            boxRect.x, boxRect.width, b);
            }
            else {
                paintString(g, b.left, b.top,
                            barRectWidth, barRectHeight,
                            boxRect.y, boxRect.height, b);
            }
        }
    }
    
    private void paintString(Graphics g, int x, int y, int width, int height,
                             int fillStart, int amountFull, Insets b) {
        if (!(g instanceof Graphics2D)) {
            return;
        }

        Graphics2D g2 = (Graphics2D)g;
		String progressString = progressBar.getString();
		g2.setFont(progressBar.getFont());
		Point renderLocation = getStringPlacement(g2, progressString,
							  x, y, width, height);
		Rectangle oldClip = g2.getClipBounds();
		
		if (progressBar.getOrientation() == JProgressBar.HORIZONTAL) {
		    g2.setColor(getSelectionBackground());
		    g2.drawString(progressString, renderLocation.x, renderLocation.y);
		    g2.setColor(getSelectionForeground());
	            g2.clipRect(fillStart, y, amountFull, height);
		    g.drawString(progressString, renderLocation.x, renderLocation.y);
		} else { // VERTICAL
		    g2.setColor(getSelectionBackground());
	            AffineTransform rotate =
	                    AffineTransform.getRotateInstance(Math.PI/2);
	            g2.setFont(progressBar.getFont().deriveFont(rotate));
		    renderLocation = getStringPlacement(g2, progressString,
							  x, y, width, height);
		    g2.drawString(progressString, renderLocation.x, renderLocation.y);
		    g2.setColor(getSelectionForeground());
		    g2.clipRect(x, fillStart, width, amountFull);
		    g2.drawString(progressString, renderLocation.x, renderLocation.y);
		}
		g2.setClip(oldClip);
    }
    
    private void drawTinyHorzProgress(
		Graphics g, int barRectWidth, int barRectHeight, Rectangle boxRect)
	{
		
	}
	
	private void drawWinHorzProgress(
		Graphics g, int barRectWidth, int barRectHeight, Rectangle boxRect)
	{
		drawWinBorder(g, barRectWidth, barRectHeight);
		
		g.translate(boxRect.x,boxRect.y);
		g.setColor(Theme.progressColor[Theme.style].getColor());
		
		int h = barRectHeight - 4;
		int x = 0;
		while(x + 6 < boxRect.width) {
			g.fillRect(x, 2, 6, h);
			x += 8;
		}

		g.translate(-boxRect.x,-boxRect.y );
	}
	
	private void drawXpHorzProgress(
		Graphics g, int barRectWidth, int barRectHeight, Rectangle boxRect)
	{
		drawXPBorder(g, barRectWidth, barRectHeight);
		
		g.translate(boxRect.x,boxRect.y);
		g.setColor(Theme.progressColor[Theme.style].getColor());
		int y = (barRectHeight - 6) / 2;
		int x = 0;
		while(x + 6 < boxRect.width) {
			g.fillRect(x, y, 6, 6);
			x += 8;
		}

		g.translate(-boxRect.x,-boxRect.y );
	}
	
	private void drawTinyVertProgress(
		Graphics g, int barRectWidth, int barRectHeight, Rectangle boxRect)
	{
		
	}
	
	private void drawWinVertProgress(
		Graphics g, int barRectWidth, int barRectHeight, Rectangle boxRect)
	{
		drawWinBorder(g, barRectWidth, barRectHeight);
		
		g.translate(boxRect.x,boxRect.y);		
		g.setColor(Theme.progressColor[Theme.style].getColor());
		int w = barRectWidth - 4;
		int y = 0;
		while(y  + 6 < boxRect.height) {
			g.fillRect(2, y, w, 6);
			y += 8;
		}

		g.translate(-boxRect.x,-boxRect.y );
	}
	
	private void drawXpVertProgress(
		Graphics g, int barRectWidth, int barRectHeight, Rectangle boxRect)
	{
		drawXPBorder(g, barRectWidth, barRectHeight);
		
		g.translate(boxRect.x,boxRect.y);		
		g.setColor(Theme.progressColor[Theme.style].getColor());
		int x = (barRectWidth - 6) / 2;
		int y = 0;
		while(y  + 6 < boxRect.height) {
			g.fillRect(x, y, 6, 6);
			y += 8;
		}

		g.translate(-boxRect.x,-boxRect.y );
	}
	
	/**
	 * @see javax.swing.plaf.ComponentUI#update(java.awt.Graphics, javax.swing.JComponent)
	 */
	public void update(Graphics g, JComponent c) {
		paint(g, c);
	}
	
	protected Color getSelectionForeground() {
		return Theme.progressSelectForeColor[Theme.style].getColor();
    }
    
    protected Color getSelectionBackground() {
		return Theme.progressSelectBackColor[Theme.style].getColor();
    }
	
    protected void installDefaults() {
		LookAndFeel.installColorsAndFont(progressBar,
			 "ProgressBar.background",
			 "ProgressBar.foreground",
			 "ProgressBar.font");
    }
}