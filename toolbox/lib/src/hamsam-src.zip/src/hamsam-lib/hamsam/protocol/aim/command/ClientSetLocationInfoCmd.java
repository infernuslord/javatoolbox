/*
 * Created on Aug 4, 2003
 *
 * To change this generated comment go to
 * Window>Preferences>Java>Code Generation>Code Template
 */
package hamsam.protocol.aim.command;

import java.io.IOException;
import java.io.OutputStream;

import hamsam.protocol.aim.flap.*;

import hamsam.protocol.aim.snac.*;

import hamsam.protocol.aim.util.*;


/**
 * @author mikem
 */
public class ClientSetLocationInfoCmd extends Command {

    private static final byte[] CAPABILITIES = { 0x09, 0x46, 0x13, 0x4B, 0x4C, 0x7F, 0x11, (byte)0xD1, 
                                                (byte)0x82, 0x22, 0x44, 0x45, 0x53, 0x54, 0x00, 0x00, 
                                                
                                                 0x09, 0x46, 0x13, 0x45, 0x4C, 0x7F, 0x11, (byte)0xD1, 
                                                (byte)0x82, 0x22, 0x44, 0x45, 0x53, 0x54, 0x00, 0x00
                                                
                                                     };
                                                     
    private static final String AWAY_FMT = "text/x-aolrtf; charset=us-ascii";                                                     

    //~ Constructors -------------------------------------------------------------------------------

    public ClientSetLocationInfoCmd() {
        flapHdr        = new FlapHeader(FlapConstants.FLAP_CHANNEL_SNAC, 6);
        snacPacket     = new SNACPacket(SNACConstants.SNAC_FAMILY_LOCATION_SERVICES, SNACConstants.CLIENT_SET_LOCATION_INFO);
        
        addTLV( new TLV(0x05, CAPABILITIES) );  
    }
    
    public ClientSetLocationInfoCmd(int seqNum, int statusflag) {
            flapHdr        = new FlapHeader(FlapConstants.FLAP_CHANNEL_SNAC, seqNum);
            snacPacket     = new SNACPacket(SNACConstants.SNAC_FAMILY_LOCATION_SERVICES, SNACConstants.CLIENT_SET_LOCATION_INFO);
        
            addTLV( new TLV(TLVConstants.TLV_TYPE_AWAY_FMT, AWAY_FMT) );
            String away = null;
            switch(statusflag) {
                case 0x0000: away = ""; break;
                case 0x0001: away = "I am away!"; break;
                case 0x0002: away = "Do Not Disturb"; break;
                case 0x0004: away = "Not Available"; break;
                case 0x0010: away = "Busy"; break;
                default:     away = ""; 
            }
            addTLV( new TLV(TLVConstants.TLV_TYPE_AWAY, away ) );  
        }
    

    //~ Methods ------------------------------------------------------------------------------------

    /* (non-Javadoc)
     * @see hamsam.protocol.aim.command.Command#writeCommandData(java.io.OutputStream)
     */
    public void writeCommandData(OutputStream os) throws IOException {
        // no snac data for this, other than the TLV above!
    }
}
