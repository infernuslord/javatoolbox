package samples.graph;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.graph.impl.DirectedSparseEdge;
import edu.uci.ics.jung.graph.impl.DirectedSparseGraph;
import edu.uci.ics.jung.graph.impl.DirectedSparseVertex;
import edu.uci.ics.jung.visualization.GraphDraw;
import edu.uci.ics.jung.visualization.GraphMouseListener;
import edu.uci.ics.jung.visualization.Layout;
import edu.uci.ics.jung.visualization.PluggableRenderer;
import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.contrib.BirdsEyeGraphDraw;
import edu.uci.ics.jung.visualization.contrib.Lens;

/**
 * Demonstrates the use of: <p>
 * <ul>BirdsEyeGraphDraw
 * <ul>BirdsEyeVisualizationViewer
 * <li>Lens
 * </ul>
 * This demo also shows ToolTips on graph vertices.
 * 
 * @author Tom Nelson - RABA Technologies
 * 
 */
public class ZoomDemo {

    /**
     * the graph
     */
    Graph graph;

    /**
     * the visual component of the graph visualization viewer
     */
    GraphDraw gd;

    /**
     * the visual component and renderer for the graph
     */
    VisualizationViewer vv;
    
    JDialog dialog;

    /**
     * create an instance of a simple graph with controls to
     * demo the zoom features.
     * 
     */
    public ZoomDemo() {
        
        // create a simple graph for the demo
        graph = new DirectedSparseGraph();
        Vertex[] v = createVertices(10);
        createEdges(v);
        gd = new GraphDraw(graph);

        final Layout layout = gd.getGraphLayout();
        
        vv = gd.getVisualizationViewer();
        
        gd.setRenderer(new PluggableRenderer());
        gd.addGraphMouseListener(new TestGraphMouseListener());
        
        // add my listener for ToolTips
        vv.setToolTipListener(new VertexListener(gd, 5.0));

        // create a frome to hold the graph
        final JFrame frame = new JFrame();
        Container content = frame.getContentPane();
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(gd);
        content.add(panel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        dialog = new JDialog(frame);
       // Container 
        content = dialog.getContentPane();
        
        // create the BirdsEyeView for zoom/pan
        final BirdsEyeGraphDraw bird = new BirdsEyeGraphDraw(graph, 0.5, 0.5);
        bird.setGraphLayout(layout);
        bird.getVisualizationViewer().addPropertyChangeListener("Lens",
                new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent e) {
                Lens.Stats stats = (Lens.Stats) e.getNewValue();
                setStats(stats);
            }
        });
        
        JButton reset = new JButton("Un-Zoom");
        // 'reset' unzooms the graph via the Lens
        // Alternatively, you could hide the Lens dialog and then call setters
        // on VisualizationViewer, setting offsetx and offsety to 0.0
        // and setting scalex and scaley to 1.0
        reset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                bird.getVisualizationViewer().resetLens();
            }
        });
        
        JButton plus = new JButton("+");
        plus.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                bird.getVisualizationViewer().zoom(2.0);
            }
        });
        JButton minus = new JButton("-");
        minus.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                bird.getVisualizationViewer().zoom(0.5);
            }
        });
        JButton help = new JButton("Help");
        help.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String zoomHelp = "<html><center>Drag the rectangle to pan<p>"+
                "Drag one side of the rectangle to zoom</center></html>";
                JOptionPane.showMessageDialog(dialog, zoomHelp);
            }
        });
        JPanel controls = new JPanel();
        controls.add(reset);
        controls.add(plus);
        controls.add(minus);
        controls.add(help);
        content.add(bird);
        content.add(controls, BorderLayout.SOUTH);
        
        JButton zoomer = new JButton("Zoom");
        // create a dialog to show a birds-eye-view style
        // zoom and pan tool.
        zoomer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialog.pack();
                dialog.show();
                bird.getVisualizationViewer().initLens();
                setStats(bird.getVisualizationViewer().getLensStats());
            }
        });
        JPanel p = new JPanel();
        p.add(zoomer);

        frame.getContentPane().add(p, BorderLayout.SOUTH);
        frame.setSize(600, 600);
        frame.show();
    }

    /**
     * create some vertices
     * @param count how many to create
     * @return the Vertices in an array
     */
    private Vertex[] createVertices(int count) {
        Vertex[] v = new Vertex[count];
        for (int i = 0; i < count; i++) {
            v[i] = graph.addVertex(new DirectedSparseVertex());
        }
        return v;
    }

    /**
     * create edges for this demo graph
     * @param v an array of Vertices to connect
     */
    void createEdges(Vertex[] v) {
        graph.addEdge(new DirectedSparseEdge(v[0], v[1]));
        graph.addEdge(new DirectedSparseEdge(v[0], v[3]));
        graph.addEdge(new DirectedSparseEdge(v[0], v[4]));
        graph.addEdge(new DirectedSparseEdge(v[4], v[5]));
        graph.addEdge(new DirectedSparseEdge(v[3], v[5]));
        graph.addEdge(new DirectedSparseEdge(v[1], v[2]));
        graph.addEdge(new DirectedSparseEdge(v[1], v[4]));
        graph.addEdge(new DirectedSparseEdge(v[8], v[2]));
        graph.addEdge(new DirectedSparseEdge(v[3], v[8]));
        graph.addEdge(new DirectedSparseEdge(v[6], v[7]));
        graph.addEdge(new DirectedSparseEdge(v[7], v[5]));
        graph.addEdge(new DirectedSparseEdge(v[0], v[9]));
        graph.addEdge(new DirectedSparseEdge(v[9], v[8]));
        graph.addEdge(new DirectedSparseEdge(v[7], v[6]));
        graph.addEdge(new DirectedSparseEdge(v[6], v[5]));
        graph.addEdge(new DirectedSparseEdge(v[4], v[2]));
        graph.addEdge(new DirectedSparseEdge(v[5], v[4]));
    }

    /**
     * set the scale and offset of the VisualizationViewer from the 
     * passed Stats object.
     * @param stats a 'struct-like' object holding values
     */
    public void setStats(Lens.Stats stats) {
        vv.setScale(stats.scalex, stats.scaley);
        vv.setOffset(stats.offsetx, stats.offsety);
        vv.repaint();
    }

    /**
     * A nested class to demo ToolTips
     */
    static class VertexListener implements VisualizationViewer.ToolTipListener {
        
        /**
         * how close to the vertex in order to fire the tooltip
         */
        double proximity;

        /**
         * the visual component holding the graph's rendering engine
         */
        GraphDraw gd;

        /**
         * create an instance with passed parameters
         * @param gd the GraphDraw for this graph
         * @param proximity how close to the vertex
         */
        public VertexListener(GraphDraw gd, double proximity) {
            this.gd = gd;
            this.proximity = proximity;
        }

        /**
         * Evaluate the mouse event position and prepare a ToolTip
         * for the Vertex that is within 'proximity' of the event.
         * @param event the MouseEvent where the mouse pointer is dwelling
         */
        public String getToolTipText(MouseEvent event) {
            Layout layout = gd.getGraphLayout();
            VisualizationViewer vv = gd.getVisualizationViewer();
            double scalex = vv.getScaleX();
            double scaley = vv.getScaleY();
            double offsetx = vv.getOffsetX();
            double offsety = vv.getOffsetY();
            Vertex v = layout.getVertex(event.getX()/scalex+offsetx, event.getY()/scaley+offsety, proximity);
            if (v != null) {
                return "tool tip for " + v;
            } else {
                return null;
            }
        }
    }
    
    /**
     * A nested class to demo the GraphMouseListener finding the
     * right vertices after zoom/pan
     */
    static class TestGraphMouseListener implements GraphMouseListener {
        
    		public void graphClicked(Vertex v, MouseEvent me) {
    		    System.err.println("Vertex "+v+" was clicked at ("+me.getX()+","+me.getY()+")");
    		}
    		public void graphPressed(Vertex v, MouseEvent me) {
    		    System.err.println("Vertex "+v+" was pressed at ("+me.getX()+","+me.getY()+")");
    		}
    		public void graphReleased(Vertex v, MouseEvent me) {
    		    System.err.println("Vertex "+v+" was released at ("+me.getX()+","+me.getY()+")");
    		}
    }

    /**
     * a driver for this demo
     */
    public static void main(String[] args) {
        new ZoomDemo();
    }
}

