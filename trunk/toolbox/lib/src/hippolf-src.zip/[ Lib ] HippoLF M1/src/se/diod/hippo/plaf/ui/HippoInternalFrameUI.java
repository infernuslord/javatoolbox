/*
 * 
 * Created on 2004-jul-25
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.ui;

import javax.swing.JComponent;
import javax.swing.JInternalFrame;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.metal.MetalInternalFrameUI;

import se.diod.hippo.plaf.common.InternalFrameTitlePane;




/**
 * 
 * Note: To change the border-thickness use the Insets of HippoBorder::InternalFrameBorder
 * 
 * @author Robert Karlsson
 * @created 2004-jul-25
 *
 */
public class HippoInternalFrameUI extends MetalInternalFrameUI {
	private InternalFrameTitlePane		titlePane;
	public  static final String IS_PALETTE	= "JInternalFrame.isPalette";




	/**
	 * 
	 * 
	 */
	public HippoInternalFrameUI( JInternalFrame iframe ) {
		super( iframe );
	}




	/**
	 * 
	 * 
	 */
	public static ComponentUI createUI( JComponent c ) {
		return new HippoInternalFrameUI( ( JInternalFrame )c );
	}




	/**
	 * 
	 * 
	 */
	public void installUI( JComponent c ) {
		super.installUI( c );

		Object paletteProp = c.getClientProperty( IS_PALETTE );
		if (paletteProp != null) {
			setPalette(((Boolean) paletteProp).booleanValue());
		}

		// Set frame background color
		// frame.setBackground( new java.awt.Color( 138, 159, 173 ) );
	}




	/**
	 * 
	 * 
	 */
	public void uninstallUI( JComponent c ) {
		super.uninstallUI( c );
	}




	/**
	 * 
	 * 
	 */
	protected JComponent createNorthPane( JInternalFrame iFrame ) {
		titlePane = new InternalFrameTitlePane( iFrame );
		return titlePane;
	}




	/**
	 * 
	 * 
	 */
	public void setPalette(boolean isPalette) {
		String key = isPalette ? "InternalFrame.paletteBorder" : "InternalFrame.border";
		titlePane.setPalette( isPalette );
	}
}
