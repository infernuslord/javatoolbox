/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	Tiny Look and Feel                                                         *
*                                                                              *
*  (C) Copyright 2003, Hans Bickel                                             *
*                                                                              *
*   For licensing information and credits, please refer to the                 *
*   comment in file de.muntjak.tinylookandfeel.TinyLookAndFeel                 *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package de.muntjak.tinylookandfeel;

import java.awt.*;
import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.SwingConstants;
import javax.swing.plaf.ComponentUI;

import de.muntjak.tinylookandfeel.controlpanel.*;

/**
 * TinySpinnerButtonUI
 * 
 * @version 1.0
 * @author Hans Bickel
 */
public class TinySpinnerButtonUI extends TinyButtonUI {
    
    private int orientation;
    
    protected static Dimension size = new Dimension(15, 8);
    
	public static ComponentUI createUI(JComponent c) {
        throw new IllegalStateException("Must not be used this way.");
	}
    
    /**
     * Creates a new Spinner Button. Use either SwingConstants.SOUTH or SwingConstants.NORTH
     * for a SpinnerButton of Type up or a down.
     * @param type
     */
    TinySpinnerButtonUI(int type) {
        orientation = type;   
    }

    public void paint(Graphics g, JComponent c) {

        AbstractButton button = (AbstractButton) c;
        
        if(!button.isEnabled()) {
			g.setColor(Theme.spinnerButtDisabledColor[Theme.style].getColor());
		}
		else if(button.getModel().isPressed()) {
			g.setColor(Theme.spinnerButtPressedColor[Theme.style].getColor());
		}
		else if(button.getModel().isRollover() && Theme.spinnerRollover[Theme.style]) {
			g.setColor(Theme.spinnerButtRolloverColor[Theme.style].getColor());
		}
		else {
			g.setColor(Theme.spinnerButtColor[Theme.style].getColor());
		}
		//System.out.println(g.getColor());
		
		switch(Theme.derivedStyle[Theme.style]) {
			case Theme.TINY_STYLE:
				drawTinyButton(g, button);
				break;
			case Theme.WIN_STYLE:
				drawWinButton(g, button);
				break;
			case Theme.XP_STYLE:
				drawXpButton(g, button);
				break;
		}
		
		if(!button.isEnabled()) {
			g.setColor(Theme.spinnerArrowDisabledColor[Theme.style].getColor());
		}
		else {
			g.setColor(Theme.spinnerArrowColor[Theme.style].getColor());
		}
		
		switch(Theme.derivedStyle[Theme.style]) {
			case Theme.TINY_STYLE:
				drawTinyArrow(g, button);
				break;
			case Theme.WIN_STYLE:
				drawWinArrow(g, button);
				break;
			case Theme.XP_STYLE:
				drawXpArrow(g, button);
				break;
		}
    }
    
    private void drawTinyButton(Graphics g, AbstractButton b) {
    	
    }
    
    private void drawWinButton(Graphics g, AbstractButton b) {
    	int x2 = size.width - 1;
		int y2 = size.height - 1;
		
		g.fillRect(2, 2, 11, 4);
		
		if(!b.isEnabled()) {
			g.setColor(Theme.spinnerLightDisabledColor[Theme.style].getColor());
		}
		else {
			g.setColor(Theme.spinnerLightColor[Theme.style].getColor());
		}
		
		if(b.getModel().isPressed()) {
			g.drawLine(0, y2, x2, y2);
			g.drawLine(x2, 0, x2, y2);
		}
		else {
			g.drawLine(1, 1, x2 - 2, 1);
			g.drawLine(1, 2, 1, y2 - 2);
		}
		
		g.setColor(Theme.backColor[Theme.style].getColor());
		
		if(b.getModel().isPressed()) {
			g.drawLine(1, y2 - 1, x2 - 1, y2 - 1);
			g.drawLine(x2 - 1, 1, x2 - 1, y2 - 2);
		}
		else {
			g.drawLine(0, 0, x2 - 1, 0);
			g.drawLine(0, 1, 0, y2 - 1);
		}
		
		if(!b.isEnabled()) {
			g.setColor(Theme.spinnerDarkDisabledColor[Theme.style].getColor());
		}
		else {
			g.setColor(Theme.spinnerDarkColor[Theme.style].getColor());
		}
		
		if(b.getModel().isPressed()) {
			g.drawLine(0, 0, x2 - 1, 0);
			g.drawLine(0, 1, 0, y2 - 1);
		}
		else {
			g.drawLine(1, y2 - 1, x2 - 1, y2 - 1);
			g.drawLine(x2 - 1, 1, x2 - 1, y2 - 2);
		}
		
		if(!b.isEnabled()) {
			g.setColor(Theme.spinnerBorderDisabledColor[Theme.style].getColor());
		}
		else {
			g.setColor(Theme.spinnerBorderColor[Theme.style].getColor());
		}
		
		if(b.getModel().isPressed()) {
			g.drawLine(1, 1, x2 - 2, 1);
			g.drawLine(1, 2, 1, y2 - 2);
		}
		else {
			g.drawLine(0, y2, x2, y2);
			g.drawLine(x2, 0, x2, y2);
		}
    }
    
    private void drawXpButton(Graphics g, AbstractButton b) {
    	int x2 = size.width - 1;
		int y2 = size.height - 1;
		
		int spread1 = Theme.spinnerSpreadLight[Theme.style];
		int spread2 = Theme.spinnerSpreadDark[Theme.style];
		if(!b.isEnabled()) {
			spread1 = Theme.spinnerSpreadLightDisabled[Theme.style];
			spread2 = Theme.spinnerSpreadDarkDisabled[Theme.style];
		}
		
		int h = size.height;
		float spreadStep1 = 10.0f * spread1 / (h - 2);
		float spreadStep2 = 10.0f * spread2 / (h - 2);
		int halfY = h / 2;
		int yd;
		Color c = g.getColor();

		for(int y = 1; y < h - 1; y++) {
			if(y < halfY) {
				yd = halfY - y;
				g.setColor(ColorRoutines.lighten(c, (int)(yd * spreadStep1)));
			}
			else if(y == halfY) {
				g.setColor(c);
			}
			else {
				yd = y - halfY;
				g.setColor(ColorRoutines.darken(c, (int)(yd * spreadStep2)));
			}
			
			g.drawLine(1, y, x2, y);
		}
		
		if(!b.isEnabled()) {
			g.setColor(Theme.spinnerBorderDisabledColor[Theme.style].getColor());
		}
		else {
			g.setColor(Theme.spinnerBorderColor[Theme.style].getColor());
		}
		g.drawRect(0, 0, x2, y2);
    }
    
    private void drawTinyArrow(Graphics g, AbstractButton b) {
    	
    }
    
    private void drawWinArrow(Graphics g, AbstractButton b) {
    	int y = 3;
    	int x = 6;
    	if(b.getModel().isPressed()) {
    		y = 4;
    		x = 7;
    	}
    	
    	switch (orientation) {
			case SwingConstants.NORTH: 
				g.drawLine(x + 1, y, x + 1, y);
				g.drawLine(x, y + 1, x + 2, y + 1);
				break; 
			case SwingConstants.SOUTH:
				g.drawLine(x + 1, y + 1, x + 1, y + 1);
				g.drawLine(x, y, x + 2, y);
				break;
		}
    }
    
    private void drawXpArrow(Graphics g, AbstractButton b) {
    	switch (orientation) {
			case SwingConstants.NORTH: 
				g.drawLine(7, 2, 7, 2);
				g.drawLine(6, 3, 8, 3);
				g.drawLine(5, 4, 9, 4);
				g.drawLine(4, 5, 6, 5);
				g.drawLine(8, 5, 10, 5);
				break; 
			case SwingConstants.SOUTH:
				g.drawLine(4, 2, 6, 2);
				g.drawLine(8, 2, 10, 2);
				g.drawLine(5, 3, 9, 3);
				g.drawLine(6, 4, 8, 4);
				g.drawLine(7, 5, 7, 5);
				break;
		}
    }
    
	/**
	 * @see javax.swing.plaf.basic.BasicButtonUI#getPreferredSize(javax.swing.JComponent)
	 */
	public Dimension getPreferredSize(JComponent c) {
		return size;
	}


}
