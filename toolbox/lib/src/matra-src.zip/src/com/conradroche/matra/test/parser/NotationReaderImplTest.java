/*
 *   The contents of this file are subject to the Mozilla Public License
 *   Version 1.1 (the "License"); you may not use this file except in
 *   compliance with the License. You may obtain a copy of the License at
 *   http://www.mozilla.org/MPL/
 *
 *   Software distributed under the License is distributed on an "AS IS"
 *   basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 *   License for the specific language governing rights and limitations
 *   under the License.
 *
 *   The Original Code is Matra - the DTD Parser.
 *
 *   The Initial Developer of the Original Code is Conrad S Roche.
 *   Portions created by Conrad S Roche are Copyright (C) Conrad 
 *   S Roche. All Rights Reserved.
 *
 *   Alternatively, the contents of this file may be used under the terms
 *   of the GNU GENERAL PUBLIC LICENSE Version 2 or any later version
 *   (the  "[GPL] License"), in which case the
 *   provisions of GPL License are applicable instead of those
 *   above.  If you wish to allow use of your version of this file only
 *   under the terms of the GPL License and not to allow others to use
 *   your version of this file under the MPL, indicate your decision by
 *   deleting  the provisions above and replace  them with the notice and
 *   other provisions required by the GPL License.  If you do not delete
 *   the provisions above, a recipient may use your version of this file
 *   under either the MPL or the GPL License."
 *
 *   [NOTE: The text of this Exhibit A may differ slightly from the text of
 *   the notices in the Source Code files of the Original Code. You should
 *   use the text of this Exhibit A rather than the text found in the
 *   Original Code Source Code for Your Modifications.]
 *
 * Created: Conrad S Roche <derupe at users.sourceforge.net>,  21-Sep-2003
 */
package com.conradroche.matra.test.parser;

import com.conradroche.dtd.decl.Notation;
import com.conradroche.dtd.parser.NotationReader;
import com.conradroche.matra.data.DTDData;
import com.conradroche.matra.exception.DTDSyntaxException;
import com.conradroche.matra.parser.NotationReaderImpl;

import junit.framework.Assert;
import junit.framework.TestCase;

/**
 * Class to unit test the NotationReaderImpl class. 
 *
 * @author Conrad Roche
 */
public class NotationReaderImplTest extends TestCase {

	private NotationReader reader = new NotationReaderImpl();
	
	/**
	 * Constructor for NotationReaderImplTest.
	 * @param arg0
	 */
	public NotationReaderImplTest(String arg0) {
		super(arg0);
	}
	
	//	NotationDecl := '<!NOTATION' S name S (('SYSTEM' S sysId) | ('PUBLIC' S pubId S sysId?)) S? '>'

	/**
	 * 
	 */
	public void testNullData() {
		
		DTDData nullData = null;
		
		checkNonNotation(nullData);
	}
	
	/**
	 * CR: JavaDoc: Add javadoc for NotationReaderImplTest::checkNonNotation
	 * 
	 * @param data
	 */
	private void checkNonNotation(DTDData data) {
		
		boolean isStart = false;
		try {
			isStart = reader.isNotationStart(data);
		} catch(Throwable th) {
			Assert.fail("Caught exception in isNotationStart while checking with (" + data + ") data. - " + th.getMessage()); 
		}
		Assert.assertFalse("isNotationStart was true for data - " + data, isStart);
		
		Notation notation = null;
		try {
			notation = reader.readNotation(data);
		} catch(Throwable th) {
			Assert.fail("Caught exception in readNotation while checking with (" + data + ") data. - " + th.getMessage()); 
		}
		Assert.assertNull(notation);
	}
	
	/**
	 * CR: JavaDoc: Add javadoc for NotationReaderImplTest::testEmptyNotation
	 */
	public void testEmptyData() {
		
		DTDData data = new DTDData("");
		checkNonNotation(data);
		
		data.reset();
		checkNonNotation(data);
	}

	/**
	 * CR: JavaDoc: Add javadoc for NotationReaderImplTest::testNonNotation
	 */	
	public void testNonNotation() {
		//provide '<!non-notation'
		//or '<!NOTATION1'
		
		String[] nonNotations = { "  ", "\n\t \n", "<!TEST  ", "<!ENTITY asdasa", 
						"<!NOTATION1", "<~NOTATION", "NOTATION", "!NOTATION", "<NOTATION",
						"<!notation", "<!Notation"
						};
		for (int i = 0; i < nonNotations.length; i++) {
			checkNonNotation(nonNotations[i]);
		}
	}

	/**
	 * CR: JavaDoc: Add javadoc for NotationReaderImplTest::checkNonNotation
	 * 
	 * @param str
	 */	
	private void checkNonNotation(String str) {
		
		DTDData data = new DTDData(str);
		checkNonNotation(data);
	}
	
	/**
	 * CR: JavaDoc: Add javadoc for NotationReaderImplTest::testInvalidName
	 */
	public void testInvalidName() {
		//provide '<!NOTATION' S <invalid name>
		
		String[] invalidNames = { "3423"
						};
		String prepend = "<!NOTATION ";
		String append[] = {" SYSTEM\tSYS_id>", "\tPUBLIC PUB_id>", "\nPUBLIC pub_ID\tSyS_id\n>"	};
		
		DTDData data = null;
		
		for(int i = 0; i < invalidNames.length; i++) {
			for(int j = 0; j < append.length; j++) {
				
				data = new DTDData(prepend + invalidNames[i] + append[j]);
				checkNotationStart(data); 	
				checkInvalidNotationRead(data);			
			}
		}
	}

	/**
	 * CR: JavaDoc: Add javadoc for NotationReaderImplTest::checkNotationStart
	 * 
	 * @param data
	 */	
	private void checkNotationStart(DTDData data) {
		
		boolean isStart = false;
		try {
			isStart = reader.isNotationStart(data);
		} catch(Throwable th) {
			Assert.fail("Caught exception in isNotationStart while checking with (" + data + ") data. - " + th.getMessage());
			return; 
		}
		Assert.assertTrue("isNotationStart was false for data - " + data, isStart);
	}
	
	/**
	 * CR: JavaDoc: Add javadoc for NotationReaderImplTest::checkInvalidNotationRead
	 * 
	 * @param data
	 */
	private void checkInvalidNotationRead(DTDData data) {
		
		try {
			Notation notation = reader.readNotation(data);
		} catch(DTDSyntaxException dse) {
//			dse.printStackTrace();
			return;
		} catch(Throwable th) {
			Assert.fail("Caught exception in readNotation while checking with (" + data + ") data. - " + th.getMessage());
			return; 
		}
		Assert.fail("Didn't catch syntax exception while parsing notation - " + data);
	}

	/**
	 * CR: JavaDoc: Add javadoc for NotationReaderImplTest::testInvalidIdentifier
	 */
	public void testInvalidIdentifier() {
		//'<!NOTATION' S name S 'something'
		//CR: TODO: Implement testInvalidIdentifier
		String prefix = "<!NOTATION name ";
	}

	/**
	 * CR: JavaDoc: Add javadoc for NotationReaderImplTest::testSysIdentifier
	 */	
	public void testSysIdentifier() {
		//'<!NOTATION' S name S 'SYSTEM' S sysId
		//CR: TODO: Implement testSysIdentifier
	}

	/**
	 * CR: JavaDoc: Add javadoc for NotationReaderImplTest::testSysIdentifierWithSpaces
	 */	
	public void testSysIdentifierWithSpaces() {
		//'<!NOTATION' S name S 'SYSTEM' S sysId
		//CR: TODO: Implement testSysIdentifierWithSpaces
	}

	/**
	 * CR: JavaDoc: Add javadoc for NotationReaderImplTest::testSysIdentifierWithQuotes
	 */	
	public void testSysIdentifierWithQuotes() {
		//'<!NOTATION' S name S 'SYSTEM' S sysId
		//CR: TODO: Implement testSysIdentifierWithQuotes
	}

	/**
	 * CR: JavaDoc: Add javadoc for NotationReaderImplTest::testPubIdentifier
	 */
	public void testPubIdentifier() {
		//'<!NOTATION' S name S 'PUBLIC' S pubId
		//CR: TODO: Implement testPubIdentifier
	}

	/**
	 * CR: JavaDoc: Add javadoc for NotationReaderImplTest::testPubIdentifierWithSpaces
	 */	
	public void testPubIdentifierWithSpaces() {
		//'<!NOTATION' S name S 'PUBLIC' S pubId
		//CR: TODO: Implement testPubIdentifierWithSpaces
	}

	/**
	 * CR: JavaDoc: Add javadoc for NotationReaderImplTest::testPubIdentifierWithQuotes
	 */	
	public void testPubIdentifierWithQuotes() {
		//'<!NOTATION' S name S 'PUBLIC' S pubId
		//CR: TODO: Implement testPubIdentifierWithQuotes
	}

	/**
	 * CR: JavaDoc: Add javadoc for NotationReaderImplTest::testPubSysIdentifier
	 */	
	public void testPubSysIdentifier() {
		//'<!NOTATION' S name S 'PUBLIC' S pubId S sysId
		//CR: TODO: Implement testPubSysIdentifier
	}
}
