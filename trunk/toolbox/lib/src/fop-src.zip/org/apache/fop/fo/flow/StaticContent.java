/*
 * $Id: StaticContent.java,v 1.18.2.6 2002/11/22 15:10:46 chrisg Exp $
 * Copyright (C) 2001 The Apache Software Foundation. All rights reserved.
 * For details on use and redistribution please refer to the
 * LICENSE file included with these sources.
 */

package org.apache.fop.fo.flow;

// FOP
import org.apache.fop.fo.*;
import org.apache.fop.fo.properties.*;
import org.apache.fop.fo.pagination.*;
import org.apache.fop.layout.Area;
import org.apache.fop.apps.FOPException;

public class StaticContent extends AbstractFlow {

    public static class Maker extends FObj.Maker {
        public FObj make(FObj parent,
                         PropertyList propertyList) throws FOPException {
            return new StaticContent(parent, propertyList);
        }
    }

    public static FObj.Maker maker() {
        return new StaticContent.Maker();
    }

    protected StaticContent(FObj parent,
                            PropertyList propertyList) throws FOPException {
        super(parent, propertyList);
        setFlowName(getProperty("flow-name").getString());
        pageSequence.addStaticContent(this);
//        ((PageSequence)parent).setIsFlowSet(false);    // hacquery of sorts
    }

    public String getName() {
        return "fo:static-content";
    }

    public int layout(Area area, Region region) throws FOPException {

        int numChildren = this.children.size();
        // Set area absolute height so that link rectangles will be drawn correctly in xsl-before and xsl-after
        String regionClass = "none";
        if (region != null) {
            regionClass = region.getRegionClass();
        } else {
            if (getFlowName().equals("xsl-region-before")) {
                regionClass = RegionBefore.REGION_CLASS;
            } else if (getFlowName().equals("xsl-region-after")) {
                regionClass = RegionAfter.REGION_CLASS;
            } else if (getFlowName().equals("xsl-region-start")) {
                regionClass = RegionStart.REGION_CLASS;
            } else if (getFlowName().equals("xsl-region-end")) {
                regionClass = RegionEnd.REGION_CLASS;
            }

        }

        if (area instanceof org.apache.fop.layout.AreaContainer)
            ((org.apache.fop.layout.AreaContainer)area).setAreaName(regionClass);

	area.setAbsoluteHeight(0); // Ytop relative to self!

	setContentWidth(area.getContentWidth());

        for (int i = 0; i < numChildren; i++) {
            FObj fo = (FObj)children.get(i);

            int status;
            if (Status.isIncomplete((status = fo.layout(area)))) {
                // in fact all should be laid out and clip, error etc depending on 'overflow'
                log.warn("Some static content could not fit in the area.");
                this.marker = i;
                if ((i != 0) && (status == Status.AREA_FULL_NONE)) {
                    status = Status.AREA_FULL_SOME;
                }
                return (status);
            }
        }
        resetMarker();
        return Status.OK;
    }

    // flowname checking is more stringient for static content currently
    protected void setFlowName(String name) throws FOPException {
        if (name == null || name.equals("")) {
            throw new FOPException("A 'flow-name' is required for "
                                   + getName() + ".");
        } else {
            _flowName = name;
        }

    }

}
