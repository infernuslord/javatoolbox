/*
 * Created on Apr 14, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package com.shfarr.beans;

/**
 * @author Stefan Harsan Farr
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public interface Property{
    public abstract String getName();

    public abstract Class getType();

    public abstract boolean isReadOnly();

    public abstract boolean isWriteOnly();

    public abstract boolean isReadWrite();

    public abstract Object getValue(Object target);

    public abstract boolean setValue(Object target, Object value);
}