// $Id: ComparatorTemplate.java,v 1.1 2002/04/25 18:17:20 bill Exp $

package com.jclark.xsl.tr;

import com.jclark.xsl.om.*;
import com.jclark.xsl.util.Comparator;
import com.jclark.xsl.expr.ExprContext;

interface ComparatorTemplate
{
    Comparator instantiate(Node node, ExprContext context) throws XSLException;
}
