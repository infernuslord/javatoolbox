package phelps.util;

import java.awt.geom.Dimension2D;
import java.awt.Toolkit;
import java.util.Map;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import phelps.awt.geom.Dimension2D_Double;


/**
	Units of measure.

	<ul>
	<li>length: <a href='#lengths'>built-in units</a>, {@link #getLength(String, String)}, {@link #convertLength(String, String)}, {@link #addLength(String, String, String, double)}
	<li>paper size: <a href='#papers'>built-in papers sizes</a>, {@link #getPaperSize(String, int)}, {@link #addPaperSize(String,String)}
	</ul>

	@version $Revision: 1.5 $ $Date: 2003/10/01 13:23:34 $
*/
public class Units {
  private static final Matcher LENGTHMATCHER_ = Pattern.compile("([-+0-9.]+)\\s*(\\w+)?").matcher("");
  private static final Map<String,Double> length_ = new HashMap<String,Double>();
  static {
	String[] units = {
		"meter","meters","m", "centimeter","centimeters","cm", "millimeter","millimeters","mm",
		"inch","inches","in", "foot","feet","ft", "mile","miles","mile",
		"point","points","pt", "scaled point","scaled point","sp", "big point","big points","bp", "pica","picas","pc", "didot","didots","dd", "cicero","ciceros","cc",
		//"px" -- special case
	};
	final double IN = 2.54/100.0;
	double[] fac = {
		1.0, 1.0/100.0, 1.0/1000.0, 
		IN, 12*IN, 5280*12*IN,
		IN/72.27, IN/65536.0, IN/72.0, IN*12.0/72.0, IN*1238.0/(1157.0*72.27), IN*12.0*1238.0/(1157.0*72.27)
	};
	assert units.length == fac.length;
	for (int i=0,imax=units.length; i<imax; i++) addLength(units[i*2], units[i*2+1], units[i*2+2], fac[i]);
    addLength("pixel","pixels","px", IN / Toolkit.getDefaultToolkit().getScreenResolution());
	// check that no dup abbrev
  }

  private static final Matcher PAPERMATCHER_ = Pattern.compile("([0-9.]+)\\s*x\\s*([0-9.]+)\\s*(\\w+)").matcher("");
  private static final Map<String,Dimension2D> paper_ = new HashMap<String,Dimension2D>();
  static {
	String[] papers = {
		"US","8.5x11in", "letter","8.5x11in", "legal","8.5x14in", "foolscap","13.5x17in",
		"4A0","1682x2378mm", "2A0","1189x1682mm", "A0","841x1189mm", "A1","594x841mm", "A2","420x594mm", "A3","297x420mm", "A4","210x297mm",
		"A5","148x210mm", "A6","105x148mm", "A7","74x105mm", "A8","52x74mm", "A9","37x52mm", "A10","26x37mm",
		"B0","1000x1414mm", "B1","707x1000mm", "B2","500x707mm", "B3","353x500mm", "B4","250x353mm", "B5","176x250mm", 
		"B6","125x176mm", "B7","88x125mm", "B8","62x88mm", "B9","44x62mm", "B10","31x44mm",
		"C0","917x1297mm", "C1","648x917mm", "C2","458x648mm", "C3","324x458mm", "C4","229x324mm", "C5","162x229mm", "C6","114x162mm", "C7","81x114mm", "C8","57x81mm", "C9","40x57mm", "C10","28x40mm", 
	};
	for (int i=0,imax=papers.length; i<imax; i+=2) addPaperSize(papers[i], papers[i+1]);
  }


  /** Parse <var>val</var> for number and unit (missing unit intepreted as 'px'), and return conversion to <var>unit</var>. */
  public static double getLength(String valunit, String unitout) throws NumberFormatException {
	Matcher m = LENGTHMATCHER_;
	m.reset(valunit);
	if (!m.find()) return Double.MIN_VALUE;	//throws....

	double val = Double.parseDouble(m.group(1));
	String unit = m.groupCount()==2? m.group(2): "px";
	double fac = convertLength(unit, unitout);
//System.out.println(valunit+" => "+v.substring(0,x)+" / "+v.substring(x)+" => "+(val*fac)+" in "+unitout);
	return val * fac;
  }

  /**
	Return conversion factor from <var>unitin</var> to <var>unitout</var>.
  */
  public static double convertLength(String unitin, String unitout) {
	Double d1 = length_.get(unitin.trim().toLowerCase()), d2 = length_.get(unitout.trim().toLowerCase());
	assert d1!=null: d1;
	assert d2!=null: d2;
	return d1.doubleValue()/*into meters*/ / d2.doubleValue() /*back to non-meters*/;
  }

  /**
	Add a new unit of length by supplying <var>abbrev</var>iation for parsing and conversion <var>factor</var> to meters.
	Built-in units:
	<ul id='lengths'>
	<li>metric: m (meters), cm (centimeters), mm (millimeters), 
	<li>English: in (inches), ft (feet), mile (miles)
	<li>printer: pt (points -- 72.27/in), sp (scaled points -- TeX), bp (big points -- 72/in), pc (picas), dd (didot points), and cc (ciceros)
	<li>screen: px (pixel -- according to current screen)
	</ul>
  */
  public static void addLength(String name, String plural, String abbrev, double factor) {
	assert abbrev!=null && factor!=0.0;
	Double fac = new Double(factor);
	length_.put(name.trim().toLowerCase(), fac);
	length_.put(plural.trim().toLowerCase(), fac);
	length_.put(abbrev.trim().toLowerCase(), fac);
  }



  /**
	Returns size in units for passed paper size.
	Accepted paper sizes the <a href='#papers'>built-in names</a> and 
	explicit dimensions given in <var>number</var>x<var>number</var><var>unit</var> syntax.
	A trailing 'r' on <var>size</var> rotates by 90 degrees clockwise; e.g., "usr" returns 11x8.5in.
  */
  public static Dimension2D getPaperSize(String size, String unitout) {
	boolean frot = false;
	String s = size.trim().toLowerCase();
	Dimension2D dim = paper_.get(s);
	if (dim==null && s.indexOf('x')!=-1) { dim = computeWxH(size); if (size.endsWith("r")) frot=true; }
	else if (dim==null && s.endsWith("r")) { frot=true; s=s.substring(0,s.length()-1).trim(); dim = paper_.get(s); }
	//if (dim==null) throw...

	double w=dim.getWidth(), h=dim.getHeight();
	if (frot) { double tmp=w; w=h; h=w; }
	double fac = convertLength("mm", unitout);
	w*=fac; h*=fac;

	return new Dimension2D_Double(w,h);
  }

  /**
	Add new paper size, giving <var>abbrev</var>iation and <var>dimensions</var> in <var>width-number</var>x<var>height-number</var><var>unit-of-length</var>.
	Built-in paper sizes:
	<ul id='papers'>
	<li>American: US (8.5x11in), legal (8.5x14in)
	<li>ISO: A0 - A10, B0 - B10, C0 - C10
	<li>foolscap (13.5x17in)
	</ul>
  */
  public static void addPaperSize(String abbrev, String dimensions) {
	assert abbrev!=null && dimensions!=null;
	paper_.put(abbrev.toLowerCase(), computeWxH(dimensions.trim()));
  }

  /** Parse dimension of WxHu syntax. */
  private static Dimension2D computeWxH(String whu) {
	Matcher m = PAPERMATCHER_;
	m.reset(whu);
	if (!m.find()) return null;	//throws....

	double w = Double.parseDouble(m.group(1)), h = Double.parseDouble(m.group(2));
	double fac = convertLength(m.group(3), "mm");

	return new Dimension2D_Double(w*fac,h*fac);
  }


	/*
  public static void main(String[] argv) {
	String[] lengths = { "1m","m", "1cm","m", "1m","cm",  "25in","in", "25in","m", "1in","px" };
	for (int i=0,imax=lengths.length; i<imax; i+=2) System.out.println(lengths[i]+" in "+lengths[i+1]+" => "+getLength(lengths[i], lengths[i+1]));

	String[] papers = { "letter", "legal", "A4", "A7" };
	for (String p: papers) System.out.println(p+" => "+paper_.get(p.toLowerCase())+" => "+getPaperSize(p, "mm")+" / "+getPaperSize(p,"in"));

	System.exit(0);
  }*/
}
