/*
* Copyright (c) 2003, the JUNG Project and the Regents of the University 
* of California
* All rights reserved.
*
* This software is open-source under the BSD license; see either
* "license.txt" or
* http://jung.sourceforge.net/license.txt for a description.
*/
/*
 * Created on Jun 23, 2003
 */
package samples.graph;

import java.io.IOException;

import javax.swing.JFrame;

import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.io.PajekNetReader;
import edu.uci.ics.jung.visualization.GraphDraw;

/**
 * Illustrates the simplest possible drawing program: reads in a graph, 
 * then adds it to a {@link edu.uci.ics.jung.visualization.GraphDraw GraphDraw} object, which displays it.
 * Does no processing, no filtering, and no custom rendering.
 * 
 * @author danyelf
 */
public class SimpleGraphDraw {

	static GraphDraw gd;

	public static void main(String[] args) throws IOException {
		JFrame jf = new JFrame();
		Graph g = getGraph();
		gd = new GraphDraw(g);
		jf.getContentPane().add(gd);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.pack();
		jf.show();
	}

	/**
	 * Generates a graph: in this case, reads it from the file
	 * "samples/datasetsgraph/simple.net"
	 * @return A sample undirected graph
	 */
	public static Graph getGraph() throws IOException {
        PajekNetReader pnr = new PajekNetReader();
        Graph g = pnr.load("samples/datasets/simple.net");
		return g;
	}
}
