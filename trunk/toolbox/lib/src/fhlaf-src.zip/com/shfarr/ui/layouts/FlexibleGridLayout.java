/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.layouts;

import java.awt.*;


public class FlexibleGridLayout implements LayoutManager2{
	protected int vGap = 0;
	protected int hGap = 0;
	protected int rows = 1;
	protected int cols = 1;
    protected boolean redistributeVertically = true;
    protected boolean redistributeHorizontally = true;
    
	
	/**
	 * JXGridLayout constructor comment.
	 * @param rows int
	 * @param cols int
	 */
	public FlexibleGridLayout(int rows, int cols){
	  this(rows, cols, 0, 0);
	}
	
	
	/**
	 * JXGridLayout constructor comment.
	 * @param rows int
	 * @param cols int
	 * @param hgap int
	 * @param vgap int
	 */
	
	
	public FlexibleGridLayout(int rows, int cols, int hGap, int vGap){
	  this.rows = rows;
	  this.cols = cols;
	  this.hGap = hGap;
	  this.vGap = vGap;
	}
    
    public FlexibleGridLayout(int rows, int cols, int hGap, int vGap, boolean redistributeHorizontally, boolean redistributeVertically){
        this.rows = rows;
        this.cols = cols;
        this.hGap = hGap;
        this.vGap = vGap;
        this.redistributeHorizontally = redistributeHorizontally;
        this.redistributeVertically = redistributeVertically;
    }
    

	public void addLayoutComponent(Component comp, Object constraints){
	}


	public void addLayoutComponent(String name, Component comp){
	}
	
	
	public float getLayoutAlignmentX(Container target){
	  return -1.0f;
	}
	
	
	public float getLayoutAlignmentY(Container target){
	  return -1.0f;
	}
	
	
	public void invalidateLayout(Container target){
	}
	
	
	public void layoutContainer(Container parent){
	  synchronized(parent.getTreeLock()){
	     Component[] cps = parent.getComponents();
	
	     Dimension pd = preferredLayoutSize(parent),
	                d = null;
	
	     int colWidths[] = new int[cols],
	         rowHeights[] = new int[rows];
	
	     // Compute prefferd dimensions for rows and columns
	     for(int k = 0; k < cps.length; k++){
		     d = cps[k].getPreferredSize();
             
		     colWidths[k%cols] = Math.max(colWidths[k%cols], d.width);
		     rowHeights[k/cols] = Math.max(rowHeights[k/cols], d.height);
	     }
	
	     // Redistribute space excess
         d = parent.getSize();
         int xExcess = d.width -pd.width,
         yExcess = d.height -pd.height,
         xCountdown = xExcess,
         yCountdown = yExcess;
             
         if(redistributeHorizontally){
                 for(int k = 0; k < cols; k++){
                 if(k%cols < cols -1){
                     int amount = (int)((double)xExcess*(double)colWidths[k%cols]/(double)pd.width);
                     xCountdown -= amount;
                     colWidths[k%cols] += amount;
                 }
                 else colWidths[k%cols] += xCountdown;
             }
         }
         
         if(redistributeVertically){
             for(int k = 0; k < rows; k++){
                 if(k/rows < rows -1){
                     int amount = (int)((double)yExcess*(double)rowHeights[k/rows]/(double)pd.height);
                     yCountdown -= amount;
                     rowHeights[k/rows] += amount;
                 }
                 else rowHeights[k/rows] += yCountdown;
             }
         }
	     
         Insets insets = parent.getInsets()!=null ? parent.getInsets() : new Insets(0, 0, 0, 0);
	
	     for(int k = 0, x = insets.left, y = insets.top; k < cps.length; k++){
		     if(k%cols!=0) x += hGap + colWidths[k%cols -1];
		     else{
			      x = insets.left;
	              if(k/cols!=0) y += vGap +rowHeights[k/cols -1];
	         }
	
		     cps[k].setBounds(x, y, (int)(colWidths[k%cols]), (int)(rowHeights[k/cols]));
             //System.out.println("---=( shfarr :: FlexibleGridLayout.java )=-> " + cps[k].getBounds());
	     }
	  }
	}
	
	
	public Dimension maximumLayoutSize(Container target){
	  return new Dimension(50000, 50000);
	}
	
	
	public Dimension minimumLayoutSize(Container parent){
	  return new Dimension(10, 10);
	}
	
	
	public Dimension preferredLayoutSize(Container parent){
	  Component[] cps = parent.getComponents();
	  int[] colWidths = new int[cols];
	  int[] rowHeights = new int[rows];
	
	  Dimension d = null;
	  for(int k = 0; k < cps.length; k++){
		  d = cps[k].getPreferredSize();
		  colWidths[k%cols] = Math.max(colWidths[k%cols], d.width);
		  rowHeights[k/cols] = Math.max(rowHeights[k/cols], d.height);
	  }
	
	  Insets insets = parent.getInsets()!=null ? parent.getInsets() : new Insets(0, 0, 0, 0);
	  d = new Dimension(insets.left +insets.right +hGap*(cols -1), insets.top +insets.bottom +vGap*(rows -1));
	
	  for(int i = 0; i < colWidths.length; i++) d.width += colWidths[i];
	  for(int i = 0; i < rowHeights.length; i++) d.height += rowHeights[i];
	
	  return d;
	}
	
	
	public void removeLayoutComponent(Component comp){
	}
}
