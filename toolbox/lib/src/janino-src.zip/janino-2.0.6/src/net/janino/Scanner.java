
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

/**
 * Splits up a character stream into tokens and returns them as
 * {@link java.lang.String String} objects.
 */

public class Scanner {

    /**
     * Set up a scanner that reads tokens from the given file in the platform
     * default encoding.
     * @param fileName
     * @throws ScanException
     * @throws IOException
     */
    public Scanner(String fileName) throws ScanException, IOException {
        this(
            fileName,
            new InputStreamReader(new FileInputStream(fileName)),
            true                   // closeReaderOnConstructorException
        );
    }

    /**
     * Set up a scanner that reads tokens from the given file in the platform
     * default encoding.
     * @param file
     * @throws ScanException
     * @throws IOException
     */
    public Scanner(File file) throws ScanException, IOException {
        this(
            file.getAbsolutePath(),
            new InputStreamReader(new FileInputStream(file)),
            true                   // closeReaderOnConstructorException
        );
    }

    /**
     * Set up a scanner that reads tokens from the given file in the given encoding.
     * @param file
     * @param encoding
     * @throws ScanException
     * @throws IOException
     */
    public Scanner(File file, String encoding) throws ScanException, IOException {
        this(
            file.getAbsolutePath(),
            new InputStreamReader(new FileInputStream(file), encoding),
            true                   // closeReaderOnConstructorException
        );
    }

    /**
     * Set up a scanner that reads tokens from the given
     * {@link InputStream} in the platform default encoding.
     * <p>
     * The <code>fileName</code> is solely used for reporting in thrown
     * exceptions.
     * @param fileName
     * @param is
     * @throws ScanException
     * @throws IOException
     */
    public Scanner(String fileName, InputStream is) throws ScanException, IOException {
        this(
            fileName,
            new InputStreamReader(is),
            false                  // closeReaderOnConstructorException
        );
    }

    /**
     * Set up a scanner that reads tokens from the given
     * {@link Reader}.
     * <p>
     * The <code>fileName</code> is solely used for reporting in thrown
     * exceptions.
     * @param fileName
     * @param in
     * @throws ScanException
     * @throws IOException
     */
    public Scanner(String fileName, Reader in) throws ScanException, IOException {
        this(fileName, in, false);
    }

    /**
     * Some public constructors open a file on-the-fly. For these constructors it is
     * important that this private constructor closes the {@link Reader} if
     * it throws an exception.
     * @param fileName
     * @param in
     * @param closeReaderOnConstructorException
     * @throws ScanException
     * @throws IOException
     */
    private Scanner(
        String  fileName,
        Reader  in,
        boolean closeReaderOnConstructorException
    ) throws ScanException, IOException {
        this.fileName = fileName;
        this.in       = new UnicodeUnescapeReader(in);

        try {
            this.readNextChar();
            this.nextToken       = this.internalRead();
            this.nextButOneToken = this.internalRead();
        } catch (ScanException e) {
            if (closeReaderOnConstructorException) try { in.close(); } catch (IOException e2) {}
        } catch (IOException e) {
            if (closeReaderOnConstructorException) try { in.close(); } catch (IOException e2) {}
        }
    }

    public void close() throws IOException { this.in.close(); }

    /**
     * Read the next token from the input.
     */
    public Token read() throws ScanException, IOException {
        Token res = this.nextToken;
        this.nextToken       = this.nextButOneToken;
        this.nextButOneToken = this.internalRead();
        return res;
    }

    /**
     * Peek the next token, but don't remove it from the input.
     */
    public Token peek() {
        if (Scanner.DEBUG) System.err.println("peek() => \"" + this.nextToken + "\"");
        return this.nextToken;
    }

    /**
     * Peek the next but one token, neither remove the next nor the next
     * but one token from the input.
     */
    public Token peekNextButOne() {
        return this.nextButOneToken;
    }

    public abstract class Token {
        private /*final*/ String fileName;
        private /*final*/ short  lineNumber;
        private /*final*/ short  columnNumber;

        private Token() {
            this.fileName     = Scanner.this.fileName;
            this.lineNumber   = Scanner.this.tokenLineNumber;
            this.columnNumber = Scanner.this.tokenColumnNumber;
        }

        public Location getLocation() {
            return new Location(this.fileName, this.lineNumber, this.columnNumber);
        }

        public boolean isKeyword() { return false; }
        public boolean isKeyword(String k) { return false; }
        public boolean isKeyword(String[] ks) { return false; }
        public String getKeyword() throws ScanException { throw new ScanException("Not a keyword token"); }

        public boolean isIdentifier() { return false; }
        public boolean isIdentifier(String id) { return false; }
        public String getIdentifier() throws ScanException { throw new ScanException("Not an identifier token"); }

        public boolean isLiteral() { return false; }
        public Class getLiteralType() throws ScanException { throw new ScanException("Not a literal token"); }
        public Object getLiteralValue() throws ScanException { throw new ScanException("Not a literal token"); }
        public Object getNegatedLiteralValue() throws ScanException { throw new ScanException("Not a literal token"); }

        public boolean isOperator() { return false; }
        public boolean isOperator(String o) { return false; }
        public boolean isOperator(String[] os) { return false; }
        public String getOperator() throws ScanException { throw new ScanException("Not an operator token"); }

        public boolean isEOF() { return false; }
    }

    public class KeywordToken extends Token {
        private final String keyword;

        /**
         * @param keyword Must be in interned string!
         */
        private KeywordToken(String keyword) {
            this.keyword = keyword;
        }

        public boolean isKeyword() { return true; }
        public boolean isKeyword(String k) { return this.keyword == k; }
        public boolean isKeyword(String[] ks) {
            for (int i = 0; i < ks.length; ++i) {
                if (this.keyword == ks[i]) return true;
            }
            return false;
        }
        public String getKeyword() { return this.keyword; }

        public String toString() { return this.keyword; }
    }

    public class IdentifierToken extends Token {
        private final String identifier;

        private IdentifierToken(String identifier) {
            this.identifier = identifier;
        }

        public boolean isIdentifier() { return true; }
        public boolean isIdentifier(String id) { return this.identifier.equals(id); }
        public String getIdentifier() { return this.identifier; }

        public String toString() { return this.identifier; }
    }

    public class LiteralToken extends Token {
        private final Object value;

        /**
         * The type of the <code>value</code> parameter determines the type of the literal
         * token:
         * <table>
         *   <tr><th><code>value</code></th><th>Literal</th></tr>
         *   <tr><td>{@link String}</td><td>STRING literal</td></tr>
         *   <tr><td>{@link Character}</td><td>CHAR literal</td></tr>
         *   <tr><td>{@link Integer}</td><td>INT literal</td></tr>
         *   <tr><td>{@link Long}</td><td>LONG literal</td></tr>
         *   <tr><td>{@link Float}</td><td>FLOAT literal</td></tr>
         *   <tr><td>{@link Double}</td><td>DOUBLE literal</td></tr>
         *   <tr><td>{@link Boolean}</td><td>BOOLEAN literal</td></tr>
         *   <tr><td><code>null</code></td><td>NULL literal</td></tr>
         * </table>
         * The special values {@link #MAX_INT_PLUS_ONE} and {@link #MAX_LONG_PLUS_ONE} denote
         * the special values 2^31 and 2^63 which may appear in decimal integer resp. long literals
         * if and only if the literal is negated.
         * @param value
         */
        private LiteralToken(Object value) {
            this.value = value;
        }

        public boolean isLiteral() { return true; }
        public Class getLiteralType() {
            if (this.value instanceof String   ) return String.class;
            if (this.value instanceof Character) return char.class;
            if (this.value instanceof Integer  ) return int.class;
            if (this.value instanceof Long     ) return long.class;
            if (this.value instanceof Float    ) return float.class;
            if (this.value instanceof Double   ) return double.class;
            if (this.value instanceof Boolean  ) return boolean.class;
            if (this.value == null              ) return void.class;
            throw new RuntimeException("Illegal literal token value type " + this.value.getClass().getName());
        }
        public Object getLiteralValue() throws ScanException {
            if (
                this.value == Scanner.MAX_INT_PLUS_ONE ||
                this.value == Scanner.MAX_LONG_PLUS_ONE
            ) throw new ScanException("This value may only appear in a negated literal");
            return this.value;
        }
        public Object getNegatedLiteralValue() throws ScanException {
            if (this.value instanceof String   ) throw new ScanException("Cannot negate string literal");
            if (this.value instanceof Character) throw new ScanException("Cannot negate character literal");
            if (this.value instanceof Integer  ) return new Integer(-((Integer) this.value).intValue());
            if (this.value instanceof Long     ) return new Long   (-((Long   ) this.value).longValue());
            if (this.value instanceof Float    ) return new Float  (-((Float  ) this.value).floatValue());
            if (this.value instanceof Double   ) return new Double (-((Double ) this.value).doubleValue());
            if (this.value instanceof Boolean  ) throw new ScanException("Cannot negate boolean literal");
            if (this.value == null              ) throw new ScanException("Cannot negate null literal");
            throw new RuntimeException("Illegal literal token value type " + this.value.getClass().getName());
        }

        public String toString() {
            return (
                this.value instanceof String    ? "\"" + this.value + '"' :
                this.value instanceof Character ? "'" + this.value + '\'' :
                this.value instanceof Long      ? this.value + "L" :
                this.value instanceof Float     ? this.value + "F" :
                this.value instanceof Double    ? this.value + "D" :
                this.value == null              ? "null" :
                this.value.toString()
            );
        }
    }
    public static final Integer MAX_INT_PLUS_ONE  = new Integer(Integer.MIN_VALUE);
    public static final Long    MAX_LONG_PLUS_ONE = new Long(Long.MIN_VALUE);


    public class OperatorToken extends Token {
        private final String operator;

        /**
         * 
         * @param operator Must be an interned string!
         */
        private OperatorToken(String operator) {
            this.operator = operator;
        }

        public boolean isOperator() { return true; }
        public boolean isOperator(String o) { return this.operator == o; }
        public boolean isOperator(String[] os) {
            for (int i = 0; i < os.length; ++i) {
                if (this.operator == os[i]) return true;
            }
            return false;
        }
        public String getOperator() { return this.operator; }

        public String toString() { return this.operator; }
    }

    public class EOFToken extends Token {
        public boolean isEOF() { return true; }
        public String toString() { return "End-Of-File"; }
    }

    private Token internalRead() throws ScanException, IOException {
        if (this.nextChar == -1) { return new EOFToken(); }

        // Skip whitespace and comments.
        for (;;) {

            // Eat whitespace.
            while (Character.isWhitespace((char) this.nextChar)) {
                this.readNextChar();
                if (this.nextChar == -1) { return new EOFToken(); }
            }

            // Skip comment.
            if (this.nextChar != '/') break;
            this.readNextChar();
            if (this.nextChar == -1) { return new OperatorToken("/"); }
            if (this.nextChar == '/') {
                for (;;) {
                    this.readNextChar();
                    if (this.nextChar == -1) { return new EOFToken(); }
                    if (this.nextChar == '\r' || this.nextChar == '\n') break;
                }
            } else
            if (this.nextChar == '*') {
                boolean gotStar = false;
                for (;;) {
                    this.readNextChar();
                    if (this.nextChar == -1) throw new ScanException("EOF in C-style comment");
                    if (this.nextChar == '*') {
                        gotStar = true;
                    } else
                    if (gotStar && this.nextChar == '/') {
                        this.readNextChar();
                        break;
                    } else {
                        gotStar = false;
                    }
                }
            } else
            {
                return new OperatorToken("/");
            }
        }

        /*
         * Whitespace and comments are now skipped; "nextChar" is definitely
         * the first character of the token.
         */
        this.tokenLineNumber   = this.nextCharLineNumber;
        this.tokenColumnNumber = this.nextCharColumnNumber;

        if (this.nextChar == -1) return new EOFToken();

        // Scan identifier.
        if (Character.isJavaIdentifierStart((char) this.nextChar)) {
            StringBuffer sb = new StringBuffer();
            sb.append((char) this.nextChar);
            for (;;) {
                this.readNextChar();
                if (
                    this.nextChar == -1 ||
                    !Character.isJavaIdentifierPart((char) this.nextChar)
                ) break;
                sb.append((char) this.nextChar);
            }
            String s = sb.toString();
            if (s.equals("true") || s.equals("false")) return new LiteralToken(new Boolean(s));
            if (s.equals("null")) return new LiteralToken(null);
            {
                String v = (String) Scanner.JAVA_KEYWORDS.get(s);
                if (v != null) return new KeywordToken(v);
            }
            return new IdentifierToken(s);
        }

        // Scan numeric literal.
        if (Character.isDigit((char) this.nextChar)) {
            return this.scanNumericLiteral(0);
        }

        // A "." is special: Could either be a floating-point constant like ".001", or the "."
        // operator.
        if (this.nextChar == '.') {
            this.readNextChar();
            if (Character.isDigit((char) this.nextChar)) {
                return this.scanNumericLiteral(2);
            } else {
                return new OperatorToken(".");
            }
        }

        // Scan string literal.
        if (this.nextChar == '"') {
            StringBuffer sb = new StringBuffer("");
            this.readNextChar();
            if (this.nextChar == -1) throw new ScanException("EOF in string literal");
            if (this.nextChar == '\r' || this.nextChar == '\n') throw new ScanException("Line break in string literal");
            while (this.nextChar != '"') {
                sb.append(unescapeCharacterLiteral());
            }
            this.readNextChar();
            return new LiteralToken(sb.toString());
        }

        // Scan character literal.
        if (this.nextChar == '\'') {
            this.readNextChar();
            char lit = unescapeCharacterLiteral();
            if (this.nextChar != '\'') throw new ScanException("Closing single quote missing");
            this.readNextChar();
            return new LiteralToken(new Character(lit));
        }

        // Scan separator / operator.
        {
            String v = (String) Scanner.JAVA_OPERATORS.get(
                new String(new char[] { (char) this.nextChar })
            );
            if (v != null) {
                for (;;) {
                    this.readNextChar();
                    String v2 = (String) Scanner.JAVA_OPERATORS.get(v + (char) this.nextChar);
                    if (v2 == null) return new OperatorToken(v);
                    v = v2;
                }
            }
        }

        throw new ScanException("Invalid character input \"" + (char) this.nextChar + "\" (character code " + (int) this.nextChar + ")");
    }

    private Token scanNumericLiteral(int initialState) throws ScanException, IOException {
        StringBuffer sb = (initialState == 2) ? new StringBuffer("0.") : new StringBuffer();
        int state = initialState;
        for (;;) {
            switch (state) {
    
            case 0: // First character.
                if (this.nextChar == '0') {
                    state = 6;
                } else
                /* if (Character.isDigit((char) this.nextChar)) */ {
                    sb.append((char) this.nextChar);
                    state = 1;
                }
                break;
    
            case 1: // Decimal digits.
                if (Character.isDigit((char) this.nextChar)) {
                    sb.append((char) this.nextChar);
                } else
                if (this.nextChar == 'l' || this.nextChar == 'L') {
                    this.readNextChar();
                    return new LiteralToken(this.decodeLong(sb.toString(), 10));
                } else
                if (this.nextChar == 'f' || this.nextChar == 'F') {
                    this.readNextChar();
                    return new LiteralToken(this.decodeFloat(sb.toString()));
                } else
                if (this.nextChar == 'd' || this.nextChar == 'D') {
                    this.readNextChar();
                    return new LiteralToken(this.decodeDouble(sb.toString()));
                } else
                if (this.nextChar == '.') {
                    sb.append('.');
                    state = 2;
                } else
                if (this.nextChar == 'E' || this.nextChar == 'e') {
                    sb.append('E');
                    state = 3;
                } else
                {
                    return new LiteralToken(this.decodeInteger(sb.toString(), 10));
                }
                break;
    
            case 2: // After decimal point.
                if (Character.isDigit((char) this.nextChar)) {
                    sb.append((char) this.nextChar);
                } else
                if (this.nextChar == 'e' || this.nextChar == 'E') {
                    sb.append('E');
                    state = 3;
                } else
                if (this.nextChar == 'f' || this.nextChar == 'F') {
                    this.readNextChar();
                    return new LiteralToken(this.decodeFloat(sb.toString()));
                } else
                if (this.nextChar == 'd' || this.nextChar == 'D') {
                    this.readNextChar();
                    return new LiteralToken(this.decodeDouble(sb.toString()));
                } else
                {
                    return new LiteralToken(this.decodeDouble(sb.toString()));
                }
                break;
    
            case 3: // Read exponent.
                if (Character.isDigit((char) this.nextChar)) {
                    sb.append((char) this.nextChar);
                    state = 5;
                } else
                if (this.nextChar == '-' || this.nextChar == '+') {
                    sb.append((char) this.nextChar);
                    state = 4;
                } else
                {
                    throw new ScanException("Exponent missing after \"E\"");
                }
                break;
    
            case 4: // After exponent sign.
                if (Character.isDigit((char) this.nextChar)) {
                    sb.append((char) this.nextChar);
                    state = 5;
                } else
                {
                    throw new ScanException("Exponent missing after \"E\" and sign");
                }
                break;
    
            case 5: // After first exponent digit.
                if (Character.isDigit((char) this.nextChar)) {
                    sb.append((char) this.nextChar);
                } else
                if (this.nextChar == 'f' || this.nextChar == 'F') {
                    this.readNextChar();
                    return new LiteralToken(this.decodeFloat(sb.toString()));
                } else
                if (this.nextChar == 'd' || this.nextChar == 'D') {
                    this.readNextChar();
                    return new LiteralToken(this.decodeDouble(sb.toString()));
                } else
                {
                    return new LiteralToken(this.decodeDouble(sb.toString()));
                }
                break;
    
            case 6: // After leading zero
                if ("01234567".indexOf(this.nextChar) != -1) {
                    sb.append((char) this.nextChar);
                    state = 7;
                } else
                if (this.nextChar == 'l' || this.nextChar == 'L') {
                    this.readNextChar();
                    return new LiteralToken(new Long(0L));
                } else
                if (this.nextChar == 'f' || this.nextChar == 'F') {
                    this.readNextChar();
                    return new LiteralToken(new Float(0F));
                } else
                if (this.nextChar == 'd' || this.nextChar == 'D') {
                    this.readNextChar();
                    return new LiteralToken(new Double(0D));
                } else
                if (this.nextChar == '.') {
                    sb.append("0.");
                    state = 2;
                } else
                if (this.nextChar == 'E' || this.nextChar == 'e') {
                    sb.append('E');
                    state = 3;
                } else
                if (this.nextChar == 'x' || this.nextChar == 'X') {
                    state = 8;
                } else
                {
                    return new LiteralToken(new Integer(0));
                }
                break;
    
            case 7: // In octal literal.
                if ("01234567".indexOf(this.nextChar) != -1) {
                    sb.append((char) this.nextChar);
                } else
                if (this.nextChar == 'l' || this.nextChar == 'L') {
                    // Octal long literal.
                    this.readNextChar();
                    return new LiteralToken(this.decodeLong(sb.toString(), 8));
                } else
                {
                    // Octal int literal
                    return new LiteralToken(this.decodeInteger(sb.toString(), 8));
                }
                break;
    
            case 8: // First hex digit
                if (Character.digit((char) this.nextChar, 16) != -1) {
                    sb.append((char) this.nextChar);
                    state = 9;
                } else
                {
                    throw new ScanException("Hex digit expected after \"0x\"");
                }
                break;
    
            case 9:
                if (Character.digit((char) this.nextChar, 16) != -1) {
                    sb.append((char) this.nextChar);
                } else
                if (this.nextChar == 'l' || this.nextChar == 'L') {
                    // Hex long literal
                    this.readNextChar();
                    return new LiteralToken(this.decodeLong(sb.toString(), 16));
                } else
                {
                    // Hex long literal
                    return new LiteralToken(this.decodeInteger(sb.toString(), 16));
                }
                break;
            }
            this.readNextChar();
        }
    }

    private Integer decodeInteger(String s, int radix) throws ScanException {
        switch (radix) {
        case 10:
            if (s.equals("2147483648")) return Scanner.MAX_INT_PLUS_ONE;
            try {
                return new Integer(s);
            } catch (NumberFormatException e) {
                throw new ScanException("Value of decimal integer literal \"" + s + "\" is out of range");
            }
        case 8:
            {
                int x = 0;
                for (int i = 0; i < s.length(); ++i) {
                    if ((x & 0xe0000000) != 0) throw new ScanException("Value of octal integer literal \"" + s + "\" is out of range");
                    x = (x << 3) + Character.digit(s.charAt(i), 8);
                }
                return new Integer(x);
            }
        case 16:
            {
                int x = 0;
                for (int i = 0; i < s.length(); ++i) {
                    if ((x & 0xf0000000) != 0) throw new ScanException("Value of hexadecimal integer literal \"" + s + "\" is out of range");
                    x = (x << 4) + Character.digit(s.charAt(i), 16);
                }
                return new Integer(x);
            }
        default:
            throw new RuntimeException("Illegal radix " + radix);
        }
    }

    private Long decodeLong(String s, int radix) throws ScanException {
        switch (radix) {
        case 10:
            if (s.equals("9223372036854775808")) return Scanner.MAX_LONG_PLUS_ONE;
            try {
                return new Long(s);
            } catch (NumberFormatException e) {
                throw new ScanException("Value of decimal long literal \"" + s + "\" is out of range");
            }
        case 8:
            {
                long x = 0L;
                for (int i = 0; i < s.length(); ++i) {
                    if ((x & 0xe000000000000000L) != 0L) throw new ScanException("Value of octal long literal \"" + s + "\" is out of range");
                    x = (x << 3) + (long) Character.digit(s.charAt(i), 8);
                }
                return new Long(x);
            }
        case 16:
            {
                long x = 0L;
                for (int i = 0; i < s.length(); ++i) {
                    if ((x & 0xf000000000000000L) != 0L) throw new ScanException("Value of hexadecimal long literal \"" + s + "\" is out of range");
                    x = (x << 4) + (long) Character.digit(s.charAt(i), 16);
                }
                return new Long(x);
            }
        default:
            throw new RuntimeException("Illegal radix " + radix);
        }
    }

    private Float decodeFloat(String s) throws ScanException {
        try {
            return new Float(s);
        } catch (NumberFormatException e) {
            throw new ScanException("Value of float literal \"" + s + "\" is out of range");
        }
    }

    private Double decodeDouble(String s) throws ScanException {
        try {
            return new Double(s);
        } catch (NumberFormatException e) {
            throw new ScanException("Value of float literal \"" + s + "\" is out of range");
        }
    }

    private char unescapeCharacterLiteral() throws ScanException, IOException {
        if (this.nextChar == -1) throw new ScanException("EOF in character literal");

        if (this.nextChar != '\\') {
            char res = (char) this.nextChar;
            this.readNextChar();
            return res;
        }
        this.readNextChar();
        int idx = "btnfr".indexOf(this.nextChar);
        if (idx != -1) {
            char res = "\b\t\n\f\r".charAt(idx);
            this.readNextChar();
            return res;
        }
        idx = "01234567".indexOf(this.nextChar);
        if (idx != -1) {
            int code = idx;
            this.readNextChar();
            idx = "01234567".indexOf(this.nextChar);
            if (idx == -1) return (char) code;
            code = 8 * code + idx;
            this.readNextChar();
            idx = "01234567".indexOf(this.nextChar);
            if (idx == -1) return (char) code;
            code = 8 * code + idx;
            if (code > 255) throw new ScanException("Invalid octal escape");
            this.readNextChar();
            return (char) code;
        }

        char res = (char) this.nextChar;
        this.readNextChar();
        return res;
    }

    // Read one character and store in "nextChar".
    private void readNextChar() throws IOException {
        this.nextChar = this.in.read();
        if (this.nextChar == '\r') {
            ++this.nextCharLineNumber;
            this.nextCharColumnNumber = 0;
            this.crLfPending = true;
        } else
        if (this.nextChar == '\n') {
            if (this.crLfPending) {
                this.crLfPending = false;
            } else {
                ++this.nextCharLineNumber;
                this.nextCharColumnNumber = 0;
            }
        } else
        {
            ++this.nextCharColumnNumber;
        }
//System.out.println("'" + (char) nextChar + "' = " + (int) nextChar);
    }

    public static class Location {
        private Location(String optionalFileName, short lineNumber, short columnNumber) {
            this.optionalFileName = optionalFileName;
            this.lineNumber       = lineNumber;
            this.columnNumber     = columnNumber;
        }
        public String getFileName() { return this.optionalFileName; }
        public short getLineNumber() { return this.lineNumber; }
        public short getColumnNumber() { return this.columnNumber; }
        public String toString() {
            StringBuffer sb = new StringBuffer();
            if (this.optionalFileName != null) {
                sb.append("File ").append(this.optionalFileName).append(", ");
            }
            sb.append("Line ").append(this.lineNumber).append(", ");
            sb.append("Column ").append(this.columnNumber);
            return sb.toString();
        }
        private /*final*/ String optionalFileName;
        private /*final*/ short  lineNumber;
        private /*final*/ short  columnNumber;
    }

    private static final boolean DEBUG = false;

    private /*final*/ String     fileName;  // null == unspecified
    private /*final*/ Reader     in;
    private int              nextChar  = -1;
    private boolean          crLfPending = false;
    private short            nextCharLineNumber   = 1;
    private short            nextCharColumnNumber = 0;

    private Token nextToken, nextButOneToken;
    private short tokenLineNumber;
    private short tokenColumnNumber;

    private static final Map JAVA_KEYWORDS = new HashMap();
    static {
        String[] ks = {
            "abstract", "boolean", "break", "byte", "case", "catch", "char",
            "class", "const", "continue", "default", "do", "double", "else",
            "extends", "final", "finally", "float", "for", "goto", "if",
            "implements", "import", "instanceof", "int", "interface", "long",
            "native", "new", "package", "private", "protected", "public",
            "return", "short", "static", "strictfp", "super", "switch",
            "synchronized", "this", "throw", "throws", "transient", "try",
            "void", "volatile", "while"
        };
        for (int i = 0; i < ks.length; ++i) Scanner.JAVA_KEYWORDS.put(ks[i], ks[i]);
    }
    private static final Map JAVA_OPERATORS = new HashMap();
    static {
        String[] ops = {
            // Separators:
            "(", ")", "{", "}", "[", "]", ";", ",", ".",
            // Operators:
            "=",  ">",  "<",  "!",  "~",  "?",  ":",
            "==", "<=", ">=", "!=", "&&", "||", "++", "--",
            "+",  "-",  "*",  "/",  "&",  "|",  "^",  "%",  "<<",  ">>",  ">>>",
            "+=", "-=", "*=", "/=", "&=", "|=", "^=", "%=", "<<=", ">>=", ">>>=",
        };
        for (int i = 0; i < ops.length; ++i) Scanner.JAVA_OPERATORS.put(ops[i], ops[i]);
    }


    /**
     * An exception that reflects an error during parsing.
     */
    public class ScanException extends LocatedException {
        public ScanException(String message) {
            super(message, new Location(
                Scanner.this.fileName,
                Scanner.this.nextCharLineNumber,
                Scanner.this.nextCharColumnNumber
            ));
        }
    }

    public static class LocatedException extends Exception {
        LocatedException(String message, Scanner.Location optionalLocation) {
            super(message);
            this.optionalLocation = optionalLocation;
        }

        /**
         * Returns the message specified at creation time, preceeded
         * with nicely formatted location information (if any).
         */
        public String getMessage() {
            return (this.optionalLocation == null) ? super.getMessage() : this.optionalLocation.toString() + ": " + super.getMessage();
        }

        /**
         * Returns the {@link Scanner.Location} object specified at
         * construction time (may be <code>null</code>).
         */
        public Scanner.Location getLocation() {
            return this.optionalLocation;
        }

        private final Scanner.Location optionalLocation;
    }
}
