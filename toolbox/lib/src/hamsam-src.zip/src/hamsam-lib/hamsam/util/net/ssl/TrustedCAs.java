/*
 * Hamsam - Instant Messaging API
 * Copyright (C) 2003 Raghu K
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package hamsam.util.net.ssl;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.List;

/**
 * A helper class to find out whether one particular CA is trusted or not.
 *
 * @author Raghu
 */
class TrustedCAs
{
	/**
	 * Single instance of this class.
	 */
	private static TrustedCAs instance = null;

	/**
	 * Mapping from a trusted CA's name to its public key
	 */
	private HashMap map;

	/**
	 * Constructor prevents instantiation.
	 */
	private TrustedCAs()
	{
		this.map = new HashMap();
	}

	/**
	 * Get an instance of this class.
	 *
	 * @return an instance of this class.
	 * @throws ClassNotFoundException
	 */
	public static synchronized TrustedCAs getInstance()
	{
		if(instance == null)
		{
			instance = new TrustedCAs();
			try
			{
				ClassLoader cl = ClassLoader.getSystemClassLoader();
				ObjectInputStream in = new ObjectInputStream(cl.getResourceAsStream("hamsam/util/net/ssl/ca-list.dat"));
				instance.map = (HashMap) in.readObject();
			}
			catch(IOException e)
			{
				// TODO log a message
			}
			catch(ClassNotFoundException e)
			{
				// This will never occur
			}
		}
		return instance;
	}

	public void validate(X509Certificate cert) throws CertificateException
	{
		PublicKey certKey = cert.getPublicKey();
		String certPrincipal = cert.getIssuerDN().toString();

		if(certKey == null || certPrincipal == null)
			throw new CertificateException("Unknown CA");

		List list = (List) this.map.get(certPrincipal);
		if(list == null || !list.contains(certKey))
			throw new CertificateException("Untrusted CA");
	}
}
