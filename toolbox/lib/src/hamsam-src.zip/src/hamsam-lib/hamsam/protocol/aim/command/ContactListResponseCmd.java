/*
 *
 * Hamsam - Instant Messaging API
 *
 * Copyright (C) 2003 Mike Miller <mikemil@users.sourceforge.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 */
package hamsam.protocol.aim.command;

import java.io.IOException;
import java.io.OutputStream;
import java.util.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import hamsam.protocol.aim.util.ByteUtils;
import hamsam.protocol.aim.util.SSIItem;


/**
 * @author mikem
 */
public class ContactListResponseCmd extends Command {

    //~ Instance fields ----------------------------------------------------------------------------

    byte ssiVersion;
    int ssiCount;
    List ssiList;

    //~ Constructors -------------------------------------------------------------------------------

    public ContactListResponseCmd(Command cmd) {
        flapHdr        = cmd.getFlapHdr();
        snacPacket     = cmd.getSNAC();

        byte[] data = cmd.getSNACData();
        ssiVersion     = data[0];
        ssiCount       = ByteUtils.getUShort(data, 1);

        if (ssiCount > 0) {
            ssiList = new ArrayList(ssiCount);
        }

        // position of SSI Item data
        int pos = 3;

        for (int i = 0; i < ssiCount; i++) {

            // extract the SSIItems
            SSIItem item = new SSIItem(data, pos, data.length);
            ssiList.add(item);

            // now bump the pos index
            pos += item.getItemByteLength();
        }

    }

    //~ Methods ------------------------------------------------------------------------------------

    /* (non-Javadoc)
     * @see hamsam.protocol.aim.command.Command#writeCommandData(java.io.OutputStream)
     */
    public void writeCommandData(OutputStream os) throws IOException {
        // we don't write this command, we receive it, so nothing to do here!
    }


    /** Returns a map of group name to list of buddy names
     * @return Map of group name to a list of buddys
     */
    public Map getGroups() {

        Map groupMap = new HashMap();
        Map groupNameMap = new HashMap();

        if ((ssiList != null) && !ssiList.isEmpty()) {

            for (Iterator iter = ssiList.iterator(); iter.hasNext();) {

                SSIItem item = (SSIItem)iter.next();
                int groupId = item.getGroupId();
                int itemType = item.getItemType();

                if (itemType == SSIItem.TYPE_GROUP) {

                    if (!groupNameMap.containsKey(new Integer(groupId))) {
                        groupMap.put(item.getItemName(), new LinkedList());
                        groupNameMap.put(new Integer(groupId), item.getItemName());
                    }
                    
                } else if (itemType == SSIItem.TYPE_BUDDY) {
                    String name = (String)groupNameMap.get(new Integer(groupId));
                    List list = (List)groupMap.get(name);
                    list.add(item.getItemName());
                }
            }
        }

        return groupMap;
    }
}
