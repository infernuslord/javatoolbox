/**
 * @(#)JException.java
 *
 * JReversePro - Java Decompiler / Disassembler.
 * Copyright (C) 2000 2001 Karthik Kumar.
 * EMail: akkumar@users.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it , under the terms of the GNU General Public License as published
 * by the Free Software Foundation; either version 2 of the License,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program.If not, write to
 *  The Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330,
 *  Boston, MA 02111-1307, USA.
 **/
package jreversepro.reflect;

import jreversepro.common.KeyWords;

import java.util.Map;
import java.util.HashMap;
import java.util.Enumeration;
import java.util.Collections;

/**
 * <b>JException</b> is an abstraction of the exception table , that is
 * an optional part of the Method attributes .
 * @author Karthik Kumar.
 **/
public class JException {

    /**
     * Start Pc of the exception handler.
     **/
    private int startPc;

    /**
     * End Pc of the exception handler
     **/
    private int endPc;

    /**
     * Set if the exception handler is for ANY data type for
     * the block - { startpc, endpc }
     **/
    private boolean any;

    /**
     * Map -
     * Key - Handler Pc beginning
     * value -Handler datatype.
     **/
    Map excCatchTable;

    /**
     * Constructor.
     * @param rhsStart StartPc
     * @param rhsEnd EndPc
     * @param rhsHandler HandlerPc of the first handler block
     * for the above mentioned code block.
     * @param rhsType Handler data type.
     **/
    public JException(int rhsStart ,
                int rhsEnd ,
                int rhsHandler ,
                String rhsType) {
        startPc = rhsStart;
        endPc = rhsEnd;
        any = (rhsType.compareTo(KeyWords.ANY) == 0);

        excCatchTable =  new HashMap();
        addCatchBlock(rhsHandler, rhsType);
    }

    /**
     * Adds a new catch block to the code block { startpc, endpc }
     * @param rhsHandlerPc Handler Pc
     * @param rhsType Handler data type.
     **/
    public void addCatchBlock(int rhsHandlerPc, String rhsType) {
        rhsType = (rhsType != null) ? rhsType : KeyWords.ANY;
        excCatchTable.put(new Integer(rhsHandlerPc), rhsType);
    }

    /**
     * @return Returns startpc of this code block.
     **/
    public int getStartPc() {
        return startPc;
    }

    /**
     * @return Returns endpc of this code block.
     **/
    public int getEndPc() {
        return endPc;
    }

    /**
     * @return Returns the Enumeration of handler types.
     **/
    public Enumeration getHandlers() {
        return Collections.enumeration(excCatchTable.entrySet());
    }

    /**
     * Given a pc, if an exceptiontable entry exists such that the
     * the handler begins with this pc, then the handler type is
     * returned. Else this returns null.
     * @param rhsHandlerPc HandlerPc for which type is queried.
     * @return Handler type of the exception handler, if one
     * exists beginning with rhsHandlerPc. null, otherwise.
     **/
    public String getExceptionClass(int rhsHandlerPc) {
        Object obj = excCatchTable.get(new Integer(rhsHandlerPc));
        if (obj == null) {
            return null;
        } else {
            return (String) obj;
        }
    }

    /**
     * @param obj Object to be compared with.
     * @return if two JException objects are equal.
     * false, otherwise.
     **/
    public boolean equals(Object obj) {
        if (!(obj instanceof JException)) {
            return false;
        } else {
            return sameTryBlock((JException) obj);
        }
    }

    /**
     * Checks if the new exception block passed as parameter
     * has the same code block { startpc, endpc } as the current one.
     * @param exc New Exception Block
     * @return Returns true if the code blocks are same for both of
     * them. false, otherwise.
     **/
    public boolean sameTryBlock(JException exc) {
        return (startPc == exc.startPc && endPc == exc.endPc);
    }

    /**
     * @return true. if at least one of the exception handlers
     * is for ANY block. false, otherwise.
     **/
    public boolean containsANYCatchBlock() {
        return excCatchTable.containsValue(KeyWords.ANY);
    }

    /**
     * @return Value of Any
     **/
    public boolean isAny() {
        return any;
    }

    /**
     * @return Stringified form of the class.
     **/
    public String toString() {
        StringBuffer sb = new StringBuffer("");
        Enumeration enum1  = Collections.enumeration(excCatchTable.keySet());
        Enumeration enum2  = Collections.enumeration(excCatchTable.values());

        while (enum1.hasMoreElements()) {
            sb.append("\t\t" + startPc + "\t" + endPc);
            sb.append("\t" + enum1.nextElement());
            sb.append(" "  + enum2.nextElement() + "\n");
        }
        return sb.toString();
    }
}