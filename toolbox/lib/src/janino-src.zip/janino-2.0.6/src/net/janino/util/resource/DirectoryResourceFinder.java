
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino.util.resource;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * A {@link net.janino.util.resource.ResourceFinder} that finds resources in a directory.
 */
public class DirectoryResourceFinder implements ResourceFinder {
    private final File directory;
    private final Map  subdirectoryNameToFiles = new HashMap(); // String => Set => File

    public DirectoryResourceFinder(File directory) {
        this.directory = directory;
    }

    // Implement ResourceFinder.

    public InputStream findResourceAsStream(String resourceName) {
        File file = this.getResourceAsFile(resourceName);
        if (file == null) return null;
        try {
            return new FileInputStream(file);
        } catch (IOException e) {
            return null;
        }
    }
    public URL findResource(String resourceName) {
        File file = this.getResourceAsFile(resourceName);
        if (file == null) return null;
        try {
            return new URL("file", null, file.getPath());
        } catch (MalformedURLException e) {
            return null;
        }
    }
    public String toString() { return "dir:" + this.directory; }

    // Internal helpers.

    private File getResourceAsFile(String resourceName) {
    
        // Determine the subdirectory name (null for no subdirectory).
        int idx = resourceName.lastIndexOf('/');
        String subdirectoryName = (
            idx == -1 ? null :
            resourceName.substring(0, idx).replace('/', File.separatorChar)
        );
    
        // Determine files existing in this subdirectory.
        Set files = (Set) this.subdirectoryNameToFiles.get(subdirectoryName); // Set => File
        if (files == null) {
            File subDirectory = (subdirectoryName == null) ? this.directory : new File(this.directory, subdirectoryName);
            File[] fa = subDirectory.listFiles();
            files = (fa == null) ? Collections.EMPTY_SET : new HashSet(Arrays.asList(fa));
            this.subdirectoryNameToFiles.put(subdirectoryName, files);
        }
    
        // Notice that "File.equals()" performs all the file-system dependent
        // magic like case conversion.
        File file = new File(this.directory, resourceName.replace('/', File.separatorChar));
        if (!files.contains(file)) return null;
    
        return file;
    }
}
