/* ====================================================================
 *
 * Skin Look And Feel 1.2.4 License.
 *
 * Copyright (c) 2000-2003 L2FProd.com.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by L2FProd.com
 *        (http://www.L2FProd.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "Skin Look And Feel", "SkinLF" and "L2FProd.com" must not
 *    be used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact info@L2FProd.com.
 *
 * 5. Products derived from this software may not be called "SkinLF"
 *    nor may "SkinLF" appear in their names without prior written
 *    permission of L2FProd.com.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL L2FPROD.COM OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package com.l2fprod.gui.plaf.light;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;

import javax.swing.JComponent;
import javax.swing.JScrollBar;
import javax.swing.SwingConstants;

import com.l2fprod.gui.plaf.skin.*;
import com.l2fprod.gui.plaf.skin.impl.*;
import com.l2fprod.gui.plaf.skin.impl.gtk.parser.*;
import com.l2fprod.util.ImageUtils;

/**
 * @author    $Author: l2fprod $
 * @created   27 avril 2002
 * @version   $Revision: 1.6 $, $Date: 2002/06/11 18:04:52 $
 */
class LightScrollbar extends AbstractSkinScrollbar implements SwingConstants {

  public LightScrollbar(LightSkin skin) {
    super(skin);
  }

  /**
   * Gets the PreferredSize attribute of the GtkScrollbar object
   *
   * @param scrollbar  Description of Parameter
   * @return           The PreferredSize value
   */
  public Dimension getPreferredSize(JScrollBar scrollbar) {
    return (scrollbar.getOrientation() == JScrollBar.VERTICAL)
        ? new Dimension(19, 48)
        : new Dimension(48, 19);
  }

  /**
   * Gets the MinimumThumbSize attribute of the GtkScrollbar object
   *
   * @return   The MinimumThumbSize value
   */
  public Dimension getMinimumThumbSize() {
    return new Dimension(19, 19);
  }

  /**
   * Gets the ArrowPreferredSize attribute of the GtkScrollbar object
   *
   * @param direction  Description of Parameter
   * @return           The ArrowPreferredSize value
   */
  public Dimension getArrowPreferredSize(int direction) {
    return new Dimension(19, 19);
  }

  /**
   * Description of the Method
   *
   * @return   Description of the Returned Value
   */
  public boolean status() {
    return true;
  }

  /**
   * Description of the Method
   *
   * @param c  Description of Parameter
   * @return   Description of the Returned Value
   */
  public boolean installSkin(JComponent c) {
    return true;
  }

  /**
   * Description of the Method
   *
   * @param g          Description of Parameter
   * @param b          Description of Parameter
   * @param direction  Description of Parameter
   * @return           Description of the Returned Value
   */
  public boolean paintArrow(java.awt.Graphics g, javax.swing.AbstractButton b, int direction) {
    LightButtonBorder.borderPaint(b, g,
                                  0, 0, b.getWidth() - 1, b.getHeight() - 1,
                                  ((LightSkin)getSkin()).getTheme().getScrollBarThumbBackgroundColor(),
                                  ((LightSkin)getSkin()).getTheme().getScrollBarThumbBorderColor());
    return true;
  }

  // track is under thumb
  /**
   * Description of the Method
   *
   * @param g            Description of Parameter
   * @param scrollbar    Description of Parameter
   * @param trackBounds  Description of Parameter
   * @return             Description of the Returned Value
   */
  public boolean paintTrack(Graphics g, JScrollBar scrollbar, Rectangle trackBounds) {
    Color oldColor = g.getColor();
    g.setColor(((LightSkin)getSkin()).getTheme().getScrollBarThumbBackgroundColor());
    g.fillRect(0, 0, trackBounds.width, trackBounds.height);
    g.setColor(oldColor);
    return true;
  }

  // thumb is the variable area
  /**
   * Description of the Method
   *
   * @param g            Description of Parameter
   * @param scrollbar    Description of Parameter
   * @param thumbBounds  Description of Parameter
   * @return             Description of the Returned Value
   */
  public boolean paintThumb(Graphics g, JScrollBar scrollbar, Rectangle thumbBounds) {
    LightButtonBorder.borderPaint(scrollbar, g,
                                  0, 0, thumbBounds.width - 1, thumbBounds.height - 1,
                                  ((LightSkin)getSkin()).getTheme().getScrollBarThumbBackgroundColor(),
                                  ((LightSkin)getSkin()).getTheme().getScrollBarThumbBorderColor());
    return true;
  }

}
