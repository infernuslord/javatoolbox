/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui;

import javax.swing.*;

import java.awt.Graphics;
import java.awt.Color;
import java.awt.Component;
import java.awt.Insets;
import java.awt.Rectangle;


public class FhSysButton extends JButton{
    public static final int UNSPECIFIED = -99999;

    public static final int SIMPLE_ARROW_NORTH = -1;
    public static final int SIMPLE_ARROW_EAST = -2;
    public static final int SIMPLE_ARROW_SOUTH = -3;
    public static final int SIMPLE_ARROW_WEST = -4;
    
    public static final int ARROW_NORTH = 1;
    public static final int ARROW_EAST = 2;
    public static final int ARROW_SOUTH = 3;
    public static final int ARROW_WEST = 4;
    
    public static final int MINIMIZER = 105;
    public static final int CLOSER = 106;
    public static final int RESTORER = 107;
    public static final int MAXIMIZER = 108;
    
    protected int type = ARROW_NORTH;
    protected int extraInset = 2;


    public FhSysButton(int type){
       this(type, 0);
    }


    public FhSysButton(int type, int extraInset){
      super();
      this.type = type;
      this.extraInset = extraInset;
      setMargins(null);
      setRolloverEnabled(true);
    }


    protected static int[][] getArrowMatrix(int width, int height, int type, int color){
      if(height <= 0 || width <= 0) return new int[][]{{color}};
      if(type > 0 && (width < 5 || height < 5)) type = -type;

      if(type%2==0){
    	 int t = width;
    	 width = height;
    	 height = t;
      }
    
      int[][] data = new int[height][width];
    
      if(type > 0){
         int hMax = Math.min(data.length, data[0].length);
         for(int i=0; i < hMax; i++){
             for(int k=0; k <= data[0].length/2; k++){
    		     if(i < hMax -hMax/2){
    			    data[i +(data.length -hMax)/2][k] = (k < data[0].length -data[0].length/2 -i -1 ? 0x00FFFFFF : 0xFFFFFFFF) & color;
    			    data[i +(data.length -hMax)/2][data[0].length -k -1] = (k < data[0].length -data[0].length/2 -i -1 ? 0x00FFFFFF : 0xFFFFFFFF) & color;
    	         }
    		     else{
    			      data[i +(data.length -hMax)/2][k] = (k <= hMax/4 +(data[0].length -hMax)/2 ? 0x00FFFFFF : 0xFFFFFFFF) & color;
    			      data[i +(data.length -hMax)/2][data[0].length -k -1] = (k <= hMax/4 +(data[0].length -hMax)/2 ? 0x00FFFFFF : 0xFFFFFFFF) & color;
    		     }
    		     
             }
    	 }
      }
      else{
           int hMax = Math.min(data.length, data[0].length -data[0].length/2);
           for(int i=0; i < hMax; i++){
    	       for(int k=0; k <= data[0].length/2; k++){
    			   data[i +(data.length -hMax)/2][k] = (k < data[0].length -data[0].length/2 -i -1 ? 0x00FFFFFF : 0xFFFFFFFF) & color;
    			   data[i +(data.length -hMax)/2][data[0].length -k -1] = (k < data[0].length -data[0].length/2 -i -1 ? 0x00FFFFFF : 0xFFFFFFFF) & color;
    	       }
    	   }
      }
      
      return data;
    }


    protected int getExtraInset(){
      return extraInset;
    }


    public int getType(){
      return type;
    }

    public void setType(int type){
        this.type = type;
        repaint();
    }


    public String getUIClassID(){
      return "SysButtonUI";
    }


    public boolean isDefaultButton(){
      return false;
    }


    public boolean isDefaultCapable(){
      return false;
    }


    public boolean isFocusPainted(){
      return false;
    }

    public boolean isFocusTraversable(){
      return false;
    }


    public void paint(Graphics g){
        super.paint(g);
      
        if(type == UNSPECIFIED) return;
      
        if(Math.abs(type) < 100){
            paintCenteredArrow(this, g, getType(), getExtraInset(), null, getForeground());
        }
    }

    public static void paintArrow(Component c, Graphics g, int orientation, Rectangle r, Color highlight, Color foreground){
      if(highlight==null) highlight = UIManager.getDefaults().getColor("Component.absoluteHighlight");
      if(foreground==null) foreground = UIManager.getDefaults().getColor("Component.foreground");
      
      int rotation = 0;
      switch(orientation){
    	     case ARROW_NORTH : break;
    	     case ARROW_EAST : rotation = GraphicsUtils.ROTATE_90; break;
    	     case ARROW_SOUTH : rotation = GraphicsUtils.ROTATE_180; break;
    	     case ARROW_WEST : rotation = GraphicsUtils.ROTATE_270; break;
    	     case SIMPLE_ARROW_NORTH : break;
    	     case SIMPLE_ARROW_EAST : rotation = GraphicsUtils.ROTATE_90; break;
    	     case SIMPLE_ARROW_SOUTH : rotation = GraphicsUtils.ROTATE_180; break;
    	     case SIMPLE_ARROW_WEST : rotation = GraphicsUtils.ROTATE_270; break;
      }
    
      g.drawImage(GraphicsUtils.createTextureImage(getArrowMatrix(r.width, r.height, orientation, highlight.getRGB()), rotation), r.x +1, r.y +1, null);
      g.drawImage(GraphicsUtils.createTextureImage(getArrowMatrix(r.width, r.height, orientation, foreground.getRGB()), rotation), r.x, r.y, null);
    }


    public static void paintCenteredArrow(Component c, Graphics g, int orientation, int extraInset, Color highlight, Color foreground){
      int w = c.getSize().width,
          h = c.getSize().height,
          x = 0,//(c.getSize().width -Math.min(c.getSize().width, c.getSize().height))/2,
          y = 0;//(c.getSize().height -Math.min(c.getSize().width, c.getSize().height))/2;
    
      if(c instanceof JComponent && ((JComponent)c).getBorder()!=null){
    	 w -= ((JComponent)c).getBorder().getBorderInsets(c).left +((JComponent)c).getBorder().getBorderInsets(c).right;
    	 h -= ((JComponent)c).getBorder().getBorderInsets(c).top +((JComponent)c).getBorder().getBorderInsets(c).bottom;
    
    	 x += ((JComponent)c).getBorder().getBorderInsets(c).left;
    	 y += ((JComponent)c).getBorder().getBorderInsets(c).top;
      }
      
      paintArrow(c, g, orientation, new Rectangle(x +extraInset, y +extraInset, w -2*extraInset, h -2*extraInset), highlight, foreground);	
    }


    public void setMargins(Insets ins){
      super.setMargin(new Insets(0, 0, 0, 0));
    }

    public void setExtraInset(int extraInset) {
        this.extraInset = extraInset;
        repaint();
    }

}
