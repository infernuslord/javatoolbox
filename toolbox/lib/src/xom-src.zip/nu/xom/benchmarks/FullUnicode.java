// Copyright 2002, 2003 Elliotte Rusty Harold
// 
// This library is free software; you can redistribute 
// it and/or modify it under the terms of version 2.1 of 
// the GNU Lesser General Public License as published by  
// the Free Software Foundation.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General 
// Public License along with this library; if not, write to the 
// Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
// Boston, MA  02111-1307  USA
// 
// You can contact Elliotte Rusty Harold by sending e-mail to
// elharo@metalab.unc.edu. Please include the word "XOM" in the
// subject line. The XOM home page is temporarily located at
// http://www.cafeconleche.org/XOM/  but will eventually move
// to http://www.xom.nu/

package nu.xom.benchmarks;

import nu.xom.Attribute;
import nu.xom.Document;
import nu.xom.Element;

/**
 * @author Elliotte Rusty Harold
 *
 */
class FullUnicode {

    private Document doc;

    public FullUnicode() {
        Element root = new Element("root");
        doc = new Document(root);           

        for (int i = 0x20; i <= 0xD7FF; i++) {
            Element data = new Element("d");
            data.appendChild(((char) i) + "");
            data.addAttribute(new Attribute("c", String.valueOf(i)));
            root.appendChild(data);
        }
        
        // skip surrogates between 0xD800 and 0xDFFF
        
        for (int i = 0xE000; i <= 0xFFFD; i++) {
            Element data = new Element("d");
            data.appendChild(((char) i) + "");
            data.addAttribute(new Attribute("c", String.valueOf(i)));
            root.appendChild(data);
        }
        
        System.gc();

        // Need to add Plane-1 characters???? but tricky because Java 
        // strings  encode them as surrogate pairs. First, fill  
        // a byte array with the ints from 1D100 to 1D1FF 
        // (the musical symbols)
     /*   ByteArrayOutputStream bout = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bout);
        try {
            for (int i = 0; i < 256; i++) {
                out.writeInt(0x1D100 + i);
            }
            out.flush();
            byte[] music = bout.toByteArray();
            InputStream in = new ByteArrayInputStream(music);
            Reader r = new InputStreamReader(in, "UCS4");
            for (int i = 0; i < 256; i++) {
                int c1 = r.read();
                int c2 = r.read();
                Element data = new Element("d");
                data.appendChild( ((char) c1) + "" + ((char) c2) );
                data.addAttribute(new Attribute("c", String.valueOf(c1)));
                root.appendChild(data);
            }
            
        }
        catch (IOException ex) {
            // shouldn't happen on a byte array 
            ex.printStackTrace();
            throw new RuntimeException("Ooops in setup"); 
             
        } */
        
    }

    // need to spawn a do-nothing thread to keep object live????

    public static void main(String[] args) throws InterruptedException {
        
        // get free memory????
        FullUnicode data = new FullUnicode();
        System.gc();
        System.gc();
        System.gc();
        // print free memory????
        Thread.sleep(50000);
        
    }
  

}
