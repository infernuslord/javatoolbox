// Copyright 2002, 2003 Elliotte Rusty Harold
// 
// This library is free software; you can redistribute 
// it and/or modify it under the terms of version 2.1 of 
// the GNU Lesser General Public License as published by  
// the Free Software Foundation.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General 
// Public License along with this library; if not, write to the 
// Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
// Boston, MA  02111-1307  USA
// 
// You can contact Elliotte Rusty Harold by sending e-mail to
// elharo@metalab.unc.edu. Please include the word "XOM" in the
// subject line. The XOM home page is temporarily located at
// http://www.cafeconleche.org/XOM/  but will eventually move
// to http://www.xom.nu/

package nu.xom.tests;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.io.ByteArrayInputStream;
import java.io.InputStream;

import junit.framework.TestCase;

import nu.xom.Builder;
import nu.xom.Comment;
import nu.xom.DocType;
import nu.xom.Document;
import nu.xom.Element;
import nu.xom.ParseException;
import nu.xom.ProcessingInstruction;
import nu.xom.ValidityException;


/**
 * @author Elliotte Rusty Harold
 *
 */
public class BuilderTest extends TestCase {

    public BuilderTest(String name) {
        super(name);   
    }
    
    private String elementDeclaration = "<!ELEMENT root (#PCDATA)>";
    private String defaultAttributeDeclaration 
      = "<!ATTLIST test name CDATA \"value\">";
    private String attributeDeclaration 
      = "<!ATTLIST root anattribute CDATA #REQUIRED>";
    private String attributeDeclaration2 
      = "<!ATTLIST root anotherattribute CDATA \"value\">";
    private String unparsedEntityDeclaration 
      = "<!ENTITY hatch-pic SYSTEM \"http://www.example.com/images/cup.gif\" NDATA gif>";
    private String internalEntityDeclaration 
      = "<!ENTITY Pub-Status \"This is a pre-release of the specification.\">";
    private String externalEntityDeclarationPublic = 
      "<!ENTITY open-hatch " 
      + "PUBLIC \"-//Textuality//TEXT Standard open-hatch boilerplate//EN\" "
      + "\"http://www.textuality.com/boilerplate/OpenHatch.xml\">";
    private String externalEntityDeclarationSystem = 
      "<!ENTITY test " 
      + "SYSTEM \"http://www.textuality.com/boilerplate/OpenHatch.xml\">";
    private String notationDeclarationSystem = "<!NOTATION ISODATE SYSTEM "
     + "\"http://www.iso.ch/cate/d15903.html\">";
    private String notationDeclarationPublic = "<!NOTATION gif PUBLIC "
    + "\"-//Textuality//TEXT Standard open-hatch boilerplate//EN\">";

    private String source = "<!DOCTYPE test [\r\n"
     + elementDeclaration + "\n" 
     + attributeDeclaration + "\n"
     + defaultAttributeDeclaration + "\n"
     + attributeDeclaration2 + "\n"
     + internalEntityDeclaration + "\n"
     + externalEntityDeclarationPublic + "\n"
     + externalEntityDeclarationSystem + "\n"
     + unparsedEntityDeclaration + "\n"
     + notationDeclarationPublic + "\n"
     + notationDeclarationSystem + "\n"
     + "]>\r\n"
     + "<?xml-stylesheet href=\"file.css\" type=\"text/css\"?>" 
     + "<!-- test -->"
     + "<test xmlns:xlink='http://www.w3.org/TR/1999/xlink'>Hello dear"
     + "\r\n<em id=\"p1\" xmlns:none=\"http://www.example.com\">very important</em>"
     + "<span xlink:type='simple'>here&apos;s the link</span>\r\n"
     + "<svg:svg xmlns:svg='http://www.w3.org/TR/2000/svg'><svg:text>text in a namespace</svg:text></svg:svg>\r\n"
     + "<svg xmlns='http://www.w3.org/TR/2000/svg'><text>text in a namespace</text></svg>"
     + "</test>\r\n"
     + "<!--epilog-->";
     
    private String validDoc = "<!DOCTYPE test [\r\n"
     + "<!ELEMENT test (#PCDATA)>\n" 
     + "]>\r\n"
     + "<?xml-stylesheet href=\"file.css\" type=\"text/css\"?>" 
     + "<!-- test -->"
     + "<test>Hello dear</test>"
     + "<!--epilog-->";
     
    private Builder builder = new Builder();
    private Builder validator = new Builder(true);
    private String base = "http://www.example.com/";

    protected void setUp() {
    }

    public void testBuildFromReader() 
      throws IOException, ParseException {
        StringReader reader1 = new StringReader(source);
        Document document = builder.build(reader1);
        verify(document);        
        assertNull(document.getBaseURI());
    }
    
    public void testBuildFromReaderWithBase()
      throws IOException, ParseException {
        StringReader reader1 = new StringReader(source);
        Document document = builder.build(reader1, base);
        verify(document);        
        assertEquals(base, document.getBaseURI());
        
    }
    
    public void testBuildFromInputStreamWithBase()
      throws IOException, ParseException {
        InputStream in = new ByteArrayInputStream(source.getBytes("UTF-8"));
        Document document = builder.build(in, base);
        verify(document);        
        assertEquals(base, document.getBaseURI());    
    }
    
    public void testBuildFromInputStreamWithoutBase()
      throws IOException, ParseException {
        InputStream in = new ByteArrayInputStream(source.getBytes("UTF-8"));
        Document document = builder.build(in);
        verify(document);        
        assertNull(document.getBaseURI());
    }

    public void testBuildFromStringWithBase()
      throws IOException, ParseException {
        Document document = builder.build(source, base);
        verify(document);       
        assertEquals(base, document.getBaseURI());  
    }
    
    public void testBuildFromStringWithNullBase()
      throws IOException, ParseException {
        Document document = builder.build(source, null);
        verify(document);        
        assertNull(document.getBaseURI());    
    }
    
    
    private void verify(Document document) {
        
        assertTrue(document.getChild(1) instanceof ProcessingInstruction);
        assertTrue(document.getChild(2) instanceof Comment);        
        DocType doctype = document.getDocType();
        Element root = document.getRootElement();

        assertEquals(root.getAttributeCount(), 1);
        assertEquals(root.getAttributeValue("name"), "value");
        assertEquals(root.getQualifiedName(), "test");
        assertEquals(root.getLocalName(), "test");
        assertEquals(root.getNamespaceURI(), "");
        
        assertTrue(doctype != null);
        assertTrue(document.getChild(0) instanceof DocType);
        assertTrue(document.getChild(4) instanceof nu.xom.Comment);
        assertTrue(document.getChild(2) instanceof nu.xom.Comment);
        assertEquals(document.getChild(2).getValue(), " test ");
        assertEquals(document.getChild(4).getValue(), "epilog");
        assertTrue(document.getChild(1) instanceof nu.xom.ProcessingInstruction);
        assertEquals(doctype.getRootElementName(), "test");
        assertNull(doctype.getPublicID());
        assertNull(doctype.getSystemID());
        
        String internalDTDSubset = doctype.getInternalDTDSubset();
        assertTrue(internalDTDSubset, internalDTDSubset.indexOf(elementDeclaration) > 0);
        assertTrue(internalDTDSubset, internalDTDSubset.indexOf(attributeDeclaration) > 0);
        assertTrue(internalDTDSubset, internalDTDSubset.indexOf(attributeDeclaration2) > 0);
        assertTrue(internalDTDSubset, internalDTDSubset.indexOf(internalEntityDeclaration) > 0);
        assertTrue(internalDTDSubset, internalDTDSubset.indexOf(externalEntityDeclarationPublic) > 0);
        assertTrue(internalDTDSubset, internalDTDSubset.indexOf(externalEntityDeclarationSystem) > 0);
        assertTrue(internalDTDSubset, internalDTDSubset.indexOf(unparsedEntityDeclaration) > 0);
        assertTrue(internalDTDSubset, internalDTDSubset.indexOf(notationDeclarationPublic) > 0);
        assertTrue(internalDTDSubset, internalDTDSubset.indexOf(notationDeclarationSystem) > 0);
               
    }

    public void testValidateFromReader() 
      throws IOException, ParseException {
        StringReader reader1 = new StringReader(validDoc);
        Document document = validator.build(reader1);       
        assertNull(document.getBaseURI());
    }
    
    public void testValidateFromReaderWithBase()
      throws IOException, ParseException {
        StringReader reader1 = new StringReader(validDoc);
        Document document = validator.build(reader1, base); 
        assertEquals(base, document.getBaseURI());
        
    }
    
    public void testValidateFromInputStreamWithBase()
      throws IOException, ParseException {
        InputStream in = new ByteArrayInputStream(validDoc.getBytes("UTF-8"));
        Document document = validator.build(in, base);  
        assertEquals(base, document.getBaseURI());  
    }
    
    public void testValidateFromInputStreamWithoutBase()
      throws IOException, ParseException {
        InputStream in = new ByteArrayInputStream(validDoc.getBytes("UTF-8"));
        Document document = validator.build(in);        
        assertNull(document.getBaseURI());
    }

    public void testValidateFromStringWithBase()
      throws IOException, ParseException {
        Document document = validator.build(validDoc, base);        
        assertEquals(base, document.getBaseURI());  
    }
    
    public void testValidateFromStringWithNullBase()
      throws IOException, ParseException {
        Document document = validator.build(validDoc, null);    
        assertNull(document.getBaseURI());  
    }


    public void testCannotBuildNamespaceMalformedDocument()
      throws IOException {
        try {
            Document document = builder.build("<root:root/>", null);
            fail("Builder allowed undeclared prefix");
        }
        catch (ParseException ex) {
            // success    
        }        
    }

    public void testInvalidDocFromReader() 
      throws IOException, ParseException {
        StringReader reader1 = new StringReader(source);
        try {
            Document document = validator.build(reader1);   
            fail("Allowed invalid doc");
        }
        catch (ValidityException ex) {
             // success   
        }
    }
    
    public void testInvalidDocFromReaderWithBase()
      throws IOException, ParseException {
        StringReader reader1 = new StringReader(source);
        try {
            Document document = validator.build(reader1, base); 
            fail("Allowed invalid doc");
        }
        catch (ValidityException ex) {
             // success   
        }
        
    }
    
    public void testInvalidDocFromInputStreamWithBase()
      throws IOException, ParseException {
        InputStream in = new ByteArrayInputStream(source.getBytes("UTF-8"));
        try {
            Document document = validator.build(in, base);  
            fail("Allowed invalid doc");
        }
        catch (ValidityException ex) {
             // success   
        }
    }
    
    public void testInvalidDocFromInputStreamWithoutBase()
      throws IOException, ParseException {
        InputStream in = new ByteArrayInputStream(source.getBytes("UTF-8"));
        try {
            Document document = validator.build(in);        
            fail("Allowed invalid doc");
        }
        catch (ValidityException ex) {
             // success   
        }
    }

    public void testInvalidDocFromStringWithBase()
      throws IOException, ParseException {
        try {
            Document document = validator.build(source, base);        
            fail("Allowed invalid doc");
        }
        catch (ValidityException ex) {
             // success   
        }
    }
    
    public void testInvalidDocFromStringWithNullBase()
      throws IOException, ParseException {
        try {
            Document document = validator.build(source, null);    
            fail("Allowed invalid doc");
        }
        catch (ValidityException ex) {
             // success   
        }
    }

    // Crimson improperly converts 0x0D and 0x0A to spaces
    // even when the attribute type is not CDATA.
    // This bug explains why the canonicalizer tests fail
    // with Crimson
    public void testCrimsonCharacterReferenceBug()
      throws IOException, ParseException {
        String data = new String(
          "<!DOCTYPE test [<!ATTLIST test name ID #IMPLIED>]>"
          + "<test name='&#x0D;'/>");
        InputStream in = new ByteArrayInputStream(data.getBytes("UTF8"));
        Document document = builder.build(in, null);      
        assertEquals("\r", document.getRootElement().getAttributeValue("name"));  
    }
    
    public void testBaseRelativeResolution()
      throws IOException, ParseException {
        Document doc = builder.build(new File("data/baserelative/test.xml"));
    }
    
   // This tests XOM's workaround for a bug in Crimson, Xerces,
   // and possibly other parsers
   public void testBaseRelativeResolutionRemotely()
      throws IOException, ParseException {
        Document doc = builder.build("http://www.cafeconleche.org");
    }
    
   // This test exposes a bug in Crimson and Xerces 
   // and possibly other parsers. I've reported the bug in Xerces.
   // I don't have a workaround for this yet.
   /* public void testBaseRelativeResolutionRemotelyWithDirectory()
      throws IOException, ParseException {
        Document doc = builder.build("http://www.ibiblio.org/xml");
   } */
    


}
