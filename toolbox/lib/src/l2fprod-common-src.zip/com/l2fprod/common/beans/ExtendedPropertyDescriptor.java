/** ===================================================================
 *
 * @PROJECT.FULLNAME@ @VERSION@ License.
 *
 * Copyright (c) @YEAR@ L2FProd.com.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by L2FProd.com
 *        (http://www.L2FProd.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "@PROJECT.FULLNAME@", "@PROJECT.SHORTNAME@" and "L2FProd.com" must not
 *    be used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact info@L2FProd.com.
 *
 * 5. Products derived from this software may not be called "@PROJECT.SHORTNAME@"
 *    nor may "@PROJECT.SHORTNAME@" appear in their names without prior written
 *    permission of L2FProd.com.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL L2FPROD.COM OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package com.l2fprod.common.beans;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.Comparator;

/**
 * ExtendedPropertyDescriptor. <br>
 *  
 */
public class ExtendedPropertyDescriptor extends PropertyDescriptor {

  private String category = "";

  public ExtendedPropertyDescriptor(String propertyName, Class beanClass)
    throws IntrospectionException {
    super(propertyName, beanClass);
  }

  public ExtendedPropertyDescriptor(
    String propertyName,
    Method getter,
    Method setter)
    throws IntrospectionException {
    super(propertyName, getter, setter);
  }

  public ExtendedPropertyDescriptor(
    String propertyName,
    Class beanClass,
    String getterName,
    String setterName)
    throws IntrospectionException {
    super(propertyName, beanClass, getterName, setterName);
  }

  /**
   * Sets this property category
   * 
   * @param category
   * @return this property for chaining calls.
   */
  public ExtendedPropertyDescriptor setCategory(String category) {
    this.category = category;
    return this;
  }

  /**
   * @return the category in which this property belongs
   */
  public String getCategory() {
    return category;
  }

  /**
   * Force this property to be readonly
   * 
   * @return this property for chaining calls.
   */
  public ExtendedPropertyDescriptor setReadOnly() {
    try {
      setWriteMethod(null);
    } catch (IntrospectionException e) {
      e.printStackTrace();
    }
    return this;
  }

  public static ExtendedPropertyDescriptor newPropertyDescriptor(
    String propertyName,
    Class beanClass)
    throws IntrospectionException {
    // the same initialization phase as in the PropertyDescriptor
    Method readMethod = BeanUtils.getReadMethod(beanClass, propertyName);
    Method writeMethod = null;

    if (readMethod == null) {
      throw new IntrospectionException(
        "No getter for property "
          + propertyName
          + " in class "
          + beanClass.getName());
    }

    writeMethod =
      BeanUtils.getWriteMethod(
        beanClass,
        propertyName,
        readMethod.getReturnType());
    
    return new ExtendedPropertyDescriptor(
      propertyName,
      readMethod,
      writeMethod);
  }

  public static Comparator BY_CATEGORY_COMPARATOR = new Comparator() {
    public int compare(Object o1, Object o2) {
      PropertyDescriptor desc1 = (PropertyDescriptor)o1;
      PropertyDescriptor desc2 = (PropertyDescriptor)o2;

      if (desc1 == null && desc2 == null) {
        return 0;
      } else if (desc1 != null && desc2 == null) {
        return 1;
      } else if (desc1 == null && desc2 != null) {
        return -1;
      } else {
        if (desc1 instanceof ExtendedPropertyDescriptor
          && !(desc2 instanceof ExtendedPropertyDescriptor)) {
          return -1;
        } else if (
          !(desc1 instanceof ExtendedPropertyDescriptor)
            && desc2 instanceof ExtendedPropertyDescriptor) {
          return 1;
        } else if (
          !(desc1 instanceof ExtendedPropertyDescriptor)
            && !(desc2 instanceof ExtendedPropertyDescriptor)) {
          return String.CASE_INSENSITIVE_ORDER.compare(
            desc1.getDisplayName(),
            desc2.getDisplayName());
        } else {
          int category =
            String.CASE_INSENSITIVE_ORDER.compare(
              ((ExtendedPropertyDescriptor)desc1).getCategory() == null
                ? ""
                : ((ExtendedPropertyDescriptor)desc1).getCategory(),
              ((ExtendedPropertyDescriptor)desc2).getCategory() == null
                ? ""
                : ((ExtendedPropertyDescriptor)desc2).getCategory());
          if (category == 0) {
            return String.CASE_INSENSITIVE_ORDER.compare(
              desc1.getDisplayName(),
              desc2.getDisplayName());
          } else {
            return category;
          }
        }
      }
    }
  };

}
