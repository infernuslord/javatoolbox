/**
 * L2FProd.com Common Components 0.1-dev License.
 *
 * Copyright 2004 L2FProd.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.l2fprod.common.demo;

import com.l2fprod.common.swing.JDirectoryChooser;
import com.l2fprod.common.swing.JTaskPane;
import com.l2fprod.common.swing.JTaskPaneGroup;
import com.l2fprod.common.swing.LookAndFeelTweaks;

import java.awt.event.ActionEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

/**
 * FolderPage. <br>
 *  
 */
public class FolderPage extends PagePanel {

  public FolderPage(String title) {
    super(title);

    final JDirectoryChooser chooser = new JDirectoryChooser();
    chooser.setControlButtonsAreShown(false);

    JPanel selectedFolderPanel =
      new JPanel(LookAndFeelTweaks.createBorderLayout());
    selectedFolderPanel.add(
      "West",
      new JLabel(Main.RESOURCE.getString("Main.folder.selected")));
    final JTextField textfield;
    selectedFolderPanel.add("Center", textfield = new JTextField());

    PropertyChangeListener listener = new PropertyChangeListener() {
      public void propertyChange(PropertyChangeEvent evt) {
        textfield.setText(
          chooser.getSelectedFile() == null
            ? ""
            : chooser.getSelectedFile().getAbsolutePath());
      }
    };

    chooser.addPropertyChangeListener(
      JDirectoryChooser.SELECTED_FILE_CHANGED_PROPERTY,
      listener);

    JTaskPane taskPane = new JTaskPane();

    // "System" GROUP
    JTaskPaneGroup systemGroup = new JTaskPaneGroup();
    systemGroup.setText(Main.RESOURCE.getString("Main.tasks.systemGroup"));
    systemGroup.setToolTipText(
      Main.RESOURCE.getString("Main.tasks.systemGroup.tooltip"));
    systemGroup.setSpecial(true);
    systemGroup.setIcon(
      new ImageIcon(FolderPage.class.getResource("icons/tasks-email.png")));

    systemGroup.add(
      makeAction(
        Main.RESOURCE.getString("Main.tasks.email"),
        "",
        "icons/tasks-email.png"));
    systemGroup.add(
      makeAction(
        Main.RESOURCE.getString("Main.tasks.delete"),
        "",
        "icons/tasks-recycle.png"));

    taskPane.add(systemGroup);

    // "Office" GROUP
    JTaskPaneGroup officeGroup = new JTaskPaneGroup();
    officeGroup.setText(Main.RESOURCE.getString("Main.tasks.office"));
    officeGroup.add(
      makeAction(
        Main.RESOURCE.getString("Main.tasks.word"),
        "",
        "icons/tasks-writedoc.png"));
    officeGroup.setExpanded(false);
    taskPane.add(officeGroup);

    // "SEE ALSO" GROUP and ACTIONS
    JTaskPaneGroup seeAlsoGroup = new JTaskPaneGroup();
    seeAlsoGroup.setText(Main.RESOURCE.getString("Main.tasks.seealso"));

    seeAlsoGroup.add(
      makeAction(
        "The Internet",
        Main.RESOURCE.getString("Main.tasks.internet.tooltip"),
        "icons/tasks-internet.png"));

    seeAlsoGroup.add(
      makeAction(
        Main.RESOURCE.getString("Main.tasks.help"),
        Main.RESOURCE.getString("Main.tasks.help.tooltip"),
        "icons/tasks-question.png"));
    taskPane.add(seeAlsoGroup);

    // "Details" GROUP
    JTaskPaneGroup detailsGroup = new JTaskPaneGroup();
    detailsGroup.setText(Main.RESOURCE.getString("Main.tasks.details"));

    JEditorPane detailsText = new JEditorPane("text/html", "<html>");
    LookAndFeelTweaks.makeMultilineLabel(detailsText);
    LookAndFeelTweaks.htmlize(detailsText);
    detailsText.setText(Main.RESOURCE.getString("Main.tasks.details.message"));
    detailsGroup.add(detailsText);

    taskPane.add(detailsGroup);

    JScrollPane scroll = new JScrollPane(taskPane);
    scroll.setBorder(null);

    JPanel panel = new JPanel(LookAndFeelTweaks.createBorderLayout());
    panel.add("Center", chooser);
    panel.add("West", scroll);
    
    add(panel, "*");
    add(selectedFolderPanel);
  }

  Action makeAction(String title, String tooltiptext, String iconPath) {
    Action action = new AbstractAction(title) {
      public void actionPerformed(ActionEvent e) {
      }
    };
    action.putValue(
      Action.SMALL_ICON,
      new ImageIcon(FolderPage.class.getResource(iconPath)));
    action.putValue(Action.SHORT_DESCRIPTION, tooltiptext);
    return action;
  }

}
