package multivalent.std.adaptor.pdf;

import java.awt.Font;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;
import java.awt.font.TextAttribute;
import java.util.Arrays;
import java.util.Map;
import java.util.HashMap;
import java.io.IOException;

import multivalent.*;
import multivalent.node.FixedIClip;
import multivalent.node.Fixed;
import multivalent.node.FixedLeafAscii;



/**
	Paints glyphs for a Type 3 font.
	It's a cross between {@link java.awt.Font} and {@link java.awt.font.GlyphVector}.

	@version $Revision: 1.12 $ $Date: 2003/08/29 04:02:46 $
*/
public class FontType3 extends FontPDF {
  static FixedLeafAscii noglyph = new FixedLeafAscii("",null, null);
  static { noglyph.getIbbox().setBounds(0,0, 0,0); noglyph.getBbox().setBounds(0,0, 0,0); noglyph.setValid(true); }

  static Context cx_ = new Context(Toolkit.getDefaultToolkit());

  static final Rectangle EMPTY_SHAPE = new Rectangle(0,0, 0,0);


  /** Trees representing glyphs.  Often just leaves. */
  Node[] glyphs_;

  /** Not the same as content width. */
  double[] advances_;

  /** Translation from from glyph space to text space to Java user space. */
  AffineTransform fontMatrix_;

  /** Translation from from glyph space through text space to Java user space. */
  AffineTransform glyph2user_;

  // data used to construct glyphs on demand
  /** Ordered references to charProcs; <code>null</code>ed when glyph instantiated. */
  String[] chnames_;
  Dict charProcs_;
  /** Faked "page" for PDF.renderStream(). */
  Dict page_;    // => need to set to current page for current /Resources!  dumb, but needed for epodd/volume6/issue4/ep6x4mxf.pdf
  private Dict localpage_ = null;
  Rectangle fontBBox_;
  PDFReader pdfr_;   // if change size (which is rare?) need to regenerate bitmaps, also create bitmaps on demand
  PDF pdf_;     // renderStream


  public FontType3(Dict fontdict, double pointsize, float size, AffineTransform Tm, Dict page, PDF pdf, PDFReader pdfr) throws IOException {
	super(fontdict, pointsize, size, Tm, pdfr);
	assert fontdict!=null && pdfr!=null: fontdict+", "+pdfr;

	Dict res = (Dict)pdfr.getObject(fontdict.get("Resources"));    // if none, use current page, ugh
	if (res!=null) {    // font has own resources, so don't use page's
		localpage_ = new Dict(5);
		localpage_.put("Resources", res);
	}
	setPage(page);

	initGlyphs(fontdict, pdfr);

	pdf_ = pdf;     // for createGlyph
	pdfr_ = pdfr;
  }

  public FontPDF deriveFont(double pointsize, float size, AffineTransform Tm) {
	FontType3 newfont = (FontType3)super.deriveFont(pointsize, size, Tm);
	if (newfont==this) return this;

	Arrays.fill(newfont.glyphs_, null);     // regenerate at new size

	newfont.setGlyph2User(pointsize, Tm);

	// set maxr_;
//System.out.println("derive Type 3 font, "+Tm+" => glyph2txt2user = "+glyph2user_+", canRender="+canRender());

	return newfont;
  }

  /**
	Type 3 fonts potentially need the <code>/Resources</code> dictionary for the <i>current</i> page,
	so set this before using this font on the page.  (Yes, this is bad design -- they should have a local <code>/Resources</code>.)
  */
  public void setPage(Dict page) { page_ = (localpage_!=null? localpage_: page); }

  AffineTransform getFontMatrix() { return fontMatrix_; }

  void setWidths(Dict fd, PDFReader pdfr) throws IOException {
	super.setWidths(fd, pdfr);

	double xscale = fontMatrix_/*glyph2user_*/.getScaleX();
	if (xscale!=1.0) {
		if (fstdwidths_) { widths_ = (int[])widths_.clone(); fstdwidths_=false; }
		for (int i=0,imax=widths_.length; i<imax; i++) widths_[i] *= xscale;
	}
//System.out.print("T3 widths_ ("+widths_.length+") = ["); for (int i=0,imax=widths_.length; i<imax; i++) System.out.print(widths_[i]+" "); System.out.println("]");
  }


  /** For Font.getSize2D(), Font.getMaxChar(), and so on. */
  /*package-private*/ Font createFont(Dict fd, double pointsize, float size, AffineTransform Tm, PDFReader pdfr) throws IOException {
	// glyph to txt
	Object[] fm = (Object[])pdfr.getObject(fd.get("FontMatrix"));
	if (fm!=null) { double[] d = new double[6]; PDF.getDoubles(fm, d, 6); fontMatrix_ = new AffineTransform(d); }
	else fontMatrix_ = new AffineTransform();

	setGlyph2User(pointsize, Tm);

	Map<TextAttribute,Object> map = new HashMap<TextAttribute,Object>(5);
	map.put(TextAttribute.FAMILY, "Times-Roman");     // no /BaseFont
	map.put(TextAttribute.SIZE, new Float(size));   // don't scale by ppi/72.0 !

	return BASEFONT.deriveFont(map);
  }

  void setGlyph2User(double pointsize, AffineTransform Tm) {
	glyph2user_ = new AffineTransform(fontMatrix_);
	AffineTransform Tm0 = new AffineTransform(Tm.getScaleX()*pointsize, Tm.getShearY(), Tm.getShearX(), Tm.getScaleY()*pointsize, 0.0, 0.0);
	glyph2user_.concatenate(Tm0);
//System.out.println(fontMatrix_+" * "+Tm0+" => "+glyph2user_);
  }


  /**
	Prime glyphs, but create individual glyphs on demand.
	Want to create on demand for performance and memory use, and have to since may require /Resources from <i>current</i> page and different pages for all the glyphs!
  */
  void initGlyphs(Dict dict, PDFReader pdfr) throws IOException {
	Object o = pdfr.getObject(dict.get("Encoding"));
	Dict en = (o!=null && COS.CLASS_DICTIONARY==o.getClass()? (Dict)o: null);  // could be name of standard encoding
	Object[] diff = (Object[])pdfr.getObject(en.get("Differences"));

	Rectangle maxr = COS.array2Rectangle((Object[])pdfr.getObject(dict.get("FontBBox")), null, false);
	//maxr_ = new Rectangle2D.Double();
	maxr.width *= glyph2user_.getScaleX(); maxr.height *= glyph2user_.getScaleY();
	//maxr_ = maxr;
	fontBBox_ = maxr;

	charProcs_ = (Dict)pdfr.getObject(dict.get("CharProcs"));
	glyphs_ = new Node[lastch_ - firstch_ + 1]; advances_ = new double[glyphs_.length]; chnames_ = new String[glyphs_.length];
	for (int i=0,imax=diff.length, j=0,jmax=glyphs_.length; i<imax; i++) {
		o = diff[i];
		if (o instanceof Number) j = ((Number)o).intValue() - firstch_;
		else { assert COS.CLASS_NAME==o.getClass();
			if (j<jmax) chnames_[j++] = (String)o;      // matchingshapes.pdf by Ghostscript 5.10 has longer /Differences
		}
	}
  }

  /**
	Convert stream into scaled document subtree.
  */
  void createGlyph(int inx) throws IOException {
	String chname = chnames_[inx];

	PDFReader pdfr = pdfr_;
	Object cpref = charProcs_.get(chname);
	//Dict charProc = (Dict)pdfr.getObject(cpref);
//System.out.println(inx+"/"+chname+"/"+cpref+"  "+charProc);
	InputStreamComposite cin = pdfr.getInputStream(cpref, true);
	// make tree
	Rectangle bounds = new Rectangle(fontBBox_);
	FixedIClip clipp = new FixedIClip(chname,null, null, bounds, bounds);
	try { pdf_.buildStream(page_, clipp, new AffineTransform(glyph2user_), cin, null);
	} catch (/*Parse, IO*/Exception e) {    // skip char
		//e.printStackTrace(); System.err.println(e); System.err.println(cpref+" "+charProc); System.exit(1);
		new multivalent.node.FixedLeafShape("bad_glyph",null, clipp, EMPTY_SHAPE, false, true);
	}
	cin.close();

	Node glyph = clipp;
	advances_[inx] = clipp.getBbox().width * glyph2user_.getScaleX();
	if (clipp.size()==0) glyph = noglyph;   // some just d0/d1.  (also i/o error)
	else if (clipp.size()==1 && clipp.sizeSticky()==0) {
		glyph = clipp.removeChildAt(0);
		glyph.setName(clipp.getName());
	}
	//Rectangle ibbox = ((Fixed)glyph).getIbbox();

	if (!glyph.isValid()) { cx_.reset(); glyph.formatNode(0,0, cx_); }
	//Rectangle bbox = glyph.getBbox();
	//glyph.baseline = bbox.height + bbox.y; bbox.y = 0; => no baseline for a font!

	assert glyph.isValid();
	glyphs_[inx] = glyph;
//glyph.dump();
//System.out.print((char)(inx+firstch_)+"/"+glyphs_[inx].bbox.width);
  }

  public double measureText(StringBuffer txt8, int s, int e) {
	double width = super.measureText(txt8, s, e);
	for (int i=s; i<e; i++) width += getAdvance(txt8.charAt(i));
	return width;
  }

  public Node getGlyph(char ch) {
	assert firstch_<=ch && ch<=lastch_: firstch_+" .. "+ch+" .. "+lastch_;
	int inx = ch - firstch_;
	if (glyphs_[inx]==null) try { createGlyph(inx); } catch (IOException ioe) {}
	assert glyphs_[inx] != null: (int)ch;   // can have holes, but then shouldn't request those chars
	return glyphs_[inx];
  }

  public double getAdvance(char ch) {
	int inx = ch - firstch_;
	if (glyphs_[inx]==null) try { createGlyph(inx); } catch (IOException ioe) {}
	return advances_[inx];
  }
}
