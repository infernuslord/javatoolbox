package com.l2fprod.tools.uis;

import com.l2fprod.util.IniFile;
import com.l2fprod.tools.ImageUtils;

import java.io.*;

/**
 * 
 * @author $Author: lavignfr $
 * @version $Revision: 1.1.1.1 $, $Date: 2000/04/10 14:15:42 $
 */
public class Convert {
    
  static String FOLDER = "gtktest";
  
  static String UIS_START = "UIS{";
  static String UIS_END = "}";
  
  public static File uisDirectory;
  
    public static void process(IniFile ini, String template,
                               String outname, String folder) throws Exception {
      System.out.println("Processing " + template);
      PrintWriter out = new PrintWriter(new FileOutputStream(outname));
      BufferedReader reader = new BufferedReader(new FileReader(template));
      String read;
      while ((read = reader.readLine()) != null) {
        out.println(parseTag(ini, read, folder));
      }
      out.flush();
      out.close();
    }
  
  public static String parseTag(IniFile ini, String s, String folder) throws Exception {
    int index = s.indexOf(UIS_START);
    if (index == -1)
	    return s;
    else {
	    int endIndex = s.indexOf(UIS_END, index + UIS_START.length());
	    if (endIndex == -1)
        throw new Exception("Tag not closed");
	    String tag = s.substring(index + UIS_START.length(), endIndex);
	    return s.substring(0, index) + getValue(ini, tag, folder) + parseTag(ini, s.substring(endIndex + 1), folder);
    }
  }
  
  public static String getValue(IniFile ini, String tag, String folder) throws Exception {
    int colon = tag.indexOf(":");
    if (colon == -1) { // simple value
	    int slash = tag.indexOf("/");
	    String section = tag.substring(0, slash);
	    String key = tag.substring(slash + 1);
      String value = ini.getKeyValue(section, key);
	    return value==null?"0":value;
    } else {
	    String type = tag.substring(0, colon);
	    String subtag = tag.substring(colon+1);	
	    if ("Button".equals(type)) {
        int sharp = subtag.indexOf("#");
        String section = ini.getSectionWhere(new String[][]{
          { "Action", subtag.substring(0, sharp) }
        });
        return getValue(ini, "Image:" + section + "/ButtonImage#" + subtag.substring(sharp+1),
                        folder);
	    } else if ("Image".equals(type) || "ImageH".equals(type)) {
        boolean horizontal = "ImageH".equals(type);
        
        // handle image Image:Section/Key#nnn|filename
        int sharp = subtag.indexOf("#");
        String filename = getValue(ini, subtag.substring(0, sharp), folder);
        String position = subtag.substring(sharp+1);		
        int index = Integer.parseInt(position.substring(0, position.indexOf(",")));
        int max;
        
        String dest;
        int pipeIndex = position.indexOf("|");
        if (pipeIndex != -1) {
          max = Integer.parseInt(position.substring(position.indexOf(",") + 1, pipeIndex));
          dest = position.substring(pipeIndex + 1);
        } else {
          max = Integer.parseInt(position.substring(position.indexOf(",") + 1));
          dest = "file" + (count++) + "." + System.getProperty("file.extension");
        }
        ImageUtils.createPicture(new File(uisDirectory, ".." + File.separator + filename).getCanonicalPath(),
                                 index, max,
                                 FOLDER + File.separator + folder +
                                 File.separator + dest, horizontal);
        return dest;
	    }
	    return tag;
    }
  }
  
  static int count = 0;
  
  public static void main(String[] args) throws Exception {
    // Usage: java Convert uisfile gtktemplate kdetemplate destdir
    uisDirectory = new File(args[0]).getParentFile();
    
    FOLDER = args[3];
    
    IniFile ini = new IniFile(args[0]);
    
    new File(FOLDER + "\\gtk\\").mkdirs();
    new File(FOLDER + "\\kde\\").mkdirs();
    
    process(ini, args[1], FOLDER + "\\gtk\\gtkrc", "gtk");
    process(ini, args[2], FOLDER + "\\kde\\kde.themerc", "kde");
    
    File f = new File(FOLDER + "\\skinlf-themepack.xml");
    PrintWriter out = new PrintWriter(new FileWriter(f));
    out.println("<?xml version=\"1.0\"?>");
    out.println("<skinlf-themepack require=\"0.3\">");
    out.println("<property name=\"JDesktopPane.backgroundEnabled\" value=\"false\" />");
    out.println("<property name=\"PopupMenu.animation\" value=\"true\" />");
    out.println("<skin>");
    out.println("<skin url=\"gtk/gtkrc\"></skin>");
    out.println("<skin url=\"kde/kde.themerc\"></skin>");
    out.println("</skin>");
    out.println("</skinlf-themepack>");
    out.flush();
    out.close();
    
    System.exit(0);
  }

}

