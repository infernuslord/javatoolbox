/*
  Copyright (C) 2003-2004 Robert F. Beeger (robert at beeger dot net)
  Licensed under the Academic Free License version 2.0
  OSI Certified Open Source Software

  Visit http://squareness.sourceforge.net/ for new releases of Squareness Look And Feel and other
  skins from the Squareness series.
*/
package net.beeger.squareness.delegate;

import java.awt.Container;
import java.awt.Graphics;
import java.awt.LayoutManager;
import javax.swing.JComponent;
import javax.swing.JInternalFrame;
import javax.swing.JMenuBar;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicInternalFrameTitlePane;
import javax.swing.plaf.basic.BasicInternalFrameUI;

import net.beeger.squareness.SquarenessConstants;
import net.beeger.squareness.util.SquarenessListenerFactory;

/**
 * The Squareness Internal Frame UI delegate.
 */
public class SquarenessInternalFrameUI extends BasicInternalFrameUI
{
  /**
   * Create the UI delegate for the given component
   * 
   * @param component The component for which to create the ui delegate
   * @return The created ui delegate
   */
  public static ComponentUI createUI (JComponent component)
  {
    return new SquarenessInternalFrameUI((JInternalFrame) component);
  }

  

  /**
   * Create the UI delegate.
   *
   * @param internalFrame The internal frame this delegate will be used for.
   */
  public SquarenessInternalFrameUI (JInternalFrame internalFrame)
  {
    super(internalFrame);
  }

  /**
   * Create the title bar of the internal frame.
   *
   * @param internalFrame The internalframe for which to create the title bar.
   * @return The created title bar.
   */
  protected JComponent createNorthPane (JInternalFrame internalFrame)
  {
    titlePane = new SquarenessInternalFrameTitlePane(internalFrame);
    return titlePane;
  }

  /**
   * The class for title bars of internal frames.
   */
  protected static class SquarenessInternalFrameTitlePane extends BasicInternalFrameTitlePane
  {
    /**
     * Create the title bar.
     *
     * @param internalFrame The internal frame to create the title bar for.
     */
    public SquarenessInternalFrameTitlePane (JInternalFrame internalFrame)
    {
      super(internalFrame);
      maxButton.putClientProperty(SquarenessConstants.ROLLOVER_CLENT_PROPERTY_KEY, Boolean.FALSE);
      maxButton.addMouseListener(SquarenessListenerFactory.getButtonRolloverMouseListener());
      iconButton.putClientProperty(SquarenessConstants.ROLLOVER_CLENT_PROPERTY_KEY, Boolean.FALSE);
      iconButton.addMouseListener(SquarenessListenerFactory.getButtonRolloverMouseListener());
      closeButton.putClientProperty(SquarenessConstants.ROLLOVER_CLENT_PROPERTY_KEY, Boolean.FALSE);
      closeButton.addMouseListener(SquarenessListenerFactory.getButtonRolloverMouseListener());
      maxButton.setBorder(new EmptyBorder(0, 0, 0, 0));
      iconButton.setBorder(new EmptyBorder(0, 0, 0, 0));
      closeButton.setBorder(new EmptyBorder(0, 0, 0, 0));
    }

    protected LayoutManager createLayout ()
    {
      return new SquarenessTitlePaneLayout();
    }

    protected JMenuBar createSystemMenuBar ()
    {
      return new SquarenessSystemMenuBar();
    }

    protected class SquarenessTitlePaneLayout extends BasicInternalFrameTitlePane.TitlePaneLayout
    {
      public void layoutContainer (Container container)
      {
        boolean leftToRight = frame.getComponentOrientation().isLeftToRight();

        int width = getWidth();
        int height = getHeight();
        int x;

        int buttonHeight = closeButton.getIcon().getIconHeight();
        int buttonWidth = closeButton.getIcon().getIconWidth();
        int y = (height - buttonHeight) >> 1;

        x = (leftToRight) ? 2 : width - 2;
        menuBar.setBounds(x, y, 2, 16);

        x = (leftToRight) ? width - buttonWidth - 2 : 2;

        if (frame.isClosable())
        {
          closeButton.setBounds(x, y, buttonWidth, buttonHeight);
          x += (leftToRight) ? -(buttonWidth + 2) : buttonWidth + 2;
        }

        if (frame.isMaximizable())
        {
          maxButton.setBounds(x, y, buttonWidth, buttonHeight);
          x += (leftToRight) ? -(buttonWidth + 2) : buttonWidth + 2;
        }

        if (frame.isIconifiable())
        {
          iconButton.setBounds(x, y, buttonWidth, buttonHeight);
        }
      }
    }

    protected class SquarenessSystemMenuBar extends BasicInternalFrameTitlePane.SystemMenuBar
    {
      public void paint (Graphics g)
      {
      }
    }
  }

}

/*
  $Log: SquarenessInternalFrameUI.java,v $
  Revision 1.5  2004/03/08 23:01:33  rbeeger
  Optimized imports.

  Revision 1.4  2004/03/08 22:53:11  rbeeger
  Fixed placement of frame buttons and painting of frame borders.

  Revision 1.3  2004/03/08 15:12:26  rbeeger
  Added and enhanced comments.
  Simplified code.

  Revision 1.2  2004/02/14 19:12:34  rbeeger
  Updated copyright statement
  Added cvs log directive at the end of each file
  Optimized imports
  Reformated code

 */
