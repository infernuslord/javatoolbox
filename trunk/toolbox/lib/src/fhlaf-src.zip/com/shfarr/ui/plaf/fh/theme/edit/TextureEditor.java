/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh.theme.edit;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Iterator;

import javax.swing.ButtonGroup;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;

import com.shfarr.ui.GraphicsUtils;
import com.shfarr.ui.layouts.FlexibleGridLayout;
import com.shfarr.ui.layouts.QueueLayout;
import com.shfarr.ui.plaf.fh.textures.CompoundTexture;
import com.shfarr.ui.plaf.fh.textures.GradientTexture;
import com.shfarr.ui.plaf.fh.textures.MatrixTexture;
import com.shfarr.ui.plaf.fh.textures.Texture;


public class TextureEditor extends JPanel implements ActionListener, ChangeListener, ItemListener{
    private JPanel sidePanel = null;
    private JPanel centerPanel = null;
    private JPanel northPanel = null;
    private JComboBox matrixNamesCombo = null;
    private JPanel southPanel = null;
    private JComboBox texturesCombo = null;
    private JPanel textureDisplayer = null;
    private JPanel editor = null;
    private JPanel matrixTextureEditor = null;
    private Texture currentTexture = null;
    private JTable colorList = null;
    private JTable textureList = null;
    private JPanel gradientTextureEditor = null;
    private JPanel compoundTextureEditor = null;
    private JSpinner rotationSpinner = null;
    private JComboBox colorNames = null;
    private String type = "matrix";
    private JRadioButton[] radios = null;
    private JTable workingList = null;
    private JPanel spinnerPanel = null;
    private JPanel listButtonPanel = null;
    
    
    public TextureEditor(){
        super(new BorderLayout(3, 3));
        setBorder(new EmptyBorder(10, 4, 0, 0));
        
        getNorthPanel();
                
        add(getSidePanel(), "East");
        add(getCenterPanel(), "Center");
    }

    protected JPanel getCenterPanel(){
        if(centerPanel == null){
            centerPanel = new JPanel(new BorderLayout(4, 4));
            centerPanel.add(getEditor(), "Center");
            centerPanel.add(getSouthPanel(), "North");
        }
    
        return centerPanel;
    }

    protected JPanel getEditor(){
        if(editor == null){
            editor = new JPanel(new BorderLayout(4, 4));
            editor.setBorder(new EmptyBorder(4, 4, 4, 0));
        }
    
        return editor;
    }

    protected JTable getColorList(){
        if(colorList == null){
            colorList = new JTable(new DefaultTableModel(new String[][]{}, new String[]{"Colors"}));
            colorList.getColumnModel().getColumn(0).setCellEditor(new DefaultCellEditor(getColorNames()));
        }
    
        return colorList;
    }
    
    protected JTable getTextureList(){
        if(textureList == null){
            textureList = new JTable(new DefaultTableModel(new String[][]{}, new String[]{"Textures"}));
            
            JComboBox combo = new JComboBox();
            combo.addActionListener(this);
            combo.setActionCommand("Subtexture Selected");

            for(Iterator i = ThemeEditor.instance().getEditedTheme().texturePalette().keySet().iterator(); i.hasNext(); ) combo.addItem((String)i.next());
            
            textureList.getColumnModel().getColumn(0).setCellEditor(new DefaultCellEditor(combo));
        }
    
        return textureList;
    }
    
    protected JComboBox getColorNames(){
        if(colorNames == null){
            colorNames = new JComboBox();
            
            for(Iterator i = ThemeEditor.instance().getEditedTheme().colorPalette().keySet().iterator(); i.hasNext(); ) {
                String name = (String)i.next();
                colorNames.addItem(name);
            }
            
            for(int i = -10; i < 10; i++) colorNames.addItem("" + i);
        }
    
        return colorNames;
    }

    protected JSpinner getRotationSpinner(){
        if(rotationSpinner == null){
            rotationSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 270, 90));
            rotationSpinner.addChangeListener(this);
        }
    
        return rotationSpinner;
    }
    
    protected JPanel getListButtonPanel(){
        if(listButtonPanel == null){
            listButtonPanel = new JPanel(new FlexibleGridLayout(2, 2, 4, 4));

            JButton addC = new JButton("+");
            addC.addActionListener(this);
            addC.setMargin(new Insets(1, 3, 1, 3)); 

            JButton remC = new JButton("-");
            remC.addActionListener(this); 
            remC.setMargin(new Insets(1, 3, 1, 3)); 

            JButton moveR = new JButton(">");
            moveR.addActionListener(this); 
            moveR.setMargin(new Insets(1, 3, 1, 3)); 

            JButton moveL = new JButton("<");
            moveL.addActionListener(this); 
            moveL.setMargin(new Insets(1, 3, 1, 3)); 
            
            listButtonPanel.add(addC);
            listButtonPanel.add(remC);

            listButtonPanel.add(moveL);
            listButtonPanel.add(moveR);
        }
    
        return listButtonPanel;
    }
    
    protected JPanel getSpinnerPanel(){
        if(spinnerPanel == null){
            spinnerPanel = new JPanel(new QueueLayout(4, QueueLayout.VERTICAL, QueueLayout.STRECH_COMPONENTS));
            
            spinnerPanel.add(new JLabel("Rotation", JLabel.LEFT));
            spinnerPanel.add(getRotationSpinner());
            spinnerPanel.add(new JLabel());
        }
    
        return spinnerPanel;
    }
    
    protected JPanel getGradientTextureEditor(){
        if(gradientTextureEditor == null){
            gradientTextureEditor = new JPanel(new BorderLayout(4, 4));
            
            JPanel actPanel = new JPanel(new QueueLayout(4, QueueLayout.VERTICAL, QueueLayout.STRECH_COMPONENTS));
            
            JScrollPane scp = new JScrollPane(getColorList());
            scp.setPreferredSize(new Dimension(100, 30));
            
            gradientTextureEditor.add(scp, "Center");
            gradientTextureEditor.add(actPanel, "West");
        }
    
        return gradientTextureEditor;
    }

    protected JPanel getCompoundTextureEditor(){
        if(compoundTextureEditor == null){
            compoundTextureEditor = new JPanel(new BorderLayout(4, 4));
            
            JPanel actPanel = new JPanel(new QueueLayout(4, QueueLayout.VERTICAL, QueueLayout.STRECH_COMPONENTS));
            
            JScrollPane scp = new JScrollPane(getTextureList());
            scp.setPreferredSize(new Dimension(100, 30));
            
            compoundTextureEditor.add(scp, "Center");
            compoundTextureEditor.add(actPanel, "West");
        }
    
        return compoundTextureEditor;
    }
    
    protected JPanel getTextureDisplayer(){
        if(textureDisplayer == null){
            textureDisplayer = new JPanel(){
                public void paint(Graphics g){
                    super.paint(g);

                    if(currentTexture != null){
                        Insets i = getBorder() != null ? getBorder().getBorderInsets(this) : new Insets(0, 0, 0, 0);
                         
                        Rectangle r = new Rectangle(0, 0, getWidth() -1, getHeight() -1);
                        
                        r.x += i.left;
                        r.y += i.top;
                        r.width -= i.left +i.right;
                        r.height -= i.top +i.bottom;

                        r.width = r.width/2;
                        
                        GraphicsUtils.paintTiledBackground(g, r, 5);
                        currentTexture.apply(r, (Graphics2D)g, this);
                        
                        r.x += r.width;  

                        currentTexture.apply(r, (Graphics2D)g, this);

                        g.setColor(Color.black);
                        g.drawLine(r.x, r.y, r.x, r.y +r.height);
            
                        r.x -= r.width;
                        r.width *= 2;
                        
                        g.drawRect(r.x, r.y, r.width, r.height);
                    }
                }
            };
            
//            textureDisplayer.setBorder(new TitledBorder(new CompoundBorder(new MatteBorder(1, 1, 1, 1, UIManager.getColor("Component.moderatedShadow")), new EmptyBorder(0, 2, 2, 2)), " Sample "));
            textureDisplayer.setPreferredSize(new Dimension(100, 100));
        }
    
        return textureDisplayer;
    }

    protected JPanel getSouthPanel(){
        if(southPanel == null){
            southPanel = new JPanel(new QueueLayout(4, QueueLayout.HORIZONTAL, QueueLayout.STRECH_COMPONENTS));
            
            southPanel.add(new JLabel("Texture", JLabel.RIGHT));
            southPanel.add(getTexturesCombo());
        }
    
        return southPanel;
    }
    
    protected JPanel getMatrixTextureEditor(){
        if(matrixTextureEditor == null){
            matrixTextureEditor = new JPanel(new QueueLayout(4, QueueLayout.VERTICAL, QueueLayout.STRECH_COMPONENTS));
            matrixTextureEditor.add(new JLabel("Matrix"));
            matrixTextureEditor.add(getMatrixNamesCombo());
        }
    
        return matrixTextureEditor;
    }
    
    protected JComboBox getMatrixNamesCombo(){
        if(matrixNamesCombo == null){
            matrixNamesCombo = new JComboBox();
            
            for(Iterator i = ThemeEditor.instance().getEditedTheme().matrixPalette().keySet().iterator(); i.hasNext(); ) {
                String name = (String)i.next();
                if(name.startsWith("textures/.")) matrixNamesCombo.addItem(name.substring(10));
            }
        }
    
        return matrixNamesCombo;
    }

    protected JComboBox getTexturesCombo(){
        if(texturesCombo == null){
            texturesCombo = new JComboBox();
            texturesCombo.setEditable(true);
            texturesCombo.addItemListener(this);

            for(Iterator i = ThemeEditor.instance().getEditedTheme().texturePalette().keySet().iterator(); i.hasNext(); ) {
                String name = (String)i.next();
                texturesCombo.addItem(name);
            }
            
            texturesCombo.setPreferredSize(new Dimension(Math.max(texturesCombo.getPreferredSize().width, 150), texturesCombo.getPreferredSize().height));
        }
    
        return texturesCombo;
    }    

    protected JPanel getNorthPanel(){
        if(northPanel == null){
            northPanel = new JPanel(new FlexibleGridLayout(1, 4, 4, 4));
            northPanel.setBorder(new EmptyBorder(4, 0, 4, 0));
            
            radios = new JRadioButton[4];
            
            radios[0] = new JRadioButton("None");
            radios[0].addActionListener(this);

            radios[1] = new JRadioButton("Matrix Based");
            radios[1].setSelected(true);
            radios[1].addActionListener(this);

            radios[2] = new JRadioButton("Gradient");
            radios[2].addActionListener(this);

            radios[3] = new JRadioButton("Compound");
            radios[3].addActionListener(this);

            ButtonGroup group = new ButtonGroup();
            
            group.add(radios[0]);
            group.add(radios[1]);
            group.add(radios[2]);
            group.add(radios[3]);
            
            northPanel.add(radios[0]);
            northPanel.add(radios[1]);
            northPanel.add(radios[2]);
            northPanel.add(radios[3]);
        }
    
        return northPanel;
    }

    protected JPanel getSidePanel(){
        if(sidePanel == null){
            sidePanel = new JPanel(new QueueLayout(4, QueueLayout.VERTICAL, QueueLayout.STRECH_COMPONENTS));
            sidePanel.setBorder(new EmptyBorder(0, 4, 4, 4));
            
            JButton save = new JButton("Save");
            save.addActionListener(this);
            
            JButton revert = new JButton("Revert");
            revert.addActionListener(this);

            JButton delete = new JButton("Delete");
            delete.addActionListener(this);

            JButton set = new JButton("Add / Set");
            set.addActionListener(this);
            
            sidePanel.add(save);
            sidePanel.add(revert);
            sidePanel.add(new JPanel());
            sidePanel.add(set);
            sidePanel.add(delete);
        }
    
        return sidePanel;
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource() instanceof JRadioButton) selectSubEditor(e.getActionCommand());
        else if(e.getActionCommand().equals("+")){
            ((DefaultTableModel)workingList.getModel()).addRow(new String[]{workingList.getColumnModel().getColumn(0).getCellEditor().getCellEditorValue().toString()});
            updateTexture();
        }
        else if(e.getActionCommand().equals("-")){
            if(workingList.getSelectedRow() != -1) ((DefaultTableModel)workingList.getModel()).removeRow(workingList.getSelectedRow());
            updateTexture();
        }
        else if(e.getActionCommand().equals("<")){
            int se = workingList.getSelectedRow(); 
            
            if(se > 0){
                String obj = (String)((DefaultTableModel)workingList.getModel()).getValueAt(se, 0);
                ((DefaultTableModel)workingList.getModel()).removeRow(workingList.getSelectedRow());
                ((DefaultTableModel)workingList.getModel()).insertRow(se -1, new String[]{obj});
                workingList.getSelectionModel().setSelectionInterval(se -1, se -1);
            }
            
            updateTexture();
        }
        else if(e.getActionCommand().equals(">")){
            int se = workingList.getSelectedRow(); 
            
            if(se < workingList.getRowCount() -1){
                String obj = (String)((DefaultTableModel)workingList.getModel()).getValueAt(se, 0);
                ((DefaultTableModel)workingList.getModel()).removeRow(workingList.getSelectedRow());
                ((DefaultTableModel)workingList.getModel()).insertRow(se +1, new String[]{obj});
                workingList.getSelectionModel().setSelectionInterval(se +1, se +1);
            }
            
            updateTexture();
        }
        else if(e.getActionCommand().equals("Subtexture Selected")) updateTexture();
        else if(e.getActionCommand().equals("Delete")){
            getTexturesCombo().removeItemListener(this);

            String item = (String)getTexturesCombo().getSelectedItem(); 

            ThemeEditor.instance().getEditedTheme().texturePalette().remove(item);

            getTexturesCombo().removeAllItems();
            for(Iterator i = ThemeEditor.instance().getEditedTheme().texturePalette().keySet().iterator(); i.hasNext(); ) getTexturesCombo().addItem((String)i.next());

            getTexturesCombo().addItemListener(this);
            getTexturesCombo().setSelectedIndex(0);
        }
        else if(e.getActionCommand().equals("Add / Set")){
            getTexturesCombo().removeItemListener(this);

            String item = (String)getTexturesCombo().getSelectedItem(); 

            ThemeEditor.instance().getEditedTheme().texturePalette().put(item, currentTexture);

            getTexturesCombo().removeAllItems();
            for(Iterator i = ThemeEditor.instance().getEditedTheme().texturePalette().keySet().iterator(); i.hasNext(); ) getTexturesCombo().addItem((String)i.next());

            getTexturesCombo().addItemListener(this);
            getTexturesCombo().setSelectedItem(item);
        }
        else if(e.getActionCommand().equals("Save")) ThemeEditor.instance().getEditedTheme().saveTextures();
    }
    
    protected void updateTexture(){
        if(type.equals("none")) currentTexture = null;
        else if(type.equals("matrix")){
            currentTexture = new MatrixTexture((String[][])ThemeEditor.instance().getEditedTheme().matrixPalette().get("textures/." + getMatrixNamesCombo().getSelectedItem()));
        }
        else if(type.equals("gradient")){
            String[] colors = new String[getColorList().getModel().getRowCount()];
            for(int i = 0; i < colors.length; i++) colors[i] = (String)getColorList().getModel().getValueAt(i, 0);
            currentTexture = new GradientTexture(colors);
        }
        else if(type.equals("compound")){
            String[] textures = new String[getTextureList().getModel().getRowCount()];
            for(int i = 0; i < textures.length; i++) textures[i] = (String)getTextureList().getModel().getValueAt(i, 0);
            currentTexture = new CompoundTexture(textures);
        }
                
        if(currentTexture != null){
            currentTexture.setTheme(ThemeEditor.instance().getEditedTheme()); 
            currentTexture.setNaturalRotation(((Integer)getRotationSpinner().getValue()).intValue()/90);
        }

        getTextureDisplayer().repaint();
    }
    
    protected void selectSubEditor(String action){
        getMatrixNamesCombo().removeItemListener(this);
        getColorNames().removeItemListener(this);
            
        if(action.equals("None")){
            type = "none";

            getEditor().removeAll();
            
            getEditor().add(getNorthPanel(), "North");

            ((JComponent)getEditor().getParent()).revalidate();
            ((JComponent)getEditor().getParent()).repaint();
        }
        else if(action.equals("Matrix Based")){
            type = "matrix";
            
            getEditor().removeAll();
            
            getEditor().add(getNorthPanel(), "North");
            getEditor().add(getTextureDisplayer(), "South");
            getEditor().add(getMatrixTextureEditor(), "Center");
            getEditor().add(getSpinnerPanel(), "West");
            
            getSpinnerPanel().remove(getListButtonPanel());
           
            getMatrixNamesCombo().addItemListener(this);

            ((JComponent)getEditor().getParent()).revalidate();
            ((JComponent)getEditor().getParent()).repaint();
        }
        else if(action.equals("Gradient")){
            type = "gradient";

            getEditor().removeAll();
            
            getEditor().add(getNorthPanel(), "North");
            getEditor().add(getTextureDisplayer(), "South");
            getEditor().add(getGradientTextureEditor(), "Center");
            getEditor().add(getSpinnerPanel(), "West");
            
            getSpinnerPanel().add(getListButtonPanel());
           
            getColorNames().addItemListener(this);
            
            ((JComponent)getEditor().getParent()).revalidate();
            ((JComponent)getEditor().getParent()).repaint();

            workingList = getColorList();
        }
        else if(action.equals("Compound")) {
            type = "compound";

            JComboBox combo = (JComboBox)((DefaultCellEditor)(getTextureList().getColumnModel().getColumn(0)).getCellEditor()).getComponent();
            combo.removeActionListener(this);
            combo.removeAllItems();
            
            for(Iterator i = ThemeEditor.instance().getEditedTheme().texturePalette().keySet().iterator(); i.hasNext(); ) combo.addItem((String)i.next());

            getEditor().removeAll();
            
            getEditor().add(getNorthPanel(), "North");
            getEditor().add(getTextureDisplayer(), "South");
            getEditor().add(getCompoundTextureEditor(), "Center");
            getEditor().add(getSpinnerPanel(), "West");
            
            getSpinnerPanel().add(getListButtonPanel());
           
            ((JComponent)getEditor().getParent()).revalidate();
            ((JComponent)getEditor().getParent()).repaint();

            workingList = getTextureList();
            combo.addActionListener(this);
        }

        updateTexture();
    }
    
    public void stateChanged(ChangeEvent e){
        updateTexture();
    }

    public void itemStateChanged(ItemEvent e){
        if(e.getSource() == getMatrixNamesCombo()){
            updateTexture();
        }
        else if(e.getStateChange() == ItemEvent.SELECTED && e.getSource() == getTexturesCombo()){
            
            Texture texture = (Texture)ThemeEditor.instance().getEditedTheme().texturePalette().get(getTexturesCombo().getSelectedItem());

            if(texture != null) {
                texture.setTheme(ThemeEditor.instance().getEditedTheme());
                getRotationSpinner().removeChangeListener(this);
                getRotationSpinner().setValue(new Integer(texture.getNaturalRotation()*90));
                getRotationSpinner().addChangeListener(this);
            }

            if(texture == null){
                selectSubEditor("None");
                radios[0].setSelected(true);
            }
            else if(texture instanceof MatrixTexture){
                selectSubEditor("Matrix Based");
                radios[1].setSelected(true);
            }
            else if(texture instanceof GradientTexture){
                while(getColorList().getRowCount() > 0) ((DefaultTableModel)getColorList().getModel()).removeRow(0);

                for(int i = 0; i < ((GradientTexture)texture).getColors().length; i++){
                    ((DefaultTableModel)getColorList().getModel()).addRow(new String[]{((GradientTexture)texture).getColors()[i]});
                }

                selectSubEditor("Gradient");
                radios[2].setSelected(true);
            }
            else if(texture instanceof CompoundTexture){
                while(getTextureList().getRowCount() > 0) ((DefaultTableModel)getTextureList().getModel()).removeRow(0);

                for(int i = 0; i < ((CompoundTexture)texture).getComponents().length; i++){
                    ((DefaultTableModel)getTextureList().getModel()).addRow(new String[]{((CompoundTexture)texture).getComponents()[i]});
                }

                selectSubEditor("Compound");
                radios[3].setSelected(true);
            }
            
            currentTexture = texture;
        }
        else if(e.getStateChange() == ItemEvent.SELECTED && workingList.getEditingRow() != -1){
            ((DefaultTableModel)workingList.getModel()).setValueAt(e.getItem(), workingList.getEditingRow(), 0);
            updateTexture();
        }
    }

}
