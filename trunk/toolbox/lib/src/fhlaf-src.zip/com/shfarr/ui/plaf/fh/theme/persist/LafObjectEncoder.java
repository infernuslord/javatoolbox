/*
 * Created on Sep 2, 2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package com.shfarr.ui.plaf.fh.theme.persist;

import java.awt.Color;
import java.awt.Font;

import sun.misc.BASE64Encoder;

import com.shfarr.beans.ObjectEncoder;

/**
 * @author Administrator
 */
public class LafObjectEncoder implements ObjectEncoder{
    public String toString(Object o){
        if(o instanceof Number || o instanceof Character || o instanceof String || o instanceof Boolean) return o.toString();   
        else if(o instanceof byte[]) return "\r\n" + new BASE64Encoder().encode((byte[])o);
        else if(o instanceof Color) return "" + ((Color)o).getRed() + ", " + ((Color)o).getGreen() + ", " + ((Color)o).getBlue() + ", " + ((Color)o).getAlpha(); 
        else if(o instanceof Font){
            Font font = (Font)o;
            String style = (font.isBold() ? "bold" : "") + (font.isItalic() ? "italic" : "");
            return font.getFontName() + ", " + (style.equals("") ? "plain" : style) + ", " + font.getSize();
        }
        
        return null;
    }
}
