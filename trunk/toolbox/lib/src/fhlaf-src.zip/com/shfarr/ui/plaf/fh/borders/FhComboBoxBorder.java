/*
 * Created on Nov 11, 2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package com.shfarr.ui.plaf.fh.borders;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;

import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.border.AbstractBorder;
import javax.swing.border.Border;
import javax.swing.plaf.UIResource;

/**
 * @author shfarr
 */
public class FhComboBoxBorder extends AbstractBorder implements UIResource{
    private Border border = null;
    
    public FhComboBoxBorder(Border border){
        this.border = border;
    }

    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height){
        if(!(c.getParent() instanceof JTable || c.getParent() instanceof JList || c.getParent() instanceof JTree)){
            border.paintBorder(c, g, x, y, width, height);
        }
    }

    public Insets getBorderInsets(Component c){
        if(!(c.getParent() instanceof JTable || c.getParent() instanceof JList || c.getParent() instanceof JTree)){
            return border.getBorderInsets(c);
        }
        else return new Insets(0, 0, 0, 0);
    }

    public Insets getBorderInsets(Component c, Insets insets){
        Insets ins = getBorderInsets(c);
      
        insets.top = ins.top;
        insets.left = ins.left;
        insets.bottom = ins.bottom;
        insets.right = ins.right;
    
        return insets;
    }
}
