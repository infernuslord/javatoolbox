/*
 * $Id: ASCIIHexFilter.java,v 1.2.2.1 2002/05/31 00:17:16 chrisg Exp $
 * Copyright (C) 2001 The Apache Software Foundation. All rights reserved.
 * For details on use and redistribution please refer to the
 * LICENSE file included with these sources.
 */
package org.apache.fop.pdf;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

public class ASCIIHexFilter extends PDFFilter {
    private static final String ASCIIHEX_EOD = ">";


    public String getName() {
        return "/ASCIIHexDecode";
    }

    public String getDecodeParms() {
        return null;
    }

    public byte[] encode(byte[] data) {

        StringBuffer buffer = new StringBuffer();
        for (int i = 0; i < data.length; i++) {
            int val = (int)(data[i] & 0xFF);
            if (val < 16)
                buffer.append("0");
            buffer.append(Integer.toHexString(val));
        }
        buffer.append(ASCIIHEX_EOD);

        try {
            return buffer.toString().getBytes(PDFDocument.ENCODING);
        } catch (UnsupportedEncodingException ue) {
            return buffer.toString().getBytes();
        }       
    }

}
