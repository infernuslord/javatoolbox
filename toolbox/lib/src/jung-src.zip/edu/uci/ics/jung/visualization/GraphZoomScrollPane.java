/*
 * Copyright (c) 2003, the JUNG Project and the Regents of the University of
 * California All rights reserved.
 * 
 * This software is open-source under the BSD license; see either "license.txt"
 * or http://jung.sourceforge.net/license.txt for a description.
 * Created on Feb 2, 2005
 *
 */
package edu.uci.ics.jung.visualization;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;

import javax.swing.BoundedRangeModel;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;



/**
 * GraphZoomScrollPane is a Container for the Graph's VisualizationViewer
 * and includes custom horizontal and vertical scrollbars.
 * GraphZoomScrollPane listens for changes in the scale and
 * translation of the VisualizationViewer, and will update the
 * scrollbar positions and sizes accordingly. Changes in the
 * scrollbar positions will cause the corresponding change in
 * the translation component (offset) of the VisualizationViewer.
 * The scrollbars are modified so that they will allow panning
 * of the graph when the scale has been changed (e.g. zoomed-in
 * or zoomed-out).
 * 
 * The lower-right corner of this component is available to
 * use as a small button or menu.
 * 
 * samples.graph.GraphZoomScrollPaneDemo shows the use of this component.
 * 
 * @author Tom Nelson - RABA Technologies
 *
 * 
 */
public class GraphZoomScrollPane extends JPanel {
    protected VisualizationViewer vv;
    protected JScrollBar hsb;
    protected JScrollBar vsb;
    protected JComponent corner;
    protected boolean scrollBarsMayControlAdjusting = true;
    protected JPanel south;
    
    /**
     * Create an instance of the GraphZoomScrollPane to contain the
     * VisualizationViewer
     * @param vv
     */
    public GraphZoomScrollPane(VisualizationViewer vv) {
        super(new BorderLayout());
        this.vv = vv;
        addComponentListener(new ResizeListener());        
        Dimension d = vv.getGraphLayout().getCurrentSize();
        vsb = new JScrollBar(JScrollBar.VERTICAL, 0, d.height, 0, d.height);
        hsb = new JScrollBar(JScrollBar.HORIZONTAL, 0, d.width, 0, d.width);
        vsb.addAdjustmentListener(new VerticalAdjustmentListenerImpl());
        hsb.addAdjustmentListener(new HorizontalAdjustmentListenerImpl());
        // respond to changes in the VisualizationViewer's transform
        // and set the scroll bar parameters appropriately
        vv.addChangeListener(
                new ChangeListener(){
            public void stateChanged(ChangeEvent evt) {
                VisualizationViewer vv = 
                    (VisualizationViewer)evt.getSource();
                setScrollBars(vv);
            }
        });
        add(vv);
        add(vsb, BorderLayout.EAST);
        south = new JPanel(new BorderLayout());
        south.add(hsb);
        setCorner(new JPanel());
        add(south, BorderLayout.SOUTH);
    }
    
    /**
     * listener for adjustment of the horizontal scroll bar.
     * Sets the translation of the VisualizationViewer
     */
    class HorizontalAdjustmentListenerImpl implements AdjustmentListener {
        int previous = 0;
        public void adjustmentValueChanged(AdjustmentEvent e) {
            int hval = e.getValue();
            float dh = previous - hval;
            previous = hval;
            if(dh != 0 && scrollBarsMayControlAdjusting) {
                AffineTransform at = AffineTransform.getTranslateInstance(dh,0);
                vv.getLayoutTransformer().concatenate(at);
            }
        }
    }
    
    /**
     * Listener for adjustment of the vertical scroll bar.
     * Sets the translation of the VisualizationViewer
     */
    class VerticalAdjustmentListenerImpl implements AdjustmentListener {
        int previous = 0;
        public void adjustmentValueChanged(AdjustmentEvent e) {
            JScrollBar sb = (JScrollBar)e.getSource();
            BoundedRangeModel m = sb.getModel();
            int vval = m.getValue();
            float dv = previous - vval;
            previous = vval;
             if(dv != 0 && scrollBarsMayControlAdjusting) {
                AffineTransform at = AffineTransform.getTranslateInstance(0,dv);
                vv.getLayoutTransformer().concatenate(at);
            }
        }
    }
    
    int count = 0;
    /**
     * use the supplied vv characteristics to set the position and
     * dimensions of the scroll bars. Called in response to
     * a ChangeEvent from the VisualizationViewer
     * @param xform the transform of the VisualizationViewer
     */
    private void setScrollBars(VisualizationViewer vv) {
        Dimension d = vv.getGraphLayout().getCurrentSize();
        
        // view center, translated to graph coords
        Point2D vvc = vv.inverseTransform(vv.getCenter());
        // graph center
        Point2D lc = new Point2D.Float(d.width/2, d.height/2);
        
        float layoutScale = (float) vv.getLayoutTransformer().getScale();
        float viewScale = (float) vv.getViewTransformer().getScale();
        float scale = layoutScale*viewScale;
        
        float xmax = d.width;
        float ymax = d.height;
        float xext = xmax/scale;
        float yext = ymax/scale;
        // the difference between the view center (in graph coords) and
        // the actual graph center. These values are normalized to the
        // 'zero' position for the scrollbar thumbs
        float xval = (float)((xmax-xext)/2.f + vvc.getX()-lc.getX());
        float yval = (float)((ymax-yext)/2.f + vvc.getY()-lc.getY());
        float xmin = 0;
        float ymin = 0;
        scrollBarsMayControlAdjusting = false;
        hsb.setValues((int)xval, (int)xext, (int)xmin, (int)xmax);
        vsb.setValues((int)yval, (int)yext, (int)ymin, (int)ymax);
        scrollBarsMayControlAdjusting = true;
    }

    /**
     * Listener to adjust the scroll bar parameters when the window
     * is resized
     */
	protected class ResizeListener extends ComponentAdapter {

		public void componentHidden(ComponentEvent e) {
		}

		public void componentResized(ComponentEvent e) {
		    setScrollBars(vv);
		}	
		public void componentShown(ComponentEvent e) {
		}
	}

    /**
     * @return Returns the corner component.
     */
    public JComponent getCorner() {
        return corner;
    }

    /**
     * @param corner The cornerButton to set.
     */
    public void setCorner(JComponent corner) {
        this.corner = corner;
        corner.setPreferredSize(new Dimension(vsb.getPreferredSize().width,
                hsb.getPreferredSize().height));
        south.add(this.corner, BorderLayout.EAST);
    }
}
