package tool.doc;

import java.awt.*;
import java.net.URL;
import java.net.URLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.io.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import multivalent.*;
import multivalent.std.ui.ForwardBack;
import multivalent.gui.VScrollbar;




/**
	Swing GUI to browser (subset).

	@version $Revision: 1.1 $ $Date: 2004/01/02 02:32:29 $
*/
public final class View {
  public static final String VERSION = "1.0 of $Date: 2004/01/02 02:32:29 $";
  public static final String USAGE = "java tool.doc.View [options] [<file...>]\n"
	  + "\t[-verbose]";


  private boolean fverbose_, fquiet_, fmonitor_;
  private PrintStream out_;



  public View() {
	defaults();
  }

  public void defaults() {

	fverbose_ = fquiet_ = fmonitor_ = false;
	out_ = phelps.io.PrintStreams.DEVNULL;
  }


  /**
	Creates a browser window as part of a Swing-based application,
	and uses a different hub document to do without menubar and toolbar.
   */
  public static void swing() {
	// 1. make browser JPanel
	Multivalent v = Multivalent.getInstance();
	final Browser br = v.getBrowser("name", "Basic", false);


	// 2. pack in another Swing-based application
	JFrame frame = new JFrame("my app");
	final FileDialog jfc = new java.awt.FileDialog(frame, "Open Document", FileDialog.LOAD);	// not Swing JFileChooser
	frame.setBounds(100,50, 500,350);

	Container c = frame.getContentPane();
	c.setLayout(new BorderLayout());
	c.add(br, BorderLayout.CENTER);


	// buttons
	JPanel p = new JPanel(new FlowLayout());
	JButton b = new JButton("<=");
	b.addActionListener(new SemanticSender(br, ForwardBack.MSG_BACKWARD, null));
	p.add(b);

	b = new JButton("=>");
	b.addActionListener(new SemanticSender(br, ForwardBack.MSG_FORWARD, null));
	p.add(b);


	JTextField tf = new JTextField();
	tf.setSize(200, 40);
	tf.setText("type URLs here");
	p.add(tf);

	// zoom...


	// for paginated documents
	b = new JButton("<-");
	b.addActionListener(new SemanticSender(br, multivalent.std.ui.Multipage.MSG_PREVPAGE, null));
	p.add(b);

	b = new JButton("->");
	b.addActionListener(new SemanticSender(br, multivalent.std.ui.Multipage.MSG_NEXTPAGE, null));
	p.add(b);

	// see multivalent.std.ui.Multipage for more semantic events (like MSG_GOPAGE)


	// menubar
	// ...
	b = new JButton("open");
	b.addActionListener( new ActionListener() {
	  public void actionPerformed(ActionEvent e) {
		jfc.show();
		String file = jfc.getFile();
		if (file != null) br.eventq(Document.MSG_OPEN, new File(new File(jfc.getDirectory()), file).toURI());
//System.out.println("dir / file = "+jfc.getDirectory()+" / "+jfc.getFile()); ... keeps spaces
	  }
	});
	p.add(b);

	b = new JButton("exit");
	b.addActionListener( new ActionListener() {
	  public void actionPerformed(ActionEvent e) { System.exit(0); }
	});
	p.add(b);
	c.add(p, BorderLayout.NORTH);

	frame.pack();
	frame.setVisible(true);


	// turn off internal scrollbars
	INode root = br.getRoot();
	Document doc = (Document)root.findBFS("content");
	doc.setScrollbarShowPolicy(VScrollbar.SHOW_NEVER);
	// then after loading new document, determine page dimensions from doc.bbox and set Swing scrollbars accordingly

  }


  static class SemanticSender implements ActionListener {
	Browser br_;
	String cmd_;
	Object arg_;

	SemanticSender(Browser br, String cmd, Object arg) { br_=br; cmd_=cmd; arg_=arg; }
	public void actionPerformed(ActionEvent e) { br_.eventq(cmd_, arg_); }
  }



  private int commandLine(String[] argv) {
	out_ = System.out;

	int argi = 0, argc = argv.length;
	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.equals("-label")) {}

		else if (arg.startsWith("-verb")) fverbose_ = true;
		//else if (arg.startsWith("-q"/*uiet*/)) fquiet = true;
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.startsWith("-h"/*"elp"*/)) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	return argi;
  }

  public static void main(String[] argv) {
	View v = new View();
	int argi = v.commandLine(argv);

	v.swing();

	
	// for (String arg: argv) v.eventq(MSG_OPEN, arg);
  }
}
