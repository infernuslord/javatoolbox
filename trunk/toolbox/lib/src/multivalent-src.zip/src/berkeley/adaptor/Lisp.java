package berkeley.adaptor;

import java.io.*;
import java.util.*;

import phelps.Utility;



/**
	Simple Lisp parser so can read in Lisp symbolic expressions.
	Hacked to be just sufficient for my needs, so no macros.
	Lists = nested ArrayList's.

	@version $Revision$ $Date$
*/
public class Lisp {
  static final boolean DEBUG = true;
  StreamTokenizer in;

  Lisp(InputStream is) {
	in = new StreamTokenizer(new BufferedReader(new InputStreamReader(is)));
	in.resetSyntax();
	in.parseNumbers();
	in.commentChar(';');	// single-line comment
	in.quoteChar('"');
	in.whitespaceChars(0,' ');
	in.wordChars('A','Z'); in.wordChars('a','z');
	in.wordChars('.','.'); in.wordChars('_','_');
	in.lowerCaseMode(false);	// symbols are case sensitive
  }


  /* *************************
   * FUNCTIONALITY
   **************************/

  public List<Object> parse() {
	List<Object> list = null;
	try {
	  list = parse(0);
	} catch (IOException e) {
	  Utility.error("error parsing Lisp: "+e);
	}

	return list;
  }


  public List<Object> parse(int level) throws IOException {
	List<Object> list = new ArrayList<Object>(10);

	// check for opening paren
	in.nextToken();

	if (in.ttype!='(') Utility.error("Lisp: looking for opening left parenthesis");

	// stuff list into ArrayList
	for (in.nextToken(); in.ttype!=StreamTokenizer.TT_EOF; in.nextToken()) {
	  switch (in.ttype) {
	  case '(':
		in.pushBack(); list.add(parse(level+1));
		break;
	  case ')':
		if (DEBUG) {
		  for (int i=0; i<level; i++) System.out.print(" ");
		  for (int i=0; i<list.size(); i++) {
			System.out.print(list.get(i)+" ");
		  }
		  System.out.println();
		}
		return list;

	  case '\'':	// literal symbol rather than its value
		// eat up balanced parentheses as string
		// can't just start reading characters--have to read tokens
		int pcnt=0;
		StringBuffer sb = new StringBuffer(30);
		do {
		  in.nextToken();

		  if (in.ttype=='(') pcnt++;
		  else if (in.ttype==')') pcnt--;

		  if (in.ttype==StreamTokenizer.TT_WORD) {
			sb.append(in.sval);
		  } else if (in.ttype==StreamTokenizer.TT_NUMBER) {
			sb.append(in.nval);
		  } else if ((char)in.ttype=='(') {
			sb.append('('); continue;	// no trailing space
		  } else if ((char)in.ttype==')') {
			int len = sb.length();
			if (len>0 && sb.charAt(len-1)==' ') sb.setLength(len-1);	// no leading space
			sb.append(')');
		  } else sb.append((char)in.ttype); // other character
		  sb.append(' ');
		} while (pcnt>0);

		sb.setLength(sb.length()-1);	// chop off trailing space
		list.add(sb.substring(0));
		break;

	  case '"': // quoted string -- maybe distinguish from symbol some day
		list.add(in.sval);	// can just point to String since String's immutable
		break;
	  case StreamTokenizer.TT_WORD:
		list.add(in.sval);	// can just point to String since String's immutable
		break;
	  case StreamTokenizer.TT_NUMBER:
		list.add(new Double(in.nval));
		break;

	  default:
		// regular character -- should have caught all previously
		//Utility.error("unrecognized character "+(char)in.ttype);
		assert false: (char)in.ttype;
	  }
	}

	Utility.error("missing right paren when hit EOF");
	return null;
  }



  /*
   * as application, test subsystems, as feasible
   */
  public static void main(String[] argv) {
	try {
	  InputStream in = new FileInputStream("mathbox.lisp");
	  Lisp lisp = new Lisp(in);
	  lisp.parse();
	} catch (Exception e) {
	  Utility.error(""+e);
	}
  }
}
