package phelps.doc;



/**
	NOT IMPLEMENTED.
	<a href="http://www.w3.org/XML/Linking.html">XPointer</a>.
	Experimental implementation to experiment with making XPointer robust.

	id('name')

	@version $Revision$ $Date$
*/
public class XPointer {
}
