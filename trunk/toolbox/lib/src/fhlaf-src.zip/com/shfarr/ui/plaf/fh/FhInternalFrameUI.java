/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh;

import javax.swing.plaf.basic.*;
import javax.swing.plaf.ComponentUI;
import javax.swing.JComponent;
import javax.swing.DesktopManager;
import javax.swing.JDesktopPane;

import java.awt.Component;
import java.awt.Rectangle;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;

import javax.swing.JInternalFrame;

import com.shfarr.ui.plaf.fh.ext.*;
import com.shfarr.ui.plaf.fh.theme.*;


public class FhInternalFrameUI extends BasicInternalFrameUI{
    public FhInternalFrameUI(javax.swing.JInternalFrame b){
      super(b);
    }

    protected DesktopManager createDesktopManager(){
      return new FhDesktopManager();
    }

    protected JComponent createNorthPane(JInternalFrame w){
      titlePane = new FhInternalFrameTitlePane(w);
      return titlePane;
    }

    public static ComponentUI createUI(JComponent x){
      return new FhInternalFrameUI((javax.swing.JInternalFrame)x);
    }

    public void installUI(JComponent jc){
      super.installUI(jc);
      //jc.setOpaque(false);
    }

    public void paint(java.awt.Graphics g, JComponent c){
        ThemeManager.instance().probeAntialiasing(g);
        super.paint(g, c);
    }

    protected ComponentListener createComponentListener(){
      return new FhInternalFrameComponentHandler();
    }

    protected class FhInternalFrameComponentHandler implements ComponentListener{
      public void componentResized(ComponentEvent e){
         Rectangle parentNewBounds = ((Component)e.getSource()).getBounds();
         JDesktopPane desktopPane = e.getSource() instanceof JDesktopPane ? (JDesktopPane)e.getSource() : null;
         JInternalFrame.JDesktopIcon icon = null;

         if(frame != null){
            icon = frame.getDesktopIcon();
    
            if(frame.isMaximum()){
                if(desktopPane !=null) desktopPane.getDesktopManager().setBoundsForFrame(frame, -1, -1, -1, -1);
                else frame.setBounds(0, 0, parentNewBounds.width, parentNewBounds.height);
            }
         }
        
         if (frame != null) frame.validate();
      }

      public void componentMoved(ComponentEvent e) {}
      public void componentShown(ComponentEvent e) {}
      public void componentHidden(ComponentEvent e) {}
    }
}
