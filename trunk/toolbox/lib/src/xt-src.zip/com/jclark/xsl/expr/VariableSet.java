// $Id: VariableSet.java,v 1.1 2002/04/25 18:12:39 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

public interface VariableSet {
    boolean contains(Name name);
}
