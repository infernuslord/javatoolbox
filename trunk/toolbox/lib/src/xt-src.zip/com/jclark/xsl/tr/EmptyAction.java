// $Id: EmptyAction.java,v 1.1 2002/04/25 18:17:41 bill Exp $

package com.jclark.xsl.tr;

import com.jclark.xsl.om.*;

/**
 * a no-op
 */
class EmptyAction implements Action
{
    public void invoke(ProcessContext context, Node sourceNode, 
                       Result result) { }
}
