/*
 * Created on Jan 26, 2004
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package com.shfarr.ui.plaf.fh;

import java.util.Vector;

import javax.swing.JComponent;
import javax.swing.LookAndFeel;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicRootPaneUI;

/**
 * @author shfarr
 */
public class FhRootPaneUI extends BasicRootPaneUI{
    public static final Vector registeredWindows = new Vector(); 

    public FhRootPaneUI(){
        super();
    }
    
    public static ComponentUI createUI(JComponent cmp){
        return new FhRootPaneUI();
    }

    public void installUI(JComponent c){
        super.installUI(c);
        
        LookAndFeel.installColors(c, "RootPane.background", "Panel.foreground");
        
        if(!registeredWindows.contains(c)) registeredWindows.add(c);
    }
}
