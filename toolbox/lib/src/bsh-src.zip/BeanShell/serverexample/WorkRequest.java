//file: WorkRequest.java
public abstract class WorkRequest extends Request {
    public abstract Object execute(  );
}
