/*
 * Copyright (c) 2003, the JUNG Project and the Regents of the University of
 * California All rights reserved.
 * 
 * This software is open-source under the BSD license; see either "license.txt"
 * or http://jung.sourceforge.net/license.txt for a description.
 * 
 * Created on Jul 20, 2004
 */
package edu.uci.ics.jung.visualization;

import java.awt.Polygon;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.util.Iterator;
import java.util.LinkedList;

import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.graph.decorators.ConstantVertexAspectRatioFunction;
import edu.uci.ics.jung.graph.decorators.ConstantVertexSizeFunction;
import edu.uci.ics.jung.graph.decorators.VertexAspectRatioFunction;
import edu.uci.ics.jung.graph.decorators.VertexSizeFunction;

/**
 * A utility class for generating <code>Shape</code>s for drawing vertices.  
 * The available shapes include rectangles, rounded rectangles, ellipses,
 * regular polygons, and regular stars.  The dimensions of the requested 
 * shapes are defined by the specified <code>VertexSizeFunction</code>
 * and <code>VertexAspectRatioFunction</code> implementations: the width
 * of the bounding box of the shape is given by the vertex size, and the
 * height is given by the size multiplied by the vertex's aspect ratio.
 *  
 * @author Joshua O'Madadhain
 */
public class VertexShapeFactory
{
    protected VertexSizeFunction vsf;
    protected VertexAspectRatioFunction varf;
    
    /**
     * Creates a <code>VertexShapeFactory</code> with the specified 
     * vertex size and aspect ratio functions.
     */
    public VertexShapeFactory(VertexSizeFunction vsf, VertexAspectRatioFunction varf)
    {
        this.vsf = vsf;
        this.varf = varf;
    }
    
    /**
     * Creates a <code>VertexShapeFactory</code> with a constant size of
     * 10 and a constant aspect ratio of 1.
     */
    public VertexShapeFactory()
    {
        this(new ConstantVertexSizeFunction(10), 
            new ConstantVertexAspectRatioFunction(1.0f));
    }
    
    /**
     * Returns a <code>Rectangle2D</code> whose width and 
     * height are defined by this instance's size and
     * aspect ratio functions for this vertex.
     */
    public Rectangle2D getRectangle(Vertex v)
    {
        float width = vsf.getSize(v);
        float height = width * varf.getAspectRatio(v);
        float h_offset = -(width / 2);
        float v_offset = -(height / 2);
        return new Rectangle2D.Float(h_offset, v_offset, width, height);
    }

    /**
     * Returns a <code>Ellipse2D</code> whose width and 
     * height are defined by this instance's size and
     * aspect ratio functions for this vertex.
     */
    public Ellipse2D getEllipse(Vertex v)
    {
        Ellipse2D e = new Ellipse2D.Float();
        e.setFrame(getRectangle(v));
        return e;
    }
    
    /**
     * Returns a <code>RoundRectangle2D</code> whose width and 
     * height are defined by this instance's size and
     * aspect ratio functions for this vertex.  The arc size is
     * set to be half the minimum of the height and width of the frame.
     */
    public RoundRectangle2D getRoundRectangle(Vertex v)
    {
        Rectangle2D frame = getRectangle(v);
        float arc_size = (float)Math.min(frame.getHeight(), frame.getWidth()) / 2;
        RoundRectangle2D r = new RoundRectangle2D.Float(0,0,0,0,arc_size,arc_size);
        r.setFrame(frame);
        return r;
    }
    
    /**
     * Returns a regular <code>num_sides</code>-sided 
     * <code>Polygon</code> whose bounding 
     * box's width and height are defined by this instance's size and
     * aspect ratio functions for this vertex.
     * @param num_sides the number of sides of the polygon; must be >= 3.
     */
    public Polygon getRegularPolygon(Vertex v, int num_sides)
    {
        if (num_sides < 3)
            throw new IllegalArgumentException("Number of sides must be >= 3");
        Rectangle2D frame = getRectangle(v);
        double width = frame.getWidth();
        double height = frame.getHeight();
        
        // generate coordinates
        double angle = 0;
        LinkedList l = new LinkedList();
        l.add(new Coordinates(0,0));
        l.add(new Coordinates(width, 0));
        double theta = (2 * Math.PI) / num_sides; 
        for (int i = 2; i < num_sides; i++)
        {
            angle -= theta; 
            double delta_x = width * Math.cos(angle);
            double delta_y = width * Math.sin(angle);
            Coordinates prev = (Coordinates)l.getLast();
            l.add(new Coordinates(prev.getX() + delta_x, prev.getY() + delta_y));
        }
        
        // create polygon
        Polygon p = new Polygon();
        for (Iterator iter = l.iterator(); iter.hasNext(); )
        {
            Coordinates c = (Coordinates)iter.next();
            p.addPoint((int)c.getX(), (int)c.getY());
        }
        
        // scale polygon to be right size, translate to center at (0,0)
        Rectangle2D r = p.getBounds2D();
        double scale_x = width / r.getWidth();
        double scale_y = height / r.getHeight();
        for (int i = 0; i < p.npoints; i++)
        {
            p.xpoints[i] = (int)(p.xpoints[i] * scale_x - scale_x*width/2);
            p.ypoints[i] = (int)(p.ypoints[i] * scale_y + height/2);
        }
        p.invalidate();
        return p;
    }
    
    /**
     * Returns a regular <code>Polygon</code> of <code>num_points</code>
     * points whose bounding 
     * box's width and height are defined by this instance's size and
     * aspect ratio functions for this vertex.
     * @param num_points the number of points of the polygon; must be >= 5.
     */
    public Polygon getRegularStar(Vertex v, int num_points)
    {
        if (num_points < 5)
            throw new IllegalArgumentException("Number of sides must be >= 5");
        Rectangle2D frame = getRectangle(v);
        double width = frame.getWidth();
        double height = frame.getHeight();
        
        // generate coordinates
        double theta = (2 * Math.PI) / num_points;
        double angle = -theta/2;
        LinkedList l = new LinkedList();
        l.add(new Coordinates(0,0));
        double delta_x = width * Math.cos(angle);
        double delta_y = width * Math.sin(angle);
        Coordinates prev = (Coordinates)l.getLast();
        l.add(new Coordinates(prev.getX() + delta_x, prev.getY() + delta_y));
        
        for (int i = 1; i < num_points; i++)
        {
            angle += theta; 
            delta_x = width * Math.cos(angle);
            delta_y = width * Math.sin(angle);
            prev = (Coordinates)l.getLast();
            l.add(new Coordinates(prev.getX() + delta_x, prev.getY() + delta_y));
            angle -= theta*2; 
            delta_x = width * Math.cos(angle);
            delta_y = width * Math.sin(angle);
            prev = (Coordinates)l.getLast();
            l.add(new Coordinates(prev.getX() + delta_x, prev.getY() + delta_y));
        }
        
        // create polygon
        Polygon p = new Polygon();
        for (Iterator iter = l.iterator(); iter.hasNext(); )
        {
            Coordinates c = (Coordinates)iter.next();
            p.addPoint((int)c.getX(), (int)c.getY());
        }
        
        // scale polygon to be right size, translate to center at (0,0)
        Rectangle2D r = p.getBounds2D();
        double scale_x = width / r.getWidth();
        double scale_y = height / r.getHeight();
        for (int i = 0; i < p.npoints; i++)
        {
            p.xpoints[i] = (int)(p.xpoints[i] * scale_x - scale_x*width);
            p.ypoints[i] = (int)(p.ypoints[i] * scale_y + height/2);
        }
        p.invalidate();
        return p;
    }
}
