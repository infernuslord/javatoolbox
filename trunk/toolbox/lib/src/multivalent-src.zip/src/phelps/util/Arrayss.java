package phelps.util;

import java.util.Arrays;	// for Javadoc references



/**
	Extensions to {@link java.util.Arrays}.
	@version $Revision: 1.1 $ $Date: 2003/08/26 19:47:06 $
*/
public class Arrayss {
  /**
	Finds first index of <var>key<var> in <var>a</var> or -1 if not present.
	If array is sorted, use {@link Arrays#binarySearch(byte[], byte)} instead.
  */
  public static int search(byte[] a, byte key) {
	if (a==null) return -1;
	for (int i=0,imax=a.length; i<imax; i++) if (key == a[i]) return i;
	return -1;
  }

  /**
	Finds first index of <var>key<var> in <var>a</var> or -1 if not present.
  */
  public static int search(byte[] a, byte[] key) {
	if (a==null || key==null || a.length < key.length) return -1;
	byte key0 = key[0];
	for (int i=0,imax=a.length - key.length; i<imax; i++) {
		if (key0 == a[i]) {
			boolean fmatch = true;
			for (int j=0+1,jmax=key.length; j<jmax; j++) if (key[j] != a[i+j]) { fmatch=false; break; }
			if (fmatch) return i;
		}
	}
	return -1;
  }

  public static int[] fillIdentity(int[] a) {
	for (int i=0,imax=a.length; i<imax; i++) a[i] = i;
	return a;
  }

  public static char[] fillIdentity(char[] a) {
	for (int i=0,imax=a.length; i<imax; i++) a[i] = (char)i;
	return a;
  }

  public static byte[] fillIdentity(byte[] a) {
	for (int i=0,imax=a.length; i<imax; i++) a[i] = (byte)i;
	return a;
  }
}
