<?php require("header.inc"); ?>
<h1>License</h1> 
<p><i>JODE</i> is Copyright &copy; 1998-2000 by Jochen Hoenicke. <br><br>

<p>This program is free software; you can redistribute it and/or modify
it under the terms of the <a
href="http://www.gnu.org/copyleft/gpl.html">GNU General Public
License</a> as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.</p>

<p>You can redistribute some of the packages under the
terms of the of the <a 
href="http://www.gnu.org/copyleft/lesser.html">GNU Lesser General
Public License</a> as published by the Free Software Foundation. See
the copyright headers in the source code.</p>

<p>This program is distributed in the hope that it will be useful,
but <b>without any warranty</b>; without even the implied warranty of
<b>merchantability</b> or <b>fitness for a particular purpose</b>.  See the
GNU General Public License for more details.</p>

<?php require("footer.inc"); ?>
