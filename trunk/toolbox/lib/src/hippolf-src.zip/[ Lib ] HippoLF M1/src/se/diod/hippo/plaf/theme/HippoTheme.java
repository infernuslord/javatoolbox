/*
 * 
 * Created on 2004-jun-29
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.theme;

import java.awt.Color;

import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.metal.DefaultMetalTheme;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jun-29
 *
 */
public class HippoTheme extends DefaultMetalTheme {
	
	
	// Button
	private static final Color 		myButtonBackground							= new Color( 198, 209, 223 );
	private static final Color 		myButtonSelect								= new Color( 200, 200, 200 );
	private static final Color 		myButtonRolloverBackground					= new Color( 198, 209, 223 );

	// CheckBox
	private static final Color 		myCheckBoxBackground						= new Color( 214, 210, 191 );

	// CheckBoxMenuItem
	private static final Color 		myCheckBoxMenuItemBorderColor				= new Color( 155, 155, 155 );
	private static final Color 		myCheckBoxMenuItemBackground				= new Color( 245, 245, 245 );

	// Combobox
	private static final Color 		myComboBoxBackground						= new Color( 245, 245, 245 );
	private static final Color 		myComboBoxSelectionBackground				= new Color( 214, 210, 191 );

	// Desktop
	private static final Color 		myDesktopBackground							= new Color( 214, 210, 191 );

	// EditorPane
	private static final Color 		myEditorPaneBackground						= new Color( 245, 245, 245 );
	private static final Color 		myEditorPaneSelectionBackground				= new Color( 214, 210, 191 );

	// InternalFrame
	private static final Color 		myInternalFrameBorderColor					= new Color(  75,  75,  75 );
	private static final Color 		myInternalFrameInactiveTitleBackground		= new Color( 198, 218, 238 );
	private static final Color 		myInternalFrameBackground					= new Color( 245, 245, 245 );
	private static final Color 		myInternalFrameActiveTitleBackground		= new Color( 184, 180, 161 );
	private static final Color 		myInternalFrameActiveTitleBackground2		= new Color( 214, 210, 191 );

	// List
	private static final Color 		myListBackground							= new Color( 245, 245, 245 );
	private static final Color 		myListSelectionBackground					= new Color( 214, 210, 191 );
	
	// Menu
	private static final Color 		myMenuBackground							= new Color( 245, 245, 245 );
	private static final Color 		myMenuSelectionBackground					= new Color( 198, 209, 223 );
	private static final Color 		myMenuIconBackground						= new Color( 214, 210, 191 );
	private static final Color 		myMenuBorderColor							= new Color( 155, 155, 155 );

	// MenuBar
	private static final Color 		myMenuBarBorderColor						= new Color( 155, 155, 155 );

	// OptionPane
	private static final Color 		myOptionPaneBackground						= new Color( 214, 210, 191 );

	// Panel
	private static final Color 		myPanelBackground							= new Color( 214, 210, 191 );

	// PopupMenu
	private static final Color 		myPopupMenuBackground						= new Color( 245, 245, 245 );

	// ProgressBar
	private static final Color 		myProgressBarBackground						= new Color( 245, 245, 245 );
	private static final Color 		myProgressBarForeground						= new Color( 214, 210, 191 );
	private static final Color 		myProgressBarBorderColor					= new Color( 155, 155, 155 );

	// RadioButton
	private static final Color 		myRadioButtonBackground						= new Color( 214, 210, 191 );

	// RadioButtonMenuItem
	private static final Color 		myRadioButtonMenuItemBackground				= new Color( 245, 245, 245 );
	private static final Color 		myRadioButtonMenuItemBorderColor			= new Color( 155, 155, 155 );
	
	// ScrollBar
	private static final Color 		myScrollBarBackground						= new Color( 245, 245, 245 );
	private static final Color 		myScrollBarThumbBackground					= new Color( 214, 210, 191 );
	private static final Color 		myScrollBarThumbBorderColor					= new Color( 155, 155, 155 );

	// ScrollPane
	private static final Color 		myScrollPaneBackground						= new Color( 245, 245, 245 );

	// Separator
	private static final Color 		mySeparatorBackground						= new Color( 155, 155, 155 );

	// Slider
	private static final Color 		mySliderBackground							= new Color( 214, 210, 191 );

	// SplitPane
	private static final Color 		mySplitPaneBackground						= new Color( 214, 210, 191 );
	private static final Color 		mySplitPaneHighlight						= new Color( 214, 210, 191 );
	private static final Color 		mySplitPaneShadow							= new Color( 214, 210, 191 );
	private static final Color 		mySplitPaneDarkShadow						= new Color( 214, 210, 191 );

	// TabbedPane
	private static final Color 		myTabbedPaneBackground						= new Color( 214, 210, 191 );
	private static final Color 		myTabbedPaneAreaBackground					= new Color( 245, 245, 245 );

	// Table
	private static final Color 		myTableBackground							= new Color( 245, 245, 245 );
	private static final Color 		myTableGridColor							= new Color( 214, 210, 191 );
	private static final Color 		myTableFocusCellBackground					= new Color( 245, 245, 245 );
	private static final Color 		myTableSelectionBackground					= new Color( 214, 210, 191 );

	// TableHeader
	private static final Color 		myTableHeaderBackground						= new Color( 184, 180, 161 );
	private static final Color 		myTableHeaderGridColor						= new Color( 144, 140, 121 );

	// TextArea
	private static final Color 		myTextAreaBackground						= new Color( 245, 245, 245 );
	private static final Color 		myTextAreaSelectionBackground				= new Color( 214, 210, 191 );

	// TextField
	private static final Color 		myTextFieldBackground						= new Color( 245, 245, 245 );
	private static final Color 		myTextFieldInactiveBackground				= new Color( 214, 210, 191 );
	private static final Color 		myTextFieldSelectionBackground				= new Color( 214, 210, 191 );

	// TextPane
	private static final Color 		myTextPaneBackground						= new Color( 245, 245, 245 );
	private static final Color 		myTextPaneSelectionBackground				= new Color( 214, 210, 191 );
	
	// ToggleButton
	private static final Color 		myToggleButtonBackground					= new Color( 198, 209, 223 );
	private static final Color 		myToggleButtonSelect						= new Color( 200, 200, 200 );

	// ToolBar
	private static final Color 		myToolBarBackground							= new Color( 214, 210, 191 );
	private static final Color 		myToolBarDragIconColor						= new Color( 155, 155, 155 );

	// ToolTip
	private static final Color 		myToolTipBackground							= new Color( 234, 230, 211 );

	// Tree
	private static final Color 		myTreeBackground							= new Color( 245, 245, 245 );
	private static final Color 		myTreeTextBackground						= new Color( 245, 245, 245 );
	private static final Color 		myTreeSelectionBackground					= new Color( 214, 210, 191 );
	private static final Color 		myTreeHash									= new Color( 214, 210, 191 );

	

	/**
	 * 
	 * Button Background
	 * 
	 */
	public ColorUIResource getButtonBackground() {
		return new ColorUIResource( myButtonBackground );
	}


	
	
	/**
	 * 
	 * Button Select
	 *  
	 */
	public ColorUIResource getButtonSelect() {
		return new ColorUIResource( myButtonSelect );
	}


	
	
	/**
	 * 
	 * ButtonRollover Background
	 * 
	 */
	public ColorUIResource getButtonRolloverBackground() {
		return new ColorUIResource( myButtonRolloverBackground );
	}

	
	
	
	/**
	 * 
	 * CheckBox Background
	 * 
	 */
	public ColorUIResource getCheckBoxBackground() {
		return new ColorUIResource( myCheckBoxBackground );
	}

	
	
	
	/**
	 * 
	 * CheckBoxMenuItemBorder Color
	 * 
	 */
	public ColorUIResource getCheckBoxMenuItemBorderColor() {
		return new ColorUIResource( myCheckBoxMenuItemBorderColor );
	}


	
	
	/**
	 * 
	 * CheckBoxMenuItem Background
	 * 
	 */
	public ColorUIResource getCheckBoxMenuItemBackground() {
		return new ColorUIResource( myCheckBoxMenuItemBackground );
	}


	
	
	/**
	 * 
	 * ComboBox Background
	 * 
	 */
	public ColorUIResource getComboBoxBackground() {
		return new ColorUIResource( myComboBoxBackground );
	}

	
	
	
	/**
	 * 
	 * ComboBoxSelection Background
	 * 
	 */
	public ColorUIResource getComboBoxSelectionBackground() {
		return new ColorUIResource( myComboBoxSelectionBackground );
	}

	
	
	
	/**
	 * 
	 * Desktop Background
	 * 
	 */
	public ColorUIResource getDesktopBackground() {
		return new ColorUIResource( myDesktopBackground );
	}

	
	
	
	/**
	 * 
	 * EditorPane Background
	 * 
	 */
	public ColorUIResource getEditorPaneBackground() {
		return new ColorUIResource( myEditorPaneBackground );
	}


	
	
	/**
	 * 
	 * EditorPaneSelection Background
	 * 
	 */
	public ColorUIResource getEditorPaneSelectionBackground() {
		return new ColorUIResource( myEditorPaneSelectionBackground );
	}

	
	
	
	/**
	 * 
	 * InternalFrameBorder Color
	 * 
	 */
	public ColorUIResource getInternalFrameBorderColor() {
		return new ColorUIResource( myInternalFrameBorderColor );
	}


	
	
	/**
	 * 
	 * InternalFrameActiveTitle Background
	 * 
	 */
	public ColorUIResource getInternalFrameActiveTitleBackground() {
		return new ColorUIResource( myInternalFrameActiveTitleBackground );
	}


	
	
	/**
	 * 
	 * InternalFrameActiveTitle Background2
	 * 
	 */
	public ColorUIResource getInternalFrameActiveTitleBackground2() {
		return new ColorUIResource( myInternalFrameActiveTitleBackground2 );
	}


	
	
	/**
	 * 
	 * InternalFrameInactiveTitle Background
	 * 
	 */
	public ColorUIResource getInternalFrameInactiveTitleBackground() {
		return new ColorUIResource( myInternalFrameInactiveTitleBackground );
	}

	
	
	
	/**
	 * 
	 * InternalFrame Background
	 * 
	 */
	public ColorUIResource getInternalFrameBackground() {
		return new ColorUIResource( myInternalFrameBackground );
	}

	
	
	
	/**
	 * 
	 * List Background
	 * 
	 */
	public ColorUIResource getListBackground() {
		return new ColorUIResource( myListBackground );
	}

	
	
	
	/**
	 * 
	 * ListSelection Background
	 * 
	 */
	public ColorUIResource getListSelectionBackground() {
		return new ColorUIResource( myListSelectionBackground );
	}

	
	
	
	/**
	 * 
	 * Menu Background
	 * 
	 */
	public ColorUIResource getMenuBackground() {
		return new ColorUIResource( myMenuBackground );
	}

	
	
	
	/**
	 * 
	 * MenuSelection Background
	 * 
	 */
	public ColorUIResource getMenuSelectionBackground() {
		return new ColorUIResource( myMenuSelectionBackground );
	}


	
	
	/**
	 * 
	 * MenuIcon Background
	 * 
	 */
	public ColorUIResource getMenuIconBackground() {
		return new ColorUIResource( myMenuIconBackground );
	}


	
	
	/**
	 * 
	 * MenuBorder Color
s	 * 
	 */
	public ColorUIResource getMenuBorderColor() {
		return new ColorUIResource( myMenuBorderColor );
	}


	
	
	/**
	 * 
	 * MenubarBorder Color
	 * 
	 */
	public ColorUIResource getMenuBarBorderColor() {
		return new ColorUIResource( myMenuBarBorderColor );
	}

	
	
	
	/**
	 * 
	 * OptionPane Background
	 * 
	 */
	public ColorUIResource getOptionPaneBackground() {
		return new ColorUIResource( myOptionPaneBackground );
	}

	
	
	
	/**
	 * 
	 * Panel Background
	 * 
	 */
	public ColorUIResource getPanelBackground() {
		return new ColorUIResource( myPanelBackground );
	}

	
	
	
	/**
	 * 
	 * PopupMenu Background
	 * 
	 */
	public ColorUIResource getPopupMenuBackground() {
		return new ColorUIResource( myPopupMenuBackground );
	}
	
	
	
	
	/**
	 * 
	 * ProgressBar Background
	 * 
	 */
	public ColorUIResource getProgressBarBackground() {
		return new ColorUIResource( myProgressBarBackground );
	}


	
	
	/**
	 * 
	 * ProgressBar Foreground
	 * 
	 */
	public ColorUIResource getProgressBarForeground() {
		return new ColorUIResource( myProgressBarForeground );
	}

	
	
	
	/**
	 * 
	 * ProgressBarBorder Color
	 * 
	 */
	public ColorUIResource getProgressBarBorderColor() {
		return new ColorUIResource( myProgressBarBorderColor );
	}

	
	
	
	/**
	 * 
	 * RadioButton Background
	 * 
	 */
	public ColorUIResource getRadioButtonBackground() {
		return new ColorUIResource( myRadioButtonBackground );
	}

	
	
	
	/**
	 * 
	 * RadioButtonMenuItem Background
	 * 
	 */
	public ColorUIResource getRadioButtonMenuItemBackground() {
		return new ColorUIResource( myRadioButtonMenuItemBackground );
	}


	
	
	/**
	 * 
	 * RadioButtonMenuItemBorder Color
	 * 
	 */
	public ColorUIResource getRadioButtonMenuItemBorderColor() {
		return new ColorUIResource( myRadioButtonMenuItemBorderColor );
	}


	
	
	/**
	 * 
	 * ScrollBar Background
	 * 
	 */
	public ColorUIResource getScrollBarBackground() {
		return new ColorUIResource( myScrollBarBackground );
	}


	
	
	/**
	 * 
	 * ScrollBarThumbBackground
	 * 
	 */
	public ColorUIResource getScrollBarThumbBackground() {
		return new ColorUIResource( myScrollBarThumbBackground );
	}


	
	
	/**
	 * 
	 * ScrollBarThumbBorder Color
	 * 
	 */
	public ColorUIResource getScrollBarThumbBorderColor() {
		return new ColorUIResource( myScrollBarThumbBorderColor );
	}

	
	
	
	/**
	 * 
	 * ScrollPane Background
	 * 
	 */
	public ColorUIResource getScrollPaneBackground() {
		return new ColorUIResource( myScrollPaneBackground );
	}

	
	
	
	/**
	 * 
	 * Slider
	 * 
	 */
	public ColorUIResource getSliderBackground() {
		return new ColorUIResource( mySliderBackground );
	}

	
	
	
	/**
	 * 
	 * SplitPane Background
	 * 
	 */
	public ColorUIResource getSplitPaneBackground() {
		return new ColorUIResource( mySplitPaneBackground );
	}


	
	
	/**
	 * 
	 * SplitPane Highlight
	 * 
	 */
	public ColorUIResource getSplitPaneHighlight() {
		return new ColorUIResource( mySplitPaneHighlight );
	}


	
	
	/**
	 * 
	 * SplitPane Shadow
	 * 
	 */
	public ColorUIResource getSplitPaneShadow() {
		return new ColorUIResource( mySplitPaneShadow );
	}




	/**
	 * 
	 * SplitPaneDark Shadow
	 * 
	 */
	public ColorUIResource getSplitPaneDarkShadow() {
		return new ColorUIResource( mySplitPaneDarkShadow );
	}

	
	
	
	/**
	 * 
	 * TabbedPane Background
	 * 
	 */
	public ColorUIResource getTabbedPaneBackground() {
		return new ColorUIResource( myTabbedPaneBackground );
	}

	
	
	
	/**
	 * 
	 * TabbedPaneArea Background
	 * 
	 */
	public ColorUIResource getTabbedPaneAreaBackground() {
		return new ColorUIResource( myTabbedPaneAreaBackground );
	}

	
	
	
	/**
	 * 
	 * Table Background
	 * 
	 */
	public ColorUIResource getTableBackground() {
		return new ColorUIResource( myTableBackground );
	}


	
	
	/**
	 * 
	 * TableGrid Color
	 * 
	 */
	public ColorUIResource getTableGridColor() {
		return new ColorUIResource( myTableGridColor );
	}


	
	
	/**
	 * 
	 * TableFocusCell Background
	 * 
	 */
	public ColorUIResource getTableFocusCellBackground() {
		return new ColorUIResource( myTableFocusCellBackground );
	}


	
	
	/**
	 * 
	 * TableSelection Background
	 * 
	 */
	public ColorUIResource getTableSelectionBackground() {
		return new ColorUIResource( myTableSelectionBackground );
	}

	
	
	
	/**
	 * 
	 * TableHeader Background
	 * 
	 */
	public ColorUIResource getTableHeaderBackground() {
		return new ColorUIResource( myTableHeaderBackground );
	}

	
	
	
	/**
	 * 
	 * TableHeader Background
	 * 
	 */
	public ColorUIResource getTableHeaderGridColor() {
		return new ColorUIResource( myTableHeaderGridColor );
	}

	
	
	
	/**
	 * 
	 * TextArea Background
	 * 
	 */
	public ColorUIResource getTextAreaBackground() {
		return new ColorUIResource( myTextAreaBackground );
	}


	
	
	/**
	 * 
	 * TextAreaSelection Background
	 * 
	 */
	public ColorUIResource getTextAreaSelectionBackground() {
		return new ColorUIResource( myTextAreaSelectionBackground );
	}


	
	
	/**
	 * 
	 * TextField Background
	 * 
	 */
	public ColorUIResource getTextFieldBackground() {
		return new ColorUIResource( myTextFieldBackground );
	}


	
	
	/**
	 * 
	 * TextFieldInactive Background
	 * 
	 */
	public ColorUIResource getTextFieldInactiveBackground() {
		return new ColorUIResource( myTextFieldInactiveBackground );
	}


	
	
	/**
	 * 
	 * TextFieldSelection Background
	 * 
	 */
	public ColorUIResource getTextFieldSelectionBackground() {
		return new ColorUIResource( myTextFieldSelectionBackground );
	}


	
	
	/**
	 * 
	 * TextPane Background
	 * 
	 */
	public ColorUIResource getTextPaneBackground() {
		return new ColorUIResource( myTextPaneBackground );
	}

	
	
	
	/**
	 * 
	 * TextPaneSelection Background
	 * 
	 */
	public ColorUIResource getTextPaneSelectionBackground() {
		return new ColorUIResource( myTextPaneSelectionBackground );
	}

	
	
	
	/**
	 * 
	 * ToggleButton Background
	 * 
	 */
	public ColorUIResource getToggleButtonBackground() {
		return new ColorUIResource( myToggleButtonBackground );
	}

	
	
	
	/**
	 * 
	 * ToggleButton Select
	 * 
	 */
	public ColorUIResource getToggleButtonSelect() {
		return new ColorUIResource( myToggleButtonSelect );
	}

	
	
	
	/**
	 * 
	 * ToolBarDragIcon Color
	 * 
	 */
	public ColorUIResource getToolBarDragIconColor() {
		return new ColorUIResource( myToolBarDragIconColor );
	}


	
	
	/**
	 * 
	 * ToolBar Background
	 * 
	 */
	public ColorUIResource getToolBarBackground() {
		return new ColorUIResource( myToolBarBackground );
	}




	/**
	 * 
	 * ToolTip Background
	 * 
	 */
	public ColorUIResource getToolTipBackground() {
		return new ColorUIResource( myToolTipBackground );
	}

	
	
	
	/**
	 * 
	 * Tree Background
	 * 
	 */
	public ColorUIResource getTreeBackground() {
		return new ColorUIResource( myTreeBackground );
	}


	
	
	/**
	 * 
	 * TreeText Background
	 * 
	 */
	public ColorUIResource getTreeTextBackground() {
		return new ColorUIResource( myTreeTextBackground );
	}


	
	
	/**
	 * 
	 * TreeSelection Background
	 * 
	 */
	public ColorUIResource getTreeSelectionBackground() {
		return new ColorUIResource( myTreeSelectionBackground );
	}


	
	
	/**
	 * 
	 * TreeHash
	 * 
	 */
	public ColorUIResource getTreeHash() {
		return new ColorUIResource( myTreeHash );
	}
}
