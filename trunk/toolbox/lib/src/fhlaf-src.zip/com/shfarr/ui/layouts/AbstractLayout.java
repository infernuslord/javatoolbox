/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.layouts;

import java.awt.*;
import java.util.Vector;


public abstract class AbstractLayout implements LayoutManager2{
    protected Vector ccs = new Vector();


    public AbstractLayout() {
      super();
    }


    public void addLayoutComponent(Component comp, Object constraints){
        ccs.add(new ConstraintsComponentPair(comp, constraints, comp.getName()));
    }


    public void addLayoutComponent(String name, Component comp){
        ccs.add(new ConstraintsComponentPair(comp, getDefaultConstraints(), name));
    }


    protected Object getConstraintsFor(Component c){
      Object theCts = null;
      for(int i=0; i<ccs.size(); i++){
    	  if(((ConstraintsComponentPair)ccs.elementAt(i)).component == c){
    		 theCts = ((ConstraintsComponentPair)ccs.elementAt(i)).constraints;
    		 break;
    	  }
      }
    
      if(theCts == null) theCts = getDefaultConstraints();
    
      return theCts;
    }


    protected abstract Object getDefaultConstraints();


    public float getLayoutAlignmentX(Container target){
      return -1.0f;
    }


    public float getLayoutAlignmentY(Container target){
      return -1.0f;
    }


    public void invalidateLayout(Container target){
    }


    public void layoutContainer(Container parent){
      synchronized(parent.getTreeLock()){
    			   performLayout(parent);
      }
    }


    public Dimension maximumLayoutSize(Container target){
      return new Dimension(0, 0);
    }


    public Dimension minimumLayoutSize(Container parent){
      return new Dimension(0, 0);
    }


    protected abstract void performLayout(Container c);


    public void removeLayoutComponent(Component comp){
      for(int i=0; i<ccs.size(); i++) if(((ConstraintsComponentPair)ccs.elementAt(i)).component==comp) ccs.removeElementAt(i);
    }
    

    protected class ConstraintsComponentPair{
        Component component = null;
        Object constraints = null;
        String name = null;
    
    
        ConstraintsComponentPair(){
          super();
        }
    
    
        ConstraintsComponentPair(Component component, Object constraints, String name){
          this.component = component;
          this.constraints = constraints;
          this.name = name;
        }
    }
}
