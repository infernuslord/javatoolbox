package multivalent.std.ui;

import java.util.Map;

import multivalent.*;
import multivalent.gui.VRadiogroup;
import multivalent.gui.VRadiobox;
import multivalent.gui.VMenuButton;
import multivalent.gui.VMenu;

import phelps.lang.Integers;



/**
	Zoom controls -- just work on PDF for now.
	For now simple menu of zoom factors, which are taken from ZOOMS attribute in hub.

	@version $Revision: 1.2 $ $Date: 2002/01/26 15:04:13 $
*/
public class Zoom extends Behavior {
  /**
	Reports current zoom factor.
	<p><tt>"getZoom"</tt>: <tt>arg=</tt> {@link java.lang.Double} <var>zoom-factor</var>
  */
  public static final String MSG_GET = "getZoom";

  /**
	Sets zoom factor from <var>arg</var>.
	<p><tt>"setZoom"</tt>: <tt>arg=</tt> {@link java.lang.Double} <var>zoom-factor</var>
  */
  public static final String MSG_SET = "setZoom";

  /**
	Construct Zoom menu by passing around to behaviors and letting them add (or delete) entiries.
	<p><tt>"createWidget/Zoom"</tt>: <tt>out=</tt> {@link VMenu} <var>instance-under-construction</var>.
  */
  public static final String MSG_CREATE_ZOOM = "createWidget/Zoom";

  public static final String ATTR_ZOOMS = "zooms";
  public static final String ATTR_ZOOM = "zoom";


  int[] zooms_ = null;
  int zoom_ = 100;
  VRadiogroup rg_ = new VRadiogroup();

  /** Entire GUI or just document content. */
  boolean all_ = false;

/*  public void buildBefore(Document doc) {
	semanticEventAfter(new SemanticEvent("zoom", Integer.toString(zoom_)), "zoom");
  }*/

/*
  public boolean formatBefore(Node node) {
	return false;
  }

  public boolean formatAfter(Node node) {
	// fool scrollbars
	return false;
  }

  public boolean paintBefore(Context cx, Node node) {
	cx.g.scale(zoom_/100.0, zoom_/100.0);
	// need to adjust Rectangle cliprect tooz
	return false;
  }

  public boolean paintAfter(Context cx, Node node) {
	cx.g.scale(100.0/zoom_, 100.0/zoom_);
	return false;
  }

  public boolean eventBefore(AWTEvent e, Point rel) {
	if (rel!=null) {
		rel.x = (rel.x * 100) / zoom_;
		rel.y = (rel.y * 100) / zoom_;
	}
	return false;
  }

  public boolean eventAfter(AWTEvent e, Point rel) {
	if (rel!=null) {
		rel.x = (rel.x * zoom_) / 100;
		rel.y = (rel.y * zoom_) / 100;
	}
	return false;
  }
*/


  /** On {@link VMenu#MSG_CREATE_VIEW}, add "Publish Annos to <server>" to menu. */
  public boolean semanticEventBefore(SemanticEvent se, String msg) {
	if (super.semanticEventBefore(se,msg)) return true;
	else if (VMenu.MSG_CREATE_VIEW==msg) {
		VMenuButton mb = (VMenuButton)createUI("menubutton", "Zoom", "event "+MSG_CREATE_ZOOM, (INode)se.getOut(), "View", false);
		mb.setDynamic("Zoom");

	} else if (MSG_CREATE_ZOOM==msg) {
		rg_.clear();
		for (int i=0,imax=zooms_.length; i<imax; i++) {
			int z = zooms_[i];
			VRadiobox radio = (VRadiobox)createUI("radiobox", "Zoom "+z+"%", "event "+MSG_SET+" "+z, (INode)se.getOut(), "Zoom", false);
			radio.setRadiogroup(rg_);
			if (zoom_ == z) rg_.setActive(radio);
		}
		//if (rg_.getActive()==null) ... add separator and menu element with that setting
	}
	return false;
  }


  public boolean semanticEventAfter(SemanticEvent se, String msg) {
	if (MSG_GET==msg) {
		se.setArg(new Double(zoom_));

	} else if (MSG_SET==msg) {
		Object arg = se.getArg();
		Browser br = getBrowser();

System.out.println(msg+" => "+arg);
		double z = -1.0; int z0=zoom_;

		if (arg instanceof String) try { z = Double.parseDouble((String)arg); } catch (NumberFormatException nfe) {}
		else if (arg instanceof Number) z = ((Number)arg).doubleValue();

		if (0.0<z && z<=1.0) {
			zoom_ = (int)(z * 100.0);

		} else if (1.0<z && z<1600.0) {
			zoom_ = (int)z;

		} // else negative or too big

		if (zoom_ != z0) {
			//br.eventq(Document.MSG_RELOAD, null);
			//br.eventq(Multipage.MSG_OPENPAGE, getDocument().getAttr(Document.PAGE));
			br.eventq(Multipage.MSG_RELOADPAGE, null);
		}
	}
/*
	if ("zoom"==msg) {
		Object arg = se.getArg();	// collect URL to save to dynamically, so to respond to filtering
System.out.println("zooming to "+arg);
		try {
			zoom_ = Integer.parseInt((String)arg);
			Browser br = getBrowser();
			IScrollPane isp = (all_? getRoot(): (Document)br.getDocRoot().childAt(0));
			//isp.zoom = zoom_;
			isp.setValid(false);
			isp.repaint();
		} catch (NumberFormatException nfe) {}
	}
*/
	return super.semanticEventAfter(se,msg);
  }


  public void restore(ESISNode n, Map<String,Object> attr, Layer layer) {
	super.restore(n,attr, layer);
	String[] szooms = getAttr(ATTR_ZOOMS, "50,100,110,125,150,175,200,400").split("\\s*,\\s*");
	zooms_ = new int[szooms.length];
	for (int i=0,imax=zooms_.length; i<imax; i++) {
		try { zooms_[i] = Integer.parseInt(szooms[i]); } catch (NumberFormatException nfe) { zooms_[i]=100; }
	}

	zoom_ = Integers.parseInt(getAttr(ATTR_ZOOM), 100);

	//all_ = Booleans.parseBoolean(getAttr("all
  }
}
