/*
 * 
 * Created on 2004-jun-29
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf;

import java.awt.Color;
import java.awt.Font;

import javax.swing.UIDefaults;
import javax.swing.border.CompoundBorder;
import javax.swing.border.LineBorder;
import javax.swing.plaf.FontUIResource;
import javax.swing.plaf.InsetsUIResource;
import javax.swing.plaf.basic.BasicBorders;
import javax.swing.plaf.metal.MetalLookAndFeel;

import se.diod.hippo.plaf.common.Border;
import se.diod.hippo.plaf.common.IconFactory;
import se.diod.hippo.plaf.theme.HippoTheme;




/**
 * 
 * @author Robert Karlsson
 * @created 2003-okt-26
 *
 */
public class HippoLookAndFeel extends MetalLookAndFeel {
	private static HippoTheme	myCurrentTheme;				// The current color theme




	/**
	 * 
	 * Constructs the <code>HippoLookAndFeel</code>.
	 * 
	 */
	public HippoLookAndFeel() {
		if( myCurrentTheme == null )
			setMyCurrentTheme( createMyDefaultTheme() );
	}




	public String getID()	{ return "HippoLF"; }
	public String getName() { return "HippoLF"; }
	public String getDescription() { return "Hippo Look and Feel" + " - \u00a9 2003 Robert Karlsson"; }

	public boolean isNativeLookAndFeel()	{ return false; }
	public boolean isSupportedLookAndFeel() { return true;  }




	/**
	 * 
	 * Initializes the class defaults
	 * 
	 */
	protected void initClassDefaults( UIDefaults table ) {
		super.initClassDefaults( table );

		final String PREFIX	= "se.diod.hippo.plaf.ui.Hippo";

		Object[] uiDefaults = {
			"ButtonUI",								PREFIX + "ButtonUI",
			"CheckBoxMenuItemUI",					PREFIX + "CheckBoxMenuItemUI",
			"ComboBoxUI",							PREFIX + "ComboBoxUI",
			//"FileChooserUI",						PREFIX + "FileChooserUI",
			"InternalFrameUI",						PREFIX + "InternalFrameUI",
			"MenuUI",								PREFIX + "MenuUI",
			"MenuItemUI",							PREFIX + "MenuItemUI",
			"OptionPaneUI",							PREFIX + "OptionPaneUI",
			"PanelUI",								PREFIX + "PanelUI",
			"PopupMenuSeparatorUI",					PREFIX + "PopupMenuSeparatorUI",
			"ProgressBarUI",						PREFIX + "ProgressBarUI",
			"RadioButtonMenuItemUI",				PREFIX + "RadioButtonMenuItemUI",
			"ScrollBarUI",							PREFIX + "ScrollBarUI",
			"ScrollPaneUI",							PREFIX + "ScrollPaneUI",
			"SliderUI",								PREFIX + "SliderUI",
			"SpinnerUI",							PREFIX + "SpinnerUI",
			"SplitPaneUI",							PREFIX + "SplitPaneUI",
			"TabbedPaneUI",							PREFIX + "TabbedPaneUI",
			"ToggleButtonUI",						PREFIX + "ToggleButtonUI",
			"ToolBarUI",							PREFIX + "ToolBarUI",
			"TreeUI",								PREFIX + "TreeUI",
		};

		table.putDefaults( uiDefaults );
	}




	/**
	 * 
	 * Initializes the component defaults
	 * 
	 */
	protected void initComponentDefaults( UIDefaults table ) {
		super.initComponentDefaults( table );

		final FontUIResource	FONT_NORMAL				= new FontUIResource( "Verdana", Font.PLAIN,  9 );
		final FontUIResource	FONT_LARGER				= new FontUIResource( "Verdana", Font.PLAIN,  10 );
		final FontUIResource	FONT_LARGEST			= new FontUIResource( "Verdana", Font.PLAIN,  11 );
		
		Object[] defaults = {
				//-- Button
				"Button.font",									FONT_NORMAL,
				"Button.background", 							getMyCurrentTheme().getButtonBackground(),
				"Button.border",								Border.getButtonBorder(),
				"Button.select", 								getMyCurrentTheme().getButtonSelect(),
				"Button.margin",								new javax.swing.plaf.InsetsUIResource( 4, 6, 4, 6 ),
				"Button.rolloverBackground",					getMyCurrentTheme().getButtonRolloverBackground(),

				//-- CheckBox
				"CheckBox.font",								FONT_NORMAL,
				"CheckBox.background",							getMyCurrentTheme().getCheckBoxBackground(),
				"CheckBox.icon",								IconFactory.getCheckBoxIcon(),

				//-- CheckBoxMenuItem
				"CheckBoxMenuItem.font",						FONT_NORMAL,
				"CheckBoxMenuItem.background",					getMyCurrentTheme().getCheckBoxMenuItemBackground(),
				"CheckBoxMenuItem.selectionBackground", 		getMyCurrentTheme().getMenuSelectionBackground(),
				"CheckBoxMenuItem.borderPainted", 				Boolean.FALSE,
				"CheckBoxMenuItem.borderColor",					getMyCurrentTheme().getCheckBoxMenuItemBorderColor(),
				"CheckBoxMenuItem.checkIcon",		 			IconFactory.getCheckBoxIcon(),
				"CheckBoxMenuItem.margin",		 				new javax.swing.plaf.InsetsUIResource( 3, 0, 3, 0 ),
				"CheckBoxMenuItem.border",		 				Border.getMenuItemBorder(),

				//-- ComboBox
				"ComboBox.font",								FONT_LARGEST,
				"ComboBox.background", 							getMyCurrentTheme().getComboBoxBackground(),
				"ComboBox.selectionBackground", 				getMyCurrentTheme().getComboBoxSelectionBackground(),

				//-- Desktop
				"Desktop.background", 							getMyCurrentTheme().getDesktopBackground(),

				//-- EditorPane
				"EditorPane.font",								FONT_LARGEST,
				"EditorPane.background",						getMyCurrentTheme().getEditorPaneBackground(),
				"EditorPane.border",							Border.getEmptyBorder(),
				"EditorPane.margin",							new InsetsUIResource( 2, 2, 2, 2 ),
				"EditorPane.selectionBackground",				getMyCurrentTheme().getEditorPaneSelectionBackground(),

				//-- FormattedTextField
				"FormattedTextField.font",						FONT_LARGEST,
				"FormattedTextField.background",				getMyCurrentTheme().getTextFieldBackground(),
				"FormattedTextField.inactiveBackground",		getMyCurrentTheme().getTextFieldInactiveBackground(),
				"FormattedTextField.margin",					new InsetsUIResource( 0, 2, 0, 2 ),
				"FormattedTextField.border",					new CompoundBorder( new LineBorder( new Color( 155, 155, 155 ), 1 ), new BasicBorders.MarginBorder() ),
				"FormattedTextField.selectionBackground",		getMyCurrentTheme().getTextFieldSelectionBackground(),

				//-- InternalFrame
				"InternalFrame.icon", 							makeIcon(getClass(), "/se/diod/hippo/images/java.gif"),
				"InternalFrame.closeIcon",						makeIcon(getClass(), "/se/diod/hippo/images/FrameClose.gif"),//HippoIconFactory.getIFrameCloseIcon(),
				"InternalFrame.iconifyIcon",					makeIcon(getClass(), "/se/diod/hippo/images/FrameMinimize.gif"),//HippoIconFactory.getIFrameIconifyIcon(),
				"InternalFrame.minimizeIcon",					makeIcon(getClass(), "/se/diod/hippo/images/FrameRestore.gif"),//HippoIconFactory.getIFrameMinimizeIcon(),
				"InternalFrame.maximizeIcon",					makeIcon(getClass(), "/se/diod/hippo/images/FrameMaximize.gif"),//HippoIconFactory.getIFrameMaximizeIcon(),
				"InternalFrame.titleFont",						FONT_LARGER,
				"InternalFrame.border", 						Border.getInternalFrameBorder(),
				"InternalFrame.borderColor",					getMyCurrentTheme().getInternalFrameBorderColor(),
				"InternalFrame.activeTitleBackground",			getMyCurrentTheme().getInternalFrameActiveTitleBackground(),
				"InternalFrame.activeTitleBackground2",			getMyCurrentTheme().getInternalFrameActiveTitleBackground2(),
				"InternalFrame.inactiveTitleBackground",		getMyCurrentTheme().getInternalFrameInactiveTitleBackground(),
				"InternalFrame.background",						getMyCurrentTheme().getInternalFrameBackground(),

				//-- Label
				"Label.font",									FONT_NORMAL,

				//-- List
				"List.font",									FONT_NORMAL,
				"List.background",								getMyCurrentTheme().getListBackground(),
				"List.selectionBackground",						getMyCurrentTheme().getListSelectionBackground(),

				//-- Menu
				"Menu.font",									FONT_NORMAL,
				"Menu.background",								getMyCurrentTheme().getMenuBackground(),
				"Menu.selectionBackground", 					getMyCurrentTheme().getMenuSelectionBackground(),
				"Menu.borderPainted", 							Boolean.FALSE,
				"Menu.margin",									new javax.swing.plaf.InsetsUIResource( 3, 0, 3, 0 ),
				"Menu.border",									Border.getMenuBorder(),
				"Menu.submenuPopupOffsetY",						new Integer( 0 ),
				"Menu.submenuPopupOffsetX",						new Integer( 0 ),
				"Menu.borderColor",								getMyCurrentTheme().getMenuBorderColor(),

				//-- MenuBar
				"MenuBar.border",								Border.getMenuBarBorder(),
				"MenuBar.borderColor",							getMyCurrentTheme().getMenuBarBorderColor(),
				"MenuBar.background",							getMyCurrentTheme().getMenuBackground(),

				//-- MenuItem
				"MenuItem.font",								FONT_NORMAL,
				"MenuItem.background",							getMyCurrentTheme().getMenuBackground(),
				"MenuItem.borderPainted", 						Boolean.FALSE,
				"MenuItem.border", 								Border.getMenuItemBorder(),
				"MenuItem.selectionBackground", 				getMyCurrentTheme().getMenuSelectionBackground(),
				"MenuItem.margin",								new javax.swing.plaf.InsetsUIResource( 2, 0, 2, 0 ),
				"MenuItem.iconBackground",						getMyCurrentTheme().getMenuIconBackground(),

				//-- OptionPane
				"OptionPane.background",						getMyCurrentTheme().getOptionPaneBackground(),
				"OptionPane.font",								FONT_NORMAL,
				"OptionPane.warningIcon",						makeIcon(getClass(), "/se/diod/hippo/images/Warn.gif"),
				"OptionPane.errorIcon",							makeIcon(getClass(), "/se/diod/hippo/images/Error.gif"),
				"OptionPane.informationIcon",					makeIcon(getClass(), "/se/diod/hippo/images/Inform.gif"),
				"OptionPane.questionIcon",						makeIcon(getClass(), "/se/diod/hippo/images/Question.gif"),

				//-- Panel
				"Panel.background",								getMyCurrentTheme().getPanelBackground(),

				//-- PasswordField
				"PasswordField.font",							FONT_LARGEST,
				"PasswordField.background",						getMyCurrentTheme().getTextFieldBackground(),
				"PasswordField.inactiveBackground",				getMyCurrentTheme().getTextFieldInactiveBackground(),
				"PasswordField.margin",							new InsetsUIResource( 0, 2, 0, 2 ),
				"PasswordField.border",							new CompoundBorder( new LineBorder( new Color( 155, 155, 155 ), 1 ), new BasicBorders.MarginBorder() ),
				"PasswordField.selectionBackground",			getMyCurrentTheme().getTextFieldSelectionBackground(),

				//-- PopupMenu
				"PopupMenu.border",								Border.getPopupMenuBorder(),
				"PopupMenu.font",								FONT_NORMAL,
				"PopupMenu.background",							getMyCurrentTheme().getPopupMenuBackground(),

				//-- ProgressBar
				"ProgressBar.background",						getMyCurrentTheme().getProgressBarBackground(),
				"ProgressBar.foreground",						getMyCurrentTheme().getProgressBarForeground(),
				"ProgressBar.cellLength",						new Integer( 10 ),
				"ProgressBar.cellSpacing",						new Integer( 1 ),
				"ProgressBar.font",								FONT_NORMAL,
				"ProgressBar.border",							Border.getProgressBarBorder(),
				"ProgressBar.borderColor",						getMyCurrentTheme().getProgressBarBorderColor(),

				//-- RadioButton
				"RadioButton.font",								FONT_NORMAL,
				"RadioButton.background",						getMyCurrentTheme().getRadioButtonBackground(),
				"RadioButton.icon",								IconFactory.getRadioButtonIcon(),

				//-- RadioButtonMenuItem
				"RadioButtonMenuItem.font",						FONT_NORMAL,
				"RadioButtonMenuItem.background",				getMyCurrentTheme().getRadioButtonMenuItemBackground(),
				"RadioButtonMenuItem.selectionBackground", 		getMyCurrentTheme().getMenuSelectionBackground(),
				"RadioButtonMenuItem.borderPainted", 			Boolean.FALSE,
				"RadioButtonMenuItem.checkIcon",		 		IconFactory.getRadioButtonMenuItemIcon(),
				"RadioButtonMenuItem.margin",		 			new javax.swing.plaf.InsetsUIResource( 3, 0, 3, 0 ),
				"RadioButtonMenuItem.border",		 			Border.getMenuItemBorder(),
				"RadioButtonMenuItem.borderColor",				getMyCurrentTheme().getRadioButtonMenuItemBorderColor(),

				//-- ScrollBar
				"ScrollBar.width",								new Integer( 15 ),
				"ScrollBar.background",							getMyCurrentTheme().getScrollBarBackground(),
				"ScrollBar.thumbBackground",					getMyCurrentTheme().getScrollBarThumbBackground(),
				"ScrollBar.thumbBorderColor",					getMyCurrentTheme().getScrollBarThumbBorderColor(),

				//-- ScrollPane
				"ScrollPane.border",							Border.getEmptyBorder(),
				"ScrollPane.background",						getMyCurrentTheme().getScrollPaneBackground(),

				//-- Separator
				"Separator.background",							getMyCurrentTheme().getSeparatorBackground(),		// Changes menu separator too.

				//-- Slider
				"Slider.font",									FONT_NORMAL,
				"Slider.background",							getMyCurrentTheme().getSliderBackground(),
				"Slider.horizontalThumbIcon",					IconFactory.getSliderHorizontalIcon(),
				"Slider.verticalThumbIcon",						IconFactory.getSliderVerticalIcon(),
				"Slider.trackWidth",							new Integer( 2 ),

				//-- Spinner
				"Spinner.border",								Border.getSpinnerBorder(),
				"Spinner.font",									FONT_NORMAL,
				"Spinner.arrowButtonBorder",					Border.getSpinnerBorder(),

				//-- SplitPane
				"SplitPane.background",							getMyCurrentTheme().getSplitPaneBackground(),
				"SplitPane.border",								Border.getEmptyBorder(),
				"SplitPane.highlight",							getMyCurrentTheme().getSplitPaneHighlight(),
				"SplitPane.darkShadow",							getMyCurrentTheme().getSplitPaneDarkShadow(),
				"SplitPane.shadow",								getMyCurrentTheme().getSplitPaneShadow(),
				"SplitPane.dividerSize",						new Integer( 7 ),

				//-- TabbedPane
				"TabbedPane.font",								FONT_NORMAL,
				"TabbedPane.background",						getMyCurrentTheme().getTabbedPaneBackground(),
				"TabbedPane.tabAreaInsets",						new javax.swing.plaf.InsetsUIResource( 0, 0, 0, 0 ),
				"TabbedPane.tabInsets",							new javax.swing.plaf.InsetsUIResource( 5, 6, 5, 6 ),

				//-- Table
				"Table.gridColor",								getMyCurrentTheme().getTableGridColor(),
				"Table.background",								getMyCurrentTheme().getTableBackground(),
				"Table.font",									FONT_NORMAL,
				"Table.focusCellBackground",					getMyCurrentTheme().getTableFocusCellBackground(),
				"Table.selectionBackground",					getMyCurrentTheme().getTableSelectionBackground(),
				"Table.border",									Border.getEmptyBorder(),

				// TableHeader
				"TableHeader.font",								FONT_LARGEST,
				"TableHeader.background",						getMyCurrentTheme().getTableHeaderBackground(),
				"TableHeader.cellBorder",						Border.getTableHeaderCellBorder(),
				"TableHeader.gridColor",						getMyCurrentTheme().getTableHeaderGridColor(),
				
				//-- TextArea
				"TextArea.font",								FONT_LARGEST,
				"TextArea.background",							getMyCurrentTheme().getTextAreaBackground(),
				"TextArea.margin",								new InsetsUIResource( 2, 2, 2, 2 ),
				"TextArea.selectionBackground",					getMyCurrentTheme().getTextAreaSelectionBackground(),

				//-- TextField
				"TextField.font",								FONT_LARGEST,
				"TextField.background",							getMyCurrentTheme().getTextFieldBackground(),
				"TextField.inactiveBackground",					getMyCurrentTheme().getTextFieldInactiveBackground(),
				"TextField.margin",								new InsetsUIResource( 0, 2, 0, 2 ),
				"TextField.border",								new CompoundBorder( new LineBorder( new Color( 155, 155, 155 ), 1 ), new BasicBorders.MarginBorder() ),
				"TextField.selectionBackground",				getMyCurrentTheme().getTextFieldSelectionBackground(),

				//-- TextPane
				"TextPane.font",								FONT_LARGEST,
				"TextPane.border",								Border.getEmptyBorder(),
				"TextPane.background",							getMyCurrentTheme().getEditorPaneBackground(),
				"TextPane.margin",								new InsetsUIResource( 2, 2, 2, 2 ),
				"TextPane.selectionBackground",					getMyCurrentTheme().getTextPaneSelectionBackground(),

				//-- TitledBorder
				"TitledBorder.font",							FONT_LARGEST,

				//-- ToggleButton
				"ToggleButton.background",						getMyCurrentTheme().getToggleButtonBackground(),
				"ToggleButton.border",							Border.getButtonBorder(),
				"ToggleButton.font",							FONT_NORMAL,
				"ToggleButton.select",							getMyCurrentTheme().getToggleButtonSelect(),
				"ToggleButton.margin",							new javax.swing.plaf.InsetsUIResource( 4, 6, 4, 6 ),

				//-- ToolBar
				"ToolBar.border",								Border.getToolBarBorder(),
				"ToolBar.background",							getMyCurrentTheme().getToolBarBackground(),
				"ToolBar.dragIconColor",						getMyCurrentTheme().getToolBarDragIconColor(),

				//-- ToolTip
				"ToolTip.font",									FONT_NORMAL,
				"ToolTip.background",							getMyCurrentTheme().getToolTipBackground(),
				"ToolTip.border",								Border.getToolTipBorder(),

				//-- Tree
				"Tree.font",									FONT_NORMAL,
				"Tree.background",								getMyCurrentTheme().getTreeBackground(),
				"Tree.textBackground",							getMyCurrentTheme().getTreeTextBackground(),
				"Tree.closedIcon", 								makeIcon(getClass(), "/se/diod/hippo/images/TreeClosed.gif"),
				"Tree.openIcon", 								makeIcon(getClass(), "/se/diod/hippo/images/TreeOpen.gif"),
				"Tree.leafIcon", 								makeIcon(getClass(), "/se/diod/hippo/images/TreeLeaf.gif"),
				"Tree.expandedIcon", 							IconFactory.getExpandedTreeIcon(),
				"Tree.collapsedIcon", 							IconFactory.getCollapsedTreeIcon(),
				"Tree.selectionBackground",						getMyCurrentTheme().getTreeSelectionBackground(),
				"Tree.hash",									getMyCurrentTheme().getTreeHash(),
		};

		table.putDefaults( defaults );
	}






	// ****************************************************************************
	//
	//                             Theme methods
	//
	// ****************************************************************************
	private static final String THEME_PACKAGE_PATH	= "se.diod.hippo.plaf.theme.HippoTheme";
	private static final String DEFAULT_THEME		= "Brown";




	/**
	 * 
	 * Sets a new <code>HippoTheme</code> for colors and fonts.
	 * 
	 */
	public static void setMyCurrentTheme( HippoTheme theme ) {
		myCurrentTheme = theme;
		setCurrentTheme( theme );
	}




	/**
	 * 
	 * Creates and answers the default color theme.
	 * 
	 */
	private static HippoTheme createMyDefaultTheme() {
		return createTheme( DEFAULT_THEME );
	}




	/**
	 * 
	 * Creates and answers a color theme from the specified theme name.
	 * 
	 */
	public static HippoTheme createTheme( String themeName ) {
		String className = THEME_PACKAGE_PATH + themeName;

		try {
			Class cl = Class.forName( className );
			return ( HippoTheme )( cl.newInstance() );
		}
		catch (ClassNotFoundException e) { System.out.println( "ClassNotFoundException :: " + e ); }
		catch (IllegalAccessException e) { System.out.println( "IllegalAccessException :: " + e ); }
		catch (InstantiationException e) { System.out.println( "InstantiationException :: " + e ); }

		System.out.println( "[Error   ][HippoLookAndFeel::createTheme(String)]\n  Failed to create theme [" + className + "]" );
		return null;
	}




	/**
	 * 
	 * Gets the current <code>HippoTheme</code>.
	 *
	 */
	public static HippoTheme getMyCurrentTheme() {
		return myCurrentTheme;
	}
}
