package multivalent.std.adaptor.ms;

import java.io.*;
import java.net.URL;
import java.net.MalformedURLException;
import java.awt.*;

import multivalent.*;
import multivalent.node.LeafAscii;



/**
	UNDER DEVELOPMENT.
	Microsoft Word.
	Based on Open Office's reverse engineering?

	@version $Revision$ $Date$
*/
public class MSWord extends multivalent.std.adaptor.MediaAdaptorRandom {
  static final boolean DEBUG = true;
  boolean test = false;

  public Object parse(INode parent) throws IOException {
	// = new DataInputStream(new BufferedInputStream(in));

	return null;
  }


//	Font defaultFont = new Font("Serif", Font.PLAIN, 12);	   // => take from doc
  public void buildBefore(Document doc) {
	doc.appendChild(new LeafAscii("don't handle Microsoft Word yet", null, null));
  }
}
