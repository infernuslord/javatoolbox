/*
 * Created on Aug 25, 2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package com.shfarr.ui;

import java.awt.Font;
import java.net.URL;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;

/**
 * @author Administrator
 */
public abstract class CustomTreeCellRenderer extends DefaultTreeCellRenderer{
    protected Vector bufferNames = null;
    protected Vector imageBuffer = null;
    
    
    public CustomTreeCellRenderer(){
      super();
        
      setFont((Font)javax.swing.UIManager.getDefaults().get("Tree.font"));
        
      setVerticalAlignment(javax.swing.SwingConstants.CENTER);
      setVerticalTextPosition(javax.swing.SwingConstants.CENTER);
        
      imageBuffer = new Vector();
      bufferNames = new Vector();
    }
    
    
    public abstract ImageIcon getOpenIconFor(DefaultMutableTreeNode o);
    public abstract ImageIcon getClosedIconFor(DefaultMutableTreeNode o);
    public abstract ImageIcon getLeafIconFor(DefaultMutableTreeNode o);
    
    
    protected boolean isPairCached(String url){
        return bufferNames.indexOf(url)!=-1;
    }
    
    
    protected void cachePair(String url, ImageIcon icon){
       bufferNames.add(url);
       imageBuffer.add(icon);
    }
    
    
    protected ImageIcon getIconFromBuffer(String url){
      int index = bufferNames.indexOf(url);
      ImageIcon icon = null;
        
      if(index==-1){
         URL rurl = ClassLoader.getSystemResource("cres/" + url);
         if(rurl != null) icon = new ImageIcon(rurl);
      }
      else icon = (ImageIcon)imageBuffer.elementAt(index);
        
      return icon;
    }
    
    
    public java.awt.Component getTreeCellRendererComponent(javax.swing.JTree tree, Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus){
      if(value!=null){
         int type = -1;
        
         setOpenIcon(getOpenIconFor(((DefaultMutableTreeNode)value)));
         setClosedIcon(getClosedIconFor(((DefaultMutableTreeNode)value)));
         setLeafIcon(getLeafIconFor(((DefaultMutableTreeNode)value)));
      }
         
      java.awt.Component cmp = super.getTreeCellRendererComponent(tree, value, selected, expanded, leaf, row, hasFocus);
        
      return cmp;
    }
    
    
    public void setText(String text){
      super.setText(" " + text);
    }
}
