// Copyright 2002, 2003 Elliotte Rusty Harold
// 
// This library is free software; you can redistribute 
// it and/or modify it under the terms of version 2.1 of 
// the GNU Lesser General Public License as published by  
// the Free Software Foundation.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General 
// Public License along with this library; if not, write to the 
// Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
// Boston, MA  02111-1307  USA
// 
// You can contact Elliotte Rusty Harold by sending e-mail to
// elharo@metalab.unc.edu. Please include the word "XOM" in the
// subject line. The XOM home page is temporarily located at
// http://www.cafeconleche.org/XOM/  but will eventually move
// to http://www.xom.nu/

package nu.xom.tests;

import junit.framework.Assert;
import junit.framework.TestCase;

import nu.xom.Comment;
import nu.xom.DocType;
import nu.xom.Document;
import nu.xom.Element;
import nu.xom.IllegalAddException;
import nu.xom.NoSuchChildException;
import nu.xom.ProcessingInstruction;
import nu.xom.Text;
import nu.xom.WellformednessException;


/**
 * @author Elliotte Rusty Harold
 *
 */
public class DocumentTest extends TestCase {

    public DocumentTest(String name) {
        super(name);
    }
    
    private Element root;
    private Document doc;
    
    
    protected void setUp() {
        root = new Element("root");
        doc = new Document(root);

    }
    
    public void testDocTypeInsertion() {
        DocType type1 = new DocType("root");
        
        try {
            doc.insertChild(type1, 1);
            fail("inserted doctype after root element");
        }
        catch (IllegalAddException ex) {
            // success
        }
        
        doc.insertChild(type1, 0);
        Assert.assertEquals(doc.getDocType(), type1);
        
        DocType type2 = new DocType("test");
        try {
            doc.insertChild(type2, 1);
            fail("Inserted 2nd DocType");
        }
        catch (IllegalAddException ex) {
            // success   
        }
        Assert.assertEquals(doc.getDocType(), type1);
        assertNull(type2.getParent());
        Assert.assertEquals(doc.getChild(0), type1);
        
        doc.setDocType(type2);
        Assert.assertEquals(doc.getDocType(), type2);
        assertNull(type1.getParent());
        Assert.assertEquals(doc.getChild(0), type2);
        
        
    }

    public void testSetDocType() {
        DocType type1 = new DocType("root");       
        doc.setDocType(type1);
        Assert.assertEquals(doc.getDocType(), type1);
        
        doc.insertChild(new Comment("test"), 0);

        DocType type2 = new DocType("root", "http://www.example.com/");       
        doc.setDocType(type2);
        Assert.assertEquals(doc.getDocType(), type2);
        assertEquals(doc.indexOf(type2), 1);
        
    }

    public void testBaseURI() {
        
        assertNull(doc.getBaseURI());
        doc.setBaseURI("http://www.example.com/index.xml");
        assertEquals(doc.getBaseURI(), "http://www.example.com/index.xml");
        doc.setBaseURI("file:///home/elharo/XOM/data/test.xml");
        assertEquals(doc.getBaseURI(), "file:///home/elharo/XOM/data/test.xml");
        doc.setBaseURI("file:///home/elharo/XO%4D/data/test.xml");
        assertEquals(doc.getBaseURI(), "file:///home/elharo/XO%4D/data/test.xml");

    }
    
    public void testSecondRoot() {
    
        try {
            doc.insertChild(new Element("test"), 0);
            fail("Added second root element");
        }
        catch (IllegalAddException ex) {
          // success    
        }
        
    }

    public void testSetRoot() {
        Element newRoot = new Element("newroot");
        doc.setRootElement(newRoot);
        
        assertEquals(doc.getRootElement(), newRoot);
        assertNull(root.getParent());
        
        try {
            doc.setRootElement(null);              
        }
        catch (NullPointerException ex) {
            // success   
        }
        
    }

    public void testDetach() {
        Comment comment = new Comment("This will be attached then detached");
        doc.appendChild(comment);
        assertEquals(doc, comment.getParent());
        comment.detach();
        assertNull(comment.getParent());
    }

    public void testGetDocument() {
        assertEquals(doc, doc.getDocument());
    }

    public void testConstructor() {
    
        Assert.assertEquals(root, doc.getRootElement());
        Assert.assertEquals(1, doc.getChildCount());
        
        Element newRoot = new Element("newRoot");
        doc.setRootElement(newRoot);
        Assert.assertEquals(newRoot, doc.getRootElement());
        Assert.assertEquals(1, doc.getChildCount());
        
        doc.appendChild(new Comment("test"));
        Assert.assertEquals(2, doc.getChildCount());

        doc.insertChild(new Comment("prolog comment"), 0);
        Assert.assertEquals(3, doc.getChildCount());
        Assert.assertTrue(doc.getChild(0) instanceof Comment);
        Assert.assertTrue(doc.getChild(1) instanceof Element);
        Assert.assertTrue(doc.getChild(2) instanceof Comment);

        doc.insertChild(new ProcessingInstruction("target", "data"), 1);
        Assert.assertTrue(doc.getChild(0) instanceof Comment);
        Assert.assertTrue(doc.getChild(1) instanceof ProcessingInstruction);
        Assert.assertTrue(doc.getChild(2) instanceof Element);
        Assert.assertTrue(doc.getChild(3) instanceof Comment);

        doc.insertChild(new ProcessingInstruction("epilog", "data"), 3);
        Assert.assertTrue(doc.getChild(0) instanceof Comment);
        Assert.assertTrue(doc.getChild(1) instanceof ProcessingInstruction);
        Assert.assertTrue(doc.getChild(2) instanceof Element);
        Assert.assertTrue(doc.getChild(3) instanceof ProcessingInstruction);
        Assert.assertTrue(doc.getChild(4) instanceof Comment);

        
        try {
            Element nullRoot = null;
            new Document(nullRoot);
            fail("allowed null root!");
        }
        catch (NullPointerException ex) {
            // success  
        }
        
        try {
            Document nullDoc = null;
            new Document(nullDoc);
            fail("allowed null doc!");
        }
        catch (NullPointerException ex) {
            // success  
        }
        
    }
    
    public void testCopyConstructor() {
        
        doc.insertChild(new Comment("text"), 0);
        doc.insertChild(new ProcessingInstruction("text", "data"), 1);
        doc.insertChild(new DocType("text"), 2);
        root.appendChild("some data");
        doc.appendChild(new Comment("after"));
        doc.appendChild(new ProcessingInstruction("text", "after"));
        
        Document doc2 = new Document(doc);
        XMLAssert.assertEquals(doc, doc2);
        
    }
    
    public void testCopyConstructorBaseURI() {
        
        doc.setBaseURI("http://www.example.com/");
        
        Document doc2 = new Document(doc);
        assertEquals(doc2.getBaseURI(), doc.getBaseURI());
        assertEquals(doc2.getBaseURI(), "http://www.example.com/");
        assertEquals(doc2.getRootElement().getBaseURI(), doc.getRootElement().getBaseURI());
        assertEquals(doc2.getRootElement().getBaseURI(), "http://www.example.com/");
        
    }
    
    public void testCopy() {
        
        doc.insertChild(new Comment("text"), 0);
        doc.insertChild(new ProcessingInstruction("text", "data"), 1);
        doc.insertChild(new DocType("text"), 2);
        root.appendChild("some data");
        doc.appendChild(new Comment("after"));
        doc.appendChild(new ProcessingInstruction("text", "after"));
        
        Document doc2 = (Document) doc.copy();
        XMLAssert.assertEquals(doc, doc2);
        
    }
    
    public void testAppend() {
    
        Element root = new Element("root");
        Document doc = new Document(root);

        try {
            doc.appendChild(new Text("test"));
            fail("appended string");
        }   
        catch (IllegalAddException e) {
            // success  
        }
        
        try {
            doc.appendChild(new Text("    "));
            fail("appended white space");
        }   
        catch (IllegalAddException e) {
            // success  
        }
        
        try {
            doc.appendChild(new Text("test"));
            fail("appended Text");
        }   
        catch (IllegalAddException e) {
            // success  
        }
        
        try {
            doc.appendChild(new Comment("test"));
            doc.appendChild(new Element("test"));
            fail("appended element");
        }   
        catch (IllegalAddException e) {
            // success  
        }
        
        try {
            doc.insertChild(new Element("test"), 0);
            fail("inserted element");
        }   
        catch (IllegalAddException e) {
            // success  
        }
        
    }

    public void testRemoval() {
    
        Element root = new Element("root");
        Document doc = new Document(root);

        try {
            root.detach();
            fail("detached root element");
        }   
        catch (WellformednessException e) {
            // success  
        }
        
        try {
            doc.removeChild(root);
            fail("removed root element");
        }   
        catch (WellformednessException e) {
            // success  
        }
        
        try {
            doc.removeChild(0);
            fail("removed root element");
        }   
        catch (WellformednessException e) {
            // success  
        }
        
        doc.appendChild(new Comment("test"));
        doc.removeChild(1);
        Assert.assertEquals(1, doc.getChildCount());
        
        Comment test = new Comment("test");
        doc.appendChild(test);
        doc.removeChild(test);
        Assert.assertEquals(1, doc.getChildCount());
        
        try {
            Comment something = new Comment("sd");
            doc.removeChild(something);
            fail("Removed nonchild");
        }
        catch (NoSuchChildException ex) {
            // success   
        }

        try {
            doc.removeChild(20);
            fail("removed overly sized element");
        }   
        catch (IndexOutOfBoundsException e) {
            // success  
        }


        
    }



}
