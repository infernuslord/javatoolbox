/**
 * $ $ License.
 *
 * Copyright $ L2FProd.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.l2fprod.common.propertysheet;

import com.l2fprod.common.beans.editor.*;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Rectangle;
import java.beans.PropertyEditor;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * Mapping between Properties, Property Types and Property Editors.
 */
public class PropertyEditorRegistry {

  private Map typeToEditor;
  private Map propertyToEditor;

  public PropertyEditorRegistry() {
    typeToEditor = new HashMap();
    propertyToEditor = new HashMap();
    registerDefaults();
  }

  /**
   * Gets an editor for the given property. The lookup is as follow:
   * <ul>
   * <li>if an editor was registered with
   * {@link #registerEditor(Property, PropertyEditor)}, it is
   * returned, else</li>
   * <li>if an editor class was registered with
   * {@link #registerEditor(Property, Class)}, it is returned, else
   * <li>
   * <li>look for editor for the property type using
   * {@link #getEditor(Class)}.</li>
   * </ul>
   * 
   * @param property
   * @return an editor suitable for the Property.
   */
  public synchronized PropertyEditor getEditor(Property property) {
    PropertyEditor editor = null;
    Object value = propertyToEditor.get(property);
    if (value instanceof PropertyEditor) {
      editor = (PropertyEditor)value;
    } else if (value instanceof Class) {
      try {
        editor = (PropertyEditor)((Class)value).newInstance();
      } catch (Exception e) {
        e.printStackTrace();
      }
    } else {
      editor = getEditor(property.getType());
    }
    return editor;
  }

  /**
   * Gets an editor for the given property type. The lookup is as
   * follow:
   * <ul>
   * <li>if an editor was registered with
   * {@link #registerEditor(Class, PropertyEditor)}, it is returned,
   * else</li>
   * <li>if an editor class was registered with
   * {@link #registerEditor(Class, Class)}, it is returned, else
   * <li>
   * <li>it returns null.</li>
   * </ul>
   * 
   * @param type
   * @return an editor suitable for the Property type or null if none
   *         found
   */
  public synchronized PropertyEditor getEditor(Class type) {
    PropertyEditor editor = null;
    Object value = typeToEditor.get(type);
    if (value instanceof PropertyEditor) {
      editor = (PropertyEditor)value;
    } else if (value instanceof Class) {
      try {
        editor = (PropertyEditor)((Class)value).newInstance();
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return editor;
  }

  public synchronized void registerEditor(Class type, Class editorClass) {
    typeToEditor.put(type, editorClass);
  }

  public synchronized void registerEditor(Class type, PropertyEditor editor) {
    typeToEditor.put(type, editor);
  }

  public synchronized void unregisterEditor(Class type) {
    typeToEditor.remove(type);
  }

  public synchronized void registerEditor(Property property, Class editorClass) {
    propertyToEditor.put(property, editorClass);
  }

  public synchronized void registerEditor(Property property,
      PropertyEditor editor) {
    propertyToEditor.put(property, editor);
  }

  public synchronized void unregisterEditor(Property property) {
    propertyToEditor.remove(property);
  }

  /**
   * Adds default editors. This method is called by the constructor
   * but may be called later to reset any customizations made through
   * the <code>registerEditor</code> methods. <b>Note: if overriden,
   * <code>super.registerDefaults()</code> must be called before
   * plugging custom defaults. </b>
   */
  public void registerDefaults() {
    typeToEditor.clear();
    propertyToEditor.clear();

    // our editors
    registerEditor(String.class, StringPropertyEditor.class);

    registerEditor(double.class, DoublePropertyEditor.class);
    registerEditor(Double.class, DoublePropertyEditor.class);

    registerEditor(float.class, FloatPropertyEditor.class);
    registerEditor(Float.class, FloatPropertyEditor.class);

    registerEditor(int.class, IntegerPropertyEditor.class);
    registerEditor(Integer.class, IntegerPropertyEditor.class);

    registerEditor(long.class, LongPropertyEditor.class);
    registerEditor(Long.class, LongPropertyEditor.class);

    registerEditor(short.class, ShortPropertyEditor.class);
    registerEditor(Short.class, ShortPropertyEditor.class);

    registerEditor(boolean.class, BooleanAsCheckBoxPropertyEditor.class);
    registerEditor(Boolean.class, BooleanAsCheckBoxPropertyEditor.class);

    registerEditor(File.class, FilePropertyEditor.class);

    // awt object editors
    registerEditor(Color.class, ColorPropertyEditor.class);
    registerEditor(Dimension.class, DimensionPropertyEditor.class);
    registerEditor(Insets.class, InsetsPropertyEditor.class);
    try {
      Class fontEditor =
        Class.forName("com.l2fprod.common.beans.editor.FontPropertyEditor");
      registerEditor(Font.class, fontEditor);
    } catch (Exception e) {
      // FontPropertyEditor might not be there when using the split jars
    }
    registerEditor(Rectangle.class, RectanglePropertyEditor.class);
  }

}
