package phelps.crypto;

//import javax.crypto.CipherSpi;
import java.io.*;
import java.util.Iterator;

import phelps.io.Files;



/**
	<a href='http://www.rsa.com'>RSA</a>'s <a href='http://www.achtung.com/crypto/rc4.html'>RC4</a> encryption/decryption.
	This should inherit from javax.crypto.CipherSpi and be used through javax.crypto.Cipher.getInstance("RC4").
	However, it would take some effort to conform to the API,
	and installation, in order to maintain security, is not automatic.
	Thus, primarily for convenience of installation, it is provided outside of Java's cryptography architecture.
	<!-- If Sun decided to build into Java a RC4 implementation, we may as well switch to it. -->

	@author T.A. Phelps
	@version $Revision: 1.8 $ $Date: 2003/06/01 08:06:17 $
*/

public class RC4 /*extends CipherSpi*/ {
  private int[] S_ = new int[256];    // use int's because adding values and want unsigned
  private int[] S0_;
  private int i_=0, j_=0;

  public RC4(byte[] key) {
	assert key!=null && key.length>0: key;
	for (int i=0; i<256; i++) S_[i] = i;

	int[] K = new int[256];
	for (int i=0, j=0, jmax=key.length; i<256; i++) {
		K[i] = key[j]&0xff;
		j++; if (j==jmax) j=0;
	}

	for (int i=0, j=0; i<256; i++) {
		j = (j + S_[i] + K[i]) & 0xff;     // &0xff same as mod 256;
		int tmp=S_[i]; S_[i]=S_[j]; S_[j]=tmp;
	}

	S0_ = (int[])S_.clone();
  }


  /** Convenience method; same as <code>encrypt(data, 0, data.length). */
  public void encrypt(byte[] data) { encrypt(data, 0, data.length); }
  /**
	Encrypt data from <var>data</var>, starting at <var>off</var> and extending for <var>length</var> bytes.
	In fact RC4 is symmetric so encrypt and decrypt are the same, but separate method names make intentions clearer.
  */
  public void encrypt(byte[] data, int off, int length) { decrypt(data, off, length); }

  /** Convenience method; same as <code>decrypt(data, 0, data.length). */
  public void decrypt(byte[] data) { decrypt(data, 0, data.length); }

  /**
	Decrypt data from <var>data</var>, starting at <var>off</var> and extending for <var>length</var> bytes.
	Input data is mutated.
  */
  public void decrypt(byte[] data, int off, int length) {
	int i=i_, j=j_; int[] S=S_;
	for (int offmax=off+length; off<offmax; off++) {
		i = (i+1) & 0xff;
		j = (j + S[i]) & 0xff;
		int tmp=S[i]; S[i]=S[j]; S[j]=tmp;
		int t = (S[i] + S[j]) & 0xff;
		data[off] ^= S[t];
	}
	i_=i; j_=j;
  }

/*
  public byte decrypt1(byte datum) {
	// copy body -- only 6 lines
	i_ = (i_+1) & 0xff;
	j_ = (j_ + S_[i_]) & 0xff;
	int tmp=S_[i_]; S_[i_]=S_[j_]; S_[j_]=tmp;
	int t = (S_[i_] + S_[j_]) & 0xff;
	int k = S_[t];
	return (byte)(datum ^ k);
  }
*/

  public void reset() { System.arraycopy(S0_,0, S_,0, S_.length); }

/*  public Object clone() {
	RC4 newrc = null;
	try { newrc = (RC4)super.clone(); } catch (CloneNotSupportedException canthappen) {}
	newrc.S_ = (int[])S_.clone();
	return newrc;
  }*/
}
