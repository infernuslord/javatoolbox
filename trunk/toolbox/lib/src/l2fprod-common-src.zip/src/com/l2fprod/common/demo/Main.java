/**
 * L2FProd.com Common Components 0.1-dev License.
 *
 * Copyright 2004 L2FProd.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.l2fprod.common.demo;

import com.l2fprod.common.swing.JButtonBar;
import com.l2fprod.common.swing.LookAndFeelTweaks;
import com.l2fprod.common.swing.StatusBar;
import com.l2fprod.common.swing.UIUtilities;
import com.l2fprod.common.swing.plaf.misc.IconPackagerButtonBarUI;
import com.l2fprod.common.util.ResourceManager;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

/**
 * Main. <br>Demonstration of L2FProd.com Common Components
 *  
 */
public class Main extends JFrame {

  static ResourceManager RESOURCE = ResourceManager.all(Main.class);

  private Component currentComponent;

  public Main() {
    super(RESOURCE.getString("Main.title"));
    buildUI();
  }

  private void show(Component component) {
    if (currentComponent != null) {
      getContentPane().remove(currentComponent);
    }
    getContentPane().add("Center", currentComponent = component);
    getContentPane().invalidate();
    getContentPane().validate();
    getContentPane().repaint();
  }

  private void addButton(
    String title,
    String iconUrl,
    final Component component,
    JButtonBar left,
    JButtonBar right,
    ButtonGroup group) {
    Action action =
      new AbstractAction(
        title,
        new ImageIcon(Main.class.getResource(iconUrl))) {
      public void actionPerformed(ActionEvent e) {
        show(component);
      }
    };

    JToggleButton buttonLeft = new JToggleButton(action);
    left.add(buttonLeft);
    
    group.add(buttonLeft);

    JToggleButton buttonRight = new JToggleButton(action);
    right.add(buttonRight);
    buttonRight.setModel(buttonLeft.getModel());

    if (group.getSelection() == null) {
      buttonLeft.setSelected(true);
      show(component);
    }
  }

  private void buildUI() {
    ((JComponent)getContentPane()).setBorder(LookAndFeelTweaks.PANEL_BORDER);

    getContentPane().setLayout(LookAndFeelTweaks.createBorderLayout());

    setDefaultCloseOperation(EXIT_ON_CLOSE);

    // We will have two button bar, one on the left and one on the right
    // both with different look and feels
    JButtonBar toolbarLeft = new JButtonBar(JButtonBar.VERTICAL);
    
    // use the IconPackager ui for the right pane
    JButtonBar toolbarRight = new JButtonBar(JButtonBar.VERTICAL);
    toolbarRight.setUI(new IconPackagerButtonBarUI());

    getContentPane().add("West", toolbarLeft);
    getContentPane().add("East", toolbarRight);

    ButtonGroup group = new ButtonGroup();

    addButton(
      RESOURCE.getString("Main.welcome"),
      "icons/welcome32x32.png",
      new WelcomePage(RESOURCE.getString("Main.welcome")),
      toolbarLeft,
      toolbarRight,
      group);

    addButton(
      RESOURCE.getString("Main.sheet1"),
      "icons/propertysheet32x32.png",
      new PropertySheetPage(RESOURCE.getString("Main.sheet1")),
      toolbarLeft,
      toolbarRight,
      group);

    addButton(
      RESOURCE.getString("Main.sheet2"),
      "icons/propertysheet32x32.png",
      new PropertySheetPage2(RESOURCE.getString("Main.sheet2")),
      toolbarLeft,
      toolbarRight,
      group);

    addButton(
      RESOURCE.getString("Main.fonts"),
      "icons/fonts32x32.png",
      new FontChooserPage(RESOURCE.getString("Main.fonts")),
      toolbarLeft,
      toolbarRight,
      group);

    addButton(
      RESOURCE.getString("Main.folder"),
      "icons/folder32x32.png",
      new FolderPage(RESOURCE.getString("Main.folder")),
      toolbarLeft,
      toolbarRight,
      group);
    
    // a simple menubar
    JMenuBar menubar = new JMenuBar();
    JMenu file = new JMenu(RESOURCE.getString("file.text"));
    file.setMnemonic(RESOURCE.getChar("file.mnemonic"));
    JMenuItem exit = new JMenuItem(RESOURCE.getString("exit.text"));
    exit.setMnemonic(RESOURCE.getChar("exit.mnemonic"));
    exit.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        System.exit(0);
      }
    });
    file.add(exit);
    menubar.add(file);
    setJMenuBar(menubar);

    // a status bar with two zones, the message zone and a progress
    StatusBar statusbar = new StatusBar();
    statusbar.addZone("message", new JLabel(" "), "*");
    statusbar.addZone("progress", new JProgressBar(), "150");
    getContentPane().add("South", statusbar);

    // set a text in the message zone
    ((JLabel)statusbar.getZone("message")).setText(RESOURCE.getString("ready"));
    // put the progress in indeterminate state
    ((JProgressBar)statusbar.getZone("progress")).setIndeterminate(true);

    setSize(640, 480);
    UIUtilities.centerOnScreen(this);
  }

  public static void main(String[] args) throws Exception {
    
    try {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    } catch (Exception e) {
    }

    LookAndFeelTweaks.tweak();

    Main main = new Main();
    main.show();
  }

}
