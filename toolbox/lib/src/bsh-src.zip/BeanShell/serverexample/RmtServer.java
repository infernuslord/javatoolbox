//file: RmtServer.java
import java.rmi.*;
import java.util.*;

public interface RmtServer extends Remote {
    Date getDate(  ) throws RemoteException;
    Object execute( WorkRequest work ) throws RemoteException;
}
