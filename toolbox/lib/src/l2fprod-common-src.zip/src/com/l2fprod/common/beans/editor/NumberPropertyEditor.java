/**
 * $ $ License.
 *
 * Copyright $ L2FProd.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.l2fprod.common.beans.editor;

import com.l2fprod.common.swing.LookAndFeelTweaks;

import javax.swing.JFormattedTextField;

/**
 * NumberPropertyEditor. <br>
 *  
 */
public class NumberPropertyEditor extends AbstractPropertyEditor {

  private Class type;

  public NumberPropertyEditor(Class type) {
    if (!Number.class.isAssignableFrom(type)) {
      throw new IllegalArgumentException("type must be a subclass of Number");
    }

    editor = new JFormattedTextField();
    this.type = type;
    ((JFormattedTextField)editor).setValue(getDefaultValue());
    ((JFormattedTextField)editor).setBorder(LookAndFeelTweaks.EMPTY_BORDER);
  }

  public Object getValue() {
    Number number = (Number)((JFormattedTextField)editor).getValue();
    if (Double.class.equals(type)) {
      return new Double(number.doubleValue());
    } else if (Float.class.equals(type)) {
      return new Float(number.floatValue());
    } else if (Integer.class.equals(type)) {
      return new Integer(number.intValue());
    } else if (Long.class.equals(type)) {
      return new Long(number.longValue());
    } else if (Short.class.equals(type)) {
      return new Short(number.shortValue());
    } else {
      // never happen
      return null;
    }
  }

  public void setValue(Object value) {
    if (value == null) {
      ((JFormattedTextField)editor).setValue(getDefaultValue());
    } else if (value instanceof Number) {
      ((JFormattedTextField)editor).setValue(value);
    } else {
      ((JFormattedTextField)editor).setValue(getDefaultValue());
    }
  }

  private Object getDefaultValue() {
    try {
      return type.getConstructor(new Class[] { String.class }).newInstance(
        new Object[] { "0" });
    } catch (Exception e) {
      // will not happen
      throw new RuntimeException(e);
    }
  }

}
