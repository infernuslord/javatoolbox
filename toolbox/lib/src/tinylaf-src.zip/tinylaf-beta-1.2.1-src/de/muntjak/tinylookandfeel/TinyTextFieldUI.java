/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	Tiny Look and Feel                                                         *
*                                                                              *
*  (C) Copyright 2003, Hans Bickel                                             *
*                                                                              *
*   For licensing information and credits, please refer to the                 *
*   comment in file de.muntjak.tinylookandfeel.TinyLookAndFeel                 *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package de.muntjak.tinylookandfeel;

import java.awt.*;
import javax.swing.*;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.metal.MetalTextFieldUI;
import javax.swing.text.JTextComponent;

import de.muntjak.tinylookandfeel.controlpanel.*;

/**
 * TinyTextFieldUI
 * 
 * @version 1.0
 * @author Hans Bickel
 */
public class TinyTextFieldUI extends MetalTextFieldUI {
	
	JTextField textField;
	/**
	 * Method createUI.
	 * @param mainColor
	 * @return ComponentUI
	 */
	public static ComponentUI createUI(JComponent c) {
		return new TinyTextFieldUI();
	}

	/**
	 * @see javax.swing.plaf.basic.BasicTextFieldUI#installUI(javax.swing.JComponent)
	 */
	public void installUI(JComponent c) {
		super.installUI(c);
		
		if(!ControlPanel.isInstantiated) return;
		
		textField = (JTextField)c;
		textField.setSelectionColor(Theme.textSelectedBgColor[Theme.style].getColor());
		textField.setSelectedTextColor(Theme.textSelectedTextColor[Theme.style].getColor());
		textField.setBackground(Theme.textBgColor[Theme.style].getColor());
		textField.setForeground(Theme.textTextColor[Theme.style].getColor());
		textField.setDisabledTextColor(Theme.disColor[Theme.style].getColor());
	}

	protected void paintBackground(Graphics g) {	
		JTextComponent editor = getComponent();
		
		if (editor.isEnabled()) {
			if(editor.isEditable()) {
				g.setColor(editor.getBackground());
			}
			else {
				g.setColor(Theme.backColor[Theme.style].getColor());
			}
			g.fillRect(0, 0, editor.getWidth(), editor.getHeight());
		} else {
			g.setColor(Theme.textDisabledBgColor[Theme.style].getColor());
			g.fillRect(0, 0, editor.getWidth(), editor.getHeight());
			
			if(Theme.style != Theme.XP_STYLE) return;
			
			g.setColor(Theme.backColor[Theme.style].getColor());
			g.drawRect(1, 1, editor.getWidth() - 3, editor.getHeight() - 3);
			g.drawRect(2, 2, editor.getWidth() - 5, editor.getHeight() - 5);
		}
	}
}