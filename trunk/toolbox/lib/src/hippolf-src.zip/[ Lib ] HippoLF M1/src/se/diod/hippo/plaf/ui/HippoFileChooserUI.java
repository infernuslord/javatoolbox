package se.diod.hippo.plaf.ui;



import javax.swing.JComponent;
//import javax.swing.UIManager;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicFileChooserUI;
import javax.swing.JFileChooser;




/**
 * 
 * @author Robert Blixt
 * @created 2004-dec-05
 *
 */
public class HippoFileChooserUI extends BasicFileChooserUI {




	/**
	 * 
	 * 
	 */
	public HippoFileChooserUI( JFileChooser b ) {
		super( b );
	}

	
	
	
	/**
	 * 
	 * 
	 * 
	 */
	public static ComponentUI createUI( JComponent c ) {
		return new HippoFileChooserUI( (JFileChooser)c );
	}




	/**
	 * 
	 * 
	 */
	public void installUI( JComponent c ) {
		super.installUI( c );
	}
}
