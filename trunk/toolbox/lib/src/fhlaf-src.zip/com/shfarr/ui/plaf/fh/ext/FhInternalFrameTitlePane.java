/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh.ext;

import java.awt.*;

import javax.swing.*;
import javax.swing.plaf.basic.*;

import com.shfarr.ui.*;
import com.shfarr.ui.plaf.fh.textures.*;
import com.shfarr.ui.plaf.fh.theme.*;



public class FhInternalFrameTitlePane extends BasicInternalFrameTitlePane{
	protected static LayoutManager layout = null;
	
	public FhInternalFrameTitlePane(JInternalFrame f){
	  super(f);
	}
	
	protected void createButtons(){
	  iconButton = new FhSysButton(FhSysButton.MINIMIZER);
	  iconButton.addActionListener(iconifyAction);
	
	  maxButton = new FhSysButton(FhSysButton.MAXIMIZER);
	  maxButton.addActionListener(maximizeAction);
	
	  closeButton = new FhSysButton(FhSysButton.CLOSER);
	  closeButton.addActionListener(closeAction);
	
	  setButtonIcons();
	}

	protected LayoutManager createLayout(){
	  if(layout==null){
	     layout = new FhInternalFrameTitlePaneLayout();
	  }
	  
	  return layout;
	}
	
	protected JButton getCloseButtonFromAncestor(){
	  return closeButton;
	}
	
	protected JInternalFrame getFrameFromAncestor(){
	  return frame;
	}
	
	protected JButton getIconButtonFromAncestor(){
	  return iconButton;
	}
	
	protected JButton getMaxButtonFromAncestor(){
	  return maxButton;
	}
	
	protected JMenuBar getMenuBarFromAncestor(){
	  return menuBar;
	}

    protected String getTitle(String text, FontMetrics fm, int availTextWidth) {
      if ( (text == null) || (text.equals("")) )  return "";
      int textWidth = SwingUtilities.computeStringWidth(fm, text);
      String clipString = "...";
      if (textWidth > availTextWidth) {
          int totalWidth = SwingUtilities.computeStringWidth(fm, clipString);
          int nChars;
          for(nChars = 0; nChars < text.length(); nChars++) {
              totalWidth += fm.charWidth(text.charAt(nChars));
              if (totalWidth > availTextWidth) {
                  break;
              }
          }
          text = text.substring(0, nChars) + clipString;
      }
      return text;
    }


	public void paintComponent(Graphics g)  {
	  paintTitleBackground(g);
	
	  if(frame.getTitle() != null){
		 boolean isSelected = frame.isSelected();
		 Font f = g.getFont();
		 g.setFont(getFont());
	
	     FontMetrics fm = g.getFontMetrics();
	     int baseline = (getHeight() + fm.getAscent() -fm.getLeading() -fm.getDescent())/2;
	
	     int titleX;
	     Rectangle r = new Rectangle(0, 0, 0, 0);
	     if(frame.isIconifiable())  r = iconButton.getBounds();
	     else if(frame.isMaximizable())  r = maxButton.getBounds();
	     else if(frame.isClosable())  r = closeButton.getBounds();
		    
	     int titleW;
		
	     String title = frame.getTitle();
	  
	     if(r.x == 0) r.x = frame.getWidth()-frame.getInsets().right;
	              
	     titleX = menuBar.getX() + menuBar.getWidth() + 5;
	     titleW = r.x - titleX - 3;
	     title = getTitle(frame.getTitle(), fm, titleW);
	
		 if(isSelected){
			g.setColor(selectedTextColor);
		    g.drawString(title, titleX, baseline);
		 }
	     else{
		      g.setColor(notSelectedTextColor);
	          g.drawString(title, titleX, baseline);
	     }
	
		 g.setFont(f);
	  }
	}


	protected void paintTitleBackground(Graphics g) {
	  boolean isSelected = frame.isSelected();
	
	  Dimension size = getSize();
	  g.setColor(notSelectedTitleColor);
	  g.fillRect(0, 0, size.width, size.height);
	 
	  int offset = 23;
	  if(frame.isClosable()) offset += 15;
	  if(frame.isMaximizable()) offset += 15;
	  if(frame.isIconifiable()) offset += 15;
	  
	  Texture texture = (Texture)UIManager.getDefaults().get("InternalFrame.titleTexture");
	  if(texture != null && ThemeManager.instance().probeSmallTextures()) texture.apply(new Rectangle(20, 0, getSize().width -offset, getSize().height), (Graphics2D)g, this);

	  if(isSelected) g.setColor(selectedTitleColor);
	  else g.setColor(notSelectedTitleColor);
	
	  FontMetrics fm = getFontMetrics(getFont());
	  String frameTitle = frame.getTitle();
	  int title_w = (frameTitle != null ? fm.stringWidth(frameTitle) +2 : 0) + (frame.getFrameIcon()!=null ? frame.getFrameIcon().getIconWidth() +2 : 0);
	
	  if(frame.getComponentOrientation()!=ComponentOrientation.LEFT_TO_RIGHT){
	     int ww = Math.min(size.width -offset, title_w -frame.getFrameIcon().getIconWidth() +2);
	     
	     g.fillRect(frame.getFrameIcon().getIconWidth() +2, 0, ww, size.height);
	     UIManager.getDefaults().getBorder("InternalFrame.titleBorder").paintBorder(this, g, frame.getFrameIcon().getIconWidth() +2, 0, ww, size.height);
	  }
	}


	protected void setButtonIcons(){
	  if(frame.isIcon()){
	     iconButton.setIcon(new FhSysIcon(FhSysButton.RESTORER));
	     maxButton.setIcon(new FhSysIcon(FhSysButton.MAXIMIZER));
	  }
	  else if(frame.isMaximum()){
	          iconButton.setIcon(new FhSysIcon(FhSysButton.MINIMIZER));
	          maxButton.setIcon(new FhSysIcon(FhSysButton.RESTORER));
	  }
	  else{
	       iconButton.setIcon(new FhSysIcon(((FhSysButton)iconButton).getType()));
	       maxButton.setIcon(new FhSysIcon(((FhSysButton)maxButton).getType()));
	  }
	  
	  closeButton.setIcon(new FhSysIcon(((FhSysButton)closeButton).getType()));
	}


    /**
     * @version test 1.0
     * @author Stefan H. Farr
     * This software is published under the terms of General Public License
     */
	public class FhInternalFrameTitlePaneLayout extends BasicInternalFrameTitlePane.TitlePaneLayout{
	
	    public Dimension minimumLayoutSize(Container c){
		  FhInternalFrameTitlePane pane = (FhInternalFrameTitlePane)c;
	
	      int width = 22;
	 
	      if(pane.getFrameFromAncestor().isClosable()) width += 15;
	      if(pane.getFrameFromAncestor().isMaximizable()) width += 15;
	      if(pane.getFrameFromAncestor().isIconifiable()) width += 15;
	
	      FontMetrics fm = getFontMetrics(pane.getFont());
	      String frameTitle = pane.getFrameFromAncestor().getTitle();
	      
	      int title_w = frameTitle != null ? fm.stringWidth(frameTitle) : 0;
	      int title_length = frameTitle != null ? frameTitle.length() : 0;
	
	      // Leave room for three characters in the title.
		  if(title_length > 3){
		     int subtitle_w = fm.stringWidth(frameTitle.substring(0, 3) + "...");
		     width += (title_w < subtitle_w) ? title_w : subtitle_w;
		  }
		  else width += title_w;
	
	      // Calculate height.
	      Icon icon = pane.getFrameFromAncestor().getFrameIcon();
	      int fontHeight = fm.getHeight();
	      fontHeight += 2;
	      int iconHeight = 0;
	      if(icon != null) iconHeight = Math.min(icon.getIconHeight(), 16);
	      
	      int height = Math.max(fontHeight, iconHeight);
	
	      Dimension dim = new Dimension(width, height);
	
	      if(pane.getBorder() != null){
	         Insets insets = pane.getBorder().getBorderInsets(c);
	         dim.height += insets.top + insets.bottom;
	         dim.width += insets.left + insets.right;
	      }
	 
	      return dim;
	    }
	
	
	    public void layoutContainer(Container c){
		  FhInternalFrameTitlePane pane = (FhInternalFrameTitlePane)c;
	
	      boolean leftToRight = pane.getFrameFromAncestor().getComponentOrientation()!=ComponentOrientation.LEFT_TO_RIGHT;
	            
		  int w = pane.getWidth(),
		      h = pane.getHeight(),
		      x,
		      buttonHeight = pane.getCloseButtonFromAncestor().getIcon().getIconHeight() +2;
	
	      Icon icon = pane.getFrameFromAncestor().getFrameIcon();
	      int iconHeight = 0;
	      if(icon != null) iconHeight += icon.getIconHeight();
	
	      x = (leftToRight) ? 0 : w - 13 - 2;
	      pane.getMenuBarFromAncestor().setBounds(x, 0, 16, 16);
	
	      x = (leftToRight) ? w - 13 - 2 : 2;
	            
		  if(pane.getFrameFromAncestor().isClosable()){
	         pane.getCloseButtonFromAncestor().setBounds(x, (h - buttonHeight)/2, 13, 13);
	         x += (leftToRight) ? -(13 + 2) : 13 + 2;
		  } 
	            
		  if(pane.getFrameFromAncestor().isMaximizable()){
		     pane.getMaxButtonFromAncestor().setBounds(x, (h - buttonHeight)/2, 13, 13);
			 x += (leftToRight) ? -(13 + 2) : 13 + 2;
		  }
	        
		  if(pane.getFrameFromAncestor().isIconifiable()) {
		     pane.getIconButtonFromAncestor().setBounds(x, (h - buttonHeight)/2, 13, 13);
		  } 
		}
	}
}
