
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * A simplified equivalent to "java.lang.reflect".
 */
public abstract class IClass {
    private static final boolean DEBUG = false;

    /**
     * Returns all the constructors declared by the class represented by the
     * type. If the class has a default constructor, it is included.
     * <p>
     * Returns an array with zero elements for an interface, array, primitive type or
     * "void".
     */
    public abstract IConstructor[] getDeclaredIConstructors();

    /**
     * Returns the methods of the class or interface (but not inherited
     * methods).<br>
     * Returns an empty array for an array, primitive type or "void".
     */
    public abstract IMethod[] getDeclaredIMethods();

    /**
     * Returns the fields of a class or interface (but not inherited
     * fields).<br>
     * Returns an empty array for an array, primitive type or "void".
     */
    public abstract IField[] getDeclaredIFields();

    /**
     * Returns the classes and interfaces declared as members of the class
     * (but not inherited classes and interfaces).<br>
     * Returns an empty array for an array, primitive type or "void".
     */
    public abstract IClass[] getDeclaredIClasses() throws Java.CompileException;

    /**
     * If this class is a member class, return the declaring class, otherwise return
     * <code>null</code>.
     */
    public abstract IClass getDeclaringIClass() throws Java.CompileException;

    /**
     * The following types have an "outer class":
     * <ul>
     *   <li>Anonymous classes declared in a non-static method of a class
     *   <li>Local classes declared in a non-static method of a class
     *   <li>Non-static member classes
     * </ul>
     */
    public abstract IClass getOuterIClass() throws Java.CompileException;

    /**
     * Returns the superclass of the class.<br>
     * Returns "null" for class "Object", interfaces, arrays, primitive types
     * and "void".
     */
    public abstract IClass getSuperclass() throws Java.CompileException;

    /**
     * Whether the class may be accessed from outside its package (JVMS 4.1 access_flags)
     */
    public abstract boolean isPublic();

    /**
     * Whether subclassing is allowed (JVMS 4.1 access_flags)
     * @return <code>true</code> if subclassing is prohibited
     */
    public abstract boolean isFinal();

    /**
     * Returns the interfaces implemented by the class.<br>
     * Returns the superinterfaces of the interface.<br>
     * Returns "Cloneable" and "Serializable" for arrays.<br>
     * Returns an empty array for primitive types and "void".
     */
    public abstract IClass[] getInterfaces() throws Java.CompileException;

    /**
     * Whether the class may be instantiated (JVMS 4.1 access_flags)
     * @return <code>true</code> if instantiation is prohibited
     */
    public abstract boolean isAbstract();

    /**
     * Returns the field descriptor for the type as defined by JVMS 4.3.2.
     */
    public abstract String getDescriptor();

    /**
     * Convenience method that determines the field descriptors of an array of {@link IClass}es.
     * @see #getDescriptor()
     */
    public static String[] getDescriptors(IClass[] iClasses) {
        String[] descriptors = new String[iClasses.length];
        for (int i = 0; i < iClasses.length; ++i) descriptors[i] = iClasses[i].getDescriptor();
        return descriptors;
    }

    /**
     * Returns "true" if this type represents an interface.
     */
    public abstract boolean isInterface();

    /**
     * Returns "true" if this type represents an array.
     */
    public abstract boolean isArray();

    /**
     * Returns "true" if this type represents a primitive type or "void".
     */
    public abstract boolean isPrimitive();

    /**
     * Returns "true" if this type represents "byte", "short", "int", "long",
     * "char", "float" or "double".
     */
    public abstract boolean isPrimitiveNumeric();

    /**
     * Returns the component type of the array.<br>
     * Returns "null" for classes, interfaces, primitive types and "void".
     */
    public abstract IClass getComponentType();

    /**
     * Returns a string representation for this object.
     */
    public String toString() { return Descriptor.toClassName(this.getDescriptor()); }

    /**
     * Determine if "this" is assignable from "that". This is true if "this"
     * is identical with "that", or if "this" is assignable from "that"'s
     * superclass (if any), or if "this" is assignable from any of the
     * interfaces which "that" implements.
     */
    public boolean isAssignableFrom(IClass that) throws Java.CompileException {

        // Identity conversion, JLS 5.1.1
        if (this == that) return true;

        // Widening primitive conversion, JLS 5.1.2
        if (Java.isWideningPrimitiveConvertible(that, this)) return true;

        // Widening reference conversion, JLS 5.1.4
        if (Java.isWideningReferenceConvertible(that, this)) return true;

        return false;
    }

    /**
     * Returns <code>true</code> if this class is an immediate or non-immediate
     * subclass of <code>that</code> class.
     */
    public boolean isSubclassOf(IClass that) throws Java.CompileException {
        for (IClass sc = this.getSuperclass(); sc != null; sc = sc.getSuperclass()) {
            if (sc == that) return true;
        }
        return false;
    }

    /**
     * If <code>this</code> represents a class: Return <code>true</code> if this class
     * directly or indirectly implements <code>that</code> interface.
     * <p>
     * If <code>this</code> represents an interface: Return <code>true</code> if this
     * interface directly or indirectly extends <code>that</code> interface.
     */
    public boolean implementsInterface(IClass that) throws Java.CompileException {
        for (IClass c = this; c != null; c = c.getSuperclass()) {
            IClass[] tis = c.getInterfaces();
            for (int i = 0; i < tis.length; ++i) {
                IClass ti = tis[i];
                if (ti == that || ti.implementsInterface(that)) return true;
            }
        }
        return false;
    }

    /**
     * Create an {@link IClass} that represents an array of the given component type.
     * @param componentType
     * @param objectType Required because the superclass of an array class is {@link Object} by definition
     */
    public static IClass createArrayIClass(final IClass componentType, final IClass objectType) {
        return new IClass() {
            public IClass.IConstructor[] getDeclaredIConstructors() { return new IClass.IConstructor[0]; }
            public IClass.IMethod[]      getDeclaredIMethods() { return new IClass.IMethod[0]; }
            public IClass.IField[]       getDeclaredIFields() { return new IClass.IField[0]; }
            public IClass[]              getDeclaredIClasses() { return new IClass[0]; }
            public IClass                getDeclaringIClass() { return null; }
            public IClass                getOuterIClass() { return null; }
            public IClass                getSuperclass() { return objectType; }
            public IClass[]              getInterfaces() { return new IClass[0]; }
            public String                getDescriptor() { return '[' + componentType.getDescriptor(); }
            public boolean               isPublic() { return componentType.isPublic(); }
            public boolean               isFinal() { return true; }
            public boolean               isInterface() { return false; }
            public boolean               isAbstract() { return false; }
            public boolean               isArray() { return true; }
            public boolean               isPrimitive() { return false; }
            public boolean               isPrimitiveNumeric() { return false; }
            public IClass                getComponentType() { return componentType; }

            public String toString() { return componentType.toString() + "[]"; }
        };
    }

    /**
     * If <code>optionalName</code> is <code>null</code>, find all {@link IClass}es visible in the
     * scope of the current class.
     * <p>
     * If <code>optionalName</code> is not <code>null</code>, find the member {@link IClass}es
     * that has the given name. If the name is ambiguous (i.e. if more than one superclass,
     * interface of enclosing type declares a type with that name), then the size of the
     * returned array is greater than one.
     * <p>
     * Examines superclasses, interfaces and enclosing type declarations.
     * @return an array of {@link IClass}es inunspecified order, possibly of length zero
     */
    IClass[] findMemberType(String optionalName) throws Java.CompileException {
        IClass[] res = (IClass[]) this.memberTypeCache.get(optionalName);
        if (res == null) {

            // Notice: A type may be added multiply to the result set because we are in its scope
            // multiply. E.g. the type is a member of a superclass AND a member of an enclosing type.
            Set s = new HashSet(); // IClass
            this.findMemberType(optionalName, s);
            res = s.isEmpty() ? IClass.ZERO_ICLASSES : (IClass[]) s.toArray(new IClass[s.size()]);
    
            this.memberTypeCache.put(optionalName, res);
        }

        return res;
    }
    private final Map memberTypeCache = new HashMap(); // String name => IClass[]
    private static final IClass[] ZERO_ICLASSES = new IClass[0];
    private void findMemberType(String optionalName, Collection result) throws Java.CompileException {

        // Search for a type with the given name in the current class.
        IClass[] memberTypes = this.getDeclaredIClasses();
        if (optionalName == null) {
            result.addAll(Arrays.asList(memberTypes));
        } else {
            String memberDescriptor = Descriptor.fromClassName(Descriptor.toClassName(this.getDescriptor()) + '$' + optionalName);
            for (int i = 0; i < memberTypes.length; ++i) {
                final IClass mt = memberTypes[i];
                if (mt.getDescriptor().equals(memberDescriptor)) {
                    result.add(mt);
                    return;
                } 
            }
        }
        
        // Examine superclass.
        {
            IClass superclass = this.getSuperclass();
            if (superclass != null) superclass.findMemberType(optionalName, result); 
        }
        
        // Examine interfaces.
        {
            IClass[] ifs = this.getInterfaces();
            for (int i = 0; i < ifs.length; ++i) ifs[i].findMemberType(optionalName, result);
        }

        // Examine enclosing type declarations.
        {
            IClass declaringIClass = this.getDeclaringIClass();
            IClass outerIClass = this.getOuterIClass();
            if (declaringIClass != null) {
                declaringIClass.findMemberType(optionalName, result);
            }
            if (outerIClass != null && outerIClass != declaringIClass) {
                outerIClass.findMemberType(optionalName, result);
            }
        }
    }

    public interface IMember {

        /**
         * @return One of {@link #PRIVATE}, {@link #PROTECTED},
         * {@link #PACKAGE} and {@link #PUBLIC}.
         */
        int getAccess();

        /**
         * Returns the {@link IClass} that declares this {@link IClass.IMember}.
         */
        IClass getDeclaringIClass();
    }

    /** Return value for {@link IClass.IMember#getAccess}. */
    public static final int PRIVATE   = 0;
    /** Return value for {@link IMember#getAccess}. */
    public static final int PROTECTED = 1;
    /** Return value for {@link IMember#getAccess}. */
    public static final int PACKAGE   = 2;
    /** Return value for {@link IMember#getAccess}. */
    public static final int PUBLIC    = 3;

    public abstract class IInvocable implements IMember {

        // Implement IMember.
        public abstract int getAccess();
        public IClass       getDeclaringIClass() { return IClass.this; }
        public abstract IClass[] getParameterTypes() throws Java.CompileException;
        public abstract String   getDescriptor() throws Java.CompileException;
        public abstract IClass[] getThrownExceptions() throws Java.CompileException;

        public boolean isMoreSpecificThan(IInvocable that) throws Java.CompileException {
            if (IClass.DEBUG) System.out.print("\"" + this + "\".isMoreSpecificThan(\"" + that + "\") => ");
            if (!that.getDeclaringIClass().isAssignableFrom(this.getDeclaringIClass())) {
                if (IClass.DEBUG) System.out.println("falsE");
                return false;
            }
            IClass[] thisParameterTypes = this.getParameterTypes();
            IClass[] thatParameterTypes = that.getParameterTypes();
            int i;
            for (i = 0; i < thisParameterTypes.length; ++i) {
                if (!thatParameterTypes[i].isAssignableFrom(thisParameterTypes[i])) {
                    if (IClass.DEBUG) System.out.println("false");
                    return false;
                }
            }
            if (IClass.DEBUG) System.out.println("true");
            return true;
        }
        public boolean isLessSpecificThan(IInvocable that) throws Java.CompileException {
            return that.isMoreSpecificThan(this);
        }
        public abstract String toString();
    }
    public abstract class IConstructor extends IInvocable {

        /**
         * Opposed to {@link java.lang.reflect.Constructor#getParameterTypes()}, the
         * return value of this method does not include the optionally leading "synthetic
         * parameters".
         */
        public abstract IClass[] getParameterTypes() throws Java.CompileException;

        /**
         * Opposed to {@link #getParameterTypes()}, the method descriptor returned by this
         * method does include the optionally leading synthetic parameters.
         */
        public String getDescriptor() throws Java.CompileException {
            return new MethodDescriptor(IClass.getDescriptors(this.getParameterTypes()), Descriptor.VOID).toString();
        }
        public String toString() {
            StringBuffer sb = new StringBuffer(this.getDeclaringIClass().toString());
            sb.append('(');
            try {
                IClass[] parameterTypes = this.getParameterTypes();
                for (int i = 0; i < parameterTypes.length; ++i) {
                    if (i > 0) sb.append(", ");
                    sb.append(parameterTypes[i].toString());
                }
            } catch (Java.CompileException ex) {
                sb.append("<invalid type>");
            }
            sb.append(')');
            return sb.toString();
        }
    }
    public abstract class IMethod extends IInvocable {
        public abstract boolean isStatic();
        public abstract boolean isAbstract();
        public abstract IClass  getReturnType() throws Java.CompileException;
        public abstract String  getName();
        public String getDescriptor() throws Java.CompileException {
            return new MethodDescriptor(
                IClass.getDescriptors(this.getParameterTypes()),
                getReturnType().getDescriptor()
            ).toString();
        }
        public String toString() {
            StringBuffer sb = new StringBuffer();
            try {
                sb.append(this.getReturnType().toString());
            } catch (Java.CompileException ex) {
                sb.append("<invalid type>");
            }
            sb.append(' ');
            sb.append(this.getDeclaringIClass().toString());
            sb.append('.');
            sb.append(this.getName());
            sb.append('(');
            try {
                IClass[] parameterTypes = this.getParameterTypes();
                for (int i = 0; i < parameterTypes.length; ++i) {
                    if (i > 0) sb.append(", ");
                    sb.append(parameterTypes[i].toString());
                }
            } catch (Java.CompileException ex) {
                sb.append("<invalid type>");
            }
            sb.append(')');
            return sb.toString();
        }
    }
    public abstract class IField implements IMember {

        // Implement IMember.
        public abstract int     getAccess();
        public IClass           getDeclaringIClass() { return IClass.this; }

        public abstract boolean isStatic();
        public abstract IClass  getType() throws Java.CompileException;
        public abstract String  getName();
        public String getDescriptor() throws Java.CompileException {
            return getType().getDescriptor();
        }
        public abstract Object  getConstantValue() throws Java.CompileException;
        public String toString() { return this.getName(); }
    }
}
