/*
 * Copyright (c) 2005, the JUNG Project and the Regents of the University 
 * of California
 * All rights reserved.
 *
 * This software is open-source under the BSD license; see either
 * "license.txt" or
 * http://jung.sourceforge.net/license.txt for a description.
 * Created on Mar 8, 2005
 *
 */
package edu.uci.ics.jung.visualization.control;

import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.geom.Point2D;

import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.transform.MutableTransformer;

/** 
 * ViewScalingGraphMouse applies a scaling transform to the View
 * of the graph. This causes all elements of the graph to grow
 * larger or smaller. ViewScalingGraphMouse, by default, is activated
 * by the MouseWheel when the control key is pressed. The control
 * key modifier can be overridden in the contstructor.
 * 
 * @author Tom Nelson
 */
public class ViewScalingGraphMousePlugin extends ScalingGraphMousePlugin {

	/**
	 * create an instance with default zoom in/out values
	 */
	public ViewScalingGraphMousePlugin() {
	    this(MouseEvent.CTRL_MASK, 1.1f, 0.9f);
	}
    
    /**
     * create an instance with passed modifiers
     * @param modifiers
     */
    public ViewScalingGraphMousePlugin(int modifiers) {
        this(modifiers, 1.1f, 0.9f);
    }
    
    /**
     * 
     * create an instance with passed zoom values and default
     * modifiers
     * @param in
     * @param out
     */
    public ViewScalingGraphMousePlugin(float in, float out) {
        this(MouseEvent.CTRL_MASK, in, out);
    }
	/**
	 * create an instance with passed modifiers and zoom in/out values
	 * @param modifiers the event modifiers to trigger the event
	 * @param in zoom in value
	 * @param out zoom out value
	 */
	public ViewScalingGraphMousePlugin(int modifiers, float in, float out) {
	    super(modifiers);
	    this.in = in;
	    this.out = out;
	}
    
	/**
	 * zoom the display in or out, depending on the direction of the
	 * mouse wheel motion.
	 */
    public void mouseWheelMoved(MouseWheelEvent e) {
        boolean accepted = checkModifiers(e);
        if(accepted == true) {
            VisualizationViewer vv = (VisualizationViewer)e.getSource();
            Point2D mouse = e.getPoint();
            Point2D center = vv.getCenter();
            MutableTransformer viewTransformer = vv.getViewTransformer();
            int amount = e.getWheelRotation();
            if(zoomAtMouse) {
                if(amount > 0) {
                    viewTransformer.scale(in, in, mouse);
                } else if(amount < 0) {
                    viewTransformer.scale(out, out, mouse);
                }
            } else {
                if(amount > 0) {
                    viewTransformer.scale(in, in, center);
                } else if(amount < 0) {
                    viewTransformer.scale(out, out, center);
                }
            }
            e.consume();
            vv.repaint();
        }
    }
}
