package phelps.awt;

import java.awt.Font;
import java.awt.font.*;
import java.awt.GraphicsEnvironment;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.List;



/**
	Font-related utilities.
<!--
	Useful for both {@link java.awt.Font} and {@link phelps.awt.fonts.NFont}.
-->

	<ul>
	<li>{@link #getAvailableFamily(String,int)} tries hard to find good substitute family
	<li>{@link #createFont(String, String, float, int)}
	</ul>

	@version $Revision: 1.8 $ $Date: 2003/10/05 18:34:12 $
*/
public class Fonts {
  static final boolean DEBUG = !false && multivalent.Multivalent.DEVEL;

  /** Font flags in font dictionary.  Flags are identical to Adobe defintiions. */
  public static final int FLAG_NONE=0,
	FLAG_FIXEDPITCH=1, 
	FLAG_SERIF=1<<1, 
	/** Not exactly standard Latin, though could be close. */
	FLAG_SYMBOLIC=1<<2, 
	FLAG_SCRIPT=1<<3, 
	/** Standard Latin. */
	FLAG_NONSYMBOLIC=1<<5,
	FLAG_ITALIC=1<<6, 
	FLAG_ALLCAP=1<<16, 
	FLAG_SMALLCAP=1<<17, 
	FLAG_FORCEBOLD=1<<18,
	FLAG_DEFAULT = FLAG_SERIF | FLAG_NONSYMBOLIC;

/*
If Java adds dynamic load of Type 1, maybe package core 14 in JAR with following Ghostscript fonts:
* PDF name              Ghostscript font    Ghostscript font name
t1TimesRoman:           n021003l.pfb        Nimbus Roman No9 L
t1TimesItalic:          n021023l.pfb
t1TimesBold:            n021004l.pfb
t1TimesBoldItalic:      n021024l.pfb
t1Helvetica:            n019003l.pfb        Nimbus Sans L
t1HelveticaOblique:     n019023l.pfb
t1HelveticaBold:        n019004l.pfb
t1HelveticaBoldOblique: n019024l.pfb
t1Courier:              n022003l.pfb        Nimbus Mono L
t1CourierOblique:       n022023l.pfb
t1CourierBold:          n022004l.pfb
t1CourierBoldOblique:   n022024l.pfb
t1Symbol:               s050000l.pfb        Standard Symbols L
t1ZapfDingbats:         d050000l.pfb        Chancery L
*/


  private static final Font BASEFONT = new Font("Times", Font.PLAIN, 12);

  // maybe refetch periodically in case updated, assuming Java itself does this or doesn't cache
  /** Shared, one-time result of {@link java.awt.GraphicsEnvironment#getAvailableFontFamilyNames()}. */
  static final String[] FAMILIES = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();	// includes Java guaranteed/built-in

  /** {@link #FAMILIES}, normalized to lowercase and no spaces. */
  private static final String[] NORMALFAMILIES = new String[FAMILIES.length];

  private static Map<String,String> f2gs_ = new HashMap<String,String>();

  /** Font family equivalence classes.  Font at array index 0 is canonical name. */
  private static final Map<String,String[]> f2pdf_ = new HashMap<String,String[]>();

  //private File TeXdir

  static {
	Arrays.sort(FAMILIES, String.CASE_INSENSITIVE_ORDER);


	for (int i=0,imax=FAMILIES.length; i<imax; i++) NORMALFAMILIES[i] = normalizeFamily(FAMILIES[i]);
	//Arrays.sort(NORMALFAMILIES); => NO: space remove may have changed sort order, but must be parallel to NORMAL! -- rare, but should sort and use hash
	//int inx = Arrays.binarySearch(FAMILIES, "Times"); FAMILIES[inx] = NORMALFAMILIES[inx] = "XXX";	// test equivalence classes


	String[] gs = {
	"Century Schoolbook L","NewCenturySchlbk",  "Dingbats","ZapfDingbats",
	"Nimbus Mono L","Courier",  "Nimbus Roman No9 L","Times","Nimbus Roman No9 L","Times-Roman",  "Nimbus Sans L","Helvetica",
	"Standard Symbols L","Symbol",
	"URW Bookman L","Bookman",
	"URW Chancery L","ZapfChancery",  "URW Gothic L","AvantGarde",  "URW Palladio L","Palatino",
	"Nimbus Roman No9 L Medium","Times-Bold",  "Nimbus Roman No9 L Medium Italic","Times-BoldItalic", //=> don't show up in getAvailableFontFamilyNames
	};
	if (searchAvailable("URW Bookman L")==-1) f2gs_ = null;	// Ghostscript fonts not installed
	else for (int i=0,imax=gs.length; i<imax; i+=2) f2gs_.put(gs[i+1].toLowerCase(), gs[i]);
if (DEBUG) System.out.println("URW? "+(f2gs_!=null));

	String[][] eq = {	// PDF Reference 1.4, p.795.  ordered to increasing specialization
	{ "Times-Roman",  /*unofficial:*/"Times", /*unofficial:*/"Times New Roman","TimesNewRoman",  "TimesNewRomanPS",  "TimesNewRomanPSMT" }, 
	{ "Times-Bold",  "TimesNewRoman,Bold","TimesNewRoman-Bold",  "TimesNewRomanPS-Bold",  "TimesNewRomanPS-BoldMT" },
	{ "Times-Italic", "TimesNewRoman,Italic","TimesNewRoman-Italic",  "TimesNewRomanPS-Italic",  "TimesNewRomanPS-ItalicMT" },
	{ "Times-BoldItalic",  "TimesNewRoman,BoldItalic","TimesNewRoman-BoldItalic",  "TimesNewRomanPS-BoldItalic",  "TimesNewRomanPS-BoldItalicMT" },
	{ "Helvetica",  "Arial",  "ArialMT" },
	{ "Helvetica-Bold","Helvetica,Bold",  "Arial,Bold","Arial-Bold",  "Arial-BoldMT" },
	{ "Helvetica-Oblique", "Helvetica,Italic","Helvetica-Italic",  "Arial,Italic","Arial-Italic",  "Arial-ItalicMT" },
	{ "Helvetica-BoldOblique", "Helvetica,BoldItalic","Helvetica-BoldItalic",  "Arial,BoldItalic","Arial-BoldItalic",  "Arial-BoldItalicMT" },
	{ "Courier",  "CourierNew",  "CourierNewPSMT" },
	{ "Courier-Bold","Courier,Bold",  "CourierNew,Bold","CourierNew-Bold",  "CourierNewPS-BoldMT" },
	{ "Courier-Oblique",  "Courier,Italic", "CourierNew-Italic","CourierNew,Italic",  "CourierNewPS-ItalicMT" },
	{ "Courier-BoldOblique", "Courier,BoldItalic",  "CourierNew-BoldItalic","CourierNew,BoldItalic",  "CourierNewPS-BoldItalicMT" },
	{ "Symbol" }, 
	{ "ZapfDingbats" /*"Monotype Sorts",?*/ /*"Wingdings",--different characters*/ }
	};
	for (int i=0,imax=eq.length; i<imax; i++) {
		String[] q = eq[i];
		for  (int j=0,jmax=q.length; j<jmax; j++) f2pdf_.put(q[j], q);
	}
  }


  /** Remove spaces and transform to all lower case. */
  private static String normalizeFamily(String s) {
	StringBuffer sb = new StringBuffer(s.length());
	for (int j=0,jmax=s.length(); j<jmax; j++) { char ch = s.charAt(j); if (!Character.isWhitespace(ch)) sb.append(ch); }
	if (sb.length() < s.length()) s = sb.toString();
	return s.toLowerCase();
  }

  private static int searchAvailable(String family) {
	int inx = Arrays.binarySearch(FAMILIES, family);
	return inx>=0? inx: -1;
  }

  private static int searchURW(String family) {
	if (f2gs_==null) return -1;
	String gs = f2gs_.get(family.toLowerCase());
	// name like "Nimbus Roman No9 L Medium" masked by family "Nimbus Roman No9 L" [no "Medium"], so check that wouldn't fail to logical name
	//if (gs!=null && inx<0 && family.indexOf('-')!=-1 && Character.isUpperCase(new java.awt.Font(gs, java.awt.Font.PLAIN, 12).getPSName().charAt(0))) return gs;
	//if (inx>=0) System.out.println("   "+family+" => Ghostscript "+gs);}
//System.out.println("gs? "+lcfam+" => "+gs+", inx="+inx+" => "+new java.awt.Font(gs, java.awt.Font.PLAIN, 12).getPSName());
	return gs!=null? searchAvailable(gs): -1;
  }

  private static int searchNormal(String family) {
	// if slow, then have private sorted to see if any hit, then march across array to find correct index
	for (int i=0,imax=NORMALFAMILIES.length; i<imax; i++) if (NORMALFAMILIES[i].equals(family)) return i;
	return -1;
  }

  /** Search kpathsea path for TeX font. */
  private static int searchTeX(String family) {
	//if (texpath == null) return -1;
	family = family.toLowerCase();
	return -1;
  }


  public static List<String> getAvailableFamilies() { return Arrays.asList(FAMILIES); }

  /** Give alternative (or canonical) name for core font, return canonical name.  Returns null if not a cononical or alternative name. */
  public static String getPDFCanonical(String family) {
	String[] q = f2pdf_.get(family);
	return q!=null? q[0]: null;
  }

  /** Sets root directory of TeX kpathsea fonts. 
  public static void setTEXMF(File dir) {
  }*/


  /**
	Given a family name, return closest font family available as {@link java.awt.Font}.

	<p>Sequence to choose font:
	<ol>
	<li>exact font family name as given
	<li>URW/Ghostscript facsimile, if installed
	<li>(when Java supports dynamic loading of Type 1, search kpathsea for TeX font)
	<li>name normalization such as removing spaces ("Times New Roman" &rArr; "TimesNewRoman")
	<li>name without style information ("Times-Bold" or "Arial,BoldItalic"), Ghostscript facsimile
	<li>family mapped to core PDF 14 family
	<li>renaming by stripping trailing caps ("ArialMT" &rArr; "Arial")
	<li>family with similar properties to <var>flags</var>
	</ol>

	@return null iff no close match to <var>family</var> and <var>flags</var> set to -1
  */
  public static String getAvailableFamily(String family, int flags) {
	assert family!=null;
	family = family.trim();
	String fam = family;
	int inx = -1;


	// 0. fixes
	// replace lousy Microsoft Symbol font with Ghostscript's, if possible
	if ("Symbol".equals(family) && java.io.File.separatorChar=='\\') inx = searchAvailable("Standard Symbols L");


	// 1. exact
	// 1a. straight
	if (inx<0) inx = searchAvailable(family);
    // 1b. Ghostscript facsimile
	if (inx<0) inx = searchURW(family);
	// 1c. Tex
	// when Java supports dynamic loading of Type 1...
	//if (inx<0) inx = searchTeX(family);

	// 2. normalize
	// 2a. space + lowercase
	if (inx<0) {
		fam = normalizeFamily(family);
		inx = searchNormal(fam);
		if (inx<0) inx = searchURW(fam);
//System.out.println("trying normalized |"+fam+"| = "+inx);
	}
	// 2b. isolate family from bold/italic/bolditalic ("Times-Bold", "Arial,BoldItalic")
	if (inx<0) {
		fam = family;
		int x; if ((x=fam.indexOf(',')) !=-1) fam=fam.substring(0,x); if ((x=fam.indexOf('-')) !=-1) fam=fam.substring(0,x); // also '+' used in embedded, but caller responsibility to strip out before
		inx = searchAvailable(fam);
	}
	// 2c. space + lowercase on isolated family
	if (inx<0) {
		fam = normalizeFamily(fam);
		inx = searchNormal(fam);
		if (inx<0) inx = searchURW(fam);
//System.out.println("trying normalized |"+fam+"| = "+inx);
	}

	// 3. equivalence class
	if (inx<0) {
		String[] q = f2pdf_.get(family);
		if (q!=null) {
			int posn=-1; for (int i=0,imax=q.length; i<imax; i++) if (family.equals(q[i])) { posn=i; break; }  assert posn!=-1: family;
			// available, URW, normalize on each in class
			for (int i=0,imax=q.length; i<imax && inx<0; i++) {	// backwards from match to increasing generality, but also wraparound just in case
				fam = q[posn]; posn = posn>0? posn-1: imax-1;
				inx = searchAvailable(fam);
//System.out.println("  eq: "+fam+"=="+inx);
				if (inx<0) inx = searchURW(fam);
				if (inx<0) {
					int x; if ((x=fam.indexOf(',')) !=-1) fam=fam.substring(0,x); if ((x=fam.indexOf('-')) !=-1) fam=fam.substring(0,x);
					inx = searchAvailable(fam);
					if (inx<0) inx = searchURW(fam);
//System.out.println("searchURW for "+fam+" = "+inx);
				}
				//if (inx<0) inx = searchNormal(normalizeFamily(fam)); => no spaces anyhow, except for Time New Roman
			}
		}
	}

	// 4. destructive renaming -- strip off caps at end of name ("ArialMT"=>"Arial", "TimesNewRomanPSMT"=>"Times New Roman" ... "Machine ITC TT" => "Machine"?)
	if (inx<0) {
		fam = family;
		int x; if ((x = fam.indexOf(',')) !=-1) fam=fam.substring(0,x); if ((x = fam.indexOf('-')) !=-1) fam=fam.substring(0,x);
		int last=fam.length()-1;
		if (Character.isUpperCase(fam.charAt(last))) {
			for (int i=last; i>0; i--) if (!Character.isUpperCase(fam.charAt(i)) /*&& !Character.isWhitespace(fam.CharAt(i))*/) {
				fam = normalizeFamily(fam.substring(0,i+1));
				inx = searchNormal(fam);
				if (inx<0) inx = searchURW(fam);
				break;
			}
		}
	}
	// 4b. strip off foundary: "Apple-Light" => "Garamond"
	if (inx<0) {
		//if (fam.startsWith("apple")) "adobecorpid-" "ms"
	}

	// 5. partial match => bad match on "Bodoni-BoldCondensed" => "Bodoni Ornaments ITC TT"
	if (inx<0 && false) {
		for (int i=0,imax=NORMALFAMILIES.length; i<imax; i++) {
			if (NORMALFAMILIES[i].startsWith(fam)) { inx = i; break; }
		}
	}

	// 6. special case
	if (inx<0 && family.startsWith("Lucida")) inx = searchAvailable("Lucida");	// guaranteed font

	// 7. based on flags
	if (inx<0 && flags!=-1) {	
		if (FLAG_NONE==flags) flags = // guess some flags by matching with known families
			family.startsWith("Courier")? FLAG_FIXEDPITCH:
			family.startsWith("Helvetica") || family.startsWith("Myriad")? FLAG_NONE/*FLAG_SERIF==0*/:
			/*family.startsWith("Times") || family.startsWith("Minion")?*/ FLAG_SERIF;

		fam = getAvailableFamily(flags);
		inx = searchAvailable(fam); assert inx!=-1: fam;	// translate back to inx
	}


	String available = inx>=0? FAMILIES[inx]: /*DEFAULTFONT?*/null;
if (DEBUG) System.out.println("\t"+family+" as "+fam+ " => "+available);
	return available;
  }

  private static String getAvailableFamily(int flags) {
	String fam = null;

if (DEBUG) System.out.print("\tflags = "+Integer.toBinaryString(flags));
	// guarenteed Java logical fonts: Serif, SansSerif, Monospaced, Dialog, and DialogInput
	if ((FLAG_FIXEDPITCH&flags)!=0) {
		fam = getAvailableFamily("Courier", -1);
		if (fam==null) fam = "Monospaced";
	} else if ((FLAG_SERIF&flags)!=0) {
		fam = getAvailableFamily("Times", -1);
		if (fam==null) fam = "Serif";
	//} else if ((FLAG_SCRIPT&flags)!=0) fam = getAvailableFamily("?", -1):
	//} else if ((FLAG_ALLCAP&flags)!=0) fam = getAvailableFamily("?", -1):
	//} else if ((FLAG_SMALLCAP&flags)!=0) fam = getAvailableFamily("?", -1):
	} else { assert (FLAG_SERIF&flags)==0;
		fam = getAvailableFamily("Helvetica", -1);
		//if (fam==null) fam = "Microsoft Sans Serif";	// maybe
		if (fam==null) fam = "SansSerif";
	}
	// italic and forcebold refer to style, and symbolic and nonsymbolic refer to encoding

	assert fam != null;
	//if (fam==null) fam = "Lucida";	// only font guaranteed, until can bundle core 14 in JAR

	return fam;
  }

  /**
	A more flexible version of {@link Font#Font(String, int, int)} that tries harder to find a good substitute
	by relying on {@link #getAvailableFamily(String,int)}.

	@return Font (never <code>null</code>) that best matches desired attributes.
  */
  public static Font createFont(String family, float size, int flags) {
	String fam = family; int inx; boolean fstyled = false;
	if ((inx = fam.indexOf(',')) !=-1) { fam=fam.substring(0,inx); fstyled=true; }	// "Arial,BoldItalic"
	if ((inx = fam.indexOf('-')) !=-1) { fam=fam.substring(0,inx); fstyled=true; }	// "Times-Bold"
	//if ((inx = fam.indexOf('+')) !=-1) fam=fam.substring(inx+1);    // "/OAJJEN+LucidaSansTypewriter-Bd" - embedded name
//if (DEBUG) System.out.print(family+"/"+fam+" => ");
	String lc = family.toLowerCase();
	Float posture = (FLAG_ITALIC&flags)!=0 || lc.indexOf("italic")!=-1 || lc.indexOf("oblique")!=-1? TextAttribute.POSTURE_OBLIQUE: 
		TextAttribute.POSTURE_REGULAR;
	Float weight = 
		lc.indexOf("light")!=-1? TextAttribute.WEIGHT_LIGHT: 
		// normal
		lc.indexOf("demi")!=-1? TextAttribute.WEIGHT_DEMIBOLD: 
		// bold
		lc.indexOf("heavy")!=-1? TextAttribute.WEIGHT_HEAVY: 
		lc.indexOf("black")!=-1? TextAttribute.WEIGHT_ULTRABOLD: 
		(FLAG_FORCEBOLD&flags)!=0/*not really*/ || lc.indexOf("bold")!=-1? TextAttribute.WEIGHT_BOLD: // at end because "bold" could match too much and mask
		TextAttribute.WEIGHT_MEDIUM;
	// Java seems not to be able to find weights other than MEDIUM and BOLD, at least on OS X
	weight = weight.floatValue() <= TextAttribute.WEIGHT_MEDIUM.floatValue()? TextAttribute.WEIGHT_MEDIUM: TextAttribute.WEIGHT_BOLD;

	String available = getAvailableFamily(family, flags);
	// special cases
	//if (fstyled && family.equals(available)) posture = weight = null;
	/*if (fTeX) {
		map.put(TextAttribute.SIZE, new Float(pointsize * ppi_ / 72f));
		map.put(TextAttribute.POSTURE, TextAttribute.POSTURE_REGULAR); //=> lame TeX
		map.put(TextAttribute.WEIGHT, TextAttribute.WEIGHT_REGULAR); //=> lame TeX
	}*/

	Map<TextAttribute,Object> map = new HashMap<TextAttribute,Object>(5);
	map.put(TextAttribute.FAMILY, available);
	map.put(TextAttribute.SIZE, new Float(size));   // don't scale by ppi/72.0 !
	map.put(TextAttribute.POSTURE, posture);
	map.put(TextAttribute.WEIGHT, weight);

//if (DEBUG && !fam.equals(newfont.getFamily())) System.out.println(match+", flags="+flags+", substituted font: "+fam+" => "+newfont.getName()+"/"+newfont.getPSName());
	return BASEFONT.deriveFont(map);
  }
}
