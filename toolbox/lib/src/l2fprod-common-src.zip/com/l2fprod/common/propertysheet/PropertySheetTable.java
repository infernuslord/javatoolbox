/** ===================================================================
 *
 * @PROJECT.FULLNAME@ @VERSION@ License.
 *
 * Copyright (c) @YEAR@ L2FProd.com.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by L2FProd.com
 *        (http://www.L2FProd.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "@PROJECT.FULLNAME@", "@PROJECT.SHORTNAME@" and "L2FProd.com" must not
 *    be used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact info@L2FProd.com.
 *
 * 5. Products derived from this software may not be called "@PROJECT.SHORTNAME@"
 *    nor may "@PROJECT.SHORTNAME@" appear in their names without prior written
 *    permission of L2FProd.com.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL L2FPROD.COM OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package com.l2fprod.common.propertysheet;

import com.l2fprod.common.swing.HeaderlessColumnResizer;
import com.l2fprod.common.swing.renderer.BooleanCellRenderer;
import com.l2fprod.common.swing.renderer.ColorCellRenderer;
import com.l2fprod.common.swing.renderer.DefaultCellRenderer;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyEditor;

import javax.swing.Icon;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

/**
 * PropertySheetTable. <br>
 *  
 */
public class PropertySheetTable extends JTable {

  private static TableCellRenderer categoryRenderer = new CategoryRenderer();
  private static TableCellRenderer propertyRenderer = new PropertyRenderer();
  private static int HOTSPOT_SIZE = 18;

  private PropertyEditorRegistry registry;

  public PropertySheetTable() {
    this(new PropertySheetTableModel());
  }

  public PropertySheetTable(PropertySheetTableModel dm) {
    super(dm);
    addMouseListener(new CategoryVisibilityToggle());

    setGridColor(UIManager.getColor("Panel.background"));

    // select only one property at a time
    getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

    // hide the table header, we do not need it
    Dimension nullSize = new Dimension(0, 0);
    getTableHeader().setPreferredSize(nullSize);
    getTableHeader().setMinimumSize(nullSize);
    getTableHeader().setMaximumSize(nullSize);
    getTableHeader().setVisible(false);

    // table header not being visible, make sure we can still resize the
    // columns
    new HeaderlessColumnResizer(this);

    setEditorRegistry(new PropertyEditorRegistry());

    // use the default renderer for Object and all primitives
    DefaultCellRenderer renderer = new DefaultCellRenderer();
    renderer.setShowOddAndEvenRows(false);

    setDefaultRenderer(Object.class, renderer);
    setDefaultRenderer(Color.class, new ColorCellRenderer());
    setDefaultRenderer(boolean.class, new BooleanCellRenderer());
    setDefaultRenderer(byte.class, renderer);
    setDefaultRenderer(char.class, renderer);
    setDefaultRenderer(double.class, renderer);
    setDefaultRenderer(float.class, renderer);
    setDefaultRenderer(int.class, renderer);
    setDefaultRenderer(long.class, renderer);
    setDefaultRenderer(short.class, renderer);
  }

  public final void setEditorRegistry(PropertyEditorRegistry registry) {
    this.registry = registry;
  }

  public final PropertyEditorRegistry getEditorRegistry() {
    return registry;
  }

  public final boolean isCellEditable(int row, int column) {
    if (column == 0) {
      return false;
    }

    Object o =
      ((PropertySheetTableModel)getModel()).getPropertySheetElement(row);
    if (o instanceof Property) {
      return ((Property)o).isEditable();
    } else {
      return false;
    }
  }

  /**
   * Gets the CellEditor for the given row and column. It uses the editor
   * registry to find a suitable editor for the property.
   */
  public final TableCellEditor getCellEditor(int row, int column) {
    if (column == 0) {
      return null;
    }

    Object o =
      ((PropertySheetTableModel)getModel()).getPropertySheetElement(row);
    if (o instanceof Property) {
      Property prop = (Property)o;
      PropertyEditor editor = getEditorRegistry().getEditor(prop);
      return new CellEditorAdapter(editor);
    } else {
      return null;
    }
  }

  /**
   * Gets the cell renderer for the given row and column. It overrides the
   * default behaviour to return custom renderers for "Category" rows, for
   * "Property" columns. For the cell containing the value of the property, it
   * calls {@link #getDefaultCellRenderer(java.lang.Class)}with the type of
   * the property.
   */
  public TableCellRenderer getCellRenderer(int row, int column) {
    Object o =
      ((PropertySheetTableModel)getModel()).getPropertySheetElement(row);
    if (o instanceof PropertySheetTableModel.Category) {
      return categoryRenderer;
    } else if (column == 0) {
      return propertyRenderer;
    } else if (column == 1) {
      Property property = (Property)o;
      TableCellRenderer renderer = getDefaultRenderer(property.getType());
      if (renderer == null) {
        if (property.getType() != null
          && !Object.class.equals(property.getType())
          && property.getType().getSuperclass() != null) {
          renderer = getDefaultRenderer(property.getType().getSuperclass());
        } else {
          renderer = getDefaultRenderer(Object.class);         
        }
      }
      return new WrappedRenderer(renderer);
    } else {
      return super.getCellRenderer(row, column);
    }
  }

  public final PropertySheetTableModel getSheetModel() {
    return (PropertySheetTableModel)getModel();
  }

  private static class CategoryVisibilityToggle extends MouseAdapter {
    public void mouseReleased(MouseEvent event) {
      // did we click on a Category?
      PropertySheetTable table = (PropertySheetTable)event.getComponent();
      int row = table.rowAtPoint(event.getPoint());
      int column = table.columnAtPoint(event.getPoint());
      if (row != -1 && column == 0 && event.getX() < HOTSPOT_SIZE) {
        Object o = table.getSheetModel().getPropertySheetElement(row);
        if (o instanceof PropertySheetTableModel.Category) {
          ((PropertySheetTableModel.Category)o).toggle();
        }
      }
    }
  }

  private static class CellBorder implements Border {

    private Color background;
    private boolean showToggle;
    private boolean toggleState;

    private Icon expandedIcon = (Icon)UIManager.get("Tree.expandedIcon");
    private Icon collapsedIcon = (Icon)UIManager.get("Tree.collapsedIcon");

    public CellBorder(Color background) {
      this.background = background;
    }
    public Insets getBorderInsets(Component c) {
      return new Insets(1, HOTSPOT_SIZE, 1, 1);
    }
    public void paintBorder(
      Component c,
      Graphics g,
      int x,
      int y,
      int width,
      int height) {
      Color oldColor = g.getColor();
      g.setColor(background);
      g.fillRect(x, y, x + HOTSPOT_SIZE - 2, y + height);
      g.setColor(oldColor);

      if (showToggle) {
        if (toggleState) {
          expandedIcon.paintIcon(
            c,
            g,
            x + (HOTSPOT_SIZE - 2 - expandedIcon.getIconWidth()) / 2,
            y + (height - expandedIcon.getIconHeight()) / 2);
        } else {
          collapsedIcon.paintIcon(
            c,
            g,
            x + (HOTSPOT_SIZE - 2 - collapsedIcon.getIconWidth()) / 2,
            y + (height - collapsedIcon.getIconHeight()) / 2);
        }
      }
    }
    public boolean isBorderOpaque() {
      return true;
    }
    public void setToggle(boolean state) {
      toggleState = state;
    }
    public void setToggleVisible(boolean visible) {
      showToggle = visible;
    }
  }

  private static class PropertyRenderer extends DefaultTableCellRenderer {
    public Component getTableCellRendererComponent(
      JTable table,
      Object value,
      boolean isSelected,
      boolean hasFocus,
      int row,
      int column) {
      super.getTableCellRendererComponent(
        table,
        value,
        isSelected,
        hasFocus,
        row,
        column);
      Property property = (Property)value;
      setText(property.getDisplayName());
      if (!isSelected) {
        setEnabled(property.isEditable());
      } else {
        setEnabled(true);
      }
      setBorder(new CellBorder(UIManager.getColor("Panel.background")));
      return this;
    }
  }

  private static class WrappedRenderer implements TableCellRenderer {
    private TableCellRenderer renderer;
    public WrappedRenderer(TableCellRenderer renderer) {
      this.renderer = renderer;
    }
    public Component getTableCellRendererComponent(
      JTable table,
      Object value,
      boolean isSelected,
      boolean hasFocus,
      int row,
      int column) {
      return renderer.getTableCellRendererComponent(
        table,
        value,
        false,
        false,
        row,
        column);
    }
  }

  private static class CategoryRenderer extends DefaultTableCellRenderer {

    private Color background;
    private Color foreground;

    public CategoryRenderer() {
      this(
        UIManager.getColor("Panel.background"),
        UIManager.getColor("Panel.background").darker());
    }

    public CategoryRenderer(Color background, Color foreground) {
      setBorder(new CellBorder(UIManager.getColor("Panel.background")));
      this.background = background;
      this.foreground = foreground;
      setFont(getFont().deriveFont(Font.BOLD));
    }

    public Component getTableCellRendererComponent(
      JTable table,
      Object value,
      boolean isSelected,
      boolean hasFocus,
      int row,
      int column) {

      PropertySheetTableModel.Category category =
        (PropertySheetTableModel.Category)value;

      setBackground(background);
      setForeground(foreground);

      if (column == 0) {
        ((CellBorder)getBorder()).setToggle(category.isVisible());
        ((CellBorder)getBorder()).setToggleVisible(true);
        setText(category.getName());
      } else {
        ((CellBorder)getBorder()).setToggleVisible(false);
        setText("");
      }
      return this;
    }
  }

}
