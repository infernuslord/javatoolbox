/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh.theme;

import java.awt.Color;
import java.util.Collection;
import java.util.Vector;

import com.shfarr.ui.GraphicsUtils;


public class ColorPalette extends Palette{
    public static final Color BLANK = new Color(0, 0, 0, 0);
    
    protected Color[] colors;
    
    public ColorPalette(){
    }
    
//    ColorPalette(Theme theme) throws Error{
//        this();
//    }
    
    public ColorPalette derivePalette(Color base){
        ColorPalette derived = new ColorPalette();
        
        derived.putAll(this);
        derived.registerColor("base", base);
        
        return derived;
    }
    
    public Color getColor(int index){
        if(colors == null){
            colors = new Color[21];
            createVariations(this, getColor("base"));
        }
        
        index = 10 +index;
        
        if(index < 0 || index > 20) return null;
        
        return colors[index];
    }
    
    public Color getColor(String name){
        if(name == null) new Throwable().printStackTrace();

        try{
            return getColor(Integer.parseInt(name));        	
        }
        catch(Exception e){
            if(name.equals("x") || name.equals("!x")) return BLANK;
            return (Color)get(name.startsWith("!") ? name.substring(1) : name);
        }
    }
    
    public Collection list(){
        if(colors == null) getColor(0);
        
        Vector v = new Vector();
        
        for(int i = 0; i < colors.length; i++) v.add("" + (i -10));
        v.addAll(keySet());
                
        return v;
    } 
    
    public boolean registerColor(String name, Color color){
        if("".equals(name)) return false;
        if(name.equals("base")) colors = null;
        if(color != null || !"base".equals(name) && !"negative".equals(name) && !"affirmative".equals(name)) put(name, color);
                
        return true;
    }
    
    protected static void createVariations(ColorPalette colorPalette, Color baseColor){
        double factor = 1 + ThemeManager.instance().getPreferences().getContrast()/100f;
        
        colorPalette.colors[ 0] = createColorVariation(baseColor, -130, factor);
        colorPalette.colors[ 1] = createColorVariation(baseColor, -120, factor);
        colorPalette.colors[ 2] = createColorVariation(baseColor, -100, factor);
        colorPalette.colors[ 3] = createColorVariation(baseColor, -90, factor);
        colorPalette.colors[ 4] = createColorVariation(baseColor, -75, factor);
        colorPalette.colors[ 5] = createColorVariation(baseColor, -65, factor); //[-3]
        colorPalette.colors[ 6] = createColorVariation(baseColor, -50, factor);
        colorPalette.colors[ 7] = createColorVariation(baseColor, -40, factor);
        colorPalette.colors[ 8] = createColorVariation(baseColor, -35, factor);
        colorPalette.colors[ 9] = createColorVariation(baseColor, -20, factor); //[-2]
        colorPalette.colors[10] = baseColor; // equilibrium point
        colorPalette.colors[11] = createColorVariation(baseColor, 20, factor); 
        colorPalette.colors[12] = createColorVariation(baseColor, 40, factor);
        colorPalette.colors[13] = createColorVariation(baseColor, 60, factor);
        colorPalette.colors[14] = createColorVariation(baseColor, 75, factor);
        colorPalette.colors[15] = createColorVariation(baseColor, 90, factor); // bg
        colorPalette.colors[16] = createColorVariation(baseColor, 100, factor);
        colorPalette.colors[17] = createColorVariation(baseColor, 120, factor);
        colorPalette.colors[18] = createColorVariation(baseColor, 125, factor);
        colorPalette.colors[19] = createColorVariation(baseColor, 130, factor);
        colorPalette.colors[20] = createColorVariation(baseColor, 160, factor);
    }
    
    protected static Color createColorVariation(Color base, int amount, double factor){
        double red = base.getRed() +amount*factor;
        double green = base.getGreen() +amount*factor;
        double blue = base.getBlue() +amount*factor;

        if(red > 255) red = 255;
        if(green > 255) green = 255;
        if(blue > 255) blue = 255;

        if(red < 0) red = 0;
        if(green < 0) green = 0;
        if(blue < 0) blue = 0;

        if(factor < 1){
            red += (255 -red)*((1 -factor));
            green += (255 -green)*((1 -factor));
            blue += (255 -blue)*((1 -factor));
        }
        
        double med = (red +green +blue)/3.0;
        double d = Math.min(med, 255 -med)/128;
    
        return new Color(GraphicsUtils.desaturate((int)red << 16 | (int)green << 8 | (int)blue, 1 -d));
    }
}
