package phelps.awt.font;

import java.awt.Font;
import java.awt.font.*;



/**
	NOT IMPLEMENTED.
	OpenType (www.adobe.com/...) utilities.

	@version $Revision$ $Date$
*/
public class OpenType implements java.awt.font.OpenType {

  /** Returns the table as an array of bytes for a specified tag. */
  public byte[] getFontTable(int sfntTag) {
	return null;
  }

  /** Returns a subset of the table as an array of bytes for a specified tag. */
  public byte[] getFontTable(int sfntTag, int offset, int count) {
	return null;
  }

  /** Returns the table as an array of bytes for a specified tag. */
  public byte[] getFontTable(String strSfntTag) {
	return null;
  }

  /** Returns a subset of the table as an array of bytes for a specified tag. */
  public byte[] getFontTable(String strSfntTag, int offset, int count) {
	return null;
  }

  /** Returns the size of the table for a specified tag. */
  public int getFontTableSize(int sfntTag) {
	return -1;
  }

  /** Returns the size of the table for a specified tag. */
  public int getFontTableSize(String strSfntTag) {
	return -1;
  }

  /** Returns the version of the OpenType font. */
  public int getVersion() {
	return -1;
  }
}
