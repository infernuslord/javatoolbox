package multivalent.std.adaptor.ms;

import java.io.*;
import java.net.URI;
import java.util.List;
import java.util.ArrayList;
import java.util.Calendar;

import multivalent.*;
import multivalent.std.adaptor.ArchiveMediaAdaptor;
import multivalent.std.adaptor.ArchiveFileEntry;
import multivalent.std.adaptor.MediaAdaptorRandom;
import multivalent.node.LeafAscii;

import phelps.Utility;
import phelps.io.BufferedRandomAccessFile;



/**
	PLACEHOLDER FOR FUTURE WORK.

	Media adaptor for Microsoft's Structured Storage, a Zip ripoff, used by MS Word, PowerPoint, HP's HPD, FlashPix, and others.

	<blockquote>
	ISO/IEC JTC1/SC29/WG1
	(ITU-T SG8)<br>
	Coding of Still Pictures
	</blockquote>

	<p>LATER:

	@version $Revision: 1.3 $ $Date: 2002/02/02 12:54:05 $
*/
public class StructuredStorage extends ArchiveMediaAdaptor {
  static final boolean DEBUG=false;
  public static final int BLOCKLEN=0x200;


  public Object parse(INode parent) throws IOException {
	Document doc = parent.getDocument();
	//URI uri = doc.getURI();

	closeInputStream();

	return parseHelper(toHTML(), "HTML", getLayer(), parent);
  }


  static class MSSSEntry extends ArchiveFileEntry {
	public int blocks;	// could compute from length, but not single simple division
	public MSSSEntry(String filename, String type, int blocks, int length, int offset, long date) {
		super(filename, -1, type, length, length, offset, date, -1);
		this.blocks=blocks;
		normal += "."+type;
	}
  }

  protected String[] getPatterns() { String[] pat={}; return pat; }

  public File extractFile(File archive, String filename, File outdir) throws IOException {
	File newfile=null;
	RandomAccessFile raf = new BufferedRandomAccessFile(archive, "r");
	List<ArchiveFileEntry> files = getCatalog(raf);
	for (int i=0,imax=files.size(); i<imax; i++) {
		MSSSEntry e = (MSSSEntry)files.get(i);
//System.out.println("*** comparing "+filename+" with "+e.normal);
		if (filename==ALLFILES || filename.equals(e.normal)) {
//System.out.println("*** extract");
			newfile = extractFile(raf, e, outdir);
			if (filename!=ALLFILES) break;	// maybe accept pattern and keep iterating until end
		}
	}
	raf.close();
	return newfile;
  }

  /** All files small (<140K), so just write out what extractByteArray produces. */
  public File extractFile(RandomAccessFile raf, MSSSEntry e, File outdir) throws IOException {
	byte[] bytes = extractByteArray(raf, e);

	File outfile = null;
	if (bytes!=null) {
		outfile = new File(outdir, e.normal);
		OutputStream out = new BufferedOutputStream(new FileOutputStream(outfile));
		out.write(bytes, 0, (int)e.length);
		out.close();
	}

	return outfile;
  }

  public byte[] extractByteArray(RandomAccessFile raf, MSSSEntry e) throws IOException {
	String type=e.type;
	int length = (int)e.length;
	byte[] buf = new byte[length];

	int b=(int)e.offset/BLOCKLEN;
//System.out.println("block = "+b+" .. ");
	if (e.type=="txt") { b+=2; length-=2*BLOCKLEN; }	 // first two blocks of text is binary
	for (int off=0; off<length; b++, off+=BLOCKLEN) {
		block(raf, b, null);
		int len = Math.min(BLOCKLEN, length-off);
//System.out.println("block = "+b+", len="+len+", e.type=|"+e.type+"|");
		System.arraycopy(rawbuf,0, buf,off, len);
		if (e.type=="txt") {
//System.out.println("off="+off+", off+len="+(off+len));
			for (int i=off,imax=off+len; i<imax; i++) {
				char ch = (char)buf[i];
//System.out.print(Integer.toHexString(buf[i])+" ");
				if (ch==0x10) buf[i] = buf[i+1] = (byte)' ';
				else if (ch=='\r') buf[i]=(byte)'\n';
				else if (ch=='&') buf[i]=(byte)'A'; else if (ch=='<') buf[i]=(byte)'_';
				else if (ch==0) { e.length = i; break; }
			}
//System.out.println("length = "+e.length);
		}
	}
//System.out.println("length = "+e.length);
	return buf;
  }

  /** Returns byte offset in disk image file corresponding to passed block number. */
  //public long block(int blkno) { return 0xb00 + blkno*BLOCKLEN; }

  static byte[] rawbuf = new byte[BLOCKLEN];
  public void block(RandomAccessFile raf, int blkno, int[] buf) throws IOException {
	raf.seek(blkno * BLOCKLEN);
	raf.read(rawbuf, BLOCKLEN/2, BLOCKLEN/2);
	raf.read(rawbuf, 0, BLOCKLEN/2);
	if (buf!=null) for (int i=0; i<BLOCKLEN; i++) buf[i] = rawbuf[i]&0xff;	   // stupid signed bytes
  }

  public List<ArchiveFileEntry> getCatalog(File archive) throws IOException {
	return getCatalog(new BufferedRandomAccessFile(archive, "r"));
  }

  int read2(RandomAccessFile raf) throws IOException { return raf.read()+(raf.read()<<8); }
  int read2(int[] buf, int off) { return buf[off]+(buf[off+1]<<8); }

  public List<ArchiveFileEntry> getCatalog(RandomAccessFile raf) throws IOException {
	int[] buf = new int[BLOCKLEN];
	List<ArchiveFileEntry> files = new ArrayList<ArchiveFileEntry>(77);
	Calendar cal = Calendar.getInstance();

	StringBuffer fsb = new StringBuffer(15);
	//raf.seek(block(0));
	block(raf, 5, buf);


	int dirstart=read2(buf, 0), dirend=read2(buf, 2);
	read2(buf,4); // ?
	int flen=buf[6]; fsb.setLength(0); for (int i=0; i<flen; i++) fsb.append((char)buf[7+i]);
	int disksize = read2(buf, 14);
	int fcnt = read2(buf, 16);	// includes deleted files
	read2(buf, 18); // ?
	int d1=buf[20], d2=buf[21];
	read2(buf, 22); // ?
	read2(buf, 24); // ?
//System.out.println("disk "+fsb.substring(0)+"/"+flen+"	"+dirstart+".."+dirend+", blocks="+disksize);

	for (int blk=5, fi=0, off=26; blk>=1; blk--, off=8) {
		block(raf, blk, buf);
		for (int b=off; fi<fcnt && b+26<BLOCKLEN; b+=26, fi++) {
//public MSSSEntry(String filename, int perms, String type, int blocks, int length, int offset, long date) {
			int bstart=read2(buf, b+0), bend=read2(buf, b+2)-1;
			int type=read2(buf, b+4);	// 2 bytes?
			flen=buf[b+6]; fsb.setLength(0); for (int i=0; i<flen; i++) fsb.append((char)buf[b+7+i]);
			int bendy=read2(buf, b+22);
			d1=buf[b+24]; d2=buf[b+25];
//if (flen==0) System.out.println("deletion");
			if (flen==0) continue;	// how to mark deleted files?
//System.out.println(fi+"/"+fcnt+" "+Integer.toHexString(b)+"  "+fsb.substring(0)+"/"+flen+"	"+bstart+".."+bend+"+"+bendy+", type="+type);
			cal.set(1900+(d2>>1), (d1&0xf), ((d2&0x1)<<7)+(d2>>4));
//			files.add(new MSSSEntry(fsb.substring(0), TYPES[type], bend-bstart+1, (bend-bstart)*BLOCKLEN + bendy, bstart*BLOCKLEN, cal.getTime().getTime()));
		}
	}

	return files;
  }



  /** Return HTML translation of document. */
  public String toHTML() throws IOException {
	RandomAccessFile raf=null;
	Browser br = getBrowser();
	Document doc = getDocument();
	File cachefile = getGlobal().getCache().mapTo(br.getCurDocument().getURI(), null, Cache.COMPUTE);
	raf = new BufferedRandomAccessFile(cachefile, "r");

	StringBuffer sb = new StringBuffer(10000);
	sb.append("<html>\n<head>");
	//sb.append("\t<title>").append("Apple DOS 3.3 ").append(url.getFile()).append("</title>\n");
	sb.append("\t<base href='").append(doc.getURI()).append("/'>\n");	// .do/.dsk as if directory!
	sb.append("</head>\n");
	sb.append("<body>\n");

	List<ArchiveFileEntry> files = getCatalog(raf);
	if (!fulltext) sb.append(files.size()).append(" files");

	// file list
	sb.append("<table width='90%'>\n");
	if (!fulltext) sb.append("<tr><b><span Behavior='ScriptSpan' script='event tableSort <node>'	title='Sort table'>")
		.append(verbose? "<th width='5%'>T/S": "")
		.append("<th align='left' width='5%'>Type<th align='left'>Filename<th align='right'>Length</span></b>\n");

	// files list
	for (int i=0, imax=files.size(); i<imax; i++) {
		MSSSEntry e = (MSSSEntry)files.get(i);

		sb.append("<tr>");
		//if (verbose) sb.append("<td>").append(Integer.toHexString(e.track).toUpperCase()).append('/').append(Integer.toHexString(e.sector).toUpperCase());
		sb.append("<td>").append(e.type);
		sb.append("<td>");
		boolean ex = e.length>0 && (e.type=="txt" || e.type=="bin");
		if (ex) sb.append("<a href='").append(e.normal).append("'>");
		sb.append(e.filename);
		if (ex) sb.append("</a>");
		if (e.length!=-1) sb.append("<th align='right'>").append(e.length);
		sb.append("\n");
	}

	sb.append("\n</table>");

	sb.append("\n</body></html>\n");
if (DEBUG) System.out.println(sb.substring(0,Math.min(sb.length(),2048)));
	raf.close();

	return sb.substring(0);
  }
}
