/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh.theme;

import java.awt.Color;
import java.awt.Font;
import java.net.URL;
import java.util.Collection;
import java.util.List;
import java.util.Vector;

import javax.swing.border.Border;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.shfarr.io.IOUtils;
import com.shfarr.ui.GraphicsUtils;
import com.shfarr.ui.plaf.fh.borders.FHMultiMatrixBorder;
import com.shfarr.ui.plaf.fh.borders.FhMatrixBorder;
import com.shfarr.ui.plaf.fh.textures.Texture;
import com.shfarr.ui.plaf.fh.theme.persist.LafObjectDecoder;
import com.shfarr.ui.plaf.fh.theme.persist.LafObjectEncoder;


public class Theme{
    protected String name = null;
    protected ColorPalette alternateColorPalette;
	protected ColorPalette colorPalette;
	protected TexturePalette texturePalette;
    protected Palette fontPalette;
    protected Palette matrixPalette;
    protected Palette metaPalette;

    protected String description = "missing";
    protected String version = "?";
    protected String author = "anonimous";
    protected boolean editable = false;
    protected List changeListeners = null;
    
    public Theme(String name) throws Exception{
        this.name = name;
        
        try{
            metaPalette();
        }
        catch(Throwable e){
            throw new Exception(e);
        }
        
        changeListeners = new Vector();
    }
    
    public Palette fontPalette(){
        if(fontPalette == null) loadFonts();
        
        return fontPalette;
    }
    
    public ColorPalette colorPalette(){
        if(colorPalette == null) loadColors();

        return colorPalette;
    }
    
    public Palette matrixPalette(){
        if(matrixPalette == null) loadMatrices();
            
        return matrixPalette;
    }
    
    public Palette texturePalette(){
        if(texturePalette == null) loadTextures();

        return texturePalette;
    }

    public Palette metaPalette(){
        if(metaPalette == null) loadMeta();

        return metaPalette;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Color getColor(String name){
        try{
            int rgb = 0;
            
            if(ThemeManager.instance().getPreferences().isUsingCustomBaseColor()){
                if(alternateColorPalette == null) alternateColorPalette = colorPalette().derivePalette(ThemeManager.instance().getPreferences().getCustomBaseColor());
                rgb = alternateColorPalette.getColor(Integer.parseInt(name)).getRGB();
            }
            else rgb = colorPalette().getColor(Integer.parseInt(name)).getRGB();
            
            if(ThemeManager.instance().getPreferences().getBrightness() > 0){
                rgb = GraphicsUtils.brighter(rgb, (ThemeManager.instance().getPreferences().getBrightness())/300f);
            }
            else if(ThemeManager.instance().getPreferences().getBrightness() < 0) {
                rgb = GraphicsUtils.darker(rgb, (-ThemeManager.instance().getPreferences().getBrightness())/300f);
            }
            
            return new Color(GraphicsUtils.desaturate(rgb, 1 -ThemeManager.instance().getPreferences().getSaturation()/100f));
        }
        catch(Exception e){
            return (ThemeManager.instance().getPreferences().isUsingCustomBaseColor() ? alternateColorPalette : colorPalette()).getColor(name);
        }
    }
    
    public Texture getTexture(String name){
        Texture tex = (Texture)texturePalette().get(name);
        
        if(tex != null) tex.setTheme(this);
        
        return tex;
    }
    
    public Font getFont(String name){
        Font f = (Font)fontPalette().get(name);
        
        if(ThemeManager.instance().getPreferences().isStrengthenFonts()) return f.deriveFont(Font.BOLD, f.getSize()*ThemeManager.instance().getPreferences().getFontSizeAdjustment()/100f);
        else return f.deriveFont(f.getSize()*ThemeManager.instance().getPreferences().getFontSizeAdjustment()/100f);
    }

    public Border getBorder(String str){
        try{
            return new FhMatrixBorder((String[][])matrixPalette().get("borders/." + str));
        }
        catch(Throwable e){
            return new FhMatrixBorder(new String[][]{{}});
        }
    }

    public Border getBorder(String component, String[] states){
        Object[] subborders = new Object[states.length];

        for(int i = 0; i < states.length; i++){
            subborders[i] = getBorder(component + (states[i].equals("normal") ? "" : "." + states[i]));
        }
        
        try{
            return new FHMultiMatrixBorder(states, subborders);
        }
        catch(Error e){
//            System.out.println("---=( shfarr :: Theme.java )=-> " + e);
            return null;
        }
    }
    
    public void loadColors(){
        try{
            colorPalette = (ColorPalette)IOUtils.xml2Object(getResourceURL(".colors.xml"), new LafObjectDecoder());
        }
        catch(Exception e){
            throw new Error(e);
        }
    }

    public void loadFonts(){
        try{
            fontPalette = (Palette)IOUtils.xml2Object(getResourceURL(".fonts.xml"), new LafObjectDecoder());
        }
        catch(Exception e){
            throw new Error(e);
        }
    }

    public void loadMatrices(){
        try{
            matrixPalette = (Palette)IOUtils.xml2Object(getResourceURL(".matrices.xml"), new LafObjectDecoder());
        }
        catch(Exception e){
            throw new Error(e);
        }
    }
    
    public void loadTextures(){
        try{
            texturePalette = (TexturePalette)IOUtils.xml2Object(getResourceURL(".textures.xml"), new LafObjectDecoder());
        }
        catch(Exception e){
            throw new Error(e);
        }
    }
    
    public void loadMeta(){
        try{
            metaPalette = (Palette)IOUtils.xml2Object(getResourceURL(".meta.xml"), new LafObjectDecoder());
        }
        catch(Exception e){
            throw new Error(e);
        }
    }

    public Collection themeFiles(){
        try{
            return (Collection)IOUtils.xml2Object(getResourceURL(".files.xml"), new LafObjectDecoder());
        }
        catch(Exception e){
            throw new Error(e);
        }
    }

    public void saveColors(){
        IOUtils.object2File(colorPalette(), ThemeManager.instance().getPreferences().getThemeDirectory() + "/" + getName() + "/.colors.xml", new LafObjectEncoder());
        fireThemeChanged();
    }
    
    public void saveFonts(){
        IOUtils.object2File(fontPalette(), ThemeManager.instance().getPreferences().getThemeDirectory() + "/" + getName() + "/.fonts.xml", new LafObjectEncoder());
        fireThemeChanged();
    }
    
    public void saveMatrices(){
        IOUtils.object2File(matrixPalette(), ThemeManager.instance().getPreferences().getThemeDirectory() + "/" + getName() + "/.matrices.xml", new LafObjectEncoder());
        fireThemeChanged();
    }
    
    public void saveTextures(){
        IOUtils.object2File(texturePalette(), ThemeManager.instance().getPreferences().getThemeDirectory() + "/" + getName() + "/.textures.xml", new LafObjectEncoder());
        fireThemeChanged();
    }

    public void saveMeta(){
        IOUtils.object2File(metaPalette(), ThemeManager.instance().getPreferences().getThemeDirectory() + "/" + getName() + "/.meta.xml", new LafObjectEncoder());
        fireThemeChanged();
    }
    
    protected void fireThemeChanged(){
        ChangeEvent ce = new ChangeEvent(this);
        for(int i = 0; i < changeListeners.size(); i++) ((ChangeListener)changeListeners.get(i)).stateChanged(ce);
    }
    
    public void addChangeListener(ChangeListener chl){
        if(!changeListeners.contains(chl)) changeListeners.add(chl);
    }
    
    public void removeChangeListener(ChangeListener chl){
        changeListeners.remove(chl);
    }
    
    public URL getResourceURL(String res){
        URL url = ClassLoader.getSystemResource(getName() + "/" + res);

        if(url == null){
            try{
                if(!getName().endsWith(".jar")){
                    url = new URL("file:///" + ThemeManager.instance().getPreferences().getThemeDirectory() + "/" + getName() + "/" +res);
                    setEditable(true);
                }
                else url = new URL("jar:file:///" + ThemeManager.instance().getPreferences().getThemeDirectory() + "/" + getName() + "!/" +res);
            }
            catch(Exception e){
            }
        }
        
        return url;
    }
    
    public String getAuthor(){
        return (String)metaPalette().get("Author");
    }

    public String getDescription(){
        return (String)metaPalette().get("Description");
    }

    public String getVersion(){
        return (String)metaPalette().get("Version");
    }

    public boolean isEditable(){
        return editable;
    }

    public void setEditable(boolean editable){
        this.editable = editable;
    }
}
