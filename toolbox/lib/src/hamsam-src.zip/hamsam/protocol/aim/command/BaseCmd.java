/*
 *
 * Hamsam - Instant Messaging API
 *
 * Copyright (C) 2003 Mike Miller <mikemil@users.sourceforge.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 */

package hamsam.protocol.aim.command;

import hamsam.protocol.aim.flap.FlapHeader;
import hamsam.protocol.aim.flap.FlapConstants;
import hamsam.protocol.aim.snac.SNACPacket;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

/**
 *  Concrete Command class.  Used as a concrete Command class
 *  for incoming Commands and also to create 'empty' SNAC Commands.
 */
public class BaseCmd extends Command {

   
    /** Constructor
     * @param hdr flap header 
     * @param cmdbytes flap command bytes
     * @param tlvs flap tlvs
     */
    public BaseCmd(FlapHeader hdr, byte[] cmdbytes, List tlvs) {
        flapHdr = hdr;
        data = cmdbytes;
        tlvList = tlvs;
    }

    /** Constructor
     * @param hdr flap header
     * @param packet SNAC Packet
     * @param tlvs command TLVs
     * @param dataBytes extra command data
     */
    public BaseCmd(FlapHeader hdr, SNACPacket packet, List tlvs, byte[] dataBytes) {
        super(hdr, packet, tlvs, dataBytes);
    }

    /** Constructor - used for creating empty SNAC Commands
     * @param seqNum flap header sequence number
     * @param snacFamily SNAC Packet family id
     * @param snacSubtype SNAC Packet subtype id
     */
    public BaseCmd(int seqNum, int snacFamily, int snacSubtype) {
        flapHdr = new FlapHeader(FlapConstants.FLAP_CHANNEL_SNAC, seqNum);
        snacPacket = new SNACPacket(snacFamily, snacSubtype);
    }

    /* (non-Javadoc)
     * @see hamsam.protocol.aim.command.Command#writeCommandData(java.io.OutputStream)
     */
    public void writeCommandData(OutputStream os) throws IOException {
        // nothing to write - empty command bytes
    }

}
