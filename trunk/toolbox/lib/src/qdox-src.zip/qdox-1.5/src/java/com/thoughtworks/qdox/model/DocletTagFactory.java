package com.thoughtworks.qdox.model;

import java.io.Serializable;

/**
 * @author Aslak Helles&oslash;y
 * @version $Revision: 1.6 $
 */
public interface DocletTagFactory extends Serializable {

    /**
     * @since 1.5
     */ 
    DocletTag createDocletTag(
        String tag, String text, 
        AbstractJavaEntity context, int lineNumber
    );

    DocletTag createDocletTag(String tag, String text);

}
