// $Id: AxisExpr.java,v 1.1 2002/04/25 18:04:56 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

abstract class AxisExpr extends ConvertibleNodeSetExpr
{
    ConvertibleNodeSetExpr makeFilterExpr(ConvertibleNodeSetExpr expr,
                                          BooleanExpr predicate) {
        return new FilterExpr(expr, predicate);
    }
    ConvertibleNodeSetExpr makeDocumentOrderExpr(ConvertibleNodeSetExpr expr) {
        return expr;
    }
}
