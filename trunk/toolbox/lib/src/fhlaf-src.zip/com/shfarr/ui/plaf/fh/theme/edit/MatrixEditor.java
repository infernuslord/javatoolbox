/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh.theme.edit;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Collection;
import java.util.Iterator;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JSpinner;
import javax.swing.JToggleButton;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.shfarr.ui.GraphicsUtils;
import com.shfarr.ui.layouts.FlexibleGridLayout;
import com.shfarr.ui.layouts.QueueLayout;
import com.shfarr.ui.plaf.fh.borders.FhMatrixBorder;
import com.shfarr.ui.plaf.fh.textures.MatrixTexture;
import com.shfarr.ui.plaf.fh.theme.ColorPalette;
import com.shfarr.ui.plaf.fh.theme.Theme;
import com.shfarr.ui.plaf.fh.theme.ThemeManager;

public class MatrixEditor extends JPanel implements ActionListener, ChangeListener{
    private ColorPalettePanel palettePanel = null;
    private JPanel southPanel = null;
    private JLabel colorDispLabel = null;
    private JSpinner widthSpinner = null;
    private JSpinner heightSpinner = null;
    private JPanel editorScroller = null;
    private JPanel editor = null;
    private JSlider widthSlider = null;
    private JSlider heightSlider = null;
    private JPanel borderSample = null;
    private MatrixTexture currentTexture = null;
    private MatrixTexture backupTexture = null;
    private FhMatrixBorder currentBorder = null;
    private FhMatrixBorder backupBorder = null;
    private JComboBox namesCombo = null;
    private JPanel sidePanel = null;
    private String fileName = null;
    private JPanel centerPanel = null;
    private JPanel northPanel = null;
    private String type = "borders";

    public MatrixEditor(){
        super(new BorderLayout(3, 3));
        setBorder(new EmptyBorder(10, 4, 0, 0));
                
        add(getSidePanel(), "East");
        add(getCenterPanel(), "Center");
    }

    protected JPanel getCenterPanel(){
        if(centerPanel == null){
            JScrollPane scp = new JScrollPane(getPalettePanel());
            scp.setPreferredSize(new Dimension(getPalettePanel().getPreferredSize().width +scp.getVerticalScrollBar().getPreferredSize().width +6, 100));

            centerPanel = new JPanel(new BorderLayout(4, 4));
            centerPanel.add(getEditorScroller(), "Center");
            centerPanel.add(getNorthPanel(), "North");
            centerPanel.add(getSouthPanel(), "South");
            centerPanel.add(scp, "West");
        }
    
        return centerPanel;
    }
    
    protected JPanel getNorthPanel(){
        if(northPanel == null){
            northPanel = new JPanel(new FlexibleGridLayout(1, 2, 4, 4));

            ButtonGroup group = new ButtonGroup();
            
            JRadioButton border = new JRadioButton("Border Matrices");
            border.setSelected(true);
            border.addActionListener(this);

            JRadioButton texture = new JRadioButton("Texture Matrices");
            texture.addActionListener(this);

            group.add(border);
            group.add(texture);
            
            northPanel.add(border);
            northPanel.add(texture);
        }
    
        return northPanel;
    }
    
    protected JPanel getSidePanel(){
        if(sidePanel == null){
            sidePanel = new JPanel(new QueueLayout(4, QueueLayout.VERTICAL, QueueLayout.STRECH_COMPONENTS));
            sidePanel.setBorder(new EmptyBorder(0, 4, 4, 4));
            
            JButton save = new JButton("Save");
            save.addActionListener(this);
            
            JButton revert = new JButton("Revert");
            revert.addActionListener(this);

            JButton add = new JButton("Add / Set");
            add.addActionListener(this);
            
            JButton delete = new JButton("Delete");
            delete.addActionListener(this);

            sidePanel.add(save);
            sidePanel.add(revert);
            sidePanel.add(new JPanel());
            sidePanel.add(add);
            sidePanel.add(delete);
        }
    
        return sidePanel;
    }

    protected JSlider getHeightSlider(){
        if(heightSlider == null){
            heightSlider = new JSlider(JSlider.VERTICAL);
            heightSlider.setMinimum(0);
            heightSlider.setMinorTickSpacing(1);
            heightSlider.setPaintTicks(true);
            heightSlider.setPaintTrack(false);
            heightSlider.setSnapToTicks(true);
            heightSlider.addChangeListener(this);
        }
    
        return heightSlider;
    }
    
    protected JSlider getWidthSlider(){
        if(widthSlider == null){
            widthSlider = new JSlider(JSlider.HORIZONTAL);
            widthSlider.setMinimum(0);
            widthSlider.setMinorTickSpacing(1);
            widthSlider.setPaintTicks(true);
            widthSlider.setPaintTrack(false);
            widthSlider.setSnapToTicks(true);
            widthSlider.addChangeListener(this);
        }

        return widthSlider;
    }
    
    protected JPanel getBorderSample(){
        if(borderSample == null){
            borderSample = new JPanel(){
                                public void paint(Graphics g){
                                    super.paint(g);
                                    Insets i = getBorder() != null ? getBorder().getBorderInsets(this) : new Insets(0, 0, 0, 0);
                                    Rectangle r = new Rectangle(i.left, i.top, getSize().width -i.left -i.right, getSize().height -i.top -i.bottom);
                                    if(currentTexture != null) currentTexture.apply(r, (Graphics2D)g, this);
                                }  
                            };
        }
    
        return borderSample;
    }
    
    protected JPanel getEditor(){
        if(editor == null){
            editor = new JPanel(){
                public void paint(Graphics g){
                    super.paint(g);
                    
                    String[][] matrix = type.equals("borders") ? currentBorder != null ? currentBorder.getMatrix() : null : currentTexture != null ? currentTexture.getMatrix() : null;
                    
                    if(matrix != null){
                        int ws = (getSize().width -2)/matrix[0].length;
                        int hs = (getSize().height -2)/matrix.length;

                        for(int i = 0; i < matrix[0].length; i++){
                            for(int k = 0; k < matrix.length; k++){
                                Rectangle r = new Rectangle(1 +i*ws +1, 1 +k*hs +1, ws -4, hs -3);
                                GraphicsUtils.paintTiledBackground(g, r, 5);

                                if(matrix[k][i] != null){
                                    g.drawImage(GraphicsUtils.createColorImage(ThemeManager.instance().getCurrentTheme().colorPalette().getColor(matrix[k][i]), ws -4, hs -3), 1 +i*ws +1, 1 +k*hs +1, null);
                                }
                                
                                if(type.equals("borders") && currentBorder != null) {
                                    g.setColor(Color.black);
                                    g.drawRect(1 +i*ws +1, 1 +k*hs +1, ws -4, hs -3);
                                    if(i == currentBorder.getCenter()[0] || k == currentBorder.getCenter()[1]) g.drawRect(1 +i*ws +2, 1 +k*hs +2, ws -6, hs -5);
                                } 
                            }
                        }
                    }
                }
            };
            
            editor.addComponentListener(new ComponentAdapter(){
                                            public void componentResized(ComponentEvent ce){
                                                if(type.equals("borders")) updateSliders();
                                            }
                                        });

            editor.addMouseListener(new MouseAdapter(){
                                        public void mouseClicked(MouseEvent me){
                                            String[][] matrix = type.equals("borders") ? currentBorder != null ? currentBorder.getMatrix() : null : currentTexture != null ? currentTexture.getMatrix() : null;
                                            
                                            int ws = (getEditor().getSize().width -2)/matrix[0].length;
                                            int hs = (getEditor().getSize().height -2)/matrix.length;
                                            
                                            int i = me.getY()/hs;
                                            int k = me.getX()/ws;
                                            
                                            if(me.getButton() == 1){
                                                if(me.getClickCount() == 2) matrix[i][k] = null;
                                                else matrix[i][k] = getColorDispLabel().getText();
                                                
                                                if(type.equals("borders")){
                                                    currentBorder.setMatrix(matrix);
                                                    currentBorder.setCenter(getWidthSlider().getValue(), getHeightSlider().getMaximum() -getHeightSlider().getValue());
                                                }
                                                else currentTexture.setMatrix(matrix);
                                            }
                                            else{
                                                getColorDispLabel().setText(matrix[i][k].startsWith("!") ? matrix[i][k].substring(1) : matrix[i][k]);
                                            }
                                            
                                            getEditor().repaint();
                                            getBorderSample().repaint();
                                        }
                                    });
        }
    
        return editor;
    }

    protected JPanel getEditorScroller(){
        if(editorScroller == null){
            editorScroller = new JPanel(null);
            
            editorScroller.addComponentListener(new ComponentAdapter(){
                public void componentResized(ComponentEvent e){
                    getBorderSample().setBounds(0, 0, getHeightSlider().getPreferredSize().width, getWidthSlider().getPreferredSize().height);
                    getWidthSlider().setBounds(getBorderSample().getWidth(), 0, editorScroller.getWidth() -getBorderSample().getWidth(), getBorderSample().getHeight());
                    getHeightSlider().setBounds(0, getBorderSample().getHeight(), getBorderSample().getWidth(), editorScroller.getHeight() -getBorderSample().getHeight());
                    getEditor().setBounds(getBorderSample().getWidth(), getBorderSample().getHeight(), editorScroller.getWidth() -getBorderSample().getWidth(), editorScroller.getHeight() -getBorderSample().getHeight());
                }
            });
            
            editorScroller.add(getBorderSample());
            editorScroller.add(getWidthSlider());
            editorScroller.add(getHeightSlider());
            editorScroller.add(getEditor());
        }
    
        return editorScroller;
    }
    
    protected JSpinner getHeightSpinner(){
        if(heightSpinner == null){
            heightSpinner = new JSpinner(new SpinnerNumberModel(3, 1, 1000, 1));
            heightSpinner.addChangeListener(this);
        }

        return heightSpinner;
    }
    protected JSpinner getWidthSpinner(){
        if(widthSpinner == null){
            widthSpinner = new JSpinner(new SpinnerNumberModel(3, 1, 1000, 1));
            widthSpinner.addChangeListener(this);
        }
    
        return widthSpinner;
    }    
    
    protected JLabel getColorDispLabel(){
        if(colorDispLabel == null){
            colorDispLabel = new JLabel("-9");
        }
    
        return colorDispLabel;
    }
    
    protected JComboBox getNamesCombo(){
        if(namesCombo == null){
            namesCombo = new JComboBox();
            namesCombo.addActionListener(this);
            namesCombo.setEditable(true);

            refreshNames(null);
        }
    
        return namesCombo;
    }    

    protected JPanel getSouthPanel(){
        if(southPanel == null){
            southPanel = new JPanel(new FlexibleGridLayout(3, 4, 4, 4));

            southPanel.setBorder(new EmptyBorder(5, 5, 5, 0));
            
            southPanel.add(new JLabel("Name:", JLabel.RIGHT));
            southPanel.add(getColorDispLabel());
            southPanel.add(new JLabel("    Matrix Width", JLabel.RIGHT));
            southPanel.add(getWidthSpinner());
            southPanel.add(new JLabel("Matrix", JLabel.RIGHT));
            southPanel.add(getNamesCombo());
            southPanel.add(new JLabel("    Matrix Height", JLabel.RIGHT));
            southPanel.add(getHeightSpinner());
        }
    
        return southPanel;
    }
    
    protected JToggleButton createToggleButton(String name, Color c){
        JToggleButton b = new JToggleButton("");
                
        // icon
        BufferedImage img = new BufferedImage(20, 20, BufferedImage.TYPE_INT_ARGB);
        Graphics g = img.createGraphics();
                
        g.setColor(Color.gray);
        g.drawRect(0, 0, 19, 19);
                
        g.setColor(Color.white);
        g.drawRect(1, 1, 17, 17);

        GraphicsUtils.paintTiledBackground(g, new Rectangle(3, 2, 14, 16), 5);
        g.drawImage(GraphicsUtils.createColorImage(c, 14, 16), 3, 2, null);
                
        b.setIcon(new ImageIcon(img));

        // selected icon
        BufferedImage imgS = new BufferedImage(20, 20, BufferedImage.TYPE_INT_ARGB);
        g = imgS.createGraphics();
                
        g.setColor(Color.orange);
        g.drawRect(0, 0, 19, 19);
                
        g.setColor(Color.white);
        g.drawRect(1, 1, 17, 17);
                
        GraphicsUtils.paintTiledBackground(g, new Rectangle(3, 2, 14, 16), 5);
        g.drawImage(GraphicsUtils.createColorImage(c, 14, 16), 3, 2, null);
                
        b.setSelectedIcon(new ImageIcon(imgS));

        b.setActionCommand(name);
        b.setMargin(new Insets(1, 1, 1, 1));
        b.addActionListener(this);
        
        return b;
    }
    
    protected JPanel getPalettePanel(){
        if(palettePanel == null){
            ColorPalette cp = ThemeManager.instance().getCurrentTheme().colorPalette();
            Collection list = cp.list();
            
            palettePanel = new ColorPalettePanel(new GridLayout(list.size()/4 +(list.size()%4 != 0 ? 1 : 0) +1, 4, 2, 2));
            
            palettePanel.setBorder(new EmptyBorder(2, 2, 2, 2));
            
            ButtonGroup group = new ButtonGroup();
            
            int i = 0;
            
            for(Iterator iter = list.iterator(); iter.hasNext(); ){
            	String name = (String)iter.next();
                
                JToggleButton b = createToggleButton(name, cp.getColor(name));                
                
                if(i == 24){
                    for(int q = 0; q < 4; q++){
                        JPanel sep = new JPanel();
                        sep.setPreferredSize(new Dimension(20, 20));
                        palettePanel.add(sep);
                    }
                }
                
                palettePanel.add(b);
                
                group.add(b);
                i++;
            }
        }
    
        return palettePanel;
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource() instanceof JComboBox) selectEditedItem();
        else if(e.getSource() instanceof JRadioButton){
            if(e.getActionCommand().equals("Border Matrices")) type = "borders";
            else type = "textures";
    
            getHeightSlider().setEnabled(type.equals("borders"));
            getWidthSlider().setEnabled(type.equals("borders"));
            getHeightSlider().setVisible(type.equals("borders"));
            getWidthSlider().setVisible(type.equals("borders"));
            
            refreshNames(null);
        }
        else if(e.getSource() instanceof JToggleButton) colorDispLabel.setText(e.getActionCommand());
        else if(e.getActionCommand().equals("Save")) ThemeEditor.instance().getEditedTheme().saveMatrices();
        else if(e.getActionCommand().equals("Add / Set")){
            String[][] matrix = GraphicsUtils.rotateClockwise(type.equals("borders") ? currentBorder.getMatrix() : currentTexture.getMatrix(), 0);
            ThemeEditor.instance().getEditedTheme().matrixPalette().put(type + "/." + getNamesCombo().getSelectedItem(), matrix);
        }
        else if(e.getActionCommand().equals("Delete")){
            fileName = ThemeManager.instance().getPreferences().getThemeDirectory() + "/" + ThemeEditor.instance().getEditedTheme().getName() + "/matrix/" + type + "/." + getNamesCombo().getSelectedItem().toString();
            
            new File(fileName).delete(); 
            
            refreshNames(null);
        }
        else if(e.getActionCommand().equals("Revert")){
            ThemeEditor.instance().getEditedTheme().loadMatrices();
            
            if(type.equals("borders")){
                currentBorder.setMatrix(backupBorder.getMatrix());
                currentBorder.setCenter(backupBorder.getCenter()[0], backupBorder.getCenter()[1]);
                updateSliders();
            }
            else currentTexture.setMatrix(backupTexture.getMatrix());

            updateSpinners();
            
            getEditor().repaint();
            getBorderSample().repaint();
        }
    }
    
    public void selectEditedItem(){
        Theme theme = ThemeEditor.instance().getEditedTheme();
        
        Object name = getNamesCombo().getSelectedItem();

        if(name != null){
            if(type.equals("borders")){
                FhMatrixBorder dumbBorder = (FhMatrixBorder)theme.getBorder(name.toString());
                
                if(dumbBorder != null){
                    currentBorder = dumbBorder;
                    backupBorder = currentBorder.deriveBorder(0);
                    updateSliders();
                }
            }
            else{
                String[][] newMatrix = (String[][])theme.matrixPalette().get(type + "/." + name.toString());
                
                if(newMatrix != null){
                    currentTexture = new MatrixTexture();
                    currentTexture.setMatrix(newMatrix);
                    backupTexture = (MatrixTexture)currentTexture.deriveTexture(0);
                }        
            }
            
            updateSpinners();
                    
            getBorderSample().setBorder(new CompoundBorder(new EmptyBorder(4, 4, 0, 0), currentBorder));
        }

        getEditor().repaint();
    }

    public void stateChanged(ChangeEvent e){
        String[][] matrix = type.equals("borders") ? currentBorder != null ? currentBorder.getMatrix() : null : currentTexture != null ? currentTexture.getMatrix() : null;
            
        if(matrix != null){
            String[][] newMatrix; 

            if(e.getSource() instanceof JSpinner){
                if(e.getSource() == widthSpinner){
                    newMatrix = new String[matrix.length][((Integer)widthSpinner.getValue()).intValue()];
                }
                else newMatrix = new String[((Integer)heightSpinner.getValue()).intValue()][matrix[0].length];
            
                for(int i = 0; i < Math.min(newMatrix.length, matrix.length); i++){
                    for(int k = 0; k < Math.min(newMatrix[i].length, matrix[i].length); k++){
                        newMatrix[i][k] = matrix[i][k];
                    }
                }
            
                if(type.equals("borders")) currentBorder.setMatrix(newMatrix);
                else currentTexture.setMatrix(newMatrix);
                
                updateSliders();
            }
            else{
                synchronized(getTreeLock()){
                    currentBorder.setCenter(getWidthSlider().getValue(), getHeightSlider().getMaximum() -getHeightSlider().getValue());
                    //currentBorder.setMatrix(currentBorder.getMatrix());
                }
            }

            getEditor().repaint();
            getBorderSample().repaint();
        }
    }

    protected void updateSpinners() {
        String[][] matrix = type.equals("borders") ? currentBorder != null ? currentBorder.getMatrix() : null : currentTexture != null ? currentTexture.getMatrix() : null;

        if(matrix != null) getHeightSpinner().setValue(new Integer(matrix.length));
        if(matrix != null) getWidthSpinner().setValue(new Integer(matrix[0].length));
    }
    
    protected void updateSliders(){
        if(type.equals("borders") && currentBorder != null){
            getHeightSlider().removeChangeListener(this);
            getWidthSlider().removeChangeListener(this);
            
            int h = ((getEditor().getSize().height -2)/currentBorder.getMatrix().length)/3;
            getHeightSlider().setBorder(new EmptyBorder(h, 0, h, 0));

            getHeightSlider().setMaximum(currentBorder.getMatrix().length -1);
            getHeightSlider().setValue(getHeightSlider().getMaximum() -currentBorder.getCenter()[1]);

            int w = ((getEditor().getSize().width -2)/currentBorder.getMatrix()[0].length)/3;
            getWidthSlider().setBorder(new EmptyBorder(0, w, 0, w));

            getWidthSlider().setMaximum(currentBorder.getMatrix()[0].length -1);
            getWidthSlider().setValue(currentBorder.getCenter()[0]);

            getHeightSlider().addChangeListener(this);
            getWidthSlider().addChangeListener(this);
        }
    }
    
    protected void refreshNames(String selectedItem){
        Theme theme = ThemeEditor.instance().getEditedTheme();
        
        getNamesCombo().removeAllItems();
        
        for(Iterator i = theme.matrixPalette().keySet().iterator(); i.hasNext(); ){
            String str = (String)i.next();
            
            if(str.startsWith(type + "/")) getNamesCombo().addItem(str.substring(type.length() +2));
        } 
        
        if(selectedItem != null) getNamesCombo().setSelectedItem(selectedItem);
        else getNamesCombo().setSelectedIndex(0);
    }
}
