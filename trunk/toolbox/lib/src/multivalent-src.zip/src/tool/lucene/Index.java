package tool.lucene;

import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.Iterator;
import java.util.regex.*;

import tool.ExtractText;
import org.apache.lucene.index.*;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.document.*;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Hits;

import phelps.io.FileList;
import phelps.io.Files;



/**
	Command-line interface to indexing <a href='http://jakarta.apache.org/lucene/docs/index.html'>Lucene</a> search engine,
	as a demonstration of how to use {@link ExtractText}.
	Assumes that the Lucene JAR is in the CLASSPATH.

	<p>To update a document, you first have to delete it and then add it again.
	Unfortunately you can't do this simultaneously, as according to <a href='http://www.jguru.com/faq/view.jsp?EID=913302'>jGuru FAQ</a>,
	you cannot have both an IndexReader doing deletes and IndexWriter adding at the same time.

	@see tool.lucene.Search

	@version $Revision: 1.7 $ $Date: 2003/08/28 20:31:26 $
*/
public class Index {
  public static final String VERSION = "1.0.1 of $Date: 2003/08/28 20:31:26 $";
  public static final String USAGE = "java tool.lucene.Index [options] <file/directory ...>\n"
	  + "\t[-new] [-refresh] [-exclude] [-optimize]\n"
	  + "\t[-index <directory>]";


  File index_;
  boolean fverbose_ = false;
  boolean fnew_ = false;
  boolean fmonitor_ = false;
  IndexWriter w_;
  Pattern ex_ = null;


  public Index(File index) {
	index_ = index;
  }

  public void close() throws IOException {
	if (w_!=null) w_.close();
  }


  public IndexWriter getIndexWriter() throws IOException {
	if (w_==null) w_ = new IndexWriter(index_, Search.ANALYZER, fnew_);
	return w_;
  }


  /**
	Indexes single file.
	@return true of known document type and successfully indexed
  */
  boolean index1(File f) throws IOException {
	//assert f.isFile(): f;
	if (f.isDirectory()) return false;

	String suri = f.getCanonicalFile().toURI().toString();  // canonicalized: forward slashes
	if (ex_!=null && ex_.matcher(suri).find()) { if (fverbose_) System.out.print(" -- excluded"); return false; }
	long mod = f.lastModified();

	String body = null;
	try { ExtractText et = new ExtractText(); et.setQuiet(true); body = et.extract(f.toURI(), null);
	} catch (Exception fail) { if (fverbose_) System.err.print(suri+" -- error extracting text: "+fail); return false; }
	if (body==null) { if (fverbose_) System.out.print(" -- no text") ; return false; }     // don't know how to parse this document type -- throw ParseException?

	Document doc = new Document();

	// Field(String name, String string,   boolean store, boolean index,   boolean token)
//System.out.println("add "+suri);
	doc.add(new Field("mod", DateField.timeToString(mod), true, true, false));
	doc.add(new Field("uri", suri,  true, true, false));
	doc.add(new Field("body", body, false, true, true));
	if (fverbose_) System.out.print("\t"+body.length());

	getIndexWriter().addDocument(doc);

	return true;
  }

  /**
	If file already exists with same modification date, skip it;
	else if doesn't exist or has later modification time, delete old and index new.
  */
  List<File> incremental(Iterator<File> toadd) throws IOException {
	List<File> l = new ArrayList<File>(10000);

	IndexReader r = IndexReader.open(index_);
	Searcher searcher = new IndexSearcher(r);
	while (toadd.hasNext()) {
		File f = toadd.next();
		String suri = f.getCanonicalFile().toURI().toString();
		long mod = f.lastModified();
//System.out.println("check "+suri);

		Term term = new Term("uri", suri);
		TermQuery q = new TermQuery(term);
		Hits hits = searcher.search(q);
		if (hits.length() == 0) l.add(f);
		else { //assert hits.length() == 1;
			Document doc = hits.doc(0);
//System.out.println("check "+mod+" vs "+DateField.stringToTime(doc.get("mod")));
			if (!DateField.timeToString(mod).equals(doc.get("mod"))) {
//System.out.println("reindex "+f);
				if (fmonitor_) System.out.println(" -- modified");
				else r.delete(term); // second search? but shouldn't happen much
				l.add(f);
			}
		}
	}

	searcher.close();
	r.close();

	return l;
  }

  /**
	Iterates over documents already indexed:
	if source document modified, reindex it;
	if source deleted, delete in index.
	Affects only URIs with <code>file:</code> scheme.
  */
  List<File> refresh() throws IOException {
	List<File> reindex = new ArrayList<File>(100);

	IndexReader r = IndexReader.open(index_);
	for (int i=0, imax=r.maxDoc(); i<imax; i++) {
		if (r.isDeleted(i)) continue;
		Document doc = r.document(i);
		String suri = doc.get("uri");
		if (suri.startsWith("file:")) {
//System.out.println("check "+suri);
			File f = new File(suri.substring("file:".length()));
			if (!f.exists()) {
				if (fmonitor_) r.delete(i);
				if (fverbose_ || fmonitor_) System.out.println(f+" -- deleted");
			} else if (f.lastModified() > DateField.stringToTime(doc.get("mod"))) {
				if (!fmonitor_) r.delete(i);
				reindex.add(f);
				if (fverbose_ || fmonitor_) System.out.println(f+" -- modified");
			}
		}
	}
	r.close();

	return reindex;
  }

  /**
	Delete all files whose URI matches <var>kill</var>.
  */
  int delete(Pattern kill) throws IOException {
	int cnt = 0;

	Matcher m = kill.matcher("");
	IndexReader r = IndexReader.open(index_);
	for (int i=0, imax=r.maxDoc(); i<imax; i++) {
		if (r.isDeleted(i)) continue;
		Document doc = r.document(i);
		String suri = doc.get("uri");
		if (m.reset(suri).find()) {
//System.out.println("check "+suri);
			if (!fmonitor_) r.delete(i);
			if (fverbose_ || fmonitor_) System.out.println(suri+" -- deleted");
			cnt++;
		}
	}
	r.close();

	return cnt;
  }

  public void checkLock(boolean fforce) {
	boolean flocked = false;
	try { flocked = IndexReader.isLocked(index_.toString()); } catch (IOException ioe) { System.err.println("error checking lock: "+ioe); System.exit(1); }

	if (flocked) {
		if (fforce) {
			try {
				IndexReader.unlock(FSDirectory.getDirectory(index_, false));
			} catch (IOException ioe) {
				System.err.println("couldn't unlock "+index_+": "+ioe);
				System.exit(1);
			}

		} else {
			System.err.println("Index in "+index_+" is locked.");
			System.err.println("Another indexer may be running.  If not, remove lock with -force.");
			System.exit(1);
		}
	}
  }

  public static void main(String[] argv) {
	File index = Files.getFile("~/.lucene");
	boolean fquiet_=false, ffverbose_=false, foptimize=false, fnew=false, frefresh=false, fforce=false;
	boolean fmonitor = false;
	Pattern kill = null;
	String x = null;

	int argi = 0, argc=argv.length;
	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.startsWith("-ind")) index = Files.getFile(argv[++argi]);
		else if (arg.equals("-new")) fnew = true;
		else if (arg.startsWith("-opt")) foptimize = true;
		else if (arg.equals("-refresh") || arg.startsWith("-sync") || arg.equals("-update")) frefresh = true;
		else if (arg.equals("-force")) fforce = true;
		else if (arg.equals("-kill") || arg.startsWith("-del")) {
			try { kill = Pattern.compile(argv[++argi]); } catch (PatternSyntaxException pse) { System.err.println("invalid regex: "+pse); System.exit(1); }
		}
		else if (arg.equals("-x") || arg.equals("-exclude")) x = argv[++argi];

		else if (arg.startsWith("-verb")) { ffverbose_ = true; fquiet_=false; }
		else if (arg.equals("-monitor")) fmonitor = true; // extend to incremental and refresh
		else if (arg.startsWith("-q"/*uiet*/)) { fquiet_ = true; ffverbose_=false; }
		else if (arg.startsWith("-v"/*ersion--after "verbose"*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.equals("-help")) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println(USAGE); System.exit(1); }
	}

	if (ffverbose_) System.out.println("index in "+index);


	long start = System.currentTimeMillis();
	Index lu = new Index(index);
	lu.fverbose_ = ffverbose_;
	lu.fmonitor_ = fmonitor;
	lu.checkLock(fforce);
	if (x!=null) try { lu.ex_ = Pattern.compile(x); } catch (PatternSyntaxException pse) { System.err.println("invalid regex: "+pse); System.exit(1); }

	int cnt = 0;
	if (kill!=null) try { cnt -= lu.delete(kill); } catch (IOException ioe) { System.err.println("couldn't delete: "+ioe); }

	try {    // index
		Iterator<File> toadd;
		if (fnew || !IndexReader.indexExists(index)) { toadd = new FileList(argv, argi, null).iterator(); fnew=true; }
		else if (frefresh) toadd = lu.refresh().iterator();
		else toadd = lu.incremental(new FileList(argv, argi, null).iterator()).iterator();
//System.out.println("fnew = "+fnew);

		lu.fnew_ = fnew;

		while (toadd.hasNext()) {
			File f = (File)toadd.next();
			if (!fquiet_) { System.out.println(); System.out.print(f); }
			if (fmonitor) {
				// don't index if testing
			} try {
				boolean ok = lu.index1(f);
				if (ok) cnt++;
			} catch (IOException ioe) {
				ioe.printStackTrace();
				if (!fquiet_) System.out.println(" -- skipped: "+ioe);
			} catch (Throwable e) {
				// do not crash
				System.err.println("ERROR: "+e);
				e.printStackTrace();
				//break?
			}
		}

		if (foptimize) lu.getIndexWriter().optimize();

		lu.close();

		long end = System.currentTimeMillis();
		System.out.println();
		if (ffverbose_) System.out.println(cnt+" document"+(cnt==1? "":"s")+" indexed, in "+(end-start + 500)/1000+" seconds");
		// show size of index (using FileList.length(index)?)

	} catch (IOException ioe) {
		System.err.println(ioe);
		ioe.printStackTrace();
	} catch (Error e) {
		System.err.println("ERROR: "+e);
	}

	System.exit(0);		// started up graphics event loop
  }
}
