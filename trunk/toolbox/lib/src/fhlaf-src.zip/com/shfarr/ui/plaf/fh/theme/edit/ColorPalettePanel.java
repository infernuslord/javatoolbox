/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh.theme.edit;

import java.awt.Dimension;
import java.awt.LayoutManager;
import java.awt.Rectangle;

import javax.swing.JPanel;
import javax.swing.JViewport;
import javax.swing.Scrollable;
import javax.swing.SwingConstants;

class ColorPalettePanel extends JPanel implements Scrollable{

    public ColorPalettePanel() {
        super();
    }

    public ColorPalettePanel(boolean isDoubleBuffered) {
        super(isDoubleBuffered);
    }

    public ColorPalettePanel(LayoutManager layout) {
        super(layout);
    }

    public ColorPalettePanel(LayoutManager layout, boolean isDoubleBuffered) {
        super(layout, isDoubleBuffered);
    }

    public Dimension getPreferredScrollableViewportSize(){
        return getPreferredSize();
    }

    public int getScrollableBlockIncrement(Rectangle visibleRect, int orientation, int direction){
        switch(orientation){
            case SwingConstants.VERTICAL: return visibleRect.height;
            case SwingConstants.HORIZONTAL: return visibleRect.width;
            default: throw new IllegalArgumentException("Invalid orientation: " + orientation);
        }
    }

    public boolean getScrollableTracksViewportHeight(){
        if(getParent() instanceof JViewport){
            return (((JViewport)getParent()).getHeight() > getPreferredSize().height);
        }
        return false;
    }

    public boolean getScrollableTracksViewportWidth(){
        if(getParent() instanceof JViewport){
            return (((JViewport)getParent()).getWidth() > getPreferredSize().width);
        }
        
        return false;
    }

    public int getScrollableUnitIncrement(Rectangle visibleRect, int orientation, int direction){
        switch(orientation){
            case SwingConstants.VERTICAL: return visibleRect.height / 40;
            case SwingConstants.HORIZONTAL: return visibleRect.width / 40;
            default: throw new IllegalArgumentException("Invalid orientation: " + orientation);
        }
    }

}