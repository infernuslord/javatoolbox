/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.plaf.*;
import javax.swing.plaf.basic.*;

import java.beans.*;

import com.shfarr.ui.*;
import com.shfarr.ui.plaf.fh.ext.*;
import com.shfarr.ui.plaf.fh.theme.*;


public class FhSpinnerUI extends BasicSpinnerUI{
    private static final FhArrowButtonHandler nextButtonHandler = new FhArrowButtonHandler(true);
    private static final FhArrowButtonHandler previousButtonHandler = new FhArrowButtonHandler(false);

	public FhSpinnerUI(){
	  super();
	}
	

	protected Component createPreviousButton() {
	  JButton button = new FhSysButton(FhSysButton.ARROW_WEST);
	  button.setName("Previous");

	  button.addActionListener(previousButtonHandler);
	  button.addMouseListener(previousButtonHandler);

	  return button;
	}
	

	protected Component createNextButton() {
	  JButton button = new FhSysButton(FhSysButton.ARROW_EAST);
	  button.setName("Next");
	  
	  button.addActionListener(nextButtonHandler);
	  button.addMouseListener(nextButtonHandler);

	  return button;
	}


	protected LayoutManager createLayout() {
	  return new FhSpinnerLayoutManager();
	}
	

	public static ComponentUI createUI(JComponent c) {
	  return new FhSpinnerUI();
	}
	
	
	public void installDefaults(){
	  super.installDefaults();
      LookAndFeel.installBorder(spinner.getEditor(), "");
      
      for(int i=0; i < spinner.getEditor().getComponentCount(); i++) ((JComponent)spinner.getEditor().getComponent(i)).setBorder(null);
	}


    protected PropertyChangeListener createPropertyChangeListener(){
	  return new FhSpinnerPropertyChangeHandler();
    }

    
    protected void replaceEditor(JComponent oldEditor, JComponent newEditor) {
	  spinner.remove(oldEditor);
	  spinner.add(newEditor, "Editor");
    }
	
	
	public void paint(Graphics g, JComponent c){
        ThemeManager.instance().probeAntialiasing(g);

	  super.paint(g, c);

      JSpinner cb = (JSpinner)c;
	  int width = cb.getWidth();
	  int height = cb.getHeight();
		
	  Insets insets = cb.getInsets();
	
	  g.setColor(UIManager.getColor("EditableComponent.background"));
	  g.drawRect(insets.left, insets.top, 10, height -insets.top -insets.bottom -1);
	  g.drawRect(width -insets.right -11, insets.top, 10, height -insets.top -insets.bottom -1);
	
      g.setColor(UIManager.getColor("Component.moderatedShadow"));
	  g.drawLine(insets.left +11, insets.top, insets.left +11, height -insets.top -insets.bottom +1);
	  g.drawLine(width -insets.right -12, insets.top, width -insets.right -12, height -insets.top -insets.bottom +1);
	}
	
	
    /**
     * @version test 1.0
     * @author Stefan H. Farr
     * This software is published under the terms of General Public License
     */
	protected class FhSpinnerLayoutManager implements LayoutManager{

		public FhSpinnerLayoutManager() {
			super();
		}


		public void addLayoutComponent(String name, Component comp) {}


		public void layoutContainer(Container parent) {
		    JSpinner cb = (JSpinner) parent;
		    int width = cb.getWidth();
		    int height = cb.getHeight();
		
		    Insets insets = cb.getInsets();
		    int buttonSize = height - (insets.top + insets.bottom);
		    Rectangle cvb;

            Component cps[] = extractComponents(parent);
            
		    cps[0].setBounds(insets.left +1, insets.top +1, 9, height -insets.top -insets.bottom -2);
		    cps[1].setBounds(insets.left +12, insets.top, width -insets.left -insets.right -24, height -insets.top -insets.bottom);
		    cps[2].setBounds(width -insets.right -10, insets.top +1, 9, height -insets.top -insets.bottom -2);
		}

		public Dimension minimumLayoutSize(Container parent){
            Component cps[] = extractComponents(parent);
            
		    Insets insets = ((JComponent)parent).getInsets();
		    Dimension ms = new Dimension(insets.left +insets.right +24 +cps[1].getPreferredSize().width, (int)(parent.getFont().getSize()*1.5) +insets.top +insets.bottom);
		    
		    ms.setSize(ms.width, Math.max(ms.height, cps[1].getPreferredSize().height));
		    
		    return ms;
		}


		public Dimension preferredLayoutSize(Container parent){
		    Dimension ps = minimumLayoutSize(parent);
		    ps.setSize(ps.width, Math.max(ps.height, minimumLayoutSize(parent).height));
		    return ps;
		}


		public void removeLayoutComponent(Component comp) {}
		
		protected Component[] extractComponents(Container parent){
		    Component[] cps = new Component[3];
		    
		    for(int i=0; i<parent.getComponentCount(); i++){
		        if("Previous".equals(parent.getComponent(i).getName())) cps[0] = parent.getComponent(i);
		        else if("Next".equals(parent.getComponent(i).getName())) cps[2] = parent.getComponent(i);
		        else cps[1] = parent.getComponent(i);
		    }
		    
		    return cps;
		}
	}


    /**
     * @version test 1.0
     * @author Stefan H. Farr
     * This software is published under the terms of General Public License
     */
    private static class FhSpinnerPropertyChangeHandler implements PropertyChangeListener{
        public void propertyChange(PropertyChangeEvent e){
            String propertyName = e.getPropertyName();
	        JSpinner spinner = (JSpinner)(e.getSource());
	        FhSpinnerUI ui = (FhSpinnerUI)(spinner.getUI());

     	    if("editor".equals(propertyName)){
               JComponent oldEditor = (JComponent)e.getOldValue();
               JComponent newEditor = (JComponent)e.getNewValue();
               
		       ui.replaceEditor(oldEditor, newEditor);
		       
		       newEditor.setBorder(null);
		       for(int i=0; i<newEditor.getComponentCount(); i++) ((JComponent)newEditor.getComponent(i)).setBorder(null);
	        }
	    }
    }


    /**
     * @version test 1.0
     * @author Stefan H. Farr
     * This software is published under the terms of General Public License
     */
    private static class FhArrowButtonHandler extends MouseAdapter implements ActionListener{
		final javax.swing.Timer autoRepeatTimer;
		final boolean isNext;
		JSpinner spinner = null;
	
		FhArrowButtonHandler(boolean isNext) {
		    this.isNext = isNext;
		    autoRepeatTimer = new javax.swing.Timer(60, this);
		    autoRepeatTimer.setInitialDelay(300);
		}
	
		private JSpinner eventToSpinner(AWTEvent e){
		    Object src = e.getSource();
		    while((src instanceof Component) && !(src instanceof JSpinner)){
			      src = ((Component)src).getParent();
		    }
		    
		    return (src instanceof JSpinner) ? (JSpinner)src : null;
		}
	
		public void actionPerformed(ActionEvent e){
		    if(spinner != null){
	           try{
	               spinner.commitEdit();
	               Object value = (isNext) ? spinner.getNextValue() : spinner.getPreviousValue();
	               
	               if(value != null) spinner.setValue(value);
               }
               catch(Exception iae){
               }
		    }
		}
	
		public void mousePressed(MouseEvent e) {
		    if (SwingUtilities.isLeftMouseButton(e) && e.getComponent().isEnabled()) {
			spinner = eventToSpinner(e);
			autoRepeatTimer.start();
		    }
		}
	
		public void mouseReleased(MouseEvent e) {
		    autoRepeatTimer.stop();	    
		    spinner = null;
		}
    }
}
