package se.diod.hippo.demo;


//import se.diod.swing.InstanceController;



/**
 * 
 * @author Robert Karlsson
 * @created 2003-okt-26
 *
 * @description This class starts the given demo application
 * 
 */
public class StartDemo {
	private static final int TESTAPP1	= 0;
	



	/**
	 * 
	 *
	 */
	public static void main( String[] args ) {
		new Demo1();
	}
}
