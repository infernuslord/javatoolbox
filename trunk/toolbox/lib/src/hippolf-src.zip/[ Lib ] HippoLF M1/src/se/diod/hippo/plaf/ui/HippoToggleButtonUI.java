/*
 * 
 * Created on 2004-jul-25
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.ui;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.metal.MetalToggleButtonUI;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-25
 *
 */
public class HippoToggleButtonUI extends MetalToggleButtonUI {
	private static final HippoToggleButtonUI INSTANCE = new HippoToggleButtonUI();




	/**
	 * 
	 * 
	 */
	public static ComponentUI createUI( JComponent c ) {
		return INSTANCE;
	}




	/**
	 * 
	 * 
	 */
	public void installUI( JComponent c ) {
		super.installUI( c );
	}




	/**
	 * 
	 * 
	 */
	public void uninstallUI( JComponent c ) {
		super.uninstallUI( c );
	}




	/**
	 * 
	 * 
	 */
	public void update( Graphics g, JComponent c ) {
		javax.swing.ButtonModel model = ((javax.swing.AbstractButton)c).getModel();
		AbstractButton b	= ( AbstractButton )c;
		Graphics g2			= g.create();

		if( c.isOpaque() ) {
			if( isToolBarButton( b ) ) {
				c.setBorder( se.diod.hippo.plaf.common.Border.getToolBarToggleButtonBorder() );
				c.setOpaque( false );
			} else {
				// Clear background..
				if( model.isEnabled() ) {
					g2.setColor( c.getBackground() );
					g2.fillRect( 0, 0, c.getWidth(), c.getHeight() );

					g2.setColor( new Color( 170, 170, 170 ) );
					g2.drawRect( 0, 0, c.getWidth()-1, c.getHeight()-1 );
				} else {
					c.setOpaque( false );
				}
			}
		} else {
			if( isToolBarButton( b ) ) {
				// Clear background..
				if( b.getModel().isRollover() ) {
					g2.setColor( javax.swing.UIManager.getColor( "Button.rolloverBackground" ) );
					g2.fillRect( 0, 0, c.getWidth(), c.getHeight() );

					g2.setColor( new Color( 170, 170, 170 ) );
					g2.drawRect( 0, 0, c.getWidth()-1, c.getHeight()-1 );
				}

			}
		}

		paint( g, c );
		g2.dispose();
	}




	/**
	 * 
	 * 
	 */
	protected void paintFocus( Graphics g, AbstractButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect) {}






	///////////////////////////////////////////////////
	//                 Helper methods                //
	///////////////////////////////////////////////////
	/**
	 * 
	 * Checks and answers if this button is in a tool bar.
	 * 
	 */
	protected static boolean isToolBarButton( AbstractButton b ) {
		java.awt.Container parent 		= b.getParent();
		return ( parent != null ) && ( parent instanceof javax.swing.JToolBar || parent.getParent() instanceof javax.swing.JToolBar );
	}
}
