/*
* Copyright (c) 2003, the JUNG Project and the Regents of the University
* of California
* All rights reserved.
*
* This software is open-source under the BSD license; see either
* "license.txt" or
* http://jung.sourceforge.net/license.txt for a description.
*/
package edu.uci.ics.jung.graph.impl;

import java.lang.ref.WeakReference;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import edu.uci.ics.jung.exceptions.FatalException;
import edu.uci.ics.jung.graph.ArchetypeEdge;
import edu.uci.ics.jung.graph.ArchetypeGraph;
import edu.uci.ics.jung.graph.ArchetypeVertex;
import edu.uci.ics.jung.graph.Edge;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.utils.GeneralUtils;
import edu.uci.ics.jung.utils.UserData;

/**
 * This class provides a skeletal implementation of the <code>Vertex</code>
 * interface to minimize the effort required to implement this interface.
 * It is appropriate for sparse graphs (those in which each vertex
 * is connected to only a few other vertices); for dense graphs (those in
 * which each vertex is connected to most other vertices), another
 * implementation might be more appropriate.
 * <P>
 * This class extends <code>UserData</code>, which provides storage and
 * retrieval mechanisms for user-defined data for each edge instance.
 * This allows users to attach data to edges without having to extend
 * this class.
 *
 * @author Scott White
 * @author Danyel Fisher
 * @author Joshua O'Madadhain
 *
 * @see AbstractSparseGraph
 * @see AbstractSparseEdge
 */
public abstract class AbstractSparseVertex extends UserData
    implements Vertex, Cloneable
{
    /**
     * The graph of which this vertex is an element.
     */
	private WeakReference m_Graph;

    /**
     * The next vertex ID.
     */
	private static int nextGlobalVertexID = 0;

    /**
     * Used to define vertex equivalence.
     */
	private int id = -1;


    /**
     * Creates a new instance of a vertex for inclusion
     * in a sparse graph.
     * Sets up the data necessary for definition of
     * vertex equivalence, and initializes the internal
     * data structures.
     *
     * @see #initialize()
     */
	protected AbstractSparseVertex() {
		this.id = nextGlobalVertexID++;		
		initialize();
	}


	/**
     * Attaches this vertex to the specified graph <code>g</code>.
	 */
	protected void addGraph_internal(AbstractSparseGraph g) {
		if (m_Graph == null ){
			this.m_Graph = new WeakReference(g) ;
		} else {
			throw new FatalException("Internal error: vertex " + this +
                " is already part of graph " + this.getGraph());
		}
	}


	/**
	 * @see ArchetypeVertex#getGraph()
	 */
	public ArchetypeGraph getGraph() {
	    if(  m_Graph == null ) {
	        return null;
	    }
	    ArchetypeGraph g = (ArchetypeGraph) m_Graph.get(); 
	    return g;
	}

	/**
	 * @see ArchetypeVertex#getNeighbors()
	 */
	public Set getNeighbors() {
		return Collections.unmodifiableSet(new HashSet(getNeighbors_internal()));
	}

    /**
     * 
     * @see edu.uci.ics.jung.graph.ArchetypeVertex#numNeighbors()
     */
    public int numNeighbors() {
        return getNeighbors_internal().size();
    }
    
	/**
	 * @see ArchetypeVertex#getIncidentEdges()
	 */
	public Set getIncidentEdges() {
		return Collections.unmodifiableSet(new HashSet(getEdges_internal()));
	}

	/**
	 * @see ArchetypeVertex#degree()
	 */
	public int degree() {
		return getEdges_internal().size();
	}

    /**
     * Returns <code>true</code> if <code>o</code> is an instance of
     * <code>ArchetypeVertex</code> that is equivalent to this vertex.
     * Respects the vertex
     * equivalences which are established by <code>copy()</code> and
     * referenced by <code>getEquivalentVertex()</code>.
     *
     * @see java.lang.Object#equals(java.lang.Object)
     * @see ArchetypeVertex#getEqualVertex(ArchetypeGraph)
     * @see ArchetypeVertex#copy
     */
    public boolean equals(Object o)
    {
        if (!(o instanceof ArchetypeVertex))
            return false;
        ArchetypeVertex v = (ArchetypeVertex)o;
        return (this == v.getEqualVertex(this.getGraph()));
    }

    /**
     * Returns the vertex in the specified graph <code>ag</code>
     * that is equivalent to this vertex.  If there is no
     * such vertex, or if <code>ag</code> is not an instance
     * of <code>AbstractSparseGraph</code>, returns <code>null</code>.
     *
     * @see ArchetypeVertex#getEqualVertex(ArchetypeGraph)
     */
    public ArchetypeVertex getEqualVertex(ArchetypeGraph ag)
    {
        if (ag instanceof AbstractSparseGraph)
        {
            AbstractSparseGraph asg = (AbstractSparseGraph)ag;
            return asg.getVertexByID(this.getID());
        }
        else
            return null;
    }

    /**
     * @deprecated As of version 1.4, renamed to getEqualVertex(ag).
     */
    public ArchetypeVertex getEquivalentVertex(ArchetypeGraph ag)
    {
        return getEqualVertex(ag);
    }
    
    
    /**
     * Returns the ID of this vertex.  This method is not intended
     * for general user access.
     */
    int getID()
    {
        return this.id;
    }

    /**
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode()
    {
        return GeneralUtils.hash(this.id);
    }

	/**
	 * @see ArchetypeVertex#isNeighborOf(ArchetypeVertex)
	 */
	public boolean isNeighborOf(ArchetypeVertex v) {
		return getNeighbors_internal().contains(v);
	}

	/**
	 * @see ArchetypeVertex#isIncident(ArchetypeEdge)
	 */
	public boolean isIncident(ArchetypeEdge e) {
		return getEdges_internal().contains(e);
	}

	/**
     * Returns the edge that connects this vertex to the specified
     * vertex <code>v</code>.  This is a
	 * simple implementation which checks the opposite vertex of
	 * each outgoing edge of this vertex; this solution is general,
     * but not efficient.
     *
	 * @see Vertex#findEdge(Vertex)
	 */
	public Edge findEdge(Vertex v) 
    {
		for (Iterator iter = getOutEdges().iterator(); iter.hasNext();) {
			Edge element = (Edge) iter.next();
			if (element.getOpposite(this).equals(v))
				return element;
		}
		return null;
	}

    public ArchetypeEdge findEdge(ArchetypeVertex v)
    {
        return this.findEdge((Vertex)v);
    }
    
    /**
     * @see Vertex#findEdgeSet(Vertex)
     */
	public Set findEdgeSet(Vertex v) 
    {
	    Set edgeSet = new HashSet();
		for (Iterator iter = getOutEdges().iterator(); iter.hasNext();) {
			Edge element = (Edge) iter.next();
			if (element.getOpposite(this).equals(v))
			    edgeSet.add( element );
		}
		return edgeSet;
	}
    
    public Set findEdgeSet(ArchetypeVertex v)
    {
        return this.findEdgeSet((Vertex)v);
    }
    
	/**
	 * @see Vertex#copy(ArchetypeGraph)
	 */
	public ArchetypeVertex copy(ArchetypeGraph newGraph) {
		
		if (newGraph == this.getGraph() )
			throw new IllegalArgumentException("Source and destination graphs " +
                "must be different");

		try {
			AbstractSparseVertex v = (AbstractSparseVertex) clone();
			v.initialize();
			v.importUserData(this);
			((Graph)newGraph).addVertex( v );
			return v;
		} catch (CloneNotSupportedException cne) {
			throw new FatalException("Can't copy vertex ", cne);
		}
	}

	/**
	 * Initializes all the data structures for this vertex.
     * (This is used on cloned vertices, since
     * <code>clone()</code> copies some information that should
     * not be in the new vertex.)
	 */
	protected void initialize() {
		m_Graph = null;
	}

	/**
	 * Returns a set containing all neighbors of this vertex.  This
     * is an internal method which is not intended for users.
	 */
	protected abstract Collection getNeighbors_internal();

	/**
	 * Returns a set containing all the incident edges of this vertex.
     * This is an internal method which is not intended for users.
	 */
	protected abstract Collection getEdges_internal();

	/**
     * Adds the specified edge <code>e</code> and vertex <code>v</code>
     * to the internal data structures of this vertex.
     *
	 * @param e    the new incident edge of this vertex
	 * @param v    the new neighbor of this vertex
	 */
	protected abstract void addNeighbor_internal(Edge e, Vertex v);

	/**
	 * Removes the specified edge <code>e</code> and vertex <code>v</code>
     * from the internal data structures of this vertex.
	 *
	 * @param e    the incident edge of this vertex which is being removed
	 * @param v    the neighbor of this vertex which is being removed
	 */
	protected abstract void removeNeighbor_internal(Edge e, Vertex v);

	/**
     * Cleans up internal data structures after this
     * edge is removed from a graph.
	 */
	protected void removeGraph_internal() {
		this.m_Graph = null;
	}

    /**
     * Returns a human-readable representation of this vertex.
     *
     * @see java.lang.Object#toString()
     */
	public String toString() {
		return "V" + String.valueOf(id);
	}

}
