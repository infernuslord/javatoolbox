/*
 * Copyright (c) 2003, the JUNG Project and the Regents of the University of
 * California All rights reserved.
 * 
 * This software is open-source under the BSD license; see either "license.txt"
 * or http://jung.sourceforge.net/license.txt for a description.
 */
package samples.graph;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;

import edu.uci.ics.jung.graph.Edge;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.utils.TestGraphs;
import edu.uci.ics.jung.visualization.*;
import edu.uci.ics.jung.visualization.Renderer;
import edu.uci.ics.jung.visualization.SpringLayout;
import edu.uci.ics.jung.visualization.contrib.CircleLayout;
import edu.uci.ics.jung.visualization.contrib.KKLayout;

public class ShowLayouts extends JApplet {

	/**
	 * 
	 * @author danyelf
	 */
	
	private static final class LayoutChooser implements ActionListener {
		private final JComboBox jcb;
		private final Graph g;
		private final GraphDraw gd;
		private LayoutChooser(JComboBox jcb, Graph g, GraphDraw gd) {
			super();
			this.jcb = jcb;
			this.g = g;
			this.gd = gd;
		}
		public void actionPerformed(ActionEvent arg0) {
			Object[] constructorArgs = { g };

			Class layoutC = (Class) jcb.getSelectedItem();
			System.out.println("Setting to " + layoutC);
			Class lay = layoutC;
			try {
				Constructor constructor =
					lay.getConstructor(constructorArgsWanted);
				Object o = constructor.newInstance(constructorArgs);
				Layout l = (Layout) o;
				gd.setGraphLayout(l);
				gd.restartLayout();
			} catch (Exception e) {
				System.out.println("Can't handle " + lay);
			}
		}
	}

	static final Class[] constructorArgsWanted = { Graph.class };

	public static void main(String[] args) {
		JPanel jp = getGraphPanel();
		
		JFrame jf = new JFrame();
		jf.getContentPane().add(jp);
		jf.pack();
		jf.show();
	}
	
	private static JPanel getGraphPanel() {
		Graph g = TestGraphs.getOneComponentGraph();
		GraphDraw gd = new GraphDraw(g);
		gd.setBackground(Color.WHITE);
		gd.setRenderer(new MyRenderer());
		gd.hideStatus();
		JPanel jp = new JPanel();
		jp.setBackground(Color.WHITE);
		jp.setLayout(new BorderLayout());
		jp.add(gd, BorderLayout.CENTER);
		Class[] combos = getCombos();
		final JComboBox jcb = new JComboBox(combos);
		jcb.setSelectedItem(SpringLayout.class);
		jcb.addActionListener(new LayoutChooser(jcb, g, gd));
		jp.add(jcb, BorderLayout.NORTH);
		return jp;
	}

	public void start() {
		this.getContentPane().add( getGraphPanel() );
	}
		

	/**
	 * @return
	 */
	private static Class[] getCombos() {
		List layouts = new ArrayList();
		layouts.add( KKLayout.class );
		layouts.add( FRLayout.class );
		layouts.add( CircleLayout.class );
		layouts.add( SpringLayout.class );
		layouts.add( ISOMLayout.class) ;
		return (Class[]) layouts.toArray( new Class[0] );
	}
	
	public static class MyRenderer implements Renderer {

		/**
		 * @see edu.uci.ics.jung.visualization.Renderer#paintVertex(java.awt.Graphics, edu.uci.ics.jung.graph.Vertex, int, int)
		 */
		public void paintVertex(Graphics g, Vertex v, int x, int y) {
			g.setColor( Color.black );
			g.fillOval(x-3, y-3, 6, 6);
		}

		/**
		 * @see edu.uci.ics.jung.visualization.Renderer#paintEdge(java.awt.Graphics, edu.uci.ics.jung.graph.Edge, int, int, int, int)
		 */
		public void paintEdge(Graphics g, Edge e, int x1, int y1, int x2, int y2) {
			g.setColor( Color.GRAY );
			g.drawLine(x1, y1, x2, y2);
		}

		/**
		 * @see edu.uci.ics.jung.visualization.Renderer#setPickedKey(edu.uci.ics.jung.visualization.PickedInfo)
		 */
		public void setPickedKey(PickedInfo pk) {
			// TODO Auto-generated method stub MyRenderer:setPickedKey
			
		}

	}
	

}
