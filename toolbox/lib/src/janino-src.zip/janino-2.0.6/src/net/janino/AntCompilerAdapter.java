
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino;

import java.io.File;
import java.io.IOException;
import java.util.StringTokenizer;

import net.janino.util.*;

import org.apache.tools.ant.taskdefs.compilers.*;
import org.apache.tools.ant.types.Path;

/**
 * A simple {@link CompilerAdapter} for the "ant" tool that silently ignores most of the
 * configuration parameters and attempts to compile all given source files into class files.
 */
public class AntCompilerAdapter extends DefaultCompilerAdapter {

    /**
     * Compile all source files in {@link #compileList} individually and write class
     * files in directory {@link #destDir}.
     * <p>
     * The following fields of {@link DefaultCompilerAdapter} are honored:
     * <ul>
     *   <li>{@link #compileList} - the set of Java<sup>TM</sup> source files to compile
     *   <li>{@link #destDir} - where to store the class files
     *   <li>{@link #compileSourcepath} - where to look for more Java<sup>TM</sup> source files
     *   <li>{@link #compileClasspath} - where to look for required classes
     *   <li>{@link #extdirs}
     *   <li>{@link #bootclasspath}
     *   <li>{@link #encoding} - how the Java<sup>TM</sup> source files are encoded
     *   <li>{@link #verbose}
     *   <li>{@link #debug}
     *   <li>{@link org.apache.tools.ant.taskdefs.Javac#getDebugLevel()}
     *   <li>{@link #src}
     * </ul>
     * The following fields of {@link DefaultCompilerAdapter} are not honored at this time:
     * <ul>
     *   <li>{@link #depend}
     *   <li>{@link #deprecation}
     *   <li>{@link #includeAntRuntime}
     *   <li>{@link #includeJavaRuntime}
     *   <li>{@link #location}
     *   <li>{@link #optimize}
     *   <li>{@link #target}
     * </ul>
     * @return "true" on success
     */
    public boolean execute() {

        // Convert source files into source file names.
        File[] sourceFiles = this.compileList;

        // Determine output directory.
        File optionalDestinationDirectory = this.destDir;

        // Determine the source path.
        File[] optionalSourcePath = AntCompilerAdapter.pathToFiles(
            this.compileSourcepath != null ?
            this.compileSourcepath :
            this.src
        );

        // Determine the class path.
        File[] classPath = AntCompilerAdapter.pathToFiles(this.compileClasspath, new File[] { new File(".") });

        // Determine the ext dirs.
        File[] optionalExtDirs = AntCompilerAdapter.pathToFiles(this.extdirs);

        // Determine the boot class path
        File[] optionalBootClassPath = AntCompilerAdapter.pathToFiles(this.bootclasspath);

        // Determine the encoding.
        String optionalCharacterEncoding = this.encoding;

        // Determine verbosity.
        boolean verbose = this.verbose;

        // Determine debugging information.
        int debuggingInformation;
        if (!this.debug) {
            debuggingInformation = Java.DEBUGGING_NONE;
        } else {
            String debugLevel = this.attributes.getDebugLevel();
            if (debugLevel == null) {
                debuggingInformation = Java.DEBUGGING_LINES | Java.DEBUGGING_SOURCE;
            } else {
                StringTokenizer st = new StringTokenizer(debugLevel, ",");
                debuggingInformation = Java.DEBUGGING_NONE;
                while (st.hasMoreTokens()) {
                    String token = st.nextToken();
                    if ("lines".equals(token)) {
                        debuggingInformation |= Java.DEBUGGING_LINES;
                    } else
                    if ("vars".equals(token)) {
                        debuggingInformation |= Java.DEBUGGING_VARS;
                    } else
                    if ("source".equals(token)) {
                        debuggingInformation |= Java.DEBUGGING_SOURCE;
                    } else {
                        ;
                    }
                }
            }
        }

        // Compile all source files.
        try {
            new Compiler(
                optionalSourcePath,
                classPath,
                optionalExtDirs,
                optionalBootClassPath,
                optionalDestinationDirectory,
                optionalCharacterEncoding,
                verbose,
                debuggingInformation,
                (StringPattern[]) null,  // optionalWarningHandlePatterns
                false                    // rebuild
            ).compile(sourceFiles);
        } catch (Scanner.ScanException e) {
            System.out.println(e.getMessage());
            return false;
        } catch (Parser.ParseException e) {
            System.out.println(e.getMessage());
            return false;
        } catch (Java.CompileException e) {
            System.out.println(e.getMessage());
            return false;
        } catch (IOException e) {
            System.out.println(e.getMessage());
            return false;
        }
        return true;
    }

    /**
     * Convert a {@link org.apache.tools.ant.types.Path} into an array of
     * {@link File}.
     * @param path
     * @return The converted path, or <code>null</code> if <code>path</code> is <code>null</code>
     */
    private static File[] pathToFiles(Path path) {
        if (path == null) return null;

        String[] fileNames = path.list();
        File[] files = new File[fileNames.length];
        for (int i = 0; i < fileNames.length; ++i) files[i] = new File(fileNames[i]);
        return files;
    }

    /**
     * Convert a {@link org.apache.tools.ant.types.Path} into an array of
     * {@link File}.
     * @param path
     * @param defaultValue
     * @return The converted path, or, if <code>path</code> is <code>null</code>, the <code>defaultValue</code>
     */
    private static File[] pathToFiles(Path path, File[] defaultValue) {
        if (path == null) return defaultValue;
        return AntCompilerAdapter.pathToFiles(path);
    }
}


