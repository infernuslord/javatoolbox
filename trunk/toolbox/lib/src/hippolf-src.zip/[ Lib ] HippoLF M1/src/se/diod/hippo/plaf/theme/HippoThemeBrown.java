/*
 * 
 * Created on 2004-jun-29
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.theme;




/**
 * 
 * Brown color: RGB(214,210,191)
 * 
 * @author Robert Karlsson
 * @created 2004-jun-29
 *
 */
public class HippoThemeBrown extends HippoTheme {




	/**
	 * 
	 * 
	 */
	public String getName() {
		return "Brown";
	}
}
