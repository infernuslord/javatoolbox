package phelps.io;

import java.io.InputStream;
import java.io.File;
import java.io.IOException;
import java.io.FileNotFoundException;



/**
	InputStream that reads from {@link RandomAccess}.

	@see FileInputStream
	@version $Revision: 1.1 $ $Date: 2003/06/12 17:46:06 $
*/
public class InputStreamRandomAccess extends InputStream {
  RandomAccess raf_;
  long mark_ = 0L;

  /**
	Creates InputStream that reads from <var>raf</var>.
  */
  public InputStreamRandomAccess(RandomAccess raf) {
	assert raf!=null;
	raf_ = raf;
  }

  /**
	Creates InputStream that reads from <var>file</var>.
	Input is buffered.
  */
  public InputStreamRandomAccess(File file) throws FileNotFoundException {
	assert file!=null;
	raf_ = new phelps.io.BufferedRandomAccessFile(file, "r");
  }

  public int read() throws IOException { return raf_.read(); }
  public int read(byte[] b) throws IOException { return raf_.read(b); }
  public int read(byte[] b, int off, int len) throws IOException { return raf_.read(b, off, len); }
  public long skip(long n) throws IOException {
	long off = raf_.getFilePointer();
	raf_.seek(off + n);
	return raf_.getFilePointer() - off;
  }

  // raf_ may be buffered, but no way to query
  public int available() throws IOException { return 0; }

  public void close() throws IOException { raf_.close(); raf_ = null; }

  public void mark(int readlimit) /*throws  IOException -- can't override*/ {
	try { mark_ = raf_.getFilePointer(); } catch (IOException ioe) {}
  }
  public void reset() throws IOException { raf_.seek(mark_); }
  public boolean markSupported() { return true; }
}
