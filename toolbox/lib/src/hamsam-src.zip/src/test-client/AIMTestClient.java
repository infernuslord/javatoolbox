/*
 *
 */

import java.io.*;
import java.util.*;
import hamsam.protocol.*;
import hamsam.api.*;
import hamsam.net.*;

/**
 * @author
 */
public class AIMTestClient {

    private Protocol[] protocols;

    /** AIM Test Client constructor
     * 
     * @throws Exception
     */
    public AIMTestClient() throws Exception {
        protocols = ProtocolManager.getAvailableProtocols();
        Protocol prot = protocols[0];
        prot.setListener(new AIMListener());

        //BufferedReader rd = new BufferedReader(new InputStreamReader(System.in));
        //System.out.print("Username: ");
        //String username = rd.readLine();
        String username = "xxxxx";
        String password = "xxxxx";

        //PasswordField passfield = new PasswordField();
        //String password = null;
        //try {
            //password = passfield.getPassword("Password: ");
        //} catch (IOException ioe) {
        //    ioe.printStackTrace();
        //}

        ProxyInfo info = new ProxyInfo();
        prot.connect(username, password, info);
        
    }

    /*
     * 
     */
    public static void main(String[] args) throws Exception {
        AIMTestClient client = new AIMTestClient();
        boolean done = false;

        while (!done) {
            String[] words = client.getCommand();
            done = client.processCommand(words);
        }
    }

    /*
     * 
     */
    private String[] getCommand() throws IOException {
        BufferedReader rd = new BufferedReader(new InputStreamReader(System.in));
        String line = rd.readLine();

        StringTokenizer tok = new StringTokenizer(line);
        String[] ret = new String[tok.countTokens()];
        for (int i = 0; tok.hasMoreTokens(); i++)
            ret[i] = tok.nextToken();

        return ret;
    }
    
    /*
     * 
     */
    private boolean processCommand(String[] words) throws Exception {
        if (words.length < 1)
            return false;

        if (words[0].equals("msg")) {
            if (words.length >= 3) {
                String msgText = new String();
                for (int i = 2; i < words.length; i++)
                    msgText += words[i] + " ";

                Buddy buddy = new Buddy(protocols[0], words[1]);
                Message msg = new Message();
                msg.addComponent(new TextComponent(msgText));

                protocols[0].sendInstantMessage(buddy, msg);
            }
        } else if (words[0].equals("add")) {
            if (words.length == 2) {
                Buddy buddy = new Buddy(protocols[0], words[1], "Friends");
                buddy.addToBuddyList();
            }
        } else if (words[0].equals("del")) {
            if (words.length == 2) {
                Buddy buddy = new Buddy(protocols[0], words[1], "Friends");
                buddy.deleteFromBuddyList();
            }
        } else if (words[0].equals("ign")) {
            if (words.length == 2) {
                Buddy buddy = new Buddy(protocols[0], words[1]);
                buddy.ignore();
            }
        } else if (words[0].equals("uign")) {
            if (words.length == 2) {
                Buddy buddy = new Buddy(protocols[0], words[1]);
                buddy.unignore();
            }
//        } else if (words[0].equals("cnf")) {
//            if (words.length > 2) {
//                Buddy myself = new Buddy(protocols[0], words[1]);
//                Buddy[] buddies = new Buddy[words.length - 1];
//                for (int i = 0; i < buddies.length; i++)
//                    buddies[i] = new Buddy(protocols[0], words[i + 1]);
//                String message = "Friends, Romans, and Countrymen, lend me your IMs";
//                conf = new Conference(protocols[0], myself, buddies, message);
//            }
//        } else if (words[0].equals("cmsg")) {
//            if (words.length == 2) {
//                Message msg = new Message();
//                msg.addComponent(new TextComponent(words[1]));
//
//                conf.sendMessage(msg);
//            }
//        } else if (words[0].equals("cnfq")) {
//            conf.quit();
        } else if (words[0].equals("off")) {
            protocols[0].disconnect();
            return true;
        }

        return false;
    }

}
