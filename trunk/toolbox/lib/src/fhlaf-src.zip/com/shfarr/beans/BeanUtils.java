/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.beans;

import java.util.List;

import com.shfarr.*;

public class BeanUtils{

    public static String getPropertyNameFor(Class c){
        String name = c.getName();

        if(name.indexOf(".") != -1) name = name.substring(name.lastIndexOf(".") + 1);

        return BasicUtils.changeCase(name, BasicUtils.CAPITAL_CASE);
    }

    public static String packPropertyName(String propertyName){
        String result = "";
        
        for(int i = 0; i < propertyName.length(); i++){
            if(propertyName.charAt(i) == ' ' || i == 0){
                if(i != 0) i++;
                char c = propertyName.charAt(i);
                result += (c >= 'a' && c <= 'z') ? (char) (((int)c) - 32) : c;
                continue;
            }
            else if(propertyName.charAt(i) == '-') result += '_';
            else result += propertyName.charAt(i);
        }
        
        return result;
    }

    public static String unpackPropertyName(String propertyName){
        StringBuffer result = new StringBuffer();
        
        for(int i = 0; i < propertyName.length(); i++){
            char c = propertyName.charAt(i);
            
            if(c >= 'A' && c <= 'Z'){
                if(i != 0) result.append(' ');
                result.append((c < 'a') ? (char) (((int)c) + 32) : c);
            }
            else if(c == '_') result.append('-'); 
            else result.append(c);
        }
        
        return result.toString();
    }

    public static PropertyHandler getHandler(Object object, String property){
        PropertyHandler[] handlers = getHandlers(object.getClass());
        
        for(int i = 0; i < handlers.length; i++){
            if(handlers[i].getProperty().getName().equals(property)){
                handlers[i].setObject(object);
                return handlers[i];
            }
        }
        
        return null;
    }

    public static PropertyHandler[] getHandlers(Object object){
        PropertyHandler[] handlers = getHandlers(object.getClass());
        
        for (int i = 0; i < handlers.length; i++) handlers[i].setObject(object);
        
        return handlers;
    }
    
    public static PropertyHandler[] getHandlers(Class type){
        List pd = Introspector.instance().getProperties(type);
        PropertyHandler[] handlers = new PropertyHandler[pd.size()];

        for (int i = 0; i < handlers.length; i++) handlers[i] = new PropertyHandler(((HeavyweightProperty)pd.get(i)), null);

        return handlers;
    }

    public static String getPackage(Class cls){
        String name = cls.getName();
        
        return name.lastIndexOf('.') != -1 ? name.substring(0, name.lastIndexOf('.')) : "";
    }

    public static String getName(Class cls){
        String name = cls.getName();
        
        return name.lastIndexOf('.') != -1 ? name.substring(name.lastIndexOf('.') +1) : name;
    }
    
    public static String capitalize(String str){
        char[] chars = str.toCharArray();
        if(chars[0] >= 'a' && chars[0] <= 'z') chars[0] -= 32;
        return String.copyValueOf(chars);
    }
    
    public static String decapitalize(String str){
        char[] chars = str.toCharArray();
        if(chars[0] >= 'A' && chars[0] <= 'Z') chars[0] += 32;
        return String.copyValueOf(chars);
    }
    
    public static String toString(Class type){
        String name = "";
        
        while(type.isArray()){
            name += "[]";
            type = type.getComponentType();
        }
        
        return type.getName() + name;
    }
}
