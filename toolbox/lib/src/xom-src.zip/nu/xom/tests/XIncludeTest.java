// Copyright 2002, 2003 Elliotte Rusty Harold
// 
// This library is free software; you can redistribute 
// it and/or modify it under the terms of version 2.1 of 
// the GNU Lesser General Public License as published by  
// the Free Software Foundation.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General 
// Public License along with this library; if not, write to the 
// Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
// Boston, MA  02111-1307  USA
// 
// You can contact Elliotte Rusty Harold by sending e-mail to
// elharo@metalab.unc.edu. Please include the word "XOM" in the
// subject line. The XOM home page is temporarily located at
// http://www.cafeconleche.org/XOM/  but will eventually move
// to http://www.xom.nu/

package nu.xom.tests;

import java.io.*;

import junit.framework.TestCase;

import nu.xom.*;
import nu.xom.xinclude.*;

/**
 * @author Elliotte Rusty Harold
 *
 */
public class XIncludeTest extends TestCase {

    // might want to test encoding heuristics on files in different encodings????

    public XIncludeTest(String name) {
        super(name);
    }

    private Builder builder;
    
    protected void setUp() {        
        builder = new Builder();       
    }

    public void test1() 
      throws ParseException, IOException, XIncludeException {
      
        File input = new File("data/xinclude/input/test.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        // For debugging
        /* File output = new File("data/xinclude/debug/test.xml");
        FileOutputStream out = new FileOutputStream(output);
        Serializer serializer = new Serializer(out);
        serializer.write(result); */
        Document expectedResult = builder.build(new File("data/xinclude/output/test.xml"));
        XMLAssert.assertEquals(result, expectedResult);
        
    }
    
    // from the XInclude CR
    public void testC1() 
      throws ParseException, IOException, XIncludeException {
      
        File input = new File("data/xinclude/input/c1.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        // For debugging
        /* File output = new File("data/xinclude/debug/c1.xml");
        FileOutputStream out = new FileOutputStream(output);
        Serializer serializer = new Serializer(out);
        serializer.write(result); */
        Document expectedResult = builder.build(new File("data/xinclude/output/c1.xml"));
        XMLAssert.assertEquals(result, expectedResult);
        
    }
    
    // from the XInclude CR
    public void testC2() 
      throws ParseException, IOException, XIncludeException {
      
        File input = new File("data/xinclude/input/c2.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        // For debugging
        /* File output = new File("data/xinclude/debug/c2.xml");
        FileOutputStream out = new FileOutputStream(output);
        Serializer serializer = new Serializer(out);
        serializer.write(result); */
        Document expectedResult = builder.build(new File("data/xinclude/output/c2.xml"));
        XMLAssert.assertEquals(result, expectedResult);
        
    }
    
    // from the XInclude CR
    public void testC3() 
      throws ParseException, IOException, XIncludeException {
      
        File input = new File("data/xinclude/input/c3.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        // For debugging
        /* File output = new File("data/xinclude/debug/c3.xml");
        FileOutputStream out = new FileOutputStream(output);
        Serializer serializer = new Serializer(out);
        serializer.write(result); */
        Document expectedResult = builder.build(new File("data/xinclude/output/c3.xml"));
        XMLAssert.assertEquals(result, expectedResult);
        
    }
    
    // C4 skipped for the moment because it uses XPointers
    // that I don't yet support

    // from the XInclude CR
    // Don't use this one yet, because there appear to be 
    // mistakes in the spec examples
    /*public void testC5() throws ParseException, IOException, XIncludeException {
      
        File input = new File("data/xinclude/input/c5.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        // For debugging
        File output = new File("data/xinclude/debug/c5.xml");
        FileOutputStream out = new FileOutputStream(output);
        Serializer serializer = new Serializer(out);
        serializer.write(result); 
        Document expectedResult = builder.build(new File("data/xinclude/output/c5.xml"));
        XMLAssert.assertEquals(result, expectedResult);
        
    } */
    
    public void testSiblingIncludes() 
      throws ParseException, IOException, XIncludeException {
      
        File input = new File("data/xinclude/input/paralleltest.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        // For debugging
        /* File output = new File("data/xinclude/debug/paralleltest.xml");
        FileOutputStream out = new FileOutputStream(output);
        Serializer serializer = new Serializer(out);
        // serializer.preserveBaseURI(true);
        serializer.write(result); */
        Document expectedResult = builder.build(new File("data/xinclude/output/paralleltest.xml"));
        XMLAssert.assertEquals(result, expectedResult);
        
    }
    
    public void testNamespaces() 
      throws ParseException, IOException, XIncludeException {
      
        File input = new File("data/xinclude/input/namespacetest.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        // For debugging
        /* File output = new File("data/xinclude/debug/namespacetest.xml");
        FileOutputStream out = new FileOutputStream(output);
        Serializer serializer = new Serializer(out);
        serializer.write(result); */
        Document expectedResult = builder.build(new File("data/xinclude/output/namespacetest.xml"));
        XMLAssert.assertEquals(result, expectedResult);
        
    }
    
    public void testNoInclusions() 
      throws ParseException, IOException, XIncludeException {
      
        File input = new File("data/xinclude/input/latin1.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        // For debugging
        /* File output = new File("data/xinclude/debug/latin1.xml");
        FileOutputStream out = new FileOutputStream(output);
        Serializer serializer = new Serializer(out);
        serializer.write(result); */
        Document expectedResult = builder.build(new File("data/xinclude/output/latin1.xml"));
        XMLAssert.assertEquals(result, expectedResult);
        
    }
    
    public void test2() 
      throws ParseException, IOException, XIncludeException {
      
        File input = new File("data/xinclude/input/simple.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        // For debugging
        /* File output = new File("data/xinclude/debug/simple.xml");
        FileOutputStream out = new FileOutputStream(output);
        Serializer serializer = new Serializer(out);
        serializer.write(result); */
        Document expectedResult = builder.build(new File("data/xinclude/output/simple.xml"));
        XMLAssert.assertEquals(result, expectedResult);
        
    }
    
    public void testReplaceRoot() 
      throws ParseException, IOException, XIncludeException {
      
        File input = new File("data/xinclude/input/roottest.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        // For debugging
        /* File output = new File("data/xinclude/debug/roottest.xml");
        FileOutputStream out = new FileOutputStream(output);
        Serializer serializer = new Serializer(out);
        serializer.write(result); */
        Document expectedResult = builder.build(new File("data/xinclude/output/roottest.xml"));
        XMLAssert.assertEquals(result, expectedResult);
        
    }
    
    public void testCircle1() 
      throws ParseException, IOException, XIncludeException {
        File input = new File("data/xinclude/input/circle1.xml");
        Document doc = builder.build(input);
        try {
            Document result = XIncluder.resolve(doc);
            fail("allowed parsed include of self");
        }
        catch (CircularIncludeException ex) {
            // success   
        }
    }
    
    public void testCircle2() 
      throws ParseException, IOException, XIncludeException {
        File input = new File("data/xinclude/input/circle2a.xml");
        Document doc = builder.build(input);
        try {
            Document result = XIncluder.resolve(doc);
            fail("allowed parsed include of self");
        }
        catch (CircularIncludeException ex) {
            // success   
        }
    }
    
    public void testMissingHref() 
      throws ParseException, IOException, XIncludeException {
        File input = new File("data/xinclude/input/missinghref.xml");
        Document doc = builder.build(input);
        try {
            Document result = XIncluder.resolve(doc);
            fail("allowed missing href");
        }
        catch (MissingHrefException ex) {
            // success   
        }
    }
    
    public void testBadParseAttribute() 
      throws ParseException, IOException, XIncludeException {
        File input = new File("data/xinclude/input/badparseattribute.xml");
        Document doc = builder.build(input);
        try {
            Document result = XIncluder.resolve(doc);
            fail("allowed bad parse attribute");
        }
        catch (BadParseAttributeException ex) {
            // success   
        }
    }
    
    public void testUnavailableResource() 
      throws ParseException, IOException, XIncludeException {
        File input = new File("data/xinclude/input/missingfile.xml");
        Document doc = builder.build(input);
        try {
            Document result = XIncluder.resolve(doc);
            fail("allowed unresolvable resource");
        }
        catch (IOException ex) {
            // success   
        }
    }
    
    public void testFallback() 
      throws ParseException, IOException, XIncludeException {
        File input = new File("data/xinclude/input/fallbacktest.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        Document expectedResult = builder.build(new File("data/xinclude/output/fallbacktest.xml"));
        XMLAssert.assertEquals(result, expectedResult);
    }
    
    public void testFallbackWithRecursiveInclude() 
      throws ParseException, IOException, XIncludeException {
        File input = new File("data/xinclude/input/fallbacktest2.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        Document expectedResult = builder.build(new File("data/xinclude/output/fallbacktest2.xml"));
        XMLAssert.assertEquals(result, expectedResult);
    }

    public void testEncodingAttribute() 
      throws ParseException, IOException, XIncludeException {
      
        File input = new File("data/xinclude/input/utf16.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        // For debugging
        /* File output = new File("data/xinclude/debug/utf16.xml");
        FileOutputStream out = new FileOutputStream(output);
        Serializer serializer = new Serializer(out);
        serializer.write(result); */
        Document expectedResult = builder.build(new File("data/xinclude/output/utf16.xml"));
        XMLAssert.assertEquals(result, expectedResult);
        
    }
    
    public void testXPointerBareNameID() 
      throws ParseException, IOException, XIncludeException {
      
        File input = new File("data/xinclude/input/xptridtest.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        // For debugging
        /* File output = new File("data/xinclude/debug/xptridtest.xml");
        FileOutputStream out = new FileOutputStream(output);
        Serializer serializer = new Serializer(out);
        serializer.write(result); */
        Document expectedResult = builder.build(new File("data/xinclude/output/xptridtest.xml"));
        XMLAssert.assertEquals(result, expectedResult);
        
    }
    
    public void testXPointerBareNameMatchesNothing() 
      throws ParseException, IOException, XIncludeException {
      
        File input = new File("data/xinclude/input/xptridtest2.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        // For debugging
        /* File output = new File("data/xinclude/debug/xptridtest2.xml");
        FileOutputStream out = new FileOutputStream(output);
        Serializer serializer = new Serializer(out);
        serializer.write(result); */
        Document expectedResult = builder.build(new File("data/xinclude/output/xptridtest2.xml"));
        XMLAssert.assertEquals(result, expectedResult);
        
    }
    
    public void testXPointerPureTumbler() 
      throws ParseException, IOException, XIncludeException {
      
        File input = new File("data/xinclude/input/xptrtumblertest.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        // For debugging
        /* File output = new File("data/xinclude/debug/xptrtumblertest.xml");
        FileOutputStream out = new FileOutputStream(output);
        Serializer serializer = new Serializer(out);
        serializer.write(result); */
        Document expectedResult = builder.build(new File("data/xinclude/output/xptrtumblertest.xml"));
        XMLAssert.assertEquals(result, expectedResult);
        
    }

    public void testXPointerTumblerMatchesNothing() 
      throws ParseException, IOException, XIncludeException {
      
        File input = new File("data/xinclude/input/xptrtumblertest2.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        // For debugging
        /*File output = new File("data/xinclude/debug/xptrtumblertest2.xml");
        FileOutputStream out = new FileOutputStream(output);
        Serializer serializer = new Serializer(out);
        serializer.write(result);  */
        Document expectedResult = builder.build(new File("data/xinclude/output/xptridtest2.xml"));
        XMLAssert.assertEquals(result, expectedResult);
        
    }
    
    public void testMalformedXPointer() 
      throws ParseException, IOException, XIncludeException {
      
        try {
            File input = new File("data/xinclude/input/badxptr.xml");
            Document doc = builder.build(input);
            Document result = XIncluder.resolve(doc);
        }
        catch (XIncludeException ex) {
            // success   
        }
        
    }
    
    public void testMalformedXPointerWithFallback() 
      throws ParseException, IOException, XIncludeException {
      
        File input = new File("data/xinclude/input/xptrfallback.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        // For debugging
        /* File output = new File("data/xinclude/debug/xptrfallback.xml");
        FileOutputStream out = new FileOutputStream(output);
        Serializer serializer = new Serializer(out);
        serializer.write(result); */
        Document expectedResult = builder.build(new File("data/xinclude/output/xptrfallback.xml"));
        XMLAssert.assertEquals(result, expectedResult);
                
    }
    
    public void testIDAndTumbler() 
      throws ParseException, IOException, XIncludeException {
      
        File input = new File("data/xinclude/input/xptridandtumblertest.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        // For debugging
        File output = new File("data/xinclude/debug/xptridandtumblertest");
        FileOutputStream out = new FileOutputStream(output);
        Serializer serializer = new Serializer(out);
        serializer.write(result);
        Document expectedResult = builder.build(new File("data/xinclude/output/xptridandtumblertest.xml"));
        XMLAssert.assertEquals(result, expectedResult);
                
    }

    public void testAutoDetectUTF16BigEndianWithByteOrderMark() 
      throws ParseException, IOException, XIncludeException {
      
        File input = new File("data/xinclude/input/UTF16BigEndianWithByteOrderMark.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        // For debugging
        File output = new File("data/xinclude/debug/UTF16BigEndianWithByteOrderMark.xml");
        FileOutputStream out = new FileOutputStream(output);
        Serializer serializer = new Serializer(out);
        serializer.write(result);
        Document expectedResult = builder.build(new File("data/xinclude/output/UTF16BigEndianWithByteOrderMark.xml"));
        XMLAssert.assertEquals(result, expectedResult);
                
    }

    public void testAutoDetectUTF16LittleEndianWithByteOrderMark() 
      throws ParseException, IOException, XIncludeException {
      
        File input = new File("data/xinclude/input/UTF16LittleEndianWithByteOrderMark.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        // For debugging
        File output = new File("data/xinclude/debug/UTF16LittleEndianWithByteOrderMark.xml");
        FileOutputStream out = new FileOutputStream(output);
        Serializer serializer = new Serializer(out);
        serializer.write(result);
        Document expectedResult = builder.build(new File("data/xinclude/output/UTF16LittleEndianWithByteOrderMark.xml"));
        XMLAssert.assertEquals(result, expectedResult);
                
    }

    public void testAutoDetectUTF8WithByteOrderMark() 
      throws ParseException, IOException, XIncludeException {
      
        File input = new File("data/xinclude/input/UTF8WithByteOrderMark.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        // For debugging
        File output = new File("data/xinclude/debug/UTF8WithByteOrderMark.xml");
        FileOutputStream out = new FileOutputStream(output);
        Serializer serializer = new Serializer(out);
        serializer.write(result);
        Document expectedResult = builder.build(new File("data/xinclude/output/UTF8WithByteOrderMark.xml"));
        XMLAssert.assertEquals(result, expectedResult);
                
    }

  // Turn off these tests because Java doesn't support UCS4 yet
 /*   public void testAutoDetectUCS4BE() 
      throws ParseException, IOException, XIncludeException {
      
        File input = new File("data/xinclude/input/UCS4BE.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        // For debugging
        File output = new File("data/xinclude/debug/UCS4BE.xml");
        FileOutputStream out = new FileOutputStream(output);
        Serializer serializer = new Serializer(out);
        serializer.write(result);
        Document expectedResult = builder.build(new File("data/xinclude/output/UTF8WithByteOrderMark.xml"));
        XMLAssert.assertEquals(result, expectedResult);
                
    }

    public void testAutoDetectUCS4LE() 
      throws ParseException, IOException, XIncludeException {
      
        File input = new File("data/xinclude/input/UCS4LE.xml");
        Document doc = builder.build(input);
        Document result = XIncluder.resolve(doc);
        // For debugging
        File output = new File("data/xinclude/debug/UCS4LE.xml");
        FileOutputStream out = new FileOutputStream(output);
        Serializer serializer = new Serializer(out);
        serializer.write(result);
        Document expectedResult = builder.build(new File("data/xinclude/output/UTF8WithByteOrderMark.xml"));
        XMLAssert.assertEquals(result, expectedResult);
                
    } */

}
