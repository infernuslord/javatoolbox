package org.codehaus.classworlds;

/**
 * @author <a href="bwalding@jakarta.org">Ben Walding</a>
 * @version $Id: UberJarRealmClassLoaderTestMain.java,v 1.1.1.1 2003/07/29 04:38:07 bob Exp $
 */
public class UberJarRealmClassLoaderTestMain
{
    public static void main(String args[]) {
    }
}
