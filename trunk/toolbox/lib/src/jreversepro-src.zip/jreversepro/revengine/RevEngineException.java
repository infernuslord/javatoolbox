/**
  * @(#)RevEngineException.java
  *
  * JReversePro - Java Decompiler / Disassembler.
  * Copyright (C) 2000 2001 Karthik Kumar.
  * EMail: akkumar@users.sourceforge.net
  *
  * This program is free software; you can redistribute it and/or modify
  * it , under the terms of the GNU General Public License as published
  * by the Free Software Foundation; either version 2 of the License,
  * or (at your option) any later version.
  *
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  * See the GNU General Public License for more details.
  * You should have received a copy of the GNU General Public License
  * along with this program.If not, write to
  *  The Free Software Foundation, Inc.,
  *  59 Temple Place - Suite 330,
  *  Boston, MA 02111-1307, USA.
  **/
package jreversepro.revengine;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.IOException;

import jreversepro.runtime.JCodeBuffer;

public class RevEngineException extends Exception {
    String mMsg;

    public RevEngineException(String aMsg) {
        mMsg = aMsg;
    }

    public RevEngineException( String aMsg, Exception ex ) {
        ByteArrayOutputStream baos =
                            new ByteArrayOutputStream();
        PrintStream ps  =  new PrintStream ( baos );
        ex.printStackTrace( ps );
        mMsg = aMsg + "\n" + new String(baos.toByteArray()) + "\n";
        ps.close();
    }

    public RevEngineException( String aMsg, Exception ex,
                                JCodeBuffer cb ) {
        ByteArrayOutputStream baos =
                            new ByteArrayOutputStream();
        PrintStream ps  =  new PrintStream ( baos );
        ex.printStackTrace( ps );
        mMsg = aMsg + "\n" + new String(baos.toByteArray())
                + "\n" + cb.toString();


        ps.close();
    }

    public String toString() {
        return ( "jreversepro.revengine.RevEngineException :\n"  +
                    mMsg ) ;
    }
}
