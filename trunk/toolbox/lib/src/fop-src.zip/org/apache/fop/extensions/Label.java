/*
 * $Id: Label.java,v 1.2.2.4 2003/01/11 21:17:40 jeremias Exp $
 * Copyright (C) 2001-2003 The Apache Software Foundation. All rights reserved.
 * For details on use and redistribution please refer to the
 * LICENSE file included with these sources.
 */

package org.apache.fop.extensions;

import org.apache.fop.fo.*;


/**
 * Class representing destinations or targets within a document (/Dest
 * objects in PDF, called "Destinations" in Adobe Acrobat). Used for the
 * bookmark/outline extension.
 */
public class Label extends ExtensionObj {
    private StringBuffer textBuffer;

    public static class Maker extends FObj.Maker {
        public FObj make(FObj parent, PropertyList propertyList) {
            return new Label(parent, propertyList);
        }

    }

    public static FObj.Maker maker() {
        return new Label.Maker();
    }

    public Label(FObj parent, PropertyList propertyList) {
        super(parent, propertyList);
    }

    protected void addCharacters(char data[], int start, int length) {
        if (textBuffer==null) {
            textBuffer = new StringBuffer();
        }
        textBuffer.append(data,start,length);
    }

    public String toString() {
        if (textBuffer != null) {
            return textBuffer.toString();
        } else {
            return null;
        }
    }

    public String getName() {
        return "fop:label";
    }

}
