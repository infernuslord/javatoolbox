package multivalent.net;

import multivalent.Behavior;
import multivalent.Document;
import multivalent.DocInfo;
import multivalent.SemanticEvent;
import multivalent.node.LeafAscii;



/**
	Handle return HTTP code.

	@version $Revision: 1.3 $ $Date: 2003/06/02 05:22:55 $
*/
public class ReturnCode extends Behavior {
  static final boolean DEBUG = false;

  int redirectcnt_=0;
  private boolean eat_=false;

  public boolean semanticEventBefore(SemanticEvent se, String msg) {
	if (super.semanticEventBefore(se,msg)) return true;
	Object arg=se.getArg();
	if (Document.MSG_OPENED==msg && arg instanceof DocInfo) {
		DocInfo di = (DocInfo)arg;
//System.out.println("*** return code = "+di.returncode+" ***");

		int code = di.returncode;
		if (DEBUG && code != 200 /*&& code>0*/) {
			new LeafAscii(di.returncode+" "+di.uri,null, di.doc);
		}
//System.out.println("return code = "+code+" / "+di.uri);

/* for the moment, 301 and 302 still done in Cache
		if (code!=301 && code!=302) redirectcnt_=0;
		switch (code) { // could use HttpURLConnection constants for these
		case 301:
		case 302:
			redirectcnt_++;
System.out.println("redirecting to "+hcon.getHeaderField("Location"));
			if (redirectcnt_>10) { redirectcnt_=0; throw new IOException("Too many redirects"); }
			di.uri = new URL(di.uri, con.getHeaderField("Location"));
			con.getInputStream().close();	// right way to close a connection?
			return getInputStream(ci, filename, type);
		case 304:	// not modified (sent "If-Modified-Since")
			con.getInputStream().close();
			return getInputStream(ci, filename, type);
/* show error message from server?	does server send one for each of these?
		default:	// error messages for everything else
			String overridemsg = "ERROR, return code "+code+"	 ";
			switch (code) {
			case 201: overridemsg += "Created"; break;
			case 202: overridemsg += "Accepted"; break;
			case 204: overridemsg += "No Content"; break;
			//case 304: overridemsg += "Not Modified"; break;
			case 400: overridemsg += "Bad Request"; break;
			case 401:
				overridemsg += "Unauthorized";
				for (int i=1; ; i++) {	// 0th field is return code
					String key=con.getHeaderFieldKey(i);
					if (key==null) break;
					String value=con.getHeaderField(i);
System.out.println("<header |"+key+"| = |"+value+"|");
				}
				break;
			case 403: overridemsg += "Forbidden"; break;
			case 404: {
				if (signature!=null) { di.genre = "HTML"; return new StringBufferInputStream(robustSearch("404 Error - Page not found", url, signature));
				} else overridemsg += "Not Found";
				break;
			}
			case 500: overridemsg += "Internal Server Error"; break;
			case 501: overridemsg += "Not Implemented"; break;
			case 502: overridemsg += "Bad Gateway"; break;
			case 503: overridemsg += "Service Unavailable"; break;
			}
			throw new IOException(overridemsg);
		}
*/

		// 200 = ignore
		// 3xx = redirect
		// 400 = leave for Robust -- or maybe "http://ww."=>"http://www."
	}
	return false;
  }

  public boolean semanticEventAfter(SemanticEvent se, String msg) {
	if (Document.MSG_OPENED==msg && eat_) { eat_=false; return true; }
	return false;
  }
}
