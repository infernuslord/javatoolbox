/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of pdfbox; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui;

import java.net.URL;
import java.util.*;
import javax.swing.*;
import javax.swing.tree.*;
import com.shfarr.BasicUtils;
import com.shfarr.DevUtils;
import com.shfarr.beans.BeanUtils;

import java.awt.*;
import java.awt.event.ActionListener;

public class UIUtils{
    /**
     * GraphicUtils constructor comment.
     */
    public UIUtils(){
        super();
    }

    public static JComponent createButton(String action, ActionListener al){
        if(action.equals("--")){
            JSeparator separator = new JSeparator(JSeparator.VERTICAL);
            return separator;
        }
        else{
            AbstractButton button = action.indexOf("|") != -1 ? (AbstractButton)new JToggleButton(action) : (AbstractButton)new JButton(action);

            button.setText("");
            button.setActionCommand(action);
            button.setFocusable(false);
            button.setToolTipText(action);
            action = action.toLowerCase();
            
            if(al != null) button.addActionListener(al);
            
            try{
                button.setIcon(createIcon(action));
            }
            catch (Exception e){
                System.out.println("Caught unhandled exception: " + e);
            }

            button.setMargin(new Insets(1, 1, 1, 1));
            button.setRolloverEnabled(true);

            return button;
        }
    }
    
    public static ImageIcon createIcon(String action){
        String[] tokens = BeanUtils.unpackPropertyName(action).split(" ");
        
        URL url = ClassLoader.getSystemResource("cres/actions/" + action + ".png");
        
        return new ImageIcon(url);
    }
    
    public static Component[] createMenuTree(JMenu root, Object[] commands, ActionListener listener){
        return createMenuTree(root, commands, commands, listener);
    }
    
    public static Component[] createMenuTree(JMenu root, Object[] texts, Object[] commands, ActionListener listener){
        if(root == null) root = new JMenu();

        ButtonGroup currentGroup = new ButtonGroup();

        for(int i = 0; i < commands.length; i++){
            if(commands[i] == null) continue;

            String[] cmdpath = BasicUtils.unpack(texts[i].toString(), '/', false);

            JComponent cMenu = root, newItem = null;

            for(int u = 0; u < cmdpath.length; u++){
                if(u < cmdpath.length - 1){
                    newItem = null;

                    for(int k = 0; k < ((JMenu)cMenu).getItemCount(); k++){
                        if(((JMenu)cMenu).getItem(k) instanceof JMenu
                           && ((JMenu)cMenu).getItem(k).getText().trim().equalsIgnoreCase(cmdpath[u])) newItem = ((JMenu)cMenu).getItem(k);
                    }

                    if(newItem == null){
                        newItem = new JMenu(cmdpath[u]);
                        if(currentGroup.getElements().hasMoreElements()) currentGroup = new ButtonGroup();
                    }

                    ((JMenu)cMenu).add(newItem);
                    cMenu = newItem;
                }
                else{
                    if(cmdpath[u].equals("--")){
                        newItem = new JSeparator();
                        ((JMenu)cMenu).add(newItem);
                        if(currentGroup.getElements().hasMoreElements()) currentGroup = new ButtonGroup();
                    }
                    else{
                        if(cmdpath[u].startsWith("&( )")){
                            newItem = new JRadioButtonMenuItem(cmdpath[u].substring(4), false);
                            currentGroup.add((AbstractButton)newItem);
                        }
                        else if(cmdpath[u].startsWith("&(o)")){
                            newItem = new JRadioButtonMenuItem(cmdpath[u].substring(4), true);
                            currentGroup.add((AbstractButton)newItem);
                        }
                        else if(cmdpath[u].startsWith("&[ ]")) newItem = new JCheckBoxMenuItem(cmdpath[u].substring(4), false);
                        else if(cmdpath[u].startsWith("&[x]")) newItem = new JCheckBoxMenuItem(cmdpath[u].substring(4), true);
                        else newItem = new JMenuItem(cmdpath[u]);

                        String command = BasicUtils.replaceString(commands[i].toString(), "&( )", "");
                        command = BasicUtils.replaceString(command.toString(), "&(o)", "");
                        command = BasicUtils.replaceString(command.toString(), "&[ ]", "");
                        command = BasicUtils.replaceString(command.toString(), "&[x]", "");

                        ((AbstractButton)newItem).setActionCommand(command);
                        ((AbstractButton)newItem).addActionListener(listener);
                        ((JMenu)cMenu).add((AbstractButton)newItem);
                    }
                }
            }
        }

        return root.getMenuComponents();
    }

    public static JButton[] createSimpleButtonSet(String[] text, ActionListener al){
        JButton[] buttons = new JButton[text.length];

        for(int i = 0; i < buttons.length; i++){
            buttons[i] = new JButton(text[i]);
            buttons[i].addActionListener(al);
            buttons[i].setDefaultCapable(true);
            
            try{
                buttons[i].setIcon(new ImageIcon(ClassLoader.getSystemResource("cres/actions/" + text[i].replace('|', '.').toLowerCase() + ".png")));
            }
            catch(Exception e){
            	DevUtils.handleException("ui", "UIUTils, cause: " + "cres/actions/" + text[i].replace('|', '.').toLowerCase() + ".png", e);
            }
        }

        return buttons;
    }

    public static DefaultMutableTreeNode createTree(Object[] components){
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("root"), actualRoot = root;

        for(int i = 0; i < components.length; i++){
            StringTokenizer st = new StringTokenizer(components[i].toString(), "/", false);

            for(int index = 0; st.hasMoreTokens(); index++){
                String ct = st.nextToken();

                DefaultMutableTreeNode cNode = lookupChildContaining(root, ct);
                if(cNode == null){
                    cNode = new DefaultMutableTreeNode(ct);
                    root.add(cNode);
                }

                root = cNode;
            }

            root = actualRoot;
        }

        return root;
    }

    public static void drawDashedRect(java.awt.Graphics g, int x, int y, int width, int height){
        drawDashedRect(g, x, y, width, height, 3);
    }

    public static void drawDashedRect(java.awt.Graphics g, int x, int y, int width, int height, int gap){
        int vx, vy;

        // draw upper and lower horizontal dashes
        for(vx = x; vx < (x + width); vx += gap){
            g.drawLine(vx, y, vx, y);
            g.drawLine(vx, y + height - 1, vx, y + height - 1);
        }

        // draw left and right vertical dashes
        for(vy = y; vy < (y + height); vy += gap){
            g.drawLine(x, vy, x, vy);
            g.drawLine(x + width - 1, vy, x + width - 1, vy);
        }
    }

    public static void drawRevertedDashedRect(java.awt.Graphics g, int x, int y, int width, int height){
        int vx, vy;

        // draw upper and lower horizontal dashes
        for(vx = x; vx < (x + width); vx += 2){
            g.drawLine(vx, y, vx, y);
            g.drawLine(vx, y + height - 1, vx, y + height - 1);
        }

        // draw left and right vertical dashes
        for(vy = y; vy < (y + height); vy += 2){
            g.drawLine(x, vy, x, vy);
            g.drawLine(x + width - 1, vy, x + width - 1, vy);
        }
    }

    public static void expandPaths(Vector paths, JTree tree, String toSelect){
        if(paths == null) return;
        DefaultMutableTreeNode root = (DefaultMutableTreeNode)tree.getModel().getRoot(), lastNode = null;

        TreePath rp = null;
        String cToken = null;

        for(int i = 0; i < paths.size(); i++){
            StringTokenizer st = new StringTokenizer(paths.get(i).toString(), "/:", false);
            st.nextToken();
            lastNode = root;

            while(st.hasMoreTokens()){
                cToken = st.nextToken();
                if(lookupChildNamed(lastNode, cToken) == null) break;
                lastNode = lookupChildNamed(lastNode, cToken);
            }

            rp = new TreePath(((DefaultTreeModel)tree.getModel()).getPathToRoot(lastNode));
            tree.expandPath(rp);
        }

        setSelectedPath(tree, toSelect);
    }

    public static DefaultMutableTreeNode lookupChildContaining(DefaultMutableTreeNode node, Object content){
        //debug: System.out.println(content + " : " + node.getUserObject() + " :~: " + content.equals(node.getUserObject()));
        if(content.equals(node.getUserObject())) return node;
        
        DefaultMutableTreeNode ans = null;
        
        for(int i = 0; i < node.getChildCount() && ans == null; i ++){
            ans = lookupChildContaining((DefaultMutableTreeNode)node.getChildAt(i), content);
        }
        
        return ans;
    }

    public static DefaultMutableTreeNode lookupChildNamed(DefaultMutableTreeNode node, String name){

        for(Enumeration children = node.children(); children.hasMoreElements(); ){
            DefaultMutableTreeNode chNode = (DefaultMutableTreeNode)children.nextElement();
            boolean eval = name.equals(chNode.toString().trim());
            if(eval) return chNode;
        }

        return null;
    }

    public static Vector lookupExpandedPaths(JTree tree){
        Vector exp = null;

        exp = new Vector();
        for(Enumeration e = tree.getExpandedDescendants(new TreePath(tree.getModel().getRoot())); e.hasMoreElements(); exp
                .add(treePath2String((TreePath)e.nextElement())));

        return exp;
    }

    public static String selectionPathAsString(JTree tree){
        return treePath2String(tree.getSelectionPath());
    }

    public static void setSelectedPath(JTree tree, String toSelect){
        StringTokenizer st = new StringTokenizer(toSelect, "/:", false);
        st.nextToken();

        DefaultMutableTreeNode lastNode = (DefaultMutableTreeNode)tree.getModel().getRoot();
        TreePath rp = null;

        while(st.hasMoreTokens()){
            lastNode = UIUtils.lookupChildNamed(lastNode, st.nextToken());
            if(lastNode == null) break;
            rp = new TreePath(((DefaultTreeModel)tree.getModel()).getPathToRoot(lastNode));
        }

        tree.setSelectionPath(rp);
    }

    public static String treePath2String(TreePath treePath){
        String str = "";
        Object[] path = treePath.getPath();

        for(int i = 0; i < path.length; i++)
            str += path[i].toString().trim() + (i == path.length - 1 ? "" : "/");

        return str;
    }
}
