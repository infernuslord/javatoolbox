package phelps.io;

import java.io.IOException;



/**
	File-like objects that support random access.

	Potentially conflicts with {@link java.util.RandomAccess}, but seldom in practice.
*/
public interface RandomAccess {

/**
ByteArrayInputStream:

int available()
 void close()
 void mark(int readAheadLimit)
 boolean markSupported()
 int read()
 int read(byte[] b, int off, int len)
 void reset()
 long skip(long n)


RandomAccessFile

void close()
 FileChannel getChannel()
 FileDescriptor getFD()
 long getFilePointer()
 long length()
 int read()
 int read(byte[] b)
 int read(byte[] b, int off, int len)
 boolean readBoolean()
 byte readByte()
 char readChar()
 double readDouble()
 float readFloat()
 void readFully(byte[] b)
 void readFully(byte[] b, int off, int len)
 int readInt()
 String readLine()
 long readLong()
 short readShort()
 int readUnsignedByte()
 int readUnsignedShort()
 String readUTF()
 void seek(long pos)
 void setLength(long newLength)
 int skipBytes(int n)
 void writeBoolean(boolean v)
 void writeByte(int v)
 void writeBytes(String s)
 void writeChar(int v)
 void writeChars(String s)
 void writeDouble(double v)
 void writeFloat(float v)
 void writeInt(int v)
 void writeLong(long v)
 void writeShort(int v)
 void writeUTF(String str)
*/

  void seek(long pos) throws IOException; // and/or mark/reset
  long getFilePointer() throws IOException;
  long length() throws IOException;
  int skipBytes(int n) throws IOException;

  int read() throws IOException;
  int read(byte[] b, int off, int len) throws IOException;
  int read(byte[] b) throws IOException;

  void readFully(byte[] b) throws IOException;
  void readFully(byte[] b, int off, int len) throws IOException;

  void write(byte[] b) throws IOException;
  void write(byte[] b, int off, int len) throws IOException;
  void write(int b) throws IOException;

  void close() throws IOException;
}
