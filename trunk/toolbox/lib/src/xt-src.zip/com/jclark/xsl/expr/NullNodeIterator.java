// $Id: NullNodeIterator.java,v 1.1 2002/04/25 18:10:01 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

public class NullNodeIterator implements NodeIterator {
    public Node next() { return null; }
}
