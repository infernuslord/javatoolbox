/*
 *
 * Hamsam - Instant Messaging API
 *
 * Copyright (C) 2003 Mike Miller <mikemil@users.sourceforge.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 */

package hamsam.protocol.aim;

import java.io.IOException;
import java.net.SocketException;
import java.util.Vector;
import java.util.logging.Logger;

    
import hamsam.net.Connection;
import hamsam.util.log.LogManager;

import hamsam.protocol.aim.command.Command;
import hamsam.protocol.aim.command.CommandEvent;


/**
 * A thread to receive all incoming data from AIM.
 *
 */
public class AIMReaderThread extends Thread {
    
    Logger log = LogManager.getLogger();

    //~ Instance fields ----------------------------------------------------------------------------
    /**
     * The connection used for reading.
     */
    private Connection conn;
    /**
     * The buffer to which to write.
     */
    private Vector buffer;
    /**
     * Flag to stop this thread.
     */
    private boolean quit;

    //~ Constructors -------------------------------------------------------------------------------
    /**
     * Construct a new reader thread which reads from a specified connection and
     * writes to a specified buffer.
     *
     * @param conn the connection for reading.
     * @param buffer the buffer to which to put the packets.
     */
    public AIMReaderThread(Connection conn, Vector buffer) {
        this.conn       = conn;
        this.buffer     = buffer;
        this.quit       = false;
        setName("hamsam.protocol.aim.AIMReaderThread");
        setDaemon(true);
    }

    //~ Methods ------------------------------------------------------------------------------------
    /**
     * Change the connection object and start using a new one. This
     * will close the old connection if it is not already closed.
     *
     * @param conn the new connection object.
     */
    public void changeConnection(Connection conn) {

        synchronized (this.conn) {

            try {
                this.conn.close();
            } catch (IOException e) {

                /* we may get an exception because the connection is already closed */
            }

            this.conn = conn;
        }
    }


    /**
     * The thread starts here.
     */
    public void run() {

        while (!quit) {

  
            Command cmd = null;
            try {
                cmd = Command.getCommand(conn);
            } catch(SocketException e ) {
                //log.severe("SocketException caught!, breaking out of reader thread", e);
                break;      
            } catch(InterruptedException e) {
                log.severe("reader interrupted");
                break;
            } catch (IllegalStateException e) {
                log.severe("IllegalStateException caught");
            } catch (IOException e) {
                log.severe("IOException caught");
            } 

            synchronized (buffer) {

                if (cmd != null) {
                    buffer.add(new CommandEvent(cmd));
                    buffer.notify();
                }
            }
        }
    }


    /**
     * Stop this thread safely.
     */
    public void stopReading() {
        quit = true;
        this.interrupt();
    }
}
