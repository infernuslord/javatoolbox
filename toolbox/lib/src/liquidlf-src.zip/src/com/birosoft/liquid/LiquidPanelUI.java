/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	Liquid Look and Feel                                                   *
*                                                                              *
*  Author, Miroslav Lazarevic                                                  *
*                                                                              *
*   For licensing information and credits, please refer to the                 *
*   comment in file com.birosoft.liquid.LiquidLookAndFeel                      *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package com.birosoft.liquid;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.*;
import javax.swing.plaf.basic.*;
import java.awt.*;
import java.awt.event.*;


public class LiquidPanelUI extends BasicPanelUI {

    // Shared UI object
    private static LiquidPanelUI panelUI;

    public static ComponentUI createUI(JComponent c) {
	if(panelUI == null) {
            panelUI = new LiquidPanelUI();
	}
        return panelUI;
    }

    public void installUI(JComponent c) {
        JPanel p = (JPanel)c;
        super.installUI(p);
        installDefaults(p);
    }

    public void uninstallUI(JComponent c) {
        super.uninstallUI(c);

    }
    
    public void paint(Graphics g, JComponent c)
    {
        
        if (g.getColor().equals(LiquidLookAndFeel.getBackgroundColor()))
        {            
            g.setColor(new Color(238,237,236));
            int i = 0;
            int height = c.getHeight();
            while (i < height)
            {
                g.drawLine(0, i, c.getWidth()-1, i);
                i++;
                g.drawLine(0, i, c.getWidth()-1, i);
                i += 3;
            }
        }
        super.paint(g, c);
    }

}
