/*
 *
 * Hamsam - Instant Messaging API
 *
 * Copyright (C) 2003 Mike Miller <mikemil@users.sourceforge.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 */

package hamsam.protocol.aim.command;

import hamsam.exception.IllegalStateException;
import hamsam.net.ProxyInfo;

/**
 * @author mikem
 */
public interface ConnectionHandler {

    /**
     * Handles low-level command processing for connecting to AIM
     * @param conn Connection object
     * @param buffer Vector used to pass command to the write thread
     * @param screenName users screen name
     * @param password users password
     */
    public void connect(ProxyInfo info, String host, int port, String screenName, String password) throws IllegalStateException;
    
    /**
     * Handles low-level command processing for disconnecting from AIM
     */
    public void disconnect();

}
