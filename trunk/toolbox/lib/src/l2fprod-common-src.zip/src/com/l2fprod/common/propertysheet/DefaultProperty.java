/** ===================================================================
 *
 * L2FProd.com Common Components 0.1-dev License.
 *
 * Copyright (c) 2004 L2FProd.com.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by L2FProd.com
 *        (http://www.L2FProd.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "L2FProd.com Common Components", "l2fprod-common" and "L2FProd.com" must not
 *    be used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact info@L2FProd.com.
 *
 * 5. Products derived from this software may not be called "l2fprod-common"
 *    nor may "l2fprod-common" appear in their names without prior written
 *    permission of L2FProd.com.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL L2FPROD.COM OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package com.l2fprod.common.propertysheet;

import com.l2fprod.common.beans.BeanUtils;

import java.lang.reflect.Method;

/**
 * DefaultProperty. <br>
 *  
 */
public class DefaultProperty extends AbstractProperty implements Cloneable {

  private String name;
  private String displayName;
  private String shortDescription;
  private Class type;
  private boolean editable = true;
  private String category;

  public Object clone() throws CloneNotSupportedException {
    DefaultProperty other = new DefaultProperty();
    other.name = name;
    other.displayName = displayName;
    other.shortDescription = shortDescription;
    other.type = type;
    other.editable = editable;
    other.category = category;
    return other;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDisplayName() {
    return displayName;
  }

  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  public String getShortDescription() {
    return shortDescription;
  }

  public void setShortDescription(String shortDescription) {
    this.shortDescription = shortDescription;
  }

  public Class getType() {
    return type;
  }

  public void setType(Class type) {
    this.type = type;
  }

  public boolean isEditable() {
    return editable;
  }

  public void setEditable(boolean editable) {
    this.editable = editable;
  }

  public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    this.category = category;
  }

  /**
   * Reads the value of this Property from the given object. It uses reflection
   * and looks for a method starting with "is" or "get" followed by the
   * capitalized Property name.
   */
  public void readFromObject(Object object) {
    try {
      Method method = BeanUtils.getReadMethod(object.getClass(), getName());
      if (method != null) {
        setValue(method.invoke(object, null));
      }
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  /**
   * Writes the value of the Property to the given object. It uses reflection
   * and looks for a method starting with "set" followed by the capitalized
   * Property name and with one parameter with the same type as the Property.
   */
  public void writeToObject(Object object) {
    try {
      Method method =
        BeanUtils.getWriteMethod(object.getClass(), getName(), getType());
      if (method != null) {
        method.invoke(object, new Object[] { getValue()});
      }
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

}
