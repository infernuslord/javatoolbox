// $Id: VariableInfo.java,v 1.1 2002/04/25 18:20:01 bill Exp $

package com.jclark.xsl.tr;

import com.jclark.xsl.expr.VariantExpr;

class VariableInfo 
{
    private final boolean param;
    private final VariantExpr expr;

    VariableInfo(VariantExpr expr, boolean param) 
    {
        this.param = param;
        this.expr = expr;
    }

    boolean isParam()
    {
        return param;
    }

    VariantExpr getExpr()
    {
        return expr;
    }
}
