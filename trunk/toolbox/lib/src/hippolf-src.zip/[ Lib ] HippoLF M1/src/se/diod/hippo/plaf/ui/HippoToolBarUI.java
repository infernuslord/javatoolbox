/*
 * 
 * Created on 2004-jul-23
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.ui;

import java.awt.Graphics;
import java.awt.Insets;

import javax.swing.JComponent;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.UIResource;
import javax.swing.plaf.metal.MetalToolBarUI;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-23
 *
 */
public class HippoToolBarUI extends MetalToolBarUI implements UIResource {
	private Border	storedBorder				= null;

	/**
	 * The Border used for buttons in a toolbar
	 */
	private Border border = new EmptyBorder(4,4,4,4);
	private int orientation = -1;
	private boolean changeBorder = true;
    
    
	/**
	 * These insets are forced inner margin for the toolbar buttons.
	 */
	private Insets insets = new Insets( 2, 2, 2, 2 );




	/////////////////////////////////////////////////
	//                   Create                    //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	public static ComponentUI createUI(JComponent c) {
		return new HippoToolBarUI();
	}




	/////////////////////////////////////////////////
	//                  Install                    //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	public void installUI(JComponent c) {
		super.installUI( c );

		storedBorder = toolBar.getBorder();
		//toolBar.setBorder( se.diod.hippo.plaf.common.HippoBorder.getToolBarBorder() );
		toolBar.putClientProperty( "JToolBar.isRollover", Boolean.TRUE );
	}




	/**
	 * 
	 * 
	 */
	protected void installDefaults() {
		super.installDefaults();
	}




	/////////////////////////////////////////////////
	//                 Uninstall                   //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	public void uninstallUI( JComponent c ) {
		super.uninstallUI( c );

		if( storedBorder != null )
			toolBar.setBorder( storedBorder );
	}






	/**
	 * 
	 * Restores the original <code>Border</code>.
	 * 
	 */
	protected void uninstallDefaults() {
		super.uninstallDefaults();
	}




	/////////////////////////////////////////////////
	//                 Painting                    //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	public void paint( Graphics g, JComponent c ) {
		Graphics g2 = g.create();

		int height		= c.getHeight();

		int componentHeight = c.getHeight() - ((((javax.swing.JComponent)c).getInsets().bottom) + (((javax.swing.JComponent)c).getInsets().top));
		int componentWidth	= c.getWidth() - ((((javax.swing.JComponent)c).getInsets().left) + (((javax.swing.JComponent)c).getInsets().right));
		int bottomInset		= componentHeight	+ ((((javax.swing.JComponent)c).getInsets().top*2));
		int leftInset		= componentWidth	+ ((((javax.swing.JComponent)c).getInsets().left*2));
		//int rightInset		= componentWidth	- c.getInsets().right;//+ ((((javax.swing.JComponent)c).getInsets().right*2));


		if (!isFloating()) {
			if (toolBar.getOrientation() != orientation) {
				if (toolBar.getOrientation() == 0) {
					if (toolBar.isFloatable()) {
						toolBar.setBorder(new EmptyBorder( 2, 11, 2, 2 ) );
					} else {
						toolBar.setBorder(new EmptyBorder(2,2,2,2));
					}
				} else {
					if (toolBar.isFloatable()) {
						toolBar.setBorder(new EmptyBorder( 12, 0, 2, 2 ) );
					} else {
						toolBar.setBorder(new EmptyBorder(2,2,2,2));
					}
				}
				orientation = toolBar.getOrientation();
				changeBorder = true;
			}

			/*
			if (toolBar.getOrientation() == 0) {
				if (toolBar.isFloatable()) {
					//vbarHandler.draw(g, 0, 1, 2, 8, c.getHeight()-4);
				}
			} else {
				if (toolBar.isFloatable()) {
					//hbarHandler.draw(g, 0, 1, 2, c.getWidth()-4, 8);
				}
			}*/
		} else {
			if (changeBorder) {
				toolBar.setBorder(new EmptyBorder(1,1,1,1));
				changeBorder = false;
				orientation = -1;
			}
		}

		if( isFloating() ){
			g2.setColor( UIManager.getColor( "ToolBar.dragIconColor" ) );
			switch( toolBar.getOrientation() ) {
				case HORIZONTAL:
					int y = 4;
					while( y+2 < bottomInset - 3 ) {
						g2.drawRect( 2, y, 1, 1 );
						y += 3;
					}
					break;
				case VERTICAL:
					int x = 4;
					while( x+2 < leftInset - 1 ) {
					//while( x+2 < bottomInset - 3 ) {
						g2.drawRect( x, 2, 1, 1 );
						x += 3;
					}
					break;
			} 
		}

		g2.dispose();
	}
}