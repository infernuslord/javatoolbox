/*
 *   The contents of this file are subject to the Mozilla Public License
 *   Version 1.1 (the "License"); you may not use this file except in
 *   compliance with the License. You may obtain a copy of the License at
 *   http://www.mozilla.org/MPL/
 *
 *   Software distributed under the License is distributed on an "AS IS"
 *   basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 *   License for the specific language governing rights and limitations
 *   under the License.
 *
 *   The Original Code is Matra - the DTD Parser.
 *
 *   The Initial Developer of the Original Code is Conrad S Roche.
 *   Portions created by Conrad S Roche are Copyright (C) Conrad 
 *   S Roche. All Rights Reserved.
 *
 *   Alternatively, the contents of this file may be used under the terms
 *   of the GNU GENERAL PUBLIC LICENSE Version 2 or any later version
 *   (the  "[GPL] License"), in which case the
 *   provisions of GPL License are applicable instead of those
 *   above.  If you wish to allow use of your version of this file only
 *   under the terms of the GPL License and not to allow others to use
 *   your version of this file under the MPL, indicate your decision by
 *   deleting  the provisions above and replace  them with the notice and
 *   other provisions required by the GPL License.  If you do not delete
 *   the provisions above, a recipient may use your version of this file
 *   under either the MPL or the GPL License."
 *
 *   [NOTE: The text of this Exhibit A may differ slightly from the text of
 *   the notices in the Source Code files of the Original Code. You should
 *   use the text of this Exhibit A rather than the text found in the
 *   Original Code Source Code for Your Modifications.]
 *
 * Created: Conrad S Roche <derupe at users.sourceforge.net>,  11-Aug-2003
 */
package com.conradroche.matra.test.decl;

import java.util.ArrayList;

import com.conradroche.dtd.decl.AttDef;
import com.conradroche.matra.data.DTDData;
import com.conradroche.matra.decl.Attribute;
import com.conradroche.matra.exception.DTDSyntaxException;
import com.conradroche.matra.test.util.DataValues;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * JUnit test case for the AttributeType class.
 * 
 * @author Conrad Roche
 */
public class AttributeTest extends TestCase {

	/*
	[53] AttDef ::= S Name S AttType S DefaultDecl

	[54] AttType ::= StringType | TokenizedType | EnumeratedType
	[55] StringType ::= 'CDATA'
	[56] TokenizedType ::= 'ID' | 'IDREF' | 'IDREFS' | 'ENTITY' | 'ENTITIES' | 'NMTOKEN' | 'NMTOKENS' 

	[57] EnumeratedType ::= NotationType | Enumeration
	[58] NotationType ::= 'NOTATION' S '(' S? Name (S? '|' S? Name)* S? ')' 
	[59] Enumeration ::= '(' S? Nmtoken (S? '|' S? Nmtoken)* S? ')'
	
	[60] DefaultDecl ::= '#REQUIRED' | '#IMPLIED' | (('#FIXED' S)? AttValue)
	[10] AttValue ::= '"' ([^<&"] | Reference)* '"' | "'" ([^<&'] | Reference)* "'"
	
	[67] Reference ::= EntityRef | CharRef
	[68] EntityRef ::= '&' Name ';'
	[66] CharRef ::= '&#' [0-9]+ ';' | '&#x' [0-9a-fA-F]+ ';'
	  
	*/

	/*
	 * Test Cases to check for
	 * I. Normal Conditions
	 * 
	 *  0. Different kind of names in all the below tests
	 *  1. StringType + (#REQUIRED | #IMPLIED)							testReadNextAttributeCdata()
	 *  2. TokenizedType + (#REQUIRED | #IMPLIED)						testReadNextAttributeTokenized()
	 *  3. StringType + #FIXED + values									testReadNextAttributeFixed()
	 *  4. StringType + value
	 *  5. TokenizedType + #FIXED + value								testReadNextAttributeFixed()
	 *  6. TokenizedType + value
	 *  7. Enumeration (multiple values) + (#REQUIRED | #IMPLIED)
	 *  8. Enumeration (single value) + (#REQUIRED | #IMPLIED)			testSingleEnumAttributes()
	 *  CR: NOTE: Having FIXED values for EnumeratedType does not make sense to me! 
	 *  9. Enumeration + #FIXED + valid value
	 * 10. Enumeration + #FIXED + reference
	 * 11. Enumeration + valid value
	 * 12. Enumeration + reference
	 * 13. Notation (multiple values) + (#REQUIRED | #IMPLIED)
	 * 14. Notation (single value) + (#REQUIRED | #IMPLIED)			
	 * 15. Notation + #FIXED + valid value
	 * 16. Notation + #FIXED + reference
	 * 17. Notation + valid value
	 * 18. Notation + reference
	 * 
	 * II. Error Conditions 
	 * - put these in AttributeErrorTest
	 * 1. Invalid name
	 * 2. Invalid TokenizedType
	 * 3. Invalid DefaultDecl ('#UNKNOWN', 'UNKNOWN')
	 * 4. Missing AttType
	 * 5. Missing DefaultDecl (EOD before reaching there)
	 * 6. EnumeratedType with non-nmtoken value(s) - could be the first, last, middle or only token
	 * 7. EnumeratedType + #FIXED + invalid value
	 * 8. 'ID' Type + #FIXED + value
	 * 9. two consecutive '|'s in enum values
	 * 
	 * III. Error conditions (from SGML DTDs)
	 * 1. Comment within the Attribute declation 
	 */

	/**
	 * Attribute object to test on.
	 */
	protected Attribute attr;

	/**
	 * Various Attribute test names.
	 */
	protected final String[] names = DataValues.getInstance().getAttributeNames();
	
	/**
	 * Constructor for AttributeTest.
	 * @param arg0
	 */
	public AttributeTest(String arg0) {
		super(arg0);
	}

	/**
	 * Returns a test suite with AttributeTest.
	 * 
	 * @return
	 */
	public static Test suite() {

		TestSuite suite = new TestSuite();

		suite.addTestSuite(AttributeTest.class);

		return suite;
	}
	
	/*
	 * @see TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		attr = new Attribute();
	}

	/*
	 * Test for void Attribute(String, String, String[], String)
	 */
	public void testAttributeStringStringStringArrayString() {
	}

	/*
	 * Test for void Attribute(String, String, int, String, String)
	 */
	public void testAttributeStringStringintStringString() {
	}

	public void testGetDefaultDecl() {
	}
	
	/**
	 * Helper function to check if the optionality of the
	 * specified attribute is of type FIXED.
	 * 
	 * @param attr The attribute to be checked
	 */
	protected void checkFixedOptionality(Attribute attr) {
		
		Assert.assertEquals(AttDef.OPTIONALITY_FIXED, attr.getOptionality());
		Assert.assertEquals(Attribute.OPTIONALITY_STR_FIXED, attr.getOptionalityString());
	}
	
	/**
	 * Helper function to compare the optionality of the
	 * specified attribute to the one specified. The value
	 * should either be Impled or Required.
	 * 
	 * @param attr The attribute to be checked
	 * @param expectedOptionality The expected value of the optionality
	 */
	protected void checkNonFixedOptionality(Attribute attr, String expectedOptionality) {
		
		if(expectedOptionality.equals(Attribute.OPTIONALITY_STR_REQUIRED)) {
			Assert.assertEquals(AttDef.OPTIONALITY_REQUIRED, attr.getOptionality());
		} else {
			Assert.assertEquals(AttDef.OPTIONALITY_IMPLIED, attr.getOptionality());
		}
		Assert.assertEquals(expectedOptionality, attr.getOptionalityString());
	}

	protected DTDData buildAttrs(String[] names, String[] types, String[] defaults) {
		
		final String[] S = {" ", "\t", "\r", "\n", " \t \n \r"};
		StringBuffer sb = new StringBuffer("");
		
		for(int i = 0; i < names.length; i++) {
			for(int j = 0; j < types.length; j++) {
				for(int k = 0; k < defaults.length; k++) {
					sb.append(S[i % S.length]).append(names[i])
					  .append(S[i % S.length]).append(types[j])
					  .append(S[i % S.length]).append(defaults[k]);					
				}
			}
		}
		DTDData dData = new DTDData(sb.toString());
		
		return dData;
	}
	
	/**
	 * CR: JavaDoc: Add javadoc for AttributeTest::buildAttrs
	 * 
	 * @param names
	 * @param type
	 * @param defaults
	 * @return
	 */
	private DTDData buildAttrs(String[] names, String type, String[] defaults) {
		
		return buildAttrs(names, new String[]{type}, defaults);
	}
	
	public void testReadNextAttributeEnum() {
	}
	
	/**
	 * CR: JavaDoc: Add javadoc for AttributeTest::testReadNextAttributeCdata
	 */
	public void testReadNextAttributeCdata() {
		
		final String[] defaults = {"#REQUIRED", "#IMPLIED"};
		
		DTDData dData = buildAttrs(names, Attribute.CDATA, defaults);
		for(int i = 0; i < names.length; i++) {
			for(int k = 0; k < defaults.length; k++) {
				
				try {
					attr.readNextAttribute(dData);
				} catch(DTDSyntaxException e) {
					fail("Caught syntax exception - " + e.getMessage());
				}
				
					
				Assert.assertEquals(names[i], attr.getAttributeName());
				Assert.assertEquals(AttDef.TYPE_STRING, attr.getAttType());
				Assert.assertEquals(Attribute.CDATA, attr.getDataType());

				checkNonFixedOptionality(attr, defaults[k]);
			}
		}
	}

	/**
	 * CR: JavaDoc: Add javadoc for AttributeTest::testReadNextAttributeTokenized
	 */			
	public void testReadNextAttributeTokenized() {

		final String[] tokenizedTypes = { "ID", "IDREF", "IDREFS", "ENTITY", 
							"ENTITIES", "NMTOKEN", "NMTOKENS"};
		
		final String[] defaults = {"#REQUIRED", "#IMPLIED"};
		
		DTDData dData = buildAttrs(names, tokenizedTypes, defaults);
			
		for(int i = 0; i < names.length; i++) {
		  for(int j = 0; j < tokenizedTypes.length; j++) {
			for(int k = 0; k < defaults.length; k++) {
				
				try {
					attr.readNextAttribute(dData);
				} catch(DTDSyntaxException e) {
					fail("Caught syntax exception - " + e.getMessage());
				}

				Assert.assertEquals(names[i], attr.getAttributeName());
				Assert.assertEquals(AttDef.TYPE_TOKENIZED, attr.getAttType());
				Assert.assertEquals(tokenizedTypes[j], attr.getDataType());
				
				checkNonFixedOptionality(attr, defaults[k]);
				
				if(tokenizedTypes[j].equals("ID")) {
					Assert.assertTrue(attr.isIDType());
				} else {
					Assert.assertFalse(attr.isIDType());
				}
			} //for k
		  } //for j
		} //for i
	}

	/**
	 * CR: JavaDoc: Add javadoc for AttributeTest::getFixedValues
	 * 
	 * @return
	 */	
	private String[] getFixedValues() {
		
		final String fixed = "#FIXED\t \n\r";
		final String[] quotes = { "\"", "'" }; 
		final String[] values = {"value", "123", "a", "1", "&entity;", "&v2;", "&#163;", 
								 "&#xaF;", "&#xA9", "_+-.()", "&entity1;&entity2;", 
								 ":-)", ")-;", ":->", "a + b != c", 
								 "&#159; &entity; &#x21", "&#159;&entity;&#x21"};
		
		ArrayList defaults = new ArrayList();
		
		for(int i = 0; i < quotes.length; i++) {
			for(int j = 0; j < values.length; j++) {
				defaults.add(fixed + quotes[i] + values[j] + quotes[i]);
			}
		}
		
		defaults.add("#FIXED\t\"isn't\"");
		defaults.add("#FIXED\n'double quote - \"'");

		return (String[]) defaults.toArray(new String[0]);
	}

	/**
	 * CR: JavaDoc: Add javadoc for AttributeTest::testReadNextAttributeFixed
	 */
	public void testReadNextAttributeFixed() {

		//ID type cannot have a fixed value - so its removed from the list below
		final String[] types = { "CDATA", "IDREF", "IDREFS", "ENTITY", 
							"ENTITIES", "NMTOKEN", "NMTOKENS"};
		
		String[] defaults = getFixedValues();
		DTDData dData = buildAttrs(names, types, defaults);
		
		attr = new Attribute();
		
		for(int i = 0; i < names.length; i++) {
		  for(int j = 0; j < types.length; j++) {
			for(int k = 0; k < defaults.length; k++) {
				
				try {
					attr.readNextAttribute(dData);
				} catch(DTDSyntaxException e) {
					fail("Caught syntax exception - " + e.getMessage());
				}

				Assert.assertEquals(names[i], attr.getAttributeName());
				
				if(types[j].equals("CDATA")) {
					Assert.assertEquals(AttDef.TYPE_STRING, attr.getAttType());
				} else {
					Assert.assertEquals(AttDef.TYPE_TOKENIZED, attr.getAttType());
				}
				Assert.assertEquals(types[j], attr.getDataType());
				
				checkFixedOptionality(attr);
			} //for k
		  } //for j
		} //for i
	}
}
