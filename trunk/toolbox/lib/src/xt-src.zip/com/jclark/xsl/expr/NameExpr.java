// $Id: NameExpr.java,v 1.1 2002/04/25 18:09:04 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

public interface NameExpr {
    Name eval(Node node, ExprContext context) throws XSLException;
}
