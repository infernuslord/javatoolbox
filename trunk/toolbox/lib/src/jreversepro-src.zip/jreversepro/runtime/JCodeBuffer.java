/**
  * @(#)JCodeBuffer.java
  *
  * JReversePro - Java Decompiler / Disassembler.
  * Copyright (C) 2000 2001 Karthik Kumar.
  * EMail: akkumar@users.sourceforge.net
  *
  * This program is free software; you can redistribute it and/or modify
  * it , under the terms of the GNU General Public License as published
  * by the Free Software Foundation; either version 2 of the License,
  * or (at your option) any later version.
  *
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  * See the GNU General Public License for more details.
  * You should have received a copy of the GNU General Public License
  * along with this program.If not, write to
  *  The Free Software Foundation, Inc.,
  *  59 Temple Place - Suite 330,
  *  Boston, MA 02111-1307, USA.
  **/

package jreversepro.runtime;

import jreversepro.common.KeyWords;
import java.util.List;
import java.util.StringTokenizer;

/** JCodeBuffer is the module responsible for formatting the
 * code of the methods.
 *
 * @author Karthik Kumar
 **/
public class JCodeBuffer {

    /**
     * StringBuffer sb contains the code
     **/
    private StringBuffer sb;

    /**
     * Current depth of the code relative to the left hand side
     * margin.
     **/
    private int depth;

    /**
     * Strings that are restricted from appearing in the final line.
     * This is mostly used in case of return statements for contructors, etc.
     **/
    private List mRestrict;

    /**
     * tabSize of the code.
     **/
    private int tabSize = 4;


    /**
     * Constructor having restricted lines and
     * initial depth of the method code.
     * @param aRestrict Restricted sentences in code.
     * @param depth Depth of the code.
     **/
    public JCodeBuffer(List aRestrict, int depth) {
        sb = new StringBuffer();
        this.depth = depth;
        mRestrict = aRestrict;
    }

    /**
     *
     * @param aRestrict Restricted sentences in code.
     **/
    public JCodeBuffer(List aRestrict) {
        this(aRestrict, 2);
    }

    /**
     * Increase the depth internally
     **/
    public void incDepth() {
        depth++;
    }

    /**
     * Decrease the depth internally
     **/
    public void decDepth() {
        depth--;
    }

    /**
     * Appends a new line with one tab each for
     * one depth.
     **/
    private void appendNewLine() {
        sb.append("\n");
        for (int i = 0 ; i  < depth; i++) {
            for (int j = 0; j < tabSize; j++) {
                sb.append(' ');
            }
        }
    }

    /**
     * This method is responsible for adding case statements
     * @param caseEntry This contains the case value for the
     * leg of a switch statement
     **/
    public void addCaseStatements(String caseEntry) {
        if (caseEntry.equals(KeyWords.DEFAULT)) {
            appendNewLine();
            sb.append(KeyWords.DEFAULT + ":");
        } else {
            StringTokenizer st =  new StringTokenizer(caseEntry, ",");
            while (st.hasMoreTokens()) {
                appendNewLine();
                sb.append(KeyWords.CASE + " " + st.nextToken() + ":");
            }
        }
        sb.append(" {");
    }


    /**
     * @param code Code
     * @param statement It set a semicolon is added
     * else left as such.
     **/
    public void addLine(String code, boolean statement) {
        if (!mRestrict.contains(code) && code.length() != 0) {
            appendNewLine();
            sb.append(code);
        }
        if (statement) {
            sb.append(";");
        }
    }

    /**
     * Deletes until the last occurrence of aKey.
     * @param aKey key whose last occurence is to be deleted.
     **/
    public void rollback(String aKey) {
        String code = sb.toString();
        int keyIndex = code.lastIndexOf(aKey);
        if (keyIndex  != -1) {
            int eolIndex =
                code.substring(0, keyIndex).lastIndexOf('\n');
            int blockBeginIndex = code.indexOf("{", eolIndex);
            int max = blockBeginIndex ;
            if (max != -1) {
                sb.delete(eolIndex, max + 1);
            }
        }
    }

    /**
     * @return Returns the code as StringBuffer
     **/
    public StringBuffer getCode() {
        return sb;
    }

    /**
     * @return Returns the code as String.
     **/
    public String toString() {
        return sb.toString();
    }
}
