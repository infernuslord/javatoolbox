/*
 * Created on Apr 29, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package com.shfarr.jsp;

import java.util.Collection;
import java.util.Iterator;

/**
 * @author Stefan Harsan Farr
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class JSPSelect{
    private String name = null;
    private Collection alternatives = null;
    private Collection selection = null;
    private String changeScript = null;
    
    public JSPSelect(){
    }

    public JSPSelect(String name, Collection options) {
        super();
        this.name = name;
        this.alternatives = options;
    }
    
    public JSPSelect(String name, Collection options, Collection selection) {
        super();
        this.name = name;
        this.alternatives = options;
        this.selection = selection;
    }
    
    public JSPSelect(String name, Collection options, Collection selection, String changeScript) {
        super();
        this.name = name;
        this.alternatives = options;
        this.selection = selection;
        this.changeScript = changeScript;
    }

    public String getChangeScript(){
		return changeScript;
	}
	
    public void setChangeScript(String changeScript){
		this.changeScript = changeScript;
	}
	
    public String getName(){
		return name;
	}
	
    public void setName(String name){
		this.name = name;
	}
	
    public Collection getAlternatives(){
		return alternatives;
	}
	
    public void setAlternatives(Collection options){
		this.alternatives = options;
	}
	
    public Collection getSelection(){
		return selection;
	}

    public void setSelection(Collection selection){
		this.selection = selection;
	}
    
    public String toString(){
        StringBuffer buffer = new StringBuffer("<select name=\"" + name +  "\" " + (changeScript != null ? " onchange=\"" + changeScript + "\"" : "") + " >");
        
        for(Iterator iter = alternatives.iterator(); iter.hasNext(); ){
            Object co = iter.next();
            buffer.append("<option value=\"" + co + (selection != null && selection.contains(co) ? "\" SELECTED" : "\"") + ">" + co + "</option>");
        }
        
        buffer.append("</select>");

        return buffer.toString();
    }
}
