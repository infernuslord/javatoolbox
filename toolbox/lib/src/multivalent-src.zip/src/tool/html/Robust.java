package tool.html;

import java.io.File;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URL;
import java.net.URI;
import java.net.MalformedURLException;
import java.util.Map;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Iterator;

import phelps.net.RobustHyperlink;
import phelps.io.FileList;
import tool.doc.ExtractText;



/**
	Rewrite HTML page or whole web site to make URLs robust.
	New version of page is minimally changed and all formatting is retained; the only change is that each HREF's URL replaced is by a robust version.
	Useful for converting bookmarks or all links in a site.

	@see phelps.net.RobustHyperlink

	@version $Revision: 1.2 $ $Date: 2003/06/29 07:12:30 $
*/
public class Robust {
  static final boolean DEBUG = true;

  public static final String VERSION = "1.1 of $Date: 2003/06/29 07:12:30 $";
  public static final String USAGE = "java tool.html.Robust <base-URL> <HTML-file or directory...>";

  static final String[] RTAG = { "base", "a", "frame" };
  static final String[] RATTR = { "href", "href", "src" };

  /** Cache of URL signatures. */
  static Map<String,String> url2sig = new HashMap<String,String>(10);

  ExtractText et_ = new ExtractText();
  boolean fforce_ = false;
  PrintStream out_;
  PrintWriter StudyOut = null;
  boolean fverbose = false;
  boolean SignQueries = false;

  //int SkipCnt = 0;
  //String SkipTo = null;

  public Robust() {
	defaults();
  }

  public void defaults() {
	out_ = phelps.io.PrintStreams.DEVNULL;
  }

  /**
	Rewrite single page vis-a-via <var>root</var>, with guards.
  */
  public void rewrite(URL root, File f) throws IOException {
	if (StudyOut!=null) {
		StudyOut.println("# m=page last mod, c=bookmark creation, v=bookmark last visitied,");
		StudyOut.println("# page cnt/web cnt or error message");
	}

	if (fverbose) System.out.println(f);

	if (!f.exists()) { System.err.println(" -- doesn't exist"); return; }
	else if (!f.canRead()) { System.err.println(" -- unreadable"); return; }
	else if (!f.canWrite()) { System.err.println(" -- unwriteable"); return; }


	try {
		String canf0 = root.getPath();
		String canf = f.getAbsolutePath().replace('\\','/');
		String relf = "";
		// strip out commonality with base file, at directory boundary
		for (int i=0,imax=canf.length(); i<imax; i++) {
			if (canf.charAt(i)!=canf0.charAt(i)) {
				while (i>0 && canf.charAt(i)!='/') i--;
				relf = canf.substring(i);
				break;
			}
		}
//System.out.println("canf0 = "+canf0+"\ncanf = "+canf);
		URL base = new URL(root, relf);
//System.out.println(url+" + "+relf+" = "+base);
		//try { base = new URL(base, f.getCanonicalPath()); } catch (MalformedURLException male) {}
		if (fverbose) System.out.println("aka "+base);


		// first write to temporary file
		File robustf = File.createTempFile("robust", ".tmp");
		PrintWriter out = new PrintWriter(new FileWriter(robustf));
		if (StudyOut!=null) StudyOut.println();
		rewrite(base, f, out);
		out.close();

		// with rewritten version successful, delete original and rename temporary
		if (!f.delete()) {
			System.err.print(" -- can't delete");
		} else {
			if (!robustf.renameTo(f)) { System.err.print(" -- can't rename "); }
			robustf.renameTo(f);
		}

	} catch (MalformedURLException male) {
		if (fverbose) System.err.println("BAD"+male);

	} catch (IOException e) {
		System.err.println(e);
	}

	if (fverbose) System.out.println();
  }


  /**
	Textually rewrite page.
  */
  void rewrite(URL base, File f, PrintWriter out) throws IOException {
	// first make big string of whole page so can scan back and forth
	char[] buf = new char[(int)f.length()];
	Reader in = new FileReader(f);
	int len = in.read(buf);
	in.close();
	String str = new String(buf, 0, len);
	int sinx=0;


	// handle A HREF, FRAME SRC, BASE HREF, ...
	int lasti=0; char ch;
	for (int i=0,imax=str.length(),ie; (i=str.indexOf('<', i))!=-1; i++) {
		// dump text up to start of tag
		i++;
		if (i>lasti) { out.print(str.substring(lasti,i)); lasti=i; }

		// find end of tag
		int iend = str.indexOf('>',i);
		if (iend==-1) break;
		if (str.charAt(i)=='/') continue;	// ignore close tag

		// tag were interested in?
		String findattr=null, attrval=null; // href for A and BASE, src for FRAME (and IMG)
		ie=i;
		while ((ch=str.charAt(ie))!='>' && !Character.isWhitespace(ch) && ie<iend) ie++;
		String tag = str.substring(i,ie).toLowerCase();
		for (int j=0,jmax=RTAG.length; j<jmax; j++) if (tag.equals(RTAG[j])) { findattr = RATTR[j]; break; }
//System.out.println("tag="+tag+" => "+findattr);
		if (findattr==null) continue;

		// find selected attribute, take value
		for (i=ie; i<iend; i=ie) {
			// name
			while (i<iend && Character.isWhitespace(str.charAt(i))) i++;	// start of attr
			ie=i;
			while (ie<iend && (ch=str.charAt(ie))!='=' && !Character.isWhitespace(ch)) ie++;   // attr itself
			boolean match = (ie-i==findattr.length() && findattr.regionMatches(true, 0, str,i,findattr.length()));
//System.out.println(findattr+" =? |"+str.substring(i,ie)+"|, match="+match);

			// val
			i=ie; while (i<iend && Character.isWhitespace(str.charAt(i))) i++;
			if (i<iend && str.charAt(i)=='=') i++; else continue;
			while (i<iend && Character.isWhitespace(str.charAt(i))) i++;
			char eoa = str.charAt(i);
			if (eoa=='"' || eoa=='\'') {
				i++; ie=i;
				while (ie<iend && str.charAt(ie)!=eoa) ie++;
			} else {
				ie=i;
				while (ie<iend && !Character.isWhitespace(str.charAt(ie))) ie++;
				if (ie>i) { eoa=str.charAt(ie-1); if (eoa=='"' || eoa=='\'') ie--; }  // close quote without open quote
			}

			if (match && ie>i) {
				if (str.charAt(i)!='#') attrval = str.substring(i,ie);	// don't sign intra-page
				//if (SkipCnt>0) { SkipCnt--; attrval=null; }
//System.out.println("\n"+findattr+" = "+attrval);
				break;
			}
		}

		// tag-specific action
		if (tag.equals("base")) {
			try { base = new URL(base, attrval); } catch (MalformedURLException e) {}
//System.out.print(str.substring(lasti,iend+1));
			if (fverbose) System.out.println("\tBASE tag => setting URL base to "+base);
		} else if (attrval!=null && attrval.length()>0) {  // rewrite given attribute value
			//if (fverbose) System.out.print("\trewriting \""+tag+" "+findattr+" => ");
			if (StudyOut!=null && sinx!=-1 && "a".equals(tag)) {
//+System.out.println("sinx="+sinx+", i="+i+", |"+str.substring(i,ie)+"|, "+str.indexOf("ADD_DATE",i));
				if ((sinx=str.indexOf("ADD_DATE", i))!=-1 && sinx<iend) StudyOut.print("c"+str.substring(sinx+8+2,sinx+8+2+9)+" ");
				if ((sinx=str.indexOf("LAST_VISIT", i))!=-1 && sinx<iend) StudyOut.print("v"+str.substring(sinx+10+2,sinx+10+2+9)+" ");
			}

			// if no "lex-sig" or forced recompute, compute now
			String strip=RobustHyperlink.stripSignature(attrval), sig=RobustHyperlink.getSignature(attrval);
			String norm = strip.toLowerCase();
			int queryi = norm.indexOf('?'); if (queryi!=-1) norm=norm.substring(0,queryi);
			URL relurl = new URL(base, strip);
			/*
			if (SkipTo!=null) {
				if (SkipTo.indexOf(norm)!=-1) SkipTo=null;	// just have to specify partial, not full for .equals()
				else {
					if (fverbose) System.out.println("skipping "+norm);
					continue;
				}
			}*/
//System.out.println("norm = |"+norm+"|");
//System.out.println("|"+base+"| + |"+attrval+"| = |"+relurl+"|");
//System.out.println(base+" + "+attrval+" => "+relurl);
//System.out.println("relurl = |"+relurl+"|, queryi="+queryi);
			String path = relurl.getFile(); if ("".equals(path)) path="/";
			String file = (path.indexOf('/')!=-1? path.substring(path.lastIndexOf('/')+1): path);
			int sfx = file.lastIndexOf('.');
			// if host-only, add '/' before signature so that Netscape 4.x doesn't screw up
			// http://sunsite.berkeley.edu:80/Dienst/UI/2.0/Describe/ncstrl.ucb%2fCSD-82-104
//System.out.println("sig="+sig+", force="+force_+", norm="+norm);
			if ((sig==null || fforce_) && (queryi==-1 || SignQueries) && (norm.endsWith(".html") || norm.endsWith(".htm") || queryi!=-1 || relurl.getFile()=="" || sfx==-1 || sfx<file.length()-5)) try {
				if (fverbose) System.out.print("\t"+attrval+" => ");

				if (i>lasti) { out.print(str.substring(lasti,i)); lasti=ie; }
				//System.out.print("|STRIP="+strip+"|");
				out.print(strip); lasti=ie;

				//if (fverbose) System.out.println("\tsigning "+attrval);
//System.err.println("\n"+attrval+" => ");
				if (StudyOut!=null) StudyOut.flush();

				//String signedurl = RobustHyperlink.computeSignature(relurl);
				URI reluri = new URI(relurl.getProtocol(), relurl.getHost(), relurl.getFile(), relurl.getRef());
				String signedurl = RobustHyperlink.computeSignature(et_.extract(reluri, null));
//System.err.println("\n"+attrval+" => "+signedurl);
				sig = signedurl.startsWith("(")? signedurl: RobustHyperlink.getSignature(signedurl);
				if (StudyOut!=null && sig.startsWith("(")) StudyOut.println(sig);	// if ordinary signature, already written out

//System.err.println(attrval+" => "+signedurl+" => "+sig);
				if (fverbose) System.out.println(sig);
				if (sig!=null && !sig.startsWith("(")) {
					url2sig.put(relurl.toString(), sig);
					//relurl = new URL(sig);
					//if (i>lasti) { out.print(str.substring(lasti,ie)); lasti=ie; }
					//out.print(URIs.relativeURL(base, new URL(sig)));
					out.print(sig);
					//lasti=ie; // replaced attr value so skip old value
				} //else if (fverbose) System.out.println("can't sign (maybe page too short)");
			 //else if (sig!=null && fverbose) System.out.println("already signed");

			} catch (Exception e) {
			// skip it
				if (fverbose) System.out.println("error during signing (may not be HTML)");
				if (StudyOut!=null) StudyOut.println("("+e+")");
			}
			//else if (fverbose) System.out.println("doesn't appear to be HTML");
		}
		//if (StudyOut!=null) break;	// while debugging
	}

	if (lasti<str.length()) out.print(str.substring(lasti));
  }



  private int commandLine(String[] argv) {
	out_ = System.out;

	int argi = 0, argc = argv.length;
	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.equals("-force")) fforce_ = true;

		else if (arg.startsWith("-verb")) fverbose = true;
		//else if (arg.startsWith("-q"/*uiet*/)) fquiet = true;
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.startsWith("-h"/*"elp"*/)) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	if (argi == argc) { System.err.println(USAGE); System.exit(0); }

	return argi;
  }

  public static void main(String[] argv) throws MalformedURLException {
	Robust ro = new Robust();
	int argi = ro.commandLine(argv);

	if (argi+2 >= argv.length) { System.err.println(USAGE); System.exit(1); }

	URL base = new URL(argv[argi++]);

	for (Iterator<File> i = new FileList(argv, argi, multivalent.std.adaptor.HTML.FILTER).iterator(); i.hasNext() ; ) {
		try {
			ro.rewrite(base, i.next());
		} catch (IOException ioe) {
			ioe.printStackTrace();
			break;
		}
	}
  }
}
