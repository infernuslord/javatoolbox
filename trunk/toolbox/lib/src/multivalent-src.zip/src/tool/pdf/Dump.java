package tool.pdf;

import java.io.InputStream;
import java.io.IOException;
import java.io.File;
import java.awt.Rectangle;
import java.awt.geom.Rectangle2D;

import multivalent.ParseException;
import multivalent.std.adaptor.pdf.*;
import static multivalent.std.adaptor.pdf.COS.*;

import phelps.lang.Integers;



/**
	Extract COS objects, stripping filters.
	Only command-line, not programmatic, as functions available from {@link PDFReader}.

	@version $Revision: 1.1 $ $Date: 2003/07/19 10:35:42 $
*/
public class Dump {
  static final boolean DEBUG = true;

  public static final String USAGE = "java tool.pdf.Dump [-password] <PDF-file>\n"
	+ "\t[-objnum <objnum>] [-range <range>] [-page <pagenum>]";
  public static final String VERSION = "1.0.1 of $Date$";

  String password_;
  String range_;
  String pages_;

  public Dump() {
	defaults();
  }

  public void defaults() {
	password_ = null;
	range_ = "1-";
	pages_ = null;

	//fverbose = false;
	//out_ = System.out;
  }

  public void dump(File file) throws IOException, ParseException {
	PDFReader pdfr = new PDFReader(file);
	pdfr.setExact(true);
	pdfr.setPassword(password_);

	int[] range;
	if (pages_!=null) {
		int[] pages = Integers.parseRange(pages_, 1,pdfr.getPageCnt());
		range = new int[pages.length];
		for (int i=0,imax=pages.length; i<imax; i++) {
			IRef ref = pdfr.getPageRef(pages[i]);
			range[i] = ref.id;

			// inherit attrs and rewrite rectangle
			Dict page = pdfr.getPage(pages[i]);
			oa2Rect(page, "MediaBox", pdfr); oa2Rect(page, "CropBox", pdfr);
			//pdfr.pinObject(ref.id);
		}
	} else range = Integers.parseRange(range_, 1,pdfr.getObjCnt());

	for (int num: range) {
		Object o = pdfr.getObject(num);
		System.out.println(o);
		if (CLASS_DICTIONARY==o.getClass() && ((Dict)o).get(STREAM_DATA)!=null) {
			//byte[] b = pdfr.getStreamData(new IRef(num,pdfr.getObjGen(num)), false, false);
			//for (int i=0,imax=b.length; i<imax; i++) System.out.write((char)(b[i]&0xff));
//System.out.println("dump "+num+", "+((Dict)o).get(STREAM_DATA)+", class="+((Dict)o).get(STREAM_DATA).getClass());
			InputStream is = pdfr.getInputStream(new IRef(num,pdfr.getObjGen(num)), false);
			for (int c; (c = is.read())!=-1; ) System.out.write((char)c);	// not System.out.print !
			is.close();
			System.out.println();
		}
	}
	pdfr.close();
  }

  private static void oa2Rect(Dict page, String attr, PDFReader pdfr) throws IOException {
	Object[] oa = (Object[])pdfr.getObject(page.get(attr));
	if (oa==null || oa.length!=4) return;
	int[] w = new int[4]; double[] d = new double[4];
	boolean fdub = false;
	for (int i=0; i<4; i++) {
		Object o = oa[i];
		if (CLASS_REAL==o.getClass()) fdub = true;
		w[i] = ((Number)o).intValue();
		d[i] = ((Number)o).doubleValue();
	}
	Rectangle2D r = fdub? (Rectangle2D)new Rectangle2D.Double(d[0],d[1],d[2],d[3]): new Rectangle(w[0],w[1],w[2],w[3]);
	page.put(attr, r);
  }



  private int commandLine(String[] argv) {
	int argi = 0, argc = argv.length;
	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.startsWith("-pass"/*"word"*/)) password_ = argv[++argi];
		else if (arg.startsWith("-range") || arg.startsWith("-obj"/*num*/) || arg.startsWith("-num")) { range_ = argv[++argi]; pages_ = null; }
		else if (arg.startsWith("-page")) { pages_ = argv[++argi]; range_ = null; }

		//else if (arg.startsWith("-verb")) fverbose = true;
		//else if (arg.startsWith("-q"/*uiet*/)) fquiet = true;
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.startsWith("-h"/*"elp"*/)) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	if (argi + 1 != argc) { System.err.println(USAGE); System.exit(1); }

	return argi;
  }

  public static void main(String[] argv) throws IOException, ParseException {
	Dump dump = new Dump();
	int argi = dump.commandLine(argv);

	dump.dump(new File(argv[argi]));
  }
}
