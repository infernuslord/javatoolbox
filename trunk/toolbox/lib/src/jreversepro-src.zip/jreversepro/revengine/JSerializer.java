/**
  * @(#)JSerializer.java
  *
  * JReversePro - Java Decompiler / Disassembler.
  * Copyright (C) 2000 2001 Karthik Kumar.
  * EMail: akkumar@users.sourceforge.net
  *
  * This program is free software; you can redistribute it and/or modify
  * it , under the terms of the GNU General Public License as published
  * by the Free Software Foundation; either version 2 of the License,
  * or (at your option) any later version.
  *
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  * See the GNU General Public License for more details.
  * You should have received a copy of the GNU General Public License
  * along with this program.If not, write to
  *  The Free Software Foundation, Inc.,
  *  59 Temple Place - Suite 330,
  *  Boston, MA 02111-1307, USA.
  **/
package jreversepro.revengine;

import jreversepro.reflect.JField;
import jreversepro.reflect.JMethod;

import jreversepro.reflect.JConstantPool;
import jreversepro.reflect.JClassInfo;
import jreversepro.reflect.JImport;

import jreversepro.runtime.JSymbolTable;

import jreversepro.parser.JClassParser;
import jreversepro.parser.ClassParserException;

import jreversepro.common.Helper;
import jreversepro.common.KeyWords;
import jreversepro.common.AppConstants;


import java.util.List;
import java.util.Set;

import java.io.File;
import java.io.IOException;

import java.net.URL;



/**
 * Serializes the Classes to a String
 * @author Karthik Kumar
 * @version 1.3
 * $version$
 **/
public class JSerializer
    implements KeyWords
{

    String CurrentClass;
    static JClassParser mClassParser;
    JClassInfo mInfoClass;
    JImport    importInfo;

    static {
        mClassParser = new JClassParser();
    }

    public JClassInfo loadClass(File aFile)
        throws ClassParserException,
               IOException
    {
        mClassParser.parse(aFile);
        String ThisClass = aFile.getName();
        mInfoClass = mClassParser.getClassInfo();
        importInfo = mInfoClass.getConstantPool().getImportedClasses();

        CurrentClass = ThisClass.substring(0, ThisClass.indexOf('.') );
        return mInfoClass;
    }

    public JClassInfo loadClass(URL url)
        throws ClassParserException,
               IOException
    {
        mClassParser.parse(url);


        mInfoClass = mClassParser.getClassInfo();
        importInfo = mInfoClass.getConstantPool().getImportedClasses();

        // xxx - bad hack.  we need to get the class name from somewhere else
        String thisClass = url.getPath();
        thisClass = thisClass.substring(thisClass.lastIndexOf('/')+1);
        CurrentClass = thisClass.substring(0, thisClass.indexOf('.'));

        return mInfoClass;
    }

    /**
     * Reverse Engineer the Class file.
     * @param aFile File reference containing the class file to be
     * reverse engineered.
     * @return  true, if successfully reverse engineered.
     * @throws ClassParserException Thrown if class file not in proper format.
     * @throws IOException Thrown if error occured in reading class file.
     * @throws RevEngineException Thrown if error occured in reverse
     * engineering file.
     **/
    public String reverseEngineer( boolean aDecompileFlag )
                        throws ClassParserException,
                                IOException,
                                RevEngineException {
        //Reverse Engineer here
        long Start = System.currentTimeMillis();
        StringBuffer sb =  new StringBuffer();
        JImport imports = mInfoClass.getConstantPool().getImportedClasses();
        sb.append( getHeaders() );
        sb.append( getPackageImports() );
        sb.append( getThisSuperClasses() );

        sb.append( getInterfaces()  + "{" );
        sb.append( getFields() );
        sb.append( getMethods(aDecompileFlag) );

        long TimeElapse = System.currentTimeMillis() - Start;
        sb.append( "\n}\n// " + TimeElapse +
                " milliseconds" );
        return sb.toString();
    }


    public final JConstantPool getCpInfo() {
        return mInfoClass.getConstantPool();
    }

    private StringBuffer getHeaders() {
        StringBuffer init =  new StringBuffer();
        init.append("// Decompiled by JReversePro " + AppConstants.VERSION);
        init.append("\n// Home : http://jrevpro.sourceforge.net ");
        init.append("\n// JVM VERSION: " +
                            mInfoClass.getMajor() + "." +
                            mInfoClass.getMinor() );
        init.append( "\n// SOURCEFILE: " +
                            mInfoClass.getSourceFile() );
        return init;
    }

    private StringBuffer getPackageImports() {
        StringBuffer result =  new StringBuffer();
        String thisClass = mInfoClass.getThisClass();
        String packageName = Helper.getPackageName(
                                         thisClass);
        if ( packageName.length() != 0 ) {
            result.append( "\npackage " +
                        packageName +  ";");
        }
        result.append( "\n" +
                importInfo.getImportClasses(packageName) );
        return result;
    }

    private StringBuffer getThisSuperClasses() {
        StringBuffer sb =  new StringBuffer();
        String SuperClass = mInfoClass.getSuperClass();


        sb.append( "\n" + mInfoClass.getAccessString() + " ");
        sb.append(CurrentClass );

        if( SuperClass.compareTo( LANG_OBJECT ) !=  0 ){
            sb.append( " extends ");
            sb.append( importInfo.getClassName(SuperClass) );
        }
        return sb;
    }

    private StringBuffer getInterfaces() {

        List interfaces = mInfoClass.getInterfaces();
        StringBuffer sb = new StringBuffer();
        if ( interfaces.size() != 0 ) {
        sb.append("\n\t\timplements ");
        for( int i = 0 ; i < interfaces.size() ;i++ ) {
            if( i!= 0  ) sb.append(" ,");
            sb.append(
                    importInfo.getClassName(
                            (String)interfaces.get(i)) );
            }
        }
        return sb;
    }

    private StringBuffer getFields() {

        StringBuffer sb = new StringBuffer();
        List listFields = mInfoClass.getFields();
        for(int i = 0 ; i < listFields.size() ; i++ ) {
            JField field = (JField) listFields.get(i);
            String dataType =
                importInfo.getClassName(
                    Helper.getJavaDataType(
                        field.getDatatype(), false) );

            String Access = field.getQualifierName();

            sb.append( "\n\t" + Access );
            sb.append( dataType );
            sb.append( " " + field.getName() );
            String val = field.getValue();
            if( field.isFinal() && val.length() != 0 ) {
                sb.append( " = " + val );
            }
            sb.append(";");
        }
        return sb;
    }

    private StringBuffer getMethods( boolean aDecompileFlag )
                    throws RevEngineException,
                           ClassParserException,
                                IOException {

        StringBuffer sb =  new StringBuffer();
        List listMethods = mInfoClass.getMethods();
        for(int i = 0 ; i < listMethods.size() ; i++ ) {
            JMethod method = ( JMethod ) listMethods.get(i);
            String returnType =
                importInfo.getClassName(
                    Helper.getJavaDataType(
                        method.getReturnType(), false) );

            String Name = method.getName();
            sb.append("\n\n\t");

            if( Name.compareTo(CLINIT) ==  0 ) {
                    sb.append("static");
            }
            else if( Name.compareTo(INIT) == 0 ) {
                sb.append( method.getQualifierName() );
                sb.append(CurrentClass);
            }
            else {
                sb.append( method.getQualifierName() );
                sb.append( returnType );
                sb.append( " " + method.getName() );
            }
            JReverseEngineer jre;
            if( aDecompileFlag ) {
                jre =
                    new JDecompiler( method,
                            mInfoClass.getConstantPool() );
            } else {
              jre = new JDisAssembler(
                   method,
                   mInfoClass.getConstantPool() );
            }
            try{
                sb.append( jre.genCode() );
            } catch ( Exception ex ) {
              ex.printStackTrace();
            }
        }
        return sb;
    }
}
