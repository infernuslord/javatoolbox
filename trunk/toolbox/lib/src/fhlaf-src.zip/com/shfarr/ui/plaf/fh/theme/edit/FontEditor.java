/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh.theme.edit;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.shfarr.ui.layouts.FlexibleGridLayout;
import com.shfarr.ui.layouts.QueueLayout;


public class FontEditor extends JPanel implements ActionListener, ChangeListener{
    private JComboBox fontCombo = null;
    private JPanel editor = null;
    private JLabel sampleLabel = null;
    private JPanel sidePanel = null;
    private JCheckBox italicCheckBox = null;
    private JCheckBox boldCheckBox = null;
    private JPanel centerPanel = null;
    private JComboBox namesCombo = null;
    private JSpinner sizeSpinner = null;
    
    public FontEditor(){
        super(new BorderLayout());
        setBorder(new EmptyBorder(10, 4, 4, 0));
        
        add(getSidePanel(), "East");
        add(getCenterPanel(), "Center");
    }

    protected JPanel getCenterPanel(){
        if(centerPanel == null){
            centerPanel = new JPanel(new BorderLayout(4, 4));
            centerPanel.setBorder(new EmptyBorder(0, 0, 0, 4));

            JPanel aPanel = new JPanel(new QueueLayout(4, QueueLayout.HORIZONTAL, QueueLayout.STRECH_COMPONENTS));
            aPanel.add(new JLabel("Font"));
            aPanel.add(getNamesCombo());
            
            centerPanel.add(aPanel, "North");
            centerPanel.add(new JScrollPane(getSampleLabel()), "Center");
            centerPanel.add(getEditor(), "South");
        }
    
        return centerPanel;
    }

    protected JComboBox getFontCombo(){
        if(fontCombo == null){
            fontCombo = new JComboBox();
            
            Font[] fonts = GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();
            for(int i = 0; i < fonts.length; i++) fontCombo.addItem(fonts[i].getName());
            
            fontCombo.addActionListener(this);
        }
    
        return fontCombo;
    }
    
    protected JLabel getSampleLabel(){
        if(sampleLabel == null){
            sampleLabel = new JLabel("Sample Text", JLabel.CENTER);
            sampleLabel.setOpaque(true);
            sampleLabel.setPreferredSize(new Dimension(100, 100));
            sampleLabel.setBorder(new EmptyBorder(5, 5, 5, 5));
        }
    
        return sampleLabel;
    }

    protected JCheckBox getBoldCheckBox(){
        if(boldCheckBox == null){
            boldCheckBox = new JCheckBox("Bold");
            boldCheckBox.addActionListener(this);
        }
    
        return boldCheckBox;
    }    
    
    protected JCheckBox getItalicCheckBox(){
        if(italicCheckBox == null){
            italicCheckBox = new JCheckBox("Italic");
            italicCheckBox.addActionListener(this);
        }
    
        return italicCheckBox;
    }    

    protected JComboBox getNamesCombo(){
        if(namesCombo == null){
            namesCombo = new JComboBox();
            
            for(Iterator i = ThemeEditor.instance().getEditedTheme().fontPalette().keySet().iterator(); i.hasNext(); ) namesCombo.addItem(i.next());

            namesCombo.addActionListener(this);
            
            selectFont((String)namesCombo.getItemAt(0));
        }
    
        return namesCombo;
    }

    protected JSpinner getSizeSpinner(){
        if(sizeSpinner == null){
            sizeSpinner = new JSpinner(new SpinnerNumberModel(1, 1, 1000, 1));
            sizeSpinner.addChangeListener(this);
        }
    
        return sizeSpinner;
    }
    
    protected JPanel getEditor(){
        if(editor == null){
            editor = new JPanel(new FlexibleGridLayout(3, 2, 4, 4));
            editor.add(getFontCombo());
            editor.add(getSizeSpinner());

            editor.add(getBoldCheckBox());
            editor.add(new JLabel());
            editor.add(getItalicCheckBox());
            editor.add(new JLabel());
        }
    
        return editor;
    }
    
    protected JPanel getSidePanel(){
        if(sidePanel == null){
            sidePanel = new JPanel(new QueueLayout(4, QueueLayout.VERTICAL, QueueLayout.STRECH_COMPONENTS));
            sidePanel.setBorder(new EmptyBorder(0, 4, 4, 4));
            
            JButton save = new JButton("Save");
            save.addActionListener(this);
            
            JButton revert = new JButton("Revert");
            revert.addActionListener(this);
            
            sidePanel.add(save);
            sidePanel.add(revert);
        }
    
        return sidePanel;
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource() == getNamesCombo()) selectFont(getNamesCombo().getSelectedItem().toString());
        
        if(e.getSource() == getFontCombo()){
            getSampleLabel().setFont(new Font(getFontCombo().getSelectedItem().toString(), getSampleLabel().getFont().getStyle(), getSampleLabel().getFont().getSize()));
        }
        
        if(e.getSource() instanceof JCheckBox){
            int style = Font.PLAIN;
            
            if(getBoldCheckBox().isSelected()) style = style | Font.BOLD;
            if(getItalicCheckBox().isSelected()) style = style | Font.ITALIC;
            
            getSampleLabel().setFont(getSampleLabel().getFont().deriveFont(style));
        }
        
        if(e.getActionCommand().equals("Save")){
            ThemeEditor.instance().getEditedTheme().fontPalette().put(getNamesCombo().getSelectedItem().toString(), getSampleLabel().getFont());
            ThemeEditor.instance().getEditedTheme().saveFonts();
        }
        else if(e.getActionCommand().equals("Revert")){
            selectFont(getNamesCombo().getSelectedItem().toString());
        }
    }
    
    protected void selectFont(String name){
        Font font = (Font)ThemeEditor.instance().getEditedTheme().fontPalette().get(name);
        
        getSampleLabel().setFont(font);
        getFontCombo().setSelectedItem(font.getName());
        getBoldCheckBox().setSelected(font.isBold());
        getItalicCheckBox().setSelected(font.isItalic());
        getSizeSpinner().setValue(new Integer(font.getSize()));
    }

    public void stateChanged(ChangeEvent e){
        getSampleLabel().setFont(getSampleLabel().getFont().deriveFont(((Integer)getSizeSpinner().getValue()).floatValue()));
    }
}
