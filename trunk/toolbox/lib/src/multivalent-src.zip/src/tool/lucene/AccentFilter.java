package tool.lucene;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.lucene.analysis.*;

import phelps.lang.Strings;



/**
	Produce an additional 7-bit ASCII version of {@link Term},
	since on some systems it's awkward to type in accents.
	Keeps characters numbered 0..127 as is,
	drops accents on letters (e.g., "&Agrave;" => "A")
	and translates various other symbols (e.g., "&copy;" => "(C)"),
	and drops other characters not in translation tables.

	@author T.A. Phelps

	@version $Revision: 1.3 $ $Date: 2003/06/01 07:33:52 $
*/
public class AccentFilter extends TokenFilter {

  private Token pending__ = null;

  public AccentFilter(TokenStream in) {
	super(in);
  }

  public Token next() throws IOException {
	Token tok;

	if (pending__==null) {
		tok = input.next();
		if (tok != null && ("word".equals(tok.type()) || "<ALPHANUM>".equals(tok.type())/*StandardTokenizer*/)) {
			String txt = tok.termText(), newtxt = Strings.toASCII7(txt);
			if (txt != newtxt) pending__ = new Token(newtxt, tok.startOffset(), tok.endOffset(), tok.type());
		}

	} else {
		tok = pending__;
		pending__ = null;
	}

	return tok;
  }
}
