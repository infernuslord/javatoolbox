// $Id: LiteralExpr.java,v 1.1 2002/04/25 18:08:21 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

class LiteralExpr extends ConvertibleStringExpr {
    private final String literal;

    LiteralExpr(String literal) {
        this.literal = literal;
    }

    public String eval(Node node, ExprContext context) {
        return literal;
    }

    public String constantValue() {
        return literal;
    }
}
