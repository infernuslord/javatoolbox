/*
 * 
 * Created on 2004-jul-25
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.common;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.UIManager;
import javax.swing.plaf.metal.MetalScrollButton;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-25
 *
 */
public class ScrollButton extends MetalScrollButton {
	private boolean isFreeStanding;

	private static Color shadowColor;
	private static Color highlightColor;



	/**
	 * 
	 * Constructor
	 * 
	 * @param direction	NORTH, SOUTH, EAST, WEST
	 * @param width The width of the button
	 * @param freeStanding
	 */
	public ScrollButton(int direction, int width, boolean freeStanding) {
		super( direction, width, freeStanding );
		shadowColor    = UIManager.getColor("ScrollBar.darkShadow");
		highlightColor = UIManager.getColor("ScrollBar.highlight");
		isFreeStanding = freeStanding;
	}




	/**
	 * 
	 *
	 */
	public void setFreeStanding( boolean freeStanding ) {
		super.setFreeStanding( freeStanding );
		isFreeStanding = freeStanding;
	}




	/**
	 * 
	 *
	 */
	public void paint( Graphics g ) {
		Graphics g2 = g.create();
		
		boolean isEnabled   = getParent().isEnabled();
		boolean isPressed   = getModel().isPressed();

		// TODO FIXED COLOR, BIG NONO!
		Color arrowColor = new Color( 155, 155, 155 );//= isEnabled ? HippoLookAndFeel.getControlInfo() : HippoLookAndFeel.getControlDisabled();
		int width		= getWidth();
		int height		= getHeight();
		int w			= width;
		int h			= height;
		int arrowHeight	= (height + 1) / 4;

		if( !isEnabled ) {
			g2.setColor( getParent().getParent().getBackground() );
			g2.fillRect(0, 0, width, height);
		} else {
			if( isPressed ) {
				g2.setColor( new Color( 200, 200, 200 ) );  // FIXED COLOR, BIG NONO!
			} else {
				g2.setColor( UIManager.getColor( "Button.background" ) );
			}

			g2.fillRect(0, 0, width, height);
		}

		g2.setColor( new Color( 155, 155, 155 ) ); // FIXED COLOR, BIG NONO!
		g2.drawRect(0, 0, width-1, height-1);

		g2.dispose();
		
		if( getDirection() == NORTH ) {
			paintNorth(g, true, isEnabled, arrowColor, isPressed, width, height, w, h, arrowHeight);
		} else if (getDirection() == SOUTH) {
			paintSouth(g, true, isEnabled, arrowColor, isPressed, width, height, w, h, arrowHeight);
		} else if (getDirection() == EAST) {
			paintEast(g, isEnabled, arrowColor, isPressed, width, height, w, h, arrowHeight-1);
		} else if (getDirection() == WEST) {
			paintWest(g, isEnabled, arrowColor, isPressed, width, height, w, h, arrowHeight-1);
		}
	}




	/**
	 * 
	 * @param g
	 * @param isEnabled
	 * @param arrowColor
	 * @param isPressed
	 * @param width
	 * @param height
	 * @param w
	 * @param h
	 * @param arrowHeight
	 */
	private void paintWest(Graphics g, boolean isEnabled, Color arrowColor, boolean isPressed, int width, int height, int w, int h, int arrowHeight) {
		Graphics g2 = g.create();
		
		
		// Draw the arrow
		g2.setColor( new Color( 55, 55, 55 ) );  // FIXED COLOR, BIG NONO!
		//g.setColor(arrowColor);
	
		int startX = (((w + 1) - arrowHeight) / 2);
		int startY = (h / 2);
	
		for (int line = 0; line < arrowHeight; line++) {
			g2.drawLine(
				startX + line,
				startY - line,
				startX + line,
				startY + line + 1);
		}
	
		if (isEnabled) {
			if (!isPressed) {
			}
		}

		g2.dispose();
	}




	/**
	 * 
	 * 
	 */
	private void paintEast(Graphics g, boolean isEnabled, Color arrowColor, boolean isPressed, int width, int height, int w, int h, int arrowHeight) {
		Graphics g2 = g.create();

		// Draw the arrow
		g2.setColor( new Color( 55, 55, 55 ) );  // FIXED COLOR, BIG NONO!
	
		int startX = (((w + 1) - arrowHeight) / 2) + arrowHeight - 1;
		int startY = (h / 2);
		for (int line = 0; line < arrowHeight; line++) {
			g.drawLine(
				startX - line,
				startY - line,
				startX - line,
				startY + line + 1);
		}
	
		if (isEnabled) {
		}

		g2.dispose();
	}




	/**
	 * 
	 * @param g
	 * @param leftToRight
	 * @param isEnabled
	 * @param arrowColor
	 * @param isPressed
	 * @param width
	 * @param height
	 * @param w
	 * @param h
	 * @param arrowHeight
	 */
	private void paintSouth(Graphics g, boolean leftToRight, boolean isEnabled,
		Color arrowColor, boolean isPressed, int width, int height, int w, int h,
		int arrowHeight) {

		Graphics g2 = g.create();

		// Draw the arrow
		g2.setColor( new Color( 55, 55, 55 ) );  // FIXED COLOR, BIG NONO!
		//g.setColor(arrowColor);
	
		int startY = (((h + 1) - arrowHeight) / 2) + arrowHeight - 1;
		int startX = (w / 2);
	
		//	    System.out.println( "startX2 :" + startX + " startY2 :"+startY);
	
		for (int line = 0; line < arrowHeight; line++) {
			g2.drawLine(
				startX - line,
				startY - line,
				startX + line + 1,
				startY - line);
		}
	
		if (isEnabled) {
			if (!isPressed) {
			}
		}

		g2.dispose();
	}




	/**
	 * 
	 * 
	 */
	private void paintNorth(Graphics g, boolean leftToRight, boolean isEnabled, Color arrowColor, boolean isPressed, int width, int height, int w, int h, int arrowHeight) {
		Graphics g2 = g.create();

		// Draw the arrow
		g2.setColor( new Color( 55, 55, 55 ) );  // FIXED COLOR, BIG NONO!
		//g.setColor(arrowColor);
		int startY = ((h + 1) - arrowHeight) / 2;
		int startX = (w / 2);
		// System.out.println( "startX :" + startX + " startY :"+startY);
		for (int line = 0; line < arrowHeight; line++) {
			g2.drawLine(
				startX - line,
				startY + line,
				startX + line + 1,
				startY + line);
		}
	
		if (isEnabled) {
			if (!isPressed) {
			}
		}

		g2.dispose();
	}
}
