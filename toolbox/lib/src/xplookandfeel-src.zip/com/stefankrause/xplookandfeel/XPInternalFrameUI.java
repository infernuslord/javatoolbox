// Beta
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	XP Look and Feel														   *
*															                   *
*  (C) Copyright 2002, by Stefan Krause, Taufik Romdhane and Contributors      *
*                                                                              *
*                                                                              *
* The XP Look and Feel started as as extension to the Metouia Look and Feel.   *
* The original header of this file was:                                        *
** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*        Metouia Look And Feel: a free pluggable look and feel for java        *
*                         http://mlf.sourceforge.net                           *
*          (C) Copyright 2002, by Taoufik Romdhane and Contributors.           *
*                                                                              *
*   This library is free software; you can redistribute it and/or modify it    *
*   under the terms of the GNU Lesser General Public License as published by   *
*   the Free Software Foundation; either version 2.1 of the License, or (at    *
*   your option) any later version.                                            *
*                                                                              *
*   This library is distributed in the hope that it will be useful,            *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of             *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                       *
*   See the GNU Lesser General Public License for more details.                *
*                                                                              *
*   You should have received a copy of the GNU General Public License along    *
*   with this program; if not, write to the Free Software Foundation, Inc.,   *
*   59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.                    *
*                                                                              *
*   Original Author:  Taoufik Romdhane                                         *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


package com.stefankrause.xplookandfeel;

import java.awt.Component;

import javax.swing.DesktopManager;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.metal.MetalInternalFrameUI;


/**
 * This class represents the UI delegate for the JInternalFrame component and
 * its derivates.
 *
 * @author Taoufik Romdhane
 */
public class XPInternalFrameUI extends MetalInternalFrameUI {

	XPInternalFrameBorder frameBorder=new XPInternalFrameBorder();
	
	/**
	 * If this flag is set, Internal Frames can have rounded vertices.
	 * Since a new DesktopManager has to be installed this is quite an 
	 * involving process that might cause errors. So for compatibility and
	 * performance reasons this can be disabled with the property
	 * xplookandfeel.roundedWindows=false
	 */
	static boolean allowRoundedWindows=true;
	
//	static Border disabledBorder=new XPInternalFrameBorder(false);
	
	/**
	 * The metouia version of the internal frame title pane.
	 */
	private XPInternalFrameTitlePane titlePane;

	/**
	 * Creates the UI delegate for the given frame.
	 *
	 * @param frame The frame to create its UI delegate.
	 */
	public XPInternalFrameUI(JInternalFrame frame) {
		super(frame);
	}

	/**
	 * Creates the UI delegate for the given component.
	 *
	 * @param c The component to create its UI delegate.
	 * @return The UI delegate for the given component.
	 */
	public static ComponentUI createUI(JComponent c) {
		return new XPInternalFrameUI((JInternalFrame) c);
	}

	JDesktopPane getDesktopPane(JComponent frame) {
		JDesktopPane pane = null;
		Component c = frame.getParent();

		// Find the JDesktopPane
		while (pane == null) {
			if (c instanceof JDesktopPane) {
				pane = (JDesktopPane) c;
			} else if (c == null) {
				break;
			} else {
				c = c.getParent();
			}
		}

		return pane;
	}

    private static DesktopManager sharedDesktopManager;

    protected DesktopManager getDesktopManager() {
    	if (!allowRoundedWindows)
    		return super.getDesktopManager();
    	
		if(sharedDesktopManager == null)
		  sharedDesktopManager = createDesktopManager();
		return sharedDesktopManager;	
    }
  
    protected DesktopManager createDesktopManager(){
		if (!allowRoundedWindows)
    		return super.createDesktopManager();
    	else
    		return new XPDesktopManager();
    }

	public void installUI(JComponent c) {
		super.installUI(c);
		if (allowRoundedWindows)
			frame.setOpaque(false);
		frame.setBorder(frameBorder);
	}

	/**
	 * Creates the north pane (the internal frame title pane) for the given frame.
	 *
	 * @param frame The frame to create its north pane.
	 */
	protected JComponent createNorthPane(JInternalFrame frame) {
		super.createNorthPane(frame);
		titlePane = new XPInternalFrameTitlePane(frame);
		return titlePane;
	}
    protected void activateFrame(JInternalFrame f) {
		super.activateFrame(f);
		frameBorder.setActive(true);
		titlePane.activate();
    }
    /** This method is called when the frame is no longer selected.
      * This action is delegated to the desktopManager.
      */
    protected void deactivateFrame(JInternalFrame f) {
		super.deactivateFrame(f);
		frameBorder.setActive(false);
		titlePane.deactivate();
    }
	/**
	 * Changes this internal frame mode from / to palette mode.
	 * This affect only the title pane.
	 *
	 * @param isPalette The target palette mode.
	 */
	public void setPalette(boolean isPalette) {
		super.setPalette(isPalette);
		titlePane.setPalette(isPalette);
		frame.setBorder(frameBorder);
	}
}