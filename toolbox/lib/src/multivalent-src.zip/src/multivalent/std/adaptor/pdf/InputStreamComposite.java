package multivalent.std.adaptor.pdf;

import java.io.*;
import phelps.io.RandomAccess;

import static multivalent.std.adaptor.pdf.COS.*;



/**
	Merges possibly multiple component {@link java.io.InputStream}s,
	possibly with encodings such as Flate and ASCIIHex,
	possibly with a Predictor (on LZW or Flate),
	possibly encrypted.
	Does not expand out image-specific filters (DCT, FAX, JBIG2).
	Allows one character of {@link #unread(int)} and {@link #peek()}.

	@see DecodeASCII85
	@see DecodeASCIIHex
	@see DecodeRunLength
	@see phelps.io.InputStreamLZW
	@see java.util.zip.InflaterInputStream
	@see DecodePredictor

	@version $Revision: 1.26 $ $Date: 2003/10/19 14:46:01 $
*/
public class InputStreamComposite extends /*Filter?*/InputStream {
  static final boolean DEBUG = false;

  static final int INVALID_CHAR = -2;   // -1 is EOF
  private static final Object[] OBJECTARRAY0 = new Object[0];

  private PDFReader pdfr_;
  private Object[] sub_;
  private int subi_ = -1;
  private InputStream in_ = null;
  private int pushch_ = INVALID_CHAR;
  private boolean isContent_, didBogusSpace_;     // commands split over substreams have implicit separating whitespace


  /**
	Returns stream of buffered, decrypted, uncompressed data; image filters not processed.
	Referenced stream dictionary (via IRef, Object[], or direct {@link Dict}) can supply inline data by setting {@link COS#STREAM_DATA} key with byte[].
	@param ref  can be {@link COS#CLASS_DICTIONARY} for stream with filters, {@link IRef} to stream or array or streams, Object[] of IRef's to stream, or {@link COS#CLASS_DATA} for final data requiring no filters.
	@param iscontent    declare whether stream corresponds to page contents, and if so insert extra space between each pair of substreams, to handle corner case where concatenated streams don't have such space and would concatenate commands or arguments.
  */
  public InputStreamComposite(Object obj, boolean iscontent, PDFReader pdfr) throws IOException {
	assert obj!=null && (CLASS_ARRAY==obj.getClass() || CLASS_IREF==obj.getClass() || CLASS_DATA==obj.getClass() || CLASS_DICTIONARY==obj.getClass()): "unknown stream type: "+(obj!=null? obj.getClass().getName(): null);
	assert pdfr!=null;

	isContent_ = iscontent;
	pdfr_ = pdfr;

	//System.out.println(o+" in "+obj.getClass().getName());
	Class cl = obj.getClass();
	Object sub;
	if (CLASS_ARRAY==cl) {    // composite: array of streams
		sub = obj;

	} else if (CLASS_IREF==cl) {
		Object ant = pdfr_.getObject(obj);
		if (CLASS_ARRAY==ant.getClass()) {    // array of streams
			sub = ant;
		} else { assert CLASS_DICTIONARY==ant.getClass();
			sub = obj;    // not ant -- keep IRef for decrypting
		}
//if (DEBUG) System.out.println("single stream: "+obj+" => "+pdfr_.getObject(o));

	} else if (CLASS_DATA==cl) { // some client supplied content, wants to call peek(), unread(), pdf_.readToken()
		Dict fake = new Dict(5);
		fake.put(STREAM_DATA, obj);
		sub = fake;

	} else { assert CLASS_DICTIONARY==cl: cl;
		sub = obj;
	}

	if (CLASS_ARRAY==sub.getClass()) {
		Object[] oa = (Object[])sub;
		if (oa.length == 0) { Dict fake=new Dict(5); fake.put(STREAM_DATA, new byte[0]); sub_=new Object[] { fake }; } // Ghostscript 6.53 has done this
		else sub_ = (Object[])oa.clone();
	} else { sub_ = new Object[] { sub }; }    // everybody gets fresh Object[] so we can null out references and help gc

	didBogusSpace_ = true;
	nextStream();   // X don't want IOException on instantiation => FileInputStream construtor throws exception too
  }



  /**
	Returns next character without advancing file position pointer, so that next peek() or read() returns same character at same position.
	Side effect: pushback character is set.
  */
  public int peek() throws IOException { if (INVALID_CHAR==pushch_) pushch_=read(); return pushch_; }

  /**
	Pushes back one character of stream, so that the next read() will return it.
  */
  public void unread(int c) {
	assert pushch_==INVALID_CHAR: "already have a pushback";
	assert c>=-1 && c<=255: "pushed back "+c+" not -1 (EOF) or in 0..255";

	pushch_ = c;
  }


  public int read() throws IOException {
	int c;

	if (pushch_!=INVALID_CHAR) { c=pushch_; pushch_=INVALID_CHAR; }
//	else if (raf_==null) c=INVALID_CHAR;   // repeated reads at end of file (substreams should handle this)
	else if (/*in_==null ||*/ (c=in_.read())==-1) {
		if (isContent_ && !didBogusSpace_) { c=' '; didBogusSpace_=true; }
		else if (subi_+1 < sub_.length/*exists a next stream*/) { nextStream(); c=/*in_.*/read(); }    // must recurse in case have 0-length stream and immediately get -1 again
	}

	return c;
  }

  public int read(byte[] b, int off, int len) throws IOException {
	assert b!=null && off>=0 && len>=0 && len+off <= b.length: "b="+b+", off="+off+", len+off="+(len+off)+" vs "+b.length;
//System.out.print("read(byte[], "+off+", "+len+") on "+in_.getClass().getName()+":  ");

	if (len==0) return 0;
	if (pushch_!=INVALID_CHAR) { b[off]=(byte)pushch_; pushch_=INVALID_CHAR; /*off++; len--;*/ return 1;/*rarely mix block read and peek()*/ }

	int cnt = in_.read(b, off, len);    // streams already buffered in ByteArrayInputStream
	if (cnt==-1) {
		if (isContent_ && !didBogusSpace_) { b[off] = (byte)' '; didBogusSpace_=true; return 1; }
		else if (subi_+1 < sub_.length /*is a next stream*/) { nextStream(); return /*in_.*/read(b, off, len); }    // must recurse in case have 0-length stream and immediately get -1 again
	}

	return cnt;
  }


  private void nextStream() throws IOException {
//System.out.println("nextStream(), subi_="+subi_+", len="+sub_.length);
	if (subi_+1 >= sub_.length) return;  // don't close last stream -- do that with InputStreamComposite.close()

	// close up old, if any
	if (subi_ >= 0) { in_.close(); sub_[subi_]=null; }  // null out reference because may have ByteArrayInputStream with big byte[] that's not freed on close()

	Object ref = sub_[++subi_];
	boolean fdecrypt = false;
	didBogusSpace_ = false;  // resets when coming back to stream after pushing XObject Form, which is OK

	InputStream is;

	Dict dict = (Dict)pdfr_.getObject(ref);
//System.out.println("nextStream ref = "+ref+" / "+ref.getClass().getName()+" = "+dict.get(STREAM_DATA));
if (DEBUG) System.out.println("open new substream "+dict);
	boolean fextern = dict.get("F")!=null;

	Object data = dict.get(STREAM_DATA);
	if (data!=null && CLASS_DATA==data.getClass()) {   // data inline
		byte[] buf = (byte[])data;
		is = new ByteArrayInputStream(buf);
//System.out.println("inline data, len="+buf.length);
		// assumed already decrypted since not from PDF file

	} else if (fextern) {
PDF.sampledata("external file");
		InputStream exis = pdfr_.getFileInputStream(dict.get("F"));
		is = (exis instanceof BufferedInputStream? exis: // embedded -- and already decypted
			new BufferedInputStream(exis, 8*1024)); // file or network -- and not encrypted

	} else if (/*dict.get("Length")==null--not stream w/o /Length ||*/ data==null) {  //  invalid content stream -- skip.  Done by Panda v0.2.
		is = new ByteArrayInputStream(new byte[0]);

	} else { assert data instanceof Number: data;   // data at given offset in file
//if (pdfr_.getRAF()==null || dict.get("Length")==null) { System.out.println("null: "+data+" "+" "+pdfr_.getRAF()+" "+dict.get("Length")); System.exit(1); }
		RandomAccess raf = pdfr_.getRAF();
		File f = pdfr_.getFile();
		long off = ((Number)data).longValue();
		int len = pdfr_.getObjInt(dict.get("Length"));

		// streams (1) not reliant on RAF so can jump to other objects (images, forms), (2) buffered so don't need BufferedInputStream wrapper
		if (raf==null) {	// characters in Type3 fonts getting re-encoded
			in_ = new ByteArrayInputStream(new byte[0]);
			return; //throw new IOException("RAF closed");

		} else if (f!=null && len > 100*1024) {	// incremental from file
//System.out.println("incremental through ISSlice @ "+off+" on "+f);
			is = new phelps.io.InputStreamSlice(new phelps.io.InputStreamRandomAccess(f), off, len);

		} else {
			byte[] buf = new byte[len];
			raf.seek(off);
			raf.readFully(buf);
//System.out.println("read fully @ "+data+", len "+len+": "+buf[0]+" "+buf[1]+" "+buf[2]+"...");
			//eatSpace();  // could verify "endstream"
			//for (int i=0,imax="endstream".length(); i<imax; i++) if ("endstream".charAt(i) != raf.read()) { System.out.println("premature end of stream, obj #"+num); break; }
			is = new ByteArrayInputStream(buf);
		}
		fdecrypt = true;	// only decrypt when read from (1) this PDF, (2) for first time
	}

	in_ = wrapStream(is, ref, fdecrypt);
  }

  private InputStream wrapStream(InputStream is, Object ref, boolean fdecrypt) throws IOException {     //-- also fextern for filter selection, buf (buf validity spot checks), ref for error reporting
//System.out.println(ref+" "+dp);
	// filters, possibly chained
	Dict dict = (Dict)pdfr_.getObject(ref);
	boolean fextern = dict.get("F")!=null;
	Object o = pdfr_.getObject(dict.get(fextern? "FFilter": "Filter"));
	Object dp = pdfr_.getObject(dict.get(fextern? "FDecodeParms": "DecodeParms")); if (dp==null) dp = pdfr_.getObject(dict.get("DP"));   // "DP" expanded by PDFReader but maybe had setExact(true)
	Object[] oa; if (o==null) oa=OBJECTARRAY0; else if (o.getClass()==CLASS_NAME) { oa=new Object[1]; oa[0]=o; } else oa=(Object[])o;
	Object[] dpa=new Object[oa.length]; if (dp==null || dpa.length==0) {} else if (dp.getClass()==CLASS_DICTIONARY) dpa[0]=(Dict)dp; else dpa=(Object[])dp;
	Encrypt e = pdfr_.getEncrypt();
	int objnum=-1, gennum=-1; if (CLASS_IREF==ref.getClass()) { IRef iref = (IRef)ref; objnum=iref.id; gennum=pdfr_.getObjGen(iref.id); }
	//assert oa.length == dpa.length;   // can be ok if not true: if don't have LZW/Flate after last dp

	// if no explicit CryptFilter on stream, use default (apply first in chain)
	if (fdecrypt && e!=null && e.getStmF()!=CryptFilter.IDENTITY && !fextern && CLASS_IREF==ref.getClass() && java.util.Arrays.asList(oa).indexOf("Crypt")==-1) {
		assert objnum!=-1 && gennum!=-1;
		//System.out.println("default encryption "+e.getStmF()+" for "+objnum);
		is = new CryptFilter(e.getStmF(), is, objnum,gennum);
	}

	for (int i=0,imax=oa.length; i<imax; i++) {
		String f = (String)pdfr_.getObject(oa[i]); // .intern()
		o = pdfr_.getObject(dpa[i]); if (OBJECT_NULL==o) o=null;    // dict or null
		Dict parms = (Dict)o;
		boolean flzwflate=false;

//if (DEBUG) System.out.println("wrap in filter = "+f);
		// could use Reflection or Class.forName("pdf."+f); new Instance(args[]); but just a limited number (five) of known filters
		if (OBJECT_NULL==f || "None".equals(f)) {
			// nothing
		} else if ("FlateDecode".equals(f) || "Fl".equals(f)) {
			//assert (b0&0xf)==8 || i>0/*encoded by ASCII or encrypted*/: ref+" "+Integer.toHexString(b0);
			is = new java.util.zip.InflaterInputStream(is/*, parms, pdfr_*/);
			flzwflate = true;
		} else if ("LZWDecode".equals(f) || "LZW".equals(f)) {
			//assert b0==0x80 || i>0: ref+" "+Integer.toHexString(b0);
			int early = 1;
			if (parms!=null && (o=parms.get("EarlyChange"))!=null) {
				early = pdfr_.getObjInt(o);
				assert early==0 || early==1: early;
				if (DEBUG && early==0) System.out.println("early change = "+early);
			}
			is = new phelps.io.InputStreamLZW(is, early==1);
			flzwflate=true;
		} else if ("BZip2Decode".equals(f)) {	// Compact stream
			is = new org.apache.tools.bzip2.CBZip2InputStream(is);
			flzwflate = true;

		} else if ("ASCIIHexDecode".equals(f) || "AHx".equals(f)) is = new DecodeASCIIHex(is);
		else if ("ASCII85Decode".equals(f) || "A85".equals(f)) is = new DecodeASCII85(is);
		else if ("RunLengthDecode".equals(f) || "RL".equals(f)) is = new DecodeRunLength(is);

		else if ("Crypt".equals(f)) {
			assert "CryptFilterDecodeParms".equals(parms.get("Type"));
			assert !fextern && objnum!=-1 && gennum!=-1;
			CryptFilter cf = e.getCryptFilter((String)parms.get("Name"));
			if (fdecrypt && cf!=CryptFilter.IDENTITY) is = new CryptFilter(cf, is, objnum,gennum);

		} else { assert "CCITTFaxDecode".equals(f) || "CCF".equals(f)
			|| "DCTDecode".equals(f) || "DCT".equals(f) || "JPXDecode".equals(f)
			|| "JBIG2Decode".equals(f): f;
			// no image decompression here -- done by Images
			assert i+1==imax: i+" < "+(imax-1);     // image better be last -- no image wrapping image or LZW
		}

		// Predictor for Flate or LZW
		if (flzwflate && parms!=null && (o=parms.get("Predictor"))!=null) {
			int pred = pdfr_.getObjInt(o);
			//if (pred>=10 && pred<15) pred = is.read() + 10;	// >=10 "merely indicates PNG ... in use; the specific ... in incoming data" 
			//System.out.println("predictor = "+pred);
			if (pred!=1 && pred!=10) is = new DecodePredictor(is, pred, parms, pdfr_);
		}
	}

	return is;
  }


  // looks like a FilterInputStream, but not because doesn't take another InputStream and filter it... though could interpret broadly as filtering on File
  /** If no filter, true; else false. */
  public boolean markSupported() { return in_.markSupported(); }

  public synchronized void reset() throws IOException { in_.reset(); pushch_=INVALID_CHAR; }
  public synchronized void mark(int readlimit) { in_.mark(readlimit); }
  public void close() throws IOException {
	//assert in_!=null: "stream already closed"; => done by java.awt.Font.createFont()
	if (in_!=null) { in_.close(); in_=null; /*not raf.close()*/ sub_=null; pdfr_=null; }     // allow multiple calls to close
  }
  public int available() throws IOException { return in_.available() /*+ (pushch_==INVALID_CHAR? 0: 1)*/; }
  public long skip(long n) throws IOException { return in_.skip(n); }
}
