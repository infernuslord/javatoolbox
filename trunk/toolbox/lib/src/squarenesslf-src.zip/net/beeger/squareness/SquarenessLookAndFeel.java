/*
  Copyright (C) 2003-2004 Robert F. Beeger (robert at beeger dot net)
  Licensed under the Academic Free License version 2.0
  OSI Certified Open Source Software

  Visit http://squareness.sourceforge.net/ for new releases of Squareness Look And Feel and other
  skins from the Squareness series.
*/
package net.beeger.squareness;

import javax.swing.LookAndFeel;
import javax.swing.UIDefaults;
import javax.swing.plaf.BorderUIResource;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.metal.MetalLookAndFeel;

import net.beeger.squareness.util.SquarenessBorderFactory;
import net.beeger.squareness.util.SquarenessIconFactory;
import net.beeger.squareness.util.SquarenessMetalTheme;

/**
 * <p>This is the core class of the Squareness Look And Feel.</p>
 * <p>It sets up the colors, fonts, ui delegates as well as other resources and defaults
 * used by this look and feel.</p>
 */
public class SquarenessLookAndFeel extends MetalLookAndFeel
{

  public SquarenessLookAndFeel ()
  {
  }

  /**
   * Is the look and feel a native look and feel?
   * 
   * @return true if the look and feel is a native look and feel, false otherwise
   */
  public boolean isNativeLookAndFeel ()
  {
    return false;
  }

  /**
   * <p>Is this look and feel supported on the underlying plattform?</p>
   * <p><b>Note:</b> The Squareness look and feel is supported on any available plattform. So this method always
   * returns true.</p>
   * 
   * @return true if the look and feel is supported on the underlying plattform, false otherwise.
   */
  public boolean isSupportedLookAndFeel ()
  {
    return true;
  }

  /**
   * Return the description of the look and feel.
   * 
   * @return The description of the look and feel.
   */
  public String getDescription ()
  {
    return DESCRIPTION;
  }

  /**
   * Return the id of the look and feel.
   * 
   * @return The id of the look and feel
   */
  public String getID ()
  {
    return ID;
  }

  /**
   * Return the name of the look and feel.
   * 
   * @return The name of the look and feel.
   */
  public String getName ()
  {
    return NAME;
  }

  //
  // protected interface
  //

  /**
   * Initialize the uiClassID to BasicComponentUI mapping.
   * The JComponent classes define their own uiClassID constants
   * (see AbstractComponent.getUIClassID).  This table must
   * map those constants to a BasicComponentUI class of the
   * appropriate type.
   * 
   * @see #getDefaults
   */
  protected void initClassDefaults (UIDefaults table)
  {
    super.initClassDefaults(table);
    String packageName = "net.beeger.squareness.delegate.";
    table.put("ButtonUI", packageName + "SquarenessButtonUI");
    table.put("RadioButtonUI", packageName + "SquarenessRadioButtonUI");
    table.put("CheckBoxUI", packageName + "SquarenessCheckBoxUI");
    table.put("ToolBarUI", packageName + "SquarenessToolBarUI");
    table.put("ToggleButtonUI", packageName + "SquarenessToggleButtonUI");
    table.put("ScrollBarUI", packageName + "SquarenessScrollBarUI");
    table.put("TabbedPaneUI", packageName + "SquarenessTabbedPaneUI");
    table.put("ComboBoxUI", packageName + "SquarenessComboBoxUI");
    table.put("SliderUI", packageName + "SquarenessSliderUI");
    table.put("InternalFrameUI", packageName + "SquarenessInternalFrameUI");
    table.put("SpinnerUI", packageName + "SquarenessSpinnerUI");

    table.put("ProgressBarUI", "javax.swing.plaf.basic.BasicProgressBarUI");
    table.put("SplitPaneUI", "javax.swing.plaf.basic.BasicSplitPaneUI");
  }

  protected void initComponentDefaults (UIDefaults table)
  {
    setCurrentTheme(new SquarenessMetalTheme());
    super.initComponentDefaults(table);

    table.put(SquarenessConstants.CONTROL_BORDER_COLOR_KEY, new ColorUIResource(34, 57, 73));
    table.put(SquarenessConstants.DEFAULT_BUTTON_BORDER_COLOR_KEY, new ColorUIResource(170, 59, 34));
    table.put(SquarenessConstants.DISABLED_CONTROL_BORDER_COLOR_KEY, new ColorUIResource(134, 144, 150));
    table.put(SquarenessConstants.NORMAL_CONTROL_COLOR_KEY, new ColorUIResource(219, 196, 99));
    table.put(SquarenessConstants.SELECTED_CONTROL_COLOR_KEY, new ColorUIResource(211, 211, 42));
    table.put(SquarenessConstants.SELECTED_CONTROL_SHADOW_COLOR_KEY, new ColorUIResource(163, 159, 28));
    table.put(SquarenessConstants.PROGRESS_BAR_BACKGROUND_COLOR_KEY, new ColorUIResource(245, 246, 220));
    table.put(SquarenessConstants.SCROLLBAR_TRACK_PRESSED_COLOR_KEY, new ColorUIResource(237,225,185));

    table.put(SquarenessConstants.SCROLL_ARROW_LEFT_KEY, new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getLeftIcon();
      }
    });
    table.put(SquarenessConstants.SCROLL_ARROW_RIGHT_KEY, new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getRightIcon();
      }
    });
    table.put(SquarenessConstants.SCROLL_ARROW_UP_KEY, new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getUpIcon();
      }
    });
    table.put(SquarenessConstants.SCROLL_ARROW_DOWN_KEY, new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getDownIcon();
      }
    });

    table.put(SquarenessConstants.SPIN_UP_KEY, new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getSpinUpIcon();
      }
    });
    table.put(SquarenessConstants.SPIN_DOWN_KEY, new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getSpinDownIcon();
      }
    });

    UIDefaults.LazyValue borderWithMargin = new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessBorderFactory.getControlBorderWithMargin();
      }
    };

    UIDefaults.LazyValue borderWithoutMargin = new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessBorderFactory.getControlBorderWithoutMargin();
      }
    };

    UIDefaults.LazyValue tableHeaderCellBorder = new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessBorderFactory.getTableHeaderCellBorder();
      }
    };

    table.put("Button.background", table.getColor(SquarenessConstants.NORMAL_CONTROL_COLOR_KEY));
    table.put("Button.border", borderWithMargin);

    table.put("ToggleButton.background", table.getColor(SquarenessConstants.NORMAL_CONTROL_COLOR_KEY));
    table.put("ToggleButton.border", borderWithMargin);

    table.put("RadioButton.icon", new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getRadioButtonIcon();
      }
    });

    table.put("CheckBox.icon", new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getCheckBoxIcon();
      }
    });

    UIDefaults.LazyValue emptyborder = new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return new BorderUIResource.EmptyBorderUIResource(0, 0, 0, 0);
      }
    };

    UIDefaults.LazyValue menuItemBorder = new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessBorderFactory.getMenuItemBorder();
      }
    };

    UIDefaults.LazyValue menuItemCheckIcon = new UIDefaults.LazyValue()
        {
          public Object createValue (UIDefaults table)
          {
            return SquarenessIconFactory.getMenuItemCheckIcon();
          }
        };

    UIDefaults.LazyValue menuItemArrowIcon = new UIDefaults.LazyValue()
        {
          public Object createValue (UIDefaults table)
          {
            return SquarenessIconFactory.getMenuItemArrowIcon();
          }
        };

    table.put("TextField.border", borderWithoutMargin);
    table.put("FormattedTextField.border", borderWithoutMargin);
    table.put("PasswordField.border", borderWithoutMargin);

    table.put("MenuBar.background", table.getColor(SquarenessConstants.CONTROL_COLOR_KEY));
    table.put("MenuBar.border", emptyborder);

    table.put("Menu.background", null);
    table.put("Menu.border", menuItemBorder);
    table.put("Menu.borderPainted", Boolean.TRUE);
    table.put("Menu.selectionForeground", table.get("textHighlightText"));
    table.put("Menu.selectionBackground", table.get("textHighlight"));
    table.put("Menu.arrowIcon", new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getMenuArrowIcon();
      }
    });
    table.put("Menu.checkIcon", menuItemCheckIcon);

    table.put("MenuItem.background", null);
    table.put("MenuItem.border", menuItemBorder);
    table.put("MenuItem.borderPainted", Boolean.TRUE);
    table.put("MenuItem.selectionForeground", table.get("textHighlightText"));
    table.put("MenuItem.selectionBackground", table.get("textHighlight"));
    table.put("MenuItem.checkIcon", menuItemCheckIcon);

    table.put("RadioButtonMenuItem.background", null);
    table.put("RadioButtonMenuItem.border", menuItemBorder);
    table.put("RadioButtonMenuItem.borderPainted", Boolean.TRUE);
    table.put("RadioButtonMenuItem.selectionForeground", table.get("textHighlightText"));
    table.put("RadioButtonMenuItem.selectionBackground", table.get("textHighlight"));
    table.put("RadioButtonMenuItem.checkIcon", new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getRadioButtonMenuItemCheckIcon();
      }
    });
    table.put("RadioButtonMenuItem.arrowIcon", menuItemArrowIcon);

    table.put("CheckBoxMenuItem.background", null);
    table.put("CheckBoxMenuItem.border", menuItemBorder);
    table.put("CheckBoxMenuItem.borderPainted", Boolean.TRUE);
    table.put("CheckBoxMenuItem.selectionForeground", table.get("textHighlightText"));
    table.put("CheckBoxMenuItem.selectionBackground", table.get("textHighlight"));
    table.put("CheckBoxMenuItem.checkIcon", new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getCheckBoxMenuItemCheckIcon();
      }
    });
    table.put("CheckBoxMenuItem.arrowIcon", menuItemArrowIcon);

    table.put("Separator.foreground", table.getColor(SquarenessConstants.CONTROL_BORDER_COLOR_KEY));
    table.put("Separator.background", null);
    table.put("PopupMenu.border", new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessBorderFactory.getNonSpacingControlBorderWithoutMargin();
      }
    });

    table.put("InternalFrame.border", new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessBorderFactory.getInternalFrameBorder();
      }
    });

    table.put("InternalFrame.icon", null);
    table.put("InternalFrame.maximizeIcon", new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getMaximizeFrameIcon();
      }
    });
    table.put("InternalFrame.minimizeIcon", new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getMinimizeFrameIcon();
      }
    });
    table.put("InternalFrame.iconifyIcon", new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getIconifyFrameIcon();
      }
    });
    table.put("InternalFrame.closeIcon", new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getCloseFrameIcon();
      }
    });

    table.put("ScrollBar.thumb", table.getColor(SquarenessConstants.NORMAL_CONTROL_COLOR_KEY));
    table.put("ScrollBar.background", table.getColor(SquarenessConstants.PROGRESS_BAR_BACKGROUND_COLOR_KEY));
    table.put("ScrollBar.width", new Integer(17));
    table.put("ScrollPane.border", borderWithoutMargin);

    table.put("TableHeader.background", table.getColor(SquarenessConstants.NORMAL_CONTROL_COLOR_KEY));

    table.put("ToolBar.border", emptyborder);
    table.put("ToolBar.background", table.get(SquarenessConstants.CONTROL_COLOR_KEY));

    table.put("ComboBox.border", borderWithoutMargin);
    table.put("ComboBox.background", table.get(SquarenessConstants.WINDOW_COLOR_KEY));
    table.put("ComboBox.selectionBackground", table.get("textHighlight"));
    table.put("ComboBox.selectionForeground", table.get("textHighlightText"));

    table.put("ProgressBar.border", borderWithoutMargin);
    table.put("ProgressBar.cellLength", new Integer(1));
    table.put("ProgressBar.cellSpacing", new Integer(1));
    table.put("ProgressBar.selectionForeground", table.getColor(SquarenessConstants.TEXT_TEXT_COLOR_KEY));
    table.put("ProgressBar.selectionBackground", table.getColor(SquarenessConstants.TEXT_TEXT_COLOR_KEY));
    table.put("ProgressBar.foreground", table.getColor(SquarenessConstants.SELECTED_CONTROL_COLOR_KEY));
    table.put("ProgressBar.background", table.getColor(SquarenessConstants.PROGRESS_BAR_BACKGROUND_COLOR_KEY));

    table.put("SplitPane.highlight", table.get(SquarenessConstants.CONTROL_BORDER_COLOR_KEY));
    table.put("SplitPane.shadow", table.get(SquarenessConstants.CONTROL_BORDER_COLOR_KEY));
    table.put("SplitPane.darkShadow", table.get(SquarenessConstants.CONTROL_BORDER_COLOR_KEY));

    table.put("TabbedPane.selected", table.get(SquarenessConstants.CONTROL_COLOR_KEY));
    table.put("TabbedPane.shadow", table.getColor(SquarenessConstants.CONTROL_BORDER_COLOR_KEY).brighter().brighter());
    table.put("TabbedPane.darkShadow", table.get(SquarenessConstants.CONTROL_BORDER_COLOR_KEY));
    table.put("TabbedPane.highlight", table.getColor(SquarenessConstants.CONTROL_COLOR_KEY).brighter().brighter());
    table.put("TabbedPane.background", table.get(SquarenessConstants.CONTROL_COLOR_KEY));
    table.put("TabbedPane.selected", null);
    table.put("Viewport.background", table.get(SquarenessConstants.CONTROL_COLOR_KEY));

    table.put("Table.scrollPaneBorder", borderWithoutMargin);
    table.put("TableHeader.cellBorder", tableHeaderCellBorder);

    table.put("Panel.background", table.get(SquarenessConstants.CONTROL_COLOR_KEY));
    table.put("Panel.foreground", table.get(SquarenessConstants.TEXT_TEXT_COLOR_KEY));

    table.put("Tree.collapsedIcon", LookAndFeel.makeIcon(getClass(), "icons/treecollapsed.gif"));
    table.put("Tree.expandedIcon", LookAndFeel.makeIcon(getClass(), "icons/treeexpanded.gif"));
    table.put("Tree.openIcon", LookAndFeel.makeIcon(getClass(), "icons/folderopened.gif"));
    table.put("Tree.closedIcon", LookAndFeel.makeIcon(getClass(), "icons/folderclosed.gif"));
    table.put("Tree.leafIcon", LookAndFeel.makeIcon(getClass(), "icons/document.gif"));

    table.put("FileView.directoryIcon", LookAndFeel.makeIcon(getClass(), "icons/folderclosed.gif"));
    table.put("FileView.fileIcon", LookAndFeel.makeIcon(getClass(), "icons/document.gif"));
    table.put("FileView.computerIcon", LookAndFeel.makeIcon(getClass(), "icons/computer.gif"));
    table.put("FileView.hardDriveIcon", LookAndFeel.makeIcon(getClass(), "icons/hd.gif"));
    table.put("FileView.floppyDriveIcon", LookAndFeel.makeIcon(getClass(), "icons/floppy.gif"));

    table.put("FileChooser.detailsViewIcon", LookAndFeel.makeIcon(getClass(), "icons/detail.gif"));
    table.put("FileChooser.homeFolderIcon", LookAndFeel.makeIcon(getClass(), "icons/home.gif"));
    table.put("FileChooser.listViewIcon", LookAndFeel.makeIcon(getClass(), "icons/list.gif"));
    table.put("FileChooser.newFolderIcon", LookAndFeel.makeIcon(getClass(), "icons/folderclosed.gif"));
    table.put("FileChooser.upFolderIcon", LookAndFeel.makeIcon(getClass(), "icons/folderup.gif"));

//    table.put("Spinner.background",table.get(SquarenessConstants.NORMAL_CONTROL_COLOR_KEY));
//    table.put("Spinner.foreground",table.get(SquarenessConstants.TEXT_TEXT_COLOR_KEY));
//    table.put("Spinner.border", borderWithoutMargin);
  }

  /**
   * Load the SystemColors into the defaults table.  The keys
   * for SystemColor defaults are the same as the names of
   * the public fields in SystemColor.  If the table is being
   * created on a native Windows platform we use the SystemColor
   * values, otherwise we create color objects whose values match
   * the defaults Windows95 colors.
   */
  protected void initSystemColorDefaults (UIDefaults table)
  {
    table.put(SquarenessConstants.DESKTOP_COLOR_KEY, new ColorUIResource(250, 251, 217));
    table.put(SquarenessConstants.ACTIVE_CAPTION_COLOR_KEY, new ColorUIResource(247, 242, 225));
    table.put(SquarenessConstants.ACTIVE_CAPTION_TEXT_COLOR_KEY, new ColorUIResource(0, 0, 0));
    table.put(SquarenessConstants.ACTIVE_CAPTION_BORDER_COLOR_KEY, new ColorUIResource(34, 57, 73));
    table.put(SquarenessConstants.INACTIVE_CAPTION_COLOR_KEY, new ColorUIResource(247, 242, 225));
    table.put(SquarenessConstants.INACTIVE_CAPTION_TEXT_COLOR_KEY, new ColorUIResource(134, 144, 150));
    table.put(SquarenessConstants.INACTIVE_CAPTION_BORDER_COLOR_KEY, new ColorUIResource(184, 175, 119));
    table.put(SquarenessConstants.WINDOW_COLOR_KEY, new ColorUIResource(255, 255, 255));
    table.put(SquarenessConstants.WINDOW_BORDER_COLOR_KEY, new ColorUIResource(34, 57, 73));
    table.put(SquarenessConstants.WINDOW_TEXT_COLOR_KEY, new ColorUIResource(0, 0, 0));
    table.put(SquarenessConstants.MENU_COLOR_KEY, new ColorUIResource(245, 246, 220));
    table.put(SquarenessConstants.MENU_TEXT_COLOR_KEY, new ColorUIResource(0, 0, 0));
    table.put(SquarenessConstants.TEXT_COLOR_KEY, new ColorUIResource(255, 255, 255));
    table.put(SquarenessConstants.TEXT_TEXT_COLOR_KEY, new ColorUIResource(0, 0, 0));
    table.put(SquarenessConstants.TEXT_HIGHLIGHT_COLOR_KEY, new ColorUIResource(211, 211, 42));
    table.put(SquarenessConstants.TEXT_HIGHLIGHT_TEXT_COLOR_KEY, new ColorUIResource(0, 0, 0));
    table.put(SquarenessConstants.TEXT_INACTIVE_TEXT_COLOR_KEY, new ColorUIResource(0, 0, 0));
    table.put(SquarenessConstants.CONTROL_COLOR_KEY, new ColorUIResource(247, 242, 225));
    table.put(SquarenessConstants.CONTROL_TEXT_COLOR_KEY, new ColorUIResource(0, 0, 0));
    table.put(SquarenessConstants.CONTROL_HIGHLIGHT_COLOR_KEY, new ColorUIResource(211, 211, 42));
    table.put(SquarenessConstants.CONTROL_LTHIGHLIGHT_COLOR_KEY, new ColorUIResource(211, 211, 42));
    table.put(SquarenessConstants.CONTROL_SHADOW_COLOR_KEY, new ColorUIResource(163 / 159 / 28));
    table.put(SquarenessConstants.CONTROL_DKSHADOW_COLOR_KEY, new ColorUIResource(163 / 159 / 28));
    table.put(SquarenessConstants.SCROLLBAR_COLOR_KEY, new ColorUIResource(245, 246, 220));
    table.put(SquarenessConstants.INFO_COLOR_KEY, new ColorUIResource(245, 246, 220));
    table.put(SquarenessConstants.INFO_TEXT_COLOR_KEY, new ColorUIResource(0, 0, 0));
  }


  //
  // private interface
  //

  private static final String DESCRIPTION = "Squareness Look And Feel";
  private static final String ID = "Squareness";
  private static final String NAME = "Squareness";
}

/*
  $Log: SquarenessLookAndFeel.java,v $
  Revision 1.11  2004/04/04 17:30:24  rbeeger
  Fixed border for popup menus..
  Changed version number fo 1.1.

  Revision 1.10  2004/04/02 15:33:50  rbeeger
  Added arrow icons for menu items.

  Revision 1.9  2004/03/10 08:48:36  rbeeger
  Added check icons for radio button menu items and check box menu items..

  Revision 1.8  2004/03/08 22:53:13  rbeeger
  Fixed placement of frame buttons and painting of frame borders.

  Revision 1.7  2004/03/08 17:21:05  rbeeger
  Added pressed scrollbar track effect.

  Revision 1.6  2004/02/14 19:12:35  rbeeger
  Updated copyright statement
  Added cvs log directive at the end of each file
  Optimized imports
  Reformated code

 */
