/*
* Copyright (c) 2003, the JUNG Project and the Regents of the University 
* of California
* All rights reserved.
*
* This software is open-source under the BSD license; see either
* "license.txt" or
* http://jung.sourceforge.net/license.txt for a description.
*/
package edu.uci.ics.jung.statistics;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import cern.colt.list.DoubleArrayList;
import edu.uci.ics.jung.algorithms.shortestpath.UnweightedShortestPath;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.UndirectedGraph;
import edu.uci.ics.jung.graph.Vertex;
/**
 * A set of statistical measures for structural properties of a graph
 * @author Scott White
 */
public class GraphStatistics {
	
	/**
	 * For each vertex, the net fraction of edges that actually exist in the neighborhood of distance 1 around
	 * each vertex vs all possible edges that could exist are computed
	 * The clustering coefficient measures the degree to which a node's neighbors are neighbors with each other
	 * Note: You can use cern.jet.stat.Descriptive to compute various statistics from the DoubleArrayList
	 * @param graph the graph for which the clustering coefficients are to be computed
	 * @return the set of clustering coefficients for each vertex
	 */
	public static DoubleArrayList clusteringCoefficients(UndirectedGraph graph) {
		DoubleArrayList clusteringValues = new DoubleArrayList();
		for (Iterator vIt = graph.getVertices().iterator(); vIt.hasNext();) {
			Vertex v = (Vertex) vIt.next();
			ArrayList neighbors = new ArrayList(v.getNeighbors());
			int numNeighbors = neighbors.size();
			if (numNeighbors == 1) {
				clusteringValues.add(1.0);
				continue;
			}
			double numNeighborNeighborEdges = 0;
			for (int v1Idx = 0; v1Idx < numNeighbors - 1; v1Idx++) {
				Vertex v1 = (Vertex) neighbors.get(v1Idx);
				for (int v2Idx = v1Idx + 1; v2Idx < numNeighbors; v2Idx++) {
					Vertex v2 = (Vertex) neighbors.get(v2Idx);
					if (v2.isNeighborOf(v1)) {
						numNeighborNeighborEdges += 1.0;
					}
				}
			}
			double numPossibleEdges =
				neighbors.size() * (neighbors.size() - 1) / 2.0;
			double clusteringCoefficient =
				numNeighborNeighborEdges / numPossibleEdges;
			clusteringValues.add(clusteringCoefficient);
		}
		return clusteringValues;
	}
	
	/**
	 * The set of average shortest path distances for each vertex.  
	 * For each vertex, the shortest path distance
	 * to every other vertex is measured and the average is computed.
	 * Note: You can use cern.jet.stat.Descriptive to compute various statistics from the DoubleArrayList
	 * @param graph the graph whose average distances are to be computed
	 * @return the set of average shortest path distances for each vertex (to every other vertex); However, if the
	 * graph is not strongly connected null will be returned since the graph diameter is infinite
	 */
	public static DoubleArrayList averageDistances(Graph graph) {
		DoubleArrayList distances = new DoubleArrayList();
		UnweightedShortestPath shortestPath = new UnweightedShortestPath(graph);
		for (Iterator vIt = graph.getVertices().iterator(); vIt.hasNext();) {
			Vertex v = (Vertex) vIt.next();
			double averageShortestPath = 0;
//			int ctr = 0;
			for (Iterator nIt = graph.getVertices().iterator();
				nIt.hasNext();
				) {
				Vertex neighbor = (Vertex) nIt.next();
				if (neighbor == v) {
					continue;
				}
                Number n = shortestPath.getDistance(v, neighbor);
                if (n == null)
                    return null;
				averageShortestPath += n.doubleValue();
			}
			averageShortestPath /= (double) (graph.getVertices().size() - 1.0);
			distances.add(averageShortestPath);
		}
		return distances;
	}
	
	/**
	 * Computes the diameter (maximum shortest path length between any vertex pair)
     * of the graph, ignoring edge weights.
	 * @param g the graph
	 * @return the diameter
	 */
	public static int diameter(Graph g) {
		UnweightedShortestPath usp = new UnweightedShortestPath(g);
		//		This is practically fast, but it would be the best if we have an
		// implementation of All Pairs Shortest Paths(APSP) algorithm.
		int diameter = 0;
		List vertices = new ArrayList(g.getVertices());
		int numVertices = g.numVertices();
		for (int i = 0; i < numVertices - 1; i++) {
			for (int j = i + 1; j < numVertices; j++) {
                Number n = usp.getDistance((Vertex) vertices.get(i), 
                        (Vertex) vertices.get(j));
                if (n != null && n.intValue() > diameter)
					diameter = n.intValue();
			}
		}
		return diameter;
	}
	
	/**
	 * Creates a histogram from a sequence of doubles
	 * @param values the sequence of doubles
	 * @param min the minimum value to bin off of
	 * @param numBins  the number of bins
	 * @param binWidth the width of the bin
	 * @return a histogram
	 */
	public static Histogram createHistogram(
		DoubleArrayList values,
		double min,
		int numBins,
		double binWidth) {
		Histogram histogram = new Histogram(numBins, min, binWidth);
		for (int idx = 0; idx < values.size(); idx++) {
			histogram.fill(values.get(idx));
		}
		return histogram;
	}
}
