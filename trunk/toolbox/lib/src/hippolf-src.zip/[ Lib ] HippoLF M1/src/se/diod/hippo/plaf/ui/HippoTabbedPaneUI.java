/*
 * 
 * Created on 2004-jul-25
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.ui;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Rectangle;

import javax.swing.JComponent;
import javax.swing.JTabbedPane;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.metal.MetalTabbedPaneUI;

import se.diod.hippo.plaf.renderer.AbstractRenderer;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-25
 *
 */
public class HippoTabbedPaneUI extends MetalTabbedPaneUI {
	private AbstractRenderer renderer;						// Holds the renderer that is used to render the tabs.




	/**
	 * 
	 * 
	 */
	public static ComponentUI createUI(JComponent tabPane) {
		return new HippoTabbedPaneUI();
	}




	/**
	 * 
	 * Installs the UI.
	 * 
	 * @see javax.swing.plaf.ComponentUI#installUI(JComponent)
	 * 
	 */
	public void installUI( JComponent c ) {
		super.installUI( c );
		renderer = createRenderer( tabPane );
		tabPane.setTabLayoutPolicy( JTabbedPane.SCROLL_TAB_LAYOUT );
	}




	/**
	 * 
	 * Uninstalls the UI.
	 * 
	 * @see javax.swing.plaf.ComponentUI#uninstallUI(JComponent)
	 * 
	 */
	public void uninstallUI( JComponent c ) {
		renderer = null;
		super.uninstallUI( c );
	}




	/**
	 * 
	 * Creates the renderer used to layout and paint the tabs.
	 * 
	 * @param tabPane               the UIs component
	 * @return AbstractRenderer     the renderer that will be used to paint
	 * 
	 */
	private AbstractRenderer createRenderer( JTabbedPane tabbedPane ) {
		return AbstractRenderer.createRenderer( tabPane );
	}




	/** 
	 * Returns the insets (i.e. the width) of the content Border
	 */
	protected Insets getContentBorderInsets(int tabPlacement) {
		return renderer.getContentBorderInsets( super.getContentBorderInsets( tabPlacement ) );
	}
	
	
	
	/////////////////////////////////////////////////
	//               Painting                      //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	protected void paintContentBorderBottomEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h) {
		Graphics g2 = g.create();

		g2.setColor( Color.GRAY );
		g2.drawLine( x, h-y-1, w, h-y-1 );

		g2.dispose();
	}




	/**
	 * 
	 * 
	 */
	protected void paintContentBorderTopEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h ) {
		Graphics g2 = g.create();

		//g.setColor( Color.WHITE );
		//g.drawLine( x, y+1, w, y+1 );
		g2.setColor( Color.GRAY );
		g2.drawLine( x, y, w, y );

		/*
		boolean leftToRight = true; //MetalUtils.isLeftToRight(tabPane);
		int right = x + w - 1;
		Rectangle selRect = selectedIndex < 0? null : getTabBounds(selectedIndex, calcRect);
		//g.setColor( selectHighlight );
		//g.setColor( new Color( 198, 209, 223 ) );

		// Clear background..
		g.setColor( javax.swing.UIManager.getColor("TabbedPane.background") );
		g.fillRect( 0, 0, w, h );

		// Draw unbroken line if tabs are not on TOP, OR
		// selected tab is not in run adjacent to content, OR
		// selected tab is not visible (SCROLL_TAB_LAYOUT)
		//
		g.setColor( new Color( 70, 70, 70 ) );
		if( tabPlacement != TOP || selectedIndex < 0 || ( selRect.y + selRect.height + 1 < y) || ( selRect.x < x || selRect.x > x + w)) {
			g.setColor( new Color( 70, 70, 70 ) );
			g.drawLine(x, y, x+w-2, y);
		} else {
			// Break line to show visual connection to selected tab
			boolean lastInRun = isLastInRun( selectedIndex );
			g.setColor( Color.black );

			if ( leftToRight || lastInRun ) {
				g.drawLine(x, y, selRect.x + 1, y);
			} else {
				g.drawLine(x, y, selRect.x, y);
			}

			if (selRect.x + selRect.width < right - 1) {
				if ( leftToRight && !lastInRun ) {
					g.drawLine(selRect.x + selRect.width, y, right - 1, y);
				} else {
					g.drawLine(selRect.x + selRect.width - 1, y, right - 1, y);
				}
			} else {
				//g.setColor( shadow ); 
				//g.drawLine(x+w-2, y, x+w-2, y);
			}
		}
		*/

		g2.dispose();
	}




	/**
	 * 
	 * 
	 */
	protected void paintContentBorderRightEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h) {
		Graphics g2 = g.create();

		//g.setColor( Color.WHITE );
		//g.drawLine( w-2, y, w-2, h );
		g2.setColor( Color.GRAY );
		g2.drawLine( w-1, y, w-1, h );

		g2.dispose();
	}




	/**
	 * 
	 * 
	 */
	protected void paintContentBorderLeftEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h) {
		Graphics g2 = g.create();

		//g.setColor( Color.WHITE );
		//g.drawLine( x+1, y, x+1, h );
		g2.setColor( Color.GRAY );
		g2.drawLine( x, y, x, h );

		g2.dispose();
	}




	/**
	 * 
	 * 
	 */
	public void paint( Graphics g, JComponent c ) {
		super.paint( g, c );
	}




	/**
	 * 
	 * Fills the background of the given tab to make sure overlap of 
	 * tabs is handled correctly.
	 * Note: that tab backgrounds seem to be painted somewhere else, too.
	 * 
	 */
	public void paintTabBackground( Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected ) {
		renderer.paintTabBackground( g, tabIndex, x, y, w, h, isSelected );
	}




	/**
	 * Paints the border for one tab. Gets the bounds of the tab as parameters.
	 * Note that the result is not clipped so you can paint outside that
	 * rectangle. Tabs painted later on have a chance to overwrite though.
	 */
	protected void paintTabBorder( Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected ) {
		renderer.paintTabBorder( g, tabIndex, x, y, w, h, isSelected );
	}




	/**
	 *
	 * Draws the rectancle around the Tab label which indicates keyboard focus
	 * 
	 */
	 protected void paintFocusIndicator( Graphics g, int tabPlacement, Rectangle[] rectangles, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected ) {
		 renderer.paintFocusIndicator( g, rectangles, tabIndex, iconRect, textRect, isSelected );
	 }




	/**
	 * 
	 * 
	 */
	protected void paintContentBorder( Graphics g, int tabPlacement, int selectedIndex ) {
		Insets ins				= tabPane.getInsets();
		java.awt.Dimension dim	= tabPane.getSize();
    
		int x = ins.left,
			y = ins.top,
			tah = calculateTabAreaHeight(tabPlacement, runCount, maxTabHeight),
			taw = calculateTabAreaWidth(tabPlacement, runCount, maxTabWidth),
			width = dim.width -x -ins.right,
			height = dim.height -y -ins.bottom;

		switch( tabPlacement ) {
			case LEFT: x += taw; width -= (x - ins.left); break;
			case RIGHT: width -= taw; break;
			case BOTTOM: height -= tah; break;
			case TOP: y += tah; height -= (y - ins.top); break;
		}

		switch( tabPlacement ) {
			case LEFT:		paintContentBorderLeftEdge( g, tabPlacement, selectedIndex, x, y, width, height );		break;
			case RIGHT:		paintContentBorderRightEdge( g, tabPlacement, selectedIndex, x, y, width, height );		break;
			case BOTTOM:	paintContentBorderBottomEdge( g, tabPlacement, selectedIndex, x, y, width, height );	break;
			case TOP:		paintContentBorderTopEdge( g, tabPlacement, selectedIndex, x, y, width, height );		break;
		}
	}




	/**
	 * 
	 * 
	 */
	private boolean isLastInRun( int tabIndex ) {
		int run = getRunForTab( tabPane.getTabCount(), tabIndex );
		int lastIndex = lastTabInRun( tabPane.getTabCount(), run );
		return tabIndex == lastIndex;
	}
}
