/*
 * Hamsam - Instant Messaging API
 * Copyright (C) 2003 Raghu K
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package hamsam.protocol.yahoo;

/**
 * Looks up each byte of the seed in a table.
 *
 * @author Raghu K
 */
class LookupTransformation extends YahooTransformation {

	private char[] table;

	public LookupTransformation(char[] table) {
		this.table = table;
	}

	protected int transform(int seed) {
		char[] bytes = getBytes(seed);
		return table[bytes[0]] |
				table[bytes[1]] << 8 |
				table[bytes[2]] << 16 |
				table[bytes[3]] << 24;
	}
}
