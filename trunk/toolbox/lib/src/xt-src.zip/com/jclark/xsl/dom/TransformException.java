// $Id: TransformException.java,v 1.1 2002/04/25 18:04:15 bill Exp $

package com.jclark.xsl.dom;

import org.w3c.dom.Node;

public class TransformException extends Exception
{
    private final Node node;

    public TransformException(String detail, Node node) {
        super(detail);
        this.node = node;
    }
  
    public Node getNode()
    {
        return node;
    }
}
