package multivalent.gui;

import java.awt.*;
import java.util.Map;

import multivalent.*;



/**
	Checkbox widget: toggle ON and OFF.
	Usable as button and menu item.

	@version $Revision: 1.5 $ $Date: 2002/01/27 02:00:01 $
*/
public class VCheckbox extends VButton {
  /** Length of side of checkbox square. */
  static final int LENGTH=6;
  static final int GAP = LENGTH+6;
  static final Insets ZEROGAP = new Insets(0,GAP,0,0);	// top,left,bottom,right

  static Insets lastold_=INSETS_ZERO, lastnew_=ZEROGAP;

  boolean state_=false;


  public VCheckbox(String name,Map<String,Object> attr, INode parent) { super(name,attr, parent); }

  public boolean getState() { return state_; }

  public void setState(boolean b) { if (state_!=b) { state_=b; repaint(); } }


  /** Ensure that padding on left is large enough for checkbox. */
  public boolean formatNode(int width,int height, Context cx) {
	int lp=padding.left, dp=0;
	if (lp<GAP) {
		if (padding==INSETS_ZERO) padding=ZEROGAP;
		else if (padding==lastold_) padding=lastnew_;   // recycling probably not very effective
		else {
			lastold_ = padding;
			padding = lastnew_ = new Insets(padding.top,GAP,padding.bottom,padding.right);
//System.out.println("new check padding = "+padding);
		}
		dp = lp-GAP;    // subtracted off padding before entry, so add back, but take away new
	}
	super.formatNode(width+dp, height, cx);

	//if (!cx.elide && bbox.height<LENGTH) { baseline += LENGTH - bbox.height; bbox.height = LENGTH; }
	if (!cx.elide && bbox.height<LENGTH) bbox.height = baseline = LENGTH;

	return false;
  }

  /** Draw checkbox too. */
  public void paintNode(Rectangle docclip, Context cx) {
	super.paintNode(docclip,cx);

	//int x=LENGTH/2+(inside_?1:0), y=bbox.height/2-LENGTH/2+(inside_?1:0);
	int x=(GAP-LENGTH)/2-GAP, y=(bbox.height-padding.top-padding.bottom-border.top-border.bottom - LENGTH)/2;   // not: baseline - LENGTH -2
	//x = -11;
	//x = bbox.width-(LENGTH/2+LENGTH/*+2*/);	// checkbox on right
	Graphics2D g = cx.g;
	g.setColor(cx.foreground);
	if (getState()) g.fillRect(x,y, LENGTH,LENGTH); else g.drawRect(x,y, LENGTH,LENGTH);
  }


  /** Change state, then call associated VScript, if any. */
  public void invoke() {
	setState(!getState());
	super.invoke(); 	// any script gets updated value (need before and after?)
  }
}
