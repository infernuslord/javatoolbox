/*
  Copyright (C) 2003-2004 Robert F. Beeger (robert at beeger dot net)
  Licensed under the Academic Free License version 2.1
  OSI Certified Open Source Software

  Visit http://squareness.sourceforge.net/ for new releases of Squareness Look And Feel and other
  skins from the Squareness series.
*/
package net.beeger.squareness.util;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.UIManager;

import net.beeger.squareness.SquarenessLookAndFeel;

/**
 * <p>Common super class for title panes.</p>
 * <p>This class is currently subclassed in inner classes in SquarenessInternalFrameUI and SquarenessRootPaneUI.
 * Those inner classes add the specific details of handling an internal frame viz. a frame.</p>
 */
public abstract class SquarenessTitlePane extends JComponent
{
  /**
   * Create the title pane and equip it with the frame buttons.
   */
  public SquarenessTitlePane ()
  {
    _firstUpdate = true;
    _maximizeIcon = UIManager.getIcon("InternalFrame.maximizeIcon");
    _minimizeIcon = UIManager.getIcon("InternalFrame.minimizeIcon");

    _closeButton = new FrameButton();
    _closeButton.setIcon(UIManager.getIcon("InternalFrame.closeIcon"));
    _closeButton.addActionListener(new ActionListener()
    {
      public void actionPerformed (ActionEvent e)
      {
        close();
      }
    });
    _maxButton = new FrameButton();
    _maxButton.setIcon(_maximizeIcon);
    _maxButton.addActionListener(new ActionListener()
    {
      public void actionPerformed (ActionEvent e)
      {
        if(isMaximized())
        {
          restore();
        }
        else
        {
          maximize();
        }
      }
    });
    _iconifyButton = new FrameButton();
    _iconifyButton.setIcon(UIManager.getIcon("InternalFrame.iconifyIcon"));
    _iconifyButton.addActionListener(new ActionListener()
    {
      public void actionPerformed (ActionEvent e)
      {
        iconify();
      }
    });

    add(_iconifyButton);
    add(_maxButton);
    add(_closeButton);

    _titleLabel = new JLabel();
    _titleLabel.setFont(UIManager.getFont("InternalFrame.titleFont", getLocale()));
    _titleLabel.setForeground(SquarenessLookAndFeel.getCurrentSquarenessTheme().getTextColor());
    add(_titleLabel);

    setLayout(new SquarenessTitlePaneLayout());
    setBackground(SquarenessLookAndFeel.getCurrentSquarenessTheme().getWindowBackgroundColor());
  }

  /**
   * <p>Update the title pane</p>
   * <p>This updates the title, the enabled state of the buttons and the icon on the maximize/restore button.</p>
   */
  protected void update()
  {
    boolean closeable = isClosable();
    boolean iconifiable = isIconifiable();
    boolean maximized = isMaximized();
    boolean maximizable = isMaximizable();
    Font font = UIManager.getFont("InternalFrame.titleFont", getLocale());
    String title = getTitle();

    if (_firstUpdate || _lastCloseable != closeable)
    {
      _closeButton.setEnabled(closeable);
    }
    if (_firstUpdate || _lastIconifiable != iconifiable)
    {
      _iconifyButton.setEnabled(iconifiable);
    }

    if (_firstUpdate || _lastMaximized != maximized)
    {
      _maxButton.setIcon(maximized ? _minimizeIcon : _maximizeIcon);
    }
    if (_firstUpdate || _lastMaximizable != maximizable)
    {
      _maxButton.setEnabled(maximizable);
    }

    if (_firstUpdate || !font.equals(_lastFont))
    {
      _titleLabel.setFont(font);
    }
    if (_firstUpdate || (title == null && _lastTitle != null) || (title != null && !title.equals(_lastTitle)))
    {
      _titleLabel.setText(title);
    }

    _lastCloseable = closeable;
    _lastIconifiable = iconifiable;
    _lastMaximized = maximized;
    _lastMaximizable = maximizable;
    _lastFont = font;
    _lastTitle = title;

    _firstUpdate = false;
  }

  /**
   * Do we have a left to right orientation?
   *
   * @return True if we are in left to right orientation, false otherwise.
   */
  public abstract boolean isLeftToRight();

  protected abstract boolean isIconifiable ();
  protected abstract boolean isMaximizable ();
  protected abstract boolean isClosable ();

  /**
   * Close the (internal) frame.
   */
  protected abstract void close();

  /**
   * Iconify the (internal) frame.
   */
  protected abstract void iconify();

  /**
   * Maximize the (internal) frame.
   */
  protected abstract void maximize();

  /**
   * Restore the (internal) frame.
   */
  protected abstract void restore();

  /**
   * Can the (internal) frame this title pane belongs to be maximized?
   * @return true if the (internal) frame can be maximized.
   */
  protected abstract boolean isMaximized();

  /**
   * Can the (internal) frame this title pane belongs to be iconified?
   * @return true if the (internal) frame can be iconified.
   */
  protected abstract boolean isIconified();

  /**
   * Return the title of the (internal) frame.
   * @return The title of the (internal) frame.
   */
  protected abstract String getTitle();

  private Icon _maximizeIcon;
  private Icon _minimizeIcon;
  private JButton _closeButton;
  private JButton _maxButton;
  private JButton _iconifyButton;
  private JLabel _titleLabel;

  /**
   * The layout manager of the Squareness title pane. It puts the buttons and the title on their right places.
   */
  protected class SquarenessTitlePaneLayout implements LayoutManager
  {
    /**
     * Removes the specified component from the layout.
     *
     * @param comp the component to be removed
     */
    public void removeLayoutComponent (Component comp)
    {

    }

    /**
     * If the layout manager uses a per-component string,
     * adds the component <code>comp</code> to the layout,
     * associating it
     * with the string specified by <code>name</code>.
     *
     * @param name the string to be associated with the component
     * @param comp the component to be added
     */
    public void addLayoutComponent (String name, Component comp)
    {

    }

    /**
     * Calculates the minimum size dimensions for the specified
     * container, given the components it contains.
     *
     * @param parent the component to be laid out
     * @see #preferredLayoutSize
     */
    public Dimension minimumLayoutSize (Container parent)
    {
      return new Dimension(_closeButton.getIcon().getIconWidth() + 60, _closeButton.getIcon().getIconHeight() + 2);
    }

    /**
     * Calculates the preferred size dimensions for the specified
     * container, given the components it contains.
     *
     * @param parent the container to be laid out
     * @see #minimumLayoutSize
     */
    public Dimension preferredLayoutSize (Container parent)
    {
      return minimumLayoutSize(parent);
    }

    public void layoutContainer (Container container)
    {
      boolean leftToRight = isLeftToRight();

      int width = getWidth();
      int height = getHeight();
      int x;

      int buttonHeight = _closeButton.getIcon().getIconHeight();
      int buttonWidth = _closeButton.getIcon().getIconWidth();
      int y = (height - buttonHeight) >> 1;

      x = (leftToRight) ? width - buttonWidth - 2 : 2;

      _closeButton.setBounds(x, y, buttonWidth, buttonHeight);
      x += (leftToRight) ? -(buttonWidth + 2) : buttonWidth + 2;
      _maxButton.setBounds(x, y, buttonWidth, buttonHeight);
      x += (leftToRight) ? -(buttonWidth + 2) : buttonWidth + 2;
      _iconifyButton.setBounds(x, y, buttonWidth, buttonHeight);

      int maxX = leftToRight ? x - 2 : width - 2;
      x = leftToRight ? 2 : x + 2;
      _titleLabel.setBounds(x, y, maxX - x, buttonHeight);
    }
  }

  /**
   * A convenience class used for the frame buttons.
   * Instances of this class have no borders, no margins and are not focusable.
   */
  protected static class FrameButton extends JButton
  {
    /**
     * Creates a button with no set text or icon.
     */
    public FrameButton ()
    {
      setMargin(new Insets(0,0,0,0));
      setBorder(BorderFactory.createEmptyBorder(0,0,0,0));
      setOpaque(true);
      setFocusPainted(false);
    }

    /**
     * Returns whether this Component can be focused.
     *
     * @return <code>true</code> if this Component is focusable;
     *         <code>false</code> otherwise.
     * @see #setFocusable
     * @since 1.4
     */
    public boolean isFocusable ()
    {
      return false;
    }
  }

  private boolean _lastCloseable;
  private boolean _lastIconifiable;
  private boolean _lastMaximized;
  private boolean _lastMaximizable;
  private Font _lastFont;
  private String _lastTitle;
  private boolean _firstUpdate;
}
/*
  $Log: SquarenessTitlePane.java,v $
  Revision 1.4  2004/12/28 23:41:36  rbeeger
  * Fixed bug [ 1092257 ] JDialog does not work

  Revision 1.3  2004/09/18 17:30:48  rbeeger
  * Updated copyright block and license file. Squareness Look And Feel is now licensed under Academic Free License 2.1
  * Added themepack.

  Revision 1.2  2004/09/10 17:29:32  rbeeger
  * title pane now works for internal frame ui and root pane ui
  * SquarenessRootPaneUI is mostly a copy of MetalRootPaneUI. The only difference: the title pane.
  * Fixed bug [ 1017901 ] An undecorated frame doesn't update properly with 1.1.1: An empty border in the frame border that worked ok in internal frames, didn't work on JFrames at all.
  * Added documentation in some places.

 */
