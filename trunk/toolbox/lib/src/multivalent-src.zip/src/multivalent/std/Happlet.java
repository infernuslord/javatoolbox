package multivalent.std;

import java.io.*;
import java.awt.AWTEvent;
import java.awt.Point;
import java.util.*;
import java.net.URL;
import java.applet.*;

import multivalent.*;



/*
getAppletContext()
	Gets a handle to the applet context.
getAudioClip(URL)
	Gets an audio clip.
getAudioClip(URL, String)
	Gets an audio clip.
getCodeBase()
	Gets the base URL.
getDocumentBase()
	Gets the document URL.
getImage(URL)
	Gets an image given a URL.
getImage(URL, String)
	Gets an image relative to a URL.
getParameter(String)
	Gets a parameter of the applet.
play(URL)
	Plays an audio clip.
play(URL, String)
	Plays an audio clip.
resize(int, int)
	Requests that the applet be resized.
resize(Dimension)
	Requests that the applet be resized.
showStatus(String)
	Shows a status message in the applet's context.
*/

/**
	<i>Doesn't work</i>
	Happlet - "hapless applets" - Multivalent wrapper for applets,
	which are less powerful than Multivalent behaviors, but it's a legacy data type.

	(Not specific to HTML adaptor:  all media types can show applets.)

	@version $Revision$ $Date$
*/
public class Happlet extends Behavior implements AppletStub {
  static final boolean DEBUG = true;

  URL codebase;
  AppletContext ac;
  Leaf appletNode;
  int x, y, width, height;
  Applet applet;

//	uiinfo = new UIInfo("Applet", this, null);

  /* *************************
   * APPLETSTUB PROTOCOLS
   **************************/

  public boolean isActive() { return true;/*fix*/ } /* Applet method */

  public void appletResize(int width, int height) {
	Browser br = getBrowser();
	appletNode.bbox.setSize(width, height);
	this.width = width; this.height = height;
	// re-layout
	br.repaint();
  }
  public AppletContext getAppletContext() {
	return ac;
  }
  public URL getCodeBase() {
	return codebase;
  }
  public URL getDocumentBase() {
//	return getControl().getDocumentBase();
	return null;
  }

  public String getParameter(String name) {
	// serve up from private stash
	return getAttr(name);
  }



  public void restore(ESISNode n, Map<String,Object> attr, Layer layer) {
	super.restore(n,attr,layer);
	// check dependencies on other behaviors by examining bv for instance of <required service>
	// passed vector of behaviors read so far so can verify dependencies
	// read into local cache -- don't build tree or anything yet: be independent of other restores just now

	// read <PARAM...> entries adding to attr hash, ignore text, until </applet>
	//assert attr_!=null: "need attributes for Applet: HEIGHT, WIDTH, X, Y, CODE";
	for (int i=0,imax=n.size(); i<imax; i++) {
		if (!(n.childAt(i) instanceof ESISNode)) continue;
		ESISNode c = (ESISNode)n.childAt(i);
		if (c.getGI().equals("param")) {
			String name = ((String)c.getAttr("name")).toLowerCase();
			//validate(name!=null, "PARAM for "+n.getGI()+" must have a name field");
			String val = (String)c.getAttr("value");		// value can be null? hmm...
			System.out.println("adding PARAM "+name+" == "+val);
			putAttr(name, val);
		}
	}

	String bclass = getAttr("code");
	//validate(bclass!=null, "must have CODE attribute");
	//validate(bclass.endsWith(".class"), bclass+" must be a class (end in .class)");
	String bname = bclass.substring(0, bclass.length()-6);

	Browser br = getBrowser();
	try {
//	  codebase = new URL(getControl().getDocumentBase(), bname);
System.out.println("trying to load "+codebase);
	  Object bc = Class.forName(bname).newInstance();	// system caches byte code?
	  if (bc instanceof Applet) {
		applet = (Applet)bc;
		// instantiate applet, setStub
		// resize according to width and height
		// init(), start()
//		ac = getControl().getAppletContext();
		applet.setStub(this);
/* NOT TRUE */		//validate(getAttr("width")!=null && getAttr("height")!=null, "must set WIDTH and HEIGHT attributes for Applet");
		int width = Integer.parseInt(getAttr("width"));
		int height = Integer.parseInt(getAttr("height"));
		//validate(getAttr("x")!=null && getAttr("y")!=null, "must set X and Y attributes for Applet");
		x = Integer.parseInt(getAttr("x"));
		y = Integer.parseInt(getAttr("y"));
		applet.setBounds(x,y, width, height);


//		appletNode = new Leaf("Applet "+bname, null/*attr?*/, this);


	  } else {
		//error("class "+bname+" is not an applet (does not subclass from Applet)");
	  }

/*
	} catch (MalformedURLException e) {
	  error("malformed URL "+e);
*/
	} catch (ClassNotFoundException e) {
	  //error("couldn't find applet "+bname);
	} catch (InstantiationException e) {
	  //error("couldn't instantiate "+bname+" -- is it abstract?");
	} catch (Exception e) {
	  //error("unanticipated error: "+e.toString());
	}
  }


  /*
   * BUILD - hack the doc tree.  return possibly new root
   */
  public void buildBefore(Document doc) {
	//super.buildBefore(doc);
	doc.appendChild(appletNode);
  }
  public void buildAfter(Document doc) {
	// usually do everything here (low->high pass), as no doc tree exists on high->low
	// but may want to prevent further work when it would be useless
  }


  /*
   * FORMAT - geometrically place doc tree element.
   * return true to shortcircuit out lower priority behaviors
   */
  public boolean formatBefore(Node node) {
	// operate by side effects on doc tree
	// on leaves set width and height
	return false;
  }
  public boolean formatAfter(Node node) {
	// position elements at right (x,y)
	// set bbox for internal nodes: bbox = bbox over children
	// if return true, shortcircuit out behaviors of higher priority.
	// probably shouldn't be allowed to do this
	return false;
  }


  /*
   * PAINT
   * maybe pass Current Transformation Matrix too
   */
  public boolean paintBefore(Context cx, Node node) {
	// draw backgrounds
	// selected regions often painted as yellow backgrounds
	// set clipping region and call Applet's repaint
	return false;
  }
  public boolean paintAfter(Context cx, Node node) {
	// propagate paints down to applet
	// draw screen representation
		// later start new thread group here
	applet.setVisible(true);
	applet.init();
	applet.start();

	return false;
  }


  //public boolean clipboardBefore(StringBuffer txt)
  //public boolean clipboardAfter(StringBuffer txt)
  public boolean eventBefore(AWTEvent e, Point rel, Node obsn) {
	// if event is in applet's region, it gets it & return true
	//if ();

	return false;
  }
}
