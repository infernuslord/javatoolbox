/*
 * 
 * Created on 2004-jul-22
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.ui;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.ButtonModel;
import javax.swing.JComponent;
import javax.swing.JMenuItem;
import javax.swing.UIManager;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicCheckBoxMenuItemUI;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-22
 *
 */
public class HippoCheckBoxMenuItemUI extends BasicCheckBoxMenuItemUI {
	protected String getPropertyPrefix() { return "CheckBoxMenuItem"; }




	/////////////////////////////////////////////////
	//                   Create                    //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	public static ComponentUI createUI( JComponent b ) {
		return new HippoCheckBoxMenuItemUI();
	}




	/////////////////////////////////////////////////
	//                  Install                    //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	protected void installDefaults() {
		super.installDefaults();
	}



	/////////////////////////////////////////////////
	//                 Uninstall                   //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	protected void uninstallDefaults() {
		super.uninstallDefaults();
	}




	/////////////////////////////////////////////////
	//                 Painting                    //
	/////////////////////////////////////////////////
	/**
	 * 
	 * 
	 */
	protected void paintBackground(Graphics g, JMenuItem menuItem, Color bgColor) {
		super.paintBackground( g, menuItem, bgColor );
		Graphics g2 = g.create();

		ButtonModel model = menuItem.getModel();

		int menuHeight = menuItem.getHeight();
		int menuWidth = menuItem.getWidth();

		// Clear background
		g2.setColor( UIManager.getColor( "CheckBoxMenuItem.background" ) );
		g2.fillRect( 0, 0, menuWidth, menuHeight );

		// Draw left gray border
		g2.setColor( javax.swing.UIManager.getColor( "MenuItem.iconBackground" ) );
		g2.fillRect(0, 0, 17, menuHeight);

		// If item is armed( selected ) create thin border around selection!
		if( model.isArmed() ) {
			g2.setColor( bgColor );
			g2.fillRect( 1, 1, menuWidth-3, menuHeight-2 );

			g2.setColor( UIManager.getColor( "CheckBoxMenuItem.borderColor" ) );
			g2.drawRect( 1, 1, menuWidth-3, menuHeight-2 );
		}

		g2.dispose();
	}
}
