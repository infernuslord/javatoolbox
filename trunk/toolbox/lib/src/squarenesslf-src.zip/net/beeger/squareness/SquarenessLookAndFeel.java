/*
  Copyright (C) 2003-2004 Robert F. Beeger (robert at beeger dot net)
  Licensed under the Academic Free License version 2.1
  OSI Certified Open Source Software

  Visit http://squareness.sourceforge.net/ for new releases of Squareness Look And Feel and other
  skins from the Squareness series.
*/
package net.beeger.squareness;

import java.util.Properties;
import java.io.InputStream;
import java.io.IOException;
import javax.swing.LookAndFeel;
import javax.swing.UIDefaults;
import javax.swing.plaf.BorderUIResource;
import javax.swing.plaf.metal.MetalLookAndFeel;

import net.beeger.squareness.theme.DefaultSquarenessTheme;
import net.beeger.squareness.theme.SquarenessTheme;
import net.beeger.squareness.theme.PropertiesSquarenessTheme;
import net.beeger.squareness.util.SquarenessBorderFactory;
import net.beeger.squareness.util.SquarenessIconFactory;

/**
 * <p>This is the core class of the Squareness Look And Feel.</p>
 * <p>It sets up the colors, fonts, ui delegates as well as other resources and defaults
 * used by this look and feel.</p>
 */
public class SquarenessLookAndFeel extends MetalLookAndFeel
{

  public static void setCurrentSquarenessTheme(SquarenessTheme theme)
  {
    _currentSquarenessTheme = theme;
    MetalLookAndFeel.setCurrentTheme(theme);
  }

  public static SquarenessTheme getCurrentSquarenessTheme()
  {
    if (_currentSquarenessTheme == null)
    {
      loadThemePackageTheme();
    }
    if (_currentSquarenessTheme == null)
    {
      setCurrentSquarenessTheme(new DefaultSquarenessTheme());
    }
    return _currentSquarenessTheme;
  }

  public static void loadThemePackageTheme ()
  {
    final InputStream themeSelectorStream = SquarenessLookAndFeel.class.getResourceAsStream("/themeselector.slfts");
    if (themeSelectorStream != null)
    {
      Properties themeSelector = new Properties();
      try
      {
        themeSelector.load(themeSelectorStream);
        String themeFileName = themeSelector.getProperty("currentTheme");
        if (themeFileName != null && themeFileName.trim().length() > 0)
        {
          Properties theme = new Properties();
          theme.load(SquarenessLookAndFeel.class.getResourceAsStream("/" + themeFileName));
          _currentSquarenessTheme = new PropertiesSquarenessTheme(theme);
        }
      }
      catch (IOException e)
      {
        e.printStackTrace();
      }
      catch (PropertiesSquarenessTheme.LoadException e)
      {
        e.printStackTrace();
      }
    }
  }

  public SquarenessLookAndFeel ()
  {
  }

  /**
   * Is the look and feel a native look and feel?
   * 
   * @return true if the look and feel is a native look and feel, false otherwise
   */
  public boolean isNativeLookAndFeel ()
  {
    return false;
  }

  /**
   * <p>Is this look and feel supported on the underlying plattform?</p>
   * <p><b>Note:</b> The Squareness look and feel is supported on any available plattform. So this method always
   * returns true.</p>
   * 
   * @return true if the look and feel is supported on the underlying plattform, false otherwise.
   */
  public boolean isSupportedLookAndFeel ()
  {
    return true;
  }

  /**
   * Return the description of the look and feel.
   * 
   * @return The description of the look and feel.
   */
  public String getDescription ()
  {
    return DESCRIPTION;
  }

  /**
   * Return the id of the look and feel.
   * 
   * @return The id of the look and feel
   */
  public String getID ()
  {
    return ID;
  }

  /**
   * Return the name of the look and feel.
   * 
   * @return The name of the look and feel.
   */
  public String getName ()
  {
    return NAME;
  }

  //
  // protected interface
  //

  /**
   * Initialize the uiClassID to BasicComponentUI mapping.
   * The JComponent classes define their own uiClassID constants
   * (see AbstractComponent.getUIClassID).  This table must
   * map those constants to a BasicComponentUI class of the
   * appropriate type.
   * 
   * @see #getDefaults
   */
  protected void initClassDefaults (UIDefaults table)
  {
    super.initClassDefaults(table);
    String packageName = "net.beeger.squareness.delegate.";
    table.put("ButtonUI", packageName + "SquarenessButtonUI");
    table.put("RadioButtonUI", packageName + "SquarenessRadioButtonUI");
    table.put("CheckBoxUI", packageName + "SquarenessCheckBoxUI");
    table.put("ToolBarUI", packageName + "SquarenessToolBarUI");
    table.put("ToggleButtonUI", packageName + "SquarenessToggleButtonUI");
    table.put("ScrollBarUI", packageName + "SquarenessScrollBarUI");
    table.put("TabbedPaneUI", packageName + "SquarenessTabbedPaneUI");
    table.put("ComboBoxUI", packageName + "SquarenessComboBoxUI");
    table.put("SliderUI", packageName + "SquarenessSliderUI");
    table.put("InternalFrameUI", packageName + "SquarenessInternalFrameUI");
    table.put("SpinnerUI", packageName + "SquarenessSpinnerUI");
    table.put("RootPaneUI", packageName + "SquarenessRootPaneUI");

    table.put("ProgressBarUI", "javax.swing.plaf.basic.BasicProgressBarUI");
    table.put("SplitPaneUI", "javax.swing.plaf.basic.BasicSplitPaneUI");
  }

  protected void initComponentDefaults (UIDefaults table)
  {
    setCurrentTheme(new DefaultSquarenessTheme());
    super.initComponentDefaults(table);

    table.put(SquarenessConstants.SCROLL_ARROW_LEFT_KEY, new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getLeftIcon();
      }
    });
    table.put(SquarenessConstants.SCROLL_ARROW_RIGHT_KEY, new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getRightIcon();
      }
    });
    table.put(SquarenessConstants.SCROLL_ARROW_UP_KEY, new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getUpIcon();
      }
    });
    table.put(SquarenessConstants.SCROLL_ARROW_DOWN_KEY, new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getDownIcon();
      }
    });

    table.put(SquarenessConstants.SPIN_UP_KEY, new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getSpinUpIcon();
      }
    });
    table.put(SquarenessConstants.SPIN_DOWN_KEY, new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getSpinDownIcon();
      }
    });

    UIDefaults.LazyValue borderWithMargin = new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessBorderFactory.getControlBorderWithMargin();
      }
    };

    UIDefaults.LazyValue borderWithoutMargin = new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessBorderFactory.getControlBorderWithoutMargin();
      }
    };

    UIDefaults.LazyValue tableHeaderCellBorder = new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessBorderFactory.getTableHeaderCellBorder();
      }
    };

    table.put("Button.background", getCurrentSquarenessTheme().getNormalControlBackgroundColor());
    table.put("Button.border", borderWithMargin);

    table.put("ToggleButton.background", getCurrentSquarenessTheme().getNormalControlBackgroundColor());
    table.put("ToggleButton.border", borderWithMargin);

    table.put("RadioButton.icon", new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getRadioButtonIcon();
      }
    });

    table.put("CheckBox.icon", new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getCheckBoxIcon();
      }
    });

    UIDefaults.LazyValue emptyborder = new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return new BorderUIResource.EmptyBorderUIResource(0, 0, 0, 0);
      }
    };

    UIDefaults.LazyValue menuItemBorder = new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessBorderFactory.getMenuItemBorder();
      }
    };

    UIDefaults.LazyValue menuItemCheckIcon = new UIDefaults.LazyValue()
        {
          public Object createValue (UIDefaults table)
          {
            return SquarenessIconFactory.getMenuItemCheckIcon();
          }
        };

    UIDefaults.LazyValue menuItemArrowIcon = new UIDefaults.LazyValue()
        {
          public Object createValue (UIDefaults table)
          {
            return SquarenessIconFactory.getMenuItemArrowIcon();
          }
        };

    table.put("TextField.border", borderWithoutMargin);
    table.put("FormattedTextField.border", borderWithoutMargin);
    table.put("PasswordField.border", borderWithoutMargin);

    table.put("MenuBar.background", getCurrentSquarenessTheme().getWindowBackgroundColor());
    table.put("MenuBar.border", emptyborder);

    table.put("Menu.background", null);
    table.put("Menu.border", menuItemBorder);
    table.put("Menu.borderPainted", Boolean.TRUE);
    table.put("Menu.selectionForeground", table.get("textHighlightText"));
    table.put("Menu.selectionBackground", table.get("textHighlight"));
    table.put("Menu.arrowIcon", new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getMenuArrowIcon();
      }
    });
    table.put("Menu.checkIcon", menuItemCheckIcon);

    table.put("MenuItem.background", null);
    table.put("MenuItem.border", menuItemBorder);
    table.put("MenuItem.borderPainted", Boolean.TRUE);
    table.put("MenuItem.selectionForeground", table.get("textHighlightText"));
    table.put("MenuItem.selectionBackground", table.get("textHighlight"));
    table.put("MenuItem.checkIcon", menuItemCheckIcon);

    table.put("RadioButtonMenuItem.background", null);
    table.put("RadioButtonMenuItem.border", menuItemBorder);
    table.put("RadioButtonMenuItem.borderPainted", Boolean.TRUE);
    table.put("RadioButtonMenuItem.selectionForeground", table.get("textHighlightText"));
    table.put("RadioButtonMenuItem.selectionBackground", table.get("textHighlight"));
    table.put("RadioButtonMenuItem.checkIcon", new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getRadioButtonMenuItemCheckIcon();
      }
    });
    table.put("RadioButtonMenuItem.arrowIcon", menuItemArrowIcon);

    table.put("CheckBoxMenuItem.background", null);
    table.put("CheckBoxMenuItem.border", menuItemBorder);
    table.put("CheckBoxMenuItem.borderPainted", Boolean.TRUE);
    table.put("CheckBoxMenuItem.selectionForeground", table.get("textHighlightText"));
    table.put("CheckBoxMenuItem.selectionBackground", table.get("textHighlight"));
    table.put("CheckBoxMenuItem.checkIcon", new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getCheckBoxMenuItemCheckIcon();
      }
    });
    table.put("CheckBoxMenuItem.arrowIcon", menuItemArrowIcon);

    table.put("Separator.foreground", getCurrentSquarenessTheme().getNormalBorderColor());
    table.put("Separator.background", null);
    table.put("PopupMenu.border", new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessBorderFactory.getNonSpacingControlBorderWithoutMargin();
      }
    });

    UIDefaults.LazyValue frameBorder = new UIDefaults.LazyValue()
        {
          public Object createValue (UIDefaults table)
          {
            return SquarenessBorderFactory.getInternalFrameBorder();
          }
        };

    table.put("InternalFrame.border", frameBorder);

    table.put("InternalFrame.icon", null);
    table.put("InternalFrame.maximizeIcon", new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getMaximizeFrameIcon();
      }
    });
    table.put("InternalFrame.minimizeIcon", new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getMinimizeFrameIcon();
      }
    });
    table.put("InternalFrame.iconifyIcon", new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getIconifyFrameIcon();
      }
    });
    table.put("InternalFrame.closeIcon", new UIDefaults.LazyValue()
    {
      public Object createValue (UIDefaults table)
      {
        return SquarenessIconFactory.getCloseFrameIcon();
      }
    });

    table.put("RootPane.frameBorder", frameBorder);
    table.put("RootPane.plainDialogBorder", frameBorder);
    table.put("RootPane.informationDialogBorder", frameBorder);
    table.put("RootPane.errorDialogBorder", frameBorder);
    table.put("RootPane.colorChooserDialogBorder", frameBorder);
    table.put("RootPane.fileChooserDialogBorder", frameBorder);
    table.put("RootPane.questionDialogBorder", frameBorder);
    table.put("RootPane.warningDialogBorder", frameBorder);


    table.put("ScrollBar.thumb", getCurrentSquarenessTheme().getNormalControlBackgroundColor());
    table.put("ScrollBar.background", getCurrentSquarenessTheme().getProgressBarBackgroundColor());
    table.put("ScrollBar.width", new Integer(17));
    table.put("ScrollPane.border", borderWithoutMargin);

    table.put("TableHeader.background", getCurrentSquarenessTheme().getNormalControlBackgroundColor());

    table.put("ToolBar.border", emptyborder);
    table.put("ToolBar.background", getCurrentSquarenessTheme().getWindowBackgroundColor());

    table.put("ComboBox.border", borderWithoutMargin);
    table.put("ComboBox.background", getCurrentSquarenessTheme().getTextInputBackgroundColor());
    table.put("ComboBox.selectionBackground", table.get("textHighlight"));
    table.put("ComboBox.selectionForeground", table.get("textHighlightText"));

    table.put("ProgressBar.border", borderWithoutMargin);
    table.put("ProgressBar.cellLength", new Integer(1));
    table.put("ProgressBar.cellSpacing", new Integer(1));
    table.put("ProgressBar.selectionForeground", getCurrentSquarenessTheme().getTextColor());
    table.put("ProgressBar.selectionBackground", getCurrentSquarenessTheme().getTextColor());
    table.put("ProgressBar.foreground", getCurrentSquarenessTheme().getSelectedControlBackgroundColor());
    table.put("ProgressBar.background", getCurrentSquarenessTheme().getProgressBarBackgroundColor());

    table.put("SplitPane.highlight", getCurrentSquarenessTheme().getNormalBorderColor());
    table.put("SplitPane.shadow", getCurrentSquarenessTheme().getNormalBorderColor());
    table.put("SplitPane.darkShadow", getCurrentSquarenessTheme().getNormalBorderColor());

    table.put("TabbedPane.selected", getCurrentSquarenessTheme().getWindowBackgroundColor());
    table.put("TabbedPane.shadow", getCurrentSquarenessTheme().getNormalBorderColor().brighter().brighter());
    table.put("TabbedPane.darkShadow", getCurrentSquarenessTheme().getNormalBorderColor());
    table.put("TabbedPane.highlight", getCurrentSquarenessTheme().getWindowBackgroundColor().brighter().brighter());
    table.put("TabbedPane.background", getCurrentSquarenessTheme().getWindowBackgroundColor());
    table.put("TabbedPane.selected", null);
    table.put("Viewport.background", getCurrentSquarenessTheme().getWindowBackgroundColor());

    table.put("Table.scrollPaneBorder", borderWithoutMargin);
    table.put("TableHeader.cellBorder", tableHeaderCellBorder);

    table.put("Panel.background", getCurrentSquarenessTheme().getWindowBackgroundColor());
    table.put("Panel.foreground", getCurrentSquarenessTheme().getTextColor());

    table.put("Tree.collapsedIcon", LookAndFeel.makeIcon(getClass(), "icons/treecollapsed.gif"));
    table.put("Tree.expandedIcon", LookAndFeel.makeIcon(getClass(), "icons/treeexpanded.gif"));
    table.put("Tree.openIcon", LookAndFeel.makeIcon(getClass(), "icons/folderopened.gif"));
    table.put("Tree.closedIcon", LookAndFeel.makeIcon(getClass(), "icons/folderclosed.gif"));
    table.put("Tree.leafIcon", LookAndFeel.makeIcon(getClass(), "icons/document.gif"));

    table.put("FileView.directoryIcon", LookAndFeel.makeIcon(getClass(), "icons/folderclosed.gif"));
    table.put("FileView.fileIcon", LookAndFeel.makeIcon(getClass(), "icons/document.gif"));
    table.put("FileView.computerIcon", LookAndFeel.makeIcon(getClass(), "icons/computer.gif"));
    table.put("FileView.hardDriveIcon", LookAndFeel.makeIcon(getClass(), "icons/hd.gif"));
    table.put("FileView.floppyDriveIcon", LookAndFeel.makeIcon(getClass(), "icons/floppy.gif"));

    table.put("FileChooser.detailsViewIcon", LookAndFeel.makeIcon(getClass(), "icons/detail.gif"));
    table.put("FileChooser.homeFolderIcon", LookAndFeel.makeIcon(getClass(), "icons/home.gif"));
    table.put("FileChooser.listViewIcon", LookAndFeel.makeIcon(getClass(), "icons/list.gif"));
    table.put("FileChooser.newFolderIcon", LookAndFeel.makeIcon(getClass(), "icons/folderclosed.gif"));
    table.put("FileChooser.upFolderIcon", LookAndFeel.makeIcon(getClass(), "icons/folderup.gif"));

//    table.put("Spinner.background",table.get(SquarenessConstants.NORMAL_CONTROL_COLOR_KEY));
//    table.put("Spinner.foreground",table.get(SquarenessConstants.TEXT_TEXT_COLOR_KEY));
//    table.put("Spinner.border", borderWithoutMargin);
  }

  /**
   * Load the SystemColors into the defaults table.  The keys
   * for SystemColor defaults are the same as the names of
   * the public fields in SystemColor.  If the table is being
   * created on a native Windows platform we use the SystemColor
   * values, otherwise we create color objects whose values match
   * the defaults Windows95 colors.
   */
  protected void initSystemColorDefaults (UIDefaults table)
  {
    table.put("desktop", getCurrentSquarenessTheme().getDesktopColor());
    table.put("activeCaption", getCurrentSquarenessTheme().getWindowBackgroundColor());
    table.put("activeCaptionText", getCurrentSquarenessTheme().getTextColor());
    table.put("activeCaptionBorder", getCurrentSquarenessTheme().getNormalBorderColor());
    table.put("inactiveCaption", getCurrentSquarenessTheme().getWindowBackgroundColor());
    table.put("inactiveCaptionText", getCurrentSquarenessTheme().getDisabledBorderColor());
    table.put("inactiveCaptionBorder", getCurrentSquarenessTheme().getInactiveWindowBorderColor());
    table.put("window", getCurrentSquarenessTheme().getTextInputBackgroundColor());
    table.put("windowBorder", getCurrentSquarenessTheme().getNormalBorderColor());
    table.put("windowText", getCurrentSquarenessTheme().getTextColor());
    table.put("menu", getCurrentSquarenessTheme().getProgressBarBackgroundColor());
    table.put("menuText", getCurrentSquarenessTheme().getTextColor());
    table.put("text", getCurrentSquarenessTheme().getTextInputBackgroundColor());
    table.put("textText", getCurrentSquarenessTheme().getTextColor());
    table.put("textHighlight", getCurrentSquarenessTheme().getSelectedControlBackgroundColor());
    table.put("textHighlightText", getCurrentSquarenessTheme().getTextColor());
    table.put("textInactiveText", getCurrentSquarenessTheme().getTextColor());
    table.put("control", getCurrentSquarenessTheme().getWindowBackgroundColor());
    table.put("controlText", getCurrentSquarenessTheme().getTextColor());
    table.put("controlHighlight", getCurrentSquarenessTheme().getSelectedControlBackgroundColor());
    table.put("controlLtHighlight", getCurrentSquarenessTheme().getSelectedControlBackgroundColor());
    table.put("controlShadow", getCurrentSquarenessTheme().getSelectedControlBackgroundShadowColor());
    table.put("controlDkShadow", getCurrentSquarenessTheme().getSelectedControlBackgroundShadowColor());
    table.put("scrollbar", getCurrentSquarenessTheme().getProgressBarBackgroundColor());
    table.put("info", getCurrentSquarenessTheme().getProgressBarBackgroundColor());
    table.put("infoText", getCurrentSquarenessTheme().getTextColor());
  }


  //
  // private interface
  //

  private static final String DESCRIPTION = "Squareness Look And Feel";
  private static final String ID = "Squareness";
  private static final String NAME = "Squareness";

  private static SquarenessTheme _currentSquarenessTheme;
}

/*
  $Log: SquarenessLookAndFeel.java,v $
  Revision 1.16  2004/09/18 17:30:48  rbeeger
  * Updated copyright block and license file. Squareness Look And Feel is now licensed under Academic Free License 2.1
  * Added themepack.

  Revision 1.15  2004/09/17 18:26:48  rbeeger
  * Squareness Look And Feel now searches for themeselector.slfts in the classpath when no theme was set. If found the theme file that is specified as currentTheme= is automatically loaded

  Revision 1.14  2004/09/10 17:29:32  rbeeger
  * title pane now works for internal frame ui and root pane ui
  * SquarenessRootPaneUI is mostly a copy of MetalRootPaneUI. The only difference: the title pane.
  * Fixed bug [ 1017901 ] An undecorated frame doesn't update properly with 1.1.1: An empty border in the frame border that worked ok in internal frames, didn't work on JFrames at all.
  * Added documentation in some places.

  Revision 1.13  2004/08/29 17:14:35  rbeeger
  * Started developing theming support

  Revision 1.12  2004/05/22 18:18:13  rbeeger
  * Fix for bug 958104 (Menu arrows don't follow an orientation policy)
  * Definition of border for JFrame in all its occurences.

  Revision 1.11  2004/04/04 17:30:24  rbeeger
  Fixed border for popup menus..
  Changed version number fo 1.1.

  Revision 1.10  2004/04/02 15:33:50  rbeeger
  Added arrow icons for menu items.

  Revision 1.9  2004/03/10 08:48:36  rbeeger
  Added check icons for radio button menu items and check box menu items..

  Revision 1.8  2004/03/08 22:53:13  rbeeger
  Fixed placement of frame buttons and painting of frame borders.

  Revision 1.7  2004/03/08 17:21:05  rbeeger
  Added pressed scrollbar track effect.

  Revision 1.6  2004/02/14 19:12:35  rbeeger
  Updated copyright statement
  Added cvs log directive at the end of each file
  Optimized imports
  Reformated code

 */
