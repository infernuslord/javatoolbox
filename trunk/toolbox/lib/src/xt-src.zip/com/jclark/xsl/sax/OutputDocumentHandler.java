// $Id: OutputDocumentHandler.java,v 1.1 2002/04/25 18:15:50 bill Exp $

package com.jclark.xsl.sax;

import org.xml.sax.*;
import java.io.IOException;

/**
 * a SAX1 DocumentHandler that serializes to a Destination
 */
public interface OutputDocumentHandler extends DocumentHandler
{
    DocumentHandler init(Destination dest, AttributeList atts) 
        throws SAXException, IOException;
}
