/*
 * Please see COPYING for license details
 *
 * Copyright (C) 2003 Raghu K, All rights reserved.
 */

package hamsam.protocol.msn;

/**
 * An error command reported by server.
 */
class ErrorCommand extends AbstractCommand
{
	/**
	 * Construct an error command with the given error number.
	 *
	 * @param type error number for this command.
	 */
	ErrorCommand(String type)
	{
		super(type);
	}
}
