package tool.lucene;

import java.io.IOException;

import org.apache.lucene.analysis.*;



/**
	Filter out words shorter that a minimum length length,
	such as 1- and 2-letter words.

	@version $Revision: 1.1 $ $Date: 2003/06/01 07:38:43 $
*/
public class ShortFilter extends TokenFilter {
  int min_;

  /**
	@param min  minimum number of characters required in token.  Tokens with fewer characters are rejected.
  */
  public ShortFilter(TokenStream in, int min) {
	super(in);
	min_ = Math.max(1,min);
  }

  public Token next() throws IOException {
	Token tok = input.next();
	if (tok!=null && tok.termText().length() < min_) tok = next();

	return tok;
  }
}
