/*
 * Copyright (c) 2005, the JUNG Project and the Regents of the University of
 * California All rights reserved.
 *
 * This software is open-source under the BSD license; see either "license.txt"
 * or http://jung.sourceforge.net/license.txt for a description.
 *
 * Created on Jul 21, 2005
 */

package edu.uci.ics.jung.visualization.transform;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;

import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.VisualizationViewer.Paintable;
import edu.uci.ics.jung.visualization.control.ModalGraphMouse;
import edu.uci.ics.jung.visualization.control.ModalHyperbolicGraphMouse;
/**
 * A class to make it easy to add a Hyperbolic projection
 * examining lens to a jung graph application. See HyperbolicTransforerDemo
 * for an example of how to use it.
 * 
 * @author Tom Nelson - RABA Technologies
 *
 *
 */
public abstract class AbstractHyperbolicLensSupport implements HyperbolicLensSupport {

    protected VisualizationViewer vv;
    protected VisualizationViewer.GraphMouse graphMouse;
    protected MutableTransformer savedViewTransformer;
    protected HyperbolicTransformer hyperbolicTransformer;
    protected ModalGraphMouse hyperbolicGraphMouse;
    protected Lens lens;
    protected String defaultToolTipText;

    protected static final String instructions = 
        "<html><center>Mouse-Drag the Lens center to move it<p>"+
        "Mouse-Drag the Lens edge to resize it<p>"+
        "Ctrl+MouseWheel to change magnification</center></html>";
    
    /**
     * create the base class, setting common members and creating
     * a custom GraphMouse
     * @param vv the VisualizationViewer to work on
     */
    public AbstractHyperbolicLensSupport(VisualizationViewer vv) {
        this.vv = vv;
        this.savedViewTransformer = vv.getViewTransformer();
        this.graphMouse = vv.getGraphMouse();
        this.defaultToolTipText = vv.getToolTipText();

        hyperbolicGraphMouse = new ModalHyperbolicGraphMouse();
    }

    public void activate(boolean state) {
        if(state) activate();
        else deactivate();
    }
    
    public HyperbolicTransformer getHyperbolicTransformer() {
        return hyperbolicTransformer;
    }

    /**
     * @return Returns the hyperbolicGraphMouse.
     */
    public ModalGraphMouse getHyperbolicGraphMouse() {
        return hyperbolicGraphMouse;
    }

    /**
     * the background for the hyperbolic projection
     * @author Tom Nelson - RABA Technologies
     *
     *
     */
    public static class Lens implements Paintable {
        HyperbolicTransformer hyperbolicTransformer;
        Ellipse2D ellipse;
        
        public Lens(HyperbolicTransformer hyperbolicTransformer) {
            this.hyperbolicTransformer = hyperbolicTransformer;
            this.ellipse = hyperbolicTransformer.getEllipse();
        }
        
        /**
         * @return Returns the hyperbolicTransformer.
         */

        public void paint(Graphics g) {
            
            Graphics2D g2d = (Graphics2D)g;
            g.setColor(Color.decode("0xdddddd"));
            g2d.fill(ellipse);
            g.setColor(Color.gray);
            g2d.draw(ellipse);
            g.drawOval((int)Math.round(ellipse.getCenterX()-5),
                    (int)Math.round(ellipse.getCenterY()-5),
                    10, 10);
        }

        public boolean useTransform() {
            return false;
        }
    }
}
