 /*
* Copyright (c) 2003, the JUNG Project and the Regents of the University 
* of California
* All rights reserved.
*
* This software is open-source under the BSD license; see either
* "license.txt" or
* http://jung.sourceforge.net/license.txt for a description.
*/
package edu.uci.ics.jung.visualization;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.geom.AffineTransform;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.swing.JPanel;

import edu.uci.ics.jung.exceptions.FatalException;
import edu.uci.ics.jung.graph.Edge;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.utils.Pair;
import edu.uci.ics.jung.utils.UserData;

public class VisualizationViewer extends JPanel implements PickedInfo {

	protected StatusCallback statusCallback;
	Thread relaxer;
	boolean suspended;
	boolean manualSuspend;
	protected Renderer renderer;
	protected Layout layout;
	
	protected ToolTipListener toolTipListener;

	protected double offsetx = 0.0;
	protected double offsety = 0.0;
	protected double scalex = 1.0;
	protected double scaley = 1.0;
	
	protected Map renderingHints = new HashMap();
	//	private Graph graph;

	public VisualizationViewer(Layout layout, Renderer r) {
		this.addComponentListener(new VisualizationListener(this));
		this.renderer = r;
		r.setPickedKey(this);
		this.layout = layout;
		setPreferredSize(new Dimension(600, 600));
		layout.initialize(new Dimension(600, 600));
		//		this.graph = layout.getGraph();
		this.suspended = true;
		this.manualSuspend = false;
        renderingHints.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		init();
		initMouseClicker();
	}

	/**
	 *
	 */
	protected void initMouseClicker() {
		GraphMouse l = new GraphMouse();
		addMouseListener(l);
		addMouseMotionListener(l);
	}

	/**
	 * UNTESTED.
	 * @param v
	 */
	public void setRenderer(Renderer r) {
		this.renderer = r;
		r.setPickedKey(this);
		repaint();
	}

	/**
	 * @param v
	 */
	public void setGraphLayout(Layout v) {
		suspend();
		v.initialize(this.layout.getCurrentSize());
		this.layout = v;
		layout.restart();
		prerelax();
		unsuspend();
	}
	
	public Layout getGraphLayout() {
		return layout;
	}

	/**
	 * starts a visRunner thread without prerelaxing
	 */
	public synchronized void restartThreadOnly() {
	    if (visRunnerIsRunning ) {
	        throw new FatalException("Can't init while a visrunner is running");
	    }
		relaxer = new VisRunner();
		relaxer.start();
	}

	
	/**
	 * Pre-relaxes and starts a visRunner thread
	 */
	public synchronized void init() {
	    if (visRunnerIsRunning ) {
	        throw new FatalException("Can't init while a visrunner is running");
	    }
		prerelax();
		relaxer = new VisRunner();
		relaxer.start();
	}

	/**
	 * Restarts layout, then calls init();
	 */
	public synchronized void restart() {
	    if (visRunnerIsRunning ) {
	        throw new FatalException("Can't restart while a visrunner is running");
	    }
		layout.restart();
		init();
		repaint();
	}

	/** 
	 * (non-Javadoc)
	 * @see javax.swing.JComponent#setVisible(boolean)
	 */
	public void setVisible(boolean aFlag) {
		super.setVisible(aFlag);
		layout.resize(this.getSize());
	}

	/**
	 * Runs the visualization forward a few hundred iterations (for half a 
	 * second)
	 */
	public void prerelax() {
		suspend();

		int i = 0;
		if (layout.isIncremental()) {
			// then increment layout for half a second
			long timeNow = System.currentTimeMillis();
			while (System.currentTimeMillis() - timeNow < 500 && !layout.incrementsAreDone()) {
				i++;
				layout.advancePositions();
			}
		}
//		System.out.println("Prerelax : " + i + " iterations");
		unsuspend();

	}

	/**
	 * If the visualization runner is not yet running, kick it off.
	 */
	protected synchronized void start() {
		suspended = false;
		synchronized (pauseObject) {
			pauseObject.notifyAll();
		}
	}

	public synchronized void suspend() {
//	    System.out.println("> Manually suspending.");
		manualSuspend = true;
	}

	public synchronized void unsuspend() {
//	    System.out.println("> Manually releasing.");
		manualSuspend = false;
		synchronized (pauseObject) {
			pauseObject.notifyAll();
		}
	}

	public Object pauseObject = new String("PAUSE OBJECT");

	public boolean isPicked(Vertex v) {
		Boolean picked = (Boolean) v.getUserDatum(getVisKey());
		return ((picked != null) && (picked == Boolean.TRUE));
	}

	/**
	 * @param picked
	 * @param b
	 */
	protected void pick(Vertex picked, boolean b) {
		if (b)
			layout.lockVertex(picked);
		else
			layout.unlockVertex(picked);
		Object key = getVisKey();
		if (picked.getUserDatum(key) != null) {
			picked.setUserDatum(
				key,
				b ? Boolean.TRUE : Boolean.FALSE,
				UserData.REMOVE);
		} else {
			picked.addUserDatum(
				key,
				b ? Boolean.TRUE : Boolean.FALSE,
				UserData.REMOVE);
		}
	}

	public static final String VIS_KEY = "edu.uci.ics.jung.visualization";

	protected Object key = null;

	protected Object getVisKey() {
		if (key == null)
			key = new Pair(this, VIS_KEY);
		return key;
	}

	protected final class GraphMouse
		extends MouseAdapter
		implements MouseMotionListener {
		protected Vertex picked;

		public void mousePressed(MouseEvent e) {
		    Point p = new Point((int)(e.getX()/scalex+offsetx), (int)(e.getY()/scaley+offsety));
			Vertex v = layout.getVertex(p.getX(), p.getY());
			if (v == null) {
				System.out.println("Bad pick!");
				return;
			}
			picked = v;
			pick(picked, true);
			layout.forceMove(picked, (int)p.getX(), (int)p.getY());
			repaint();
		}
		public void mouseReleased(MouseEvent e) {
			if (picked == null)
				return;
			pick(picked, false);
			picked = null;
			repaint();
		}
		public void mouseDragged(MouseEvent e) {
			if (picked == null)
				return;
			layout.forceMove(picked, (int)(e.getX()/scalex+offsetx), (int)(e.getY()/scaley+offsety));
			repaint();
			//			drawSpot( e.getX(), e.getY() );
		}

		public void mouseMoved(MouseEvent e) {
			return;
		}

	}

	long[] relaxTimes = new long[5];
	long[] paintTimes = new long[5];
	int relaxIndex = 0;
	int paintIndex = 0;
	double paintfps, relaxfps;

	//	int x = -1;
	//	int y = -1;
	//	private void drawSpot(int x, int y) {
	//		this.x = x; this.y = y;
	//	}

	boolean stop = false;

	boolean visRunnerIsRunning = false; 
	
	protected class VisRunner extends Thread {
		public VisRunner() {
			super("Relaxer Thread");
		}

		public void run() {
		    visRunnerIsRunning = true;
		    try {
			while (!layout.incrementsAreDone() && !stop) {
//			    								System.out.println("Iterating!");

				synchronized (pauseObject) {
					while ((suspended || manualSuspend) && !stop) {
//												System.out.println("Going into suspend...");
						try {
							pauseObject.wait();
						} catch (InterruptedException e) {
						}
//												System.out.println("Coming out of suspend...");
					}
				}
//				System.out.println("Making progress in the viz loop!");
				long start = System.currentTimeMillis();
				layout.advancePositions();
				long delta = System.currentTimeMillis() - start;

				if (stop)
					return;

				String status = layout.getStatus();
				if (statusCallback != null && status != null) {
					statusCallback.callBack(status);
				}

				if (stop)
					return;

				relaxTimes[relaxIndex++] = delta;
				relaxIndex = relaxIndex % relaxTimes.length;
				relaxfps = average(relaxTimes);

				if (stop)
					return;

				repaint();

				if (stop)
					return;

				try {
					sleep(20);
				} catch (InterruptedException ie) {
				}
			}
//						System.out.println("Stopping iteration loop.");
		    } finally {
					    visRunnerIsRunning = false;
		    }
		}
	}
	
	/**
	 * Returns a flag that says whether the visRunner thread is running. If
	 * it is not, then you may need to restart the thread (with 
	 * @return
	 */
	public boolean isVisRunnerRunning() {
	    return visRunnerIsRunning;
	}

	public void setScale(double scalex, double scaley) {
	    this.scalex = scalex;
	    this.scaley = scaley;
	}
	
	public double getScaleX() {
	    return scalex;	
	}
	
	public double getScaleY() {
	    return scaley;
	}
	
	public double getOffsetX() {
	    return offsetx;
	}
	
	public double getOffsetY() {
	    return offsety;
	}
	
	public void setOffset(double offsetx, double offsety) {
	    Dimension d = layout.getCurrentSize();
	    this.offsetx = offsetx*d.width;
	    this.offsety = offsety*d.height;
	}

    /**
     * @return Returns the renderingHints.
     */
    public Map getRenderingHints() {
        return renderingHints;
    }
    /**
     * @param renderingHints The renderingHints to set.
     */
    public void setRenderingHints(Map renderingHints) {
        this.renderingHints = renderingHints;
    }
	protected synchronized void paintComponent(Graphics g) {
		start();
		super.paintComponent(g);

		Graphics2D g2d = (Graphics2D)g;
		g2d.setRenderingHints(renderingHints);
		AffineTransform oldXform = g2d.getTransform();
		AffineTransform newXform = new AffineTransform(oldXform);
		newXform.scale(scalex, scaley);
		newXform.translate(-offsetx, -offsety);
		g2d.setTransform(newXform);

		long start = System.currentTimeMillis();
		// for all edges, paint edge
		for (Iterator iter = layout.getVisibleEdges().iterator();
			iter.hasNext();
			) {
			Edge e = (Edge) iter.next();
			Vertex v1 = (Vertex) e.getEndpoints().getFirst();
			Vertex v2 = (Vertex) e.getEndpoints().getSecond();
			renderer.paintEdge(
				g,
				e,
				(int) layout.getX(v1),
				(int) layout.getY(v1),
				(int) layout.getX(v2),
				(int) layout.getY(v2));
		}

		for (Iterator iter = layout.getVisibleVertices().iterator();
			iter.hasNext();
			) {
			Vertex v = (Vertex) iter.next();
			renderer.paintVertex(
				g,
				v,
				(int) layout.getX(v),
				(int) layout.getY(v));
		}

		long delta = System.currentTimeMillis() - start;
		paintTimes[paintIndex++] = delta;
		paintIndex = paintIndex % paintTimes.length;
		paintfps = average(paintTimes);

		g2d.setTransform(oldXform);
	}

	/**
	 * Returns the double average of a number of long values.
	 * @param paintTimes	an array of longs
	 * @return the average of the doubles
	 */
	protected double average(long[] paintTimes) {
		double l = 0;
		for (int i = 0; i < paintTimes.length; i++) {
			l += paintTimes[i];
		}
		return l / paintTimes.length;
	}

	protected class VisualizationListener extends ComponentAdapter {
		protected VisualizationViewer vv;
		public VisualizationListener(VisualizationViewer vv) {
			this.vv = vv;
		}
		public void componentHidden(ComponentEvent e) {
		}

		public void componentResized(ComponentEvent e) {
			vv.layout.resize(e.getComponent().getSize());
			//			vv.prerelax();
		}
		public void componentShown(ComponentEvent e) {
		}

	}
	/**
	 * @param scb
	 */
	public void setTextCallback(StatusCallback scb) {
		this.statusCallback = scb;
	}

	/**
	 * 
	 */
	public synchronized void stop() {
	    System.out.println("> stop.");
		manualSuspend = false;
		suspended = false;
		stop = true;
		synchronized (pauseObject) {
			pauseObject.notifyAll();
		}
	}

    public void setToolTipListener(ToolTipListener listener) {
        this.toolTipListener = listener;
        setToolTipText("VisViewer"); // something to make tool tips happen at all
}

    public String getToolTipText(MouseEvent event) {
        if(toolTipListener != null) {
            return toolTipListener.getToolTipText(event);
        } else {
            return getToolTipText();
        }
      }

	
    public interface ToolTipListener {
        public String getToolTipText(MouseEvent event);
      }


}
