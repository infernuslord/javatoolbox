/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.layouts;

import java.awt.Container;
import java.awt.Component;
import java.awt.Insets;
import java.awt.Dimension;
import java.util.Hashtable;

import javax.swing.JPopupMenu;

import java.awt.Point;

import javax.swing.JRootPane;
import javax.swing.JSeparator;
import javax.swing.SwingUtilities;

public class QueueLayout extends AbstractLayout{
    public static final int VERTICAL = 0;
    public static final int HORIZONTAL = 100;
    
    public static final int STRECH_COMPONENTS = 2;
    public static final int CENTER_COMPONENTS = 3;
    public static final int FLOAT_COMPONENTS = 4;
    public static final int SINK_COMPONENTS = 5;
    
    public static final Integer BEGIN = new Integer(0);
    public static final Integer END = new Integer(1);
    
    protected int gap = 0;
    protected int orientation = VERTICAL;
    protected boolean showingAll = true;
    protected int alignment = CENTER_COMPONENTS;
    protected Hashtable popupHash = null;


    public QueueLayout() {
      this(0);
    }
    
    
    public QueueLayout(int gap){
      this(gap, 0, CENTER_COMPONENTS);
    }
    
    
    public QueueLayout(int gap, int orientation, int alignment){
      super();
    
      setGap(gap);
      setOrientation(orientation);
      popupHash = new Hashtable();
      this.alignment = alignment;
    }
    
    
    protected Object getDefaultConstraints(){
      return BEGIN;
    }
    
    
    public int getGap() {
      return gap;
    }
    
    
    public int getOrientation() {
      return orientation;
    }
    
    
    public boolean isShowingAll(){
      return showingAll;
    }
    
    
    protected void performLayout(Container parent){
      Component[] cps = parent.getComponents();
      Insets ins = parent.getInsets();
      Dimension cPrefSize = null,
                pSize = parent.getSize();
    
      int offset = 0;
    
      int startOffset = orientation==VERTICAL ? ins.top : ins.left,
    	  availSpace = orientation==VERTICAL ? pSize.height -ins.bottom -ins.top : pSize.width -ins.right -ins.left,
    	  endOffset = startOffset +availSpace +getGap(),
    	  mobileVal = 0;
    
      for(int i=0; i<cps.length; i++){
    	  if(!cps[i].isVisible()) continue;
    
    	  cPrefSize = cps[i].getPreferredSize()!=null ? cps[i].getPreferredSize() : new Dimension(20, 20);
    	  mobileVal = orientation==VERTICAL ? cPrefSize.height : cPrefSize.width;
    
    	  //availSpace -= mobileVal;
    
    	  if(BEGIN.equals(getConstraintsFor(cps[i]))){
    		 offset = startOffset;
    		 startOffset += mobileVal +getGap();
    	  }
    	  else{
    		   endOffset -=  mobileVal +getGap();
    		   offset = endOffset;
    	  }
    
    	  // CENTER_COMPONENTS by default
    	  int x = ins.left + (pSize.width -ins.left -ins.right -cPrefSize.width)/2,
    	      y = ins.top + (pSize.height -ins.top -ins.bottom -cPrefSize.height)/2,
    		  w = cPrefSize.width,
    		  h = cPrefSize.height;
    
          if(alignment == STRECH_COMPONENTS){
             x = ins.left;
    		 y = ins.top;
    		 w = pSize.width -ins.right -ins.left;
    		 h = pSize.height -ins.top -ins.bottom;
    	  }
          else if(alignment == SINK_COMPONENTS){
              x = ins.left +parent.getWidth() -ins.right -cPrefSize.width;
              y = ins.top +parent.getHeight() -ins.bottom -cPrefSize.height;
          }
          else if(alignment == FLOAT_COMPONENTS){
              x = ins.left;
              y = ins.top;
          }
          
    	  
    	  if(cps[i] instanceof JSeparator){
             x = ins.left +2;
    		 y = ins.top +2;
    		 w = pSize.width -ins.right -ins.left -4;
    		 h = pSize.height -ins.top -ins.bottom -4;
    	  }
    
    	  if(orientation==VERTICAL) cps[i].setBounds(x, offset, w, mobileVal);
    	  else cps[i].setBounds(offset, y, mobileVal, h);
    
    	  availSpace -= getGap() +mobileVal;
      }
    }
    
    
    public java.awt.Dimension preferredLayoutSize(Container parent){
      Insets ins = parent.getInsets()!=null ? parent.getInsets() : new Insets(0, 0, 0, 0);
    
      int pw = 0,
    	  ph = 0;
    
      Component[] cps = parent.getComponents();
      
      int cpCount = 0;
      
      for(int i=0; i<cps.length; i++){
    	  if(!cps[i].isVisible()) continue;
    
    	  if(orientation==VERTICAL){
    		 pw = Math.max(cps[i].getPreferredSize().width, pw);
    		 ph += cps[i].getPreferredSize().height +(cpCount!=0 ? +getGap() : 0);
    	  }
    	  else{
    		   ph = Math.max(cps[i].getPreferredSize().height, ph);
    		   pw += cps[i].getPreferredSize().width +(cpCount!=0 ? +getGap() : 0);
    	  }
    
    	  cpCount++;
      }
    
      return new java.awt.Dimension(pw +ins.left +ins.right, ph +ins.top +ins.bottom);
    }
    
    
    public void setGap(int newGap) {
      gap = newGap;
    }
    
    
    public void setOrientation(int newOrientation) {
      orientation = newOrientation;
    }
    
    
    protected void showPopup(Container src){
      JPopupMenu popup = (JPopupMenu)popupHash.get(src);
      
      Point point = null;
      JRootPane rp = SwingUtilities.getRootPane(src);
    
      if(getOrientation()==HORIZONTAL){
    	 point = new Point(src.getSize().width -popup.getPreferredSize().width -1, rp.getSize().height > src.getLocation().y +popup.getPreferredSize().height
    		                                                                       ? src.getSize().height -1
    		                                                                       : -popup.getPreferredSize().height);
      }
      else{
    	   point = new Point(rp.getSize().width > src.getLocation().x +popup.getPreferredSize().width
    		                 ? src.getSize().width -1
    		                 : -popup.getPreferredSize().width, src.getSize().height -popup.getPreferredSize().height -1);
      }
    
      point = SwingUtilities.convertPoint(src, point, rp);
      popup.show(rp, point.x, point.y);
    }
}
