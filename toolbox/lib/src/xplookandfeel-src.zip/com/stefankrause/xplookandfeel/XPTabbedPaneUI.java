// Beta
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	XP Look and Feel														   *
*															                   *
*  (C) Copyright 2002, by Stefan Krause, Taufik Romdhane and Contributors      *
*                                                                              *
*                                                                              *
* The XP Look and Feel started as as extension to the Metouia Look and Feel.   *
* The original header of this file was:                                        *
** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*        Metouia Look And Feel: a free pluggable look and feel for java        *
*                         http://mlf.sourceforge.net                           *
*          (C) Copyright 2002, by Taoufik Romdhane and Contributors.           *
*                                                                              *
*   This library is free software; you can redistribute it and/or modify it    *
*   under the terms of the GNU Lesser General Public License as published by   *
*   the Free Software Foundation; either version 2.1 of the License, or (at    *
*   your option) any later version.                                            *
*                                                                              *
*   This library is distributed in the hope that it will be useful,            *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of             *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                       *
*   See the GNU Lesser General Public License for more details.                *
*                                                                              *
*   You should have received a copy of the GNU General Public License along    *
*   with this program; if not, write to the Free Software Foundation, Inc.,   *
*   59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.                    *
*                                                                              *
*   Original Author:  Taoufik Romdhane                                         *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


package com.stefankrause.xplookandfeel;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JComponent;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicTabbedPaneUI;

import com.stefankrause.xplookandfeel.skin.Skin;
import com.stefankrause.xplookandfeel.skin.SkinSimpleButtonIndexModel;

/**
 * This class represents the UI delegate for the JTabbedPane component.
 *
 * @author Taoufik Romdhane
 */
public class XPTabbedPaneUI extends BasicTabbedPaneUI {
	static Skin skinTop;
	static Skin skinLeft;
	static Skin skinRight;

	static Skin skinBottom;

	static Skin skinBorderBottom;
	static Skin skinBorderRight;

    SkinSimpleButtonIndexModel indexModel=new SkinSimpleButtonIndexModel();
	/**
	 * The outer highlight color of the border.
	 */
	private Color outerHighlight = XPDefaultTheme.tabbedPaneBorderColor; //XPLookAndFeel.getControlDisabled();

	/**
	 * The inner highlight color of the border.
	 */
	private Color innerHighlight = Color.green; //XPLookAndFeel.getPrimaryControlHighlight();

	/**
	 * The outer shadow color of the border.
	 */
	private Color outerShadow = Color.blue; //XPLookAndFeel.getControlDarkShadow();

	/**
	 * The inner shadow color of the border.
	 */
	private Color innerShadow = Color.PINK; //XPLookAndFeel.getDesktopColor();

	Color componentBackground = XPLookAndFeel.getControl();
	Color tabBackground = XPLookAndFeel.getLightControl();

	/**
	 * Creates the UI delegate for the given component.
	 *
	 * @param c The component to create its UI delegate.
	 * @return The UI delegate for the given component.
	 */
	public static ComponentUI createUI(JComponent c) {
		return new XPTabbedPaneUI();
	}

	int rollover = -1;

	protected void installListeners() {
		super.installListeners();
		tabPane.addMouseMotionListener((MouseMotionListener) mouseListener);
	}
	protected MouseListener createMouseListener() {
		return new MyMouseHandler();
	}
	private void ensureCurrentLayout() {
		if (!tabPane.isValid()) {
			tabPane.validate();
		}
		/* If tabPane doesn't have a peer yet, the validate() call will
		 * silently fail.  We handle that by forcing a layout if tabPane
		 * is still invalid.  See bug 4237677.
		 */
		if (!tabPane.isValid()) {
			TabbedPaneLayout layout = (TabbedPaneLayout) tabPane.getLayout();
			layout.calculateLayoutInfo();
		}
	}
	
	private int getTabAtLocation(int x, int y) {
		ensureCurrentLayout();

		int tabCount = tabPane.getTabCount();
		for (int i = 0; i < tabCount; i++) {
			if (rects[i].contains(x, y)) {
				return i;
			}
		}
		return -1;
	}
	
	public class MyMouseHandler implements MouseListener, MouseMotionListener {
		public void mousePressed(MouseEvent e) {
			if (!tabPane.isEnabled()) {
				return;
			}
			int tabIndex = getTabAtLocation(e.getX(), e.getY());
			if (tabIndex >= 0 && tabPane.isEnabledAt(tabIndex)) {
				if (tabIndex == tabPane.getSelectedIndex()) {
					if (tabPane.isRequestFocusEnabled()) {
						tabPane.requestFocus();
						tabPane.repaint(getTabBounds(tabPane, tabIndex));
					}
				} else {
					tabPane.setSelectedIndex(tabIndex);
				}
			}
		}
		public void mouseEntered(MouseEvent e) {
		}

		public void mouseExited(MouseEvent e) {
			if (rollover != -1) {
				tabPane.repaint(getTabBounds(tabPane, rollover));
				rollover = -1;
			}
		}

		public void mouseClicked(MouseEvent e) {
		}

		public void mouseReleased(MouseEvent e) {
		}

		public void mouseDragged(MouseEvent e) {
		}

		public void mouseMoved(MouseEvent e) {
			if (tabPane == null)
				return;
			if (!tabPane.isEnabled()) {
				return;
			}
			int tabIndex = getTabAtLocation(e.getX(), e.getY());
			if (tabIndex != rollover && rollover != -1) { // Update old rollover
				tabPane.repaint(getTabBounds(tabPane, rollover));
				if (tabIndex == -1)
					rollover = -1;
			}
			if (tabIndex >= 0 && tabPane.isEnabledAt(tabIndex)) {
				if (tabIndex == rollover) { // Paint new rollover
				} else {
					rollover = tabIndex;
					tabPane.repaint(getTabBounds(tabPane, tabIndex));
				}
			}
		}

	}

	/**
	 * Paints the backround of a given tab.
	 *
	 * @param g The graphics context.
	 * @param tabPlacement The placement of the tab to paint.
	 * @param tabIndex The index of the tab to paint.
	 * @param x The x coordinate of the top left corner.
	 * @param y The y coordinate of the top left corner.
	 * @param w The width.
	 * @param h The height.
	 * @param isSelected True if the tab to paint is selected otherwise false.
	 */
	protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) {
	}

	/**
	 * Paints the border of a given tab.
	 *
	 * @param g The graphics context.
	 * @param tabPlacement The placement of the tab to paint.
	 * @param selectedIndex The index of the selected tab.
	 */
	protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex) {
		int width = tabPane.getWidth();
		int height = tabPane.getHeight();
		Insets insets = tabPane.getInsets();

		int x = insets.left;
		int y = insets.top;
		int w = width - insets.right - insets.left;
		int h = height - insets.top - insets.bottom;

		// Trick: Need to paint one pixel in the corners!
		g.setColor(outerHighlight);

		switch (tabPlacement) {
			case LEFT :
				x += calculateTabAreaWidth(tabPlacement, runCount, maxTabWidth);
				w -= (x - insets.left);
				g.drawLine(x + 1, y, x + 1, y);
				break;
			case RIGHT :
				w -= calculateTabAreaWidth(tabPlacement, runCount, maxTabWidth);
				g.drawLine(x + w - 4, y, x + w - 4, y);
				break;
			case BOTTOM :
				h -= calculateTabAreaHeight(tabPlacement, runCount, maxTabHeight);
				g.drawLine(x, y + h - 4, x, y + h - 4);
				break;
			case TOP :
			default :
				y += calculateTabAreaHeight(tabPlacement, runCount, maxTabHeight);
				h -= (y - insets.top);
				g.drawLine(x, y + 1, x, y + 1);
		}
	}

	/**
	 * Draws the border around each tab.
	 *
	 * @param g The graphics context.
	 * @param tabPlacement The placement of the tabs.
	 * @param tabIndex The index of the tab to paint.
	 * @param x The x coordinate of the top left corner.
	 * @param y The y coordinate of the top left corner.
	 * @param w The width.
	 * @param h The height.
	 * @param isSelected True if the tab to paint is selected otherwise false.
	 */
	protected void paintTabBorder(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) {
		g.setColor(outerHighlight);        

        int index=indexModel.getIndexForState( tabPane.isEnabledAt(tabIndex), rollover == tabIndex, isSelected );

		switch (tabPlacement) {
			case LEFT :
				getSkinLeft().draw(g, index, x,y, w, h - 1);

				break;
			case RIGHT :
				getSkinRight().draw(g, index, x - 2, y,  w, h - 1);
				break;
			case BOTTOM :
				getSkinBottom().draw(g, index, x, y-2,  w - 1, h);

				break;
			case TOP :
			default :
				getSkinTop().draw(g, index, x, y,  w - 1, h);
		}
	}

	public void update(Graphics g, JComponent c) {
		int width = tabPane.getWidth();
		int height = tabPane.getHeight();
		Insets insets = tabPane.getInsets();

		int x = insets.left;
		int y = insets.top;
		int w = width - insets.right - insets.left;
		int h = height - insets.top - insets.bottom;
		if (c.isOpaque()) {
			g.setColor(componentBackground);
			g.fillRect(0, 0, c.getWidth(), c.getHeight());
		}
		int tabPlacement = tabPane.getTabPlacement();
		switch (tabPlacement) {
			case LEFT :
				x += calculateTabAreaWidth(tabPlacement, runCount, maxTabWidth);
				w -= (x - insets.left);
				break;
			case RIGHT :
				w -= calculateTabAreaWidth(tabPlacement, runCount, maxTabWidth);
				break;
			case BOTTOM :
				h -= calculateTabAreaHeight(tabPlacement, runCount, maxTabHeight);
				break;
			case TOP :
			default :
				y += calculateTabAreaHeight(tabPlacement, runCount, maxTabHeight);
				h -= (y - insets.top);
		}

		g.setColor(tabBackground);
		g.fillRect(x, y, w, h);

		g.setColor(outerHighlight);
		g.drawLine(x, y, x, y + h - 3); // left
		g.drawLine(x, y, x + w - 3, y); // top

		getSkinBorderRight().draw(g, 0, x + w - 3, y,  3, h);

		getSkinBorderBottom().draw(g, 0, x, y + h - 3,  w, 3);
		paint(g, c);
		
	}
	
    protected int getTabLabelShiftX(int tabPlacement, int tabIndex, boolean isSelected) {
        Rectangle tabRect = rects[tabIndex];
        int nudge = 0;
        switch(tabPlacement) {
          case LEFT:
              nudge = isSelected? -1 : 1;
              break;
          case RIGHT:
              nudge = isSelected? 1 : -1;
              break;
          case BOTTOM:
          case TOP:
          default:
              nudge = 0;
        }
        return nudge;
    }

    protected int getTabLabelShiftY(int tabPlacement, int tabIndex, boolean isSelected) {
        Rectangle tabRect = rects[tabIndex];
        int nudge = 0;
        switch(tabPlacement) {
           case BOTTOM:
              nudge = isSelected? 1 : -1;
              break;
          case LEFT:
          case RIGHT:
              nudge = tabRect.height % 2;
              break;
          case TOP:
          default:
              nudge = isSelected? -1 : 1;
        }
        return nudge;
    }
    

    public Skin getSkinTop()
    {
        if (skinTop==null) {
               skinTop=   new Skin("XPTabTop.res", 4, 3, 6, 3, 2);
        }
        return skinTop;
    }

    public Skin getSkinLeft()
    {
        if (skinLeft==null) {
               skinLeft=   new Skin("XPTabLeft.res", 4, 6, 3, 2, 3);
        }
        return skinLeft;
    }

    public Skin getSkinRight()
    {
        if (skinRight==null) {
               skinRight=   new Skin("XPTabRight.res", 4, 2, 3, 6, 3);
        }
        return skinRight;
    }

    public Skin getSkinBottom()
    {
        if (skinBottom==null) {
               skinBottom=   new Skin("XPTabBottom.res", 4, 3, 2, 3, 6);
        }
        return skinBottom;
    }

    public Skin getSkinBorderBottom()
    {
        if (skinBorderBottom==null) {
               skinBorderBottom=   new Skin("XPTabBordeBottom.res", 1, 3, 0, 3, 0);
        }
        return skinBorderBottom;
    }

    public Skin getSkinBorderRight()
    {
        if (skinBorderRight==null) {
               skinBorderRight=   new Skin("XPTabBorderRight.res", 1, 0, 3, 0, 3);
        }
        return skinBorderRight;
    }
        
        	
}