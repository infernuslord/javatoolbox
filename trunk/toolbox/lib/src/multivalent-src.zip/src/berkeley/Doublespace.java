package berkeley;

import multivalent.*;
import multivalent.node.Root;


/**
	BROKEN -- replaced by fine-grained reformatting.
	Doublespace text in entire document.
	Sets spaceabove on root structural context.

	LATER: three kinds of spacing: absolute, additive, max of settings.

	@version $Revision$ $Date$
*/
public class Doublespace extends Behavior {
  int spacing=0;
  int active;


  /**************************
   * PROTOCOLS
   **************************/

  public Doublespace() { active = 0; }

  static String spaceTitle[] = {
	  "Singlespace", "Space and a half", "Doublespace", "Triplespace"
  };
  /*
  public int countItems() { return spaceTitle.length; }
  public String getCategory(int id) { return "View"; }
  public Object getTitle(int id) { return spaceTitle[id]; }
  public int getType(int id) { return Valence.RADIOBOX; }
  public String getStatusHelp(int id) { return "Set linespaceing"; }
  */
  public void setActive(int id) {
	Browser br = getBrowser();
	active=id;
//	  if (xdoc!=null) xdoc.aswordscnt += (active==-1? -1: 1);

	spacing=0;

	switch (id) {
		case 0: spacing=0; break;
		case 1: spacing=6; break;
		case 2: spacing=12; break;
		case 3: spacing=24; break;
		default: assert false: id;
	}
	Root root = br.getRoot();
	space(root);
	root.markDirtySubtree(false);
	br.repaint();
  }


  // not updated on a rebuild
  void space(INode root) {
	Browser br = getBrowser();
	//((CLGeneral)br.getStyleSheet().get("ROOT")).setSpaceAbove(spacing);
	// => doesn't work anymore.  stupid anyhow.  do it with a span now
  }

  public void buildAfter(Document doc) {
	space(doc);
  }


/*
	public boolean checkDependencies(Vector vbe) {
	  // find Xdoc behavior, if any, for ugly hack
		for (int i=0; i<vbe.size(); i++) {
			if (vbe.elementAt(i) instanceof Xdoc) { xdoc=(Xdoc)vbe.elementAt(i); break; }
		}
		return true;
	}
*/
}
