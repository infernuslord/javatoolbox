package junitx.example.packageA;

import junit.framework.TestCase;

/**
 * @version $Revision: 1.1 $, $Date: 2003/02/05 10:34:22 $
 * @author <a href="mailto:vbossica@users.sourceforge.net">Vladimir R. Bossicard</a>
 */
public class SampleAJarTest extends TestCase {

    public SampleAJarTest(String name) {
        super(name);
    }

    public void testDummy1() {

    }

}
