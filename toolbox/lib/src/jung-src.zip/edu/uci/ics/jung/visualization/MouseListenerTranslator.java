/*
 * Created on Feb 17, 2004
 */
package edu.uci.ics.jung.visualization;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;

import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.visualization.PickSupport;

/**
 * This class translates mouse clicks into vertex clicks
 * 
 * @author danyelf
 */
public class MouseListenerTranslator extends MouseAdapter {

	private VisualizationViewer vv;
	private GraphMouseListener gel;

	/**
	 * @param gel
	 * @param vv
	 */
	public MouseListenerTranslator(GraphMouseListener gel, VisualizationViewer vv) {
		this.gel = gel;
		this.vv = vv;
	}
	
	/**
	 * Transform the point to the coordinate system in the
	 * VisualizationViewer, then use either PickSuuport
	 * (if available) or Layout to find a Vertex
	 * @param point
	 * @return
	 */
	private Vertex getVertex(Point2D point) {
	    // adjust for scale and offset in the VisualizationViewer
	    Point2D p = vv.inverseTransform(point);
	    PickSupport pickSupport = vv.getPickSupport();
	    Vertex v = null;
	    if(pickSupport != null) {
	        v = pickSupport.getVertex(p.getX(), p.getY());
	    } 
	    return v;
	}
	/**
	 * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
	 */
	public void mouseClicked(MouseEvent e) {
	    Vertex v = getVertex(e.getPoint());
		if ( v != null ) {
			gel.graphClicked(v, e );
		}
	}

	/**
	 * @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
	 */
	public void mousePressed(MouseEvent e) {
		Vertex v = getVertex(e.getPoint());
		if ( v != null ) {
			gel.graphPressed(v, e );
		}
	}

	/**
	 * @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
	 */
	public void mouseReleased(MouseEvent e) {
		Vertex v = getVertex(e.getPoint());
		if ( v != null ) {
			gel.graphReleased(v, e );
		}
	}
}
