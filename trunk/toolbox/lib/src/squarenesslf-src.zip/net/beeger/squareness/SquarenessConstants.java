/*
  Copyright (C) 2003-2004 Robert F. Beeger (robert at beeger dot net)
  Licensed under the Academic Free License version 2.0
  OSI Certified Open Source Software

  Visit http://squareness.sourceforge.net/ for new releases of Squareness Look And Feel and other
  skins from the Squareness series.
*/
package net.beeger.squareness;

/**
 * <p>This class contains all the constants used in this Look And Feel.</p>
 * <p>Currently only color name constants are used.</p>
 */
public interface SquarenessConstants
{
  //
  // public interface
  //

  static final String DESKTOP_COLOR_KEY = "desktop";
  static final String ACTIVE_CAPTION_COLOR_KEY = "activeCaption";
  static final String ACTIVE_CAPTION_TEXT_COLOR_KEY = "activeCaptionText";
  static final String ACTIVE_CAPTION_BORDER_COLOR_KEY = "activeCaptionBorder";
  static final String INACTIVE_CAPTION_COLOR_KEY = "inactiveCaption";
  static final String INACTIVE_CAPTION_TEXT_COLOR_KEY = "inactiveCaptionText";
  static final String INACTIVE_CAPTION_BORDER_COLOR_KEY = "inactiveCaptionBorder";
  static final String WINDOW_COLOR_KEY = "window";
  static final String WINDOW_BORDER_COLOR_KEY = "windowBorder";
  static final String WINDOW_TEXT_COLOR_KEY = "windowText";
  static final String MENU_COLOR_KEY = "menu";
  static final String MENU_TEXT_COLOR_KEY = "menuText";
  static final String TEXT_COLOR_KEY = "text";
  static final String TEXT_TEXT_COLOR_KEY = "textText";
  static final String TEXT_HIGHLIGHT_COLOR_KEY = "textHighlight";
  static final String TEXT_HIGHLIGHT_TEXT_COLOR_KEY = "textHighlightText";
  static final String TEXT_INACTIVE_TEXT_COLOR_KEY = "textInactiveText";
  static final String CONTROL_COLOR_KEY = "control";
  static final String CONTROL_TEXT_COLOR_KEY = "controlText";
  static final String CONTROL_HIGHLIGHT_COLOR_KEY = "controlHighlight";
  static final String CONTROL_LTHIGHLIGHT_COLOR_KEY = "controlLtHighlight";
  static final String CONTROL_SHADOW_COLOR_KEY = "controlShadow";
  static final String CONTROL_DKSHADOW_COLOR_KEY = "controlDkShadow";
  static final String SCROLLBAR_COLOR_KEY = "scrollbar";
  static final String INFO_COLOR_KEY = "info";
  static final String INFO_TEXT_COLOR_KEY = "infoText";
  static final String CONTROL_BORDER_COLOR_KEY = "controlBorderColor";
  static final String DEFAULT_BUTTON_BORDER_COLOR_KEY = "defaultButtonBorderColor";
  static final String DISABLED_CONTROL_BORDER_COLOR_KEY = "disabledControlBorderColor";
  static final String NORMAL_CONTROL_COLOR_KEY = "normalControlColor";
  static final String SELECTED_CONTROL_COLOR_KEY = "selectedControlColor";
  static final String SELECTED_CONTROL_SHADOW_COLOR_KEY = "selectedControlShadowColor";
  static final String PROGRESS_BAR_BACKGROUND_COLOR_KEY = "progressBarBackgroundColor";
  static final String SCROLLBAR_TRACK_PRESSED_COLOR_KEY = "scrollbarTrackPressedColor";

  static final String ROLLOVER_CLENT_PROPERTY_KEY = "SquarenessRollover";
  static final String SCROLLBAR_THUMB_PRESSED_CLIENT_PROPERTY_KEY = "SquarenessScrollBarThumbPressed";
  static final String SCROLLBAR_TRACK_PRESSED_CLIENT_PROPERTY_KEY = "SquarenessScrollBarTrackPressed";

  static final String SCROLL_ARROW_LEFT_KEY = "scrollArrowLeft";
  static final String SCROLL_ARROW_RIGHT_KEY = "scrollArrowRight";
  static final String SCROLL_ARROW_UP_KEY = "scrollArrowUp";
  static final String SCROLL_ARROW_DOWN_KEY = "scrollArrowDown";
  static final String SPIN_UP_KEY = "spinUp";
  static final String SPIN_DOWN_KEY = "spinDown";

  static final String CHECKED_FOR_JEDIT_ROLLOVER ="SquarenessCheckedJEDITROLLOVER";

}

/*
  $Log: SquarenessConstants.java,v $
  Revision 1.8  2004/03/08 17:21:05  rbeeger
  Added pressed scrollbar track effect.

  Revision 1.7  2004/03/04 19:01:40  rbeeger
  Simplyfied scroll bar ui delegate code.
  Began work on pressed scroll bar track painting.

  Revision 1.6  2004/03/03 19:55:50  rbeeger
  Added special handling of jEdit RolloverButtons

  Revision 1.5  2004/02/14 19:12:35  rbeeger
  Updated copyright statement
  Added cvs log directive at the end of each file
  Optimized imports
  Reformated code

 */
