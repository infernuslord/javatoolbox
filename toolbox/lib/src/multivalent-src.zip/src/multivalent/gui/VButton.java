package multivalent.gui;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.Map;

import multivalent.*;
import multivalent.node.IParaBox;

import multivalent.std.VScript;



/**
	Button widget: click to invoke the associated script (as given by SCRIPT attribute).
	Usable as button and menu item.

<!--
for comparison: AWT button
Public Methods
  X		addActionListener(ActionListener l)	Adds the specified action listener to receive action events from this button.
  SCRIPT	getActionCommand()	Returns the command name of the action event fired by this button.
  SCRIPT	removeActionListener(ActionListener l)	Removes the specified action listener so that it no longer receives action events from this button.
  SCRIPT	setActionCommand(String command)			Sets the command name for the action event fired by this button.
-->

	@version $Revision: 1.3 $ $Date: 2002/01/27 01:59:32 $
*/
public class VButton extends IParaBox implements EventListener {
  /** Cursor inside button, so that if release, execute. */
  private boolean inside_=false;


  public VButton(String name,Map<String,Object> attr, INode parent) { this(name,attr, parent, null); }
  public VButton(String name,Map<String,Object> attr, INode parent, String script) {
	super(name,attr, parent);
	if (script!=null) putAttr("script", script);
  }

  public boolean formatNode(int width,int height, Context cx) {
	super.formatNode(width/*Integer.MAX_VALUE--embedded table needs non-probe width*/,0/*0 to fake out HTML BODY.  height*/, cx);
	// tree nodes should have border built in, handled by Node.formatBeforeAfter()/paint()
	//bbox.setSize(bbox.width, bbox.height);
	baseline = bbox.height;// + border.top+border.bottom+padding.top+padding.bottom;     // not baseline of children, as box in line should not descend below baseline

	valid_ = true;
	return false;
  }

  public boolean breakBefore() { return false; }
  public boolean breakAfter() { return false; }


  public int dx() { return super.dx()+(inside_? 1: 0); }
  public int dy() { return super.dy()+(inside_? 1: 0); }


  public void paintNode(Rectangle docclip, Context cx) {
	super.paintNode(docclip, cx);
	if (!(getParentNode() instanceof VMenu)) {  // => nested selector in stylesheet
		Graphics2D g = cx.g;
		g.setColor(cx.foreground);
		g.draw3DRect(0-border.left-padding.left,0-border.top-padding.top, bbox.width-1,bbox.height-1, !inside_);
	}
  }


  public boolean eventNode(AWTEvent e, Point rel) {
	int eid=e.getID();
	Browser br = getBrowser();

	if (eid==MouseEvent.MOUSE_PRESSED) {
		br.setGrab(this);
		inside_ = true;
		repaint();
	}

	//return super.eventNode(e, rel); -- NO, opaque to children: function as a leaf
	br.setCurNode(this,-1);     // but take this from super.eventNode(e,rel)
//System.out.println("VButton "+getFirstLeaf().getName()+(eid!=TreeEvent.FIND_NODE));
	//return (eid!=TreeEvent.FIND_NODE);    // opaque to content
	return false;
	//return true;
  }


  public void event(AWTEvent e) {
	int eid=e.getID();
	Browser br = getBrowser();

	if (eid==MouseEvent.MOUSE_DRAGGED) {
		// could just compute location of button in screen cordinates in eventNode() and just compare bboxes here
		// => don't do it that way because may be inside lens

		br.getRoot().eventBeforeAfter(new TreeEvent(this, TreeEvent.FIND_NODE), br.getCurScrn());	// bypass grabs on Browser
		Node now = br.getCurNode();

		if (now!=null && contains(now) != inside_) { inside_=!inside_; repaint(); }

	} else if (eid==MouseEvent.MOUSE_RELEASED) {
		br.releaseGrab(this);

		if (inside_) invoke();
		inside_ = false;

		repaint();	// redraw after performed associated command
	}
  }


  /**
	Execute associated VScript, if any.
	VCheckbox and VRadiobox override to change state first.
  */
  public void invoke() {
//System.out.println(getName()+" invoking SCRIPT = "+getAttr(ATTR_SCRIPT)); //+", listeners="+listeners_);
	VScript.eval(getValue(ATTR_SCRIPT), getDocument(), getAttributes(), this);
  }
}
