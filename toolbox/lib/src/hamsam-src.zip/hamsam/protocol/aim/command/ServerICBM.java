/*
 *
 * Hamsam - Instant Messaging API
 *
 * Copyright (C) 2003 Mike Miller <mikemil@users.sourceforge.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 */

package hamsam.protocol.aim.command;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.List;

import hamsam.protocol.aim.util.TLV;
import hamsam.protocol.aim.util.ByteUtils;

/**
 * @author mikem
 */
public class ServerICBM extends Command {

    private static final int MSG_COOKIE_LEN = 8;
    private static final int TLV_MSG_DATA = 0x0002;
    private static final int TLV_MSG_TEXT = 0x0101;

    // this plus the screen name length should point to the beginning of the TLVs
    private static final int TLV_PARTIAL_OFFSET = MSG_COOKIE_LEN + 7;

    private byte[] msgCookie;
    private short msgChannel;
    private byte screenNameLength;
    private String screenName;
    private short senderWarningLevel;
    private short tlvCount;
    private List tlvList;

    public ServerICBM(Command cmd) {
        flapHdr = cmd.getFlapHdr();
        snacPacket = cmd.getSNAC();
        byte[] data = cmd.getSNACData();

        msgCookie = new byte[MSG_COOKIE_LEN];
        System.arraycopy(data, 0, msgCookie, 0, MSG_COOKIE_LEN);

        msgChannel = (short)ByteUtils.getUShort(data, MSG_COOKIE_LEN);
        screenNameLength = data[MSG_COOKIE_LEN + 2];
        screenName = new String(data, MSG_COOKIE_LEN + 3, screenNameLength);

        senderWarningLevel = (short)ByteUtils.getUShort(data, MSG_COOKIE_LEN + 3 + screenNameLength);
        tlvCount = (short)ByteUtils.getUShort(data, MSG_COOKIE_LEN + 5 + screenNameLength);

        // compute tlv offset and the rest is TLVs
        int tlvOffset = TLV_PARTIAL_OFFSET + screenNameLength;
        tlvList = TLV.getTLVs(data, tlvOffset);

    }

    public String getMessageText() {
        String msg = null;
        if (tlvList != null && !tlvList.isEmpty()) {
            outer : for (Iterator iter = tlvList.iterator(); iter.hasNext();) {
                TLV tlv = (TLV)iter.next();
                if (tlv.getType() == TLV_MSG_DATA) {
                    byte[] innerTlvs = tlv.getValue();
                    List list = TLV.getTLVs(innerTlvs, 0);
                    if (list != null && !list.isEmpty()) {
                        for (Iterator iterator = list.iterator(); iterator.hasNext();) {
                            TLV element = (TLV)iterator.next();
                            if (element.getType() == TLV_MSG_TEXT) {
                                byte[] temp = element.getValue();
                                byte[] text = new byte[temp.length-4];
                                System.arraycopy(temp, 4, text, 0, temp.length - 4);
                                msg = new String(text);
                                break outer;
                            }
                        }
                    }
                }
            }
        }
        return msg;
    }

    /* (non-Javadoc)
     * @see hamsam.protocol.aim.command.Command#writeCommandData(java.io.OutputStream)
     */
    public void writeCommandData(OutputStream os) throws IOException {
        // nothing to write - we receive this message/command
    }

}
