/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	Tiny Look and Feel                                                         *
*                                                                              *
*  (C) Copyright 2003, Hans Bickel                                             *
*                                                                              *
*   For licensing information and credits, please refer to the                 *
*   comment in file de.muntjak.tinylookandfeel.TinyLookAndFeel                 *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package de.muntjak.tinylookandfeel;

import java.awt.*;

import javax.swing.JComponent;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicMenuBarUI;

/**
 * TinyMenuBarUI
 * 
 * @version 1.0
 * @author Hans Bickel
 */
public class TinyMenuBarUI extends BasicMenuBarUI {
	
  /**
   * Creates the UI delegate for the given component.
   * Because in normal application there is usually only one menu bar, the UI
   * delegate isn't cached here.
   *
   * @param mainColor The component to create its UI delegate.
   * @return The UI delegate for the given component.
   */
  public static ComponentUI createUI(JComponent c)
  {
  	// first five pixels free
  	c.setBorder(new EmptyBorder(0,5,0,0 ));
    return new TinyMenuBarUI();
  }

  /**
   * Paints the menu bar background.
   *
   * @param g The graphics context to use.
   * @param mainColor The component to paint.
   */
  public void paint(Graphics g, JComponent c)
  {
	  g.setColor(Theme.menuBarColor[Theme.style].getColor());
	  g.fillRect(0, 0, c.getWidth() - 1, c.getHeight() - 1);
  }
}