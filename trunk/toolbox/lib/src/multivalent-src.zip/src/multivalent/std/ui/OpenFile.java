package multivalent.std.ui;

import javax.swing.JFileChooser;

import multivalent.*;



/**
	Browse a file on the local file system, as chosen by a Swing JFileChooser.

	@version $Revision: 1.2 $ $Date: 2002/02/01 07:14:20 $
*/
public class OpenFile extends Behavior {
  /**
	Request opening file from local file system, as choen by a Swing JFileChooser.
	<p><tt>"openFile"</tt>.
  */
  public static final String MSG_OPEN = "openFile";


  static JFileChooser jc = null;	// static OK because modal -- create on demand


  public boolean semanticEventAfter(SemanticEvent se, String msg) {
	if (MSG_OPEN==msg) {
		// LATER: arg gives default, else last opened file (getPreference("HOME") for first)
		/*
		String content = typein.getContent();
		File filein = (content.length()<=1? null: new File(content));
		if (filein==null) jc.setCurrentDirectory(null);
		else if (filein.exists()) jc.setCurrentDirectory(filein.isDirectory()? filein: filein.getParentFile());
		*/

		Browser br = getBrowser();	// Browser is a Component
		if (jc==null) jc = new JFileChooser();

//System.out.println("calling "+jc);
		if (br!=null && jc.showOpenDialog(br) == JFileChooser.APPROVE_OPTION) {
			// set type to initial file
//System.out.println("setting typein content to "+jc.getSelectedFile());
			//if (typein!=null) typein.setContent(jc.getSelectedFile().toString());
			br.eventq(Document.MSG_OPEN, jc.getSelectedFile().toURI());
		}
		return true;
	}
	return false;
  }
}
