package tool.html;

import java.util.*;
import java.util.Map.Entry;
import java.net.URL;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.io.BufferedInputStream;

import multivalent.*;
import multivalent.node.*;
import multivalent.std.adaptor.HTML;

import phelps.net.URIs;



/**
	OUT OF DATE.
	Perfect your HTML correct automatically!  Cleans up mismatched tags, updates deprecated tags
	to modern usage, optionally writes XHTML, and more.
	Also, make your URLs robust: See <a href="util.RobustHyperlink">RobustHyperlink</a>.

	Documentation at web site, under "Tools".

	<!--
	To do:
	upon reading, translate relative links to absolute; on saving, absolute to relative
	minimizer save mode that writes out minimum text to render page (no comments, no whitespace, drop tags where implied)

	strip out bogus tags and attributes, such as those introduced by Microsoft Word

TagSoup
Run as an application, this class can dump
out the clean parse, optionally pretty printed, optionally making
hyperlinks robust, optionally writing XHTML, and other
transformations.
	-->

	@version $Revision: 1.3 $ $Date: 2003/06/01 07:39:48 $
*/
public class Massage {
  static final boolean DEBUG = true;

  static final String USAGE = "java tool.html.Massage [-xhtml] <url> <file>";
  public static final String VERSION = "0.1";



  static boolean fXHTML = false;
  static boolean fUsability = false;
  static int linestart=0;

  static void indent(int level, StringBuffer sb) {
	sb.append("\n");
	linestart = sb.length();
	for (int i=0,imax=level; i<imax; i++) sb.append("  ");
  }

  static void emitTagStart(String name, Iterator<Map.Entry<String,Object>> entrySetIterator, boolean empty, int level, StringBuffer sb) {
	if (fXHTML) name = name.toLowerCase();
	sb.append('<').append(name);

	if (entrySetIterator!=null) {
		int curcol = sb.length()-linestart;
		while (entrySetIterator.hasNext()) {
			Map.Entry<String,Object> keyval = entrySetIterator.next();
			String key=keyval.getKey(), val=(String)keyval.getValue();
			if (fXHTML) key=key.toLowerCase();	// already normalize to this


			int attrlen = 2 + key.length() + (val.equals(name)? 0: 2+val.length()+1);
			if (curcol+attrlen>BreakAt && level*2+attrlen<BreakAt-15) { indent(level, sb); curcol=0; }

			sb.append("  ").append(key);
			if (fXHTML && val==null) val=key;	// unminimize attrs
			if (val!=null) sb.append("=\"").append(val/*encode*/).append("\"");
			curcol += attrlen;
		}
	}

	if (fXHTML && empty) sb.append(" /");
	sb.append('>');
  }


  static void emitTagEnd(String name, int level, StringBuffer sb) {
	if (fXHTML) name = name.toLowerCase();
	sb.append("</").append(name).append('>');
  }


  static int BreakAt = 75;
  //List<Span> spans = new LinkedList<Span>();
  public static String walk(Node htmlroot) {
	StringBuffer sb = new StringBuffer(100000);

	if (fXHTML) {
		sb.append(
		"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
		"<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"\n" +
		"\t\"http://www.w3.org/TR/1999/PR-xhtml1-19991210/DTD/xhtml1-strict.dtd\">\n");

		htmlroot.putAttr("xmlns", "http://www.w3.org/1999/xhtml");
		//htmlroot.putAttr("xml:lang","en"); htmlroot.putAttr("lang","en");
	}

	walkAux(htmlroot, -1, sb, true, new LinkedList<Span>());
	return sb.substring(0);
  }

  public static boolean walkAux(Node n, int level, StringBuffer sb, boolean laststruct, List<Span> spans) {
	String name = n.getName();

	if (n instanceof LeafText) {
		if (fXHTML && laststruct) {  // nest re-start prevailing spans
			for (Iterator<Span> i=spans.iterator(); i.hasNext(); ) { Span r=i.next(); emitTagStart(r.getName(), r.attrEntrySetIterator(), false, level, sb); }
		}

		// format content + handle span transitions
		if (!laststruct) sb.append(' ');

		boolean verbose = false; //"Directions".equals(name) || "RESIDU".equals(name) || "research".equals(name) || "A".equals(name) || "Services".equals(name);
		//List<> sticky = n.sticky_;
//		if (sticky!=null) sb.append("\n").append(n.sticky_.toString());
//if (verbose) System.out.println(n.getName()+", sticky="+sticky);
		int start=0, imax=n.sizeSticky(), jmax=0;
		if (sb.length() - linestart + name.length() + 5*imax > BreakAt) indent(level, sb);
		for (int i=0; i<imax; i=jmax) {
			Mark m = n.getSticky(i); if (!(m.getOwner() instanceof Span)) continue;
			int x = m.offset;
if (verbose) System.out.println(name+" x @ "+x);

			// piece up to transition
			if (x>start) { sb.append(name.substring(start,x)); start=x; }

			// find run of transitions at this point (often just one)
			for (jmax=i+1; jmax<imax; jmax++) if (n.getSticky(jmax).offset!=x) break;

			// traverse all close tags first, back to front
if (verbose) System.out.println("closing tags "+jmax+".."+(jmax-1));
			for (int j=jmax-1; j>=i; j--) {
				m = n.getSticky(j); if (!(m.getOwner() instanceof Span)) continue;
				Span r = (Span)m.getOwner();
				if (m==r.getEnd()) {
					spans.remove(r);
					emitTagEnd(r.getName(), level, sb);
				}
if (verbose) System.out.println("closed "+r.getName()+"? "+(m==r.getEnd()));
			}

			// now open tags, front to back
			for (int j=i; j<jmax; j++) {
				m = n.getSticky(j); if (!(m.getOwner() instanceof Span)) continue;
				Span r = (Span)m.getOwner();
				if (m==r.getStart()) {
					spans.add(r);
					emitTagStart(r.getName(), r.attrEntrySetIterator(), false, level, sb);	  // XHTML does this on demand
				}
			}
		}
		if (n.size() > start) sb.append(name.substring(start));
		laststruct=false;
		//if (sb.length() - linestart > BreakAt) { indent(level, sb); laststruct=true; }

	} else if (n.isStruct()) {
		// emit node
		indent(level, sb);

		if (name!=null) {
			emitTagStart(name, n.attrEntrySetIterator(), false, level, sb);
			laststruct=true;
		}

		// recurse over children
		INode p = (INode)n;
		for (int i=0,imax=p.size(); i<imax; i++) laststruct = walkAux(p.childAt(i), level+(name!=null?1:0), sb, laststruct, spans);

		// nest: suspend prevailing spans
		if (fXHTML && !laststruct) {
			for (Iterator<Span> i=spans.iterator(); i.hasNext(); ) { Span r=i.next(); emitTagEnd(r.getName(), level, sb); }
		}

		if (laststruct) indent(level, sb);
		if (name!=null) {
			emitTagEnd(name, level, sb);
			laststruct=true;
		}

	} else if (HTML.TAGTYPE_EMPTY==HTML.getParseType(name)) {	// OK to use == rather than .equals() here
		indent(level, sb);
		emitTagStart(name, n.attrEntrySetIterator(), true, level, sb);
		// could do more special casing for tags here
		laststruct=true;

	} // else shouldn't happen

	return laststruct;
  }


  static void error(String msg) {
	System.err.println(msg);
	System.exit(1);
  }


  public static void main(String[] argv) {
	//Browser br = new Browser(null, "BOGUS", false);
	//Layer shim = new Layer("SHIM", doc, Color.BLACK);
	HTML html = new HTML();
	boolean robust=false, force=false, prettyprint=false, stdout=true, verbose=true;//false

	int argi=0, argc=argv.length;
	boolean err=false;
	for ( ; argi<argc && argv[argi].startsWith("-"); argi++) {
		String opt=argv[argi].toLowerCase();	// used to have .substring(1) to chop off initial "-", but code easier to read with "-" in each string
		if ("-xhtml".equals(opt)) { fXHTML = true; }
		else if ("-robust".equals(opt)) robust=true;
		else if ("-prettyprint".equals(opt)) prettyprint=true;
		else if ("-usablity".equals(opt)) fUsability=true;
		else if ("-perfect".equals(opt)) { fXHTML=robust=prettyprint=fUsability=force=true; }
		else if ("-stdout".equals(opt)) { stdout=true; }

		else if (opt.startsWith("-verb"/*ose*/)) {}
		else if (opt.startsWith("-q"/*uiet*/)) {}
		else if (opt.startsWith("-v"/*ersion--after "verbose"*/)) { System.out.println(VERSION); System.exit(0); }
		else if ("-help".equals(opt)) { System.out.println(USAGE); System.exit(0); }
		else error(USAGE);
	}


	// validate URL
	URI uri=null;
	try {
		uri = new URI(new URL(html.getClass().getResource("HTML.class"), argv[argi]).toString());
	} catch (MalformedURLException male) {
		error(male.toString());
	} catch (URISyntaxException male) {
	}

	if (err || argi==argc) { System.err.println(USAGE); System.exit(1); }



	// build tree
	Root root = new Root(null, null);
	Document doc = new Document(null, null, root);
	INode htmlroot = null;
	try {
		html.docURI = uri;
		html.setInputStream(new BufferedInputStream(URIs.toURL(uri).openStream()));
		htmlroot = (INode)html.parse(doc);
	} catch (Exception e) { error(e.toString()); System.exit(1); }

	// walk tree
//	html.spans.clear(); // for HTML, just report transitions as you see them, but for XHTML have to end and begin within structural bounds

	String treedump = walk(htmlroot);
	//root.dump();

	System.out.println(treedump);

	System.exit(0);
  }
}
