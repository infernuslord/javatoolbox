/*
 * Hamsam - Instant Messaging API
 * Copyright (C) 2003 Raghu K
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package hamsam.api;

import java.io.Serializable;
import java.util.Vector;
import java.util.Enumeration;

/**
 * An instant message.
 *
 * Instant messages contain not only plain text messages, but various
 * other things such as URLs, font and color variations, smileys etc.
 * Unfortunately, different protocols use different encoding schemes for
 * sending instant messages. This class provides an implementation
 * independent way of representing instant messages, so that users
 * of Hamsam library do not have to worry about proprietory message
 * formats.
 *
 * <p>
 * Each message object contains a sequence of message components. Each
 * message component will be one of the following.
 *
 * <p>
 * <h3>1. TextComponent</h3>
 * A text component contains a sequence of characters that represent a message.
 * This sequence, together with the font and color information, determines what
 * to display to the user.
 *
 * <p>
 * <h3>2. SmileyComponent</h3>
 * This is a small picture, sometimes referred to as an emoticon, used to represent
 * a user's emotions. For each smiley, there will be an alternate text representation.
 * For clients that don't want to display smileys, may use this text representation.
 *
 * <p>
 * <h3>3. URLComponent</h3>
 * A URL is special in that clients may want to show it as a "web link" rather than
 * plain text. The URL component allows this by providing a link text and link URL.
 * The link text is a text component that needs to be displayed to the user, while
 * the link URL is a URL to which the user may connect to.
 *
 * <p>
 * All the message components mentioned above are inherited from the
 * {@link MessageComponent MessageComponent} interface. You can use these components
 * in an {@link IMListener IMListener} as shown below.
 *
 * <p>
 * <code>
 * public void instantMessageReceived(Buddy buddy, Message message)
 * {
 * 	Enumeration e = message.getComponents();
 * 	while(e.hasMoreElements())
 * 	{
 * 		MessageComponent comp = (MessageComponent) e.nextElement();
 * 		if(comp instanceof TextComponent)
 * 		{
 * 			// handle text component
 * 		}
 * 		else if(comp instanceof SmileyComponent)
 * 		{
 * 			// handle smiley component
 * 		}
 * 		else if(comp instanceof URLComponent)
 * 		{
 * 			// handle URL component
 * 		}
 * 	}
 * }
 * </code>
 *
 * @author Raghu
 */
public class Message implements Serializable
{
	/**
	 * This vector holds all the mesage components.
	 */
	private Vector componentVector;

	/**
	 * Default constructor.
	 */
	public Message()
	{
		componentVector = new Vector();
	}

	/**
	 * Add a message component to this message.
	 *
	 * @param comp the component to be added.
	 */
	public void addComponent(MessageComponent comp)
	{
		componentVector.add(comp);
	}

	/**
	 * Returns an enumeration of the components of this message. The returned
	 * Enumeration object will generate all message components in this message.
	 *
	 * @return an enumeration of the message components of this message.
	 * @see MessageComponent MessageComponent
	 */
	public Enumeration getComponents()
	{
		return componentVector.elements();
	}
}
