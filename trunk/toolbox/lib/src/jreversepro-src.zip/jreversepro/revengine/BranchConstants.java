/*
 * @(#)BranchConstants.java
 *
 * JReversePro - Java Decompiler / Disassembler.
 * Copyright (C) 2000 2001 Karthik Kumar.
 * EMail: akkumar@users.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it , under the terms of the GNU General   License as published
 * by the Free Software Foundation; either version 2 of the License,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General   License for more details.
 * You should have received a copy of the GNU General   License
 * along with this program.If not, write to
 *  The Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330,
 *  Boston, MA 02111-1307, USA.
 */
package jreversepro.revengine;

public interface BranchConstants {
    //Constants for JBranchTable

    int TYPE_INVALID = -1;
    int TYPE_NORMAL = 0;
    int TYPE_AUTO = 1;
    int TYPE_GOTO = 2;
    int TYPE_BRANCH = 3;
    int TYPE_JSR = 4;
    int TYPE_RET = 5;

    int TYPE_IF =  12;
    int TYPE_ELSE =  13;
    int TYPE_ELSE_IF = 14;
    int TYPE_WHILE = 15;
    int TYPE_DO_WHILE = 16;
    int TYPE_TRY = 17;
    int TYPE_TRY_ANY = 18;
    int TYPE_CATCH = 19;
    int TYPE_CATCH_ANY = 20;
    int TYPE_SYNC = 21;
    int TYPE_SWITCH = 22;
    int TYPE_CASE = 23;

    int TARGET_INVALID = -1;
}
