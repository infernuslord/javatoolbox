/**
  * @(#)JBranchEntry.java
  *
  *
  * JReversePro - Java Decompiler / Disassembler.
  * Copyright (C) 2000 2001 Karthik Kumar.
  * EMail: akkumar@users.sourceforge.net
  *
  * This program is free software; you can redistribute it and/or modify
  * it , under the terms of the GNU General Public License as published
  * by the Free Software Foundation; either version 2 of the License,
  * or (at your option) any later version.
  *
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  * See the GNU General Public License for more details.
  * You should have received a copy of the GNU General Public License
  * along with this program.If not, write to
  *  The Free Software Foundation, Inc.,
  *  59 Temple Place - Suite 330,
  *  Boston, MA 02111-1307, USA.
  **/
package jreversepro.revengine;

import jreversepro.common.KeyWords;
import jreversepro.common.Helper;
import jreversepro.runtime.JOperandStack;
import jreversepro.runtime.JCodeBuffer;
import jreversepro.runtime.Operand;
import jreversepro.runtime.OperandConstants;
import java.util.Map;

/**
 * JBranchEntry refers to a single conditional BranchEntry only.
 * @author Karthik Kumar
 * @version 1.3
 **/
public class JBranchEntry implements KeyWords,
                                     BranchConstants,
                                     OperandConstants {
    int StartPc;
    int TargetPc;
    int NextPc;

    int Type;
    //Possible values.  TYPE_WHILE || TYPE_IF.

    String Opr1;
    String Opr2;
    String Operator;

    boolean written;

    public JBranchEntry( int StartPc, int TargetPc, int Type ) {
        this(StartPc, StartPc, TargetPc, Type, "", "", "" );
        if ( Type == TYPE_JSR ) {
            StartPc = TargetPc;
        }
        written = false;
    }

    public JBranchEntry( int StartPc, int NextPc, int TargetPc,
                        int Type,
                        String Opr1, String Opr2,
                        String Operator ) {

        this.StartPc  = StartPc;
        this.NextPc  = NextPc;
        this.TargetPc  = TargetPc;


        this.Type = Type;

        this.Opr1 = Opr1;
        this.Opr2 = Opr2;
        this.Operator = Operator;
    }

    public void setWrittenFlag() {
        written = true;
    }

    public void resetWrittenFlag() {
        written = false;
    }

    public final boolean isWhile() {
        return (StartPc > TargetPc);
    }

    public final int getStartPc() {
        return StartPc;
    }

    public final int getTargetPc() {
        return TargetPc;
    }

    public final int getNextPc() {
        return NextPc;
    }

    public final int getType() {
        return Type;
    }

    public String getOpr1() {
        return Opr1;
    }

    public void setNextPc( int NextPc) {
        this.NextPc = NextPc;
    }

    public void setTargetPc( int TargetPc) {
        this.TargetPc = TargetPc;
    }

    public void setStartPc( int StartPc) {
        this.StartPc = StartPc;
    }

    public void setType(int Type) {
        this.Type = Type;
    }

    public void setOpr1 ( String Opr1 ) {
        this.Opr1 = Opr1;
    }

    public void setOpr2 ( String Opr2) {
        this.Opr2 = Opr2;
    }

    public void convertToWhile() {
        setType( TYPE_WHILE );

        //Swap targetPc and NextPc.
        int temp = TargetPc;
        TargetPc = NextPc;
        NextPc = temp;
   }

    public void complementOperator() {
        Operator = getComplementOperator(Operator);
    }

    public final boolean doesStartWith(int RhsStartPc )
        throws RevEngineException {
        if ( Type == TYPE_INVALID ) return false;
//        if ( Type == TYPE_TRY_ANY ) return false;
        return getStartBlockPc() == RhsStartPc ;
    }

    public boolean independent() {
        return Type == TYPE_IF || Type == TYPE_WHILE ||
                Type == TYPE_TRY || Type == TYPE_DO_WHILE ||
                Type == TYPE_SYNC || Type == TYPE_SWITCH ||
                Type == TYPE_CASE || Type == TYPE_TRY_ANY;
    }

    public final boolean doesContain ( int aPc )
            throws RevEngineException {
        return ( getStartBlockPc() <= aPc &&
                    getEndBlockPc() >= aPc );
    }

    public final int getStartBlockPc()
            throws RevEngineException {
        switch(Type) {
            case TYPE_IF:
            case TYPE_ELSE:
            case TYPE_ELSE_IF:
            case TYPE_TRY:
            case TYPE_TRY_ANY:
            case TYPE_CATCH:
            case TYPE_CATCH_ANY:
            case TYPE_JSR:
            case TYPE_SYNC:
            case TYPE_SWITCH:
            case TYPE_CASE:
            case TYPE_WHILE:
                return StartPc;
//            case TYPE_WHILE:
            case TYPE_DO_WHILE:
                return TargetPc;
            default:
                throw new RevEngineException("Invalid Branch Entry");
        }
    }

    public final int getEndBlockPc()
            throws RevEngineException {
        switch(Type) {
            case TYPE_IF:
            case TYPE_ELSE:
            case TYPE_ELSE_IF:
            case TYPE_TRY:
            case TYPE_TRY_ANY:
            case TYPE_CATCH:
            case TYPE_CATCH_ANY:
            case TYPE_JSR:
            case TYPE_SYNC:
            case TYPE_CASE:
            case TYPE_SWITCH:
                return TargetPc;
            case TYPE_WHILE:
            case TYPE_DO_WHILE:
                return NextPc;
            default:
                throw new RevEngineException("Invalid Branch Entry ");
        }
    }

    public final int getStartExecPc()
            throws RevEngineException {
        switch(Type){
            case TYPE_IF:
            case TYPE_ELSE:
            case TYPE_ELSE_IF:
            case TYPE_TRY:
            case TYPE_TRY_ANY:
            case TYPE_CATCH:
            case TYPE_CATCH_ANY:
            case TYPE_JSR:
            case TYPE_SYNC:
            case TYPE_CASE:
            case TYPE_SWITCH:
                return NextPc;
            case TYPE_WHILE:
            case TYPE_DO_WHILE:
                return TargetPc;
            default:
                throw new RevEngineException("Invalid Branch Entry");
        }
    }

    public final void appendStartBlockStmt(JCodeBuffer cb ) {
        Helper.log( "Branch Begins " + this );
        if ( !( Type == TYPE_CATCH_ANY ||
                Type == TYPE_TRY_ANY ) ) {
            switch(Type) {
                case TYPE_IF:
                    String Expr = getExpression();
                    cb.addLine("if ( "  + Expr + " ) {", false );
                    break;
                case TYPE_ELSE_IF:
                    cb.addLine("else if ( "  + getExpression() +  " ) {", false);
                    break;
                case TYPE_ELSE :
                    cb.addLine("else { ", false );
                    break;
                case TYPE_WHILE:
                    cb.addLine("for ( ;"  + getExpression() + "; ) {", false);
                    break;
                case TYPE_DO_WHILE:
                    cb.addLine("do { ", false );
                    break;
                case TYPE_TRY:
                    cb.addLine("try { ", false );
                    break;
                case TYPE_CATCH:
                    cb.addLine("catch ( " + Opr1 + "  " + Opr2 + "  )  {", false );
                    break;
                case TYPE_JSR:
                    cb.addLine("finally {", false );
                    break;
                case TYPE_SYNC:
                    cb.addLine("synchronized(" + Opr1 + ") {", false);
                    break;
                case TYPE_CASE:
                    cb.addCaseStatements( Opr1 );
                    break;
                case TYPE_SWITCH:
                    cb.addLine("switch (" + Opr1 + ") {", false );
                    break;
                default:
            }
            cb.incDepth();
        }
    }

    public final void appendStartBlockStmtX(JCodeBuffer cb ) {
        Helper.log( "Branch Begins " + this );
        if ( !( Type == TYPE_CATCH_ANY ||
                Type == TYPE_TRY_ANY ) ) {
            switch(Type) {
                case TYPE_IF:
                    String Expr = getExpression();
                    cb.addLine("if ( "  + Expr + " )", false);
                    break;
                case TYPE_ELSE_IF:
                    cb.addLine("else if ( "  + getExpression() +  " )", false);
                    break;
                case TYPE_ELSE :
                    cb.addLine("else", false);
                    cb.addLine("{", false);
                    cb.incDepth();
                    break;
                case TYPE_WHILE:
                    cb.addLine("for ( ;"  + getExpression() + "; )", false);
                    break;
                case TYPE_DO_WHILE:
                    cb.addLine("do", false);
                    cb.addLine("{", false);
                    cb.incDepth();
                    break;
                case TYPE_TRY:
                    cb.addLine("try", false);
                    cb.addLine("{", false);
                    cb.incDepth();
                    break;
                case TYPE_CATCH:
                    cb.addLine("catch ( " + Opr1 + "  " + Opr2 + "  )", false);
                    cb.addLine("{", false);
                    cb.incDepth();
                    break;
                case TYPE_JSR:
                    cb.addLine("finally", false );
                    cb.addLine("{", false);
                    cb.incDepth();
                    break;
                case TYPE_SYNC:
                    cb.addLine("synchronized(" + Opr1 + ")", false);
                    cb.addLine("{", false);
                    cb.incDepth();
                    break;
                case TYPE_CASE:
                    cb.addCaseStatements( Opr1 );
                    cb.incDepth();
                    break;
                case TYPE_SWITCH:
                    cb.addLine("switch (" + Opr1 + ")", false);
                    cb.addLine("{", false);
                    cb.incDepth();
                    break;
                default:
            }
        }
    }

    public final void appendStartBlockCharX(JCodeBuffer cb ) {
        if ( !( Type == TYPE_CATCH_ANY ||
                Type == TYPE_TRY_ANY ) ) {
            switch(Type) {
                case TYPE_IF:
                case TYPE_ELSE_IF:
                case TYPE_WHILE:
                    cb.addLine("{", false);
                    cb.incDepth();
                    break;
                case TYPE_ELSE :
                case TYPE_DO_WHILE:
                case TYPE_TRY:
                case TYPE_CATCH:
                case TYPE_JSR:
                case TYPE_SYNC:
                case TYPE_CASE:
                case TYPE_SWITCH:
                    break;
                default:
            }
        }
    }

    public final boolean appendEndBlockStmt(JCodeBuffer cb,
                                        JOperandStack jos ) {
        boolean mergeStack = false;
        if ( !( Type == TYPE_CATCH_ANY ||
                Type == TYPE_TRY_ANY ) ) {
            Helper.log( "Branch Ends " + this );
            cb.decDepth();
            switch(Type) {
                case TYPE_IF:
                    if ( written ) {
                        cb.addLine("}", false);
                    } else if ( !jos.empty() ) {
                        cb.rollback("if");
                        Operand op1 = (Operand)jos.pop();
                        String Expr = getExpression();
                        jos.push(new Operand(
                            "(" + Expr + ") ? " + op1.getValueEx(L_TERN) + " : ",
                            op1.getDatatype(), L_TERN));
                    } else {
                        cb.addLine("}", false );
                    }
                    break;
                case TYPE_ELSE:
                    if ( written ) {
                        cb.addLine("}", false);
                    } else {
                        if ( !jos.empty() ) {
                            cb.rollback("else");
                        }
                        mergeStack = true;
                    }
                    break;
                case TYPE_TRY:
                case TYPE_ELSE_IF:
                case TYPE_WHILE:
                case TYPE_JSR:
                case TYPE_SYNC:
                case TYPE_CATCH:
                case TYPE_SWITCH:
                case TYPE_CASE:
                    cb.addLine("}", false);
                    break;
                case TYPE_DO_WHILE:
                    cb.addLine("} while ( "  + Opr1 + " " +  Operator +
                                " " + Opr2 + " )", false );
                    break;
                default:
            }
        }
        return mergeStack;
    }

    public void rewriteCondition(JBranchEntry NextEntry,
                            String ConditionType,
                            boolean Complement ) {
        Opr1 = this.getCondition(Complement);
        Operator = ConditionType;
        Opr2 = NextEntry.getCondition(true);
    }


    public void setEndBlockPc( int aNewPc) {
        switch(Type) {
            case TYPE_IF:
            case TYPE_ELSE:
            case TYPE_ELSE_IF:
            case TYPE_TRY:
            case TYPE_TRY_ANY:
            case TYPE_CATCH:
            case TYPE_CATCH_ANY:
            case TYPE_JSR:
            case TYPE_SYNC:
            case TYPE_CASE:
            case TYPE_SWITCH:
                TargetPc = aNewPc;
                break;
            case TYPE_WHILE:
            case TYPE_DO_WHILE:
                NextPc = aNewPc;
                break;
        }
    }


     /**
        * Given the index to the entry in the BranchTable , this
        * returns the condition .
        * <p>
        * For example , if an entry has <br>
        * <code>4:  i  3 !=  </code> .<br>
        * Then <code>getCondition(4,true)</code> yields
        * <code>i != 3 </code>  and <br>
        * <code>getCondition(4,false)</code> yields
        * <code>i == 3 </code></p> .
        */
    private String getCondition(boolean Complement ){
        if( !Complement) {
            Operator = getComplementOperator(Operator);
        }
        return getExpression();
    }



     /**
    * Returns the complementary operator of the given operator.
    * <p>
    * @param  Rhs  Operator
    * @return the complementary operator of <code>Rhs</code>
    */
    private String getComplementOperator( String Rhs ) {
        if( Rhs.compareTo(OPR_GT) == 0 ) return OPR_LE;
        else if( Rhs.compareTo(OPR_GE) == 0 ) return OPR_LT;
        else if( Rhs.compareTo(OPR_LT) == 0 ) return OPR_GE;
        else if( Rhs.compareTo(OPR_LE) == 0 ) return OPR_GT;
        else if( Rhs.compareTo(OPR_EQ) == 0 ) return OPR_NE;
        else if( Rhs.compareTo(OPR_NE) == 0 ) return OPR_EQ;
        else return Rhs;
    }

    public String getExpression() {
        Operator = Operator.trim();
        Opr2 = Opr2.trim();

        if ( Opr2.equals(FALSE) ) {
            if( Operator.equals(OPR_EQ) ) {
                return OPR_NOT + Opr1;
            }
            return Opr1;
        } else if ( Opr2.equals(TRUE) ) {
            if( Operator.equals(OPR_EQ) ) {
                return Opr1;
            }
            return OPR_NOT + Opr1;
        } else {
            return Opr1 + " " + Operator + " "  + Opr2;
        }
    }

    public String toString() {
        StringBuffer sb  = new StringBuffer("  ");
        sb.append( written + " " );
        sb.append( StartPc + " " + NextPc + "  " + TargetPc + " ");
        switch(Type){
            case TYPE_IF:
                sb.append("TYPE_IF");
                break;
            case TYPE_ELSE_IF:
                sb.append("TYPE_ELSE_IF");
                break;
            case TYPE_ELSE:
                sb.append("TYPE_ELSE");
                break;
            case TYPE_DO_WHILE:
                sb.append("TYPE_DO_WHILE");
                break;
            case TYPE_TRY:
                sb.append("TYPE_TRY");
                break;
            case TYPE_TRY_ANY:
                sb.append("TYPE_TRY_ANY");
                break;
            case TYPE_CATCH:
                sb.append("TYPE_CATCH");
                break;
            case TYPE_CATCH_ANY:
                sb.append("TYPE_CATCH_ANY");
                break;
            case TYPE_WHILE:
                sb.append("TYPE_WHILE");
                break;
            case TYPE_JSR:
                sb.append("TYPE_JSR");
                break;
            case TYPE_SYNC:
                sb.append("TYPE_SYNCHRONIZED");
                break;
            case TYPE_CASE:
                sb.append("TYPE_CASE");
                break;
            case TYPE_SWITCH:
                sb.append("TYPE_SWITCH");
                break;
            default:
                sb.append(Type);
        }
        sb.append( " " + Opr1 + " " + Operator + " " + Opr2 ) ;
        return sb.toString();
    }
}
