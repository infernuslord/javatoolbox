// $Id: Engine.java,v 1.1 2002/04/25 18:17:43 bill Exp $

package com.jclark.xsl.tr;

import com.jclark.xsl.om.*;
import java.io.IOException;
import java.net.URL;

/**
 * An engine, compiles a stylesheet
 */
public interface Engine
{
    LoadContext getSheetLoadContext();
    Sheet createSheet(Node node) throws IOException, XSLException;
    NameTable getNameTable();
}
