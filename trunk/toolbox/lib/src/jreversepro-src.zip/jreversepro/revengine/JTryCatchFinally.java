/**
  * @(#)JTryCatchFinally.java
  *
  * JReversePro - Java Decompiler / Disassembler.
  * Copyright (C) 2000 2001 Karthik Kumar.
  * EMail: akkumar@users.sourceforge.net
  *
  * This program is free software; you can redistribute it and/or modify
  * it , under the terms of the GNU General Public License as published
  * by the Free Software Foundation; either version 2 of the License,
  * or (at your option) any later version.
  *
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  * See the GNU General Public License for more details.
  * You should have received a copy of the GNU General Public License
  * along with this program.If not, write to
  *  The Free Software Foundation, Inc.,
  *  59 Temple Place - Suite 330,
  *  Boston, MA 02111-1307, USA.
  **/

package jreversepro.revengine;

import jreversepro.reflect.JInstruction;

import java.util.List;
import java.util.Stack;

public class JTryCatchFinally {
    List ByteIns;
    JBranchTable bt;
    Stack stk;
    EntryX data;

    class EntryX {
        JBranchEntry catchEnt;
        JBranchEntry tryEnt;
        int tryEnd;
        int catchType;
        int jsrType;
    }

    public JTryCatchFinally(List Instructions, JBranchTable jbt) {
        ByteIns = Instructions;
        bt = jbt;
        stk = new Stack();
    }

    public void tryEnt(JBranchEntry ent, int cType, int jType) {

        try {
            EntryX dataNew = new EntryX();

            dataNew.tryEnt = ent;
            dataNew.catchType = cType;
            dataNew.jsrType = jType;

            dataNew.tryEnd = dataNew.tryEnt.getEndBlockPc();
            int target = bt.findGotoTarget(dataNew.tryEnd);
            if (target == -1) {
                JInstruction Ins = bt.findGotoIns(ByteIns, dataNew.tryEnt.getStartBlockPc(), dataNew.tryEnd);
                if (Ins != null) {
                    target = Ins.getTargetPc();
                    dataNew.tryEnd = Ins.index;
                } else {
                    target = dataNew.tryEnd;
                }
            }
            dataNew.tryEnt.setEndBlockPc(dataNew.tryEnd);
            dataNew.tryEnd = target;
            dataNew.catchEnt = null;
            // check for previous open try-catch blok
            if (stk.size() > 0 && data.catchEnt != null) {
                if (data.catchEnt.getStartBlockPc() < dataNew.tryEnt.getStartBlockPc()) {
                    JInstruction Ins = bt.findGotoIns(ByteIns, data.catchEnt.getStartBlockPc(), data.tryEnd);
                    if (Ins != null) {
                        data.catchEnt.setEndBlockPc(Ins.index);
                    } else {
                        data.catchEnt.setEndBlockPc(data.tryEnd);
                    }
                    data.catchEnt = null;
                    stk.pop();
                }
            }
            stk.push(dataNew);
            data = dataNew;
        } catch (RevEngineException revx) {
            revx.printStackTrace();
        }
    }

    /**
     * Insert the method's description here.
     * Creation date: (12.5.2002 14:59:25)
     */
    public void catchEnt(JBranchEntry ent) {

        try {
            while (ent.getType() != data.catchType
                || ent.getStartBlockPc() > data.tryEnd) {
                    if (data.catchEnt != null) {
                        JInstruction Ins = bt.findGotoIns(ByteIns, data.catchEnt.getStartBlockPc(), ent.getStartBlockPc());
                        if (Ins != null) {
                            data.catchEnt.setEndBlockPc(Ins.index);
                        }
                        data.catchEnt = null;
                    }
                if (stk.size() == 0) return;
                data = (EntryX)stk.pop();
            }
            if (data.catchEnt != null) {
                JInstruction Ins = bt.findGotoIns(ByteIns, data.catchEnt.getStartBlockPc(), ent.getStartBlockPc());
                if (Ins != null) {
                    data.catchEnt.setEndBlockPc(Ins.index);
                }
            }
            data.catchEnt = ent;
        } catch (RevEngineException revx) {
            revx.printStackTrace();
        }
    }

    public void jsrEnt(JBranchEntry ent) {

        try {
            while (ent.getType() != data.jsrType
                || ent.getStartBlockPc() > data.tryEnd) {
                if (data.catchEnt != null) {
                    data.catchEnt.setEndBlockPc(data.tryEnd);
                    data.catchEnt = null;
                }
                if (stk.size() == 0) return;
                data = (EntryX)stk.pop();
            }
            if (data.catchEnt != null) {
                JInstruction Ins = bt.findGotoIns(ByteIns, data.catchEnt.getStartBlockPc(), ent.getStartBlockPc());
                if (Ins != null) {
                    data.catchEnt.setEndBlockPc(Ins.index);
                }
                data.catchEnt = null;
            }
        } catch (RevEngineException revx) {
            revx.printStackTrace();
        }
    }

    public void end() {
        if (data != null && data.catchEnt != null) {
            try {
                JInstruction Ins = bt.findGotoIns(ByteIns, data.catchEnt.getStartBlockPc(), data.tryEnd);
                if (Ins != null) {
                    data.catchEnt.setEndBlockPc(Ins.index);
                } else {
                    data.catchEnt.setEndBlockPc(data.tryEnd);
                }
                data.catchEnt = null;
            } catch (RevEngineException revx) {
                revx.printStackTrace();
            }
        }
    }
}