/*
 * Please see COPYING for license details
 *
 * Copyright (C) 2003 Raghu K, All rights reserved.
 */

package hamsam.protocol.msn;

/**
 * A query command is used to answer challenges raised by MSN server. A challenge
 * is a ping from notification server.
 */
class MsnQuery extends AbstractCommand
{
	/**
	 * Payload for query is stored here.
	 */
	private String payload;

	/**
	 * Constructor for outgoing queries.
	 *
	 * @param payload payload to be sent to the server.
	 */
	MsnQuery(String payload)
	{
		super("QRY");
		addParam("msmsgs@msnmsgr.com");
		addParam("32");

		this.payload = payload;
	}

	/**
	 * Returns a string representation of this query. The returned string is
	 * composed by appending the following components.
	 *
	 * <ul>
	 * 	<li>Command type (QRY).</li>
	 * 	<li>A space character.</li>
	 * 	<li>Transaction ID, if available.</li>
	 * 	<li>A space character.</li>
	 * 	<li>All the parameters separated by space characters.</li>
	 * 	<li>A CRLF.</li>
	 * 	<li>The payload of this query.</li>
	 * </ul>
	 *
	 * The string is not terminated by a CRLF.
	 *
	 * @return string representation of this query.
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer(super.toString());
		ret.append("\r\n");

		ret.append(payload);

		return ret.toString();
	}
}
