/*
 *   The contents of this file are subject to the Mozilla Public License
 *   Version 1.1 (the "License"); you may not use this file except in
 *   compliance with the License. You may obtain a copy of the License at
 *   http://www.mozilla.org/MPL/
 *
 *   Software distributed under the License is distributed on an "AS IS"
 *   basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 *   License for the specific language governing rights and limitations
 *   under the License.
 *
 *   The Original Code is Matra - the DTD Parser.
 *
 *   The Initial Developer of the Original Code is Conrad S Roche.
 *   Portions created by Conrad S Roche are Copyright (C) Conrad 
 *   S Roche. All Rights Reserved.
 *
 *   Alternatively, the contents of this file may be used under the terms
 *   of the GNU GENERAL PUBLIC LICENSE Version 2 or any later version
 *   (the  "[GPL] License"), in which case the
 *   provisions of GPL License are applicable instead of those
 *   above.  If you wish to allow use of your version of this file only
 *   under the terms of the GPL License and not to allow others to use
 *   your version of this file under the MPL, indicate your decision by
 *   deleting  the provisions above and replace  them with the notice and
 *   other provisions required by the GPL License.  If you do not delete
 *   the provisions above, a recipient may use your version of this file
 *   under either the MPL or the GPL License."
 *
 *   [NOTE: The text of this Exhibit A may differ slightly from the text of
 *   the notices in the Source Code files of the Original Code. You should
 *   use the text of this Exhibit A rather than the text found in the
 *   Original Code Source Code for Your Modifications.]
 *
 * Created: Conrad S Roche <derupe at users.sourceforge.net>,  19-Sep-2003
 */
package com.conradroche.matra.test.parser;

import com.conradroche.dtd.decl.Comment;
import com.conradroche.dtd.parser.CommentReader;
import com.conradroche.matra.data.DTDData;
import com.conradroche.matra.exception.DTDSyntaxException;
import com.conradroche.matra.parser.CommentReaderImpl;

import junit.framework.Assert;
import junit.framework.TestCase;

/**
 * Class to unit test the CommentReaderImpl class.
 *
 * @author Conrad Roche
 */
public class CommentReaderImplTest extends TestCase {

	private CommentReader commentReader = new CommentReaderImpl();
	
	/**
	 * Constructor for CommentReaderImplTest.
	 * @param arg0
	 */
	public CommentReaderImplTest(String arg0) {
		super(arg0);
	}

	public void testValidComments() {
		String[] comments = 
			{" this is a test ", "this is another test",
				"- ", " - ", 
				"", " ", "\t", "\n", "\t\n",
				" declarations for <head> & <body> ",
				"a \n multi-line\n comment",
				"no-spaces", "@#@#%%@#",
				"Did you know that 3 - 2 = 1? hmm. I bet you did!"
			};
			
		for(int i = 0; i < comments.length; i++) {
			checkValidComment(comments[i]);
		}
		
	}
	
	public void testAdjacentComments() {

		String[] comments = 
			{" declarations for <head> & <body> ", "Did you know that 3 - 2 = 1? hmm. I bet you did!"};

		DTDData data = new DTDData("<!--" + comments[0] + "--><!--" + comments[1] + "-->");
		checkValidComment(data, comments[0]);
		checkValidComment(data, comments[1]);
		
		data = new DTDData(" \t<!--" + comments[0] + "-->  \n<!--" + comments[1] + "-->");
		data.skipWhiteSpace();
		checkValidComment(data, comments[0]);
		data.skipWhiteSpace();
		checkValidComment(data, comments[1]);
		
		data = new DTDData(" \t<!--" + comments[0] + "-->  \n<!--" + comments[1] + "--");
		data.skipWhiteSpace();
		checkValidComment(data, comments[0]);
		data.skipWhiteSpace();
		checkInvalidComment(data, comments[1]);
	}

	private void checkValidComment(DTDData data, String str) {
		
		Assert.assertTrue("isCommentStart check failed for " + data + ".", commentReader.isCommentStart(data));
		
		Comment comment = null;
		
		try {
			comment = commentReader.readComment(data);
		} catch(DTDSyntaxException dse) {
			Assert.fail("Caught DTDSyntaxException while parsing " + data + "." + dse.getMessage());
		} catch(Throwable th) {
			Assert.fail("Caught Throwable while parsing " + data + "." + th.getMessage());
		}
		
		Assert.assertEquals(str, comment.getCommentText());
	}
			
	private void checkValidComment(String str) {
		
		DTDData data = new DTDData("<!--" + str + "-->");
		checkValidComment(data, str);
	}
	
	public void testInvalidComments() {
		String[] invalidComments =
			{"<!-- this is a -- comment -->",
			 "<!-- -- comment -->", "<!-- comment -- -->",
			 "<!-- -- -->", "<!-->",
			 "<!------>", "<!--- --->", "<!----->", "<!-- --->", 
			 "<!-- comment", "<!-- comment -", "<!-- comment --", 
			 "<!-- B+, B, or B--->",
			 "<!-- this is a nested <!-- comment --> and is not allowed -->",
			 "<!--<!---->-->",
			 "<!-- ->", "<!-- --!>", "<!-- >", "<!-- />", "<!-- --",
			 "<!-- !>", "<!-- __>", "<!--", "<!-- ==>",
			 "<!--\n", "<!--\n--\n-->",
			 "<!-- comment -?>", "<!-- comment --?", "<!-- comment ?->" 
			};
		for(int i = 0; i < invalidComments.length; i++) {
			checkInvalidComment(invalidComments[i]);
		}
	}

	private void checkInvalidComment(DTDData data, String str) {

		Assert.assertTrue("isCommentStart check failed for " + data + ".", commentReader.isCommentStart(data));
		
		try {
			commentReader.readComment(data);
		} catch(DTDSyntaxException dse) {
			return;
		} catch(Throwable th) {
			Assert.fail("Caught exception for '" + str + "' - " + th.getMessage());
			return;
		}
		Assert.fail("Did not get DTDSyntaxException for '" + str + "'");
	}
	
	/**
	 * Add javadoc for CommentReaderImplTest::checkInvalidComment
	 * @param string
	 */
	private void checkInvalidComment(String str) {
		
		DTDData data = new DTDData(str);
		checkInvalidComment(data, str);
	}
	
	public void testNullComment() {
		
		DTDData data = null;
		checkNullComment(data);
		
		data = new DTDData(null);
		checkNullComment(data);
		
		data.reset();
		checkNullComment(data);
		
		data = new DTDData("");
		checkNullComment(data);
	}
	
	private void checkNullComment(DTDData data) {

		Assert.assertFalse("isCommentStart check failed for " + data + ".", commentReader.isCommentStart(data));
		
		Comment comment = null;
		
		try {
			comment = commentReader.readComment(data);
		} catch(DTDSyntaxException dse) {
			Assert.fail("Caught DTDSyntaxException while parsing " + data + "." + dse.getMessage());
		} catch(Throwable th) {
			Assert.fail("Caught Throwable while parsing " + data + "." + th.getMessage());
		}

		Assert.assertNull(comment);
	}
	
	public void testNonComments() {
		
		String[] nonComments = {
					"  <!-- comment -->", "", " ", "\t\n \n",
					"comment text - no comment markup",
					"?!-- comment -->", "<?-- comment -->", "<!?- comment -->", "<!-? comment -->"
		};
		
		for(int i = 0; i < nonComments.length; i++) {
			checkNonComment(new DTDData(nonComments[i]));
		}
	}
	
	private void checkNonComment(DTDData data) {
		
		checkNullComment(data);
	}
}
