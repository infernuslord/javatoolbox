/*
 * Please see COPYING for license details
 *
 * Copyright (C) 2003 Raghu K, All rights reserved.
 */

package hamsam.net;

import java.net.UnknownHostException;
import java.io.IOException;
import hamsam.exception.IllegalArgumentException;
import hamsam.exception.IllegalStateException;

/**
 * Defines the type of connections to be used for each protocol. An object
 * that implements this interface is used by Hamsam library to determine
 * what type of connections are to be used for each protocol.
 *
 * @author Raghu
 */
public class ProxyInfo
{
	/**
	 * Connection type indicating a direct connection to the Internet.
	 */
	public static final int DIRECT = 0;

	/**
	 * Connection type indicating a connection through Socks Version 4
	 * proxy to the Internet.
	 */
	public static final int SOCKS4 = 1;

	/**
	 * Connection type indicating a connection through Socks Version 5
	 * proxy to the Internet.
	 */
	public static final int SOCKS5 = 2;

	/**
	 * Connection type indicating a connection through HTTP proxy to
	 * the Internet.
	 */
	public static final int HTTP = 3;

	/**
	 * The connection type of this proxy information object.
	 */
	private int type;

	/**
	 * Hostname of the proxy server.
	 */
	private String serverName;

	/**
	 * Proxy server port.
	 */
	private int serverPort;

	/**
	 * Username to be used for proxy authentication.
	 */
	private String username;

	/**
	 * Password to be used for proxy authentication.
	 */
	private String password;

	/**
	 * Construct a proxy information object indicating direct connection
	 * to the Internet. This is to be used if you don't have any proxy servers.
	 */
	public ProxyInfo()
	{
		this.type = DIRECT;
		this.serverName = null;
		this.serverPort = -1;
		this.username = null;
		this.password = null;
	}

	/**
	 * Construct a proxy information object indicating the type of proxy to
	 * be used, the proxy server's host name, and proxy server's listening
	 * port number. This is to be used if you are connecting through Socks or
	 * HTTP proxy servers.
	 *
	 * <p>
	 * You may use SOCKS4, SOCKS5, or HTTP as the proxy types. If you specify
	 * the proxy type as DIRECT, an
	 * {@link hamsam.exception.IllegalArgumentException IllegalArgumentException}
	 * will be thrown.
	 *
	 * @param type The proxy server type.
	 * @param serverName The host name of the proxy server.
	 * @param serverPort The TCP/IP port number in which the proxy is listening.
	 * @throws IllegalArgumentException If <code>type</code> is <code>DIRECT</code>.
	 */
	public ProxyInfo(int type, String serverName, int serverPort) throws IllegalArgumentException
	{
		if(type == DIRECT)
			throw new IllegalArgumentException("Proxy type can not be DIRECT.");

		this.type = type;
		this.serverName = serverName;
		this.serverPort = serverPort;
		this.username = null;
		this.password = null;
	}

	/**
	 * Set the username to be used for proxy authentication.
	 *
	 * <p>
	 * Socks version 5 and HTTP proxies optionally use authentication through
	 * a username-password mechanism. This method sets the username for such
	 * authentication.
	 *
	 * <p>
	 * If the proxy type is other than <code>SOCKS5</code> or <code>HTTP</code>,
	 * this method throws an
	 * {@link hamsam.exception.IllegalStateException IllegalStateException}.
	 *
	 * @param username The username to be used for proxy authentication.
	 * @throws IllegalStateException If the proxy type is neither Socks version 5
	 *                               nor HTTP.
	 */
	public void setUsername(String username) throws IllegalStateException
	{
		if(type != SOCKS5 && type != HTTP)
			throw new IllegalStateException("Proxy type must be SOCKS5 or HTTP");

		this.username = username;
	}

	/**
	 * Set the password to be used for proxy authentication.
	 *
	 * <p>
	 * Socks version 5 and HTTP proxies optionally use authentication through
	 * a username-password mechanism. This method sets the password for such
	 * authentication.
	 *
	 * <p>
	 * If the proxy type is other than <code>SOCKS5</code> or <code>HTTP</code>,
	 * this method throws an
	 * {@link hamsam.exception.IllegalStateException IllegalStateException}.
	 *
	 * @param password The password to be used for proxy authentication.
	 * @throws IllegalStateException If the proxy type is neither Socks version 5
	 *                               nor HTTP.
	 */
	public void setPassword(String password) throws IllegalStateException
	{
		if(type != SOCKS5 && type != HTTP)
			throw new IllegalStateException("Proxy type must be SOCKS5 or HTTP");

		this.password = password;
	}

	/**
	 * Returns the type of proxy to be used as indicated by this object.
	 *
	 * <p>
	 * This method returns the proxy type set at the time of constructing this
	 * object.
	 *
	 * @return The proxy type as indicated by this object.
	 */
	public int getProxyType()
	{
		return type;
	}

	/**
	 * Returns the host name of the proxy server to be used.
	 *
	 * <p>
	 * If this object specifies a direct connection to the Internet,
	 * this method will return <code>null</code>.
	 *
	 * @return The host name of the proxy server, or <code>null</code>
	 *         if there is no proxy servers.
	 */
	public String getServerName()
	{
		return serverName;
	}

	/**
	 * Returns the TCP/IP port at which the proxy server is listening.
	 *
	 * <p>
	 * If there is no proxy server, this will return -1.
	 *
	 * @return The proxy server port, or -1 if there is no proxy.
	 */
	public int getServerPort()
	{
		return serverPort;
	}

	/**
	 * Returns the username to be used for proxy authentication.
	 *
	 * <p>
	 * If the type of the proxy is neither Socks version 5 nor HTTP,
	 * an
	 * {@link hamsam.exception.IllegalStateException IllegalStateException}
	 * will be thrown.
	 *
	 * @return The username for proxy authentication, or <code>null</code>
	 *         if the proxy does not require authentication.
	 * @throws IllegalStateException If the proxy type is neither Socks version 5
	 *                               nor HTTP.
	 */
	public String getUsername() throws IllegalStateException
	{
		if(type != SOCKS5 && type != HTTP)
			throw new IllegalStateException("Proxy type must be SOCKS5 or HTTP");

		return username;
	}

	/**
	 * Returns the password to be used for proxy authentication.
	 *
	 * <p>
	 * If the type of the proxy is neither Socks version 5 nor HTTP,
	 * an IllegalStateException will be thrown.
	 *
	 * @return The password for proxy authentication, or <code>null</code>
	 *         if the proxy does not require authentication.
	 * @throws IllegalStateException If the proxy type is neither Socks version 5
	 *                               nor HTTP.
	 */
	public String getPassword() throws IllegalStateException
	{
		if(type != SOCKS5 && type != HTTP)
			throw new IllegalStateException("Proxy type must be SOCKS5 or HTTP");

		return password;
	}

	/**
	 * Creates a connection through the proxy set in this ProxyInfo object.
	 *
	 * @param hostname the host to connect to.
	 * @param port the TCP/IP ports number to connect to.
	 * @return a newly created connection to the specified server at the
	 *         specified port.
	 * @throws UnknownHostException if the proxy server or the host is unknown.
	 * @throws IOException if an I/O error occured while connecting.
	 * @throws IllegalStateException if this ProxyInfo is not initialized properly.
	 */
	public Connection getConnection(String hostname, int port) throws UnknownHostException, IOException, IllegalStateException
	{
		Connection conn;

		switch(type)
		{
			case DIRECT:
				conn = new DirectConnection(hostname, port);
				break;
			case SOCKS4:
				conn = new SocksConnection(serverName, serverPort, hostname, port);
				break;
			case SOCKS5:
				conn = new SocksConnection(
								serverName, serverPort,
								username, password,
								hostname, port);
				break;
			case HTTP:
				if(username == null || password == null)
					conn = new HttpConnection(serverName, serverPort, hostname, port);
				else
					conn = new HttpConnection(
									serverName, serverPort,
									username, password,
									hostname, port);
				break;
			default:
				throw new IllegalStateException("Unknown proxy type");
		}

		return conn;
	}
}
