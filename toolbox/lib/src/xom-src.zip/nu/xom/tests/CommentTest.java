// Copyright 2002, 2003 Elliotte Rusty Harold
// 
// This library is free software; you can redistribute 
// it and/or modify it under the terms of version 2.1 of 
// the GNU Lesser General Public License as published by  
// the Free Software Foundation.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General 
// Public License along with this library; if not, write to the 
// Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
// Boston, MA  02111-1307  USA
// 
// You can contact Elliotte Rusty Harold by sending e-mail to
// elharo@metalab.unc.edu. Please include the word "XOM" in the
// subject line. The XOM home page is temporarily located at
// http://www.cafeconleche.org/XOM/  but will eventually move
// to http://www.xom.nu/

package nu.xom.tests;

import junit.framework.Assert;
import junit.framework.TestCase;

import nu.xom.Comment;
import nu.xom.Document;
import nu.xom.Element;
import nu.xom.IllegalDataException;

public class CommentTest extends TestCase {

    public CommentTest() {
        super("Comment tests");
    }

    public CommentTest(String name) {
        super(name);
    }

    public void testConstructor() {
         Comment c1 = new Comment("test");

         Assert.assertEquals(c1.getValue(), "test");

         Comment c2 = new Comment("");

         Assert.assertEquals(c2.getValue(), "");

     }

    public void testSetter() {

        Comment c1 = new Comment("test");
        c1.setValue("legal");
        assertEquals("legal", c1.getValue());
        
        try {
          c1.setValue("test -- test");
          fail("Should raise an IllegalDataException");
        }
        catch (IllegalDataException success) {}
        try {
          c1.setValue("-test");
          fail("Should raise an IllegalDataException");
        }
        catch (IllegalDataException success) {}
        try {
          c1.setValue("test-");
          fail("Should raise an IllegalDataException");
        }
        catch (IllegalDataException success) {}

        c1.setValue(null);
        assertEquals("", c1.getValue());

     }


    public void testEquals() {
        Comment c1 = new Comment("test");
        Comment c2 = new Comment("test");
        Comment c3 = new Comment("skjlchsakdjh");

        Assert.assertEquals(c1, c1);
        Assert.assertEquals(c1.hashCode(), c1.hashCode());
        Assert.assertTrue(!c1.equals(c2));
        Assert.assertTrue(!c1.equals(c3));
    }

    public void testCopy() {
        Comment c1 = new Comment("test");
        Comment c2 = (Comment) c1.copy();

        Assert.assertEquals(c1.getValue(), c2.getValue());
        Assert.assertTrue(!c1.equals(c2));
        Assert.assertNull(c2.getParent());

    }

    // Check passing in a string with broken surrogate pairs
    // and with correct surrogate pairs
    public void testSurrogates() {

        String goodString = "test: \uD8F5\uDF80  ";
        Comment c = new Comment(goodString);
        Assert.assertEquals(goodString, c.getValue());

        // Two high-halves
        try {
          Comment c1 = new Comment("test: \uD8F5\uDBF0  ");
          fail("Should raise an IllegalDataException");
        }
        catch (IllegalDataException success) {}


        // Two high-halves
        try {
          Comment c1 = new Comment("test: \uD8F5\uD8F5  ");
          fail("Should raise an IllegalDataException");
        }
        catch (IllegalDataException success) {}

        // One high-half
        try {
           Comment c1 = new Comment("test: \uD8F5  ");
           fail("Should raise an IllegalDataException");
         }
         catch (IllegalDataException success) {}

        // One low half
         try {
            Comment c1 = new Comment("test: \uDF80  ");
            fail("Should raise an IllegalDataException");
          }
          catch (IllegalDataException success) {}

        // Low half before high half
         try {
            Comment c1 = new Comment("test: \uDCF5\uD8F5  ");
            fail("Should raise an IllegalDataException");
          }
          catch (IllegalDataException success) {}


    }

    public void testLeafNode() {

        Comment c1 = new Comment("data");
        Assert.assertEquals(c1.getChildCount(), 0);
        Assert.assertTrue(!c1.hasChildren());
        try {
            c1.getChild(0);
            fail("Didn't throw IndexOutofBoundsException");
        }
        catch (IndexOutOfBoundsException ex) {
            // success   
        }
        
        /*
        Assert.assertNull(c1.getPreviousSibling());
        Assert.assertNull(c1.getNextSibling()); */
        Assert.assertNull(c1.getParent());

        Element element = new Element("test");
        element.appendChild(c1);
        Assert.assertEquals(c1.getParent(), element);
        Assert.assertEquals(c1, element.getChild(0));

        element.removeChild(c1);
        assertTrue(!element.hasChildren());

    }

   public void testGetDocument() {

        Comment c1 = new Comment("data");
        Assert.assertNull(c1.getDocument());
        Element root = new Element("root");
        root.appendChild(c1);
        Assert.assertNull(c1.getDocument());
        Document doc = new Document(root);
        Assert.assertEquals(c1.getDocument(), doc);

    }

}
