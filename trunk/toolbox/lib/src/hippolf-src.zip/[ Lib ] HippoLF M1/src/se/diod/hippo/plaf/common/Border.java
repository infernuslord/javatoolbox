/*
 * 
 * Created on 2004-jul-22
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.common;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;

import javax.swing.AbstractButton;
import javax.swing.ButtonModel;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JToolBar;
import javax.swing.UIManager;
import javax.swing.border.AbstractBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.BorderUIResource;
import javax.swing.plaf.UIResource;
import javax.swing.plaf.basic.BasicBorders;





/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-22
 *
 */
public class Border {
	private static javax.swing.border.Border buttonBorder;
	private static javax.swing.border.Border dialogPanelBorder;
	private static javax.swing.border.Border emptyBorder;
	private static javax.swing.border.Border emptyBorder2;
	private static javax.swing.border.Border internalFrameBorder;
	private static javax.swing.border.Border menuBorder;
	private static javax.swing.border.Border menuItemBorder;
	private static javax.swing.border.Border menuBarBorder;
	private static javax.swing.border.Border popupMenuBorder;
	private static javax.swing.border.Border progressBarBorder;
	private static javax.swing.border.Border spinnerBorder;
	private static javax.swing.border.Border tableHeaderCellBorder;
	private static javax.swing.border.Border toolBarBorder;
	private static javax.swing.border.Border toolBarButtonBorder;
	private static javax.swing.border.Border toolBarSelectedButtonBorder;
	private static javax.swing.border.Border toolBarSelectedToggleButtonBorder;
	private static javax.swing.border.Border toolBarToggleButtonBorder;
	private static javax.swing.border.Border toolTipBorder;




	/**
	 * 
	 * Returns a button border.
	 * 
	 */
	public static javax.swing.border.Border getButtonBorder() {
		if( buttonBorder ==	null ) { 
			buttonBorder =	new BorderUIResource.CompoundBorderUIResource( new ButtonBorder(), new BasicBorders.MarginBorder());
		}
		return buttonBorder;
	}

	
	
	
	/**
	 * 
	 * Returns a dialog (optionpane) border.
	 * 
	 */
	public static javax.swing.border.Border getDialogPanelBorder() {
		if( dialogPanelBorder ==	null ) {
			dialogPanelBorder =	new CompoundBorder( new DialogPanelBorder(), new BasicBorders.MarginBorder() );
		}
		return dialogPanelBorder;
	}

	
	
	
	/**
	 * 
	 * Returns an empty border.
	 * 
	 */
	public static javax.swing.border.Border getEmptyBorder() {
		if( emptyBorder == null ) {
			emptyBorder = new CompoundBorder( new EmptyBorder( 0, 0, 0, 0 ), new BasicBorders.MarginBorder());
		}

		return emptyBorder;
	}

	
	
	

	/** 
	 * Returns an empty border.
	 * 
	 */
	public static javax.swing.border.Border getEmptyBorder( int top, int left, int bottom, int right ) {
		if( emptyBorder2 == null ) {
			emptyBorder2 = new CompoundBorder( new EmptyBorder( top, left, bottom, right ), new BasicBorders.MarginBorder());
		}

		return emptyBorder2;
	}

	
	
	
	/**
	 * 
	 * Returns a menubar border.
	 * 
	 */
	public static javax.swing.border.Border getInternalFrameBorder() {
		if( internalFrameBorder == null ) { 
			internalFrameBorder = new InternalFrameBorder();
		}

		return internalFrameBorder;
	}

	
	
	
	/**
	 * 
	 * Returns a menubar border.
	 * 
	 */
	public static javax.swing.border.Border getMenuBarBorder() {
		if( menuBarBorder == null ) { 
			menuBarBorder = new MenuBarBorder();
		}

		return menuBarBorder;
	}




	/**
	 * 
	 * Returns a menubar border.
	 * 
	 */
	public static javax.swing.border.Border getMenuItemBorder() {
		if( menuItemBorder == null ) { 
			menuItemBorder = new CompoundBorder( new MenuItemBorder(), new BasicBorders.MarginBorder());
		}

		return menuItemBorder;
	}




	/**
	 * 
	 * Returns a menubar border.
	 * 
	 */
	public static javax.swing.border.Border getMenuBorder() {
		if( menuBorder == null ) { 
			menuBorder = new CompoundBorder( new MenuBorder(), new BasicBorders.MarginBorder());
		}

		return menuBorder;
	}

	
	
	
	/**
	 * 
	 * Returns an empty border.
	 * 
	 */
	public static javax.swing.border.Border getPopupMenuBorder() {
		if( popupMenuBorder == null ) { 
			popupMenuBorder = new CompoundBorder( new PopupMenuBorder(), new BasicBorders.MarginBorder());
		}
		return popupMenuBorder;
	}

	
	
	
	/**
	 * 
	 * Returns a progressbar border.
	 * 
	 */
	public static javax.swing.border.Border getProgressBarBorder() {
		if( progressBarBorder == null ) {
			progressBarBorder =	 new CompoundBorder( new ProgressBarBorder(), new BasicBorders.MarginBorder() );
		}
		return progressBarBorder;
	}

	
	
	
	/**
	 * 
	 * Returns a progressbar border.
	 * 
	 */
	public static javax.swing.border.Border getSpinnerBorder() {
		if( spinnerBorder == null ) {
			spinnerBorder =	 new CompoundBorder( new SpinnerBorder(), new BasicBorders.MarginBorder() );
		}
		return spinnerBorder;
	}

	
	
	
	/**
	 * 
	 * Returns a menubar border.
	 * 
	 */
	public static javax.swing.border.Border getTableHeaderCellBorder() {
		if( tableHeaderCellBorder == null ) { 
			tableHeaderCellBorder = new TableHeaderCellBorder();
			//tableHeaderCellBorder = new CompoundBorder( new TableHeaderCellBorder(), getEmptyBorder() );
		}

		return tableHeaderCellBorder;
	}

	
	
	
	/**
	 * 
	 * Returns an empty border.
	 * 
	 */
	public static javax.swing.border.Border getToolBarBorder() {
		if( toolBarBorder == null ) { 
			toolBarBorder = new CompoundBorder( new ToolBarBorder(), new BasicBorders.MarginBorder());
		}
		return toolBarBorder;
	}

	
	
	
	/**
	 * 
	 * Returns an empty border.
	 * 
	 */
	public static javax.swing.border.Border getToolBarButtonBorder() {
		if( toolBarButtonBorder ==	null ) { 
			toolBarButtonBorder =	new ToolBarButtonBorder();
		}
		return toolBarButtonBorder;
	}




	/**
	 * 
	 * Returns a ToolBar Selected Button Border.
	 * 
	 */
	public static javax.swing.border.Border getToolBarSelectedButtonBorder() {
		if( toolBarSelectedButtonBorder ==	null ) { 
			toolBarSelectedButtonBorder =	new ToolBarSelectedButtonBorder();
		}
		return toolBarSelectedButtonBorder;
	}

	
	
	
	/**
	 * 
	 * Returns a toolbar togglebutton border.
	 * 
	 */
	public static javax.swing.border.Border getToolBarSelectedToggleButtonBorder() {
		if( toolBarSelectedToggleButtonBorder == null ) {
			toolBarSelectedToggleButtonBorder =	 new ToolBarSelectedToggleButtonBorder();
		}
		return toolBarSelectedToggleButtonBorder/*spinnerBorder*/;
	}



	
	/**
	 * 
	 * Returns a toolbar togglebutton border.
	 * 
	 */
	public static javax.swing.border.Border getToolBarToggleButtonBorder() {
		if( toolBarToggleButtonBorder == null ) {
			toolBarToggleButtonBorder =	 new ToolBarToggleButtonBorder();
		}
		return toolBarToggleButtonBorder;
	}

	
	
	
	/**
	 * 
	 * Returns a tooltip border.
	 * 
	 */
	public static javax.swing.border.Border getToolTipBorder() {
		if( toolTipBorder ==	null ) {
			toolTipBorder =	new CompoundBorder( new ToolTipBorder(), new BasicBorders.MarginBorder() );
		}
		return toolTipBorder;
	}






	// **********************************************************************
	//
	//                           Border Classes
	//
	// **********************************************************************
	/**
	 * 
	 * 
	 */
	private static class ButtonBorder extends AbstractBorder {
		private static final Insets INSETS  = new Insets( 0, 0, 0, 0 );

		public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
			Graphics g2 = g.create();
			AbstractButton button = (AbstractButton) c;
			ButtonModel model = button.getModel();

			if( model.isEnabled() ) {
				boolean isPressed = model.isPressed() && model.isArmed();
				boolean isDefault = button instanceof JButton && ( (JButton)button ).isDefaultButton();

				//if (isPressed && isDefault) {
				//} else if (isPressed) {
				//} else if (isDefault) {
				//} else {
				g2.setColor( new java.awt.Color( 155, 155, 155 ) );
				g2.drawRect( x, y, w-1, h-1 );
				//}
			} else {
				// Disabled state..
				g2.setColor( new java.awt.Color( 155, 155, 155 ) );
				g2.drawRect( x, y, w-1, h-1 );
			}

			g2.dispose();
		}

		public Insets getBorderInsets( Component c ) {
			return INSETS;
		}
	}

	
	
	
	/**
	 * 
	 * 
	 */
	private static class DialogPanelBorder extends AbstractBorder {
		private static final Insets INSETS  = new Insets( 1, 1, 1, 1 );

		public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
			Graphics g2 = g.create();

			g2.setColor( new Color( 155, 155, 155 ) );
			g2.drawRect( x, h-1, w-1, h-1 );

			g2.dispose();
		}

		public Insets getBorderInsets( Component c ) { return INSETS; }
	}

	
	
	
	/**
	 * 
	 * A border used for <code>JInternalFrame</code>s.
	 * 
	 */
	private static class InternalFrameBorder extends AbstractBorder implements UIResource {
		private static final Insets NORMAL_INSETS		= new Insets(1, 1, 1, 1);
		private static final Insets MAXIMIZED_INSETS	= new Insets(1, 1, 1, 1);

		public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
			Graphics g2 = g.create();

			g.translate(x, y);

			g2.setColor( UIManager.getColor( "InternalFrame.background" ) );
			g2.fillRect( 0, 0, w - 1, h - 1 );

			g2.setColor( UIManager.getColor( "InternalFrame.borderColor" ) );
			g2.drawRect( 0, 0, w - 1, h - 1 );

			g2.dispose();
		}
		
		public Insets getBorderInsets(Component c) { 
			return ((JInternalFrame) c).isMaximum() ? MAXIMIZED_INSETS : NORMAL_INSETS;
		}
	}

	
	
	
	/**
	 * 
	 * A single line border for MenuBar
	 * 
	 */
	private static class MenuBarBorder extends AbstractBorder {
		private static final Insets INSETS  = new Insets(1, 2, 1, 2);

		public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
			Graphics g2 = g.create();

			g2.setColor( UIManager.getColor( "MenuBar.borderColor" ) );
			g2.drawLine( 0, h-1, w, h-1);

			g2.dispose();
		}

		public Insets getBorderInsets(Component c) { return INSETS; }
	}




	/**
	 * 
	 * A single line border for MenuItem
	 * 
	 */
	private static class MenuItemBorder extends AbstractBorder {
		private static final Insets INSETS  = new Insets(1, 2, 1, 2);

		public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
			//g.setColor( new java.awt.Color( 55, 55, 55 ) );
			//g.drawRect( 0, 0, w-1, h-1);
		}

		public Insets getBorderInsets(Component c) { return INSETS; }
	}




	/**
	 * 
	 * 
	 */
	private static class MenuBorder extends AbstractBorder {
		private static final Insets INSETS  = new Insets(0, 1, 0, 0);

		public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
			Graphics g2 = g.create();

			g2.setColor( new java.awt.Color( 155, 155, 155, 255 ) );
			g2.drawRect( x, y, w, h );

			g2.dispose();
		}

		public Insets getBorderInsets(Component c) { return INSETS; }
	}


	
	
	/**
	 * 
	 * 
	 */
	private static class PopupMenuBorder extends AbstractBorder {
		private static final Insets INSETS  = new Insets( 1, 1, 2, 1 );

		public void paintBorder( Component c, Graphics g, int x, int y, int w, int h ) {
			Graphics g2 = g.create();

			g2.setColor( new Color( 155, 155, 155 ) );
			g2.drawRect( x, y, w-1, h-1 );

			g2.dispose();
		}

		public Insets getBorderInsets( Component c ) { return INSETS; }
	}




	/**
	 * 
	 * 
	 */
	private static class ProgressBarBorder extends AbstractBorder {
		private static final Insets INSETS  = new Insets( 2, 2, 2, 2 );

		public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
			Graphics g2 = g.create();

			g2.setColor( UIManager.getColor( "ProgressBar.borderColor") );
			g2.drawRect( x, y, w-1, h-1 );

			g2.dispose();
		}

		public Insets getBorderInsets( Component c ) { return INSETS; }
	}

	
	
	
	/**
	 * 
	 * 
	 */
	private static class SpinnerBorder extends AbstractBorder {
		private static final Insets INSETS  = new Insets( 1, 1, 1, 1 );

		public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
			Graphics g2 = g.create();

			g2.setColor( new Color( 155, 155, 155 ) );
			g2.drawRect( x, y, w-1, h-1 );

			g2.dispose();
		}

		public Insets getBorderInsets( Component c ) { return INSETS; }
	}

	
	
	
	/**
	 * 
	 * A border used for <code>TableHeader</code>s.
	 * 
	 */
	private static class TableHeaderCellBorder extends AbstractBorder implements UIResource {
		public void paintBorder( Component c, Graphics g, int x, int y, int w, int h ) {
			Graphics g2 = g.create();

			g2.setColor( UIManager.getColor( "TableHeader.gridColor" ) );

			//g.drawLine( 0, 0, 0, h );			// Left Line
			//g.drawLine( w-1, 0, w-1, h );		// Right Line
			g2.drawRect( 0, h-1, w, h-1 );		// Bottom Line

			g2.dispose();
		}
	}

	
	
	
	/**
	 * 
	 * 
	 */
	private static class ToolBarBorder extends AbstractBorder {
		private static Insets insets  = new Insets( 0, 0, 20, 20 );

		public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
			/*Graphics g2 = g.create();

			int borderY = c.getHeight() - insets.bottom;
			int borderW = c.getWidth()  - insets.right;

			JToolBar t	= (JToolBar)c;
			if( t.getOrientation() == JToolBar.HORIZONTAL ) {
				g2.setColor( new Color( 0, 0, 0, 60 ) );
				g2.drawLine( 0, borderY, w, borderY );
			} else if( t.getOrientation() == JToolBar.VERTICAL ) {
				g2.setColor( new Color( 0, 0, 0, 60 ) );
				g2.drawLine( borderW, 2, borderW, c.getHeight() );
			} 

			g2.dispose();*/
		}

		public Insets getBorderInsets( Component c ) { 
			JToolBar t	= (JToolBar)c;

			// If floatable make space for "toolbar drag button"
			if( t.isFloatable() ) {
				if( t.getOrientation() == JToolBar.HORIZONTAL ) {
					insets.left = 12;
					insets.top	= 0;
				} else if( t.getOrientation() == JToolBar.VERTICAL ) {
					insets.left = 0;
					insets.top	= 12;
				}
			}
			return insets;
		}
	}




	/**
	 * 
	 * 
	 */
	private static class ToolBarButtonBorder extends AbstractBorder {
		private static final Insets INSETS  = new Insets( 2, 4, 2, 4 );

		public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {}
		public Insets getBorderInsets( Component c ) { return INSETS; }
	}

	
	
	
	/**
	 * 
	 * 
	 */
	private static class ToolBarSelectedButtonBorder extends AbstractBorder {
		private static final Insets INSETS  = new Insets( 2, 4, 2, 4 );

		public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
			Graphics g2 = g.create();
			
			g2.setColor( new java.awt.Color( 155, 155, 155, 255 ) );

			// Calculate y pos of border
			int componentHeight = c.getHeight() - ((((javax.swing.JComponent)c).getInsets().bottom) + (((javax.swing.JComponent)c).getInsets().top));
			int bottomInsets = componentHeight + ((((javax.swing.JComponent)c).getInsets().top*2));

			g2.setColor( new Color( 170, 170, 170 ) );
			g2.drawRect( 0, 0, c.getWidth()-1, bottomInsets-1 );

			//g2.drawLine( 0, 0, 0, bottomInsets );							// Left Line
			//g2.drawLine( c.getWidth()-2, 0, c.getWidth()-2, bottomInsets );
			//g2.setColor( new java.awt.Color( 245, 245, 245 ) );
			//g2.drawLine( 1, 0, 1, bottomInsets );
			//g2.drawLine( c.getWidth()-1, 0, c.getWidth()-1, bottomInsets );	// Right Line

			g2.dispose();
		}

		public Insets getBorderInsets( Component c ) { 
			return INSETS;
		}
	}




	/**
	 * 
	 * 
	 */
	private static class ToolBarSelectedToggleButtonBorder extends AbstractBorder {
		private static final Insets INSETS  = new Insets( 2, 4, 2, 4 );

		public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
			Graphics g2 = g.create();
			
			g2.setColor( new java.awt.Color( 155, 155, 155 ) );

			// Calculate y pos of border
			int componentHeight = c.getHeight() - ((((javax.swing.JComponent)c).getInsets().bottom) + (((javax.swing.JComponent)c).getInsets().top));
			int bottomInsets = componentHeight + ((((javax.swing.JComponent)c).getInsets().top*2));

			g2.setColor( new Color( 170, 170, 170 ) );
			g2.drawRect( 0, 0, c.getWidth()-1, bottomInsets-1 );

			//g2.drawLine( 0, 0, 0, bottomInsets );							// Left Line
			//g2.drawLine( c.getWidth()-2, 0, c.getWidth()-2, bottomInsets );
			//g2.setColor( new java.awt.Color( 245, 245, 245 ) );
			//g2.drawLine( 1, 0, 1, bottomInsets );
			//g2.drawLine( c.getWidth()-1, 0, c.getWidth()-1, bottomInsets );	// Right Line

			g2.dispose();

			/*Graphics g2 = g.create();

			g2.setColor( Color.red );
			g2.fillRect( x, h-1, w-1, h-1 );

			g2.setColor( new Color( 155, 155, 155 ) );
			g2.drawRect( x, h-1, w-1, h-1 );

			g2.dispose();*/
		}

		public Insets getBorderInsets( Component c ) { return INSETS; }
	}

	
	
	
	/**
	 * 
	 * 
	 */
	private static class ToolBarToggleButtonBorder extends AbstractBorder {
		private static final Insets INSETS  = new Insets( 2, 4, 2, 4 );

		public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
			Graphics g2 = g.create();

			AbstractButton b = (AbstractButton)c;
			if( b.isSelected() ) {
				g2.setColor( new Color( 155, 155, 155 ) );
				g2.drawRect( x, y, w-1, h-1 );
			}

			g2.dispose();
		}

		public Insets getBorderInsets( Component c ) { return INSETS; }
	}

	
	
	
	/**
	 * 
	 * 
	 */
	private static class ToolTipBorder extends AbstractBorder {
		private static final Insets INSETS  = new Insets( 4, 4, 4, 4 );

		public void paintBorder( Component c, Graphics g, int x, int y, int w, int h ) {
			Graphics g2 = g.create();

			g2.setColor( new java.awt.Color( 0, 0, 0 ) );
			g2.drawRect( c.getX(), c.getY(), c.getWidth()-1, c.getHeight()-1 );

			g2.dispose();
		}

		public Insets getBorderInsets(Component c) { return INSETS; }
	}
}
