/*
 * Copyright (c) 2005, the JUNG Project and the Regents of the University of
 * California All rights reserved.
 *
 * This software is open-source under the BSD license; see either "license.txt"
 * or http://jung.sourceforge.net/license.txt for a description.
 *
 * Created on Aug 15, 2005
 */

package edu.uci.ics.jung.visualization.control;

import java.awt.event.MouseWheelEvent;
import java.awt.geom.Point2D;

import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.transform.MutableTransformer;

/**
 * Overrides ViewScalingGraphMousePlugin so that mouse events in
 * the satellite view cause view scaling in the main view
 * 
 * @see ViewScalingGraphMousePlugin
 * @author Tom Nelson - RABA Technologies
 *
 */
public class SatelliteViewScalingGraphMousePlugin extends
        ViewScalingGraphMousePlugin {

    public SatelliteViewScalingGraphMousePlugin() {
        super();
    }

    public SatelliteViewScalingGraphMousePlugin(int modifiers) {
        super(modifiers);
    }
    
    public SatelliteViewScalingGraphMousePlugin(float in, float out) {
        super(in, out);
    }
    
    public SatelliteViewScalingGraphMousePlugin(int modifiers, float in,
            float out) {
        super(modifiers, in, out);
    }
    
    /**
     * zoom the display in or out, depending on the direction of the
     * mouse wheel motion.
     */
    public void mouseWheelMoved(MouseWheelEvent e) {
        boolean accepted = checkModifiers(e);
        if(accepted == true) {
            VisualizationViewer vv = (VisualizationViewer)e.getSource();
            if(vv instanceof SatelliteVisualizationViewer) {
                VisualizationViewer vvMaster = 
                    ((SatelliteVisualizationViewer)vv).getMaster();
                
                MutableTransformer viewTransformerMaster = vvMaster.getViewTransformer();
                
                Point2D center = vvMaster.getCenter();
                int amount = e.getWheelRotation();
                
                if(amount > 0) {
                    viewTransformerMaster.scale(in, in, center);
                } else if(amount < 0) {
                    viewTransformerMaster.scale(out, out, center);
                }
                
                e.consume();
                vv.repaint();
            }
        }
    }


}
