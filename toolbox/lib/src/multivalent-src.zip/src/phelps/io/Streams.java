package phelps.io;

import java.io.*;
//import java.util.zip.GZIPInputStream;	// i/o all over: .io, .net, .util



/**
	Utility methods for {@link java.io.InputStream}s and {@link java.io.OutputStream}s.

	<ul>
	<li>{@link #copy(InputStream, OutputStream)}
	</ul>

	@version $Revision: 1.4 $ $Date: 2003/10/13 06:20:27 $
*/
public class Streams {
  private Streams() {}


  /** Convenience method for <code>copy(in, out, false)</code>. */
  public static long copy(InputStream in, OutputStream out) throws IOException { return copy(in, out, false); }

  public static long copy(InputStream in, OutputStream out, boolean fclose) throws IOException { return copy(in, out, fclose, Integer.MAX_VALUE); }

  /**
	Copy contents of <var>in</var> to <var>out</var>.
	If <var>fclose</var> is <code>true</code> then close both streams,
	so a stream-to-stream copy is as simple as <code>copy(new InputStream(), new OutputStream(), true)</code>.
	Neither stream needs to be buffered as block reads and writes are used (which is all that buffered streams do).
	@return number of bytes copied
  */
  public static long copy(InputStream in, OutputStream out, boolean fclose, int length) throws IOException {
	byte[] buf = new byte[Math.min(length, Files.BUFSIZ)];
	long len = 0L;

	try {
		for (int togo = length, hunk; togo > 0 && (hunk = in.read(buf, 0, Math.min(togo,buf.length)))>=0; togo -= hunk) {
			out.write(buf, 0, hunk);
			len += hunk;
		}
	} catch (IOException ioe) { throw new IOException(ioe.getMessage()+" @ "+len); }

	if (fclose) {
		out.close();
		in.close();
	}

	return len;
  }
}
