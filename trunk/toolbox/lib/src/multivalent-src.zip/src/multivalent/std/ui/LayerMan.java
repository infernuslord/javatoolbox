package multivalent.std.ui;

import java.io.*;
//import java.awt.Graphics;
//import java.awt.Color;
import java.util.*;

import multivalent.*;


/**
	<i>Placeholder for future work</i>
	Manage {@link Layer}s: create new, remove, save, toggle active, ....

	<p>To do
	<ul>
	<li>create new layer (take name, save to)
	<li>load layer from network
	<li>remove current layer
	<li>list of layers, toggle on/off
	<li>list of layers, pick active
	<li>save current layer
	<li>set active layer
	</ul>

	@version $Revision$ $Date$
*/
public class LayerMan extends Behavior {
}
