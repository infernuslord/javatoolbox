package tool.pdf;

import java.util.Date;
import java.io.IOException;
import java.io.File;
import java.io.PrintStream;
import java.io.InputStream;
import java.util.*;
import java.awt.Rectangle;

import multivalent.std.adaptor.pdf.*;
import multivalent.ParseException;
import multivalent.std.adaptor.pdf.Fonts;
import static multivalent.std.adaptor.pdf.COS.*;
import static multivalent.std.adaptor.pdf.SecurityHandlerStandard.*;

import phelps.io.FileList;
import phelps.io.Files;
import phelps.lang.Strings;
import phelps.lang.Integers;
import phelps.util.Units;
import phelps.awt.geom.Rectangles2D;



/**
	Report various information.

	@author Copyright (c) 2002 - 2004  Thomas A. Phelps
	@version $Revision: 1.13 $ $Date: 2004/02/05 23:07:26 $
*/
public class Info {
  static final boolean DEBUG = true;

  public static final String VERSION = "1.2 of $Date: 2004/02/05 23:07:26 $";
  public static final String USAGE = "java tool.pdf.Info [information] [options] <PDF-file-or-directory...>\n"
	+ "\tinfo: [-general] [-image] [-anno] [-fonts] [-objects] [-content]\n"
	// + [-java]
	+ "\toptions: [-label] [-password <password>]";

  private static final String[] KEYS_TXT = { "Title", "Author", "Subject", "Keywords", "Creator", "Producer" };
	//"CreationDate", "ModDate", "Trapped", "Metadata"
  private static final String[] CLASS_NAMES = { "null", "iref 0 R", "<<dict>>", "[array]", "/name", "(string)", "double", "long", "boolean", "data" };

  private static final List<Class> DATA_TYPES = Collections.unmodifiableList(Arrays.asList(new Class[] { null, CLASS_IREF, CLASS_DICTIONARY, CLASS_ARRAY, CLASS_NAME, CLASS_STRING, CLASS_REAL, CLASS_INTEGER, CLASS_BOOLEAN, CLASS_DATA }));

  private static final String FONT_HEADER = "FONT NAME                        TYPE          ENCODING      EMB SUB UNI   OBJ#  #glyphs  pages";

  private static class Stat {
	int cnt = 0;
	int space = 0;
	int wasted = 0;
	int size = 0;
	int min = Integer.MAX_VALUE;
	int max = Integer.MIN_VALUE;
	// compute avg len

	public String toString() {
		String rep = "#"+cnt+", use="+space;
		if (wasted>0) rep += ", of which waste="+wasted;
		if (size>0) rep += ", min/avg/max="+min+".."+(size/cnt)+".."+max;
		return rep;
	}
  }

  static class FontInfo {
	String name;
	String type;
	String encoding;
	boolean embedded;
	boolean subset;
	boolean toUnicode;
	int objnum;
	int glyphs;
	String inpages;

	FontInfo(String n, String t, String e, boolean em, boolean sub, boolean uni, int num, int g, String pg) {
		name=n; type=t; encoding=e; embedded=em; subset=sub; toUnicode=uni; objnum=num; glyphs=g; inpages=pg;
	}
  }

  static Comparator<FontInfo> FontInfoByName = new Comparator<FontInfo>() {
	public int compare(FontInfo fi1, FontInfo fi2) { return Strings.DICTIONARY_ORDER.compare(fi1.name, fi2.name); }
  };


  private String password_;
  private boolean fgeneral_, fimage_, fanno_, ffont_, fobjects_, fcontent_, fjava_, fhist_;
  private String label_ = null;
  private boolean flabel_;
  private File dirbase_ = new File(".").getAbsoluteFile();
  private boolean fverbose_, fquiet_;
  private PrintStream out_;


  public Info() {
	defaults();
  }

  public void defaults() {
	password_ = null;
	fgeneral_ = fimage_ = fanno_ = ffont_ = fobjects_ = fcontent_ = fjava_ = fhist_ = false;
	flabel_ = false;

	fverbose_ = fquiet_ = false;
	out_ = phelps.io.PrintStreams.DEVNULL;
  }

  public void setOut(PrintStream out) { out_ = out!=null? out: phelps.io.PrintStreams.DEVNULL; }



  private void print(String txt) {
	if (flabel_) out_.print(label_);
	if (txt!=null) out_.print(txt);
  }
  private void println(String txt) {
	print(txt);
	out_.println();
  }
  private void println() { println(""); }

  public void info(File file) throws IOException, ParseException {
	assert file!=null;
	PDFReader pdfr = new PDFReader(file);
	info(pdfr);
  }

  public void info(PDFReader pdfr) throws IOException, ParseException {
	if (flabel_) label_ = Files.relative(dirbase_, pdfr.getFile()) + ": ";
	if (!fgeneral_ && !fimage_ && !fanno_ && !ffont_) fgeneral_ = true;

	pdfr.setPassword(password_);
	pdfr.setExact(true);    // don't zap "/Type"

	if (fgeneral_) general(pdfr);

	pdfr.fault();
	if (fimage_) image(pdfr);
	if (fanno_) anno(pdfr);
	if (ffont_) font(pdfr);
	if (fobjects_) objects(pdfr);
	if (fcontent_) content(pdfr);
	if (fjava_) profileJava(pdfr);

	pdfr.close();
  }



  /**
	Extract various information from /Catalog and /Info dictionaries.
  */
  void general(PDFReader pdfr) throws IOException {
	Dict trailer = pdfr.getTrailer();
	Dict cat = pdfr.getCatalog();    // could have followed link from trailer

	Dict info = (Dict)pdfr.getInfo();
	if (info!=null) {
		Object val;
		for (int i=0,imax=KEYS_TXT.length; i<imax; i++) {
			String key = KEYS_TXT[i];
			val = pdfr.getObject(info.get(key));
			if (val != null) println(key+": "+val);
		}

		long create=-1L, mod;
		if ((val = pdfr.getObject(info.get("CreationDate"))) != null) {
			try {
				create = parseDate((StringBuffer)val, false);
				println("Created: "+new Date(create));
			} catch (InstantiationException ignore) {}
		}
		if ((val = pdfr.getObject(info.get("ModDate"))) != null) {
			try {
				mod = parseDate((StringBuffer)val, false);
				if (mod != create) println("Modified: "+new Date(mod));
			} catch (InstantiationException ignore) {}
		}
	}

	println("Page count: "+pdfr.getPageCnt());
	println("PDF version: "+pdfr.getMajorVersion()+"."+pdfr.getMinorVersion());   // updated by /Catalog's /Version

	if (cat.get("Outlines")!=null) println("outline");
	if (cat.get("Metadata")!=null) println("metadata");
	if (cat.get("StructTreeRoot")!=null) println("structured");
	if (cat.get("SpiderInfo")!=null) println("converted from HTML");
	if (cat.get("AcroForm")!=null) println("forms");
	//if () println("linearized");

	if (pdfr.getLinearized()>0) {
		Dict dict = (Dict)pdfr.getObject(pdfr.getLinearized());
		println("Linearized: version "+dict.get("Linearized"));
	}

	multivalent.std.adaptor.pdf.Encrypt e = pdfr.getEncrypt();
	//CryptFilter cf = e.getStrF();
	Dict edict = (Dict)pdfr.getObject(trailer.get("Encrypt"));
	SecurityHandler sh = e.getSecurityHandler();
	//if (cf!=CryptFilter.IDENTITY) {
	if (sh != SecurityHandler.IDENTITY) {
		print("Encrypted: filter ");
		if (sh instanceof SecurityHandlerStandard) {
			SecurityHandlerStandard shs = (SecurityHandlerStandard)sh;
			int R=shs.getR(), P=shs.getP();
			println("Standard (revision "+R+"), "+shs.getLength()+"-bit key" + (sh.isAuthorized()? ", null password": ""));

			if ((PERM_ALL & P) != PERM_ALL) {
				print("    restrictions:");
				if ((PERM_PRINT & P) == 0) out_.print("  print");
				if ((PERM_MODIFY & P) == 0) out_.print("  modify");
				if ((PERM_COPY & P) == 0) out_.print("  copy/extract");
				if ((PERM_ANNO & P) == 0) out_.print("  annotate");
				if (R<3 || (PERM_FILL & P) == 0) out_.print("  fill forms");
				if (R<3 || (PERM_COPY_R3 & P) == 0) out_.print("  accessibility");
				if (R<3 || (PERM_ASSEMBLE & P) == 0) out_.print("  assemble");
				if (R>=3 && (PERM_PRINT_GOOD & P) == 0) out_.print("  high-quality print");
				println();
			}

		} else {
			//Dict edict = e.toDictionary();
			println(edict.get("Filter")+", " + (sh.isAuthorized()? ", null password": ""));
		}
	}

	Dict comp = (Dict)trailer.get(KEY_COMPRESS);
	if (comp!=null) {
		StringBuffer sb = new StringBuffer(80);
		sb.append("Compressed:");
		Number oldlen = (Number)comp.get(KEY_COMPRESS_LENGTHO);
		if (oldlen != null) {
			int newlen = (int)pdfr.getFile().length();
			sb.append(" ").append((oldlen.intValue() - newlen) * 100 / oldlen.intValue()).append("%");
		}
		Object o;;
		if ((o = comp.get(KEY_COMPRESS_FILTER))!=null) sb.append(", ").append(o).append(" format");
		if ((o = comp.get(KEY_COMPRESS_VERSION)) != null) sb.append(" v").append(o);
		if ((o = comp.get("Producer")) !=null) sb.append(", by ").append(o);
		println(sb.toString());
	}

	String xml = pdfr.getMetadata(cat);
	if (xml.length()>0) println(xml);
  }



  /**
	Scan all objects looking for Image XObjects.
  */
  void image(PDFReader pdfr) throws IOException {
	for (int i=0,imax=pdfr.getObjCnt(); i<imax; i++) {
		Object o = pdfr.getObject(i);
		if (CLASS_DICTIONARY != o.getClass()) continue;
		Dict dict = (Dict)o;
		Object type = pdfr.getObject(dict.get("Type")), subtype = pdfr.getObject(dict.get("Subtype"));
		if (("XObject".equals(type) || type==null) && "Image".equals(subtype)) {
			print("image: object "+i+", "+pdfr.getObject(dict.get("Width"))+"x"+pdfr.getObject(dict.get("Height")));
			String filter = Images.getFilter(dict, pdfr);
			out_.print(", "+(filter!=null? filter: "raw samples"));
			println(", length = "+pdfr.getObject(dict.get("Length")));
		}
	}
  }



  /**
	Iterate over pages for annotations.
  */
  void anno(PDFReader pdfr) throws IOException, ParseException {
	for (int i=0,imax=pdfr.getPageCnt(); i<imax; i++) {
		Dict page = (Dict)pdfr.getObject(pdfr.getPageRef(i+1));

		Object[] anno = (Object[])pdfr.getObject(page.get("Annots"));
		if (anno == null) continue;

		for (int j=0,jmax=anno.length; j<jmax; j++) {
			print("anno: page "+(i+1)+", ");
			Object o = anno[j];
			if (CLASS_IREF == o.getClass()) out_.print("object "+((IRef)o).id+", ");
			Dict dict = (Dict)pdfr.getObject(anno[j]);
			Object subtype = pdfr.getObject(dict.get("Subtype"));
			out_.print(subtype);
			o = pdfr.getObject(dict.get("Rect"));
			if (o!=null) out_.print(", bounds "+Rectangles2D.pretty(array2Rectangle((Object[])o, null)));
			//if ("Link".equals(subtype)) { // show destination of link
			println();
		}
	}
  }



  void font(PDFReader pdfr) throws IOException, ParseException {
	int objcnt = pdfr.getObjCnt();

	Set[] obj2page = new Set[objcnt];
	for (int i=0,imax=pdfr.getPageCnt(); i<imax; i++) {
		Dict page = pdfr.getPage(i+1);
		Dict res = (Dict)pdfr.getObject(page.get("Resources")); if (res==null) continue;
		Dict fonts = (Dict)pdfr.getObject(res.get("Font")); if (fonts==null) continue;
		for (Iterator<Object> j = fonts.values().iterator(); j.hasNext(); ) {
			IRef pg = (IRef)j.next();
			int objnum = pg.id;
			if (obj2page[objnum]==null) obj2page[objnum] = new HashSet<Integer>(5);
			obj2page[objnum].add(Integers.getInteger(i+1));
		}
	}

	List<FontInfo> l = new ArrayList<FontInfo>(50);
	for (int i=0+1; i<objcnt; i++) {
		Object o = pdfr.getObject(i);
		if (CLASS_DICTIONARY != o.getClass()) continue;
		Dict dict = (Dict)o;
		if (!"Font".equals(pdfr.getObject(dict.get("Type")))) continue;

		// 1. collect data
		String sub = (String)pdfr.getObject(dict.get("Subtype"));
		boolean fem = "Type3".equals(sub) || "Type0".equals(sub);

		String basefont = (String)pdfr.getObject(dict.get("BaseFont"));
		if (basefont==null) basefont = "<none>";
		boolean fsub = false;
		if (Fonts.isSubset(basefont)) {
			fsub = true;	// Ghostscript 6.0 produces subsets LACKING "SIXCAP+" convention
			//fem = true; => check /FontFile.  should agree
			basefont = basefont.substring("SIXCAP+".length());
		}

		Dict fdesc = (Dict)pdfr.getObject(dict.get("FontDescriptor"));
		String subsub = null;
		Object emref=null;
		if (fdesc!=null) {
			if ((emref=fdesc.get("FontFile"))!=null || (emref=fdesc.get("FontFile2"))!=null || (emref=fdesc.get("FontFile3"))!=null) {
				Dict edict = (Dict)pdfr.getObject(emref);
				subsub = (String)edict.get("Subtype");
				fem = true;
			}
			if (fdesc.get("Charset")!=null) fsub = true;
		}

		Object en = pdfr.getObject(dict.get("Encoding"));
		String enc = en==null? "<intrinsic>": CLASS_NAME==en.getClass()? (String)en: "<custom>";
		int inx = enc.indexOf("Encoding"); if (inx>0) enc = enc.substring(0,inx);
		boolean funi = dict.get("ToUnicode")!=null; //|| dict.get("Widths")==null;// || core 14
		int glyphs = -1;
		if ("Type3".equals(sub)) {
			Dict cp = (Dict)pdfr.getObject(dict.get("CharProcs"));
			glyphs = cp.size();
		} else if ("Type1".equals(sub) || "TrueType".equals(sub)) {
			Object[] oa = (Object[])pdfr.getObject(dict.get("Widths"));
			if (oa!=null) { glyphs=0; for (Object w: oa) if (((Number)w).intValue() != 0) glyphs++; }
		}

		String inpages;
		Set<Integer> o2p = obj2page[i]; int pcnt = o2p!=null? o2p.size(): 0;
		if (pcnt==0) inpages = "*unused*";
		else if (pcnt==1) inpages = o2p.iterator().next().toString();
		else {
			int[] nums = new int[pcnt];
			int k=0; for (Iterator<Integer> j = o2p.iterator(); j.hasNext(); ) nums[k++] = j.next().intValue();
			Arrays.sort(nums);
			inpages = Units.toRange(nums);
		}

		l.add(new FontInfo(basefont, subsub!=null? subsub: sub, enc, fem, fsub, funi, i, glyphs, inpages));
	}		


	// 2. output
	FontInfo[] fontinfo = l.toArray(new FontInfo[l.size()]);
	Arrays.sort(fontinfo, FontInfoByName);

	if (fontinfo.length > 0) println(FONT_HEADER.substring(0, !fverbose_? 80: FONT_HEADER.length()));
	for (int i=0,imax=fontinfo.length; i<imax; i++) {
		FontInfo fi = fontinfo[i];
		StringBuffer sb = new StringBuffer(80);
		sb.append(fi.name); tab(sb, FONT_HEADER.indexOf("TYPE"));
		sb.append(fi.type); //if (subsub!=null) sb.append(" / ").append(subsub);
		tab(sb, FONT_HEADER.indexOf("ENC"));
		sb.append(fi.encoding); tab(sb, FONT_HEADER.indexOf("EMB"));

		if (!fi.embedded && Fonts.isCore14(fi.name)) {
			sb.append("--core 14--");
		} else {
			sb.append(" ").append(fi.embedded? "Y": "N").append("  ");
			if (!fi.embedded || "Type3".equals(fi.type) || "Type0".equals(fi.type)) sb.append("n/a ");
			else sb.append(" ").append(fi.subset? "Y": "N").append("  ");
			sb.append(" ").append(fi.toUnicode? "Y": "N").append(" ");
		}

		right(sb, 7, fi.objnum);

		if (fverbose_) {
			tab(sb, FONT_HEADER.indexOf("#gly"));
			if (fi.glyphs>=0) right(sb, 7, fi.glyphs);
			tab(sb, FONT_HEADER.indexOf("pages"));
			sb.append(fi.inpages);
		}

		println(sb.toString());
	}
  }



  void objects(PDFReader pdfr) throws IOException {
	int objcnt = pdfr.getObjCnt();
	int fontcnt=0, t1fontcnt=0, ttfontcnt=0, t3fontcnt=0, ofontcnt=0, emfontcnt=0;
	int imgcnt=0, formcnt=0, pscnt=0;
	int thumbcnt=0;
	int annocnt=0, linkcnt=0;
	List<Object> fonts = new ArrayList<Object>(20);

	// count fonts, images, annotations, ...
	for (int i=1; i<objcnt; i++) {
		Object o = pdfr.getObject(i);

		if (o!=null && o.getClass() == CLASS_DICTIONARY) {
			Dict dict = (Dict)o;
			String type=(String)dict.get("Type"), subtype=(String)dict.get("Subtype");
			if ("Font".equals(type)) {
				fontcnt++;
				fonts.add(dict.get("BaseFont"));
				if ("Type1".equals(subtype)) t1fontcnt++;
				else if ("TrueType".equals(subtype)) ttfontcnt++;
				else if ("Type3".equals(subtype)) t3fontcnt++;
				else ofontcnt++;

			} if ("FontDescriptor".equals(type)) {
				if (dict.get("FontFile")!=null || dict.get("FontFile2")!=null || dict.get("FontFile3")!=null) emfontcnt++;

			} else if ("XObject".equals(type)) {
				if ("Image".equals(subtype)) imgcnt++;
				else if ("Form".equals(subtype)) formcnt++;

			} else if ("Page".equals(type)) {
				if (dict.get("Thumb")!=null) thumbcnt++;
			} else if ("Annot".equals(type)) {
				annocnt++;
				if ("Link".equals(subtype)) linkcnt++;
			}
		}
	}

	// count characters and words
	// case 'Tj': case 'TJ': case '\'': case '"': ...


	// report
	System.out.println(objcnt+" objects");
	if (fontcnt>0) {
		System.out.print("\t"+fontcnt+" fonts:  ");
		if (t1fontcnt>0) System.out.print(t1fontcnt+" Type 1   ");
		if (ttfontcnt>0) System.out.print(ttfontcnt+" TrueType   ");
		if (t3fontcnt>0) System.out.print(t3fontcnt+" Type 3   ");
		if (emfontcnt>0) System.out.print(emfontcnt+" embedded   ");
		System.out.print(fonts);
		System.out.println();
	}
	if (imgcnt>0) System.out.println(imgcnt+" images");
	if (formcnt>0) System.out.println(formcnt+" forms");
	if (thumbcnt>0) System.out.println(thumbcnt+" thumbnails");
	if (annocnt>0) {
		System.out.print("\t"+annocnt+" annotations:   ");
		if (linkcnt>0) System.out.print(linkcnt+" hyperlinks   ");
		System.out.println();
	}
  }



  void content(PDFReader pdfr) throws IOException {
	// counts of command usage
	Object[] oa1 = new Object[1];

	Map<String,Stat> counts = new HashMap<String,Stat>(150);
	for (int i=0,imax=pdfr.getPageCnt(); i<imax; i++) {
		//if (!Quiet) System.out.print(i+" ");  // pretty quick

		Dict pagedict = (Dict)pdfr.getObject(pdfr.getPageRef(i+1));
		InputStreamComposite in = pdfr.getInputStream(pagedict.get("Contents"), true);

		StringBuffer sb = new StringBuffer(4*1024);
		for (int c; (c=in.peek())!=-1; ) {
			if (!Character.isLetter((char)c) && c!='\'' && c!='"') {     // OPERAND
				//ops[opsi++] =
				pdfr.readObject(in);

			} else {    // OPERATOR
				String op = (String)pdfr.readObject(in);

				// add to count -- well, there are worse ways
				Stat stat = (Stat)counts.get(op);
				if (stat==null) counts.put(op, new Stat());
				else stat.cnt++;
			}
		}
		in.close();
	}

	System.out.println("Content streams command usage:");
	for (Iterator<Map.Entry<String,Stat>> hi=counts.entrySet().iterator(); hi.hasNext(); ) {
		Map.Entry<String,Stat> e = hi.next();
		String cmd=e.getKey();
		int cnt = e.getValue().cnt;
		System.out.print(cmd+" "+cnt+"   ");
	}
	System.out.println();
  }



  void profileJava(PDFReader pdfr) throws IOException {
	Stat[] stats = new Stat[DATA_TYPES.size()];
	for (int i=0,imax=DATA_TYPES.size(); i<imax; i++) stats[i] = new Stat();
	int objcnt = pdfr.getObjCnt();
	profileJava(pdfr.getTrailer(), stats, new boolean[objcnt]);
//System.out.println("trailer = "+pdfr.getTrailer());

	// report
	for (int i=0,imax=DATA_TYPES.size(); i<imax; i++) {
		System.out.println(CLASS_NAMES[i]+" "+stats[i]);
	}
  }

  protected void profileJava(Object o, Stat[] stats, boolean[] seen) throws IOException {
	Class cl = (o!=null? o.getClass(): null);
	int inx = DATA_TYPES.indexOf(cl);
	Stat stat = stats[inx];
	stat.cnt++;
	stat.space += 4;    // handle to object

	if (CLASS_IREF == cl) {    // only way to reference!
		stat.space += 4*2;
		stat.wasted += 4;   // gen
		// none wasted, size/min/max n/a

		int id = ((IRef)o).id;
		if (!seen[id]) {   // don't cycle
			seen[id] = true;
			//RESTORE: profileJava(pdfr_.getObject(id), stats, seen);
		}

	} else if (CLASS_ARRAY == cl) {     // array
		Object[] oa = (Object[])o;

		int len = oa.length;
		stat.space += len*4 + 4/*length "field"*/;
		// none wasted
		stat.size += len; stat.min=Math.min(stat.min, len); stat.max=Math.max(stat.max, len);

		for (int i=0,imax=oa.length; i<imax; i++) profileJava(oa[i], stats, seen);

	} else if (CLASS_DICTIONARY == cl) {  // dictionary
		Dict omap = (Dict)o;

		int cap=16, size=omap.size(); while (cap*0.75<size) cap <<= 1;
		stat.space += (4*5/*fields*/) + omap.size() * (4+ 4*4/*Map.Entry = key,val,hash,next*/ + 4*cap/*table length*/);
		stat.wasted += (cap-size)*3;    // *4 bytes * .75 load capacity min
		stat.size += size; stat.min=Math.min(stat.min, size); stat.max=Math.max(stat.max, size);

		for (Iterator<Map.Entry<Object,Object>> i=omap.entrySet().iterator(); i.hasNext(); ) {
			Map.Entry<Object,Object> e = i.next();
			// if (e.getKey()==STREAM_DATA)
			profileJava(e.getValue(), stats, seen);
		}

	} else if (CLASS_NAME == cl) {
		String oname = (String)o;
		int len = oname.length();
		stat.space += len*2 + 4*4/*fields*/; // char[] = 2 bytes per
		stat.size += len; stat.min=Math.min(stat.min, len); stat.max=Math.max(stat.max, len);

	} else if (CLASS_STRING == cl) {
		StringBuffer sb = (StringBuffer)o;
		int cap=sb.capacity(), len=sb.length();
		stat.space += cap*2 + 4*3/*fields*/;
		stat.wasted += (cap-len)*2;
		stat.size += len; stat.min=Math.min(stat.min, len); stat.max=Math.max(stat.max, len);

	} else if (CLASS_REAL == cl) stat.space += 8;
	else if (CLASS_INTEGER == cl) stat.space += 4;
	else if (CLASS_BOOLEAN == cl) stat.space += 4;  // assume aligned

  }



  /**
	Various histograms.  Experimental.
  */
  void hist(PDFReader pdfr) throws IOException {
	for (int i=1,imax=pdfr.getObjCnt(); i<imax; i++) {
		Object o = pdfr.getObject(i);

//System.out.println(1+" "+o);
		// color usage in images from raw samples (non-JPEG, non-FAX, non-JBIG2)
		if (o.getClass() == CLASS_DICTIONARY && "Image".equals(pdfr.getObject(((Dict)o).get("Subtype")))) {
			Dict dict = (Dict)o;
			System.out.print(i+"  "+dict.get("Width")+"x"+dict.get("Height")+", "+dict.get("ColorSpace")+":  ");

			int bpc = ((Number)dict.get("BitsPerComponent")).intValue();
			if (bpc==8) {
				int[] h = new int[256];
				InputStream in = pdfr.getInputStream(dict); for (int c; (c=in.read())!=-1; ) h[c]++; in.close();
				int hcnt = 0; for (int j=0,jmax=h.length; j<jmax; j++) if (h[j]>0) hcnt++;
				Arrays.sort(h);

				//for (int j=0,jmax=h.length; j<imax; j++) if (h[j]>0) System.out.print(Integer.toHexString(j)+"="+h[j]+" ");
				System.out.print("("+hcnt+")  ");
				for (int j=255,jmin=240; j>=jmin; j--) System.out.print(" "+h[j]);
				System.out.println();

			} else System.out.println("bpc = "+bpc);
		}
	}

  }



  private void tab(StringBuffer sb, int col) { for (int i=sb.length(); i<col; i++) sb.append(' '); }
  private void right(StringBuffer sb, int width, int num) {
	String sobj = Integer.toString(num);
	tab(sb, sb.length() + width - sobj.length());
	sb.append(sobj);
  }


  private int commandLine(String[] argv) {
	out_ = System.out;

	int argi = 0, argc = argv.length;
	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.startsWith("-gen"/*"eral"*/)) fgeneral_ = true;
		else if (arg.startsWith("-im"/*"age"*/)) fimage_ = true;
		else if (arg.startsWith("-anno")) fanno_ = true;
		else if (arg.startsWith("-font")) ffont_ = true;
		else if (arg.startsWith("-obj"/*ects*/)) fobjects_ = true;
		else if (arg.startsWith("-con"/*tent*/)) fcontent_ = true;
		else if (arg.startsWith("-prof"/*file*/) || arg.startsWith("-java")) fjava_ = true;
 
		else if (arg.startsWith("-l")) flabel_ = true;
		else if (arg.equals("-password")) password_ = argv[++argi];

		else if (arg.startsWith("-verb")) fverbose_ = true;
		else if (arg.startsWith("-q"/*uiet*/)) fquiet_ = true;
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.equals("-help")) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	if (argi == argc) { System.err.println(USAGE); System.exit(0); }

	return argi;
  }

  public static void main(String[] argv) throws IOException {
	Info info = new Info();
	int argi = info.commandLine(argv);

	for (Iterator<File> i = new FileList(argv, argi, FILTER).iterator(); i.hasNext(); ) {
		File file = i.next();
		if (!info.flabel_) info.println("Filename: "+file);
		try {
			info.info(file);
		} catch (Exception e) {
			System.err.println(file+": "+e);
			if (DEBUG) e.printStackTrace();
		}
	}
	System.exit(0);
  }
}
