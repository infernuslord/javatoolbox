/*
 *   The contents of this file are subject to the Mozilla Public License
 *   Version 1.1 (the "License"); you may not use this file except in
 *   compliance with the License. You may obtain a copy of the License at
 *   http://www.mozilla.org/MPL/
 *
 *   Software distributed under the License is distributed on an "AS IS"
 *   basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 *   License for the specific language governing rights and limitations
 *   under the License.
 *
 *   The Original Code is Matra - the DTD Parser.
 *
 *   The Initial Developer of the Original Code is Conrad S Roche.
 *   Portions created by Conrad S Roche are Copyright (C) Conrad 
 *   S Roche. All Rights Reserved.
 *
 *   Alternatively, the contents of this file may be used under the terms
 *   of the GNU GENERAL PUBLIC LICENSE Version 2 or any later version
 *   (the  "[GPL] License"), in which case the
 *   provisions of GPL License are applicable instead of those
 *   above.  If you wish to allow use of your version of this file only
 *   under the terms of the GPL License and not to allow others to use
 *   your version of this file under the MPL, indicate your decision by
 *   deleting  the provisions above and replace  them with the notice and
 *   other provisions required by the GPL License.  If you do not delete
 *   the provisions above, a recipient may use your version of this file
 *   under either the MPL or the GPL License."
 *
 *   [NOTE: The text of this Exhibit A may differ slightly from the text of
 *   the notices in the Source Code files of the Original Code. You should
 *   use the text of this Exhibit A rather than the text found in the
 *   Original Code Source Code for Your Modifications.]
 *
 * Created: Conrad S Roche <derupe at users.sourceforge.net>,  09-Aug-2003
 */
package com.conradroche.matra.test.data;

import java.util.StringTokenizer;

import com.conradroche.matra.data.ParseableData;
import com.conradroche.matra.test.util.*;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * JUnit test case for the ParseableDataTest class.
 * 
 * @author Conrad Roche
 */
public class ParseableDataTest extends DataTest {

	/**
	 * The ParseableData object being tested.
	 */
	private ParseableData pData;
	
	/**
	 * ParseableData object containing null String value.
	 */
	private ParseableData nullData;
	
	/**
	 * Constructor for ParseableDataTest.
	 * @param arg0
	 */
	public ParseableDataTest(String arg0) {
		super(arg0);
	}

	/**
	 * Returns a test suite with ParseableDataTest.
	 * 
	 * @see com.conradroche.matra.test.data.DataTest#suite()
	 * 
	 * @return
	 */
	public static Test suite() {

		TestSuite suite = new TestSuite();

		suite.addTestSuite(ParseableDataTest.class);

		return suite;
	}
	
	/**
	 * Setup the data for testing.
	 */
	protected void setUp() {
		data = new ParseableData(strData);
		pData = (ParseableData) data;
		nullData = new ParseableData(null);
	}

	/**
	 * Test the  ParseableData::getNextToken() method
	 */
	public void testGetNextToken() {
		
		StringTokenizer tokenizer = new StringTokenizer(strData, " \t\n\r");

		while(tokenizer.hasMoreTokens()) {
			Assert.assertEquals(tokenizer.nextToken(), pData.getNextToken());
			pData.skipWhiteSpace();
		}
		
		//After End of Data
		Assert.assertEquals("", pData.getNextToken());
		
		//Blank Data
		pData.reset();
		Assert.assertEquals("", pData.getNextToken());
		
		//null Data
		Assert.assertEquals("", nullData.getNextToken());
	}

	/**
	 * Test the ParseableData::getNextToken(char[]) method
	 */
	public void testGetNextTokencharArray() {
		
		char[] space = DataValues.getInstance().getSpaceChars();
		
		StringTokenizer tokenizer = new StringTokenizer(strData, " \t\n\r");
		
		while(tokenizer.hasMoreTokens()) {
			Assert.assertEquals(tokenizer.nextToken(), pData.getNextToken(space));
			pData.skipWhiteSpace();
		}

		//After End of Data
		Assert.assertEquals("", pData.getNextToken(space));
		
		//Blank Data
		pData.reset();
		Assert.assertEquals("", pData.getNextToken(space));
		
		//null Data
		Assert.assertEquals("", nullData.getNextToken(space));
	}

	/**
	 * Test the ParseableData::getNextToken(char) method.
	 */
	public void testGetNextTokenchar() {
		
		StringTokenizer tokenizer = new StringTokenizer(strData, "c");
		
		while(tokenizer.hasMoreTokens()) {
			Assert.assertEquals(tokenizer.nextToken(), pData.getNextToken('c'));
		}

		//After End of Data
		Assert.assertEquals("", pData.getNextToken('c'));
		
		//Blank Data
		pData.reset();
		Assert.assertEquals("", pData.getNextToken('c'));
		
		//null Data
		Assert.assertEquals("", nullData.getNextToken('c'));
	}

	/**
	 * Test the ParseableData::skipChars(char[]) method.
	 */
	public void testSkipCharscharArray() {
		
		char[] skip = {'T', 'h', 'c', 'o', 'm', 'p', 'l', 'e', 't', ' ', '\t'};
		
		pData.skipChars(skip);
		Assert.assertEquals(15, pData.getCurrentPosition());
		
		pData.rewind();
		checkIsDataBegin(pData);
		
		pData.skipChars(new char[]{' ', '\t'});
		checkIsDataBegin(pData);
		
		//null char[]
		pData.skipChars(null);
		checkIsDataBegin(pData);

		//empty char[]
		pData.skipChars(new char[]{});
		checkIsDataBegin(pData);
		
		//After End of Data
		pData.skipChars(pData.length());
		Assert.assertEquals(pData.length(), pData.getCurrentPosition());
		
		pData.skipChars(skip);
		Assert.assertEquals(pData.length(), pData.getCurrentPosition());

		//Blank data
		pData.reset();
		checkIsDataBegin(pData);
		
		pData.skipChars(skip);
		checkIsDataBegin(pData);
		
		pData.skipChars(new char[]{' ', '\t'});
		checkIsDataBegin(pData);
		
		pData.skipChars(null);
		checkIsDataBegin(pData);

		pData.skipChars(new char[]{});
		checkIsDataBegin(pData);
		
		//null data
		nullData.reset();
		
		nullData.skipChars(skip);
		Assert.assertEquals(0, nullData.getCurrentPosition());
		
		nullData.skipChars(new char[]{' ', '\t'});
		Assert.assertEquals(0, nullData.getCurrentPosition());
		
		nullData.skipChars(null);
		Assert.assertEquals(0, nullData.getCurrentPosition());

		nullData.skipChars(new char[]{});
		Assert.assertEquals(0, nullData.getCurrentPosition());
	}

	/**
	 * Test the ParseableData::skipChars(int) method.
	 */
	public void testSkipCharsint() {
		
		pData.skipChars(0);
		checkIsDataBegin(pData);
		
		pData.skipChars(10);
		Assert.assertEquals(10, pData.getCurrentPosition());

		pData.skipChars(strData.length());
		Assert.assertEquals(strData.length(), pData.getCurrentPosition());
		
		pData.rewind();
		pData.skipChars(strData.length());
		Assert.assertEquals(strData.length(), pData.getCurrentPosition());
		
		pData.rewind();
		pData.skipChars(strData.length() + 10);
		Assert.assertEquals(strData.length(), pData.getCurrentPosition());
		
		//Blank data
		pData.reset();
		
		pData.skipChars(0);
		checkIsDataBegin(pData);
		
		pData.skipChars(10);
		checkIsDataBegin(pData);
		
		//null Data
		nullData.skipChars(0);
		Assert.assertEquals(0, nullData.getCurrentPosition());
		
		nullData.skipChars(10);
		Assert.assertEquals(0, nullData.getCurrentPosition());
	}

	/**
	 * Test the ParseableData::skipWhiteSpace method.
	 */
	public void testSkipWhiteSpace() {
		
		pData.skipWhiteSpace();
		Assert.assertEquals(0, pData.getCurrentPosition());
		
		pData.skipChars("The".length());
		Assert.assertEquals(3, pData.getCurrentPosition());
		
		pData.skipWhiteSpace();
		Assert.assertEquals(5, pData.getCurrentPosition());
		
		ParseableData spaceOnly = new ParseableData(" \t\n\r\r\n\t ");
		checkIsDataBegin(spaceOnly);
		
		spaceOnly.skipWhiteSpace();
		Assert.assertEquals(spaceOnly.length(), spaceOnly.getCurrentPosition());
		
		//Blank data
		pData.reset();

		pData.skipWhiteSpace();
		Assert.assertEquals(0, pData.getCurrentPosition());
		checkIsDataBegin(pData);
		
		//null Data
		nullData.skipWhiteSpace();
		Assert.assertEquals(0, nullData.getCurrentPosition());
		
	}
}