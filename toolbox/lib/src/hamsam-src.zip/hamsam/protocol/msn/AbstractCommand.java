/*
 * Hamsam - Instant Messaging API
 * Copyright (C) 2003 Raghu K
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package hamsam.protocol.msn;

import java.util.Vector;

/**
 * Super class of all types of commands in MSN - Normal commands, Messages,
 * Errors, and QRY command.
 */
abstract class AbstractCommand
{
	/**
	 * Type identifier for this command.
	 */
	private String type;

	/**
	 * List of parameters for this command.
	 */
	private Vector paramList;

	/**
	 * Transaction ID for this command.
	 */
	private Integer transactionID;

	/**
	 * Construct a command with the given command type.
	 *
	 * @param type the three letter command type.
	 */
	protected AbstractCommand(String type)
	{
		this.type = type;
		paramList = new Vector();
	}

	/**
	 * Returns the command type.
	 *
	 * @return command type of this command.
	 */
	String getType()
	{
		return this.type;
	}

	/**
	 * Add a parameter to the set of parameters for this
	 * command.
	 *
	 * @param param the parameter to be added.
	 */
	void addParam(String param)
	{
		paramList.add(param);
	}

	/**
	 * Returns a parameter from the set of parameters for this
	 * command.
	 *
	 * @param pos the position of the parameter requested in the list of parameters.
	 *            first parameter is at position 0, second at position 1, and so on.
	 * @return the requested parameter.
	 */
	String getParam(int pos)
	{
		return (String) paramList.elementAt(pos);
	}

	/**
	 * Returns the number of parameters in this command.
	 *
	 * @return number of parameters.
	 */
	int getParamCount()
	{
		return paramList.size();
	}

	/**
	 * Set the transaction id for this command.
	 *
	 * @param id transaction id for this command.
	 */
	void setTransactionID(Integer id)
	{
		this.transactionID = id;
	}

	/**
	 * Returns the transaction id for this command.
	 *
	 * @return transaction id for this command, if any. Otherwise null.
	 */
	Integer getTransactionID()
	{
		return this.transactionID;
	}

	/**
	 * Returns a string representation of this command. The returned string is
	 * composed by appending the following components separated by space character.
	 *
	 * <ul>
	 * 	<li>Command type.</li>
	 * 	<li>Transaction ID, if available.</li>
	 * 	<li>All the parameters separated by space characters.</li>
	 * </ul>
	 *
	 * Note that the string is not terminated by a CRLF.
	 *
	 * @return string representation of this command
	 */
	public String toString()
	{
		StringBuffer buff = new StringBuffer(type);

		if(transactionID != null)
		{
			buff.append(" ");
			buff.append(transactionID);
		}

		for(int i = 0; i < paramList.size(); i++)
		{
			buff.append(" ");
			buff.append(paramList.get(i));
		}

		return buff.toString();
	}
}
