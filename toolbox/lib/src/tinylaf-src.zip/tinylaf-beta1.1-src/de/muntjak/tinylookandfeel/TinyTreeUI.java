/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	Tiny Look and Feel                                                         *
*                                                                              *
*  (C) Copyright 2003, Hans Bickel                                             *
*                                                                              *
*   For licensing information and credits, please refer to the                 *
*   comment in file de.muntjak.tinylookandfeel.TinyLookAndFeel                 *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package de.muntjak.tinylookandfeel;

import java.awt.*;
import javax.swing.*;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.metal.MetalTreeUI;

import de.muntjak.tinylookandfeel.controlpanel.*;

/**
 * TinyTreeUI
 * 
 * @version 1.0
 * @author Hans Bickel
 */
public class TinyTreeUI extends MetalTreeUI {
	
	public static ComponentUI createUI(JComponent x) {
		return new TinyTreeUI();
    }
    
	protected void installDefaults() {
		super.installDefaults();
		
		if(!ControlPanel.isInstantiated) return;
		
		tree.setBackground(UIManager.getColor("Tree.background"));
		tree.setFont( UIManager.getFont("Tree.font") );
	}
}
