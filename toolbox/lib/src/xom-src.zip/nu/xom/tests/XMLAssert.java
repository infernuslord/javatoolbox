// Copyright 2002, 2003 Elliotte Rusty Harold
// 
// This library is free software; you can redistribute 
// it and/or modify it under the terms of version 2.1 of 
// the GNU Lesser General Public License as published by  
// the Free Software Foundation.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General 
// Public License along with this library; if not, write to the 
// Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
// Boston, MA  02111-1307  USA
// 
// You can contact Elliotte Rusty Harold by sending e-mail to
// elharo@metalab.unc.edu. Please include the word "XOM" in the
// subject line. The XOM home page is temporarily located at
// http://www.cafeconleche.org/XOM/  but will eventually move
// to http://www.xom.nu/

package nu.xom.tests;

import junit.framework.Assert;
import nu.xom.Attribute;
import nu.xom.Comment;
import nu.xom.DocType;
import nu.xom.Document;
import nu.xom.Element;
import nu.xom.Node;
import nu.xom.ProcessingInstruction;
import nu.xom.Text;


/*
 * This class provides utility methods to
 * compare nodes for deep equality in an infoset
 * sense.
 *
 * @author Elliotte Rusty Harold
 *
 */
class XMLAssert {
    
    public static void assertEquals(Text text1, Text text2) {
        Assert.assertEquals(
          normalizePCDATA(text1.getValue()), 
          normalizePCDATA(text2.getValue())
        );
    }
    
    
    
    public static void assertEquals(Attribute att1, Attribute att2) {
        
        String value1 = normalizeAttributeValue(att1.getValue());
        String value2 = normalizeAttributeValue(att2.getValue());
        if ("xml:base".equals(att1.getQualifiedName())) {
            Assert.assertTrue(value1.endsWith(value2) || value2.endsWith(value1));
        } 
        else {
            Assert.assertEquals(value1, value2);
            Assert.assertEquals(att1.getLocalName(), att2.getLocalName());
            Assert.assertEquals(
              att1.getQualifiedName(), att2.getQualifiedName()
            );
            Assert.assertEquals(
              att1.getNamespaceURI(), att2.getNamespaceURI()
            );
        }

    }

    // convert all line breaks to \n
    private static String normalizePCDATA(String s) {
        
        char NEL = 0x85;
        
        StringBuffer result = new StringBuffer(s.length());
        boolean lastCharacterWasCarriageReturn = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\r') {
                result.append('\n');
                lastCharacterWasCarriageReturn = true;               
            }
            else if (c == '\n') {
                if (!lastCharacterWasCarriageReturn) {
                    result.append('\n');
                } 
                lastCharacterWasCarriageReturn = false;               
            }
            /* This one's really flaky, but it's necessary to
             * work around Java'a mishandling of NEL
             */
            else if (c == NEL) {
                result.append('\n');
                lastCharacterWasCarriageReturn = false;               
            }
            else {
                result.append(c);
                lastCharacterWasCarriageReturn = false;
            }
        }
        return result.toString();
        
    }

    
    private static String normalizeAttributeValue(String s) {
        
        s = s.trim();
        StringBuffer result = new StringBuffer(s.length());
        boolean lastCharacterWasSpace = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == ' ' || c == '\r' || c == '\n' || c == '\t') {
                if (!lastCharacterWasSpace) result.append(' ');
                lastCharacterWasSpace = true;               
            }
            else {
                result.append(c);
                lastCharacterWasSpace = false;
            }
        }
        return result.toString();
        
    }

    public static void assertEquals(DocType type1, DocType type2) {
        
        Assert.assertEquals(
          type1.getInternalDTDSubset(), 
          type2.getInternalDTDSubset()
        );
        Assert.assertEquals(
          type1.getPublicID(), 
          type2.getPublicID()
        );
        Assert.assertEquals(
          type1.getSystemID(), 
          type2.getSystemID()
        );
        Assert.assertEquals(
          type1.getRootElementName(), 
          type2.getRootElementName()
        );
    }

    public static void assertEquals(
      Element element1, Element element2) {
        
        Assert.assertEquals(
          element1.getLocalName(), 
          element2.getLocalName()
        );
        Assert.assertEquals(
          element1.getQualifiedName(), 
          element2.getQualifiedName()
        );
        Assert.assertEquals(
          element1.getNamespaceURI(), 
          element2.getNamespaceURI()
        );

        Assert.assertEquals(
          element1.getAttributeCount(), 
          element2.getAttributeCount()
        );
        
        for (int i = 0; i < element1.getAttributeCount(); i++ ) {
            Attribute att1 = element1.getAttribute(i);
            Attribute att2 
              = element2.getAttribute(
                att1.getLocalName(), 
                att1.getNamespaceURI()
                );
            Assert.assertNotNull(att2);
            assertEquals(att1, att2);
        }
        
        // Check additional namespaces
        /* Assert.assertEquals(
          element1.getNamespaceDeclarationCount(), 
          element2.getNamespaceDeclarationCount()
        );        
        for (int i = 0; 
             i < element1.getNamespaceDeclarationCount(); 
             i++ ) {
            String prefix1 = element1.getNamespacePrefix(i);
            String uri1 = element1.getNamespaceURI(prefix1);
            Assert.assertNotNull(element2.getNamespaceURI(prefix1));
            Assert.assertEquals(
              uri1, element2.getNamespaceURI(prefix1)
            );                        
        }    */    

        // Check namespaces in scope by listing all the prefixes
        // on element1 and making sure element2 gives the same value
        // for those prefixes, and vice versa. This is necessary
        // to handle a few weird cases that arise in XInclude
        // when prefixes are decalrd multiple times, to account for
        // the fact that some serializers may drop redundant
        // namespace declarations 
        for (int i = 0; 
             i < element1.getNamespaceDeclarationCount(); 
             i++ ) {
            String prefix1 = element1.getNamespacePrefix(i);
            String uri1 = element1.getNamespaceURI(prefix1);
            Assert.assertNotNull(element2.getNamespaceURI(prefix1));
            Assert.assertEquals(
              uri1, element2.getNamespaceURI(prefix1)
            );                      
        }
        for (int i = 0; 
             i < element2.getNamespaceDeclarationCount(); 
             i++ ) {
            String prefix1 = element2.getNamespacePrefix(i);
            String uri1 = element2.getNamespaceURI(prefix1);
            Assert.assertNotNull(element1.getNamespaceURI(prefix1));
            Assert.assertEquals(
              uri1, element1.getNamespaceURI(prefix1)
            );                      
        }
        
        if (element1.getChildCount() != element2.getChildCount()) {
           // combine text nodes; this modifies the elements
           // but shouldn't be a big problem as long as 
           // this is only used for unit testing  
           combineTextNodes(element1);
           combineTextNodes(element2);
           
        }
        Assert.assertEquals(element1.getChildCount(), element2.getChildCount());
        for (int i = 0; i < element1.getChildCount(); i++) {
            Node child1 = element1.getChild(i);
            Node child2 = element2.getChild(i);
            assertEquals(child1, child2);
        }

    }
    
    private static void combineTextNodes(Element element) {
        for (int i = 0; i < element.getChildCount()-1; i++) {
            Node child = element.getChild(i);
            if (child instanceof Text) {
                  Node followingSibling = element.getChild(i+1);
                  if (followingSibling instanceof Text) {
                      Text combined = new Text(child.getValue() + followingSibling.getValue());
                      element.replaceChild(child, combined);
                      element.removeChild(followingSibling);
                      i--;
                  }
            }
        }        
    }

    public static void assertEquals(Document doc1, Document doc2) {
        
        Assert.assertEquals(
          doc1.getChildCount(), 
          doc2.getChildCount()
        );
        for (int i = 0; i < doc2.getChildCount(); i++) {
            Node child1 = doc1.getChild(i);
            Node child2 = doc2.getChild(i);
            assertEquals(child1, child2);
        }

    }


    
    public static void assertEquals(
      Comment comment1, Comment comment2) {
        Assert.assertEquals(comment1.getValue(), comment2.getValue());
    }
    
    public static void assertEquals(ProcessingInstruction instruction1, 
      ProcessingInstruction instruction2) {
        Assert.assertEquals(instruction1.getValue(),
                            instruction1.getValue());
        Assert.assertEquals(instruction1.getTarget(), 
                            instruction1.getTarget());
    }
    
    public static void assertEquals(Node node1, Node node2) {
        
        try {
            if (node1 instanceof Document) {
                assertEquals((Document) node1, (Document) node2);
            }
            else if (node1 instanceof Element) {
                assertEquals((Element) node1, (Element) node2);
            }
            else if (node1 instanceof Text) {
                assertEquals((Text) node1, (Text) node2);
            }
            else if (node1 instanceof DocType) {
                assertEquals((DocType) node1, (DocType) node2);
            }
            else if (node1 instanceof Comment) {
                assertEquals((Comment) node1, (Comment) node2);
            }
            else if (node1 instanceof ProcessingInstruction) {
                assertEquals(
                  (ProcessingInstruction) node1, 
                  (ProcessingInstruction) node2
                );
            }
            else {
                throw new IllegalArgumentException(
                  "Unexpected node type " + node1.getClass().getName()
                );
                
            }
        }
        catch (ClassCastException ex) {            
            Assert.fail("Mismatched node types: " 
             + node1.getClass().getName() + " != "
             + node2.getClass().getName());
        }
        
    }
    
}
