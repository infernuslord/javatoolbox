/*
 * Hamsam - Instant Messaging API
 * Copyright (C) 2003 Raghu K
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package hamsam.net;

import java.net.Socket;
import java.net.UnknownHostException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.IOException;

/**
 * An <code>HTTPConnection</code> connects to a specified host on a
 * specified port by establishing an HTTP/1.1 tunnel. This uses
 * HTTP CONNECT to create a persistent connection and uses that
 * to send and receive data.
 *
 * @author  Raghu
 * @version 0.1
 * @see     hamsam.net.SocksConnection  SocksConnection
 * @see     hamsam.net.DirectConnection DirectConnection
 */
public class HttpConnection implements Connection
{
	/**
	 * The socket representing this connection.
	 */
	private Socket sock;

	/**
	 * The input stream of the connection.
	 */
	private InputStream in;

	/**
	 * The output stream of the connection.
	 */
	private OutputStream out;

	/**
	 * Construct an HTTP connection to the specified host and port through an
	 * HTTP 1.1 proxy. The proxy optionally may require a user name and
	 * password for authentication. In that case, use the
	 * {@link #HttpConnection(String, int, String, String, String, int)
	 * HttpConnection(proxyHost, proxyPort, username, password, host, port)}
	 * constructor.
	 *
	 * @param proxyHost The HTTP proxy host name
	 * @param proxyPort The HTTP proxy port number
	 * @param host      The host name to be connected to.
	 * @param port      The port number to be connected on.
	 * @throws UnknownHostException If the IP address of the host could not be determined.
	 * @throws IOException          If an I/O error occurs when creating the connection.
	 * @throws SecurityException    If a security manager exists and its checkConnect
	 *                              method doesn't allow the operation.
	 */
	public HttpConnection(
				String proxyHost,
				int proxyPort,
				String host,
				int port) throws UnknownHostException, IOException
	{
		this(proxyHost, proxyPort, null, null, host, port);
	}

	/**
	 * Construct an HTTP connection to the specified host and port through an
	 * HTTP 1.1 proxy which requires authentication. The proxy optionally may
	 * require a user name and password for authentication. Those can be passed
	 * to this constructor. If the proxy does not require a user name and
	 * password, use the {@link #HttpConnection(String, int, String, int)
	 * HttpConnection(proxyHost, proxyPort, host, port)} constructor.
	 *
	 * @param proxyHost The HTTP proxy host name
	 * @param proxyPort The HTTP proxy port number
	 * @param username  The username to connect to the proxy.
	 * @param password  The password to connect to the proxy.
	 * @param host      The host name to be connected to.
	 * @param port      The port number to be connected on.
	 * @throws UnknownHostException If the IP address of the host could not be determined.
	 * @throws IOException          If an I/O error occurs when creating the connection.
	 * @throws SecurityException    If a security manager exists and its checkConnect
	 *                              method doesn't allow the operation.
	 */
	public HttpConnection(
				String proxyHost,
				int proxyPort,
				String username,
				String password,
				String host,
				int port) throws UnknownHostException, IOException
	{
		// connect to HTTP proxy
		sock = new Socket(proxyHost, proxyPort);
		in = sock.getInputStream();
		out = sock.getOutputStream();

		BufferedReader rd = new BufferedReader(new InputStreamReader(in));
		PrintStream wr = new PrintStream(out);

		// send the CONNECT request
		wr.print("CONNECT " + host + ":" + port + " HTTP/1.1\r\n");
		wr.print("Host: " + host + ":" + port + "\r\n");

		if(username != null && password != null)
			wr.print("Proxy-Authorization: Basic " +
							toBase64(username + ":" + password) + "\r\n");

		wr.print("\r\n");

		String line = rd.readLine();

		if(line == null)
			throw new IOException("Proxy closed connection");

		if(!line.startsWith("HTTP/1.0 200") && !line.startsWith("HTTP/1.1 200"))
			throw new IOException("Cannot CONNECT, Proxy returned " + line);

		// skip the remainings of the HTTP response
		while(line != null && !line.equals(""))
			line = rd.readLine();
	}

	/**
	 * Returns the number of bytes that can be read from this connection
	 * without blocking by the next caller of a method for this connection.
	 * The next caller might be the same thread or or another thread.
	 *
	 * <p>
	 * This method has exactly the same semantics as that of
	 * <code>java.io.InputStream.available()</code>.
	 *
	 * @return the number of bytes that can be read from this connection without blocking.
	 * @throws IOException if an I/O error occurs.
	 */
	public int available() throws IOException
	{
		return in.available();
	}

	/**
	 * Reads the next byte of data from the input stream. The value byte is returned as an
	 * int in the range 0 to 255. If no byte is available because the end of the stream has
	 * been reached, the value -1 is returned. This method blocks until input data is
	 * available, the end of the stream is detected, or an exception is thrown.
	 *
	 * @return the next byte of data, or -1 if the end of the stream is reached.
	 * @throws IOException if an I/O error occurs.
	 */
	public int read() throws IOException
	{
		return in.read();
	}

	/**
	 * Reads some number of bytes from the connection and stores them into
	 * the buffer array b. The number of bytes actually read is returned as
	 * an integer. If no bytes are available because of EOF, returns -1.
	 * This call has exactly the same semantics as that of
	 * <code>java.io.InputStream.read(byte[] b)</code>.
	 *
	 * @param b             The buffer to which data is read.
	 * @return              The total number of bytes read into the buffer, or -1 if there
	 *                      is no more data because the end of the stream has been reached.
	 * @throws IOException  If an I/O error occurs.
	 */
	public int read(byte[] b) throws IOException
	{
		return in.read(b);
	}

	/**
	 * Reads up to len bytes of data from the connection into an array of bytes.
	 * An attempt is made to read as many as len bytes, but a smaller number may
	 * be read, possibly zero. The number of bytes actually read is returned as
	 * an integer. If no bytes are available because of EOF, returns -1.
	 * This call has exactly the same semantics as that of
	 * <code>java.io.InputStream.read(byte[] b, int off, int len)</code>.
	 *
	 * @param b             The buffer to which data is read.
	 * @param off           The start offset in array <code>b</code> at which data is written.
	 * @param len           The maximum number of bytes to be read.
	 * @return              The total number of bytes read into the buffer, or -1 if there
	 *                      is no more data because the end of the stream has been reached.
	 * @throws IOException  If an I/O error occurs.
	 */
	public int read(byte[] b, int off, int len) throws IOException
	{
		return in.read(b, off, len);
	}

	/**
	 * Writes b.length bytes from the specified byte array to this connection.
	 *
	 * @param b The data to be sent through this connection.
	 * @throws IOException If an I/O error occurs.
	 */
	public void write(byte[] b) throws IOException
	{
		out.write(b);
	}

	/**
	 * Flushes this connection and forces any buffered output bytes to be
	 * written out. The general contract of flush is that calling it is an
	 * indication that, if any bytes previously written have been buffered by
	 * the implementation of the connection, such bytes should immediately be
	 * written to their intended destination.
	 *
	 * @throws IOException If an I/O error occurs.
	 */
	public void flush() throws IOException
	{
		out.flush();
	}

	/**
	 * Closes this connection and releases any resources associated with it.
	 *
	 * @throws IOException If an I/O error occurs.
	 */
	public void close() throws IOException
	{
		in.close();
		out.close();
		sock.close();
	}

	/**
	 * Convert a string to base 64 encoded form. Used for
	 * proxy authentication.
	 *
	 * @param line The line to be converted.
	 * @return The base 64 encoded <code>String</code>.
	 * @throws NullPointerException If line is null
	 */
	private String toBase64(String line)
	{
		char[] alphabet = {
				'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
				'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T',
				'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd',
				'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
				'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x',
				'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7',
				'8', '9', '+', '/' 
		};

		int inlen = line.length();
		int outlen = 0;
		int index;
		for(index = 0; index < inlen; index += 3)
			outlen += 4;
		if(index != inlen)
			outlen += 4;

		char[] out = new char[outlen];
		byte[] c = line.getBytes();
		int tmp = 0;
		int len = 0;
		int n = 0;

		for(int i = 0; i < c.length; i++)
		{
			tmp = tmp << 8;
			tmp += c[i];
			n++;

			if(n == 3)
			{
				out[len] = alphabet[(tmp >>> 18) & 0x3f];
				out[len + 1] = alphabet[(tmp >>> 12) & 0x3f];
				out[len + 2] = alphabet[(tmp >>> 6) & 0x3f];
				out[len + 3] = alphabet[tmp & 0x3f];
				len += 4;
				tmp = 0;
				n = 0;
			}
		}

		switch(n)
		{
			case 2:
				tmp <<= 8;
				out[len] = alphabet[(tmp >>> 18) & 0x3f];
				out[len + 1] = alphabet[(tmp >>> 12) & 0x3f];
				out[len + 2] = alphabet[(tmp >>> 6) & 0x3f];
				out[len + 3] = '=';
				break;
			case 1:
				tmp <<= 16;
				out[len] = alphabet[(tmp >>> 18) & 0x3f];
				out[len + 1] = alphabet[(tmp >>> 12) & 0x3f];
				out[len + 2] = '=';
				out[len + 3] = '=';
				break;
		}
		return new String(out);
	}

	/**
	 * Returns an InputStream that can be used to indirectly call the
	 * read methods.
	 *
	 * @return An InputStream for reading from this connection.
	 * @throws IOException If an I/O error occurs.
	 */
	public InputStream getInputStream() throws IOException
	{
		return in;
	}

	/**
	 * Returns the socket used by this connection.
	 * 
	 * @return the socket used by this connection
	 * @throws IOException If an I/O error occurs.
	 */
	public Socket getSocket() throws IOException
	{
		return this.sock;
	}
}
