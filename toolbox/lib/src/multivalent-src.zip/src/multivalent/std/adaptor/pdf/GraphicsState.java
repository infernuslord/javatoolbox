package multivalent.std.adaptor.pdf;

import java.awt.Color;
import java.awt.color.ColorSpace;
import java.awt.geom.AffineTransform;

import multivalent.node.FixedIClip;



/**
	PDF graphics state, with many attributes.
	As a PDF content stream is interpreted, GraphicsState objects and pushed and poppsed on the stack.

	@version $Revision: 1.7 $ $Date: 2003/08/29 04:03:38 $
*/
public class GraphicsState {
  public AffineTransform ctm;

  public float linewidth;
  public int linecap;	// 0=butt, 1=round, 2=projecting
  public int linejoin;	// 0=miter, 1=round, 2=bevel
  public float miterlimit;
  public float[] dasharray;
  public float dashphase;
  public String renderingintent;
  public int flatness;
  public double smoothness;
  public ColorSpace fCS, sCS;    // not needed before mozilla-ch02.pdf
  public Color fillcolor;
  public Color strokecolor;

  public Dict fontdict;
  public double pointsize;
  public int Tr;
  public double Tw, Tc, Tz, Ts, TL;
  //public AffineTransform Tm, Tlm;    // not part of state

  // transparency
  public float alphastroke;
  public float alphanonstroke;



  // implicit state
  //public Encoding encoding;	// => bound to font
  public FixedIClip clip;


  public GraphicsState() {
	//ctm = new AffineTransform();
	linewidth = 1f;   // => take from DEFAULT_STROKE
	linecap = 0;
	linejoin = 0;
  }

  /** Makes copy of <var>gs</var>. */
  public GraphicsState(GraphicsState gs) {
	ctm = new AffineTransform(gs.ctm);  // clone() + new AffineTransform()

	linewidth = gs.linewidth;
	linecap = gs.linecap;
	linejoin = gs.linejoin;
	miterlimit = gs.miterlimit;
	dasharray = gs.dasharray;
	dashphase = gs.dashphase;

	renderingintent = gs.renderingintent;
	flatness = gs.flatness;
	smoothness = gs.smoothness;

	fCS = gs.fCS; sCS = gs.sCS;
	fillcolor = gs.fillcolor;
	strokecolor = gs.strokecolor;

	fontdict = gs.fontdict;
	pointsize = gs.pointsize;
	Tr = gs.Tr;
	Tc = gs.Tc; Tw = gs.Tw; Tz = gs.Tz; TL = gs.TL; Ts = gs.Ts;

	alphastroke = gs.alphastroke;
	alphanonstroke = gs.alphanonstroke;

	clip = gs.clip;
  }

  public String toString() { return ctm.toString(); }
}
