/*
 * @(#)JDisAssembler.java
 *
 * JReversePro - Java Decompiler / Disassembler.
 * Copyright (C) 2000 2001 Karthik Kumar.
 * EMail: akkumar@users.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it , under the terms of the GNU General Public License as published
 * by the Free Software Foundation; either version 2 of the License,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program.If not, write to
 *  The Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330,
 *  Boston, MA 02111-1307, USA.
 */
package jreversepro.revengine;


import jreversepro.common.Helper;
import jreversepro.common.JJvmSet;
import jreversepro.common.JJvmOpcodes;
import jreversepro.reflect.JConstantPool;
import jreversepro.reflect.JInstruction;
import jreversepro.reflect.JMethod;

import java.util.List;
import java.util.Enumeration;

import java.io.IOException;
import java.util.Collections;

/**
 *  <b>JDisAssembler</b> writes out the assebly byte codes.
 * @author Karthik Kumar
 * @version 1.3
 */
public class JDisAssembler implements JReverseEngineer, JJvmOpcodes {

    List ByteIns;
    JConstantPool CpInfo;
    JMethod CurMethod;

    public JDisAssembler( JMethod RhsMethod,
                          JConstantPool RhsCpInfo ) {
        ByteIns = RhsMethod.getInstructions();
        CpInfo =  RhsCpInfo;
        CurMethod = RhsMethod;
    }

    public StringBuffer genCode()
                throws RevEngineException,
                            IOException {

        StringBuffer Assembly = new StringBuffer("");
        Assembly.append( JDecompiler.getMethodHeaders(CurMethod, null));
        Assembly.append(" {");
        Assembly.append( CurMethod.getLocalStackInfo() );

        try {
            Enumeration enum  = Collections.enumeration(ByteIns);
            while( enum.hasMoreElements() ) {
                JInstruction ThisIns = ( JInstruction) enum.nextElement();
                if( ThisIns.opcode == OPCODE_TABLESWITCH ) {
                    JSwitchTable switches  =
                      new JSwitchTable( ThisIns);
                    Assembly.append("\n\t\t"  +  ThisIns.index + ": ");
                    Assembly.append("tableswitch ");
                    Assembly.append( switches.disassemble() );
                }
                else if ( ThisIns.opcode == OPCODE_LOOKUPSWITCH ) {
                    JSwitchTable switches  =
                      new JSwitchTable( ThisIns);
                    Assembly.append("\n\t\t"  +  ThisIns.index + ": ");
                    Assembly.append("lookupswitch ");
                    Assembly.append( switches.disassemble() );
                }
                else if( ThisIns.opcode == OPCODE_WIDE ) {
                    //Handling to be done here.
                }
                else {
                    dealDefault(Assembly, ThisIns);
                }
            }
        } catch ( RevEngineException  ree ) {
            Assembly.append(DECOMPILE_FAILED_MSG);
        }
        Assembly.append("\n\t}");
        return Assembly;
    }

    private void dealDefault( StringBuffer Assembly,
                                JInstruction ThisIns ) {
        Assembly.append("\n\t\t"  +  ThisIns.index + ": ");
        String Ins = ThisIns.getInsName();
        Assembly.append(Ins);
        if( ThisIns.args == null ) return;
        int len = ThisIns.args.length;
        if ( len == 1 ) {
            int ThisByte = ThisIns.getArgUnsignedByte();
            if( ThisIns.opcode >= OPCODE_LDC &&
                 ThisIns.opcode  <= OPCODE_LDC2_W ) {
                Assembly.append(" #");
                //Indicates an index to the Constant Pool
                Assembly.append( ThisByte + " <");
                Assembly.append( CpInfo.getTagDescriptor(ThisByte) );
                Assembly.append(" >");
            }
            else Assembly.append(" " + ThisByte );
        }
        else if( len == 2 ) {
            int Value = ThisIns.getArgUnsignedShort();
            Assembly.append(" ");
            if( Ins.indexOf("if") != -1 ||
                 ThisIns.opcode == OPCODE_GOTO  ||
                 ThisIns.opcode == OPCODE_JSR  )
            {
                Assembly.append( ThisIns.getTargetPc() );
            }
            else if( ThisIns.opcode == OPCODE_IINC ) {
                Assembly.append( ThisIns.getArgUnsignedByte() + " " +
                                ThisIns.getArgUnsignedByte(1) );
            }
            else if( ThisIns.opcode == OPCODE_SIPUSH ) {
                Assembly.append(Value);
            }
            else {
                Assembly.append("#");
                //Indicates an index to the Constant Pool
                Assembly.append(Value + " <");
                Assembly.append( CpInfo.getTagDescriptor(Value) );
                Assembly.append(" >");
            }
        }
        else if( len == 4 ) {
            int Value = ThisIns.getArgUnsignedShort();
            Assembly.append(" #");
            //Indicates an index to the Constant Pool
            Assembly.append(Value + " <");
            Assembly.append( CpInfo.getTagDescriptor(Value) );
            Assembly.append(" >");
        }
    }
}