/*
  Copyright (C) 2003-2004 Robert F. Beeger (robert at beeger dot net)
  Licensed under the Academic Free License version 2.1
  OSI Certified Open Source Software

  Visit http://squareness.sourceforge.net/ for new releases of Squareness Look And Feel and other
  skins from the Squareness series.
*/
package net.beeger.squareness.delegate;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Rectangle;
import javax.swing.AbstractButton;
import javax.swing.ButtonModel;
import javax.swing.JComponent;
import javax.swing.SwingUtilities;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicHTML;
import javax.swing.plaf.basic.BasicToggleButtonUI;
import javax.swing.text.View;

import net.beeger.squareness.SquarenessConstants;
import net.beeger.squareness.util.SquarenessButtonPainter;
import net.beeger.squareness.util.SquarenessListenerFactory;

/**
 * The Squareness Toggle Button UI delegate.
 */
public class SquarenessToggleButtonUI extends BasicToggleButtonUI
{
  /**
   * Create the UI delegate for the given component
   * 
   * @param component The component for which to create the ui delegate
   * @return The created ui delegate
   */
  public static ComponentUI createUI (JComponent component)
  {
    return _buttonUI;
  }

  /**
   * Install the UI delegate for the given component
   * 
   * @param component The component for which to install the ui delegate.
   */
  public void installUI (JComponent component)
  {
    component.putClientProperty(SquarenessConstants.ROLLOVER_CLENT_PROPERTY_KEY, Boolean.FALSE);
    component.addMouseListener(SquarenessListenerFactory.getButtonRolloverMouseListener());
    super.installUI(component);
  }

  /**
   * Uninstall the UI delegate from the given component.
   *
   * @param component The component from which to uninstall the UI delegate.
   */
  public void uninstallUI (JComponent component)
  {
    component.removeMouseListener(SquarenessListenerFactory.getButtonRolloverMouseListener());
    super.uninstallUI(component);
  }

  /**
   * Paint the component.
   * 
   * @param graphics  The graphics resource used to paint the component
   * @param component The component to paint.
   */
  public void paint (Graphics graphics, JComponent component)
  {
    Color oldColor = graphics.getColor();

    SquarenessButtonPainter.paintButton(graphics, (AbstractButton) component);

    AbstractButton b = (AbstractButton) component;
    ButtonModel model = b.getModel();

    Dimension size = b.getSize();
    FontMetrics fm = graphics.getFontMetrics();

    Insets i = component.getInsets();

    Rectangle viewRect = new Rectangle(size);

    viewRect.x += i.left;
    viewRect.y += i.top;
    viewRect.width -= (i.right + viewRect.x);
    viewRect.height -= (i.bottom + viewRect.y);

    Rectangle iconRect = new Rectangle();
    Rectangle textRect = new Rectangle();

    Font f = component.getFont();
    graphics.setFont(f);

    // layout the text and icon
    String text = SwingUtilities.layoutCompoundLabel(component, fm, b.getText(), b.getIcon(),
                                                     b.getVerticalAlignment(), b.getHorizontalAlignment(),
                                                     b.getVerticalTextPosition(), b.getHorizontalTextPosition(),
                                                     viewRect, iconRect, textRect,
                                                     b.getText() == null ? 0 : b.getIconTextGap());

    graphics.setColor(b.getBackground());

    if (model.isArmed() && model.isPressed() || model.isSelected())
    {
      paintButtonPressed(graphics, b);
    }

    // Paint the Icon
    if (b.getIcon() != null)
    {
      paintIcon(graphics, b, iconRect);
    }
	
    // Draw the Text
    if (text != null && !text.equals(""))
    {
      View v = (View) component.getClientProperty(BasicHTML.propertyKey);
      if (v != null)
      {
        v.paint(graphics, textRect);
      }
      else
      {
        paintText(graphics, b, textRect, text);
      }
    }
	
    // draw the dashed focus line.
    if (b.isFocusPainted() && b.hasFocus())
    {
      paintFocus(graphics, b, viewRect, textRect, iconRect);
    }

    graphics.setColor(oldColor);
  }

  private static SquarenessToggleButtonUI _buttonUI = new SquarenessToggleButtonUI();
}

/*
  $Log: SquarenessToggleButtonUI.java,v $
  Revision 1.5  2004/09/18 17:30:47  rbeeger
  * Updated copyright block and license file. Squareness Look And Feel is now licensed under Academic Free License 2.1
  * Added themepack.

  Revision 1.4  2004/03/08 15:12:26  rbeeger
  Added and enhanced comments.
  Simplified code.

  Revision 1.3  2004/02/14 19:12:34  rbeeger
  Updated copyright statement
  Added cvs log directive at the end of each file
  Optimized imports
  Reformated code

 */
