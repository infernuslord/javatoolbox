/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh;

import javax.swing.*;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Rectangle;

import javax.swing.border.Border;
import javax.swing.plaf.*;
import javax.swing.plaf.basic.BasicSeparatorUI;

import com.shfarr.ui.GraphicsUtils;
import com.shfarr.ui.plaf.fh.borders.FhMatrixBorder;

public class FhSeparatorUI extends BasicSeparatorUI{

    public FhSeparatorUI(){
        super();
    }

    public static ComponentUI createUI(JComponent c){
        return new FhSeparatorUI();
    }

    public Dimension getPreferredSize(JComponent c){
        Border b = UIManager.getDefaults().getBorder("Separator.border");

        if(b == null) return new Dimension(5, 5);
        else{
            Insets i = b.getBorderInsets(c);
            return new Dimension(i.left + i.right, i.top + i.bottom);
        }
    }

    protected void installDefaults(JSeparator s){
        LookAndFeel.installColors(s, "Separator.background", "Separator.foreground");

        if(s instanceof JToolBar.Separator){
            Dimension size = ((JToolBar.Separator)s).getSeparatorSize();

            if(size == null || size instanceof UIResource){
                size = (Dimension)(UIManager.get("ToolBar.separatorSize"));
                ((JToolBar.Separator)s).setSeparatorSize(size);
            }
        }
    }

    public void paint(Graphics g, JComponent c){
        Rectangle r = new Rectangle(0, 0, c.getWidth(), c.getHeight());

        Border b = UIManager.getDefaults().getBorder("Separator.border");
        if(b instanceof FhMatrixBorder && ((JSeparator)c).getOrientation() == JSeparator.VERTICAL) b = ((FhMatrixBorder)b).deriveBorder(GraphicsUtils.ROTATE_90);

//        Insets i = b != null ? b.getBorderInsets(c) : new Insets(0, 0, 0, 0);
//
//        if(((JSeparator)c).getOrientation() == JSeparator.HORIZONTAL) r.setBounds(i.left, r.height/2 -i.top, r.width -i.left -i.right, i.top + i.bottom + 1);
//        else r.setBounds(r.width / 2 - i.left, i.top, i.left + i.right + 1, r.height -i.top -i.bottom);

        b.paintBorder(c, g, r.x, r.y, r.width, r.height);
    }
}
