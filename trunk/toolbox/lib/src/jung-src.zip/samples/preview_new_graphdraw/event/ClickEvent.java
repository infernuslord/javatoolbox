/*
 * Created on Dec 9, 2003
 */
package samples.preview_new_graphdraw.event;

import java.awt.event.MouseEvent;
import java.util.EventObject;

import edu.uci.ics.jung.utils.UserDataContainer;


public class ClickEvent extends EventObject {
	protected double dist;
	protected MouseEvent originator;
	protected UserDataContainer graphObject;

	public ClickEvent(
		Object src,
		UserDataContainer udc,
		double dist,
		MouseEvent e) {
		super(src);
		this.dist = dist;
		this.originator = e;
		this.graphObject = udc;
	}

	public double getDist() {
		return dist;
	}

	public MouseEvent getOriginator() {
		return originator;
	}

	public UserDataContainer getGraphObject() {
		return graphObject;
	}
	
	public String toString() { 
	    return "ClickEvent[" + graphObject + "," + originator + "]";
	}

}