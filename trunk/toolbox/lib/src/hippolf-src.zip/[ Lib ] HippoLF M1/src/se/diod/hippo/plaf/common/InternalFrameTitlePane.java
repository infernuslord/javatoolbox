/*
 * 
 * Created on 2004-jul-25
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.common;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.Icon;
import javax.swing.JInternalFrame;
import javax.swing.UIManager;
import javax.swing.plaf.metal.MetalInternalFrameTitlePane;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-25
 *
 */
public class InternalFrameTitlePane extends MetalInternalFrameTitlePane {
	private Icon storedIcon	= null;





	/**
	 * 
	 * 
	 */
	public InternalFrameTitlePane( JInternalFrame frame ) {
		super( frame );
		storedIcon = frame.getFrameIcon();

	}




	/**
	 * 
	 * 
	 */
	public void paintPalette( Graphics g ) {
		boolean leftToRight = true;

		int width	= getWidth();
		int height	= getHeight();

		boolean isSelected	= frame.isSelected();

		Color col1	= UIManager.getColor( "InternalFrame.activeTitleBackground" );
		Color col2	= UIManager.getColor( "InternalFrame.activeTitleBackground2" );
		if( isSelected ) {
			java.awt.Graphics2D g2d = (java.awt.Graphics2D)g;
			g2d.setPaint( new java.awt.GradientPaint(width/2, 0, col1, width, height, col2, false ) );
			g2d.fillRect( 0, 0, width, height );
		} else {
			g.setColor( col1 );
			g.fillRect( 0, 0, width, height );
		}

		// Set border..
		Color darkShadow = new Color( 0, 0, 0 );
		g.setColor(darkShadow);
		g.drawLine(0, height - 1, width, height - 1);
	}

	
	

	/**
	 * 
	 * 
	 */
	public void paintComponent( Graphics g ) {
		if (isPalette) {
			paintPalette( g );
			return;
		}

		boolean isSelected	= frame.isSelected();

		int width			= getWidth();
		int height			= getHeight();

		Color foreground	= null;
		Color shadow		= null;


		Color col1	= UIManager.getColor( "InternalFrame.activeTitleBackground" );
		Color col2	= UIManager.getColor( "InternalFrame.activeTitleBackground2" );
		if( isSelected ) {
			java.awt.Graphics2D g2d = (java.awt.Graphics2D)g;
			g2d.setPaint( new java.awt.GradientPaint(width/2, 0, col1, width, height, col2, false ) );
			g2d.fillRect( 0, 0, width, height );
		} else {
			g.setColor( col1 );
			g.fillRect( 0, 0, width, height );
		}

		// Draw bottom border of TitlePane..
		g.setColor( new Color( 70, 70, 70 ) );
		g.drawLine( 0, height - 1, width, height - 1 );

		// Retrieve x/yoffset..
		java.awt.FontMetrics fm = g.getFontMetrics();
		int yOffset = ((height - fm.getHeight()) / 2) + fm.getAscent();
		int xOffset = 5;

		javax.swing.Icon icon = frame.getFrameIcon();
		if (icon != null) {
			int iconY = ((height / 2) - (icon.getIconHeight() / 2));
			icon.paintIcon(frame, g, xOffset, iconY);
			xOffset += icon.getIconWidth() + 5;
		}

		// Draw title text..
		String frameTitle = frame.getTitle();
		g.setColor( Color.black );
		g.drawString( frameTitle, xOffset, yOffset );
	}
}
