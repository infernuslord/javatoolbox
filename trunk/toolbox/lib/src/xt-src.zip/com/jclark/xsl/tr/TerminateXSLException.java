// $Id: TerminateXSLException.java,v 1.1 2002/04/25 18:19:46 bill Exp $

package com.jclark.xsl.tr;

import com.jclark.xsl.om.*;

public class TerminateXSLException extends XSLException
{
    public TerminateXSLException(String detail, Node node)
    {
        super(detail, node);
    }
}
