/*
 * Copyright (c) 2003, the JUNG Project and the Regents of the University 
 * of California
 * All rights reserved.
 *
 * This software is open-source under the BSD license; see either
 * "license.txt" or
 * http://jung.sourceforge.net/license.txt for a description.
 */
package edu.uci.ics.jung.visualization.contrib;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.beans.PropertyChangeListener;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.swing.JPanel;

import edu.uci.ics.jung.exceptions.FatalException;
import edu.uci.ics.jung.graph.Edge;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.utils.Pair;
import edu.uci.ics.jung.utils.UserData;
import edu.uci.ics.jung.visualization.Layout;
import edu.uci.ics.jung.visualization.PickedInfo;
import edu.uci.ics.jung.visualization.Renderer;

/**
 * BirdsEyeVisualizationViewer is intended to be an additional display of a
 * graph and layout that is being manipulated elsewhere. This class makes no
 * calls that mutate the graph or layout
 * 
 * @author Tom Nelson - RABA Technologies
 * 
 *  
 */
public class BirdsEyeVisualizationViewer extends JPanel implements PickedInfo {

    Thread relaxer;

    boolean suspended;

    boolean manualSuspend;

    protected Renderer renderer;

    protected Layout layout;
    
	protected Map renderingHints = new HashMap();


    double offsetx = 0.0;

    double offsety = 0.0;

    double scalex = 1.0;

    double scaley = 1.0;

    private Lens lens;

    /**
     * create an instance with passed values
     * @param layout the layout to use
     * @param r the renderer to use
     * @param scalex the scale in the horizontal direction
     * @param scaley the scale in the vertical direction
     */
    public BirdsEyeVisualizationViewer(Layout layout, Renderer r,
            double scalex, double scaley) {

        this.renderer = r;
        this.scalex = scalex;
        this.scaley = scaley;
        r.setPickedKey(this);
        //System.err.println("in ctor layout is " + layout);
        this.layout = layout;
        this.suspended = true;
        this.manualSuspend = false;
        renderingHints.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        init();
    }

    public Lens.Stats getLensStats() {
        if(lens != null) {
            return lens.getStats();
        } else {
            return null;
        }
    }

    /**
     * reset the Lens to no zoom/no offset.
     * passes call to Lens 
     *
     */
    public void resetLens() {
        if(lens != null) {
            lens.reset();
        }
    }
    
    /**
     * set the initial values for the Lens 
     * (50% zoom centered in display)
     *
     */
    public void initLens() {
        if(lens != null) {
            lens.init();
        }
    }
    
    /**
     * proportionally zoom the Lens
     * @param percent
     */
    public void zoom(double percent) {
        if(lens != null) {
            lens.zoom(percent);
        }
    }

    /**
     * defers setting the perferred size until the component is
     * live and the layout size is known
     * Adds the mouse clicker at that time.
     */
    public void addNotify() {
        super.addNotify();
        Dimension layoutSize = layout.getCurrentSize();
        if (layoutSize != null) {
            Dimension mySize = new Dimension((int) (layoutSize.width * scalex),
                    (int) (layoutSize.height * scaley));
            setPreferredSize(mySize);
            initMouseClicker();
        }
    }

    /**
     *  Creates and adds the Lens to control zoom/pan functions
     */
    protected void initMouseClicker() {
        Dimension layoutSize = layout.getCurrentSize();
        if (layoutSize != null) {
            lens = new Lens(layout, scalex, scaley);
            // now that the Lens is available, pass the
            // Lens propertyChangeListeners to the Lens
            // and remove them from this
            PropertyChangeListener[] listeners =
                getPropertyChangeListeners("Lens");
            for(int i=0; i<listeners.length; i++) {
                lens.addPropertyChangeListener("Lens", listeners[i]);
                removePropertyChangeListener(listeners[i]);
            }
        }
        addMouseListener(lens);
        addMouseMotionListener(lens);
    }

    /**
     * UNTESTED.
     */
    public void setRenderer(Renderer r) {
        this.renderer = r;
        r.setPickedKey(this);
        repaint();
    }

    /**
     * setter for layout
     * @param v the layout
     */
    public void setGraphLayout(Layout v) {
        suspend();
        this.layout = v;
        unsuspend();
    }

    /**
     * getter for graph layout
     * @return the layout
     */
    public Layout getGraphLayout() {
        return layout;
    }

    /**
     * Pre-relaxes and starts a visRunner thread
     */
    public synchronized void init() {
        if (visRunnerIsRunning) {
            throw new FatalException("Can't init while a visrunner is running");
        }
        relaxer = new VisRunner();
        relaxer.start();
    }

    boolean stop = false;

    boolean visRunnerIsRunning = false;

    protected class VisRunner extends Thread {
        public VisRunner() {
            super("Relaxer Thread");
        }

        // similar to 'run' in VisualizationViewer, but methods that
        // mutate the layout engine or graph are removed
        public void run() {
            visRunnerIsRunning = true;
            try {
                while (!stop) {

                    synchronized (pauseObject) {
                        while ((suspended || manualSuspend) && !stop) {
                            System.out.println("Going into suspend...");
                            try {
                                pauseObject.wait();
                            } catch (InterruptedException e) {
                            }
                            System.out.println("Coming out of suspend...");
                        }
                    }

                    if (stop)
                        return;

//                    String status = layout.getStatus();
//                    if (statusCallback != null && status != null) {
//                        statusCallback.callBack(status);
//                    }

                    if (stop)
                        return;

                    if (stop)
                        return;

                    repaint();

                    if (stop)
                        return;

                    try {
                        sleep(20);
                    } catch (InterruptedException ie) {
                    }
                }
            } finally {
                visRunnerIsRunning = false;
            }
            System.err.println("broke the loop");
        }
    }

    /**
     * If the visualization runner is not yet running, kick it off.
     */
    protected synchronized void start() {
        suspended = false;
        synchronized (pauseObject) {
            pauseObject.notifyAll();
        }
    }

    public synchronized void suspend() {
        manualSuspend = true;
    }

    public synchronized void unsuspend() {
        manualSuspend = false;
        synchronized (pauseObject) {
            pauseObject.notifyAll();
        }
    }

    public Object pauseObject = new String("PAUSE OBJECT");

    public boolean isPicked(Vertex v) {
        Boolean picked = (Boolean) v.getUserDatum(getVisKey());
        return ((picked != null) && (picked == Boolean.TRUE));
    }

    /**
     * @param picked
     * @param b
     */
    protected void pick(Vertex picked, boolean b) {
        if (b)
            layout.lockVertex(picked);
        else
            layout.unlockVertex(picked);
        Object key = getVisKey();
        if (picked.getUserDatum(key) != null) {
            picked.setUserDatum(key, b ? Boolean.TRUE : Boolean.FALSE,
                    UserData.REMOVE);
        } else {
            picked.addUserDatum(key, b ? Boolean.TRUE : Boolean.FALSE,
                    UserData.REMOVE);
        }
    }

    public static final String VIS_KEY = "edu.uci.ics.jung.visualization";

    protected Object key = null;

    protected Object getVisKey() {
        if (key == null)
            key = new Pair(this, VIS_KEY);
        return key;
    }

    /**
     * paint the graph components. The Graphics will have been transformed
     * by scalex and scaley prior to calling this method
     * @param g
     */
    private void paintGraph(Graphics g) {
        start();
        // paint all the Edges
        for (Iterator iter = layout.getVisibleEdges().iterator(); iter
                .hasNext();) {
            Edge e = (Edge) iter.next();
            Vertex v1 = (Vertex) e.getEndpoints().getFirst();
            Vertex v2 = (Vertex) e.getEndpoints().getSecond();
            renderer.paintEdge(g, e, (int) layout.getX(v1), 
                    (int) layout.getY(v1), (int) layout.getX(v2), (int) layout.getY(v2));
        }
        // Paint all the Vertices
        for (Iterator iter = layout.getVisibleVertices().iterator(); iter
                .hasNext();) {
            Vertex v = (Vertex) iter.next();
            renderer.paintVertex(g, v, (int) layout.getX(v), 
                    (int) layout.getY(v));
        }
    }

    /**
     * paint the graph, transforming with the scalex and scaley
     */
    protected synchronized void paintComponent(Graphics g) {

        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g;
		g2d.setRenderingHints(renderingHints);

        AffineTransform oldXform = g2d.getTransform();
        AffineTransform newXform = new AffineTransform(oldXform);
        newXform.scale(scalex, scaley);
        g2d.setTransform(newXform);

        paintGraph(g);

        Color oldColor = g.getColor();
        // the Lens will be cyan
        g2d.setColor(Color.cyan);
        
        // put the old transform back (not scaled) to draw the Lens
        g2d.setTransform(oldXform);
        if (lens != null) {
            g2d.draw(lens);
        }
        // restore old color after drawing the Lens
        g.setColor(oldColor);
    }

}