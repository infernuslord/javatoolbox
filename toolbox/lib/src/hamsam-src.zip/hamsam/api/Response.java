/*
 * Hamsam - Instant Messaging API
 * Copyright (C) 2003 Raghu K
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package hamsam.api;

import java.io.Serializable;

/**
 * A response to allow or disallow a user request.
 *
 * There are scenarios where the user is asked to allow or
 * disallow a request that came from another user. Some
 * examples are request to add a user to another user's
 * buddy list, an invitation for conference, and request for
 * file transfer. If they disallow such requests, they are requested
 * to give an explanation why they chose to disallow the
 * request. This class encapsulates the choice that the user
 * made as well as the explanation they gave, if any.
 *
 * @author Raghu
 */
public class Response implements Serializable
{
	/**
	 * Does this Response accept the request?
	 */
	private boolean accept;

	/**
	 * The explanation for rejection.
	 */
	private String message;

	/**
	 * Creates a response which accepts the request involved.
	 */
	public Response()
	{
		this.accept = true;
	}

	/**
	 * Creates a response which rejects the request involved.
	 *
	 * @param message the explanation for the rejection.
	 */
	public Response(String message)
	{
		this.accept = false;
		this.message = new String(message);
	}

	/**
	 * Determines if this response accepts the request involved.
	 *
	 * @return <code>true</code> if the response accepts request involved,
	 *         <code>false</code> otherwise.
	 */
	public boolean isAccepted()
	{
		return accept;
	}

	/**
	 * Returns the explanation for rejection of the request involved.
	 *
	 * @return the explanation message if the request was rejected,
	 *         <code>null</code> otherwise.
	 */
	public String getMessage()
	{
		return message;
	}
}
