package phelps.io;

import java.io.OutputStream;



/**
	Utility methods for {@link java.io.OutputStream}s.

	<ul>
	<li>{@link #DEVNULL}
	</ul>

	@version $Revision: 1.1 $ $Date: 2003/08/17 14:24:28 $
*/
public class OutputStreams {
  public final static OutputStream DEVNULL = new OutputStream() {
	public void close() {}
	public void flush() {}
	public void write(byte[] b) {}
	public void write(byte[] b, int off, int len) {}
	public void write(int b) {}
  };

  private OutputStreams() {}
}
