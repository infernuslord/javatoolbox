/*
 * Copyright (c) 2003, the JUNG Project and the Regents of the University of
 * California All rights reserved.
 * 
 * This software is open-source under the BSD license; see either "license.txt"
 * or http://jung.sourceforge.net/license.txt for a description.
 */
package edu.uci.ics.jung.visualization;

import java.awt.BorderLayout;
import java.awt.Color;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.decorators.EdgeColorFunction;
import edu.uci.ics.jung.graph.decorators.EdgeThicknessFunction;
import edu.uci.ics.jung.graph.decorators.StringLabeller;
import edu.uci.ics.jung.graph.decorators.VertexColorFunction;
import edu.uci.ics.jung.graph.filters.Filter;
import edu.uci.ics.jung.graph.filters.LevelFilter;
import edu.uci.ics.jung.graph.filters.SerialFilter;
import edu.uci.ics.jung.graph.filters.impl.DropSoloNodesFilter;
import edu.uci.ics.jung.visualization.graphdraw.SettableRenderer;

/**
 * A Swing-only component for drawing graphs. Allows a series of manipulations
 * to access and show graphs, to set their various colors and lines, and to
 * dynamically change values. This is a good starting place for getting a graph
 * up quickly.
 * 
 * @author Danyel Fisher
 */
public class GraphDraw extends JComponent implements StatusCallback {

	protected Graph graph;
	private final SettableRenderer originalRenderer;
	protected Renderer r;
	protected Layout layout;
	protected VisualizationViewer vv;
	protected Filter mainFilter;

	protected List allFilters = new LinkedList();
	protected List sliders = new LinkedList();

	protected JPanel toolbar;
	protected JLabel statusbar;

	/**
	 * Creates a graph drawing environment that draws this graph object. By
	 * default, uses the Spring layout, the Fade renderer and the
	 * AbstractSettable renderer, the Drop Solo Nodes filter, and no adjustable
	 * filters at all. By default, now HIDES the status bar; call showStatus()
	 * to show it. 
	 * 
	 * @param g
	 */
	public GraphDraw(Graph g) {
		this.graph = g;
		StringLabeller sl = StringLabeller.getLabeller(g);
		layout = new SpringLayout(g);
		originalRenderer = new SettableRenderer(sl);
		r = originalRenderer;
		vv = new VisualizationViewer(layout, r);
		setLayout(new BorderLayout());
		add(vv, BorderLayout.CENTER);

		toolbar = new JPanel();
		add(toolbar, BorderLayout.WEST);
        toolbar.setVisible(false);
        
		statusbar = new JLabel(" ");
		add(statusbar, BorderLayout.SOUTH);
		vv.setTextCallback(this);
		hideStatus();

		mainFilter = DropSoloNodesFilter.getInstance();
	}

	/**
	 * Returns the visualizationviewer that actually does the graph drawing.
	 */
	public VisualizationViewer getVisualizationViewer() {
		return vv;
	}

	
	/**
	 * This is the interface for adding a mouse listener. The GEL
	 * will be called back with mouse clicks on vertices.
	 * @param gel
	 */
	public void addGraphMouseListener( GraphMouseListener gel ) {
		vv.addMouseListener( new MouseListenerTranslator( gel, vv ));
	}
	
	/**
	 * Shows the status bar at bottom left
	 */
	public void showStatus() {
		statusbar.setVisible(true);
	}

	/**
	 * Hides the status bar at bottom left
	 */
	public void hideStatus() {
		statusbar.setVisible(false);
	}

	public void setBackground(Color bg) {
		super.setBackground(bg);
		vv.setBackground(bg);
	}

	public void callBack(String status) {
		statusbar.setText(status);
	}

	/**
	 * A method to set the renderer.
	 * 
	 * @param r
	 *            the new renderer
	 */
	public void setRenderer(Renderer r) {
		this.r = r;
		vv.setRenderer(r);
	}

	public void resetRenderer() {
		this.r = originalRenderer;
		vv.setRenderer(r);
	}

    /**
     * Returns the original renderer, whether or not it is currently in use.
     * 
     * @deprecated As of version 1.5.2, replaced by getRenderer.
     */
	public Renderer getRender() {
		return originalRenderer;
	}

    /**
     * Returns the renderer currently in use.
     */
    public Renderer getRenderer()
    {
        return vv.renderer;
    }
    
	/**
	 * A passthrough to the function at <code>originalRenderer</code>.
	 * 
	 * @param c
	 *            the new edge color
	 */
	public void setEdgeColor(Color c) {
		originalRenderer.setEdgeColor(c);
	}

	/**
	 * A passthrough to the function at <code>originalRenderer</code>.
	 * 
	 * @param ecf
	 *            the new <code>EdgeColorFunction</code>
	 */
	public void setEdgeColorFunction(EdgeColorFunction ecf) {
		originalRenderer.setEdgeColorFunction(ecf);
	}

	/**
	 * A passthrough to the function at <code>originalRenderer</code>.
	 * 
	 * @param i
	 *            the thickness of the edge
	 */
	public void setEdgeThickness(int i) {
		originalRenderer.setEdgeThickness(i);
	}

	/**
	 * A passthrough to the function at <code>originalRenderer</code>.
	 * 
	 * @param etf
	 *            the new <code>EdgeThicknessFunction</code>
	 */
	public void setEdgeThicknessFunction(EdgeThicknessFunction etf) {
		originalRenderer.setEdgeThicknessFunction(etf);
	}

	/**
	 * A passthrough to the function at <code>originalRenderer</code>.
	 * 
	 * @param vertexColor
	 *            the new foreground color of the vertices
	 */
	public void setVertexForegroundColor(Color vertexColor) {
		originalRenderer.setVertexForegroundColor(vertexColor);
	}

	/**
	 * A passthrough to the function at <code>originalRenderer</code>.
	 * 
	 * @param vertexColor
	 *            the new picked color of the vertices
	 */
	public void setVertexPickedColor(Color vertexColor) {
		originalRenderer.setVertexPickedColor(vertexColor);
	}

	/**
	 * A passthrough to the function at <code>originalRenderer</code>.
	 * 
	 * @param vertexColor
	 *            the background color of the vertex that is to be set
	 */
	public void setVertexBGColor(Color vertexColor) {
		originalRenderer.setVertexBGColor(vertexColor);
	}

	/**
	 * A passthrough to the function at <code>originalRenderer</code>.
	 * 
	 * @param vcf
	 *            the new <code>VertexColorFunction</code>
	 */
	public void setVertexColorFunction(VertexColorFunction vcf) {
		originalRenderer.setVertexColorFunction(vcf);
	}

	/**
	 * Dynamically chooses a new GraphLayout.
	 * 
	 * @param l
	 *            the new graph layout algorithm
	 */
	public void setGraphLayout(Layout l) {
		this.layout = l;
		vv.setGraphLayout(l);
	}

	/**
	 * Removes all the filters, deleting the sliders that drive them.
	 */
	public void removeAllFilters() {
		toolbar.removeAll();
        toolbar.setVisible(false);
		sliders.clear();
		allFilters.clear();
		mainFilter = new SerialFilter(allFilters);
	}

	/**
	 * Adds a Filter that doesn't slide.
	 * 
	 * @param f
	 */
	public void addStaticFilter(Filter f) {
		allFilters.add(f);
		mainFilter = new SerialFilter(allFilters);
	}

	/**
	 * Creates a new slider based off of a <tt>LevelFilter</tt>. The
	 * function adds the <tt>Filter</tt> into the sequence of filters
	 * preserved by the current visualization, creates a JSlider to go with it,
	 * and then returns it.
	 * <p>
	 * TODO: The situation may not be entirely right until applyFilter has been
	 * called.
	 * 
	 * @param l
	 *            The Filter to use.
	 * @param low
	 *            The low value on the filter: this will be the low point on
	 *            the slider
	 * @param high
	 *            The high value on the filter: this will be the high point on
	 *            the slider
	 * @param defaultVal
	 *            The starting point on the filter
	 * @return the slider (which will have been also added to the Sliders
	 *         panel)
	 */
	public JSlider addSlider(LevelFilter l, int low, int high, int defaultVal) {
		JSlider js = new JSlider(JSlider.VERTICAL, low, high, defaultVal);
		l.setValue(defaultVal);
		sliders.add(js);
		toolbar.add(js);
        toolbar.setVisible(true);
		js.addChangeListener(new SliderChangeListener(this, js, l));
		allFilters.add(l);
		mainFilter = new SerialFilter(allFilters);
		return js;
	}

	/**
	 * Adds a tool to the toolbar.
	 * 
	 * @param jc
	 *            the tool--any JComponent--to be added to the Toolbar on the
	 *            left side
	 */
	public void addTool(JComponent jc) {
		toolbar.add(jc);
        toolbar.setVisible(true);
	}

	protected class SliderChangeListener implements ChangeListener {
		protected LevelFilter levelFilter;
		protected JSlider js;
		protected GraphDraw gd;

		int oldValue = -1;

		public SliderChangeListener(GraphDraw gd, JSlider js, LevelFilter l) {
			this.levelFilter = l;
			this.js = js;
			this.gd = gd;
		}

		public void stateChanged(ChangeEvent e) {
			int val = js.getValue();
			if (oldValue == val) {
				return;
			}
			oldValue = val;
			levelFilter.setValue(val);
			Graph fg = gd.mainFilter.filter(gd.graph).assemble();
			gd.layout.applyFilter(fg);
		}

	}
	/**
	 * Returns the currently operative layout.
	 */
	public Layout getGraphLayout() {
		return layout;
	}

	/**
	 * This is the "scramble" button--it resets the layout.
	 */
	public void restartLayout() {
		vv.restart();
	}

	/**
	 *  
	 */
	public void stop() {
		vv.stop();
	}

}
