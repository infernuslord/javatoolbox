package phelps.io;

import java.io.OutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;



/**
	OutputStream that counts the number of bytes written to it.

	@version $Revision: 1.2 $ $Date: 2003/08/17 14:23:16 $
*/
public class OutputStreamCount extends FilterOutputStream {
  private long size_ = 0L;

  public OutputStreamCount(OutputStream out) { super(out); }
  public void write(byte[] b) throws IOException { out.write(b); size_ += b.length; }
  public void write(byte[] b, int off, int len) throws IOException { out.write(b,off,len); size_ += len; }
  public void write(int b) throws IOException { out.write(b); size_++; }

  /** Resets count of number of bytes written to stream to 0. */
  public void reset() { size_=0L; }
  /** Returns count of number of bytes written to stream. */
  public long size() { return size_; }	// ByteArrayOutputStream uses size(), but otherwise would choose length()
}
