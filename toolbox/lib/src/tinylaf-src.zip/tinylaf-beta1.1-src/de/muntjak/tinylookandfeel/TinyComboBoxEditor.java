/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	Tiny Look and Feel                                                         *
*                                                                              *
*  (C) Copyright 2003, Hans Bickel                                             *
*                                                                              *
*   For licensing information and credits, please refer to the                 *
*   comment in file de.muntjak.tinylookandfeel.TinyLookAndFeel                 *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package de.muntjak.tinylookandfeel;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.AbstractBorder;
import javax.swing.plaf.metal.MetalComboBoxEditor;

import de.muntjak.tinylookandfeel.controlpanel.*;

/**
 * TinyComboBoxEditor
 * 
 * @version 1.1
 * @author Hans Bickel
 */
public class TinyComboBoxEditor extends MetalComboBoxEditor {
	  
    public TinyComboBoxEditor() {
        super();
        
        editor.setBorder(new EditorBorder());
    }
    
    class EditorBorder extends AbstractBorder {

    	/**
		* @see javax.swing.border.Border#getBorderInsets(java.awt.Component)
		*/
		public Insets getBorderInsets(Component c) {
				 return Theme.comboInsets[Theme.style];
		}
		
		/**
		* @see javax.swing.border.Border#paintBorder(java.awt.Component, java.awt.Graphics, int, int, int, int)
		*/
		public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
			JComponent cb = (JComponent)editor.getParent();
			if(cb.getBorder() == null) return;
			
			switch(Theme.derivedStyle[Theme.style]) {
				case Theme.TINY_STYLE:
					drawTinyBorder(c, g, x, y, w, h);
					break;
				case Theme.WIN_STYLE:
					drawWinBorder(c, g, x, y, w, h);
					break;
				case Theme.XP_STYLE:
					drawXpBorder(c, g, x, y, w, h);
					break;
			}
		}
    }
    
    private void drawTinyBorder(Component c, Graphics g, int x, int y, int w, int h) {
		if (!c.isEnabled()) {
			g.setColor(Theme.textBorderDisabledColor[Theme.style].getColor());
		}
		else {
			g.setColor(Theme.textBorderColor[Theme.style].getColor());
		}		
		g.drawRect(x + 1, y + 1, w - 3, h - 3);
		
		if (!c.isEnabled()) {
			g.setColor(Theme.textDarkDisabledColor[Theme.style].getColor());
		}
		else {
			g.setColor(Theme.textDarkColor[Theme.style].getColor());
		}
		g.drawLine(x, y, x + w - 2, y);
		g.drawLine(x, y + 1, x, y + h - 2);
		
		if (!c.isEnabled()) {
			g.setColor(Theme.textLightDisabledColor[Theme.style].getColor());
		}
		else {
			g.setColor(Theme.textLightColor[Theme.style].getColor());
		}
		g.drawLine(x, y + h - 1, x + w - 1, y + h - 1);
		g.drawLine(x + w - 1, y, x + w - 1, y + h - 2);
	}
		
	private void drawWinBorder(Component c, Graphics g, int x, int y, int w, int h) {
		if (!c.isEnabled()) {
			g.setColor(Theme.textBorderDisabledColor[Theme.style].getColor());
		}
		else {
			g.setColor(Theme.textBorderColor[Theme.style].getColor());
		}		
		g.drawLine(x + 1, y + 1, x + w - 1, y + 1);
		g.drawLine(x + 1, y + 2, x + 1, y + h - 3);
		
		if (!c.isEnabled()) {
			g.setColor(Theme.textDarkDisabledColor[Theme.style].getColor());
		}
		else {
			g.setColor(Theme.textDarkColor[Theme.style].getColor());
		}
		g.drawLine(x, y, x + w - 1, y);
		g.drawLine(x, y + 1, x, y + h - 2);
		
		g.setColor(Theme.backColor[Theme.style].getColor());
		g.drawLine(x + 1, y + h - 2, x + w - 1, y + h - 2);
		
		if (!c.isEnabled()) {
			g.setColor(Theme.textLightDisabledColor[Theme.style].getColor());
		}
		else {
			g.setColor(Theme.textLightColor[Theme.style].getColor());
		}
		g.drawLine(x, y + h - 1, x + w - 1, y + h - 1);
	}
	
	private void drawXpBorder(Component c, Graphics g, int x, int y, int w, int h) {
		if (!c.isEnabled()) {
         	DrawRoutines.drawEditableComboBorder(
				g, Theme.comboBorderDisabledColor[Theme.style].getColor(), 0, 0, w, h);
		}
		else {
			DrawRoutines.drawEditableComboBorder(
				g, Theme.comboBorderColor[Theme.style].getColor(), 0, 0, w, h);
		}
	}


    /**
     * A subclass of BasicComboBoxEditor that implements UIResource.
     * BasicComboBoxEditor doesn't implement UIResource
     * directly so that applications can safely override the
     * cellRenderer property with BasicListCellRenderer subclasses.
     * <p>
     * <strong>Warning:</strong>
     * Serialized objects of this class will not be compatible with
     * future Swing releases. The current serialization support is
     * appropriate for short term storage or RMI between applications running
     * the same version of Swing.  As of 1.4, support for long term storage
     * of all JavaBeans<sup><font size="-2">TM</font></sup>
     * has been added to the <code>java.beans</code> package.
     * Please see {@link java.beans.XMLEncoder}.
     */
    public static class UIResource extends TinyComboBoxEditor
    	implements javax.swing.plaf.UIResource {
    }
}


