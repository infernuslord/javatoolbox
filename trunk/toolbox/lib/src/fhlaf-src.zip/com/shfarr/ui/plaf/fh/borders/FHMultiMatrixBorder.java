/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh.borders;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

import javax.swing.border.AbstractBorder;
import javax.swing.border.Border;
import javax.swing.plaf.UIResource;


public class FHMultiMatrixBorder extends AbstractBorder implements UIResource{
    private TreeMap map = null;
    private Object key = null;
    
    protected FHMultiMatrixBorder(){
        map = new TreeMap();
        key = "normal";
    }

    public FHMultiMatrixBorder(String[] keys, Object[] matrices){
        map = new TreeMap();
        
        int count = 0;
        
        for(int i = 0; i < keys.length; i++){
            if(matrices[i] != null){
                map.put(keys[i], matrices[i]);
                count++;
            }
        }
        
        if(count == 0) throw new Error("Empty border list error");
        
        key = "normal";
    }

    public FHMultiMatrixBorder deriveBorder(int rotation){
        FHMultiMatrixBorder mmb = new FHMultiMatrixBorder();
        
        for(Iterator iter = map.keySet().iterator(); iter.hasNext(); ){
            String key = (String)iter.next();
            mmb.map.put(key, getBorder(key).deriveBorder(rotation));
        }
        
        return mmb;
    }
 
    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height){
        if(key == null) key = "normal";
        
        Border b = (Border)map.get(key);
        if(b == null) b = (Border)map.get("normal");
        
        b.paintBorder(c, g, x, y, width, height);
    }

    public Insets getBorderInsets(Component c){
        Border b = (Border)map.get(key);
        
        if(b == null) b = (Border)map.get("normal");
        
        return b.getBorderInsets(c);
    }

    public Insets getBorderInsets(Component c, Insets insets){
        Insets ins = getBorderInsets(c);
      
        insets.top = ins.top;
        insets.left = ins.left;
        insets.bottom = ins.bottom;
        insets.right = ins.right;
    
        return insets;
    }

    public void selectMatrix(Object key){
        if(key == null) key = "normal";
        
        this.key = key;
    }
    
    public Set keys(){
        return map.keySet();
    }
    
    public FhMatrixBorder getBorder(Object key){
        return (FhMatrixBorder)map.get(key);
    }
}
