// $Id: NumberExpr.java,v 1.1 2002/04/25 18:10:07 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

public interface NumberExpr {
    double eval(Node node, ExprContext context) throws XSLException;
}
