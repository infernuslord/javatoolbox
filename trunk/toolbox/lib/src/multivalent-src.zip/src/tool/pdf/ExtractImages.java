package tool.pdf;

import java.io.*;
import java.util.Iterator;

import multivalent.*;
import multivalent.std.adaptor.pdf.*;
import static multivalent.std.adaptor.pdf.COS.*;

import phelps.lang.Integers;
import phelps.io.FileList;



/**
	Extract images from PDF.
	Target image type can be anything supported by Java: JPEG, PNG;
	or if you have Image I/O installed, also JPEG2000, BMP, ....

	@version $Revision: 1.2 $ $Date: 2003/08/15 19:10:22 $
*/
public class ExtractImages {
  static final boolean DEBUG = true;

  public static final String USAGE = "java tool.pdf.ExtractImages [options] <PDF-file...>\n"
	+ "\t[-page <page-range>] [-objnum <range>] [-password <owner-password]";
//  [-format img] => v2.0
  public static final String VERSION = "0.1 of $Date: 2003/08/15 19:10:22 $";


  private String range_, objrange_;
  private String format_;
  private String password_;
  private boolean fverbose_, fquiet_, fmonitor_;
  private PrintStream out_;

  public ExtractImages() {
	defaults();
  }

  public void defaults() {
	range_ = null;
	objrange_ = null;
	password_ = null;

	fverbose_ = fquiet_ = fmonitor_ = false;
	out_ = phelps.io.PrintStreams.DEVNULL;
  }


  public void extract(File file) throws IOException, ParseException {
	if (fverbose_) System.out.println(file);
    assert file!=null && file.exists();

	PDFReader pdfr = new PDFReader(file);
	// must be owner password, or check PERM_COPY on user
	SecurityHandler sh = pdfr.getEncrypt().getSecurityHandler();
	//if (sh.authOwner(password_) || (sh.authUser(password_) && (sh.getP() & PERM_COPY) !=0)) ...

	int objcnt = pdfr.getObjCnt(), pagecnt = pdfr.getPageCnt();
	boolean[] fex = new boolean[objcnt];

	if (objrange_!=null) {
		for (int num: Integers.parseRange(objrange_, 1,objcnt)) {
			if (!fex[num]) { extract1(pdfr, num, "im"+num); fex[num]=true; }
		}

	} else {
		for (int pagenum: Integers.parseRange(range_, 1,pagecnt)) {
			Dict page = (Dict)pdfr.getPage(pagenum);	// inherit /Resources
			Dict res = (Dict)pdfr.getObject(page.get("Resources")); if (res==null) continue;
			Dict xo = (Dict)pdfr.getObject(res.get("XObject")); if (xo==null) continue;
			
			int pagesub = 1;
			for (Iterator<Object> i = xo.values().iterator(); i.hasNext(); ) {
				IRef ref = (IRef)i.next();
				Object o = pdfr.getObject(ref); if (CLASS_DICTIONARY != o.getClass()) continue;
				Dict xdict = (Dict)o; if (!"Image".equals(pdfr.getObject(xdict.get("Subtype")))) continue;

				int num = ref.id;
				if (!fex[num]) {
					extract1(pdfr, num, "im"+pagenum+(pagesub==1? "": "-"+pagesub));
					pagesub++; fex[num] = true;
				}
			}
		}
	}

	pdfr.close();
  }

  /** Adds image type suffix to path. */
  public void extract1(PDFReader pdfr, int objnum,  String pathout) throws IOException {
	Dict dict = (Dict)pdfr.getObject(objnum);
	String f = Images.getFilter(dict, pdfr);
	String sfx = "DCTDecode".equals(f)? "jpg": "CCITTFaxDecode".equals(f)? "fax": "JPXDecode".equals(f)? "jp2": "JBIG2Decode".equals(f)? "jbig2": "raw";

	extract1(pdfr, objnum, new File(pathout+"."+sfx));
  }


  public void extract1(PDFReader pdfr, int objnum,  File fileout) throws IOException {
	Object o = pdfr.getObject(objnum);
	if (o==null || CLASS_DICTIONARY!=o.getClass() || !"Image".equals(((Dict)o).get("Subtype"))) { out_.println("object #"+objnum+" not an image dictionary"); return; }

	Dict dict = (Dict)o;
	if ("JBIG2Decode".equals(Images.getFilter(dict, pdfr))) { out_.println("JBIG2 extraction not supported"); return; }
	InputStream in = pdfr.getInputStream(new IRef(objnum, pdfr.getObjGen(objnum)));

	if (format_ == null) {	// byte shovelling
		System.out.println("image "+objnum+" -> "+fileout);
		// for JBIG2 have to collect global table
		// have to wrap Fax and raw samples (raw=>PNG?)
		RandomAccessFile raf = new RandomAccessFile(fileout, "rw");
		byte[] buf = new byte[8*1024];
		for (int hunk; (hunk = in.read(buf)) >= 0; ) raf.write(buf, 0, hunk);
		raf.close();

	} else {	// realize image, convert to output format
		// ImageIO...
	}

	in.close();
  }



  private int commandLine(String[] argv) {
	out_ = System.out;

	int argi = 0, argc = argv.length;
	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.equals("-page") || arg.equals("-range")) range_ = argv[++argi];
		else if (arg.equals("-objnum")) objrange_ = argv[++argi];
		else if (arg.startsWith("-format")) format_ = argv[++argi];
		else if (arg.startsWith("-pass"/*"word"*/)) password_ = argv[++argi];

		else if (arg.startsWith("-verb")) fverbose_ = true;
		//else if (arg.startsWith("-q"/*uiet*/)) fquiet = true;
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.startsWith("-h"/*"elp"*/)) {
			System.out.println(USAGE); 
			// report formats available via ImageIO
			// ...
			System.exit(0);
		} else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	if (argi == argc) { System.err.println(USAGE); System.exit(0); }

	return argi;
  }

  public static void main(String[] argv) {
	ExtractImages e = new ExtractImages();
    int argi = e.commandLine(argv);

	for (Iterator<File> i = new FileList(argv, argi, FILTER).iterator(); i.hasNext(); ) {
		File file = i.next();
		try {
			//if (fquiet_) System.out.println(file);
			e.extract(file);
		} catch (Exception ioe) {
			System.err.println(file+": "+ioe);
			if (DEBUG) ioe.printStackTrace();
		}
	}
  }
}
