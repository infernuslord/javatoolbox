/** ====================================================================
 *
 * @PROJECT.FULLNAME@ @VERSION@ License.
 *
 * Copyright (c) @YEAR@ L2FProd.com.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by L2FProd.com
 *        (http://www.L2FProd.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "@PROJECT.FULLNAME@", "@PROJECT.SHORTNAME@" and "L2FProd.com" must not
 *    be used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact info@L2FProd.com.
 *
 * 5. Products derived from this software may not be called "@PROJECT.SHORTNAME@"
 *    nor may "@PROJECT.SHORTNAME@" appear in their names without prior written
 *    permission of L2FProd.com.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL L2FPROD.COM OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package com.l2fprod.common.swing;

import java.awt.Window;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.util.prefs.Preferences;

import javax.swing.JFileChooser;

/**
 * UserPreferences. <BR>
 *  
 */
public class UserPreferences {

  /**
   * Gets the default file chooser. Its current directory will be tracked and
   * restored on subsequent calls.
   * 
   * @return the default file chooser
   */
  public static JFileChooser getDefaultFileChooser() {
    return getFileChooser("default");
  }

  /**
   * Gets the default directory chooser. Its current directory will be tracked
   * and restored on subsequent calls.
   * 
   * @return the default directory chooser
   */
  public static JDirectoryChooser getDefaultDirectoryChooser() {
    return getDirectoryChooser("default");
  }

  /**
   * Gets the file chooser with the given id. Its current directory will be
   * tracked and restored on subsequent calls.
   * 
   * @param id
   * @return the file chooser with the given id
   */
  public static JFileChooser getFileChooser(final String id) {
    JFileChooser chooser = new JFileChooser();
    track(chooser, "FileChooser." + id + ".path");
    return chooser;
  }

  /**
   * Gets the directory chooser with the given id. Its current directory will
   * be tracked and restored on subsequent calls.
   * 
   * @param id
   * @return the directory chooser with the given id
   */
  public static JDirectoryChooser getDirectoryChooser(String id) {
    JDirectoryChooser chooser = new JDirectoryChooser();
    track(chooser, "DirectoryChooser." + id + ".path");
    return chooser;
  }

  private static void track(JFileChooser chooser, final String key) {
    Preferences prefs = node();
    // get the path for the given filechooser
    String path = node().get(key, null);
    if (path != null) {
      File file = new File(path);
      if (file.exists()) {
        chooser.setCurrentDirectory(file);
      }
    }

    PropertyChangeListener trackPath = new PropertyChangeListener() {
      public void propertyChange(PropertyChangeEvent evt) {
          // everytime the path change, update the preferences
  if (evt.getNewValue() instanceof File) {
          node().put(key, ((File)evt.getNewValue()).getAbsolutePath());
        }
      }
    };

    chooser.addPropertyChangeListener(
      JFileChooser.DIRECTORY_CHANGED_PROPERTY,
      trackPath);
  }

  /**
   * Restores the window size, position and state if possible. Tracks the
   * window size, position and state.
   * 
   * @param window
   */
  public static void track(Window window) {
    Preferences prefs = node().node("Windows");

    ComponentListener trackDimension = new ComponentAdapter() {
      public void componentMoved(ComponentEvent e) {
        super.componentMoved(e);
      }
      public void componentResized(ComponentEvent e) {
        super.componentResized(e);
      }
    };

    window.addComponentListener(trackDimension);
  }

  /**
   * @return the Preference node where User Preferences are stored.
   */
  private static Preferences node() {
    return Preferences.userNodeForPackage(UserPreferences.class).node(
      "UserPreferences");
  }

}
