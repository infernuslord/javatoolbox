package multivalent.std.ui;

import java.awt.*;
import java.awt.event.*;
import java.awt.datatransfer.*;

import multivalent.*;


/**
	Pluggable events duplicating some Macintosh key bindings.

	@see multivalent.std.ui.BindingsDefault
	@see multivalent.std.ui.BindingsTk

	@version $Revision: 1.3 $ $Date: 2005/07/28 03:43:18 $
*/
public class BindingsMacintosh extends Behavior implements EventListener {
  public void buildAfter(Document doc) {
	if (System.getProperty("os.name").toLowerCase().startsWith("mac os x"))
		doc.getRoot().addObserver(this);    // catch keys in tree
  }

  /**
	Where possible, convert into a standard key and let BindingsDefault catch it;
	for example, M-v => ACTION_PASTE.
  */
  public boolean eventAfter(AWTEvent e, Point rel, Node obsn) {
	int eid=e.getID();
	Browser br = getBrowser();
	//CursorMark cur = br.getCursorMark();

	if (eid==KeyEvent.KEY_PRESSED) {
		//if (seized) br.setGrab(this);   // so get key up
		KeyEvent ke = (KeyEvent)e;
		int keycode = ke.getKeyCode();

		boolean grab = true;

		// Meta
		if (ke.isMetaDown()) {
			switch (keycode) {
			// re-throw these to BindingsDefault
			case 'V': br.eventq(new KeyEvent(br, eid, ke.getWhen()+1, 0, KeyEvent.VK_PASTE, ke.getKeyChar(), ke.getKeyLocation())); grab=false; break;
			case 'C': br.eventq(new KeyEvent(br, eid, ke.getWhen()+1, 0, KeyEvent.VK_COPY, ke.getKeyChar(), ke.getKeyLocation())); grab=false; break;
			default:
				grab = false;
			}
		}
	}
	return false;
  }

  public void event(AWTEvent e) {
	if (e.getID()==KeyEvent.KEY_RELEASED) getBrowser().releaseGrab(this);
  }
}
