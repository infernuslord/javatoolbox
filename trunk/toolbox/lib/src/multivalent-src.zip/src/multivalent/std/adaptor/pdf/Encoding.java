package multivalent.std.adaptor.pdf;

import java.util.Map;
import java.util.HashMap;
import java.io.IOException;
import java.io.File;
import java.util.Arrays;

import multivalent.MediaAdaptor;
import phelps.lang.Strings;
import phelps.awt.Fonts;



/**
	Character encoding, from Macintosh, Windoze, Standard, PDF to Unicode.
	Can translate to Unicode or differences to original for widths table,
	and encapsulates bizarre Windows +0xf000.

	@version $Revision: 1.26 $ $Date: 2003/10/04 22:46:47 $
*/
public class Encoding {
//  public static final int MACROMAN_ENCODING=0, MACEXPERT_ENCODING=1, WINANSI_ENCODING=2;
  private static final int MS_IDIOCY = 0;//0xf000; -- Java does this now?

  private static final char INVALID_CHAR = '\0';    // => -1/\uffff

  private static final char[] macRomanMap_=new char[256], macExpertMap_=new char[256],
	winAnsiMap_=new char[256], standardMap_=new char[256],
	pdfMap_=new char[256],  // "it is not customary to use this encoding to show text from fonts"
	symbolMap_=new char[256], zapfMap_=new char[256],
	texMap_=new char[256];
  private static final char[] macRoman2std_, winAnsi2std_, pdf2std_;
  //protected static final char[][] coreEncodings_ = new char[256][6];  // array so can iterate over, in constuctiong base and picking from string name

  private static final char[] IDENTITY_MAP = new char[256];

  /** Special case encoding. */
  private static final Encoding /*TEX161_ENCODING, TEX163_ENCODING,*/ IDENTITY_ENCODING;
  //protected static Map cache = new HashMap(10);   => done by caller
  private static final Encoding IDENTITY_H_ENCODING = new IdentityH();


  // table from PDF References, augmented with Unicode
  // STD MAC WIN PDF ... Unicode
  // take these out of class namespace and put in static code block
  static final String[] refTable_ = {    // this cost a lot of carpal tunnel points
	"AE", "\341\256\306\306\u00c6",
	"Aacute", "\000\347\301\301\u00c1",
	"Acircumflex", "\000\345\302\302\u00c2",
	"Adieresis", "\000\200\304\304\u00c4",
	"Agrave", "\000\313\300\300\u00c0",
	"Aring", "\000\201\305\305\u00c5",
	"Atilde", "\000\314\303\303\u00c3",

	"Ccedilla", "\000\202\307\307\u00c7",

	"Eacute", "\000\203\311\311\u00c9",
	"Ecircumflex", "\000\346\312\312\u00ca",
	"Edieresis", "\000\350\313\313\u00cb",
	"Egrave", "\000\351\310\310\u00c8",
	"Eth", "\000\000\320\320\u00d0",
	"Euro", "\000\000\200\240\u20ac",

	"Iacute", "\000\352\315\315\u00cd",
	"Icircumflex", "\000\353\316\316\u00ce",
	"Idieresis", "\000\354\317\317\u00cf",
	"Igrave", "\000\355\314\314\u00cc",

	"Lslash", "\350\000\000\225\u0141",

	"Ntilde", "\000\204\321\321\u00d1",

	"OE", "\352\316\214\226\u0152",
	"Oacute", "\000\356\323\323\u00d3",
	"Ocircumflex", "\000\357\324\324\u00d4",
	"Odieresis", "\000\205\326\326\u00d6",
	"Ograve", "\000\361\322\322\u00d2",
	"Oslash", "\351\257\330\330\u00d8",
	"Otilde", "\000\315\325\325\u00d5",

	"Scaron", "\000\000\212\227\u0160",

	"Thorn", "\000\000\336\336\u00de",

	"Uacute", "\000\362\332\332\u00da",
	"Ucircumflex", "\000\363\333\333\u00db",
	"Udieresis", "\000\206\334\334\u00dc",
	"Ugrave", "\000\364\331\331\u00d9",

	"Yacute", "\000\000\335\335\u00dd",
	"Ydieresis", "\000\331\237\230\u0178",

	"Zcaron", "\000\000\216\231\u017d",

	"aacute", "\000\207\341\341\u00e1",
	"acircumflex", "\000\211\342\342\u00e2",
	"acute", "\302\253\264\264\u00b4",
	"adieresis", "\000\212\344\344\u00e4",
	"ae", "\361\276\346\346\u00e6",
	"agrave", "\000\210\340\340\u00e0",
	//"ampersand", "\046\046\046\046&",
	"aring", "\000\214\345\345\u00e5",
	"asciicircum", "\136\136\136\136^",
	"asciitilde", "\176\176\176\176~",
	"asterisk", "\052\052\052\052*",
	//"at", "\100\100\100\100@", -- same everywhere with ASCII encoding
	"atilde", "\000\213\343\343\u00e3",

	//"backslash", "\134\134\134\134\\",
	//"bar", "\174\174\174\174|",
	//"braceleft", "\173\173\173\173{",
	//"braceright", "\175\175\175\175}",
	//"bracketleft", "\133\133\133\133[",
	//"bracketright", "\135\135\135\135]",
	"breve", "\306\371\000\030\u0306",
	"brokenbar", "\000\000\246\246\u00a6",
	"bullet", "\267\245\225\200\u2022",

	"caron", "\317\377\000\031\u02c7",
	"ccedilla", "\000\215\347\347\u00e7",
	"cedilla", "\313\374\270\270\u00b8",
	"cent", "\242\242\242\242\u00a2",
	"circumflex", "\303\366\210\032\u02c6",
	//"colon", "\072\072\072\072:",
	//"comma", "\054\054\054\054,",
	"copyright", "\000\251\251\251\u00a9",
	"currency", "\250\333\244\244\u00a4",

	"dagger", "\262\240\206\201\u2020",
	"daggerdbl", "\263\340\207\202\u2021",
	"degree", "\000\241\260\260\u00b0",
	"dieresis", "\310\254\250\250\u00a8",
	"divide", "\000\326\367\367\u00f7",
	//"dollar", "\044\044\044\044$",
	"dotaccent", "\307\372\000\033\u02d9",
	"dotlessi", "\365\365\000\232\u0131",

	"eacute", "\000\216\351\351\u00e9",
	"ecircumflex", "\000\220\352\352\u00ea",
	"edieresis", "\000\221\353\353\u00eb",
	"egrave", "\000\217\350\350\u00e8",
	"ellipsis", "\274\311\205\203\u2026",
	"emdash", "\320\321\227\204\u2014",
	"endash", "\261\320\226\205\u2013",
	//"equal", "\075\075\075\075=",
	"eth", "\000\000\360\360\u00f0",
	//"exclam", "\041\041\041\041!",
	"exclamdown", "\241\301\241\241\u00a1",

	"fi", "\256\336\000\223\ufb01",
	"fl", "\257\337\000\224\ufb02",
	"florin", "\246\304\203\206\u0192",
	"fraction", "\244\332\000\207\u2044",

	"germandbls", "\373\247\337\337\u00df",
	"grave", "\301\140\140\140\u0060",
	//"greater", "\076\076\076\076>",
	"guillemotleft", "\253\307\253\253\u00ab",
	"guillemotright", "\273\310\273\273\u00bb",
	"guilsinglleft", "\254\334\213\210\u2039",
	"guilsinglright", "\255\335\233\211\u203a",

	"hungarumlaut", "\315\375\000\034\u00a8",
	//"hyphen", "\055\055\055\055-",

	"iacute", "\000\222\355\355\u00ed",
	"icircumflex", "\000\224\356\356\u00ee",
	"idieresis", "\000\225\357\357\u00ef",
	"igrave", "\000\223\354\354\u00ec",

	//"less", "\074\074\074\074<",
	"logicalnot", "\000\302\254\254\u00ac",
	"lslash", "\370\000\000\233\u0142",

	"macron", "\305\370\257\257\u00af",
	"minus", "\000\000\000\212\u2212",
	"mu", "\000\265\265\265\u03bc",
	"multiply", "\000\000\327\327\u00d7",

	"ntilde", "\000\226\361\361\u00f1",
	//"numbersign", "\043\043\043\043#",

	"oacute", "\000\227\363\363\u00f3",
	"ocircumflex", "\000\231\364\364\u00f4",
	"odieresis", "\000\232\366\366\u00f6",
	"oe", "\372\317\234\234\u0153",
	"ogonek", "\316\376\000\035\u02db",
	"ograve", "\000\230\362\362\u00f2",
	"onehalf", "\000\000\275\275\u00bd",
	"onequarter", "\000\000\274\274\u00bc",
	"onesuperior", "\000\000\271\271\u00b9",
	"ordfeminine", "\343\273\252\252\u00aa",
	"ordmasculine", "\353\274\272\272\u00ba",
	"oslash", "\371\277\370\370\u00f8",
	"otilde", "\000\233\365\365\u00f5",

	"paragraph", "\266\246\266\266\u00b6",
	//"parenleft", "\050\050\050\050(",
	//"parenright", "\051\051\051\051)",
	//"percent", "\045\045\045\045%",
	//"period", "\056\056\056\056.",
	"periodcentered", "\264\341\267\267\u00b7",
	"perthousand", "\275\344\211\213\u2030",
	//"plus", "\053\053\053\053+",
	"plusminus", "\000\261\261\261\u00b1",

	//"question", "\077\077\077\077?",
	"questiondown", "\277\300\277\277\u00bf",
	"quotedbl", "\042\042\042\042\"",
	"quotedblbase", "\271\343\204\214\u201e",
	"quotedblleft", "\252\322\223\215\u201c",
	"quotedblright", "\272\323\224\216\u201d",
	"quoteleft", "\140\324\221\217\u2018",
	"quoteright", "\047\325\222\220\u2019",
	"quotesinglbase", "\270\342\202\221\u201a",
	"quotesingle", "\251\047\047\047\'",

	"registered", "\000\250\256\256\u00ae",
	"ring", "\312\373\000\036\u02da",

	"scaron", "\000\000\232\235\u0161",
	"section", "\247\244\247\247\u00a7",
	//"semicolon", "\073\073\073\073;",
	//"slash", "\057\057\057\057/",
	//"space", "\040\040\040\040 ",
	"sterling", "\243\243\243\243\u00a3",

	"thorn", "\000\000\376\376\u00fe",
	"threequarters", "\000\000\276\276\u00be",
	"threesuperior", "\000\000\263\263\u00b3",
	"tilde", "\304\367\230\037\u02dc",
	"trademark", "\000\252\231\222\u2122",
	"twosuperior", "\000\000\262\262\u00b2",

	"uacute", "\000\234\372\372\u00fa",
	"ucircumflex", "\000\236\373\373\u00fb",
	"udieresis", "\000\237\374\374\u00fc",
	"ugrave", "\000\235\371\371\u00f9",
	"underscore", "\137\137\137\137_",

	"yacute", "\000\000\375\375\u00fd",
	"ydieresis", "\000\330\377\377\u00ff",
	"yen", "\245\264\245\245\u00a5",

	"zcaron", "\000\000\236\236\u017e",

	// additions necessary in practice
	"shy", "\000\000\255\000\u00ad",
  };

  // symbol ... Unicode
  // http://www.unicode.org/Public/MAPPINGS/VENDORS/ADOBE/symbol.txt
  static final String[] refTableSym_ = {
	// digits same everywhere
	"Alpha", "\101\u0391",
	"Beta", "\102\u0392",
	"Chi", "\103\u03a7",
	"Delta", "\104\u0394",
	"Epsilon", "\105\u0395",
	"Eta", "\110\u0397",
	"Euro", "\240\u20ac",
	"Gamma", "\107\u0393",
	"Ifraktur", "\301\u2111",
	"Iota", "\111\u0399",
	"Kappa", "\113\u039a",
	"Lambda", "\114\u039b",
	"Mu", "\115\u039c",
	"Nu", "\116\u039d",
	"Omega", "\127\u03a9",
	"Omicron", "\117\u039f",
	"Phi", "\106\u03a6",
	"Pi", "\120\u03a0",
	"Psi", "\131\u03a8",
	"RFraktur", "\302\u211c",
	"Rho", "\122\u03a1",
	// no \u03a2
	"Sigma", "\123\u03a3",
	"Tau", "\124\u03a4",
	"Theta", "\121\u0398",
	"Upsilon", "\125\u03a5",
	"Upsilon1", "\241\u03d2",
	"Xi", "\130\u039e",
	"Zeta", "\132\u0396",
	"aleph", "\300\u2135",
	"alpha", "\141\u03b1",
	//"ampersand", "\046u00",
	"angle", "\320\u2220",
	"angleleft", "\341\u2329",
	"angleright", "\361\u232a",
	"approxequal", "\237\u2248",
	"arrowboth", "\253\u2194",
	"arrowdblboth", "\333\u21d4",
	"arrowdbldown", "\337\u21d3",
	"arrowdblleft", "\334\u21d0",
	"arrowdblright", "\336\u21d2",
	"arrowdblup", "\335\u21d1",
	"arrowdown", "\257\u2193",
	"arrowhorizex", "\276\uf8e7",
	"arrowleft", "\254\u2190",
	"arrowright", "\256\u2192",
	"arrowup", "\255\u2191",
	"arrowvertex", "\275\uf8e6",
	"asteriskmath", "\052\u2217",
	//"bar", "\174|",
	"beta", "\142\u03b2",
	//"braceleft", "\173u00",
	//"braceright", "\175u00",
	"bracelefttp", "\354\uf8f1",
	"braceleftmid", "\355\uf8f2",
	"braceleftbt", "\356\uf8f3",
	"bracerighttp", "\374\uf8fc",
	"bracerightmid", "\375\uf8fd",
	"bracerightbt", "\376\uf8fe",
	"braceex", "\357\uf8f4",
	//"bracketleft", "\133u00",
	//"bracketright", "\135u00",
	"bracketlefttp", "\351\uf8ee",
	"bracketleftex", "\352\uf8ef",
	"bracketleftbt", "\353\uf8f0",
	"bracketrighttp", "\371\uf8f9",
	"bracketrightex", "\372\uf8fa",
	"bracketrightbt", "\373\uf8fb",
	"bullet", "\267\u2022",     // conflict
	"carriagereturn", "\277\u21b5",
	"chi", "\143\u03c7",
	"circlemultiply", "\304\u2297",
	"circleplus", "\305\u2295",
	"club", "\247\u2663",
	//"colon", "\072u00",
	//"comma", "\054u00",
	"congruent", "\100\u2245",
	"copyrightsans", "\343\uf8e9",  // was a9
	"copyrightserif", "\323\uf6d9",
	"degree", "\260\u00b0",     // conflict
	"delta", "\144\u03b4",
	"diamond", "\250\u2666",
	"divide", "\270\u00f7",     // conflict
	"dotmath", "\327\u22c5",
	"element", "\316\u2208",
	"ellipsis", "\274\u2026",     // conflict
	"emptyset", "\306\u2205",
	"epsilon", "\143\u03b5",
	//"equal", "\075u00",
	"equivalence", "\272\u2261",
	"eta", "\150\u03b7",
	//"exclam", "\041u00",
	"existential", "\044\u2203",
	"florin", "\246\u0192",     // conflict
	"fraction", "\244\u2044",     // conflict
	"gamma", "\147\u03b3",
	"gradient", "\321\u2207",
	//"greater", "\076u00",
	"greaterequal", "\263\u2265",
	"heart", "\251\u2665",
	"infinity", "\245\u221e",
	"integral", "\362\u222b",
	"integraltp", "\363\u2320",
	"integralex", "\364\uf8f5",
	"integralbt", "\365\u2321",
	"intersection", "\307\u2229",
	"iota", "\151\u03b9",
	"kappa", "\153\u03ba",
	"lambda", "\154\u03bb",
	//"less", "\074u00",
	"lessequal", "\243\u2264",
	"logicaland", "\331\u2227",
	"logicalnot", "\330\u00ac",     // conflict
	"logicalor", "\332\u2228",
	"lozenge", "\340\u25ca",
	"minus", "\055\u2212",     // conflict
	"minute", "\242\u2032",
	"mu", "\155\u03bc",     // conflict
	"multiply", "\264\u00d7",     // conflict
	"notlement", "\317\u2209",
	"notequal", "\271\u2260",
	"notsubset", "\313\u2284",
	"nu", "\156\u03bd",
	//"numbersign", "\043u00",
	"omega", "\167\u03c9",
	"omega1", "\166\u03d6",
	"omicron", "\157\u03bf",
	//"parenleft", "\050u00",
	//"parenright", "\051u00",
	"parenlefttp", "\346\uf8eb",
	"parenleftex", "\347\uf8ec",
	"parenleftbt", "\350\uf8ed",
	"parenrighttp", "\366\uf8f6",
	"parenrightex", "\367\uf8f7",
	"parentrightbt", "\370\uf8f8",
	"partialdiff", "\266\u2202",
	//"percent", "\045u00",
	//"period", "\056u00",
	"perpendicular", "\136\u22a5",
	"phi", "\146\u03c6",
	"phi1", "\152\u03d5",
	"pi", "\160\u03c0",
	//"plus", "\053u00",
	"plusminus", "\261\u00b1",     // conflict
	"product", "\325\u220f",
	"propersubset", "\314\u2282",
	"propersuperset", "\311\u2283",
	"proportional", "\265\u221d",
	"psi", "\171\u03c8",
	//"question", "\077u00",
	"radical", "\326\u221a",
	"radicalex", "\140\uf8e5",
	"reflexsubset", "\315\u2286",
	"reflexsuperset", "\312\u2287",
	"registersans", "\342\uf8e8",   // was ae
	"registerserif", "\322\uf6da",
	"rho", "\162\u03c1",
	"second", "\262\u2033",
	//"semicolon", "\073u00",
	"sigma", "\163\u03c3",
	"sigma1", "\126\u03c2",
	"similar", "\176\u223c",
	//"slash", "\057u00",
	//"space", "\040u00a0",
	"spade", "\252\u2660",
	"suchthat", "\047\u220b",   // 220d?
	"summation", "\345\u2211",
	"tau", "\164\u03c4",
	"therefore", "\134\u2234",
	"theta", "\161\u03b8",
	"theta1", "\112\u03d1",
	"trademarksans", "\344\uf8ea",  // was 2122
	"trademarkserif", "\324\uf6db",
	//"underscore", "\137u00",
	"union", "\310\u222a",
	"universal", "\042\u2200",
	"upsilon", "\165\u03c5",
	"weierstrass", "\303\u2118",
	"xi", "\170\u03be",
	"zeta", "\172\u03b6",
  };

  // corresponding Ghostscript font doesn't have Unicode encoding (yet?)
  // http://partners.adobe.com/asn/developer/type/zapfdingbats.txt
  static final String[] refTableZapf_ = {
	"space","\040\u0020",
	"a1","\041\u2701",
	"a2","\042\u2702",
	"a202","\043\u2703",
	"a3","\044\u2704",
	"a4","\045\u260e",
	"a5","\046\u2706",
	"a119","\047\u2707",
	"a118","\050\u2708",
	"a117","\051\u2709",
	"a11","\052\u261b",
	"a12","\053\u261e",
	"a13","\054\u270c",
	"a14","\055\u270d",
	"a15","\056\u270e",
	"a16","\057\u270f",
	"a105","\060\u2710",
	"a17","\061\u2711",
	"a18","\062\u2712",
	"a19","\063\u2713",
	"a20","\064\u2714",
	"a21","\065\u2715",
	"a22","\066\u2716",
	"a23","\067\u2717",
	"a24","\070\u2718",
	"a25","\071\u2719",
	"a26","\072\u271a",
	"a27","\073\u271b",
	"a28","\074\u271c",
	"a6","\075\u271d",
	"a7","\076\u271e",
	"a8","\077\u271f",
	"a9","\100\u2720",
	"a10","\101\u2721",
	"a29","\102\u2722",
	"a30","\103\u2723",
	"a31","\104\u2724",
	"a32","\105\u2725",
	"a33","\106\u2726",
	"a34","\107\u2727",
	"a35","\110\u2605",
	"a36","\111\u2729",
	"a37","\112\u272a",
	"a38","\113\u272b",
	"a39","\114\u272c",
	"a40","\115\u272d",
	"a41","\116\u272e",
	"a42","\117\u272f",
	"a43","\120\u2730",
	"a44","\121\u2731",
	"a45","\122\u2732",
	"a46","\123\u2733",
	"a47","\124\u2734",
	"a48","\125\u2735",
	"a49","\126\u2736",
	"a50","\127\u2737",
	"a51","\130\u2738",
	"a52","\131\u2739",
	"a53","\132\u273a",
	"a54","\133\u273b",
	"a55","\134\u273c",
	"a56","\135\u273d",
	"a57","\136\u273e",
	"a58","\137\u273f",
	"a59","\140\u2740",
	"a60","\141\u2741",
	"a61","\142\u2742",
	"a62","\143\u2743",
	"a63","\144\u2744",
	"a64","\145\u2745",
	"a65","\146\u2746",
	"a66","\147\u2747",
	"a67","\150\u2748",
	"a68","\151\u2749",
	"a69","\152\u274a",
	"a70","\153\u274b",
	"a71","\154\u25cf",
	"a72","\155\u274d",
	"a73","\156\u25a0",
	"a74","\157\u274f",
	"a203","\160\u2750",
	"a75","\161\u2751",
	"a204","\162\u2752",
	"a76","\163\u25b5",
	"a77","\164\u25bc",
	"a78","\165\u25c6",
	"a79","\166\u2756",
	"a81","\167\u25d7",
	"a82","\170\u2758",
	"a83","\171\u2759",
	"a84","\172\u275a",
	"a97","\173\u275b",
	"a98","\174\u275c",
	"a99","\175\u275d",
	"a100","\176\u275e",
	// these not in PDF Reference but in ITC Zapf Dingbats encoding
	"a89","\177\uf8d7",
	"a90","\200\uf8d8",
	"a93","\201\uf8d9",
	"a94","\202\uf8da",
	"a91","\203\uf8db",
	"a92","\204\uf8dc",
	"a205","\205\uf8dd",
	"a85","\206\uf8de",
	"a206","\207\uf8df",
	"a86","\210\uf8e0",
	"a87","\211\uf8e1",
	"a88","\212\uf8e2",
	"a95","\213\uf8e3",
	"a96","\215\uf8e4",
	// end not in ref
	// GAP
	"a101","\241\u2761",
	"a102","\242\u2762",
	"a103","\243\u2763",
	"a104","\244\u2764",
	"a106","\245\u2765",
	"a107","\246\u2766",
	"a108","\247\u2767",
	"a112","\250\u2663",
	"a111","\251\u2666",
	"a110","\252\u2665",
	"a109","\253\u2660",
	"a120","\254\u2460",
	"a121","\255\u2461",
	"a122","\256\u2462",
	"a123","\257\u2463",
	"a124","\260\u2464",
	"a125","\261\u2465",
	"a126","\262\u2466",
	"a127","\263\u2467",
	"a128","\264\u2468",
	"a129","\265\u2469",
	"a130","\266\u2776",
	"a131","\267\u2777",
	"a132","\270\u2778",
	"a133","\271\u2779",
	"a134","\272\u277a",
	"a135","\273\u277b",
	"a136","\274\u277c",
	"a137","\275\u277d",
	"a138","\276\u277e",
	"a139","\277\u277f",
	"a140","\300\u2780",
	"a141","\301\u2781",
	"a142","\302\u2782",
	"a143","\303\u2783",
	"a144","\304\u2784",
	"a145","\305\u2785",
	"a146","\306\u2786",
	"a147","\307\u2787",
	"a148","\310\u2788",
	"a149","\311\u2789",
	"a150","\312\u278a",
	"a151","\313\u278b",
	"a152","\314\u278c",
	"a153","\315\u278d",
	"a154","\316\u278e",
	"a155","\317\u278f",
	"a156","\320\u2790",
	"a157","\321\u2791",
	"a158","\322\u2792",
	"a159","\323\u2793",
	"a160","\324\u2794",
	"a161","\325\u2192",
	"a163","\326\u2194",
	"a164","\327\u2195",
	"a196","\330\u2798",
	"a165","\331\u2799",
	"a192","\332\u279a",
	"a166","\333\u279b",
	"a167","\334\u279c",
	"a168","\335\u279d",
	"a169","\336\u279e",
	"a170","\337\u279f",
	"a171","\340\u27a0",
	"a172","\341\u27a1",
	"a173","\342\u27a2",
	"a162","\343\u27a3",
	"a174","\344\u27a4",
	"a175","\345\u27a5",
	"a176","\346\u27a6",
	"a177","\347\u27a7",
	"a178","\350\u27a8",
	"a179","\351\u27a9",
	"a193","\352\u27aa",
	"a180","\353\u27ab",
	"a199","\354\u27ac",
	"a181","\355\u27ad",
	"a200","\356\u27ae",
	"a182","\357\u27af",
	// no \360
	"a201","\361\u27b1",
	"a183","\362\u27b2",
	"a184","\363\u27b3",
	"a197","\364\u27b4",
	"a185","\365\u27b5",
	"a194","\366\u27b6",
	"a198","\367\u27b7",
	"a186","\370\u27b8",
	"a195","\371\u27b9",
	"a187","\372\u27ba",
	"a188","\373\u27bb",
	"a189","\374\u27bc",
	"a190","\375\u27bd",
	"a191","\376\u27be"
  };

  // Mac Expert
  // http://partners.adobe.com/asn/developer/type/corporateuse.txt
  static final String[] refTableMacExpert_ = {
	// smallcaps, sup/sub, oldstyle
	"AEsmall", "\276\uf7e6",
	"Aacutesmall", "\207\uf7b4",
	"Acircumflexsmall", "\211\uf7e2",
	"Acutesmall", "\047\uf7e1",
	"Adieresissmall", "\212\uf7e4",
	"Agravesmall", "\210\uf7e0",
	"Aringsmall", "\214\uf7e5",
	"Asmall", "\141\uf761",
	"Atildesmall", "\213\uf7e3",
	"Brevesmall", "\363\uf6f4",
	"Bsmall", "\142\uf762",
	"Caronsmall", "\256\uf7f5",
	"Ccedillasmall", "\215\uf7e7",
	"Cedillasmall", "\311\uf7b8",
	"Circumflexsmall", "\136\uf6f6",
	"Csmall", "\143\uf763",
	"Dieresissmall", "\254\uf7a8",
	"Dotaccentsmall", "\372\uf6f7",
	"Dsmall", "\144\uf764",
	"Eacutesmall", "\216\uf7e9",
	"Ecircumflexsmall", "\220\uf7ea",
	"Edieresissmall", "\221\uf7eb",
	"Egravesmall", "\217\uf7e8",
	"Esmall", "\145\uf765",
	"Ethsmall", "\104\uf7f0",
	"Fsmall", "\146\uf766",
	"Gravesmall", "\140\uf760",
	"Gsmall", "\147\uf767",
	"Hsmall", "\150\uf768",
	"Hungarumlautsmall", "\042\uf6f8",
	"Iacutesmall", "\222\uf7ed",
	"Icircumflexsmall", "\224\uf7ee",
	"Idieresissmall", "\225\uf7ef",
	"Igravesmall", "\223\uf7ec",
	"Ismall", "\151\uf769",
	"Jsmall", "\152\uf76a",
	"Ksmall", "\153\uf76b",
	"Lslashsmall", "\302\uf6f9",
	"Lsmall", "\154\uf76c",
	"Macronsmall", "\364\uf7af",
	"Msmall", "\155\uf76d",
	"Nsmall", "\156\uf76e",
	"Ntildesmall", "\226\uf7f1",
	"OEsmall", "\317\uf6fa",
	"Oacutesmall", "\227\uf7f3",
	"Ocircumflexsmall", "\231\uf7f4",
	"Odieresissmall", "\232\uf7f6",
	"Ogoneksmall", "\362\uf6fb",
	"Ogravesmall", "\230\uf7f2",
	"Oslashsmall", "\277\uf7f8",
	"Osmall", "\157\uf76f",
	"Otildesmall", "\233\uf7f5",
	"Psmall", "\160\uf770",
	"Qsmall", "\161\uf771",
	"Ringsmall", "\373\uf6fd",
	"Rsmall", "\162\uf772",
	"Scaronsmall", "\247\uf6fd",
	"Ssmall", "\163\uf773",
	"Thornsmall", "\271\uf7fe",
	"Tildesmall", "\176\uf6fe",
	"Tsmall", "\164\uf774",
	"Uacutesmall", "\234\uf7fa",
	"Ucircumflexsmall", "\236\uf7fb",
	"Udieresissmall", "\237\uf7fc",
	"Ugravesmall", "\235\uf7f9",
	"Usmall", "\165\uf775",
	"Vsmall", "\166\uf776",
	"Wsmall", "\167\uf777",
	"Xsmall", "\170\uf778",
	"Yacutesmall", "\264\uf7fd",
	"Ydieresissmall", "\330\uf7ff",
	"Ysmall", "\171\uf779",
	"Zcaronsmall", "\275\uf6ff",
	"Zsmall", "\172\uf77a",
	"ampersandsmall", "\046\uf726",

	"asuperior", "\201\uf6e9",
	"bsuperior", "\365\uf6ea",
	"centinferior", "\251\uf6df",
	"centoldstyle", "\043\uf7a2",
	"centsuperior", "\202\uf6e0",
	"colon", "\072:",
	"colonmonetary", "\173\u20a1",
	"comma", "\054,",
	"commainferior", "\262\uf6e1",
	"commasuperior", "\370\uf6e2",
	"dollarinferior", "\266\uf6e3",
	"dollaroldstyle", "\044\uf724",
	"dollarsuperior", "\045\uf6e4",
	"dsuperior", "\353\uf6eb",
	"eightinferior", "\245\u2088",
	"eightoldstyle", "\070\uf738",
	"eightsuperior", "\241\u2078",
	"esuperior", "\344\uf6ec",
	"exclamdownsmall", "\326\uf7a1",
	"exclamsmall", "\041\uf721",
	"ff", "\126\ufb00",
	"ffi", "\131\ufb03",
	"ffl", "\132\ufb04",
	"fi", "\127\ufb01",
	"figuredash", "\320\u2012",
	"fiveeighths", "\114\u215d",
	"fiveinferior", "\260\u2085",
	"fiveoldstyle", "\065\uf735",
	"fivesuperior", "\336\u2075",
	"fl", "\130\ufb02",
	"fourinferior", "\242\u2084",
	"fouroldstyle", "\064\uf734",
	"foursuperior", "\335\u2074",
	"fraction", "\057\u2044",
	"hyphen", "\055-",
	"hypheninferior", "\137\uf6e5",
	"hyphensuperior", "\321\uf6e6",
	"isuperior", "\351\uf6ed",
	"lsuperior", "\361\uf6ee",
	"msuperior", "\367\uf6ef",
	"nineinferior", "\273\u2089",
	"nineoldstyle", "\071\uf739",
	"ninesuperior", "\341\u2079",
	"nsuperior", "\366\u207f",
	"onedotenleader", "\053\u2024",
	"oneeighth", "\112\u215b",
	"onefitted", "\174\uf6dc",
	"onehalf", "\110\u00bd",
	"oneinferior", "\301\u2081",
	"oneoldstyle", "\061\uf731",
	"onequarter", "\107\u00bc",
	"onesuperior", "\332\u00b9",
	"onethird", "\116\u2153",
	"osuperior", "\257\uf6f0",
	"parenleftinferior", "\133\u208d",
	"parenleftsuperior", "\050\u207d",
	"parenrightinferior", "\135\u208e",
	"parenrightsuperior", "\051\u207e",
	"period", "\056.",
	"periodinferior", "\263\uf6e7",
	"periodsuperior", "\371\uf6e8",
	"questiondownsmall", "\300\uf7bf",
	"questionsmall", "\077\uf73f",
	"rsuperior", "\345\uf6f0",
	"rupiah", "\175\uf6dd",
	"semicolon", "\073;",
	"seveneighths", "\115\u215e",
	"seveninferior", "\246\u2087",
	"sevenoldstyle", "\067\uf7e7",
	"sevensuperior", "\340\u2077",
	"sixinferior", "\244\u2086",
	"sixoldstyle", "\066\uf736",
	"sixsuperior", "\337\u2076",
	"space", "\040 ",
	"ssuperior", "\352\uf6f2",
	"threeeighths", "\113\u215c",
	"threeinferior", "\243\u2083",
	"threeoldstyle", "\063\uf733",
	"threequarters", "\111\u00be",
	"threequartersemdash", "\075\uf6de",
	"threesuperior", "\334\u00b3",
	"tsuperior", "\346\uf6f3",
	"twodotenleader", "\052\u2025",
	"twoinferior", "\252\u2082",
	"twooldstyle", "\062\uf732",
	"twosuperior", "\333\u00b2",
	"twothirds", "\117\u2154",
	"zeroinferior", "\274\u2080",
	"zerooldstyle", "\060\uf730",
	"zerosuperior", "\342\u2070"
  };

  // Type 1/TrueType conversions of TeX fonts generally don't have Unicode mappings, so impute
  // include Unicode translation for future improvement
  static final String[] refTableTeX_ = {
	// cmr (+ cmti + cmtt)
	"Gamma", "\000\u0393",
	"Delta", "\001\u0394",
	"Theta", "\002\u0398",
	"Lambda", "\003\u039b",
	"Xi", "\004\u039e",
	"Pi", "\005\u03a0",
	"Sigma", "\006\u03a3",
	"Upsilon", "\007\u03a5",
	"Phi", "\010\u03a6",
	"Psi", "\011\u03a8",
	"Omega", "\012\u03a9",

	"ff", "\013\ufb00",
	"fi", "\014\ufb01",
	"fl", "\015\ufb02",
	"ffi", "\016\ufb03",
	"ffl", "\017\ufb04",

	"dotlessi", "\020\u0131",
	"dotlessj", "\021\uf6be",
	"grave", "\022\u0060",
	"acute", "\023\u00b4",
	"caron", "\024\u02c7",
	"breve", "\025\u0306",
	"overscore", "\026\026",
	"ring", "\027\u02da",
	"cedilla", "\030\u00b8",
	"germandbls", "\031\u00df",
	"ae", "\032\u00e6",
	"oe", "\033\u0153",
	"oslash", "\034\u00f8",
	"AE", "\035\u00c6",
	"OE", "\036\u0152",
	"Oslash", "\037\u00d8",
	"polishlcross", "\040\040",   // takes place of space

	"quotedblright", "\042\u201d",
	"quoteright", "\047\u2019",
	"exclamdown", "\074\u00a1",
	"questiondown", "\076\u00bf",
	"quotedblleft", "\134\u201d",
	"dotaccent", "\137\u02d9",
	"quoteleft", "\140\u2018",
	"endash", "\173\u2013",
	"emdash", "\174\u2014",
	"hungarumlaut", "\175\u00a8",
	"dieresis", "\177\u00a8",


	// cmmi
	"alpha", "\013\u03b1",
	"beta", "\014\u03b2",
	"gamma", "\015\u03b3",
	"delta", "\016\u03b4",
	"epsilon1", "\017\u02b5",
	"zeta", "\020\u03b6",
	"eta", "\021\u03b7",
	"theta", "\022\u03b8",
	"iota", "\023\u03b9",
	"kappa", "\024\u03ba",
	"lambda", "\025\u03bb",
	"mu", "\026\u03bc",
	"nu", "\027\u03bd",
	"xi", "\030\u03be",
	"pi", "\031\u03c0",
	"rho", "\032\u03c1",
	"sigma", "\033\u03c3",
	"tau", "\034\u03c4",
	"upsilon", "\035\u03c5",
	"phi", "\036\u03c6",
	"chi", "\037\u03c7",
	"psi", "\040\u03c8",
	"omega", "\041\u03c9",
	"epsilon", "\042\u03b5",
	"theta1", "\043\u03d1",
	"pi1", "\044\u03d6",
	"rho1", "\045\u03f1",
	"sigma1", "\046\u03c2",
	"phi1", "\047\u03d5",

	"arrowlefttophalf", "\050\u21bc",
	"arrowleftbothalf", "\051\u21bd",
	"arrowrighttophalf", "\052\u21c0",
	"arrowrightbothalf", "\053\u21c1",
	"arrowhookleft", "\054\u21a9",
	"arrowhookright", "\055\u21aa",
	"triangleright", "\056\u22b2",
	"triangleleft", "\057\u22b3",

	"zerooldstyle", "\060\uf730",
	"oneoldstyle", "\061\uf731",
	"twooldstyle", "\062\uf732",
	"threeoldstyle", "\063\uf733",
	"fouroldstyle", "\064\uf734",
	"fiveoldstyle", "\065\uf735",
	"sixoldstyle", "\066\uf736",
	"sevenoldstyle", "\067\uf737",
	"eightoldstyle", "\070\uf738",
	"nineoldstyle", "\071\uf739",
	// conflicts with cmr: period, comma

	"star", "\077\u22c6",

	"partialdiff", "\100\u2202",
	"flat", "\133\u266d",
	"natural", "\134\u266e",
	"sharp", "\135\u266f",
	"slurbelow", "\136\u2323",
	"slurabove", "\137\u2322",

	"lscript", "\140\u2113",
	// conflicts with cmr: dotlessi, dotlessj
	"weierstrass", "\175\u2118",
	"vector", "\176\176",
	"tie", "\177\177",


	// cmsy
	"minus", "\000\u2212",
	"middot", "\001\u2219",
	"multiply", "\002\u00d7",
	"asteriskmath", "\003\u2217",
	"divide", "\004\u00f7",
	"diamondmath", "\005\u22c4",
	"plusminus", "\006\u00b1",
	"minusplus", "\007\u2213",

	"circleplus", "\010\u2295",
	"circleminus", "\011\u2296",
	"circlemultiply", "\012\u2297",
	"circledivide", "\013\u2298",
	"circledot", "\014\u2299",
	"circlecopyrt", "\015\015",     // no Unicode
	"openbullet", "\016\u25e6",
	"bullet", "\017\u2022",

	"equivasymptotic", "\020\u224d",
	"equivalence", "\021\u2261",
	"reflexsubset", "\022\u2286",
	"reflexsuperset", "\023\u2287",
	"lessequal", "\024\u2264",
	"greaterequal", "\025\u2265",
	"precedesequal", "\026\026",
	"followsequal", "\027\027",

	"similar", "\030\u223c",
	"approxequal", "\031\u2248",
	"propersubset", "\032\u2282",
	"propersuperset", "\033\u2283",
	"lessmuch", "\034\u226a",
	"greatermuch", "\035\u226b",
	"precedes", "\036\u227a",
	"follows", "\037\u227b",

	"arrowleft", "\040\u2190",
	"arrowright", "\041\u2192",
	"arrowup", "\042\u2191",
	"arrowdown", "\043\u2193",
	"arrowboth", "\044\u2914",
	"arrownortheast", "\045\u2197",
	"arrowsoutheast", "\046\u2198",
	"similarequal", "\047\047",

	"arrowdblleft", "\050\u21d0",
	"arrowdblright", "\051\u21d2",
	"arrowdblup", "\052\u21d1",
	"arrowdbldown", "\053\u21d3",
	"arrowdblboth", "\054\u21d4",
	"arrownorthwest", "\055\u2196",
	"arrowsouthwest", "\056\u2199",
	"proportional", "\057\u221d",

	"prime", "\060\060",
	"infinity", "\061\u221e",
	"element", "\062\u2208",
	"owner", "\063\u220b",
	"triangle", "\064\u25b3",
	"triangleinv", "\065\u25bd",
	"negationslash", "\066\066",
	"mapsto", "\067\067",

	"universal", "\070\u2200",
	"existential", "\071\u2203",
	"logicalnot", "\072\u00ac",
	"emptyset", "\073\u2205",
	"Rfractur", "\074\u211c",
	"Ifractur", "\075\075",
	"latticetop", "\076\u22a4",
	"perpendicular", "\077\u22a5",

	"aleph", "\100\u2135",

	"union", "\133\u222a",
	"intersection", "\134\u2229",
	"unionmulti", "\135\u228e",
	"logicaland", "\136\u2227",
	"logicalor", "\137\u2228",

	"turnstileleft", "\140\u22a2",
	"turnstileright", "\141\u22a3",
	"floorleft", "\142\u230a",
	"floorright", "\143\u230b",
	"ceilingleft", "\144\u2308",
	"ceilingright", "\145\u2309",
	"braceleft", "\146\u007b",
	"braceright", "\147\u007d",

	"angbracketleft", "\150\150",
	"angbracketright", "\151\151",
	"bar", "\152\u007c",
	"bardbl", "\153\153",
	"arrowbothv", "\154\154",
	"arrowdblbothv", "\155\155",
	"backslash", "\156\134",    // JBuilder 6 bitches about "\u005c", but 005a/5b/5d/5e/5f all ok
	"wreathproduct", "\157\u2240",

	"radical", "\160\u221a",
	"coproduct", "\161\u2210",
	"nabla", "\162\u2207",
	"integral", "\163\u222b",
	"unionsq", "\164\u2294",
	"intersectionsq", "\165\u2293",
	"subsetsqequal", "\166\u2291",
	"supersetsqequal", "\167\u2292",

	"section", "\170\u00a7",
	"dagger", "\171\u2020",
	"daggerdbl", "\172\u2021",
	"paragraph", "\173\u00b6",
	"club", "\174\u2663",
	"diamond", "\175\u2666",
	"heart", "\176\u2665",
	"spade", "\177\u2660",

	// conflict with cmsy: "arrowup", "\013\u2191",
	// conflict with cmsy: "arrowdown", "\014\u2193",
	// conflict with exclamdown, questiondown

	// cmex -- no Unicode for these
  };


  /**
	For differences encoding, hash on name to get character encodings.
	Restore separate map for Symbol when Java give access to a font's built-in encoding.
  */
  //public // maps available momentarily while generating Core14AFM
  static final Map<String,String> uname2char_ = new HashMap<String,String>(refTable_.length/* /2 for name/chars, *2 for hash*/),
	//unamesym2char = new HashMap(refTableSym_.length),
	unameEx2char_ = new HashMap<String,String>(refTableMacExpert_.length),
	unameTeX2char_ = new HashMap<String,String>(refTableTeX_.length)
	;

  static {
	assert refTable_.length % 2 == 0;
//System.out.println("refTable size = "+refTable_.length+" %6="+(refTable_.length % 6));

	// Identity
	for (int i=0,imax=IDENTITY_MAP.length; i<imax; i++) IDENTITY_MAP[i] = (char)i;


	// Unicode mapping of common characters -- mapped fine in core sets, just need names
	//for (int i=0; i<256; i++) uname2char_.put(Strings.valueOf(i), new Character((char)i));
	//for (int i='A',imax='Z'+1; i<imax; i++) uname2char_.put(Strings.valueOf(i), new Character((char)i));
	//for (int i='a',imax='z'+1; i<imax; i++) uname2char_.put(Strings.valueOf(i), new Character((char)i));
	for (int i=0; i<256; i++)  uname2char_.put(Strings.valueOf((char)i), "     ");
	for (int i=33; i<127; i++) {
		uname2char_.put(Strings.valueOf((char)i), ""+(char)i+(char)i+(char)i+(char)i+(char)i);
		unameTeX2char_.put(Strings.valueOf((char)i), ""+(char)i+(char)i);
	}
	String[] charname = {
		"zero","0", "one","1", "two","2", "three","3", "four","4", "five","5", "six","6", "seven","7", "eight","8", "nine","9",
		"ampersand","&", "at","@", "backslash","\\", "bar","|", "braceleft","{", "braceright","}", "bracketleft","[", "bracketright","]",
		"colon",":", "comma",",", "dollar","$", "equal","=", "exclam","!",
		"greater",">", "hyphen","-", "less","<", "numbersign","#",
		"parenleft","(", "parenright",")", "percent","%", "period",".", "plus","+", "question","?",
		"semicolon",";", "slash","/", "space"," ",
		// additions used in practice -- some of these defined in Mac Expert
		"ff","\ufb00", "ffi","\ufb03", "ffl","\ufb04", "dotlessj","\uf6be",
	};
	for (int i=0, imax=charname.length; i<imax; i+=2) {
		String uch = charname[i+1], sch=(uch.charAt(0)<256? uch: "\000"/*" "*/);
		uname2char_.put(charname[i], sch+sch+sch+sch + uch);
		//unamesym2char.put(charname[i], sch + uch);
		unameTeX2char_.put(charname[i], sch/*+uch*/);
	}

	// construct standard mappings
	// assume characters encoded the same everywhere, fix from table of exceptions
	// probably faster to make one and clone, but no big deal
	for (int i=0; i<256; i++) macRomanMap_[i] = macExpertMap_[i] = winAnsiMap_[i] = standardMap_[i] = pdfMap_[i] = symbolMap_[i] = zapfMap_[i] = texMap_[i] = ' ';
	//macRomanMap_[0] = macExpertMap_[0] = winAnsiMap_[0] = standardMap_[0] = pdfMap_[0] = symbolMap_[0] = zapfMap_[0] = (char)-1;  // possible erroneous Unicode
	for (int i=33; i<127; i++) macRomanMap_[i] /*= macExpertMap_[i]*/ = winAnsiMap_[i] = standardMap_[i] = pdfMap_[i] = symbolMap_[i] /*= zapfMap_[i]*/ = texMap_[i] = (char)i;
	//for (int i=0xa0; i<0x100; i++) macRomanMap_[i] = macExpertMap_[i] = winAnsiMap_[i] = standardMap_[i] = pdfMap_[i] = symbolMap_[i] = (char)i;

	macRoman2std_=(char[])IDENTITY_MAP.clone(); winAnsi2std_=(char[])IDENTITY_MAP.clone(); pdf2std_=(char[])IDENTITY_MAP.clone();

	// tables of exceptions (special case where names are already mapped)
	for (int i=0, imax=refTable_.length; i<imax; i+=2) {
//System.out.println(refTable_[i]);
		String codes = refTable_[i+1];  assert codes.length() == 5;
		char ucode = codes.charAt(4);   assert ucode != 0;
		assert uname2char_.get(refTable_[i]) == null;
		uname2char_.put(refTable_[i], codes);

		char ch, stdch=codes.charAt(0), mapch=(stdch!=0? stdch: ' ');   // for mapch, if no widths and not in std, screwed.  map to ' ' rather than whatever character happens to be at that location
		if (stdch!=0) standardMap_[stdch] = ucode;
		if ((ch=codes.charAt(1))!=0) { macRomanMap_[ch] = ucode; macRoman2std_[ch] = mapch; }
		if ((ch=codes.charAt(2))!=0) { winAnsiMap_[ch] = ucode; winAnsi2std_[ch] = mapch; }
		if ((ch=codes.charAt(3))!=0) { pdfMap_[ch] = ucode; pdf2std_[ch] = mapch; }
	}

	// footnote 3: "In WinAnsiEncoding, all unused codes greater than 40 map to the bullet character.  However, only code 225 is specifically assigned to the bullet character; other codes are ubject to future reassignment."
	//for (int i=041; i<256; i++) if (winAnsiMap_[i]=='\0') winAnsiMap_[i]='\u2022';
	winAnsiMap_[127] = '\u2022';    // don't know what unused entires are
//for (int j=0xa0; j<0x100; j++) System.out.print(j+"="+(int)winAnsiMap_[j]+" ");    System.out.println();


	// Symbol
	for (int i=0, imax=refTableSym_.length; i<imax; i+=2) {
//System.out.println(refTableSym_[i]+", "+refTableSym_[i+1].length());
		String codes = refTableSym_[i+1];   assert codes.length() == 2;
		//unamesym2char.put(refTableSym_[i], codes);
//if (uname2char_.get(refTableSym_[i])!=null) System.out.println("sym dup: "+refTableSym_[i]+": "+refTableSym_[i+1]+" vs "+uname2char_.get(refTableSym_[i]));
		String name = refTableSym_[i];
		String latin = (String)uname2char_.get(name);
		if (latin==null) uname2char_.put(name, codes);  // polluted namespace, but it's necessary as we can't get at built-in encoding of fonts
		else if (latin.charAt(0) != codes.charAt(0)) {  // if not defined in standard, set to symbol
			assert latin.charAt(0) == 0;
			uname2char_.put(name, codes.charAt(0) + latin.substring(1));
		}
		symbolMap_[codes.charAt(0)] = codes.charAt(1);
	}

	// ZapfDingbats
	for (int i=0, imax=refTableZapf_.length; i<imax; i+=2) {
		String codes = refTableZapf_[i+1];  assert codes.length() == 2;
		String name = refTableZapf_[i];
		String latin = (String)uname2char_.get(name);
		if (latin==null) uname2char_.put(name, codes);
		zapfMap_[codes.charAt(0)] = codes.charAt(1);
		//System.out.print(refTableZapf_[i]+" => "+(int)refTableZapf_[i+1].charAt(0)+"   ");
	}

	// MacExpert
	for (int i=0, imax=refTableMacExpert_.length; i<imax; i+=2) {
		String codes = refTableMacExpert_[i+1];  assert codes.length() == 2: "@"+i+": "+refTableMacExpert_[i];
//if (uname2char_.get(refTableMacExpert_[i])!=null) System.out.println("ex dup: "+refTableMacExpert_[i]+": "+refTableMacExpert_[i+1]+" vs "+uname2char_.get(refTableMacExpert_[i]));
		unameEx2char_.put(refTableMacExpert_[i], codes);
		macExpertMap_[codes.charAt(0)] = codes.charAt(1);
		//System.out.print(refTableMacExpert_[i]+" => "+(int)refTableMacExpert_[i+1].charAt(0)+"   ");
	}

	// TeX
	for (int i=0, imax=refTableTeX_.length; i<imax; i+=2) {
		String codes = refTableTeX_[i+1];  assert codes.length() == 2: "@"+i+": "+refTableTeX_[i];
//if (uname2char_.get(refTableMacExpert_[i])!=null) System.out.println("ex dup: "+refTableMacExpert_[i]+": "+refTableMacExpert_[i+1]+" vs "+uname2char_.get(refTableMacExpert_[i]));
		unameTeX2char_.put(refTableTeX_[i], codes.substring(0,1));
		texMap_[codes.charAt(0)] = codes.charAt(0/*1*/);
	}


	// special case encodings
	//char[] tex161=(char[])IDENTITY_MAP.clone(); for (int i=0; i<32; i++) tex161[i]=(char)(i+161); TEX161_ENCODING = new Encoding(tex161/*, IDENTITY_MAP*/);
	//char[] tex163=(char[])IDENTITY_MAP.clone(); for (int i=0; i<32; i++) tex163[i]=(char)(i+163); TEX163_ENCODING = new Encoding(tex163/*, IDENTITY_MAP*/);

	IDENTITY_ENCODING = new Encoding(IDENTITY_MAP/*, IDENTITY_MAP*/);
  }



  /** Characters are mapped to Unicode equivalents. */
  char[] toUni_;
  /** But things such as the widths table need the specified encoding. */
  char[] toBase_;
  /** Only ever care about mapping back to Adobe Standard, from differences and MacRoman or WinAnsi, so can index into core 14 widths. */
  char[] toStd_;
  //String[] names_;

  /**
	Handles built-in encodings (defaults to StandardEncoding), tweaks according to differences if any.
	@param font - actual font constructed from same font dictionary.
	  As of this writing, the core 14 fonts aren't bundled in the JAR, so embedded metadata can differ from actual font.
	  The encoding vector for TrueType TeX fonts has to be determined from examination of the actual font.
  */
  public static Encoding getInstance(Dict fontdict, PDFReader pdfr) throws IOException {
	String subtype = (String)pdfr.getObject(fontdict.get("Subtype"));
	if ("Type3".equals(subtype) /*|| "Type0".equals(subtype)*/) return IDENTITY_ENCODING;

	String family = (String)pdfr.getObject(fontdict.get("BaseFont"));
	Dict fdesc = (Dict)pdfr.getObject(fontdict.get("FontDescriptor"));
	Object enobj = pdfr.getObject(fontdict.get("Encoding"));   // name or dictionary
	//Object unicode = getObject(fontdict.get("ToUnicode"));  // always translate to Unicode if font has Unicode mapping -- LATER
//if (unicode!=null) System.out.println("unicode: "+unicode);
//System.out.println(getObject(fontdict.get("BaseFont"))+"/"+newfont.getClass().getName());

	// stupid Doze offset needed for Windoze Symbol, embedded fonts, ...
	// xpdf has in TrueType handling code: "if (platform == 3 && encoding == 0) ... charMapOffset = 0xf000;", that is, TrueType + Microsoft + Symbol
	boolean fdoze = false;
	// need but don't have check for platform==3 (Microsoft), but instead:
	// Windoze Symbol core 14 -- when Java can load Type 1 from a JAR, package Ghostscript's Symbol font and eliminate moronic Microsoft
	if ("Symbol".equals(family) && File.separatorChar=='\\' /*&& always TrueType*/ && phelps.awt.Fonts.getAvailableFamilies().indexOf("Standard Symbols L")>=0) fdoze=false;    // will be replaced by Ghostscript in PDF.getFont()
	else if ("TrueType".equals(subtype)
		&& (enobj==null || "WinAnsiEncoding".equals(enobj))
		&& fdesc!=null) {     // often embedded
		int flags = pdfr.getObjInt(fdesc.get("Flags"));
		fdoze = (flags&Fonts.FLAG_SYMBOLIC) !=0;
//System.out.println(family+" symbolic? "+flags+" => "+((flags&SYMBOLIC_FFLAG)!=0));
	}
//if (fdoze) System.out.println("+0xf000 on "+family);
//System.out.println(fontdict.get("Subtype")+", "+family+", "+File.separatorChar+", "+enobj+" => "+fdoze);//+", "+fdesc.get("Flags"));
//System.out.println("*** "+family+", dozeset_ = "+dozeset_);


	Encoding en;
	if (enobj==null) { // "built-in encoding" of font (not necessarily built-in font), assume "AdobeStandardEncoding" or "FontSpecific"
//System.out.println("symbol, encoding="+(encoding_==Encodings.symbol2Unicode));
		//assert !fdoze;
		en = new Encoding(null, family, null, fdoze);
		// could cache, but cheap to make

	} else if (enobj.getClass()==COS.CLASS_NAME) {
		if ("Identity-H".equals(enobj) || "Identity-V".equals(enobj)) en = IDENTITY_H_ENCODING;
		else if ("Type0".equals(subtype)) en = IDENTITY_ENCODING;

		else en = new Encoding((String)enobj, family, null/*no differences*/, fdoze);
		// could cache, but cheap to make, unless fdoze which copies array

	} else { assert enobj.getClass()==COS.CLASS_DICTIONARY;   // differences
		Dict emap = (Dict)enobj;
		en = new Encoding((String)pdfr.getObject(emap.get("BaseEncoding")), family, (Object[])pdfr.getObject(emap.get("Differences")), fdoze);
		if (fdesc!=null && (fdesc.get("FontFile")!=null || fdesc.get("FontFile2")!=null || fdesc.get("FontFile3")!=null)) en.toBase_ = IDENTITY_MAP;     // weird special case for embedded
	}
	return en;
  }


  Encoding(char[] toUni/*, char[] toBase*/) {
	toUni_ = toUni;
	toBase_ = toStd_ = IDENTITY_MAP;
  }

  Encoding(String encoding, String family, Object[] diff, boolean fdoze) {
	if (encoding==null && family!=null) encoding = ("Symbol".equals(family)? "SymbolEncoding": "ZapfDingbats".equals(family)? "ZapfDingbatsEncoding": "StandardEncoding");

	toStd_ = IDENTITY_MAP;
	char[] map;
	int eoff;//, uoff=4;
	Map n2c = uname2char_;
	if ("MacRomanEncoding".equals(encoding)) { map=macRomanMap_; eoff=1; toStd_=macRoman2std_; }
	else if ("MacExpertEncoding".equals(encoding)) { map=macExpertMap_; eoff=0; /*uoff=1;*/ n2c=unameEx2char_; }
	else if ("WinAnsiEncoding".equals(encoding)) { map=winAnsiMap_; eoff=2; toStd_=winAnsi2std_; }
	else if ("PDFDocEncoding".equals(encoding)) { map=pdfMap_; eoff=3; toStd_=pdf2std_; }
	else if ("SymbolEncoding".equals(encoding)) { map=symbolMap_; eoff=0; /*uoff=1;*/ /*n2c=unamesym2char;*/ }  // symbol merged in
	else if ("ZapfDingbatsEncoding".equals(encoding)) { map=zapfMap_; eoff=0; /*uoff=1;*/ }
	else if ("TeX".equals(encoding)) { map=texMap_; eoff=0/*1 when Unicode points*/; n2c=unameTeX2char_; }
	else { assert "StandardEncoding".equals(encoding);  map=standardMap_; eoff=0; }
//System.out.println("in Encoding "+encoding);


	if (diff!=null || fdoze) map = (char[])map.clone();

	char[] base = IDENTITY_MAP;
	//String[] names = new String[base.length];
	if (diff!=null) {
		base = (char[])base.clone();
		boolean cant = false;

/* not helpful
		// hack since can't load embedded Type 1 => LATER: use toUnicode table
		// some embedded Type 1s have non-standard glyphs with unfamiliar character names.  sometimes just a letter and a number, like "G47", so try to parse these
		boolean parsable = true;

		String prefix = null;   // extract common prefix
		for (int i=0,imax=diff.length; i<imax; i++) {
			Object o = diff[i];	if (o.getClass()!=COS.CLASS_NAME) continue;
			String cname = (String)o;
			if (prefix==null) prefix = cname;   // first CLASS_NAME, which I guess is always the second entry in array
			else for (int j=0,jmax=prefix.length(); j<jmax; j++) if (prefix.charAt(j) != cname.charAt(j)) { prefix = prefix.substring(0,j); break; }
		}

		boolean ashex = false;  // determine if numbering hex or decimal
		for (int i=0,imax=diff.length; i<imax && parsable; i++) {
			Object o = diff[i];	if (o.getClass()!=COS.CLASS_NAME) continue;
			String cname = (String)o;
			for (int j=prefix.length(), jmax=cname.length(); j<jmax; j++) {
				char ch = cname.charAt(j);
				if ((ch>='a' && ch<='f') || (ch>='A' && ch<='F')) ashex = true;
				else if (ch<'0' || ch>'9') parsable=false;
			}
		}
//System.out.println("parsable="+parsable+", prefix="+prefix+", ashex="+ashex);
*/

		for (int i=0,imax=diff.length, j=0; i<imax; i++) {
			Object o = diff[i];
			if (o instanceof Number) {
				j = ((Number)o).intValue();
				//System.out.print("\n"+j);
			} else { assert COS.CLASS_NAME==o.getClass();
				if (".notdef".equals(o)) map[j] = ' ';
				//else if (n2c==null) map[j] = (char)j;	//base remains IDENTITY
				else {
					//names[j] = (String)o;

					String uchars = (String)n2c.get(o);
					if (uchars!=null) {
//if (uoff>=uchars.length()) System.out.println(uoff+" too big for "+family+"/"+encoding+": "+o+" = |"+uchars+"|");
						map[j] = uchars.charAt(uchars.length()-1);  // can have 5-length Latin or 2-length symbol, but Unicode char is always last
						char basech = uchars.charAt(eoff);
						base[j] = (basech!=INVALID_CHAR? basech: (char)j);
//if ("cmr10".equals(family) && "ff".equals(o)) System.out.println("#"+j+" "+o+" => u"+Integer.toHexString((int)map[j])+"/"+(int)base[j]+", tostd==IDENT? "+(toStd_==IDENTITY_MAP));
					} else {
						/*if (parsable) map[j] = base[j] = (char)Integer.parseInt(((String)o).substring(prefix.length()), ashex? 0x10: 10);
						else*/ map[j] = base[j] = (char)j;
						if (PDF.DEBUG) {
							if (!cant) { System.out.print(family+" can't map: "); cant=true; }  // this happens in practice and not an error
							System.out.print(" "+o+"("+map[j]+")");
						}
					}
//if ("fi".equals(uchar)) System.out.print(o+"=>"+Integer.toHexString((int)map[j])+", ");
//System.out.print("["+j+"]="+(int)map[j]+"   ");
				}
				j++;
			}
		}
		if (PDF.DEBUG && cant) System.out.println();
	}

	// Windoze symbol disregards Unicode for WinAnsi + 0xf000
	if (fdoze) for (int i=0,imax=map.length; i<imax; i++) map[i] = (char)(base[i] + MS_IDIOCY);

	toUni_=map; toBase_=base; //names_=names;
  }



  /**
	Return Unicode translation of passed <code>StringBuffer</code>.
	@param basetoo  Mutate passed </code>StringBuffer</code> according to differences table, if any, to match Adobe standard encoding.
  */
  public String translate(StringBuffer sb, boolean basetoo) {
	assert sb!=null;

//System.out.print("translate |"+sb+"|, ");
	int len = sb.length();
	StringBuffer sbout = new StringBuffer(len);
//System.out.println(encoding.hashCode()+" vs "+standardEncoding.hashCode()+", "+winAnsiEncoding.hashCode()+", "+symbolEncoding.hashCode());
//System.out.println("encoding = "+(encoding==standardEncoding? "standard": encoding==winAnsiEncoding? "winAnsi": encoding==symbolEncoding? "symbol": encoding.toString()));
	if (!basetoo || (toBase_ == IDENTITY_MAP && toStd_==IDENTITY_MAP)) {     // true unless /Differences or +0xf000
		/*if (toUni_!=IDENTITY_MAP)*/ for (int i=0,imax=len; i<imax; i++) sbout.append(toUni_[sb.charAt(i)]);
	} else {
//System.out.println(201+" toBase="+toBase_[201]+", toStd="+toStd_[toBase_[201]]);
		for (int i=0,imax=len; i<imax; i++) {
			char ch = sb.charAt(i);
			sb.setCharAt(i, toStd_[toBase_[ch]]);
			//System.out.print(((int)ch)+"=>"+toBase_[ch]+"=>"+toStd_[toBase_[ch]]+"  ");
			sbout.append(toUni_[ch]);
		}
	}
//System.out.println(" => "+sb.substring(0));
	return Strings.valueOf(sbout);
  }

  /** Return encoding's name of character at that index.
  public String getName(char ch) {
	//assert firstch<=ch && ch<=lastch;
	return names_[ch];
  }

  public char getChar(String name) {
  } */
}

class IdentityH extends Encoding {
  IdentityH() { super(null); }

  public String translate(StringBuffer sb, boolean basetoo) {
	assert sb!=null && sb.length() % 2 == 0;

	int len = sb.length();
	StringBuffer sbout = new StringBuffer(len/2);
	for (int i=0; i<len; i+=2) sbout.append((char)((sb.charAt(i)<<8) | sb.charAt(i+1)));
	sb.setLength(0); sb.append(sbout);  // make sure String and StringBuffer same length

//System.out.println("IdentityH "+sbout);
	return Strings.valueOf(sbout);
  }
}
