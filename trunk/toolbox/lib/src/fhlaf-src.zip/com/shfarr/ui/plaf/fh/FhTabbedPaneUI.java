/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh;

import javax.swing.plaf.basic.*;

import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;

import java.awt.Graphics;
import java.awt.Insets;

import javax.swing.JTabbedPane;

import javax.swing.Icon;
import javax.swing.UIManager;
import javax.swing.JComponent;
import javax.swing.border.Border;
import javax.swing.plaf.ComponentUI;

import com.shfarr.ui.GraphicsUtils;
import com.shfarr.ui.plaf.fh.borders.FHMultiMatrixBorder;
import com.shfarr.ui.plaf.fh.borders.FhMatrixBorder;
import com.shfarr.ui.plaf.fh.textures.Texture;
import com.shfarr.ui.plaf.fh.theme.ThemeManager;

import java.awt.Dimension;
import java.awt.image.BufferedImage;

//TODO Oct 21, 2003: the tab background overpaints
public class FhTabbedPaneUI extends BasicTabbedPaneUI{
    protected int lastTab0y = -9999;

	public FhTabbedPaneUI() {
		super();
	}

	public static ComponentUI createUI(JComponent c){
	   return new FhTabbedPaneUI();
	}

    public void paint(Graphics g, JComponent c){
        ThemeManager.instance().probeAntialiasing(g);

        super.paint(g, c);
        
        if(tabPane.getSelectedIndex() != -1) paintTab(g, tabPane.getTabPlacement(), rects, tabPane.getSelectedIndex(), new Rectangle(), new Rectangle());
    }

    public void installUI(JComponent c){
        super.installUI(c);
        c.setOpaque(true);
        c.setBorder((Border)UIManager.getDefaults().get("TabbedPane.border"));
    }
    
    protected void paintTabArea(Graphics g, int tabPlacement, int selectedIndex){
        int tabCount = tabPane.getTabCount(),
            tah = calculateTabAreaHeight(tabPlacement, runCount, maxTabHeight),
            taw = calculateTabAreaWidth(tabPlacement, runCount, maxTabWidth);

        Insets ins = tabPane.getInsets();

        Rectangle iconRect = new Rectangle(),
                  textRect = new Rectangle();
        Rectangle clipRect = g.getClipBounds();  

        g.setColor(UIManager.getColor("TabbedPane.tabAreaBackground"));

        switch(tabPlacement){
            case LEFT: g.fillRect(ins.left, ins.top, taw, tabPane.getSize().height); break;
            case RIGHT: g.fillRect(tabPane.getSize().width -ins.right -taw, ins.top, taw, tabPane.getSize().height); break;
            case BOTTOM: g.fillRect(ins.left, tabPane.getSize().height -ins.bottom -tah, tabPane.getSize().width, tah); break;

            default: g.fillRect(ins.left, ins.top, tabPane.getSize().width, tah); break;
        }

        // Paint tabRuns of tabs from back to front
        for(int i = runCount - 1; i >= 0; i--){
            int start = tabRuns[i];
            int next = tabRuns[(i == runCount - 1)? 0 : i + 1];
            int end = (next != 0 ? next - 1 : tabCount -1);

            for(int j = start; j <= end; j++) if(rects[j].intersects(clipRect)) paintTab(g, tabPlacement, rects, j, iconRect, textRect);
        }
    }

    protected Insets getContentBorderInsets(int tabPlacement){
        Border b = UIManager.getDefaults().getBorder("TabbedPane.contentBorder");

        return b == null ? new Insets(0, 0, 0, 0) : b.getBorderInsets(tabPane); 
    }
    
    protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex){
        Insets ins = tabPane.getInsets();
        Dimension dim = tabPane.getSize();

        int x = ins.left,
            y = ins.top,
            tah = calculateTabAreaHeight(tabPlacement, runCount, maxTabHeight),
            taw = calculateTabAreaWidth(tabPlacement, runCount, maxTabWidth),
            width = dim.width -x -ins.right,
            height = dim.height -y -ins.bottom;
        
        switch(tabPlacement){
            case LEFT: x += taw; width -= (x - ins.left); break;
            case RIGHT: width -= taw; break;
            case BOTTOM: height -= tah; break;
            case TOP: y += tah; height -= (y - ins.top); break;
        }
        
        Border b = UIManager.getDefaults().getBorder("TabbedPane.contentBorder");
        
        if(b instanceof FhMatrixBorder && ThemeManager.instance().getCurrentTheme().metaPalette().get("TabContent border rotates").equals(Boolean.TRUE)){
            switch(tabPlacement){
                case LEFT: b = ((FhMatrixBorder)b).deriveBorder(GraphicsUtils.ROTATE_270); break;
                case RIGHT: b = ((FhMatrixBorder)b).deriveBorder(GraphicsUtils.ROTATE_90); break;
                case BOTTOM: b = ((FhMatrixBorder)b).deriveBorder(GraphicsUtils.ROTATE_180); break;
            }
        }
        
        if(b != null) b.paintBorder(tabPane, g, x, y, width, height);
    }

    protected void paintTabBorder(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected){
        int shift = 1;
        Insets ins = getContentBorderInsets(0);
        Border mb = null;
        
        switch(tabPlacement){
            case LEFT:
                shift += ins.left;
                w += shift;
                mb = UIManager.getBorder("TabbedPane.tabLeft");
                
                if(mb instanceof FHMultiMatrixBorder){
                    mb = ((FHMultiMatrixBorder)mb).deriveBorder(GraphicsUtils.ROTATE_90);

                    if(isSelected && tabPane.hasFocus()) ((FHMultiMatrixBorder)mb).selectMatrix("focused");
                    else if(isSelected) ((FHMultiMatrixBorder)mb).selectMatrix("selected");
                    else ((FHMultiMatrixBorder)mb).selectMatrix(null);
                }
                
                if(mb != null) mb.paintBorder(tabPane, g, x, y, h, w);
                
                break;

            case RIGHT:
                shift += ins.right;
                w += shift; x -= shift;
                mb = UIManager.getBorder("TabbedPane.tabRight");
                    
                if(mb instanceof FHMultiMatrixBorder){
                    if(isSelected && tabPane.hasFocus()) ((FHMultiMatrixBorder)mb).selectMatrix("focused");
                    else if(isSelected) ((FHMultiMatrixBorder)mb).selectMatrix("selected");
                    else ((FHMultiMatrixBorder)mb).selectMatrix(null);
                }
                
                if(mb != null) mb.paintBorder(tabPane, g, x, y, w, h);
                break;

            case BOTTOM:
                shift += ins.bottom;
                h += shift; y -= shift;
                mb = UIManager.getBorder("TabbedPane.tabBottom");
                    
                if(mb instanceof FHMultiMatrixBorder){
                    if(isSelected && tabPane.hasFocus()) ((FHMultiMatrixBorder)mb).selectMatrix("focused");
                    else if(isSelected) ((FHMultiMatrixBorder)mb).selectMatrix("selected");
                    else ((FHMultiMatrixBorder)mb).selectMatrix(null);
                }
                
                if(mb != null) mb.paintBorder(tabPane, g, x, y, w, h);
                break;

            default: 
                shift += ins.top;
                h += shift; 
                mb = UIManager.getBorder("TabbedPane.tabTop");
                    
                if(mb instanceof FHMultiMatrixBorder){
                    if(isSelected && tabPane.hasFocus()) ((FHMultiMatrixBorder)mb).selectMatrix("focused");
                    else if(isSelected) ((FHMultiMatrixBorder)mb).selectMatrix("selected");
                    else ((FHMultiMatrixBorder)mb).selectMatrix(null);
                }
                
                if(mb != null) mb.paintBorder(tabPane, g, x, y, w, h);
                break;
        }
    }

    protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected){
        int shift = ((Integer)UIManager.getDefaults().get("TabbedPane.selectedTabShift")).intValue();
        
        if(isSelected) g.setColor(UIManager.getColor("TabbedPane.selectedBackground"));
        else g.setColor(UIManager.getColor("TabbedPane.unselectedBackground"));
        
        switch(tabPlacement){
            case LEFT: w += shift; g.fillRect(x, y, h, w); if(isSelected) paintTexture(g, tabPlacement, x, y, h, w); break;
            case RIGHT: w += shift; x -= shift; g.fillRect(x, y, w, h); if(isSelected) paintTexture(g, tabPlacement, x, y, w, h); break;
            case BOTTOM: h += shift; y -= shift; g.fillRect(x, y, w, h); if(isSelected) paintTexture(g, tabPlacement, x, y, w, h); break;

            default: h += shift; g.fillRect(x, y, w, h); if(isSelected) paintTexture(g, tabPlacement, x, y, w, h); break;
        }

        g.setColor(tabPane.getForegroundAt(tabIndex));
    }
    
    private void paintTexture(Graphics g, int tabPlacement, int x, int y, int w, int h){
        Texture texture = (Texture)UIManager.getDefaults().get("TabbedPane.tabTexture");
        if(texture != null && ThemeManager.instance().probeSmallTextures()) texture.apply(new Rectangle(x, y, w, h), (Graphics2D)g, this.tabPane);
    }
    
    protected void paintTab(Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect){
        if(tabPlacement == JTabbedPane.LEFT){
            BufferedImage b_img = new BufferedImage(rects[tabIndex].height, rects[tabIndex].width + getContentBorderInsets(tabPlacement).left, BufferedImage.TYPE_INT_ARGB);
            Graphics imgc = b_img.createGraphics();

            imgc.translate(-rects[tabIndex].x, -rects[tabIndex].y);
            //imgc.setClip(g.getClip());
            ((Graphics2D)imgc).setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            
            super.paintTab(imgc, tabPlacement, rects, tabIndex, iconRect, textRect);
            
            b_img = GraphicsUtils.rotate90(b_img, 1);
            g.drawImage(b_img, rects[tabIndex].x, rects[tabIndex].y, null);
        }
        else super.paintTab(g, tabPlacement, rects, tabIndex, iconRect, textRect);
    }

    protected void layoutLabel(int tabPlacement, FontMetrics metrics, int tabIndex, String title, Icon icon, Rectangle tabRect, Rectangle iconRect, Rectangle textRect, boolean isSelected ){
        if(tabPlacement == JTabbedPane.LEFT){
            Rectangle tabRect_mod = new Rectangle(tabRect.x, tabRect.y, tabRect.height, tabRect.width);
            super.layoutLabel(tabPlacement, metrics, tabIndex, title, icon, tabRect_mod, iconRect, textRect, isSelected); 
        }
        else super.layoutLabel(tabPlacement, metrics, tabIndex, title, icon, tabRect, iconRect, textRect, isSelected);
    }
    
    private boolean scrollableTabLayoutEnabled() {
	   return tabPane.getTabLayoutPolicy() == JTabbedPane.SCROLL_TAB_LAYOUT;
    }
    
    protected int getTabLabelShiftY(int tabPlacement, int tabIndex, boolean isSelected){
        int shift = ((Integer)UIManager.getDefaults().get("TabbedPane.selectedTabShift")).intValue();

        switch(tabPlacement){
            case LEFT: return 0;
            case RIGHT: return 0;
            case BOTTOM: return -shift/2;
            default: return shift/2;
        }
    }

    protected int getTabLabelShiftX(int tabPlacement, int tabIndex, boolean isSelected){
        int shift = ((Integer)UIManager.getDefaults().get("TabbedPane.selectedTabShift")).intValue();

        switch(tabPlacement){
            case LEFT: return shift/2;
            case RIGHT: return -shift/2;
            case BOTTOM: return 0;
            default: return 0;
        }
    }
    
    protected void paintFocusIndicator(Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected){
    }

    protected int getTabRunIndent(int tabPlacement, int run){
        return -1;
    }
    
    protected int calculateTabWidth(int tabPlacement, int tabIndex, FontMetrics metrics){
        if(tabPlacement == JTabbedPane.LEFT) return super.calculateTabHeight(tabPlacement, tabIndex, metrics.getHeight());
        else return super.calculateTabWidth(tabPlacement, tabIndex, metrics);
    }

    protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight){
        if(tabPlacement == JTabbedPane.LEFT) return super.calculateTabWidth(tabPlacement, tabIndex, getFontMetrics());
        else return super.calculateTabHeight(tabPlacement, tabIndex, fontHeight);
    }
}