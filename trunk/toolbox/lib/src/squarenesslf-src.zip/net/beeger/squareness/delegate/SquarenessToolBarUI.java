/*
  Copyright (C) 2003-2004 Robert F. Beeger (robert at beeger dot net)
  Licensed under the Academic Free License version 2.1
  OSI Certified Open Source Software

  Visit http://squareness.sourceforge.net/ for new releases of Squareness Look And Feel and other
  skins from the Squareness series.
*/
package net.beeger.squareness.delegate;

import java.awt.Component;
import java.awt.event.ContainerEvent;
import java.awt.event.ContainerListener;
import javax.swing.AbstractButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JToggleButton;
import javax.swing.border.Border;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.UIResource;
import javax.swing.plaf.basic.BasicToolBarUI;

import net.beeger.squareness.util.SquarenessBorderFactory;

/**
 * The Squareness Tool Bar UI delegate.
 */
public class SquarenessToolBarUI extends BasicToolBarUI
{
  /**
   * Create the ui delegate for the given component
   * 
   * @param component The component for which to create the ui delegate
   * @return The created ui delegate
   */
  public static ComponentUI createUI (JComponent component)
  {
    return new SquarenessToolBarUI();
  }

  /**
   * Install the UI delegate for the given component.
   *
   * @param component The component for which to install the UI delegate.
   */
  public void installUI (JComponent component)
  {
    super.installUI(component);
    toolBar.addContainerListener(new ContainerListener()
    {
      public void componentAdded (ContainerEvent e)
      {
        JComponent child = (JComponent) e.getChild();
      }

      public void componentRemoved (ContainerEvent e)
      {
      }
    });
  }

  /**
   * Create a rollover border. This border will be used if rollover borders are enabled.
   */
  protected Border createRolloverBorder ()
  {
    return SquarenessBorderFactory.getButtonRolloverBorder();
  }

  /**
   * Create a non rollover border. This border will be used if rollover borders are disabled.
   */
  protected Border createNonRolloverBorder ()
  {
    return SquarenessBorderFactory.getButtonNonRolloverBorder();
  }

  /**
   * Set the non rollover border on the given component.
   *
   * @param component The component to set the non rollover border on.
   */
  protected void setBorderToNonRollover (Component component)
  {
    super.setBorderToNonRollover(component);
    if (component instanceof AbstractButton)
    {
      AbstractButton button = (AbstractButton) component;
      if (button.getBorder() instanceof UIResource)
      {
        if (button instanceof JToggleButton && !(button instanceof JCheckBox))
        {
          // only install this border for the ToggleButton
          button.setBorder(SquarenessBorderFactory.getButtonNonRolloverBorder());
        }
      }
    }
  }
}

/*
  $Log: SquarenessToolBarUI.java,v $
  Revision 1.4  2004/09/18 17:30:47  rbeeger
  * Updated copyright block and license file. Squareness Look And Feel is now licensed under Academic Free License 2.1
  * Added themepack.

  Revision 1.3  2004/03/08 15:12:26  rbeeger
  Added and enhanced comments.
  Simplified code.

  Revision 1.2  2004/02/14 19:12:34  rbeeger
  Updated copyright statement
  Added cvs log directive at the end of each file
  Optimized imports
  Reformated code

 */
