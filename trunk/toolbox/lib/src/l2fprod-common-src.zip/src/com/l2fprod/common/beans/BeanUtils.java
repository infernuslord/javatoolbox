/** ===================================================================
 *
 * L2FProd.com Common Components 0.1-dev License.
 *
 * Copyright (c) 2004 L2FProd.com.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by L2FProd.com
 *        (http://www.L2FProd.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "L2FProd.com Common Components", "l2fprod-common" and "L2FProd.com" must not
 *    be used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact info@L2FProd.com.
 *
 * 5. Products derived from this software may not be called "l2fprod-common"
 *    nor may "l2fprod-common" appear in their names without prior written
 *    permission of L2FProd.com.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL L2FPROD.COM OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package com.l2fprod.common.beans;

import java.lang.reflect.Method;

/**
 * BeanUtils. <br>
 *  
 */
public class BeanUtils {

  private BeanUtils() {
  }

  public static Method getReadMethod(Class clazz, String propertyName) {
    Method readMethod = null;
    String base = capitalize(propertyName);

    // Since there can be multiple setter methods but only one getter
    // method, find the getter method first so that you know what the
    // property type is. For booleans, there can be "is" and "get"
    // methods. If an "is" method exists, this is the official
    // reader method so look for this one first.
    try {
      readMethod = clazz.getMethod("is" + base, null);
    } catch (Exception getterExc) {
      try {
        // no "is" method, so look for a "get" method.
        readMethod = clazz.getMethod("get" + base, null);
      } catch (Exception e) {
        // no is and no get, we will return null
      }
    }

    return readMethod;
  }

  public static Method getWriteMethod(
    Class clazz,
    String propertyName,
    Class propertyType) {
    Method writeMethod = null;
    String base = capitalize(propertyName);

    Class params[] = { propertyType };
    try {
      writeMethod = clazz.getMethod("set" + base, params);
    } catch (Exception e) {
      // no write method
    }

    return writeMethod;
  }

  private static String capitalize(String s) {
    if (s.length() == 0) {
      return s;
    } else {
      char chars[] = s.toCharArray();
      chars[0] = Character.toUpperCase(chars[0]);
      return String.valueOf(chars);
    }
  }

}
