/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	Tiny Look and Feel                                                         *
*                                                                              *
*  (C) Copyright 2003, Hans Bickel                                             *
*                                                                              *
*   For licensing information and credits, please refer to the                 *
*   comment in file de.muntjak.tinylookandfeel.TinyLookAndFeel                 *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package de.muntjak.tinylookandfeel;

import javax.swing.*;

/**
 * TinyDesktopManager
 * 
 * @version 1.0
 * @author Hans Bickel
 */
public class TinyDesktopManager extends DefaultDesktopManager {

	public void beginDraggingFrame(JComponent f) {}

	public void dragFrame(JComponent f, int newX, int newY) {

		setBoundsForFrame(f, newX, newY, f.getWidth(), f.getHeight());
	}

	public void endDraggingFrame(JComponent f) {}

	public void resizeFrame(JComponent f, int newX, int newY, int newWidth, int newHeight) {

		setBoundsForFrame(f, newX, newY, newWidth, newHeight);
	}

	public void endResizingFrame(JComponent f) {}
}
