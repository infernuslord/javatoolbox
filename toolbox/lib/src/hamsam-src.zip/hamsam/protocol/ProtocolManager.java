/*
 * Hamsam - Instant Messaging API
 * Copyright (C) 2003 Raghu K
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package hamsam.protocol;

import hamsam.api.IMListener;
import hamsam.exception.IllegalArgumentException;
import hamsam.exception.IllegalStateException;
import hamsam.protocol.aim.AIMProtocol;
import hamsam.protocol.msn.MsnProtocol;
import hamsam.protocol.yahoo.YahooProtocol;

import java.io.Serializable;
import java.util.Vector;

/**
 * Provides an interface for manipulating all available protocols.
 *
 * This class enables the plug-and-play behaviour of Hamsam. Users
 * of Hamsam library may use this class to manipulate all available
 * protocols without knowing actually what all protocols are
 * available at compile time. This means that you can easily switch
 * between different versions of Hamsam without changing your code.
 * As and when new versions of the library comes up with support
 * for new protocols, you can just remove the old version from the
 * classpath and put the new library to the classpath. If the
 * application is coded properly, it will start supporting the new
 * protocols without any change of code.
 *
 * @author Raghu
 * @see    Protocol Protocol
 */
public abstract class ProtocolManager implements Serializable
{
	/**
	 * All available protocols.
	 */
	private static Vector protocols;

	static
	{
		protocols = new Vector();

		protocols.add(new YahooProtocol());
		protocols.add(new MsnProtocol());
        protocols.add(new AIMProtocol());
	}

	/**
	 * Set the listener which will receive all instant messaging
	 * events from all available protocols.
	 *
	 * @param listener the listener to be registered, pass
	 *                 <code>null</code> to unregister the
	 *                 current listener.
	 */
	public static void setIMListener(IMListener listener)
	{
		for(int i = 0; i < protocols.size(); i++)
			((Protocol) protocols.elementAt(i)).setListener(listener);
	}

	/**
	 * Get all available protocols.
	 *
	 * @return an array of all available protocols.
	 */
	public static Protocol[] getAvailableProtocols()
	{
		Protocol[] ret = new Protocol[protocols.size()];

		for(int i = 0; i < protocols.size(); i++)
			ret[i] = (Protocol) protocols.elementAt(i);

		return ret;
	}

	/**
	 * Change your status message for all protocols which are connected.
	 * The status passed may be null, which indicates to make the user
	 * invisible. If a protocol does not support invisible status,
	 * an IllegalArgumentException is thrown.
	 *
	 * @param status                          the new status message.
	 * @throws IllegalArgumentException  if <code>status</code> is null and a
	 *                                        protocol does not support invisible status.
	 * @see Protocol#isInvisibleSupported()   Protocol.isInvisibleSupported() 
	 */
	public static void changeStatus(String status) throws IllegalArgumentException
	{
		for(int i = 0; i < protocols.size(); i++)
		{
			try
			{
				((Protocol) protocols.elementAt(i)).changeStatus(status);
			}
			catch(IllegalStateException e)
			{
				// This protocol is not connected
			}
		}
	}
}
