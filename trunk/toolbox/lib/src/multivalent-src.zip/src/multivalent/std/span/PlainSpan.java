package multivalent.std.span;

import java.awt.Font;

import multivalent.*;


/**
	Convenience span for setting plain text.
	Applications should usually instead use a generic {@link multivalent.Span} with a name, and set display properties in the stylesheet.

	@version $Revision: 1.2 $ $Date: 2002/02/02 13:16:27 $
*/
public class PlainSpan extends Span {

  public boolean appearance(Context cx, boolean all) { cx.style = Font.PLAIN; return false; }

//  public int getPriority() { return ContextListener.PRIORITY_SPAN+ContextListener.LITTLE; }
}
