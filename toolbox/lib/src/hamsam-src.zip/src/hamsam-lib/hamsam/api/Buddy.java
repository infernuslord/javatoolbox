/*
 * Please see COPYING for license details
 *
 * Copyright (C) 2003 Raghu K, All rights reserved.
 */

package hamsam.api;

import java.io.Serializable;
import hamsam.protocol.Protocol;
import hamsam.exception.UnsupportedOperationException;
import hamsam.exception.IllegalArgumentException;
import hamsam.exception.IllegalStateException;

/**
 * A buddy is a person who is participating in instant messaging.
 * A buddy is usually identified by a unique name in the underlying
 * protocol's namespace.
 *
 * @author Raghu
 */
public class Buddy implements Serializable
{
	/**
	 * The protocol used by this buddy.
	 */
	private Protocol protocol;

	/**
	 * The username of this buddy.
	 */
	private String username;

	/**
	 * The group of this buddy.
	 */
	private String group;

	/**
	 * Status of this buddy.
	 */
	private String status;

	/**
	 * Alias name of this buddy.
	 */
	private String alias;

	/**
	 * Construct a buddy object for a buddy with a specified
	 * protocol and username. This constructor is used when the
	 * group of the buddy is not relevant.
	 *
	 * @param protocol the underlying protocol for this buddy.
	 * @param username the username of this buddy.
	 */
	public Buddy(Protocol protocol, String username)
	{
		this.protocol = protocol;
		this.username = username;
		this.group = null;
	}

	/**
	 * Construct a buddy object for a buddy with a specified
	 * protocol, username, and group. If the protocol does not
	 * support buddy groups, the group parameter is ignored.
	 *
	 * @param protocol the underlying protocol for this buddy.
	 * @param username the username of this buddy.
	 * @param group the group to which this buddy belongs to. If the
	 *              protocol does not support groups, this parameter is
	 *              ignored.
	 */
	public Buddy(Protocol protocol, String username, String group)
	{
		this.protocol = protocol;
		this.username = username;

		if(protocol.isBuddyGroupSupported())
			this.group = group;
		else
			this.group = null;
	}

	/**
	 * Get the status message for this buddy.
	 *
	 * @return the status message.
	 */
	public String getStatus()
	{
		return status;
	}

	/**
	 * Set the status message for this buddy.
	 *
	 * @param status the status message.
	 */
	public void setStatus(String status)
	{
		this.status = status;
	}

	/**
	 * Returns the alias name of this buddy. Alias is also known as nick name.
	 * Alias is not unique in the namespace of a protocol. Not all protocols
	 * support aliases. If this buddy's protocol does not support aliases, this
	 * method returns <code>null</code>.
	 *
	 * @see hamsam.protocol.Protocol#isBuddyNameAliasSupported() Protocol.isBuddyNameAliasSupported
	 * @return the alias name of this buddy.
	 */
	public String getAlias()
	{
		return alias;
	}

	/**
	 * Set the alias name of this buddy. This method is internally used by Hamsam API
	 * and not meant for users of the API. If you want to change the alias name
	 * of a buddy, use {@link #changeAlias(String) changeAlias(newAlias)} instead.
	 *
	 * <p>
	 * Alias is also known as nick name. Alias is not unique in the namespace of a
	 * protocol. Not all protocols support aliases.
	 *
	 * @see hamsam.protocol.Protocol#isBuddyNameAliasSupported() Protocol.isBuddyNameAliasSupported
	 * @param alias the alias name of this buddy.
	 */
	public void setAlias(String alias)
	{
		this.alias = alias;
	}

	/**
	 * Changes the alias name of this buddy. Alias is also known as nick name.
	 * Alias is not unique in the namespace of a protocol. Not all protocols
	 * support aliases. If this buddy's protocol does not support aliases, this
	 * method throws an {@link hamsam.exception.UnsupportedOperationException
	 * UnSupportedOperationException}.
	 *
	 * @param alias the new alias for this buddy
	 */
	public void changeAlias(String alias) throws UnsupportedOperationException
	{
		this.protocol.changeBuddyAlias(this, alias);
		setAlias(alias);
	}

	/**
	 * Get the protocol used by this buddy.
	 *
	 * @return the protocol of this buddy.
	 */
	public Protocol getProtocol()
	{
		return protocol;
	}

	/**
	 * Returns the username of this buddy.
	 *
	 * @return the username of this buddy.
	 */
	public String getUsername()
	{
		return username;
	}

	/**
	 * Returns the group of this buddy. If the underlying
	 * protocol does not support groups, this will return null.
	 *
	 * @return the group of this buddy.
	 */
	public String getGroup()
	{
		return group;
	}

	/**
	 * Add this buddy to your buddy list. The result of this operation
	 * will be notified to the registered <code>IMListener</code>.
	 *
	 * @see IMListener#buddyAddRequest(Buddy,Buddy,String) IMListener.buddyAddRequest
	 * @see IMListener#buddyAdded(Buddy) IMListener.buddyAdded
	 * @see IMListener#buddyAddFailed(Buddy,String) IMListener.buddyAddFailed
	 *
	 * @throws IllegalArgumentException if the protocol supports buddy groups and the
	 *                                  group of the buddy is not specified.
	 * @throws IllegalStateException if the protocol is not connected yet
	 */
	public void addToBuddyList() throws IllegalArgumentException, IllegalStateException
	{
		protocol.addToBuddyList(this);
	}

	/**
	 * Delete this buddy from your buddy list. The result of this operation
	 * will be notified to the registered <code>IMListener</code>.
	 *
	 * @see IMListener#buddyDeleted(Buddy) IMListener.buddyDeleted
	 * @see IMListener#buddyDeleteFailed(Buddy,String) IMListener.buddyDeleteFailed
	 *
	 * @throws IllegalArgumentException if the protocol supports buddy groups and the
	 *                                  group of the buddy is not specified.
	 * @throws IllegalStateException if the protocol is not connected yet
	 */
	public void deleteFromBuddyList() throws IllegalArgumentException, IllegalStateException
	{
		protocol.deleteFromBuddyList(this);
	}

	/**
	 * Prevent this buddy from sending you messages. The result of this
	 * operation will be notified to the registered <code>IMListener</code>.
	 *
	 * @see IMListener#buddyIgnored(Buddy) IMListener.buddyIgnored
	 * @see IMListener#buddyIgnoreFailed(Buddy,String) IMListener.buddyIgnoreFailed
	 *
	 * @throws UnsupportedOperationException if this protocol does not support ignoring buddies.
	 * @throws IllegalStateException if the protocol is not connected yet
	 */
	public void ignore() throws UnsupportedOperationException, IllegalStateException
	{
		protocol.ignoreBuddy(this);
	}

	/**
	 * Undo a previous ignore operation for this buddy. The result of this
	 * operation will be notified to the registered <code>IMListener</code>.
	 *
	 * @see IMListener#buddyUnignored(Buddy) IMListener.buddyUnignored
	 * @see IMListener#buddyUnignoreFailed(Buddy,String) IMListener.buddyUnignoreFailed
	 *
	 * @throws UnsupportedOperationException if this protocol does not support ignoring buddies.
	 * @throws IllegalStateException if the protocol is not connected yet
	 */	
	public void unignore() throws UnsupportedOperationException, IllegalStateException
	{
		protocol.unignoreBuddy(this);
	}

	/**
	 * Send an instant message to this buddy.
	 *
	 * @param message the message to be sent.
	 * @throws IllegalStateException if the protocol is not yet connected.
	 */
	public void sendInstantMessage(Message message) throws IllegalStateException
	{
		protocol.sendInstantMessage(this, message);
	}

	/**
	 * Notify this buddy that you have started typing.
	 *
	 * @throws UnsupportedOperationException if this protocol does not support
	 *                                       typing notifications.
	 * @throws IllegalStateException if the protocol is not connected yet
	 */
	public void typingStarted() throws UnsupportedOperationException, IllegalStateException
	{
		protocol.typingStarted(this);
	}
	
	/**
	 * Notify this buddy that you have stopped typing.
	 *
	 * @throws UnsupportedOperationException if this protocol does not support
	 *                                       typing notifications.
	 * @throws IllegalStateException if the protocol is not connected yet
	 */
	public void typingStopped() throws UnsupportedOperationException, IllegalStateException
	{
		protocol.typingStopped(this);
	}

	/**
	 * Compares the specified object with this Buddy for equality.
	 * Returns true if and only if the specified object is also a Buddy,
	 * both Buddies have the same protocol and username.
	 *
	 * @param obj the object to be compared for equality with this Buddy.
	 * @return true if the specified object is equal to this Buddy.
	 */
	public boolean equals(Object obj)
	{
		if(!(obj instanceof Buddy))
			return false;

		Buddy objBuddy = (Buddy) obj;

		if(this.protocol != objBuddy.protocol)
			return false;
		if(!this.username.equals(objBuddy.username))
			return false;

		return true;
	}
}
