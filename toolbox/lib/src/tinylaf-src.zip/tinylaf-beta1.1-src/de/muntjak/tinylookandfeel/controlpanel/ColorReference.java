/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	Tiny Look and Feel                                                         *
*                                                                              *
*  (C) Copyright 2003, Hans Bickel                                             *
*                                                                              *
*                                                                              *
*   This library is free software; you can redistribute it and/or modify it    *
*   under the terms of the GNU Lesser General Public License as published by   *
*   the Free Software Foundation; either version 2.1 of the License, or (at    *
*   your option) any later version.                                            *
*                                                                              *
*   This library is distributed in the hope that it will be useful,            *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of             *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                       *
*   See the GNU Lesser General Public License for more details.                *
*                                                                              *
*   You should have received a copy of the GNU General Public License along    *
*   with this program; if not, write to the Free Software Foundation, Inc.,    *
*   59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.                    *
*                                                                              *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package de.muntjak.tinylookandfeel.controlpanel;

import java.awt.*;
import java.io.*;
import javax.swing.*;

import de.muntjak.tinylookandfeel.Theme;

/**
 * ColorReference
 * 
 * @version 1.0
 * @author Hans Bickel
 */
public class ColorReference {
	
	public static final int ABS_COLOR 		= 1;
	public static final int MAIN_COLOR 		= 2;
	public static final int BACK_COLOR 		= 3;
	public static final int DIS_COLOR 		= 4;
	public static final int FRAME_COLOR 		= 5;
	public static final int SUB1_COLOR 		= 6;
	public static final int SUB2_COLOR 		= 7;
	public static final int SUB3_COLOR 		= 8;
	public static final int SUB4_COLOR 		= 9;
	public static final int SUB5_COLOR 		= 10;
	public static final int SUB6_COLOR 		= 11;
	public static final int SUB7_COLOR 		= 12;
	public static final int SUB8_COLOR 		= 13;

	private Color c;
	private int sat, bri;
	private int ref;
	private boolean locked;
	private ColorIcon icon;
	private static ColorIcon absolueIcon;
	
	public ColorReference(Color c) {
		this.c = c;
		sat = 0;
		bri = 0;
		ref = ABS_COLOR;
	}
	
	public ColorReference(Color c, int sat, int bri, int ref) {
		this.c = c;
		this.sat = sat;
		this.bri = bri;
		this.ref = ref;
	}
	
	public ColorReference(Color c, int sat, int bri, int ref, boolean locked) {
		this.c = c;
		this.sat = sat;
		this.bri = bri;
		this.ref = ref;
		this.locked = locked;
	}
	
	public void reset() {
		sat = 0;
		bri = 0;
	}
	
	public Color getColor() { return c; }
	
	public int getSaturation() { return sat; }
	
	public int getBrightness() { return bri; }
	
	public int getReference() { return ref; }
	
	public Color getReferenceColor() {
		switch(ref) {
			case MAIN_COLOR:
				return Theme.mainColor[Theme.style].getColor();
			case BACK_COLOR:
				return Theme.backColor[Theme.style].getColor();
			case DIS_COLOR:
				return Theme.disColor[Theme.style].getColor();
			case FRAME_COLOR:
				return Theme.frameColor[Theme.style].getColor();
			case SUB1_COLOR:
				return Theme.sub1Color[Theme.style].getColor();
			case SUB2_COLOR:
				return Theme.sub2Color[Theme.style].getColor();
			case SUB3_COLOR:
				return Theme.sub3Color[Theme.style].getColor();
			case SUB4_COLOR:
				return Theme.sub4Color[Theme.style].getColor();
			case SUB5_COLOR:
				return Theme.sub5Color[Theme.style].getColor();
			case SUB6_COLOR:
				return Theme.sub6Color[Theme.style].getColor();
			case SUB7_COLOR:
				return Theme.sub7Color[Theme.style].getColor();
			case SUB8_COLOR:
				return Theme.sub8Color[Theme.style].getColor();
			default:
				return c;
		}
	}
	
	public String getReferenceString() {
		switch(ref) {
			case MAIN_COLOR:
				return "Main Color";
			case BACK_COLOR:
				return "Back Color";
			case DIS_COLOR:
				return "Disabled Color";
			case FRAME_COLOR:
				return "Frame Color";
			case SUB1_COLOR:
				return "Sub1 Color";
			case SUB2_COLOR:
				return "Sub2 Color";
			case SUB3_COLOR:
				return "Sub3 Color";
			case SUB4_COLOR:
				return "Sub4 Color";
			case SUB5_COLOR:
				return "Sub5 Color";
			case SUB6_COLOR:
				return "Sub6 Color";
			case SUB7_COLOR:
				return "Sub7 Color";
			case SUB8_COLOR:
				return "Sub8 Color";
			default:
				return "";
		}
	}
	
	public void setColor(Color newColor) {
		if(!isAbsoluteColor()) return;
		
		c = newColor;
	}
	
	public void setSaturation(int newSat) { sat = newSat; }
	
	public void setBrightness(int newBri) { bri = newBri; }
	
	public void setReference(int newRef) { ref = newRef; }
	
	public void setColor(int sat, int bri) {
		if(isAbsoluteColor()) return;
		
		this.sat = sat;
		this.bri = bri;
		
		switch(ref) {
			case MAIN_COLOR:
				c = SBChooser.getAdjustedColor(Theme.mainColor[Theme.style].getColor(), sat, bri);
				break;
			case BACK_COLOR:
				c = SBChooser.getAdjustedColor(Theme.backColor[Theme.style].getColor(), sat, bri);
				break;
			case DIS_COLOR:
				c = SBChooser.getAdjustedColor(Theme.disColor[Theme.style].getColor(), sat, bri);
				break;
			case FRAME_COLOR:
				c = SBChooser.getAdjustedColor(Theme.frameColor[Theme.style].getColor(), sat, bri);
				break;
			case SUB1_COLOR:
				c = SBChooser.getAdjustedColor(Theme.sub1Color[Theme.style].getColor(), sat, bri);
				break;
			case SUB2_COLOR:
				c = SBChooser.getAdjustedColor(Theme.sub2Color[Theme.style].getColor(), sat, bri);
				break;
			case SUB3_COLOR:
				c = SBChooser.getAdjustedColor(Theme.sub3Color[Theme.style].getColor(), sat, bri);
				break;
			case SUB4_COLOR:
				c = SBChooser.getAdjustedColor(Theme.sub4Color[Theme.style].getColor(), sat, bri);
				break;
			case SUB5_COLOR:
				c = SBChooser.getAdjustedColor(Theme.sub5Color[Theme.style].getColor(), sat, bri);
				break;
			case SUB6_COLOR:
				c = SBChooser.getAdjustedColor(Theme.sub6Color[Theme.style].getColor(), sat, bri);
				break;
			case SUB7_COLOR:
				c = SBChooser.getAdjustedColor(Theme.sub7Color[Theme.style].getColor(), sat, bri);
				break;
			case SUB8_COLOR:
				c = SBChooser.getAdjustedColor(Theme.sub8Color[Theme.style].getColor(), sat, bri);
				break;
		}
	}
	
	public Color update() {
		if(isAbsoluteColor()) return c;
		
		switch(ref) {
			case MAIN_COLOR:
				c = SBChooser.getAdjustedColor(Theme.mainColor[Theme.style].getColor(), sat, bri);
				break;
			case BACK_COLOR:
				c = SBChooser.getAdjustedColor(Theme.backColor[Theme.style].getColor(), sat, bri);
				break;
			case DIS_COLOR:
				c = SBChooser.getAdjustedColor(Theme.disColor[Theme.style].getColor(), sat, bri);
				break;
			case FRAME_COLOR:
				c = SBChooser.getAdjustedColor(Theme.frameColor[Theme.style].getColor(), sat, bri);
				break;
			case SUB1_COLOR:
				c = SBChooser.getAdjustedColor(Theme.sub1Color[Theme.style].getColor(), sat, bri);
				break;
			case SUB2_COLOR:
				c = SBChooser.getAdjustedColor(Theme.sub2Color[Theme.style].getColor(), sat, bri);
				break;
			case SUB3_COLOR:
				c = SBChooser.getAdjustedColor(Theme.sub3Color[Theme.style].getColor(), sat, bri);
				break;
			case SUB4_COLOR:
				c = SBChooser.getAdjustedColor(Theme.sub4Color[Theme.style].getColor(), sat, bri);
				break;
			case SUB5_COLOR:
				c = SBChooser.getAdjustedColor(Theme.sub5Color[Theme.style].getColor(), sat, bri);
				break;
			case SUB6_COLOR:
				c = SBChooser.getAdjustedColor(Theme.sub6Color[Theme.style].getColor(), sat, bri);
				break;
			case SUB7_COLOR:
				c = SBChooser.getAdjustedColor(Theme.sub7Color[Theme.style].getColor(), sat, bri);
				break;
			case SUB8_COLOR:
				c = SBChooser.getAdjustedColor(Theme.sub8Color[Theme.style].getColor(), sat, bri);
				break;
		}
		
		return c;
	}
	
	public boolean isAbsoluteColor() { return (ref == ABS_COLOR); }
	
	public void setLocked(boolean newLocked) { locked = newLocked; }
	
	public boolean isLocked() { return locked; }
	
	public String toString() {
		return c.toString();
	}
	
	public Icon getIcon() {
		if(icon == null) {
			icon = new ColorIcon(false);
		}
		
		return icon;
	}
	
	public static Icon getAbsoluteIcon() {		
		if(absolueIcon == null) {
			absolueIcon = new ColorReference(Color.BLACK).new ColorIcon(true);
		}
		
		return absolueIcon;
	}
	
	public void save(DataOutputStream out) throws IOException {
		out.writeInt(c.getRed());
		out.writeInt(c.getGreen());
		out.writeInt(c.getBlue());
		out.writeInt(sat);
		out.writeInt(bri);
		out.writeInt(ref);
		out.writeBoolean(locked);
	}
	
	public void load(DataInputStream in) throws IOException {
		try {
			c = new Color(in.readInt(), in.readInt(), in.readInt());
			sat = in.readInt();
			bri = in.readInt();
			ref = in.readInt();
			locked = in.readBoolean();
		} catch(Exception ex) {
			throw new IOException("ColorReference.load() : " + ex.getMessage());
		}
	}
	
	class ColorIcon implements Icon {

		private boolean paintGradients;
		
		ColorIcon(boolean paintGradients) {
			this.paintGradients = paintGradients;
		}
		
		public int getIconHeight() {
			return 16;
		}

		public int getIconWidth() {
			return 16;
		}
		
		public void paintIcon(Component comp, Graphics g, int x, int y) {
			Color tempCol = g.getColor();

			g.setColor(Color.GRAY);
			g.drawRect(x, y, getIconWidth(), getIconHeight());
			
			if(paintGradients) {
				float hue = 0.0f;

				for(int i = 0; i < 15; i++) {
					g.setColor(Color.getHSBColor(hue, 0.5f, 1.0f));
					g.drawLine(x + 1 + i, y + 1, x + 1 + i, y + getIconHeight() - 1);
					hue += 1.0 / 16.0;
				}
			}
			else {
				g.setColor(c);
				g.fillRect(x + 1, y + 1, getIconWidth() - 1, getIconHeight() - 1);
			}
			
			// draw arrow
			if(comp instanceof AbstractButton) {
				if(((AbstractButton)comp).isSelected()) {
					g.setColor(Color.WHITE);
					drawArrow(g, x + 1, y + 1);
					
					g.setColor(Color.BLACK);
					drawArrow(g, x, y);
				}
			}
			
			g.setColor(tempCol);
		}
		
		private void drawArrow(Graphics g, int x, int y) {
			g.drawLine(x + 3, y + 5, x + 3, y + 7);
			g.drawLine(x + 4, y + 6, x + 4, y + 8);
			g.drawLine(x + 5, y + 7, x + 5, y + 9);
			g.drawLine(x + 6, y + 6, x + 6, y + 8);
			g.drawLine(x + 7, y + 5, x + 7, y + 7);
			g.drawLine(x + 8, y + 4, x + 8, y + 6);
			g.drawLine(x + 9, y + 3, x + 9, y + 5);
		}
	}
}
