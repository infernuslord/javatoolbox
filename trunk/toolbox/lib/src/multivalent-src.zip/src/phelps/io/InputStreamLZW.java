package phelps.io;

import java.io.InputStream;
import java.io.FilterInputStream;
import java.io.IOException;



/**
	InputStream that decompresses LZW, both UNIX compress and PDF formats.
	Description of LZW found in PDF Reference, and format of UNIX <code>compress</code> found in <code>ncompress-4.2.4</code>.

	@version $Revision: 1.27 $ $Date: 2003/09/18 13:41:15 $
*/
public class InputStreamLZW extends FilterInputStream {
  static final boolean DEBUG = false;

  /** Clear table. */
  static final int CLEAR = 256;
  /** End of data. */
  int eod_;
  int tablestart_;

  /** Magic number for UNIX compress. */
  static final int C_MAGIC1 = 0x1f, C_MAGIC2 = 0x9d;
  static final int C_BITMASK=0x1f, C_BLOCKMODE=0x80;

  /** Bit length of codes. */
  static final int MINBITS=9;
  private int maxbits_, maxlen_;

  private byte[] nextByte_;  //maybe make int[] and don't worry about casting between int and byte.  byte[] 4K vs int[] 16K
  private int[] prevEntry_;
  private int tablei_;
  private int tablelen_;

  private int codelen_ = MINBITS;
  private int mask_ = (1<<MINBITS)-1;
  private int prevcode_ = -1;
  private int bits_ = 0;
  private int validcnt_ = 0;
  private boolean high_; int bitcnt_;	// are new bytes added high or low?
  private int early_;

  private byte[] phrase_;    // each entry in table adds on byte, so this len can't be more than table len, which is a reasonable 2**12
  private int phrasei_;

  private boolean eof_ = false;


  /** Constructor for data stream in PDF format. */
  public InputStreamLZW(InputStream in, boolean earlychange) throws IOException {
	super(in);
	eod_=257; tablestart_=eod_+1;
	init(12, false, earlychange);
  }

  /** Constructor for data stream in UNIX compress format. */
  public InputStreamLZW(InputStream in) throws IOException {
	super(in);

	if (in.read()!=C_MAGIC1 || in.read()!=C_MAGIC2) throw new IOException("bad magic number");

	eod_=-1; tablestart_=CLEAR+1;

	int c = in.read();
	int maxbits = c & 0x1f; if (!(12<=maxbits && maxbits<=16)) throw new IOException("invalid max bits: "+maxbits);
	init(maxbits, true, false);

	//assert (c & C_BLOCKMODE) != 0;
	if ((c & C_BLOCKMODE) == 0) tablei_--;	// weird
  }

  private void init(int maxbits, boolean high, boolean earlychange) {
	maxbits_ = maxbits;
	high_ = high;
	early_ = earlychange? 1: 0;

	maxlen_ = 1<<maxbits;
	nextByte_ = new byte[maxlen_];
	prevEntry_ = new int[nextByte_.length];
	phrase_ = new byte[maxlen_]; phrasei_ = maxlen_;
	tablelen_ = (1<<MINBITS) - early_; tablei_ = tablestart_;

	// initialize single-character phrases in table
	for (int i=0; i<256; i++) {
		nextByte_[i] = (byte)i;
		prevEntry_[i] = -1;     // none
	}
  }

  //public int read(byte[] b) throws IOException { return read(b, 0, b.length); }   // same as inherited

  public int read(byte[] b, int off, int len) throws IOException {
	assert b!=null && off>=0 && len>=0 && len+off <= b.length;
	if (eof_) return -1;

	// speeds up phrase writing as opposed to {@link #read()}.  Used by images.
	len = Math.min(len, b.length-off);
	byte[] ph=phrase_;  // local faster than instance vars
	for (int i=off,imax=off+len, c; i<imax; i++) {
		if (phrasei_ < maxlen_) {    // speed up much?  gets most of gain without copying entire decoding
			int pi=phrasei_, inc = Math.min(maxlen_-pi, imax-i);
			for (int j=i,jmax=i+inc; j<jmax; j++) b[j] = ph[pi++];
			//System.arraycopy(ph,phrasei_, b,i, inc);  // 3130ms=>3510 -- worse, because System.arraycopy has some overhead and phrases in practice are short?
			i += inc -1/*loop inc*/; phrasei_ += inc;
		} else if ((c=read())!=-1) b[i]=(byte)c;
		else return i-off;
	}
	return len;
  }


  public int read() throws IOException {
	int b;

	if (phrasei_ < maxlen_) b = phrase_[phrasei_++] & 0xff;     // want unsigned bytes!
//if (DEBUG) System.out.println("PHRASE @ "+phrasei_);

	else if (eof_) b = -1;     // repeated reads at EOF

	else {
		// need at least one and at most two new bytes to satisfy codelen
		assert validcnt_ < codelen_;
		int c = in.read();	// track EOF for bad streams that end with EOF without LZW EOD
//if (DEBUG) System.out.println("read byte "+Integer.toHexString(c));
		int code;
		if (high_) {	// UNIX compress
			bits_ = (c<<validcnt_) | bits_; validcnt_+=8;
			if (validcnt_ < codelen_) { bits_ = (in.read()<<validcnt_) | bits_; validcnt_+=8; }
			code = bits_ & mask_;
			validcnt_ -= codelen_;
			bitcnt_ += codelen_;
			bits_ = (bits_>>codelen_) & ((1<<validcnt_)-1);
		} else {	// LZW
			bits_ = (bits_<<8) | c; validcnt_+=8;
			if (validcnt_ < codelen_) { bits_ = (bits_<<8) | in.read(); validcnt_+=8; }
			code = (bits_ >> (validcnt_-codelen_)) & mask_;
			validcnt_ -= codelen_;
		}
//*if (DEBUG)*/ System.out.println(/*"NEW: shift by "+validcnt_+*/"code="+Integer.toHexString(code)+", ts="+tablei_);
		assert validcnt_ < MINBITS: validcnt_;
//System.out.println("code="+Integer.toHexString(code)+", ts="+tablei_);


		if (code==CLEAR) {
if (DEBUG) System.out.println("clear");
			tablei_=tablestart_; tablelen_=(1<<MINBITS)-early_;
			if (high_) {
				int round=codelen_*8, diff=bitcnt_ % round;	// skip to next block, aligned on byte boundary
				if (diff>0) for (int i=0, imax=(round-diff)/8; i<imax; i++) in.read();
				bitcnt_ = 0;
				tablei_--;
			} else prevcode_ = -1;
			codelen_=MINBITS; mask_=(1<<codelen_)-1;
			b = read();	// don't return metacharacter

		} else if (code==eod_ || c==-1) {
if (DEBUG) System.out.println("eod");
			b = -1;
			eof_ = true;     // close has own

		} else if (tablei_ == tablelen_) {  // illegal case of operating with full table
if (DEBUG) System.out.println("full table, code="+code);
			if (code < CLEAR) b = code;
			else {  // phrase
				for (int p=code; p!=-1; p=prevEntry_[p]) phrase_[--phrasei_] = nextByte_[p];
				b = phrase_[phrasei_++] & 0xff;
			}
			// keep current table size -- don't expand, don't clear

		} else {
//System.out.println("table "+tablei_+", prev="+prevcode_+", next="+code);
			prevEntry_[tablei_] = prevcode_;

			if (code < CLEAR) {
//if (DEBUG) System.out.println("<256");
				nextByte_[tablei_] = (byte)code;
				b = code;

			} else if (code > tablei_) {    // illegal, but happens in practice: volume5/issue4/berry.pdf
//if (DEBUG) System.out.println("code "+code+" > table len "+tablei_);
				b = -1; close(); throw new java.io.StreamCorruptedException("illegal LZW code "+code+" > table len "+tablei_);   // terminate, and let caller handle

			} else { // phrase
				//assert code <= tablei_: "code "+code+" > table len "+tablei_;
				for (int p=code; p!=-1; p=prevEntry_[p]) phrase_[--phrasei_] = nextByte_[p];

				b = nextByte_[tablei_] = phrase_[phrasei_++];    // eat first byte of phrase
				if (code == tablei_) phrase_[maxlen_-1] = (byte)b;    // referred to self
				b &= 0xff;
//if (DEBUG) System.out.println("ref "+code+", next="+b+", len = "+(maxlen_-phrasei_+1));
			}

			if (prevcode_!=-1) {    // first after table clear doesn't generate table entry
				tablei_++;
				if (tablei_ == tablelen_
					&& codelen_ < maxbits_) {    // "must issue a clear-table code when the table becomes full" -- but they don't, so empirically it seems you stop building the table
					codelen_++; mask_=(1<<codelen_)-1; tablelen_=(1<<codelen_) - early_;
				}
			}
			prevcode_ = code;
		}
	}

	assert -1<=b && b<=255;
	return b;
  }


  public boolean markSupported() { return false; }  // mutates table so can't replay from backing InputStream
  public void close() throws IOException { eof_=true; super.close(); }
}
