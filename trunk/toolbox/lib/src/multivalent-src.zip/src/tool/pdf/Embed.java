package tool.pdf;

import java.io.IOException;
import java.io.File;
import java.io.PrintStream;
import java.io.ByteArrayOutputStream;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

import multivalent.ParseException;
import multivalent.std.adaptor.pdf.*;
import static multivalent.std.adaptor.pdf.COS.*;

import phelps.io.FileList;
import phelps.io.InputStreams;
import phelps.lang.Strings;
import phelps.lang.Integers;
import phelps.util.Units;



/**
	Embed embedded files and stream objects into separate files.

	@author Copyright (c) 2003  Thomas A. Phelps
	@version $Revision: 1.1 $ $Date: 2003/12/07 03:49:26 $
*/
public class Embed {
  static final boolean DEBUG = true;

  public static final String VERSION = "1.0 of $Date: 2003/12/07 03:49:26 $";
  public static final String USAGE = "java tool.pdf.Embed [options] <PDF-file...>\n"
	+ "\t[-fonts] [-images] [-streams]\n"
	+ "\t[-pool <directory>] [-max <size>]";

  //private boolean fembed_;
  private boolean ffont_, fimage_, fstream_;
  private String range_;
  private File pool_;
  private long max_;
  private String password_;
  private boolean fverbose_, fquiet_, fmonitor_;
  private PrintStream out_;



  public Embed() {
	defaults();
  }

  public void defaults() {
	//fembed_ = true;
	ffont_ = fimage_ = fstream_ = false;
	range_ = null;
	pool_ = new File(".");
	max_ = Long.MAX_VALUE;
	password_ = null;

	fverbose_ = fquiet_ = fmonitor_ = false;
	out_ = phelps.io.PrintStreams.DEVNULL;
  }

  public void setFont(boolean b) { ffont_ = b; }
  public void setImage(boolean b) { fimage_ = b; }
  public void setStream(boolean b) { fstream_ = b; }
  public void setMax(int max) { max_ = max; }
  public void setPool(File pool) { pool_ = pool; }
  public void setRange(String range) { range_ = range; }



  public void embed(File file) throws IOException, ParseException {
	String path = file.getPath();
	String pathout = (path.toLowerCase().endsWith(".pdf")? path.substring(0, path.length()-4): path) + "-em.pdf";
	embed(file, new File(pathout));
  }

  public void embed(File filein, File fileout) throws IOException, ParseException {
	if (fverbose_) System.out.println(filein);
	assert filein!=null && filein.exists();

	PDFReader pdfr = new PDFReader(filein);
	PDFWriter pdfw = new PDFWriter(fileout, pdfr);

	embed(pdfr, pdfw);

	//pdfw.setMonitor(true);
	pdfw.writePDF();
	pdfw.close();
	pdfr.close();
  }

  public void embed(PDFReader pdfr, PDFWriter pdfw) throws IOException, ParseException {
	pdfr.setPassword(password_);
	pdfw.setPassword(password_);
	if (DEBUG) pdfw.setCompress(false);

  }



  private int commandLine(String[] argv) throws UnsupportedOperationException, NumberFormatException {
	out_ = System.out;

	int argi = 0, argc = argv.length;
	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.startsWith("-max")) setMax(Integer.parseInt(argv[++argi]));
		else if (arg.startsWith("-pool") || arg.startsWith("-cache")) setPool(new File(argv[++argi]));

		else if (arg.startsWith("-page") || arg.startsWith("-range")) setRange(argv[++argi]);
		else if (arg.startsWith("-pass"/*"word"*/)) password_ = argv[++argi];

		else if (arg.startsWith("-verb")) fverbose_ = true;
		//else if (arg.startsWith("-q"/*uiet*/)) fquiet = true;
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.startsWith("-h"/*"elp"*/)) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	if (argi == argc) { System.err.println(USAGE); System.exit(0); }

	return argi;
  }

  public static void main(String[] argv) {
	Embed em = new Embed();
	int argi = 0;
	try { argi = em.commandLine(argv); } catch (Exception e) { System.err.println(e.getMessage()); System.exit(1); }

	for (Iterator<File> i = new FileList(argv, argi, FILTER).iterator(); i.hasNext(); ) {
		File file = i.next();
		try {
			//if (fquiet_) System.out.println(file);
			em.embed(file);
		} catch (Exception e) {
			System.err.println(file+": "+e);
			if (DEBUG) e.printStackTrace();
		}
	}
	System.exit(0);
  }
}
