// $Id: ParserTest.java,v 1.1 2002/04/25 18:10:38 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

class ParserTest {
    static public void main(String args[]) throws XSLException {
        ExprParser.parseStringExpr(null, args[0], new EmptyVariableSet());
    }
}
