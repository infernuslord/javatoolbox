import mypackage.*;

/**
	
	@author Pat Niemeyer (pat@pat.net)
*/
public class Test 
{
	public static void main( String [] args )
	{
		print(Accessibility2.supersfield4);
	}

	private static void print( Object o ) { System.out.println(o); }
	private static void print( long o ) { System.out.println(o); }
	private static void print( double o ) { System.out.println(o); }
	private static long time() { return System.currentTimeMillis(); }
}
