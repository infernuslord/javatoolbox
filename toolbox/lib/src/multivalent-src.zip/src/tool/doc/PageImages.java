package tool.doc;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.MalformedURLException;
import java.util.Iterator;
import java.util.Arrays;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.image.AffineTransformOp;
import java.awt.geom.Dimension2D;
import java.awt.geom.AffineTransform;
import javax.imageio.*;

import multivalent.*;
import multivalent.node.Root;
import multivalent.std.adaptor.pdf.*;

import phelps.io.FileList;
import phelps.lang.Integers;
import phelps.util.Units;
import phelps.util.Arrayss;



/**
	Convert documents into page images.
	Works with PDF.

	@version $Revision: 1.4 $ $Date: 2004/02/05 23:03:56 $
*/
public class PageImages {
  static final boolean DEBUG = !false && multivalent.Multivalent.DEVEL;

  public static final String USAGE = "java tool.PageImages [<options>] <file...>\n"
	+ "\t[-page <range>] [-thumb <pixels>] [-format <format>]";
// [-paper <size>]
  public static final String VERSION = "1.0 of $Date: 2004/02/05 23:03:56 $";


  private String range_;
  private int paperwidth_, paperheight_;
  private String format_;
  private int thumb_;
  private boolean fverbose_, fquiet_, fmonitor_;
  private PrintStream out_;

  public PageImages() {
	defaults();
  }

  public void defaults() {
	paperwidth_ = paperheight_ = -1;
	range_ = null;
	thumb_ = -1;
	setFormat(null);

	fverbose_ = fquiet_ = fmonitor_ = false;
	out_ = phelps.io.PrintStreams.DEVNULL;
  }

  public void setPaperSize(int width, int height) { paperwidth_ = width; paperheight_ = height; }

  public void setRange(String range) { range_ = range; }
  public void setThumb(int pixels) { thumb_ = pixels; }
  public void setFormat(String format) {
	format_ = format!=null? format: "PNG";
  }


  public void images(File file) throws IOException, ParseException {
	// only PDF for now  
	imagePDF(file);
  }

  private void imagePDF(File file) throws IOException, ParseException {
	// pretend we're a browser
	Browser br = Multivalent.getInstance().getBrowser("fake");
	PDF pdf = (PDF)Behavior.getInstance("AdobePDF", "AdobePDF", null, null, null);
	pdf.setFile(file);
	Root root = br.getRoot();
	Document doc = new Document("doc",null, root);
	pdf.docURI = file.toURI();

	pdf.parse(doc);	// empty parse to determine page count
	int pagecnt = Integer.parseInt(doc.getAttr(Document.ATTR_PAGECOUNT));
	doc.clear();
	int[] range = Units.parseRange(range_, 1,pagecnt);

	for (int i=0,imax=range.length; i<imax; i++) {
		int pg = range[i];
		if (pg==0) continue;
		for (int j=0; j<i; j++) if (pg == range[i]) continue;	// single copy of each page

		// build tree
		doc.putAttr(Document.ATTR_PAGE, Integer.toString(pg));
		if (!fquiet_) System.out.print(" "+pg);
		pdf.parse(doc);

		// paper size dimensions: externally set or take from formatted page
		int w = paperwidth_, h = paperheight_;
		Node top = doc.childAt(0);
		if (w==-1) {
			doc.formatBeforeAfter(200,200, null);	// PDF fixed format, so passed WxH doesn't matter
			w = top.bbox.width; h = top.bbox.height;
		}
//System.out.println("paper dimensions "+w+"x"+h);

		BufferedImage img = new BufferedImage(w,h, BufferedImage.TYPE_INT_RGB);
		Graphics2D g = img.createGraphics();
		g.setClip(0,0, w,h);

		// paint page
		g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		Context cx = doc.getStyleSheet().getContext(g, Toolkit.getDefaultToolkit(), null);
		top.paintBeforeAfter(g.getClipBounds(), cx);

		writePage(file, img, pg, pagecnt);

		// clean up
		doc.removeAllChildren();
		cx.reset();
		g.dispose(); img = null;
	}

	pdf.getReader().close();
	if (!fquiet_) System.out.println();
  }

  private void writePage(File file, BufferedImage img, int page, int pagecnt) throws IOException {
	String name = file.getName();
	int inx = name.indexOf("."); if (inx>0) name = name.substring(0,inx);	// chop suffix
	String s1=Integer.toString(page), sn=Integer.toString(pagecnt); 
	String zeros = "0000000000".substring(10-(sn.length()-s1.length()));
	name = name + "-p" + zeros + page + "." + format_.toLowerCase();
	File outfile = new File(file.getParentFile(), name);

	if (thumb_ > 10) {
		// scale by constant on x and y, by whatever is needed to get down to thumb_
		double scale = Math.max(thumb_ / (double)img.getWidth(), thumb_ / (double)img.getHeight());
		
		if (scale < 1.0) {
			AffineTransformOp aop = new AffineTransformOp(AffineTransform.getScaleInstance(scale,scale), AffineTransformOp.TYPE_NEAREST_NEIGHBOR);	// BILINEAR in JDK 1.4.1 discolors when scaling down
			img = aop.filter(img, null);
		}
	}

	ImageIO.write(img, format_, outfile);
  }



  private int commandLine(String[] argv) throws UnsupportedOperationException, NumberFormatException {
	out_ = System.out;

	int argi = 0, argc = argv.length;
	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.startsWith("-format")) {
			if (argi+1==argc || argv[argi+1].startsWith("-")) {
				String[] wr = ImageIO.getWriterFormatNames();
				Arrays.sort(wr, String.CASE_INSENSITIVE_ORDER);
				out_.println("available formats: "+Arrays.asList(wr));
				if (Arrayss.indexOf(wr, "JPEG2000")==-1) out_.println("(Install Sun's Java Advanced Imaging for more formats.)");
				System.exit(0);
			} else setFormat(argv[++argi]);

		} else if (arg.startsWith("-page") || arg.startsWith("-range")) setRange(argv[++argi]);

		else if (arg.startsWith("-thumb")) {
			try {
				setThumb(Integer.parseInt(argv[++argi]));
			} catch (NumberFormatException nfe) {
				System.err.println("can't parse "+argv[argi]+" as number");
				System.exit(1);
			}

		} else if (arg.startsWith("-paper")) {
			Dimension2D dim = Units.getPaperSize(argv[++argi], "bp");
			setPaperSize((int)dim.getWidth(), (int)dim.getHeight());
//System.out.println("paper dim "+paperwidth_+"x"+paperheight_);
		}

		else if (arg.startsWith("-verb")) fverbose_ = true;
		//else if (arg.startsWith("-q"/*uiet*/)) fquiet = true;
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.startsWith("-h"/*"elp"*/)) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	if (argi == argc) { System.err.println(USAGE); System.exit(0); }

	return argi;
  }

  public static void main(String[] argv) {
	PageImages im = new PageImages();
	int argi = 0;
	try { argi = im.commandLine(argv); } catch (Exception e) { System.err.println(e.getMessage()); System.exit(1); }

	for (Iterator<File> i = new FileList(argv, argi, null/*FILTER*/).iterator(); i.hasNext(); ) {
		File file = i.next();
		try {
			//if (fquiet_) System.out.println(file);
			im.images(file);
		} catch (Exception e) {
			System.err.println(file+": "+e);
			if (DEBUG) e.printStackTrace();
		}
	}
	System.exit(0);
  }
}
