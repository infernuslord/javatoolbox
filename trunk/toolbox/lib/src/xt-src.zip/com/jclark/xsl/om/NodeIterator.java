// $Id: NodeIterator.java,v 1.1 2002/04/25 18:13:15 bill Exp $

package com.jclark.xsl.om;

/**
 * represents a list of Nodes
 */
public interface NodeIterator 
{
    /**
     * return the next Node in the list
     */
    Node next() throws XSLException;
}
