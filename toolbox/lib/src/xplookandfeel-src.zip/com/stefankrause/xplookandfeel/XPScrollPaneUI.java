// Beta
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*	XP Look and Feel														   *
*															                   *
*  (C) Copyright 2002, by Stefan Krause, Taufik Romdhane and Contributors      *
*                                                                              *
*                                                                              *
* The XP Look and Feel started as as extension to the Metouia Look and Feel.   *
* The original header of this file was:                                        *
** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*        Metouia Look And Feel: a free pluggable look and feel for java        *
*                         http://mlf.sourceforge.net                           *
*          (C) Copyright 2002, by Taoufik Romdhane and Contributors.           *
*                                                                              *
*   This library is free software; you can redistribute it and/or modify it    *
*   under the terms of the GNU Lesser General Public License as published by   *
*   the Free Software Foundation; either version 2.1 of the License, or (at    *
*   your option) any later version.                                            *
*                                                                              *
*   This library is distributed in the hope that it will be useful,            *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of             *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                       *
*   See the GNU Lesser General Public License for more details.                *
*                                                                              *
*   You should have received a copy of the GNU General Public License along    *
*   with this program; if not, write to the Free Software Foundation, Inc.,   *
*   59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.                    *
*                                                                              *
*   Original Author:  Taoufik Romdhane                                         *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


package com.stefankrause.xplookandfeel;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JComponent;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.metal.MetalScrollBarUI;
import javax.swing.plaf.metal.MetalScrollPaneUI;

/**
 * This class represents the UI delegate for the JScrollPane component.
 *
 * @author Taoufik Romdhane
 */
public class XPScrollPaneUI extends MetalScrollPaneUI
  implements PropertyChangeListener
{

  /**
   * Creates the UI delegate for the given component.
   *
   * @param c The component to create its UI delegate.
   * @return The UI delegate for the given component.
   */
  public static ComponentUI createUI(JComponent c)
  {
    return new XPScrollPaneUI();
  }

  /**
   * Installs some default values for the given scrollpane.
   * The free standing property is disabled here.
   *
   * @param c The reference of the scrollpane to install its default values.
   */
  public void installUI(JComponent c)
  {
    super.installUI(c);

    scrollpane.getHorizontalScrollBar().putClientProperty
      (MetalScrollBarUI.FREE_STANDING_PROP, Boolean.FALSE);
    scrollpane.getVerticalScrollBar().putClientProperty
      (MetalScrollBarUI.FREE_STANDING_PROP, Boolean.FALSE);
  }

  /**
   * Creates a property change listener that does nothing inorder to prevent the
   * free standing scrollbars.
   *
   * @return An empty property change listener.
   */
  protected PropertyChangeListener createScrollBarSwapListener()
  {
    return this;
  }

  /**
   * Simply ignore any change.
   *
   * @param event The property change event.
   */
  public void propertyChange(PropertyChangeEvent event)
  {
  }
}