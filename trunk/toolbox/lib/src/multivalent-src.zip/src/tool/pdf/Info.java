package tool.pdf;

import java.util.Date;
import java.io.IOException;
import java.io.File;
import java.io.PrintStream;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Arrays;
import java.util.Collections;
import java.awt.Rectangle;

import multivalent.std.adaptor.pdf.*;
import multivalent.ParseException;
import static multivalent.std.adaptor.pdf.COS.*;
import static multivalent.std.adaptor.pdf.SecurityHandlerStandard.*;

import phelps.io.FileList;
import phelps.text.Formats;
import phelps.io.Files;



/**
	Extract various information and objects from PDFs.

	Copyright (c) 2002 - 2003  Thomas A. Phelps
	@version $Revision: 1.10 $ $Date: 2003/08/29 04:40:27 $
*/
public class Info {
  static final boolean DEBUG = true;

  public static final String VERSION = "1.1 of $Date: 2003/08/29 04:40:27 $";
  public static final String USAGE = "java tool.pdf.Info [information] [options] <PDF-file-or-directory...>\n"
	+ "\tinformation is one or more: [-general] [-image] [-anno] [-objects] [-content]\n"
	// + [-java]
	+ "\toptions: [-label] [-password <password>]";

  private static final String[] KEYS_TXT = { "Title", "Author", "Subject", "Keywords", "Creator", "Producer" };
	//"CreationDate", "ModDate", "Trapped", "Metadata"
  private static final String[] CLASS_NAMES = { "null", "iref 0 R", "<<dict>>", "[array]", "/name", "(string)", "double", "long", "boolean", "data" };

  private static final List<Class> DATA_TYPES = Collections.unmodifiableList(Arrays.asList(new Class[] { null, CLASS_IREF, CLASS_DICTIONARY, CLASS_ARRAY, CLASS_NAME, CLASS_STRING, CLASS_REAL, CLASS_INTEGER, CLASS_BOOLEAN, CLASS_DATA }));

  private static class Stat {
	int cnt = 0;
	int space = 0;
	int wasted = 0;
	int size = 0;
	int min = Integer.MAX_VALUE;
	int max = Integer.MIN_VALUE;
	// compute avg len

	public String toString() {
		String rep = "#"+cnt+", use="+space;
		if (wasted>0) rep += ", of which waste="+wasted;
		if (size>0) rep += ", min/avg/max="+min+".."+(size/cnt)+".."+max;
		return rep;
	}
  }



  private String password_;
  private boolean fgeneral_, fimage_, fanno_, fobjects_, fcontent_, fjava_, fhist_;
  private boolean flabel_;
  private File dirbase = new File(".").getAbsoluteFile();
  private boolean fverbose_, fquiet_;
  private PrintStream out_;

  private String label_ = null;

  public Info() {
	defaults();
  }

  public void defaults() {
	password_ = null;
	fgeneral_ = fimage_ = fanno_ = fobjects_ = fcontent_ = fjava_ = fhist_ = false;
	flabel_ = false;

	fverbose_ = fquiet_ = false;
	out_ = phelps.io.PrintStreams.DEVNULL;
  }

  public void setOut(PrintStream out) { out_ = out!=null? out: phelps.io.PrintStreams.DEVNULL; }



  private void out(String txt) {
	if (flabel_) out_.print(label_);
	if (txt!=null) out_.print(txt);
  }
  private void outln(String txt) {
	out(txt);
	out_.println();
  }

  public void info(File file) throws IOException, ParseException {
	assert file!=null;
	if (flabel_) label_ = Files.relative(dirbase, file) + ": ";
	if (!fgeneral_ && !fimage_ && !fanno_) fgeneral_ = true;

	PDFReader pdfr = new PDFReader(file);
	pdfr.setPassword(password_);
	pdfr.setExact(true);    // don't zap "/Type"

	if (fgeneral_) general(pdfr);

	pdfr.fault();
	if (fimage_) image(pdfr);
	if (fanno_) anno(pdfr);
	if (fobjects_) objects(pdfr);
	if (fcontent_) content(pdfr);
	if (fjava_) profileJava(pdfr);

	pdfr.close();
  }

  /**
	Extract various information from /Catalog and /Info dictionaries.
  */
  void general(PDFReader pdfr) throws IOException {
	Dict trailer = pdfr.getTrailer();
	Dict cat = pdfr.getCatalog();    // could have followed link from trailer

	Dict info = (Dict)pdfr.getInfo();
	if (info!=null) {
		Object val;
		for (int i=0,imax=KEYS_TXT.length; i<imax; i++) {
			String key = KEYS_TXT[i];
			val = pdfr.getObject(info.get(key));
			if (val != null) outln(key+": "+val);
		}

		long create=-1L, mod;
		if ((val = pdfr.getObject(info.get("CreationDate"))) != null) {
			try {
				create = parseDate((StringBuffer)val, false);
				outln("Created: "+new Date(create));
			} catch (InstantiationException ignore) {}
		}
		if ((val = pdfr.getObject(info.get("ModDate"))) != null) {
			try {
				mod = parseDate((StringBuffer)val, false);
				if (mod != create) outln("Modified: "+new Date(mod));
			} catch (InstantiationException ignore) {}
		}
	}

	outln("Page count: "+pdfr.getPageCnt());
	outln("PDF version: "+pdfr.getMajorVersion()+"."+pdfr.getMinorVersion());   // updated by /Catalog's /Version

	if (cat.get("Outlines")!=null) outln("outline");
	if (cat.get("Metadata")!=null) outln("metadata");
	if (cat.get("StructTreeRoot")!=null) outln("structured");
	if (cat.get("SpiderInfo")!=null) outln("converted from HTML");
	if (cat.get("AcroForm")!=null) outln("forms");
	//if () outln("linearized");

	if (pdfr.getLinearized()>0) {
		Dict dict = (Dict)pdfr.getObject(pdfr.getLinearized());
		outln("Linearized: version "+dict.get("Linearized"));
	}

	multivalent.std.adaptor.pdf.Encrypt e = pdfr.getEncrypt();
	//CryptFilter cf = e.getStrF();
	Dict edict = (Dict)pdfr.getObject(trailer.get("Encrypt"));
	SecurityHandler sh = e.getSecurityHandler();
	//if (cf!=CryptFilter.IDENTITY) {
	if (sh != SecurityHandler.IDENTITY) {
		out("Encrypted: filter ");
		if (sh instanceof SecurityHandlerStandard) {
			SecurityHandlerStandard shs = (SecurityHandlerStandard)sh;
			int R=shs.getR(), P=shs.getP();
			outln("Standard (revision "+R+"), "+shs.getLength()+"-bit key" + (sh.isAuthorized()? ", null password": ""));

			if ((PERM_ALL & P) != PERM_ALL) {
				out("    restrictions:");
				if ((PERM_PRINT & P) == 0) out_.print("  print");
				if ((PERM_MODIFY & P) == 0) out_.print("  modify");
				if ((PERM_COPY & P) == 0) out_.print("  copy/extract");
				if ((PERM_ANNO & P) == 0) out_.print("  annotate");
				if (R<3 || (PERM_FILL & P) == 0) out_.print("  fill forms");
				if (R<3 || (PERM_COPY_R3 & P) == 0) out_.print("  accessibility");
				if (R<3 || (PERM_ASSEMBLE & P) == 0) out_.print("  assemble");
				if (R>=3 && (PERM_PRINT_GOOD & P) == 0) out_.print("  high-quality print");
				out_.println();
			}

		} else {
			//Dict edict = e.toDictionary();
			outln(edict.get("Filter")+", " + (sh.isAuthorized()? ", null password": ""));
		}
	}

	Dict comp = (Dict)trailer.get(KEY_COMPRESS);
	if (comp!=null) {
		StringBuffer sb = new StringBuffer(80);
		sb.append("Compressed:");
		Number oldlen = (Number)comp.get(KEY_COMPRESS_LENGTHO);
		if (oldlen != null) {
			int newlen = (int)pdfr.getFile().length();
			sb.append(" ").append((oldlen.intValue() - newlen) * 100 / oldlen.intValue()).append("%");
		}
		Object o;;
		if ((o = comp.get(KEY_COMPRESS_FILTER))!=null) sb.append(", ").append(o).append(" format");
		if ((o = comp.get(KEY_COMPRESS_VERSION)) != null) sb.append(" v").append(o);
		if ((o = comp.get("Producer")) !=null) sb.append(", by ").append(o);
		outln(sb.toString());
	}

	String xml = pdfr.getMetadata(cat);
	if (xml.length()>0) outln(xml);
  }

  /**
	Scan all objects looking for Image XObjects.
  */
  void image(PDFReader pdfr) throws IOException {
	for (int i=0,imax=pdfr.getObjCnt(); i<imax; i++) {
		Object o = pdfr.getObject(i);
		if (CLASS_DICTIONARY != o.getClass()) continue;
		Dict dict = (Dict)o;
		Object type = pdfr.getObject(dict.get("Type")), subtype = pdfr.getObject(dict.get("Subtype"));
		if (("XObject".equals(type) || type==null) && "Image".equals(subtype)) {
			out("image: object "+i+", "+pdfr.getObject(dict.get("Width"))+"x"+pdfr.getObject(dict.get("Height")));
			String filter = Images.getFilter(dict, pdfr);
			out_.print(", "+(filter!=null? filter: "raw samples"));
			out_.println(", length = "+pdfr.getObject(dict.get("Length")));
		}
	}
  }

  /**
	Iterate over pages for annotations.
  */
  void anno(PDFReader pdfr) throws IOException, ParseException {
	for (int i=0,imax=pdfr.getPageCnt(); i<imax; i++) {
		Dict page = (Dict)pdfr.getObject(pdfr.getPageRef(i+1));

		Object[] anno = (Object[])pdfr.getObject(page.get("Annots"));
		if (anno == null) continue;

		for (int j=0,jmax=anno.length; j<jmax; j++) {
			out("anno: page "+(i+1)+", ");
			Object o = anno[j];
			if (CLASS_IREF == o.getClass()) out_.print("object "+((IRef)o).id+", ");
			Dict dict = (Dict)pdfr.getObject(anno[j]);
			Object subtype = pdfr.getObject(dict.get("Subtype"));
			out_.print(subtype);
			o = pdfr.getObject(dict.get("Rect"));
			if (o!=null) out_.print(", bounds "+Formats.pretty(array2Rectangle((Object[])o, null, false)));
			//if ("Link".equals(subtype)) { // show destination of link
			out_.println();
		}
	}
  }

  void objects(PDFReader pdfr) throws IOException {
	int objcnt = pdfr.getObjCnt();
	int fontcnt=0, t1fontcnt=0, ttfontcnt=0, t3fontcnt=0, ofontcnt=0, emfontcnt=0;
	int imgcnt=0, formcnt=0, pscnt=0;
	int thumbcnt=0;
	int annocnt=0, linkcnt=0;
	List<Object> fonts = new ArrayList<Object>(20);

	// count fonts, images, annotations, ...
	for (int i=1; i<objcnt; i++) {
		Object o = pdfr.getObject(i);

		if (o!=null && o.getClass() == CLASS_DICTIONARY) {
			Dict dict = (Dict)o;
			String type=(String)dict.get("Type"), subtype=(String)dict.get("Subtype");
			if ("Font".equals(type)) {
				fontcnt++;
				fonts.add(dict.get("BaseFont"));
				if ("Type1".equals(subtype)) t1fontcnt++;
				else if ("TrueType".equals(subtype)) ttfontcnt++;
				else if ("Type3".equals(subtype)) t3fontcnt++;
				else ofontcnt++;

			} if ("FontDescriptor".equals(type)) {
				if (dict.get("FontFile")!=null || dict.get("FontFile2")!=null || dict.get("FontFile3")!=null) emfontcnt++;

			} else if ("XObject".equals(type)) {
				if ("Image".equals(subtype)) imgcnt++;
				else if ("Form".equals(subtype)) formcnt++;

			} else if ("Page".equals(type)) {
				if (dict.get("Thumb")!=null) thumbcnt++;
			} else if ("Annot".equals(type)) {
				annocnt++;
				if ("Link".equals(subtype)) linkcnt++;
			}
		}
	}

	// count characters and words
	// case 'Tj': case 'TJ': case '\'': case '"': ...


	// report
	System.out.println(objcnt+" objects");
	if (fontcnt>0) {
		System.out.print("\t"+fontcnt+" fonts:  ");
		if (t1fontcnt>0) System.out.print(t1fontcnt+" Type 1   ");
		if (ttfontcnt>0) System.out.print(ttfontcnt+" TrueType   ");
		if (t3fontcnt>0) System.out.print(t3fontcnt+" Type 3   ");
		if (emfontcnt>0) System.out.print(emfontcnt+" embedded   ");
		System.out.print(fonts);
		System.out.println();
	}
	if (imgcnt>0) System.out.println(imgcnt+" images");
	if (formcnt>0) System.out.println(formcnt+" forms");
	if (thumbcnt>0) System.out.println(thumbcnt+" thumbnails");
	if (annocnt>0) {
		System.out.print("\t"+annocnt+" annotations:   ");
		if (linkcnt>0) System.out.print(linkcnt+" hyperlinks   ");
		System.out.println();
	}
  }

  void content(PDFReader pdfr) throws IOException {
	// counts of command usage
	Object[] oa1 = new Object[1];

	Map<String,Stat> counts = new HashMap<String,Stat>(150);
	for (int i=0,imax=pdfr.getPageCnt(); i<imax; i++) {
		//if (!Quiet) System.out.print(i+" ");  // pretty quick

		Dict pagedict = (Dict)pdfr.getObject(pdfr.getPageRef(i+1));
		InputStreamComposite in = pdfr.getInputStream(pagedict.get("Contents"), true);

		StringBuffer sb = new StringBuffer(4*1024);
		for (int c; (c=in.peek())!=-1; ) {
			if (!Character.isLetter((char)c) && c!='\'' && c!='"') {     // OPERAND
				//ops[opsi++] =
				pdfr.readObject(in);

			} else {    // OPERATOR
				String op = (String)pdfr.readObject(in);

				// add to count -- well, there are worse ways
				Stat stat = (Stat)counts.get(op);
				if (stat==null) counts.put(op, new Stat());
				else stat.cnt++;
			}
		}
		in.close();
	}

	System.out.println("Content streams command usage:");
	for (Iterator<Map.Entry<String,Stat>> hi=counts.entrySet().iterator(); hi.hasNext(); ) {
		Map.Entry<String,Stat> e = hi.next();
		String cmd=e.getKey();
		int cnt = e.getValue().cnt;
		System.out.print(cmd+" "+cnt+"   ");
	}
	System.out.println();
  }

  void profileJava(PDFReader pdfr) throws IOException {
	Stat[] stats = new Stat[DATA_TYPES.size()];
	for (int i=0,imax=DATA_TYPES.size(); i<imax; i++) stats[i] = new Stat();
	int objcnt = pdfr.getObjCnt();
	profileJava(pdfr.getTrailer(), stats, new boolean[objcnt]);
//System.out.println("trailer = "+pdfr.getTrailer());

	// report
	for (int i=0,imax=DATA_TYPES.size(); i<imax; i++) {
		System.out.println(CLASS_NAMES[i]+" "+stats[i]);
	}
  }

  protected void profileJava(Object o, Stat[] stats, boolean[] seen) throws IOException {
	Class cl = (o!=null? o.getClass(): null);
	int inx = DATA_TYPES.indexOf(cl);
	Stat stat = stats[inx];
	stat.cnt++;
	stat.space += 4;    // handle to object

	if (CLASS_IREF == cl) {    // only way to reference!
		stat.space += 4*2;
		stat.wasted += 4;   // gen
		// none wasted, size/min/max n/a

		int id = ((IRef)o).id;
		if (!seen[id]) {   // don't cycle
			seen[id] = true;
			//RESTORE: profileJava(pdfr_.getObject(id), stats, seen);
		}

	} else if (CLASS_ARRAY == cl) {     // array
		Object[] oa = (Object[])o;

		int len = oa.length;
		stat.space += len*4 + 4/*length "field"*/;
		// none wasted
		stat.size += len; stat.min=Math.min(stat.min, len); stat.max=Math.max(stat.max, len);

		for (int i=0,imax=oa.length; i<imax; i++) profileJava(oa[i], stats, seen);

	} else if (CLASS_DICTIONARY == cl) {  // dictionary
		Dict omap = (Dict)o;

		int cap=16, size=omap.size(); while (cap*0.75<size) cap <<= 1;
		stat.space += (4*5/*fields*/) + omap.size() * (4+ 4*4/*Map.Entry = key,val,hash,next*/ + 4*cap/*table length*/);
		stat.wasted += (cap-size)*3;    // *4 bytes * .75 load capacity min
		stat.size += size; stat.min=Math.min(stat.min, size); stat.max=Math.max(stat.max, size);

		for (Iterator<Map.Entry<Object,Object>> i=omap.entrySet().iterator(); i.hasNext(); ) {
			Map.Entry<Object,Object> e = i.next();
			// if (e.getKey()==STREAM_DATA)
			profileJava(e.getValue(), stats, seen);
		}

	} else if (CLASS_NAME == cl) {
		String oname = (String)o;
		int len = oname.length();
		stat.space += len*2 + 4*4/*fields*/; // char[] = 2 bytes per
		stat.size += len; stat.min=Math.min(stat.min, len); stat.max=Math.max(stat.max, len);

	} else if (CLASS_STRING == cl) {
		StringBuffer sb = (StringBuffer)o;
		int cap=sb.capacity(), len=sb.length();
		stat.space += cap*2 + 4*3/*fields*/;
		stat.wasted += (cap-len)*2;
		stat.size += len; stat.min=Math.min(stat.min, len); stat.max=Math.max(stat.max, len);

	} else if (CLASS_REAL == cl) stat.space += 8;
	else if (CLASS_INTEGER == cl) stat.space += 4;
	else if (CLASS_BOOLEAN == cl) stat.space += 4;  // assume aligned

  }


  /**
	Various histograms.  Experimental.
  */
  void hist(PDFReader pdfr) throws IOException {
	for (int i=1,imax=pdfr.getObjCnt(); i<imax; i++) {
		Object o = pdfr.getObject(i);

//System.out.println(1+" "+o);
		// color usage in images from raw samples (non-JPEG, non-FAX, non-JBIG2)
		if (o.getClass() == CLASS_DICTIONARY && "Image".equals(pdfr.getObject(((Dict)o).get("Subtype")))) {
			Dict dict = (Dict)o;
			System.out.print(i+"  "+dict.get("Width")+"x"+dict.get("Height")+", "+dict.get("ColorSpace")+":  ");

			int bpc = ((Number)dict.get("BitsPerComponent")).intValue();
			if (bpc==8) {
				int[] h = new int[256];
				InputStream in = pdfr.getInputStream(dict); for (int c; (c=in.read())!=-1; ) h[c]++; in.close();
				int hcnt = 0; for (int j=0,jmax=h.length; j<jmax; j++) if (h[j]>0) hcnt++;
				Arrays.sort(h);

				//for (int j=0,jmax=h.length; j<imax; j++) if (h[j]>0) System.out.print(Integer.toHexString(j)+"="+h[j]+" ");
				System.out.print("("+hcnt+")  ");
				for (int j=255,jmin=240; j>=jmin; j--) System.out.print(" "+h[j]);
				System.out.println();

			} else System.out.println("bpc = "+bpc);
		}
	}

  }



  private int commandLine(String[] argv) {
	out_ = System.out;

	int argi = 0, argc = argv.length;
	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.startsWith("-gen"/*"eral"*/)) fgeneral_ = true;
		else if (arg.startsWith("-im"/*"age"*/)) fimage_ = true;
		else if (arg.startsWith("-anno")) fanno_ = true;
		else if (arg.startsWith("-obj"/*ects*/)) fobjects_ = true;
		else if (arg.startsWith("-con"/*tent*/)) fcontent_ = true;
		else if (arg.startsWith("-prof"/*file*/) || arg.startsWith("-java")) fjava_ = true;
 
		else if (arg.startsWith("-l")) flabel_ = true;
		else if (arg.equals("-password")) password_ = argv[++argi];

		else if (arg.startsWith("-verb")) fverbose_ = true;
		else if (arg.startsWith("-q"/*uiet*/)) fquiet_ = true;
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.equals("-help")) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	if (argi == argc) { System.err.println(USAGE); System.exit(0); }

	return argi;
  }

  public static void main(String[] argv) throws IOException {
	Info info = new Info();
	int argi = info.commandLine(argv);

	for (Iterator<File> i = new FileList(argv, argi, FILTER).iterator(); i.hasNext(); ) {
		File file = i.next();
		if (!info.flabel_) info.outln("Filename: "+file);
		try {
			info.info(file);
		} catch (Exception ioe) {
			System.err.println(file+": "+ioe);
			if (DEBUG) ioe.printStackTrace();
		}
	}
  }
}
