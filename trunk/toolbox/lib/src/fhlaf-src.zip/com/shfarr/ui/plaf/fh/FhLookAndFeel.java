/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh;

import javax.swing.filechooser.FileSystemView;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;
import javax.swing.plaf.InsetsUIResource;
import javax.swing.plaf.UIResource;
import javax.swing.plaf.metal.*;
import javax.swing.*;
import java.awt.*;
import java.net.URL;
import java.util.Enumeration;
import java.util.Iterator;

import com.shfarr.ui.*;
import com.shfarr.ui.plaf.fh.borders.FhComboBoxBorder;
import com.shfarr.ui.plaf.fh.ext.*;
import com.shfarr.ui.plaf.fh.theme.*;

public class FhLookAndFeel extends MetalLookAndFeel{
	public FhLookAndFeel(){
		super();
        FileSystemView.getFileSystemView().toString();
	}
	
	public UIDefaults getDefaults(){
	  UIDefaults table = new FhUIDefaults();
	  
	  initClassDefaults(table);
	
	  return table;
	}
	
	
	public String getDescription(){
	  return "Fh Look And Feel";
	}
	
	
	public String getID(){
	  return "Fh";
	}
	
	
	public String getName(){
	  return "Fh";
	}
	
    protected void initClassDefaults(UIDefaults table){
	  super.initClassDefaults(table);

      initComponentDefaults(table);

	  Object[] uiDefaults ={
          "InternalFrameUI", FhInternalFrameUI.class.getName(),
          "LabelUI", FhLabelUI.class.getName(),
          "DesktopPaneUI", FhDesktopPaneUI.class.getName(),
          "DesktopIconUI", FhDesktopIconUI.class.getName(),
          "TableUI", FhTableUI.class.getName(),
          "TableHeaderUI", FhTableHeaderUI.class.getName(),
          "MenuItemUI", FhMenuItemUI.class.getName(),
          "CheckBoxMenuItemUI", FhCheckBoxMenuItemUI.class.getName(),
          "RadioButtonMenuItemUI", FhRadioButtonMenuItemUI.class.getName(),
          "MenuUI", FhMenuUI.class.getName(),
          "MenuBarUI", FhMenuBarUI.class.getName(),
          "PopupMenuUI", FhPopupMenuUI.class.getName(),
          "SeparatorUI", FhSeparatorUI.class.getName(),
          "ButtonUI", FhButtonUI.class.getName(),
          "SysButtonUI", FhSysButtonUI.class.getName(),
          "ToggleButtonUI", FhToggleButtonUI.class.getName(),
          "CheckBoxUI", FhCheckBoxUI.class.getName(),
          "RadioButtonUI", FhRadioButtonUI.class.getName(),
          "OptionPaneUI", FhOptionPaneUI.class.getName(),
          "FileChooserUI", FhFileChooserUI.class.getName(),
          "SplitPaneUI", FhSplitPaneUI.class.getName(),
          "ToolBarUI", FhToolBarUI.class.getName(),
          "ToolBarSeparatorUI", FhSeparatorUI.class.getName(),
          "ProgressBarUI", FhProgressBarUI.class.getName(),
          "TextFieldUI", FhTextFieldUI.class.getName(),
          "FormattedTextFieldUI", FhTextFieldUI.class.getName(),
          "PasswordFieldUI", FhPasswordFieldUI.class.getName(),
          "ComboBoxUI", FhComboBoxUI.class.getName(),
          "SpinnerUI", FhSpinnerUI.class.getName(),
          "SliderUI", FhSliderUI.class.getName(),
          "TreeUI", FhTreeUI.class.getName(),
          "ToolTipUI", FhToolTiplUI.class.getName(),
          "PanelUI", FhPanelUI.class.getName(),
          "WizardUI", FhPanelUI.class.getName(),
          "ScrollBarUI", FhScrollBarUI.class.getName(),
          "TabbedPaneUI", FhTabbedPaneUI.class.getName(),
          "RootPaneUI", FhRootPaneUI.class.getName(),
          "ScrollPaneUI", FhScrollPaneUI.class.getName(),
          "ComboPopupUI", FhPopupMenuUI.class.getName(),
          //"ListUI", FhTableUI.class.getName(),

	      "ToolTip.border", getCurrentTheme().getBorder("ToolTip"),
          "DesktopIcon.border", getCurrentTheme().getBorder("DesktopIcon"),
	      "InternalFrame.border", getCurrentTheme().getBorder("InternalFrame"),
          "InternalFrame.titleBorder", getCurrentTheme().getBorder("InternalFrame.title"),
          "DesktopIcon.border", getCurrentTheme().getBorder("InternalFrame.icon"),
          "List.focusCellHighlightBorder", getCurrentTheme().getBorder("ListCell.focus"),
          "Table.focusCellHighlightBorder", getCurrentTheme().getBorder("ListCell.focus"),
          "TableHeader.cellBorder", getCurrentTheme().getBorder("TableHeader.cell"),
          "MenuItem.border", getCurrentTheme().getBorder("MenuItem", new String[]{"normal", "armed", "pressed"}),
          "CheckBoxMenuItem.border", getCurrentTheme().getBorder("MenuItem", new String[]{"normal", "armed", "pressed"}),
          "RadioButtonMenuItem.border", getCurrentTheme().getBorder("MenuItem", new String[]{"normal", "armed", "pressed"}),
          "MenuBar.border", getCurrentTheme().getBorder("MenuBar"),
          "Menu.border", getCurrentTheme().getBorder("Menu", new String[]{"normal", "armed", "pressed"}),
          "SysButton.border", getCurrentTheme().getBorder("SysButton", new String[]{"normal", "armed", "pressed"}),
          "PopupMenu.border", getCurrentTheme().getBorder("PopupMenu"),
          "ToggleButton.border", getCurrentTheme().getBorder("Button", new String[]{"normal", "armed", "focused", "focused.armed", "default", "pressed", "rollover", "rollover.armed", "rollover.pressed"}),
          "CheckBox.border", getCurrentTheme().getBorder("CheckBox"),
          "Button.border", getCurrentTheme().getBorder("Button", new String[]{"normal", "armed", "focused", "focused.armed", "default", "pressed", "rollover", "rollover.armed", "rollover.pressed"}),
          "RadioButton.border", getCurrentTheme().getBorder("RadioButton"),
          "OptionPane.border", getCurrentTheme().getBorder("OptionPane"),
          "SplitPane.border", getCurrentTheme().getBorder("SplitPane"),
          "ToolBar.border", getCurrentTheme().getBorder("ToolBar", new String[]{"normal", "vertical"}),
          "TextArea.border", getCurrentTheme().getBorder("TextArea"),
          "TextPane.border", getCurrentTheme().getBorder("TextPane"),
          "EditorPane.border", getCurrentTheme().getBorder("EditorPane"),
          "ComboBox.border", new FhComboBoxBorder(getCurrentTheme().getBorder("ComboBox")),
          "ComboBox.popupBorder", getCurrentTheme().getBorder("ComboBox.popup"),
          "ComboPopup.border", getCurrentTheme().getBorder("ComboBox.popup"),
          "TextField.border", getCurrentTheme().getBorder("TextField", new String[]{"normal", "inactive"}),
          "FormattedTextField.border", getCurrentTheme().getBorder("TextField", new String[]{"normal", "inactive"}),
          "PasswordField.border", getCurrentTheme().getBorder("TextField", new String[]{"normal", "inactive"}),
          "Spinner.border", getCurrentTheme().getBorder("Spinner"),
          "Slider.border", getCurrentTheme().getBorder("Slider"),
          "Slider.trackBorder", getCurrentTheme().getBorder("Slider.track"),
          "Slider.thumbBorder", getCurrentTheme().getBorder("Slider.thumb"),
          "ScrollPane.border", getCurrentTheme().getBorder("ScrollPane"),
          "Table.scrollPaneBorder", getCurrentTheme().getBorder("ScrollPane"),
          "ScrollBar.thumbBorder", getCurrentTheme().getBorder("ScrollBar", new String[]{"thumb", "thumb.selected"}),
          "TabbedPane.border", getCurrentTheme().getBorder("TabbedPane"),
          "TabbedPane.contentBorder", getCurrentTheme().getBorder("TabbedPane.content"),

          "TabbedPane.tabTop", getCurrentTheme().getBorder("Tab.top", new String[]{"normal", "selected", "focused"}),
          "TabbedPane.tabLeft", getCurrentTheme().getBorder("Tab.left", new String[]{"normal", "selected", "focused"}),
          "TabbedPane.tabRight", getCurrentTheme().getBorder("Tab.right", new String[]{"normal", "selected", "focused"}),
          "TabbedPane.tabBottom", getCurrentTheme().getBorder("Tab.bottom", new String[]{"normal", "selected", "focused"}),

          "ProgressBar.border", getCurrentTheme().getBorder("ProgressBar"),
          "OptionPane.sideIconBorder",  getCurrentTheme().getBorder("OptionPane.icon"),
          "OptionPane.separatorBorder",  getCurrentTheme().getBorder("OptionPane.separator"),
          "SplitPaneDivider.border", getCurrentTheme().getBorder("SplitPaneDivider"),
          "Tree.selectionBorderColor", new ColorUIResource(ThemeManager.instance().getCurrentTheme().getColor("selection.background").darker()),
          "Tree.editorBorder", getCurrentTheme().getBorder("ListCell.editor"),
          "Touch.border", getCurrentTheme().getBorder("Touch"),
          "Separator.border", getCurrentTheme().getBorder("Separator"),
          "Desktop.iconBorder",  getCurrentTheme().getBorder("DesktopIcon"),

          "ToolTip.font", new FontUIResource(getCurrentTheme().getFont("dialog font")),
          "DesktopIcon.font", new FontUIResource(getCurrentTheme().getFont("button font")),
          "InternalFrame.titleFont", new FontUIResource(getCurrentTheme().getFont("title font")),
          "List.font", new FontUIResource(getCurrentTheme().getFont("cell font")),
          "TableHeader.font", new FontUIResource(getCurrentTheme().getFont("header font")),
          "MenuItem.font", new FontUIResource(getCurrentTheme().getFont("menu font")),
          "CheckBoxMenuItem.font", new FontUIResource(getCurrentTheme().getFont("menu font")),
          "RadioButtonMenuItem.font", new FontUIResource(getCurrentTheme().getFont("menu font")),
          "MenuBar.font", new FontUIResource(getCurrentTheme().getFont("menu font")),
          "Menu.font", new FontUIResource(getCurrentTheme().getFont("menu font")),
          "SysButton.font", new FontUIResource(getCurrentTheme().getFont("button font")),
          "PopupMenu.font", new FontUIResource(getCurrentTheme().getFont("menu font")),
          "ToggleButton.font", new FontUIResource(getCurrentTheme().getFont("button font")),
          "CheckBox.font", new FontUIResource(getCurrentTheme().getFont("decoration font")),
          "Button.font", new FontUIResource(getCurrentTheme().getFont("button font")),
          "RadioButton.font", new FontUIResource(getCurrentTheme().getFont("decoration font")),
          "OptionPane.font", new FontUIResource(getCurrentTheme().getFont("dialog font")),
          "OptionPane.messageFont", new FontUIResource(getCurrentTheme().getFont("dialog font")),
          "SplitPane.font", new FontUIResource(getCurrentTheme().getFont("decoration font")),
          "ToolBar.font", new FontUIResource(getCurrentTheme().getFont("button font")),
          "TextArea.font", new FontUIResource(getCurrentTheme().getFont("monospaced font")),
          "TextPane.font", new FontUIResource(getCurrentTheme().getFont("text font")),
          "EditorPane.font", new FontUIResource(getCurrentTheme().getFont("text font")),
          "ComboBox.font", new FontUIResource(getCurrentTheme().getFont("text font")),
          "TextField.font", new FontUIResource(getCurrentTheme().getFont("text font")),
          "FormattedTextField.font", new FontUIResource(getCurrentTheme().getFont("text font")),
          "PasswordField.font", new FontUIResource(getCurrentTheme().getFont("text font")),
          "Spinner.font", new FontUIResource(getCurrentTheme().getFont("text font")),
          "Slider.font", new FontUIResource(getCurrentTheme().getFont("decoration font")),
          "TabbedPane.font", new FontUIResource(getCurrentTheme().getFont("decoration font")),
          "TabbedPane.tabFont", new FontUIResource(getCurrentTheme().getFont("decoration font")),
          "Label.font", new FontUIResource(getCurrentTheme().getFont("decoration font")),
          "ProgressBar.font", new FontUIResource(getCurrentTheme().getFont("dialog font")),
          "Tree.font", new FontUIResource(getCurrentTheme().getFont("cell font")),

          "CheckBox.icon", new FhSysIcon(FhSysIcon.CHECK_BOX),
          "RadioButton.icon", new FhSysIcon(FhSysIcon.RADIO_BUTTON),
          "OptionPane.errorIcon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/error.png")),
          "OptionPane.informationIcon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/inform.png")),
          "OptionPane.warningIcon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/warn.png")),
          "OptionPane.questionIcon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/question.png")),
	      "InternalFrame.icon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/internalFrameIcon.png")),
          "CheckBoxMenuItem.checkIcon", new FhSysIcon(FhSysIcon.CHECK_BOX_MENU_ITEM),
          "RadioButtonMenuItem.checkIcon", new FhSysIcon(FhSysIcon.RADIO_BUTTON_MENU_ITEM),
          "Tree.openIcon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/treeOpened.png")),
          "Tree.closedIcon", new UIResourceImageIcon (getCurrentTheme().getResourceURL("icons/treeClosed.png")),
          "Tree.leafIcon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/treeLeaf.png")),
          "Tree.expandedIcon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/less.png")),
          "Tree.collapsedIcon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/more.png")),
          "Menu.arrowIcon", new FhSysIcon(FhSysIcon.ARROW),
          "CheckBox.selectedIcon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/checkBoxSelected.png")),
          "CheckBox.unselectedIcon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/checkBoxUnselected.png")),
          "RadioButton.selectedIcon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/radioButtonSelected.png")),
          "RadioButton.unselectedIcon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/radioButtonUnselected.png")),
          "CheckBoxMenuItem.selectedIcon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/checkBoxMenuItemSelected.png")),
          "CheckBoxMenuItem.unselectedIcon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/checkBoxMenuItemUnselected.png")),
          "RadioButtonMenuItem.selectedIcon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/radioButtonMenuItemSelected.png")),
          "RadioButtonMenuItem.unselectedIcon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/radioButtonMenuItemUnselected.png")),
          "FileView.directoryIcon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/treeClosed.png")),
          "FileView.fileIcon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/treeLeaf.png")),
          "FileView.floppyDriveIcon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/disk.png")),
          "FileChooser.newFolderIcon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/newFolder.png")),
          "FileChooser.upFolderIcon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/parentFolder.png")),
          "FileChooser.homeFolderIcon", new UIResourceImageIcon(getCurrentTheme().getResourceURL("icons/homeFolder.png")),

          "ToolTip.background", table.get("Component.absoluteHighlight"),
          "Viewport.background", table.get("Component.darkBackground"),
          "List.focusCellBackground", table.get("EditableComponent.focusSelectionBackground"),
          "Table.focusCellBackground", table.get("EditableComponent.focusSelectionBackground"),
          "TableHeader.cellBackground", table.get("Component.background"),
          "TableHeader.background", table.get("Component.darkBackground"),
          "MenuItem.background", table.get("Menu.background"),
          "CheckBoxMenuItem.background", table.get("Menu.background"),
          "RadioButtonMenuItem.background", table.get("Menu.background"),
          "Menu.background", table.get("Menu.background"),
          "MenuBar.background", table.get("Menu.background"),
          "PopupMenu.background", table.get("Menu.background"),
          "Separator.background", table.get("Menu.background"),
          "Button.background", table.get("Component.background"),
          "Button.backgroundPressed", table.get("Component.pressedBackground"),
          "SysButton.background", table.get("Component.background"),
          "SysButton.backgroundPressed", table.get("Component.pressedBackground"),
          "ToggleButton.background", table.get("Component.background"),
          "ToggleButton.backgroundPressed", table.get("Component.pressedBackground"),
          "OptionPane.sideIconBackground", table.get("Component.lightHighlight"),
          "Wizard.background", table.get("Component.absoluteHighlight"),
          "OptionPane.separatorBackground", table.get("Component.background"),
          "ProgressBar.background", table.get("EditableComponent.background"),
          "ProgressBar.selectionBackground", table.get("EditableComponent.selectionForeground"),
          "ComboBox.background", table.get("Menu.background"),
          "ComboBox.popupBackground", table.get("Component.darkBackground"),
          "ComboBox.buttonBackground", table.get("Component.background"),
          "Spinner.background", table.get("Component.background"),
          "Spinner.buttonBackground", table.get("Component.background"),
          "Tree.textBackground", table.get("EditableComponent.background"),
          "Desktop.background", table.get("Component.darkBackground"),
          "ScrollPane.background", table.get("Component.darkBackground"),
          "TabbedPane.background", table.get("Component.background"),
          "TabbedPane.tabAreaBackground", table.get("Component.deepHighlight"),
          "TabbedPane.unselectedBackground", table.get("Component.deepHighlight"),
          "TabbedPane.selectedBackground", table.get("Component.background"),
          "Panel.background", table.get("Component.background"),
          "RootPane.background", table.get("Component.background"),
          
          "Table.focusCellForeground", table.get("EditableComponent.focusSelectionForeground"),
          "List.focusCellForeground", table.get("EditableComponent.focusSelectionForeground"),
          "Table.focusCellForeground", table.get("EditableComponent.focusSelectionForeground"),
          "Table.gridColor", table.get("Grid.foreground"),
          "OptionPane.messageForeground", table.get("Component.foreground"),
          "ProgressBar.foreground", table.get("EditableComponent.selectionBackground"),
          "Tree.textForeground", table.get("EditableComponent.foreground"),

          "ScrollBar.highlight", table.get("highlight"),
          "Slider.highlight", table.get("Component.absoluteHighlight"),
          "Slider.shadow", table.get("Component.deepShadow"),

          "MenuItem.margin", new Insets(1, 1, 1, 1),
          "CheckBoxMenuItem.margin", new Insets(1, 1, 1, 1),
          "RadioButtonMenuItem.margin", new Insets(1, 1, 1, 1),
          "Menu.margin", new Insets(0, 0, 0, 0),
          "Button.margin", new InsetsUIResource(2, 14, 2, 14),
          "TextField.margin", new Insets(0, 0, 0, 0),
          "FormattedTextField.margin", new Insets(0, 0, 0, 0),
          "PasswordField.margin", new Insets(0, 0, 0, 0),
          "TextArea.margin", new Insets(0, 0, 0, 0),
          "TextPane.margin", new Insets(0, 0, 0, 0),
          "EditorPane.margin", new Insets(0, 0, 0, 0),
          "SysButton.margin", new InsetsUIResource(2, 14, 2, 14),

          "PopupMenu.gap", new Integer(1),
          "SysButton.textIconGap", new Integer(4),

          "ScrollBar.minimumThumbSize", new Dimension(9, 9),

          "TabbedPane.tabLabelShift", new Integer(2),
          "TabbedPane.selectedTabShift", new Integer(2),
          "TabbedPane.contentBorderInsets", new Insets(2, 2, 2, 2),
          "TabbedPane.selectedTabPadInsets", new Insets(0, 1, 0, 1),
          "TabbedPane.tabInsets", new Insets(2, 8, 0, 8),
          "TabbedPane.tabRunOverlay", new Integer(1),
	
          "SysButton.focusInputMap", new UIDefaults.LazyInputMap(new Object[]{"SPACE", "pressed", "released SPACE", "released"}),
          "SysButton.textShiftOffset", new Integer(0),
    
          "OptionPane.windowBindings", new Object[]{"ESCAPE", "close"},
          "OptionPane.separatorSize",  new Dimension(8, 8),
      
          "SplitPane.dividerSize", new Integer(5),
      
          "ToolBar.separatorSize", new Dimension(9, 9),

          "Tree.leftChildIndent", new Integer(7),
          "Tree.rightChildIndent", new Integer(13),
          "Tree.rowHeight", new Integer(19),
          "Tree.scrollsOnExpand", Boolean.TRUE,

          "Tree.changeSelectionWithFocus", Boolean.TRUE,
          "Tree.drawsFocusBorderAroundIcon", Boolean.FALSE,
	  };
	
	  table.putDefaults(uiDefaults);
	}
	
	
	protected void initComponentDefaults(UIDefaults table){

       // allow basic look & feel to load the table
	   super.initComponentDefaults(table);

	   // remove entries that might have default form from the table
	   for(Enumeration e = table.keys(); e.hasMoreElements(); ){
	       Object key = e.nextElement();
	       if(key.toString().indexOf(".background")!=-1) table.remove(key);
	       else if(key.toString().indexOf(".foreground")!=-1) table.remove(key);
	       else if(key.toString().indexOf(".inactiveForeground")!=-1) table.remove(key);
	       else if(key.toString().indexOf(".inactiveBackground")!=-1) table.remove(key);
	       else if(key.toString().indexOf(".disabledForeground")!=-1) table.remove(key);
	       else if(key.toString().indexOf(".disabledBackground")!=-1) table.remove(key);
	       else if(key.toString().indexOf(".selectionForeground")!=-1) table.remove(key);
	       else if(key.toString().indexOf(".selectionBackground")!=-1) table.remove(key);
	       else if(key.toString().indexOf(".lightShadow")!=-1) table.remove(key);
	       else if(key.toString().indexOf(".moderatedShadow")!=-1) table.remove(key);
	       else if(key.toString().indexOf(".font")!=-1) table.remove(key);
	       else if(key.toString().indexOf(".deepShadow")!=-1) table.remove(key);
	       
           else if(key.toString().indexOf(".absoluteShadow")!=-1) table.remove(key);
	       else if(key.toString().indexOf(".lightHighlight")!=-1) table.remove(key);
	       else if(key.toString().indexOf(".moderatedHighlight")!=-1) table.remove(key);
	       else if(key.toString().indexOf(".deepHighlight")!=-1) table.remove(key);
	       else if(key.toString().indexOf(".absoluteHighlight")!=-1) table.remove(key);
	       else if(key.toString().indexOf(".caretForeground")!=-1) table.remove(key);
	       else if(key.toString().indexOf(".caretBlinkRate")!=-1) table.remove(key);
	   }
	   
       table.put("List.font", new FontUIResource(getCurrentTheme().getFont("cell font")));
       table.put("Table.font", new FontUIResource(getCurrentTheme().getFont("cell font")));
       
       for(Iterator i = getCurrentTheme().metaPalette().keySet().iterator(); i.hasNext(); ){
           String key = (String)i.next();
           
           if(key.toLowerCase().indexOf("foreground") != -1 ||
                                key.toLowerCase().indexOf("background") != -1 ||
                                key.toLowerCase().indexOf("highlight") != -1 ||
                                key.toLowerCase().indexOf("shadow") != -1){
//               System.out.println("---=( Stefan Harsan Farr :: FhLookAndFeel.java )=-> " + key + " : " +getCurrentTheme().metaPalette().get(key));
               table.put(key, new ColorUIResource(getCurrentTheme().getColor((String)getCurrentTheme().metaPalette().get(key))));
           }
           else table.put(key, getCurrentTheme().metaPalette().get(key));
       }
	}
	
	public boolean isNativeLookAndFeel(){
	  return false;
	}
	
	public boolean isSupportedLookAndFeel(){
	  return true;
	}
    
    public Theme getCurrentTheme() {
        return ThemeManager.instance().getCurrentTheme();
    }
    
    private class UIResourceImageIcon extends ImageIcon implements UIResource{
        public UIResourceImageIcon(URL url){
            super(url);
        }
    }
}
