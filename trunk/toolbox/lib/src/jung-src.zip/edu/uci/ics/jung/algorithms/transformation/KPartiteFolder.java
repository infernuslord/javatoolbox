/*
 * Created on Apr 21, 2004
 */
package edu.uci.ics.jung.algorithms.transformation;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.apache.commons.collections.Predicate;
import org.apache.commons.collections.functors.NotPredicate;

import edu.uci.ics.jung.graph.Edge;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.KPartiteGraph;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.graph.impl.DirectedSparseEdge;
import edu.uci.ics.jung.graph.impl.SparseGraph;
import edu.uci.ics.jung.graph.impl.UndirectedSparseEdge;
import edu.uci.ics.jung.graph.predicates.ParallelEdgePredicate;
import edu.uci.ics.jung.utils.PredicateUtils;
import edu.uci.ics.jung.utils.UserData;
import edu.uci.ics.jung.utils.UserDataContainer.CopyAction;

/**
 * @author danyelf
 */
public class KPartiteFolder {

    /**
     * Used in <code>fold()</code> as a user data key to the data attached to
     * the edges in the folded graph.
     */
    public static final String FOLDED_DATA = "edu.uci.ics.jung.graph.KPartiteFolder:Folded Data";

    protected boolean parallel;
    protected CopyAction copy_action = UserData.REMOVE;

    /**
     * Creates an instance of this Folder. See the discussion of fold for notes
     * on the "parallel" argument.
     *  
     */
    public KPartiteFolder(boolean parallel) {
        this.parallel = parallel;
    }

    public void setParallel(boolean parallel) {
        this.parallel = parallel;
    }
    
    public void setCopyAction(CopyAction copy_action)
    {
        this.copy_action = copy_action;
    }

    /**
     * <p>
     * Converts <code>g</code> into a unipartite graph whose vertex set is the
     * vertices whose partition is specified by <code>p</code>. For vertices
     * <code>a</code> and <code>b</code> in this partition, the resultant
     * graph will include the edge <code>(a,b)</code> if the original graph
     * contains edges <code>(a,c)</code> and <code>(c,b)</code> for at least
     * one vertex <code>c</code>.
     * </p>
     * 
     * <p>
     * If <code>parallel</code> is true, then each such connecting vertex
     * <code>c</code> will be represented by a single edge in the resultant
     * graph, and the resultant graph may therefore contain parallel edges.
     * Otherwise, each edge <code>(a,b)</code> in the resultant graph will be
     * annotated with the set of vertices <code>c</code> that connected
     * <code>a</code> to <code>b</code> in the original graph, and the
     * graph's edge requirements will be set to refuse parallel edges.
     * </p>
     * 
     * <p>In either case, if there is an edge from (a) to (b), and a distinct
     * edge from (b) to (a), then a self
     * </p>
     * 
     * <p>
     * If <code>g</code> is neither strictly directed nor strictly undirected,
     * or allows parallel edges, this method throws
     * <code>IllegalArgumentException</code>.
     * 
     * @param g
     *            the graph to convert
     * @param p
     *            the predicate which specifies the partition to fold into
     * @throws IllegalArgumentException
     */
    public Graph fold(KPartiteGraph g, Predicate p) {
        checkGraphConstraints(g);

        Graph newGraph = createGraph(g);

        // get vertices for the specified partition, copy into new graph
        Set vertices = PredicateUtils.getVertices(g, p);
        for (Iterator iter = vertices.iterator(); iter.hasNext();) {
            Vertex v = (Vertex) iter.next();
            v.copy(newGraph);
        }

        for (Iterator iter = vertices.iterator(); iter.hasNext();) {
            Vertex v = (Vertex) iter.next();
            Vertex v_new = (Vertex) v.getEqualVertex(newGraph);
            Set succs = v.getSuccessors();

            for (Iterator s_iter = succs.iterator(); s_iter.hasNext();) {
                Vertex s = (Vertex) s_iter.next();
                Set s_succs = s.getSuccessors();

                for (Iterator t_iter = s_succs.iterator(); t_iter.hasNext();) {
                    Vertex t = (Vertex) t_iter.next();

                    // if t is in the partition of interest
                    // and has not been covered (undirected graphs only)
                    if (!vertices.contains(t)) continue;

                    Vertex t_new = (Vertex) t.getEqualVertex(newGraph);
                    addEdge(newGraph, v_new, s, t_new);

                }
            }
        }

        return newGraph;
    }

    /**
     * Creates a new edge from firstEnd to secondEnd in newGraph. Note that
     * "firstEnd" and "secondEnd" are both parts of the newGraph, while
     * intermediate is part of the original graph. If parallel is set,
     * adds a new edge from firstEnd to secondEnd, labelled with "intermediate".
     * If parallel is not set, then (as is appropriate) adds an edge
     * or creates one from firstEnd to secondEnd, and adds intermediate as a label. 
     * 
     * @param newGraph
     * @param firstEnd
     * @param intermediate
     * @param secondEnd
     */
    protected void addEdge(Graph newGraph, Vertex firstEnd,
            Vertex intermediate, Vertex secondEnd) {
        boolean undirected = PredicateUtils.enforcesUndirected(newGraph);
        if( undirected && firstEnd == secondEnd ) return;
        if (parallel) {
            Edge v_t;
            if (undirected)
                v_t = new UndirectedSparseEdge(firstEnd, secondEnd);
            else
                v_t = new DirectedSparseEdge(firstEnd, secondEnd);
            v_t.addUserDatum(FOLDED_DATA, intermediate, copy_action);
            newGraph.addEdge(v_t);
        } else {
            Edge v_t = firstEnd.findEdge(secondEnd);
            if (v_t == null) {
                if (undirected)
                    v_t = new UndirectedSparseEdge(firstEnd, secondEnd);
                else
                    v_t = new DirectedSparseEdge(firstEnd, secondEnd);
                v_t.addUserDatum(FOLDED_DATA, new HashSet(), copy_action);
                newGraph.addEdge(v_t);
            }
            Set folded_vertices = (Set) v_t.getUserDatum(FOLDED_DATA);
            folded_vertices.add(intermediate);
        }

    }

    /**
     * Returns a base graph to use--by default, returns a new SparseGraph
     * without constraints.
     */
    protected Graph createGraph(KPartiteGraph g) {
        Graph newGraph = new SparseGraph();
        Collection edge_requirements = newGraph.getEdgeConstraints();

        if (!parallel) edge_requirements.add(Graph.NOT_PARALLEL_EDGE);

        boolean undirected = PredicateUtils.enforcesUndirected(g);
        if (undirected)
            edge_requirements.add(Graph.UNDIRECTED_EDGE);
        else
            edge_requirements.add(Graph.DIRECTED_EDGE);

        return newGraph;
    }

    /**
     * Checks whether a graph
     */
    protected void checkGraphConstraints(KPartiteGraph g) {
        // no mixed graphs allowed
        boolean undirected = PredicateUtils.enforcesUndirected(g);
        if (!undirected && !PredicateUtils.enforcesDirected(g))
                throw new IllegalArgumentException(
                        "Graph must be strictly "
                                + "directed or strictly undirected (no mixed graphs allowed)");

        // if the graph has any parallel edges, reject it
        boolean enforcesNotParallel = PredicateUtils.enforcesNotParallel(g);
        boolean noParallelEdges = PredicateUtils.satisfiesEdgeConstraint(g,
                NotPredicate.getInstance(ParallelEdgePredicate.getInstance()));
        if (!enforcesNotParallel && !noParallelEdges)
                throw new IllegalArgumentException(
                        "Graph must have no parallel edges");
    }

}