package com.shfarr.ui.wizards;

import java.awt.Component;

/**
 * Insert the type's description here.
 * Creation date: (7/23/01 3:48:35 PM)
 * @author: 
 */
public interface Wizard{
public boolean canDo(String job);
/**
 * Insert the method's description here.
 * Creation date: (7/23/01 4:17:48 PM)
 * @return int
 */
public int getCurrentStep();
/**
 * Insert the method's description here.
 * Creation date: (7/23/01 4:17:24 PM)
 * @return int
 */
public int getStepCount();
public boolean isBusy();
public Object launchWizard(Object object, String message, Component caller);
}
