package multivalent.std.adaptor;

import java.io.IOException;
import java.io.File;
import java.io.InputStream;

import multivalent.MediaAdaptor;

import phelps.io.InputStreamCached;



/**
	Superclass for media adaptors that require a file, not a stream.

	@see multivalent.std.adaptor.pdf.PDF
	@see tex.dvi.DVI

	@version $Revision: 1.2 $ $Date: 2002/10/16 09:18:12 $
*/
public abstract class MediaAdaptorRandom extends MediaAdaptor {
  private File file_ = null;

  /**
	Return associated file, which may require blocking on {@link InputStreamCached#getFile()}.
  */
  protected File getFile() throws IOException {
	if (file_==null) {
		InputStream is = getInputStream();
		assert is!=null;
//System.out.println(" MAF file from "+is+" in "+System.identityHashCode(this));
		if (is instanceof InputStreamCached) {
			file_ = ((InputStreamCached)is).getFile();
//System.out.println("closing "+is);
			closeInputStream();
			//is_=null;
		} else assert false: is;
//System.out.println(" MAF file = "+file_+" from "+is);
	} //else System.out.println(" MAF already set = "+file_);
	assert file_!=null;
	return file_;
  }

  public void setInputStream(String txt) { throw new UnsupportedOperationException("can't create file-based media adaptor from String"); }

  public void setInputStream(InputStream is) {
	assert is!=null;

//System.out.println("set MAF "+is+" in "+System.identityHashCode(this));
	// just check validity here -- don't force file to be created until getFile()
	if (is instanceof InputStreamCached) { // ok
//try { System.out.println(" out = "+((InputStreamCached)is).getFile()+" "+System.identityHashCode(is)); } catch (IOException ioe) { System.out.println("can't get file"); }
		super.setInputStream(is);
	//else if (is instanceof FileInputStream) ((FileInputStream)is).getChannel();     // LATER, when move to nio
	} else throw new java.lang.IllegalArgumentException("Requires InputStreamCached from which to obtain File, not "+is.getClass().getName());
	//else throw new java.lang.IllegalArgumentException("Must be file-based: InputStreamCached or FileInputStream");
  }

  public void setFile(File file) throws IOException {
	assert file!=null;
	assert file_==null: file_;
	if (file_==null) file_ = file;
//System.out.println("setFile "+file);
  }

  public void closeFile() throws IOException {
	closeInputStream();
  }

/*  public void buildBefore(Document doc) {
	// generally need data by now
	getFile();

	super.buildBefore(doc);
  }*/
}
