// $Id: DOMExtensions.java,v 1.1 2002/04/25 18:03:15 bill Exp $

package com.jclark.xsl.dom;

public interface DOMExtensions
{
    org.w3c.dom.Element getElementById(org.w3c.dom.Document doc, String str);
}
