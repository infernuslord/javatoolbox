package tool.pdf;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.io.FileFilter;
import java.util.*;

import multivalent.ParseException;
import multivalent.std.adaptor.pdf.*;
import static multivalent.std.adaptor.pdf.COS.*;

import phelps.io.FileList;
import phelps.lang.Integers;
import phelps.util.Units;



/**
	Uncompress.
	Removes Ascii85, Flate, LZW and so on, but not image filters.
	Marks page objects with page number, and marks other object with their use by pages.
	Prettyprints content streams.

	@version $Revision: 1.12 $ $Date: 2004/01/06 02:37:21 $
*/
public class Uncompress implements Observer {
  static final boolean DEBUG = true;

  public static final String VERSION = "2.2 of $Date: 2004/01/06 02:37:21 $";
  public static final String USAGE = "java tool.pdf.Uncompress [options] <PDF-file>\n"
	+ "\t[-exact] [-fonts] [-password <owner-password>]";


  private boolean fexact_;
  private boolean ffonts_;
  private String password_;
  private boolean fverbose_, fquiet_, fmonitor_;
  private PrintStream out_;

  private PDFReader pdfr_; private PDFWriter pdfw_; // for update()
  private List<Integer> pagenum_ = null;
  private Set[] objuse_;
  /** Mark content streams, from page or XObject Form. */
  private boolean[] content_;

  public Uncompress() {
	defaults();
  }

  public void defaults() {
	fexact_ = false;
	ffonts_ = false;
	password_ = null;

	fverbose_ = fquiet_ = fmonitor_ = false;
	out_ = phelps.io.PrintStreams.DEVNULL;
  }

  public void setExact(boolean b) { fexact_ = b; /*ffonts_ = false; -- allow to be independent*/ }
  public void setPlainFonts(boolean b) { ffonts_ = b; }
  public void setPassword(String password) { password_=password; }
  public void setOut(PrintStream out) { out_ = out!=null? out: phelps.io.PrintStreams.DEVNULL; }


  public void uncompress(File filein, File fileout) throws IOException, ParseException {
	//X assert !filein.equals(fileout);
	PDFReader pdfr = new PDFReader(filein);
	PDFWriter pdfw = new PDFWriter(fileout, pdfr); 
	if (fmonitor_) { /*pdfr.setMonitor(true);*/ pdfw.setMonitor(true); }

	uncompress(pdfr, pdfw);

	pdfr_ = pdfr; pdfw_ = pdfw;
	pdfw.writePDF(this);
	pdfr_=null; pdfw_=null;

	if (!fquiet_) {
		//if (digital signature) out_.println("reapply digital signatures");
		//if (pdfr.isRepaired()) out_.println("repaired errors");
		out_.println(pdfw.getFile()+" is UNCOMPRESSED"+(fexact_? "": " and prettyprinted")+", and can be edited");
	}
	if (fverbose_) {
		out_.println("file length "+pdfr.getRAF().length()+" => "+pdfw.getRAF().length());
	}

	pdfw.close();
	pdfr.close();
  }

  /**
	When writing with prettyprinting, pass this class instance as the observer to {@link PDFWriter#writePDF(Observer)}.
  */
  public void uncompress(PDFReader pdfr, PDFWriter pdfw) throws IOException, ParseException {
	pdfr.setExact(true);	// if uncompress to debug want exact not corrected
	if (pdfr.getTrailer().get("Encrypt")!=null) {
		SecurityHandler sh = pdfr.getEncrypt().getSecurityHandler();
		sh.authOwner(password_);
		if (!sh.isAuthorized()) throw new ParseException("owner password required");
		pdfr.getTrailer().remove("Encrypt");	// encrypted uncompressed useless
	}

	pdfw.setExact(fexact_);
	/*if (!fexact_)*/ pdfw.getTrailer().remove(KEY_COMPRESS);
	pdfw.setCompress(false); //pdfw.setCrunch(false);

	if (!fexact_) markupPages(pdfr, pdfw);
	if (ffonts_) pdfw.convertType1(phelps.awt.font.NFontType1.SUBFORMAT_DECRYPTED);
  }


  public void update(Observable obs, Object arg) {
	if (fexact_) return;

	Object[] oa = (Object[])arg; Object o = oa[0]; int num = ((Integer)oa[1]).intValue();
	String txt = null;
	int pg = pagenum_.indexOf(oa[1]);
	if (pg != -1) txt = "page "+(pg+1);
	else if (num >= 1) {
		Set<Integer> l = (Set<Integer>)objuse_[num]; int pcnt = l.size();
		if (pcnt==0) {}	// not directly referenced by page
		else if (pcnt==1) txt = "used by page "+l.iterator().next();
		else {
			int[] nums = new int[pcnt];
			int j=0; for (Iterator<Integer> i = l.iterator(); i.hasNext(); ) nums[j++] = i.next().intValue();
			txt = "used by pages "+Units.toRange(nums);
		}
	}

	if (CLASS_DICTIONARY==o.getClass() && ((Dict)o).get(STREAM_DATA) != null) try {
		Dict dict = (Dict)o;
		if (/*compareVersion(1,5)<0) ||*/ pdfr_.getEncrypt().getCryptFilter(dict) != CryptFilter.IDENTITY) pdfw_.removeFilter(dict, "Crypt");
//System.out.println("prettyprint obj "+num);
		if (content_[num]) prettyprint(dict, pdfr_, pdfw_);
	} catch (IOException shouldnthappen) {}

	if (txt!=null) try { pdfw_.getRAF().write(("% "+txt+"\n").getBytes()); } catch (IOException shouldnthappen) { System.out.println("can't write: "+shouldnthappen); }
  }

  private void prettyprint(Dict stream, PDFReader pdfr, PDFWriter pdfw) throws IOException {
	try {
		Cmd[] cmds = pdfr.readCommandArray(stream);
//System.out.println(" => "+Runtime.getRuntime().freeMemory());
		stream.put(STREAM_DATA, pdfw.writeCommandArray(cmds, true));
//System.out.println(" => "+Runtime.getRuntime().freeMemory());
		// could handle bigger streams, but would have to duplicate PDFWriter writeCommandArray
		/*
		ByteArrayOutputStream bout = new ByteArrayOutputStream(100*1024);
		InputStreamComposite in = getInputStream(contentstream, true);
		for (Cmd cmd; (cmd = pdfr.readCommand(in))!=null; ) {
			
		}
		in.close();
System.out.println("  len = "+bout.length());
		stream.put(STREAM_DATA, bout.toByteArray());
		bout.close();
		*/
	} catch (IOException pe) {
		// object split across streams -- just don't rewrite
	}

	/*boolean fBI = false;
	if (!funcompress) for (int j=0,jmax=cmds.length; j<jmax; j++) if ("BI".equals(cmds[j].op)) { fBI=true; break; }
	if (funcompress || fBI)*/
//System.out.print(" r/w "+ca[i]);
  }


  private void markupPages(PDFReader pdfr, PDFWriter pdfw) throws IOException {
	int objcnt = pdfr.getObjCnt();

	int pagecnt = pdfr.getPageCnt();
	pagenum_ = new ArrayList<Integer>(pagecnt);
	for (int i=0; i<pagecnt; i++) pagenum_.add(Integers.getInteger(pdfr.getPageRef(i+1).id));    // pin + index for Object=>num lookup

	objuse_ = new Set[objcnt];
	for (int i=0+1; i<objcnt; i++) {
//System.out.println("adding "+i);
		objuse_[i] = new LinkedHashSet<Integer>(5);
	}

	content_ = new boolean[objcnt];
	for (int i=0; i<pagecnt; i++) {
		IRef pageref = pdfr.getPageRef(i+1);
		pageOwner((i+1), pdfr.getObject(pageref), objuse_);
		findContent(pageref, pdfr);
	}
  }

  private void pageOwner(int pagenum, Object o, Set[] objuse) throws IOException {
	Class cl = o.getClass();
	if (CLASS_IREF == cl) {
		int id = ((IRef)o).id;
		Integer pg = Integers.getInteger(pagenum);
		if (!objuse[id].contains(pg)) {
			objuse[id].add(pg);
			//pageOwner(pagenum, pdfr.getObject(o),pdfr, objuse); -- maybe selectively recuse, but everything connected via page tree
		}
	} else if (CLASS_ARRAY == cl) for (Object oi: (Object[])o) pageOwner(pagenum, oi, objuse);
	else if (CLASS_DICTIONARY == cl) for (Iterator<Object> i = ((Dict)o).values().iterator(); i.hasNext(); ) pageOwner(pagenum, i.next(), objuse);
  }

  private void findContent(Object ref, PDFReader pdfr) throws IOException {
	Dict dict = (Dict)pdfr.getObject(ref);

	// contents array
	Object coref = dict.get("Contents");
	Object co = pdfr.getObject(coref);
	Object[] ca = co==null? new Object[0]: CLASS_DICTIONARY==co.getClass()? new Object[] { coref }: (Object[])co;
	for (int i=0,imax=ca.length; i<imax; i++) content_[((IRef)ca[i]).id] = true;

	// Form XObject too
	Dict res = (Dict)pdfr.getObject(dict.get("Resources"));
	Dict xores = res!=null? (Dict)pdfr.getObject(res.get("XObject")): null;
	if (xores!=null) for (Iterator<Object> i=xores.values().iterator(); i.hasNext(); ) {
		Object o = pdfr.getObject(i.next());
		if (CLASS_DICTIONARY==o.getClass()) {
			Dict xdict = (Dict)o;
			if ("Form".equals("Subtype")) findContent(o, pdfr);
		}
	}
  }



  private int commandLine(String[] argv) {
	out_ = System.out;
	fexact_ = false;

	int argi=0, argc=argv.length;
	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.equals("-exact")) setExact(true);
		else if (arg.startsWith("-font"/*"s"*/)) setPlainFonts(true);
		else if (arg.equals("-password")) setPassword(argv[++argi]);

		else if (arg.startsWith("-verb")) fverbose_ = true;
		else if (arg.startsWith("-q"/*uiet*/)) fquiet_ = true;
		else if (arg.startsWith("-mon"/*itor*/)) fmonitor_ = true;
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.startsWith("-h"/*"elp"*/)) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	if (argi == argc) { System.err.println(USAGE); System.exit(0); }

	return argi;
  }

  public static void main(String[] argv) throws IOException {
	// make machine for uncompressing PDFs with given parameters
	Uncompress un = new Uncompress();
	int argi = un.commandLine(argv);

	// limit to uncompressing exactly one?
	for (Iterator<File> i = new FileList(argv, argi, FILTER).iterator(); i.hasNext(); ) {
		File filein = i.next();
		String path = filein.getPath();
		String fileout = (path.toLowerCase().endsWith(".pdf")? path.substring(0,path.length()-".pdf".length()): path) + "-u.pdf";
		try {
			un.uncompress(filein, new File(fileout));
		} catch (Exception e) {
			System.err.println(filein+": "+e);
			if (DEBUG) e.printStackTrace();
		}
	}
	System.exit(0);
  }
}
