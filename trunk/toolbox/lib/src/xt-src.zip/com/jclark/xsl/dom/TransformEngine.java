// $Id: TransformEngine.java,v 1.1 2002/04/25 18:04:12 bill Exp $

package com.jclark.xsl.dom;

import org.w3c.dom.Node;

/**
 * 
 */
public interface TransformEngine
{
    Transform createTransform(Node stylesheetRoot) 
        throws TransformException;
}
