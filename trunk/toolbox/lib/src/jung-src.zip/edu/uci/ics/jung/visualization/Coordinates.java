/*
* Copyright (c) 2003, the JUNG Project and the Regents of the University 
* of California
* All rights reserved.
*
* This software is open-source under the BSD license; see either
* "license.txt" or
* http://jung.sourceforge.net/license.txt for a description.
*/
package edu.uci.ics.jung.visualization;

/**
 * 
 * Stores coordinates (X,Y) for vertices being visualized. 
 * 
 * @author Scott White
 */
public class Coordinates {

    /** x location */
    private double x;
    /** y location */
    private double y;

     public Coordinates() {
        this.x = 0;
        this.y = 0;
    }

    public Coordinates(double x, double y) {
        this.x = x;
        this.y = y;
    }

	/**
	 * Initializes this coordinate to the value of the passed-in
	 * coordinate.
	 * @param coordinates
	 */
    public Coordinates(Coordinates coordinates) {
        this.x = coordinates.getX();
        this.y = coordinates.getY();
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

	/**
	 * Sets the x value to be d;
	 * @param d
	 */
    public void setX(double d) {
        x = d;
    }

	/**
	 * Sets the y value to be d;
	 * @param d
	 */
    public void setY(double d) {
        y = d;
    }

	/**
	 * Increases the x and y values of this
	 * scalar by (x, y).
	 * @param x
	 * @param y
	 */
    public void add(double x, double y) {
        addX(x);
        addY(y);
    }

	/**
	 * Increases the x value by d.
	 * @param d
	 */
    public void addX(double d) {
        x += d;
    }

	/**
	 * Increases the y value by d.
	 * @param d
	 */
    public void addY(double d) {
        y += d;
    }

	/**
	 * Multiplies a coordinate by scalar x and y values.
	 * @param x	A scalar to multiple x by
	 * @param y	A scalar to multiply y by
	 */
    public void mult(double x, double y) {
        multX(x);
        multY(y);
    }

	/**
	 * Multiplies the X coordinate by a scalar value.
     * <P>
	 * For example, (3, 10) x-scaled by 2 returns (6, 10).
	 * @param d	the scalar value by which x will be multiplied
	 */
    public void multX(double d) {
        x *= d;
    }

	/**
	 * Multiplies the Y coordinate by a scalar value.
     * <P>
	 * For example, (3, 10) y-scaled by 2 returns (3, 20).
     * @param d the scalar value by which y will be multiplied
	 */
    public void multY(double d) {
        y *= d;
    }

    /**
     * Computes the euclidean distance between two coordinates
     * @param o another coordinates
     * @return the euclidean distance
     */
    public double distance(Coordinates o) {
        double xDelta = x - o.getX();
        double yDelta = y - o.getY();
        return Math.sqrt((xDelta * xDelta) + (yDelta * yDelta));
    }

    /**
     * Computes the midpoint between the two coordinates
     * @param o another coordinates
     * @return the midpoint
     */
    public Coordinates midpoint(Coordinates o) {
        double midX = (this.getX() + o.getX()) / 2.0;
        double midY = (this.getY() + o.getY()) / 2.0;
        Coordinates midpoint = new Coordinates(midX, midY);
        return midpoint;
    }

}
