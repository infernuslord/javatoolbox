package samples.graph;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.decorators.DefaultToolTipFunction;
import edu.uci.ics.jung.graph.decorators.EdgeShape;
import edu.uci.ics.jung.graph.decorators.PickableEdgePaintFunction;
import edu.uci.ics.jung.utils.TestGraphs;
import edu.uci.ics.jung.visualization.FRLayout;
import edu.uci.ics.jung.visualization.GraphZoomScrollPane;
import edu.uci.ics.jung.visualization.PickedState;
import edu.uci.ics.jung.visualization.PluggableRenderer;
import edu.uci.ics.jung.visualization.ShapePickSupport;
import edu.uci.ics.jung.visualization.VisualizationModel;
import edu.uci.ics.jung.visualization.DefaultVisualizationModel;
import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.control.DefaultModalGraphMouse;
import edu.uci.ics.jung.visualization.transform.HyperbolicLayoutLensSupport;
import edu.uci.ics.jung.visualization.transform.HyperbolicLensSupport;
import edu.uci.ics.jung.visualization.transform.shape.HyperbolicViewLensSupport;

/**
 * Demonstrates the use of <code>HyperbolicTransform</code>
 * applied to either the model (graph layout) or the view
 * (VisualizationViewer)
 * The hyperbolic transform is applied in an elliptical lens
 * that affects that part of the visualization. For
 * 
 * @author Tom Nelson - RABA Technologies
 * 
 */
public class HyperbolicLensDemo extends JApplet {

    /**
     * the graph
     */
    Graph graph;

    /**
     * the visual component and renderer for the graph
     */
    VisualizationViewer vv;

    /**
     * provides a Hyperbolic lens for the view
     */
    HyperbolicLensSupport viewSupport;
    
    /**
     * provides a Hyperbolic lens for the model
     */
    HyperbolicLensSupport layoutSupport;
    
    /**
     * create an instance of a simple graph with controls to
     * demo the zoomand hyperbolic features.
     * 
     */
    public HyperbolicLensDemo() {
        
        // create a simple graph for the demo
        graph = TestGraphs.getOneComponentGraph();
        
        PluggableRenderer pr = new PluggableRenderer();
        FRLayout layout = new FRLayout(graph);
        layout.setMaxIterations(1000);

        Dimension preferredSize = new Dimension(400,400);
        final VisualizationModel visualizationModel = 
            new DefaultVisualizationModel(layout, preferredSize);
        vv =  new VisualizationViewer(visualizationModel, pr, preferredSize);
        vv.setPickSupport(new ShapePickSupport());
        pr.setEdgeShapeFunction(new EdgeShape.QuadCurve());
        PickedState ps = vv.getPickedState();
        pr.setEdgePaintFunction(new PickableEdgePaintFunction(ps, Color.black, Color.red));
        vv.setBackground(Color.white);

        // add a listener for ToolTips
        vv.setToolTipFunction(new DefaultToolTipFunction());
        
        Container content = getContentPane();
        GraphZoomScrollPane gzsp = new GraphZoomScrollPane(vv);
        content.add(gzsp);
        
        /**
         * the regular graph mouse for the normal view
         */
        final DefaultModalGraphMouse graphMouse = new DefaultModalGraphMouse();

        vv.setGraphMouse(graphMouse);
        
        viewSupport = new HyperbolicViewLensSupport(vv);
        layoutSupport = new HyperbolicLayoutLensSupport(vv);
        layoutSupport.getHyperbolicTransformer().setEllipse(viewSupport.getHyperbolicTransformer().getEllipse());
        ;        

        JButton plus = new JButton("+");
        plus.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // call listener in GraphMouse instead of manipulating vv scale directly
                // this is so the crossover from zoom to scale works with the buttons
                // as well as with the mouse wheel
                Dimension d = vv.getSize();
                graphMouse.mouseWheelMoved(new MouseWheelEvent(vv,MouseEvent.MOUSE_WHEEL,
                        System.currentTimeMillis(),0,d.width/2,d.height/2,1,false, 
                        MouseWheelEvent.WHEEL_UNIT_SCROLL,1,1));
            }
        });
        JButton minus = new JButton("-");
        minus.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // call listener in GraphMouse instead of manipulating vv scale directly
                // this is so the crossover from zoom to scale works with the buttons
                // as well as with the mouse wheel
                Dimension d = vv.getSize();
                graphMouse.mouseWheelMoved(new MouseWheelEvent(vv,MouseEvent.MOUSE_WHEEL,
                        System.currentTimeMillis(),0,d.width/2,d.height/2,1,false, 
                        MouseWheelEvent.WHEEL_UNIT_SCROLL,1,-1));
            }
        });
        
        ButtonGroup radio = new ButtonGroup();
        JRadioButton normal = new JRadioButton("None");
        normal.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                if(e.getStateChange() == ItemEvent.SELECTED) {
                    if(viewSupport != null) {
                        viewSupport.deactivate();
                    }
                    if(layoutSupport != null) {
                        layoutSupport.deactivate();
                    }
                }
            }
        });

        final JRadioButton hyperView = new JRadioButton("In View");
        hyperView.addItemListener(new ItemListener(){
            public void itemStateChanged(ItemEvent e) {
                viewSupport.activate(e.getStateChange() == ItemEvent.SELECTED);
            }
        });
        final JRadioButton hyperModel = new JRadioButton("In Layout");
        hyperModel.addItemListener(new ItemListener(){
            public void itemStateChanged(ItemEvent e) {
                layoutSupport.activate(e.getStateChange() == ItemEvent.SELECTED);
            }
        });

        radio.add(normal);
        radio.add(hyperModel);
        radio.add(hyperView);
        normal.setSelected(true);
        
        graphMouse.addItemListener(layoutSupport.getHyperbolicGraphMouse().getModeListener());
        graphMouse.addItemListener(viewSupport.getHyperbolicGraphMouse().getModeListener());
        
        
//        JPanel modePanel = new JPanel(new GridLayout(2,1));
//        modePanel.setBorder(BorderFactory.createTitledBorder("Mouse Mode"));
//        modePanel.add(graphMouse.getModeComboBox());
//      
        
        JMenuBar menubar = new JMenuBar();
        menubar.add(graphMouse.getModeMenu());
        gzsp.setCorner(menubar);
        

        JPanel controls = new JPanel();
        JPanel zoomControls = new JPanel(new GridLayout(2,1));
        zoomControls.setBorder(BorderFactory.createTitledBorder("Zoom"));
        JPanel hyperControls = new JPanel(new GridLayout(2,2));
        hyperControls.setBorder(BorderFactory.createTitledBorder("Hyperbolic Lens"));
        zoomControls.add(plus);
        zoomControls.add(minus);
        hyperControls.add(normal);
        hyperControls.add(hyperModel);
        hyperControls.add(hyperView);
        controls.add(zoomControls);
        controls.add(hyperControls);
//        controls.add(modePanel);
        content.add(controls, BorderLayout.SOUTH);
    }

    /**
     * a driver for this demo
     */
    public static void main(String[] args) {
        JFrame f = new JFrame();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.getContentPane().add(new HyperbolicLensDemo());
        f.pack();
        f.show();
    }
}
