package multivalent.std.adaptor;

import java.awt.*;
import java.awt.geom.Line2D;	// imports its inner classes too
import java.io.*;
import java.net.URL;
import java.net.MalformedURLException;
import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import multivalent.*;
import multivalent.node.*;

import phelps.Utility;



/**
	NOT IMPLEMENTED -- PROBABLY TO LINK INTO BATIK.
	<a href="http://www.w3.org/TR/SVG/" target="supplemental">Scalable Vector Graphics</a> media adaptor.

	Uses CSS.

	@version $Revision$ $Date$
*/
public class SVG extends MediaAdaptorReader {
  // should be a better way to do this
  static final String tags =
	"svg " +
	"desc title "+
	"g "+
	"rect circle ellipse line polyline polygon";
  static final int SVG=0,
	DESC=SVG+1, TITLE=DESC+1,
	G=TITLE+1,
	RECT=G+1, CIRCLE=RECT+1, ELLIPSE=RECT+2, LINE=RECT+3, POLYLINE=RECT+4, POLYGON=RECT+5;
  static Map<String,Integer> tagID;
  static {
	int id=0;
	StringTokenizer st=new StringTokenizer(tags);
	tagID = new HashMap<String,Integer>(st.countTokens()*2);
	while (st.hasMoreTokens()) {
		String name = st.nextToken().toLowerCase().intern();
		assert tagID.get(name)==null: "duplicate tag name in tags array: "+name;
		tagID.put(name, new Integer(id++));
		// check that command doesn't already exist
	}

	// spot checks
	assert tagID.get("G").intValue() == G;
  }


  protected Node svgroot=null;
/*
  public boolean restore(InputStream urlin) throws IOException {
	// XML parse
	ESISNode proot = null;
	try { proot = (ESISNode)new XML().parse(urlin,null); } catch (Exception e) { System.out.println(e); return false; }

	// traverse XML and build mirror tree with SVG-specific nodes
	svgroot = buildSVG(proot);
	return false;
  }
*/

  /** Recurses down to tail, aggregates as recurse up. */
  protected Node buildSVG(ESISNode en) {
	String gi=en.getGI(); Map<String,Object> attrs=en.attrs;
	Node n = null;

	// if few enough tags, just use if-else chain rather than hash
System.out.println(gi);
	int id = tagID.get(gi).intValue();
	switch (id) {
	case SVG: n = new svg(gi,attrs, null); break;
	case TITLE: n = new desc(gi,attrs, null); break;
	case DESC: n = new title(gi,attrs, null); break;
	case G: n = new g(gi,attrs, null); break;
	case RECT: n = new rect(gi,attrs, null); break;
	//case CIRCLE: n = new circle(gi,attrs, null); break;
	//case ELLIPSE: n = new ellipse(gi,attrs, null); break;
	case LINE: n = new line(gi,attrs, null); break;
	//case POLYLINE: n = new polyline(gi,attrs, null); break;
	//case POLYGON: n = new polygon(gi,attrs, null); break;
	default:
	}

	if (n.isStruct()) {	// faster if set flag above, but safer this way
		INode ni = (INode)n;
		for (int i=0,imax=en.size(); i<imax; i++) {
			ni.appendChild(buildSVG((ESISNode)en.childAt(i)));
		}
	}

	return n;
  }

  public void buildBefore(Document doc) {
	if (svgroot!=null) doc.appendChild(svgroot);
	//System.out.println("svgroot="+svgroot);
  }

  public Object parse(INode parent) throws Exception {
	// LATER: just return XML parse
	return null;
  }



  /*
   * Utility methods for node classes
   */

  static int getDimension(String spec) {
	double value = getDDimension(spec);
//System.out.println(spec+": "+value+" => "+(int)value);
	return (int)getDDimension(spec);
  }

  static double getDDimension(String spec) {
	double value=0, scale=1.0; String dim=null;

	if (spec==null) return 0;
	for (int i=0,imax=spec.length(); i<imax; i++) {
		if (!Character.isDigit(spec.charAt(i))) {
			if (i==0) return 0; //throw new ParseException("no numerical value in dimension: "+dim);
			try { value=Double.parseDouble(spec.substring(0,i)); } catch (NumberFormatException nfe) { return 0.0; }
			while (i<imax && Character.isWhitespace(spec.charAt(i))) i++;
			/*if (i==imax) return value;  // already in pixels?
			else*/ dim=spec.substring(i);
			break;
		} else if (i+1==imax) {
			try { value=Double.parseDouble(spec); } catch (NumberFormatException nfe) { return 0.0; }
		}
	}

	if ("in".equals(dim)) scale=100.0;	// what's the screen ppi?
	else if ("".equals(dim)) scale=1.0;

	return value*scale;
  }




  /*
   * Specialized classes
   */

  /** Sets dimensions. */
class svg extends INode {
  public svg(String name,Map<String,Object> attr, INode parent) { super(name,attr, parent); }
  public boolean formatNode(int width,int height, Context cx) {
	super.formatNode(width,height, cx);

	// later scale to incoming width and height
	int w=getDimension(getAttr("width")), h=getDimension(getAttr("height"));
	if (w==0) w=100;
	if (h==0) h=100;
	bbox.setBounds(0,0,w,h);
	return !valid_;
  }
  public void paintNode(Rectangle docclip, Context cx) {
//System.out.println("painting "+bbox);
	super.paintNode(docclip, cx);
	Graphics2D g = cx.g;
	g.setColor(Color.BLACK);
	g.drawRect(0,0,bbox.width,bbox.height);
  }
}

/** No effect... for now. */
class desc extends Leaf {
  public desc(String name,Map<String,Object> attr, INode parent) { super(name,attr, parent); }
}
/** No effect... for now. */
class title extends Leaf {
  public title(String name,Map<String,Object> attr, INode parent) { super(name,attr, parent); }
}

/** Grouper--no effect over being an INode, which means can set attrs */
class g extends INode {
  public g(String name,Map<String,Object> attr, INode parent) {
	super(name,attr, parent);
  }
  //public void paintNodeContent(Rectangle docclip, Context cx) {

  //}
/*	public boolean formatNode(int width,int height, Context cx) {
	super.formatNode(width,height, cx);
	int imax=size();
	if (imax>0) {
		bbox.setBounds(childAt(0).bbox);
		for (int i=1; i<imax; i++) bbox.add(childAt(i).bbox);
	}
	return !valid_;
  }*/
}

class rect extends Leaf {
  //Rectangle r = null; -- same as bbox!
  public rect(String name,Map<String,Object> attr, INode parent) {
	super(name,attr, parent);
	bbox.setBounds(getDimension(getAttr("x")),getDimension(getAttr("y")), getDimension(getAttr("width")),getDimension(getAttr("height")));
//System.out.println("making rect "+bbox);
  }

  public boolean formatNodeContent(Context cx, int start, int end) {
	bbox.setBounds(bbox);
//System.out.println("formatting rect "+bbox);
	return false;
  }

  public boolean paintNodeContent(Context cx, int start, int end) {
System.out.println("painting rect "+bbox);
/*
	Color fillcolor = (Color)cx.attrs.get("fillcolor");
	Graphics2D g = cx.g;
	if (fillcolor!=null) { g.setColor(fillcolor); g.fill(bbox); }
	Color strokecolor = (Color)cx.attrs.get("strokecolor");
	if (fillcolor!=null) { g.setColor(fillcolor); g.draw(bbox); }
	g.setColor(Color.BLACK);
	g.draw(bbox);
*/
	return false;
  }
}

class line extends Leaf {
  Line2D.Double l = null;
  public line(String name,Map<String,Object> attr, INode parent) {
	super(name,attr, parent);
	l = new Line2D.Double((double)getDimension(getAttr("x")),getDimension(getAttr("y")), getDimension(getAttr("width")),getDimension(getAttr("height")));
  }
  public boolean formatNodeContent(Context cx, int start, int end) {
	double x1=l.getX1(),y1=l.getY1(), x2=l.getX2(),y2=l.getY2();
	bbox.setBounds((int)x1,(int)y1, (int)(x2-x1),(int)(y2-y1));
	return false;
  }
  public boolean paintNodeContent(Context cx, int start, int end) {
	Graphics2D g = cx.g;
/*
	Color fillcolor = (Color)cx.attrs.get("fillcolor");
	if (fillcolor!=null) { g.setColor(fillcolor); g.fill(l); }
	Color strokecolor = (Color)cx.attrs.get("strokecolor");
	if (fillcolor!=null) { g.setColor(fillcolor); g.draw(l); }
	g.draw(l);
*/
	return false;
  }
}
}
