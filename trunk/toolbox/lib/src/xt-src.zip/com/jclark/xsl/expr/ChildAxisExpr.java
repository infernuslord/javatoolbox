// $Id: ChildAxisExpr.java,v 1.1 2002/04/25 18:05:13 bill Exp $

package com.jclark.xsl.expr;

import com.jclark.xsl.om.*;

/**
 *
 */
class ChildAxisExpr extends AxisExpr
{
    public NodeIterator eval(Node node, ExprContext context)
    {
        return node.getChildren();
    }

    int getOptimizeFlags()
    {
        return STAYS_IN_SUBTREE | SINGLE_LEVEL;
    }
}
