/*
 * Created on Jan 21, 2004
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package com.shfarr.ui.plaf.fh.tools;

import javax.swing.JComponent;
import javax.swing.JDialog;

/**
 * @author shfarr
 */
public class Animation{
    public void displayDialog(JDialog dialog, JComponent component){
    }
}
