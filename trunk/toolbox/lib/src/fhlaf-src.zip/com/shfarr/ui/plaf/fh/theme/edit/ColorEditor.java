/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh.theme.edit;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.Collection;
import java.util.Iterator;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingUtilities;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;

import com.shfarr.ui.GraphicsUtils;
import com.shfarr.ui.layouts.QueueLayout;
import com.shfarr.ui.plaf.fh.theme.ColorPalette;

/**
 * @author Administrator
 */
public class ColorEditor extends JPanel implements ActionListener{
    
    private JLabel customColorChooser = null; 
    private JPanel centerPanel = null; 
    private JPanel sidePanel = null; 
    private JPanel palettePanel = null; 
    private JPanel northPanel = null; 
    private JTextField colorField = null;
    private JSpinner alphaSpinner = null;
    private JToggleButton selected = null;
    
    public ColorEditor() {
        super(new BorderLayout(3, 3));
        setBorder(new EmptyBorder(10, 4, 4, 0));
                
        add(getsidePanel(), "East");
        add(getCenterPanel(), "Center");
    }

    protected JLabel getCustomColorChooser(){
        if(customColorChooser == null){
            customColorChooser = new JLabel("", JLabel.CENTER);
            customColorChooser.setOpaque(true);
            customColorChooser.setPreferredSize(new Dimension(30, 50));
            customColorChooser.setBorder(new CompoundBorder(new MatteBorder(0, 0, 0, 0, customColorChooser.getBackground()), new MatteBorder(1, 1, 1, 1, Color.black)));
        }
            
        return customColorChooser;
    }
    
    protected JPanel getPalettePanel(){
        if(palettePanel == null){
            ColorPalette cp = ThemeEditor.instance().getEditedTheme().colorPalette();
            Collection list = cp.list();
            
            palettePanel = new ColorPalettePanel(new GridLayout(list.size()/4 +(list.size()%4 != 0 ? 1 : 0) +1, 4, 2, 2));
            
            palettePanel.setBorder(new EmptyBorder(5, 5, 5, 5));
            
            ButtonGroup group = new ButtonGroup();
            
            int i = 0;
            
            for(Iterator iter = list.iterator(); iter.hasNext(); ){
                String name = (String)iter.next();
                
                if(cp.getColor(name) != null){
                    JToggleButton b = createToggleButton(name, cp.getColor(name));                
                
                    if(i == 24){
                        for(int q = 0; q < 4; q++){
                            JLabel sep = new JLabel();
                            sep.setPreferredSize(new Dimension(20, 20));
                            palettePanel.add(sep);
                        }
                    }
                
                    palettePanel.add(b);
                
                    group.add(b);
                    i++;
                }
            }
        }
    
        return palettePanel;
    }
    
    protected JToggleButton createToggleButton(String name, Color c){
        JToggleButton b = new JToggleButton("");
                
        // icon
        BufferedImage img = new BufferedImage(20, 20, BufferedImage.TYPE_INT_ARGB);
        Graphics g = img.createGraphics();
                
        g.setColor(Color.gray);
        g.drawRect(0, 0, 19, 19);
                
        g.setColor(Color.white);
        g.drawRect(1, 1, 17, 17);

        GraphicsUtils.paintTiledBackground(g, new Rectangle(3, 2, 14, 16), 5);
        g.drawImage(GraphicsUtils.createColorImage(c, 14, 16), 3, 2, null);
                
        b.setIcon(new ImageIcon(img));
        b.setDisabledIcon(new ImageIcon(img));

        // selected icon
        BufferedImage imgS = new BufferedImage(20, 20, BufferedImage.TYPE_INT_ARGB);
        g = imgS.createGraphics();
                
        g.setColor(Color.orange);
        g.drawRect(0, 0, 19, 19);
                
        g.setColor(Color.white);
        g.drawRect(1, 1, 17, 17);
                
        GraphicsUtils.paintTiledBackground(g, new Rectangle(3, 2, 14, 16), 5);
        g.drawImage(GraphicsUtils.createColorImage(c, 14, 16), 3, 2, null);
                
        b.setSelectedIcon(new ImageIcon(imgS));

        b.setActionCommand(name);
        b.setMargin(new Insets(1, 1, 1, 1));
        b.addActionListener(this);
        
        b.setEnabled(!isBaseColor(name));
        
        return b;
    }

    protected JPanel getCenterPanel(){
        if(centerPanel == null){
            JScrollPane scp = new JScrollPane(getPalettePanel());
            scp.setPreferredSize(new Dimension(getPalettePanel().getPreferredSize().width +scp.getVerticalScrollBar().getPreferredSize().width +6, 100));

            centerPanel = new JPanel(new BorderLayout(4, 4));
            //centerPanel.add(new JLabel("Color Palette"));
            centerPanel.add(scp, "West");
            centerPanel.add(getNorthPanel(), "Center");
        }
    
        return centerPanel;
    }

    protected JTextField getColorField(){
        if(colorField == null){
            colorField = new JTextField();
            colorField.setPreferredSize(new Dimension(240, colorField.getPreferredSize().height));
        }
    
        return colorField;
    }

    protected JSpinner getAlphaSpinner(){
        if(alphaSpinner == null){
            alphaSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 255, 1));
        }
    
        return alphaSpinner;
    }

    protected JPanel getNorthPanel(){
        if(northPanel == null){
            northPanel = new JPanel(new QueueLayout(4, QueueLayout.VERTICAL, QueueLayout.STRECH_COMPONENTS));

            northPanel.setBorder(new EmptyBorder(0, 5, 5, 5));

            northPanel.add(new JLabel("Selected Color"));
            northPanel.add(getCustomColorChooser());
            northPanel.add(new JLabel(""));
            northPanel.add(getColorField());
            
            JButton cc = new JButton("Select");
            cc.setActionCommand("Choose Color");
            cc.addActionListener(this);
            
            JPanel alphaPanel = new JPanel(new QueueLayout(4, QueueLayout.HORIZONTAL, QueueLayout.CENTER_COMPONENTS));
            alphaPanel.add(cc);
            alphaPanel.add(getAlphaSpinner(), QueueLayout.END);
            alphaPanel.add(new JLabel("Alpha ", JLabel.RIGHT), QueueLayout.END);
            
            northPanel.add(alphaPanel);
        }
    
        return northPanel;
    }

    protected JPanel getsidePanel(){
        if(sidePanel == null){
            sidePanel = new JPanel(new QueueLayout(4, QueueLayout.VERTICAL, QueueLayout.STRECH_COMPONENTS));
            sidePanel.setBorder(new EmptyBorder(0, 4, 4, 4));
            
            JButton save = new JButton("Save");
            save.addActionListener(this);
            
            JButton revert = new JButton("Revert");
            revert.addActionListener(this);
            
            JButton remove = new JButton("Remove");
            remove.addActionListener(this);
            
            JButton set = new JButton("Add / Set");
            set.addActionListener(this);
            set.setActionCommand("Set");
            
            JButton rollback = new JButton("Rollback");
            rollback.addActionListener(this);

            sidePanel.add(save);
            sidePanel.add(revert);
            sidePanel.add(new JPanel());
            sidePanel.add(set);
            sidePanel.add(rollback);
            sidePanel.add(remove);
        }
    
        return sidePanel;
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource() instanceof JToggleButton){
            selected = (JToggleButton)e.getSource();
            
            getColorField().setText(e.getActionCommand());
            
            Color c = ThemeEditor.instance().getEditedTheme().colorPalette().getColor(e.getActionCommand());
            
            getCustomColorChooser().setBackground(new Color(0xFF << 24 | c.getRGB()));
            getAlphaSpinner().setValue(new Integer(c.getAlpha()));
        }
        
        if(e.getActionCommand().equals("Revert")){
            ThemeEditor.instance().getEditedTheme().loadColors();
            refreshToggleButtons();
        }

        if(e.getActionCommand().equals("Save")){
            ThemeEditor.instance().getEditedTheme().saveColors();
        }

        if(e.getActionCommand().equals("Rollback") && selected != null){
            getColorField().setText(selected.getActionCommand());
            
            Color c = ThemeEditor.instance().getEditedTheme().colorPalette().getColor(selected.getActionCommand());
            
            getCustomColorChooser().setBackground(new Color(0xFF << 24 | c.getRGB()));
            getAlphaSpinner().setValue(new Integer(c.getAlpha()));
        }

        if(e.getActionCommand().equals("Set")){
            int alpha = ((Integer)getAlphaSpinner().getValue()).intValue();
            Color c = getCustomColorChooser().getBackground();
            
            Color old = ThemeEditor.instance().getEditedTheme().colorPalette().getColor(getColorField().getText());
            
            ThemeEditor.instance().getEditedTheme().colorPalette().registerColor(getColorField().getText(), new Color(c.getRed(), c.getGreen(), c.getBlue(), alpha));
            
            if(getColorField().getText().equals("base") && !getColorField().getText().equals("")) refreshToggleButtons();
            else{
                JToggleButton b = createToggleButton("dummy", new Color(c.getRed(), c.getGreen(), c.getBlue(), alpha));

                if(old != null){
                    selected.setIcon(b.getIcon());
                    selected.setSelectedIcon(b.getSelectedIcon());
                }
                else refreshToggleButtons();
            }
        }
        
        if(e.getActionCommand().equals("Choose Color")){
            Color c = JColorChooser.showDialog(SwingUtilities.windowForComponent(((JButton)e.getSource())), "Custom Color", getCustomColorChooser().getBackground());
            if(c != null) getCustomColorChooser().setBackground(c);
        }
        
        if(e.getActionCommand().equals("Remove") && !getColorField().getText().equals("")){
            ThemeEditor.instance().getEditedTheme().colorPalette().registerColor(getColorField().getText(), null);
            refreshToggleButtons();
        }
    }

    protected void refreshToggleButtons(){
        JScrollPane scp = (JScrollPane)palettePanel.getParent().getParent();
         
        palettePanel = null;

        scp.setViewportView(getPalettePanel());
    }
    
    protected boolean isBaseColor(String name){
        try{
            int i = Integer.parseInt(name);
        	
            if(i > -11 && i < 11) return true;
            else return false;
        }
        catch(Exception e){
            return false;
        }
    }
}
