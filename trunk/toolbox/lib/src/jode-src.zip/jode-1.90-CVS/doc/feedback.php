<?php require("header.inc"); ?> 

<h1>Feedback</h1>

<p>You can report bugs to the <?php sflink("bugs/")?>bug forum</a>. </p>

<p>You can contact me by email via <a
href="http://sourceforge.net/sendmessage.php?touser=18252">hoenicke at
users.sourceforge.net</a>.  Please mention <i>jode</i> in the
subject.</p>

<p>There is a mailing list.  Check <a href="http://lists.sourceforge.net/mailman/listinfo/jode-users">this page</a> for subscription informations.</p>

<?php require("footer.inc"); ?> 
