/*
 * Created on Dec 28, 2003
 */
package edu.uci.ics.jung.graph;


/**
 * A Hyperedge is a part of a hypergraph that
 * connects to zero or more Hypervertices.
 * Note that two different Hyperedges are 
 * NOT equal, even if they point to the same
 * set of vertices. Also note that Hyperedge
 * is mutable; it is possible to add and remove
 * vertices from the edge.
 * 
 * @author danyelf
 */
public interface Hyperedge extends ArchetypeEdge {

	/**
	 * @param hv1
	 */
	void addVertex(Hypervertex hv1);

}
