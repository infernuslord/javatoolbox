/*
 * @(#)JClassInfo.java
 *
 * JReversePro - Java Decompiler / Disassembler.
 * Copyright (C) 2000 Karthik Kumar.
 * EMail: akkumar@users.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it , under the terms of the GNU General Public License as published
 * by the Free Software Foundation; either version 2 of the License,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program.If not, write to
 *  The Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330,
 *  Boston, MA 02111-1307, USA.
 */
package jreversepro.reflect;

import jreversepro.common.KeyWords;
import java.util.List;
import java.util.ArrayList;

/**
 * <b>JClassInfo</b> is the abstract representation of the Class File.
 * The names of the methods are self explanatory.
 *
 * @author      Karthik Kumar
 */
public class JClassInfo implements KeyWords {

    /**
     * ACC_SUPER bit required to be set on all
     * modern classes.
     **/
    public static final int ACC_SUPER   = 0x0020;

    /**
     * ACC_INTERFACE bit required to be set if it is an
     * interface and not a class.
     **/
    public static final int ACC_INTERFACE   = 0x0200;

    //Generic Info about a class File.
    /**
     * Absolute path where the class' source file was located.
     **/
    private String absPath;

    /**
     * Major number of the JVM version that this class file
     * is compiled for.
     **/
    private short majorNumber;

    /**
     * Minor number of the JVM version that this class file
     * is compiled for.
     **/
    private short minorNumber;


    /**
     * Name of the current class in the JVM format.
     * That is, if the class is String then the name would be
     * java/lang/String.
     **/
    private String thisClass;


    /**
     * Name of the current class' superclass in the JVM format.
     * That is, if the class is String then the name would be
     * java/lang/String.
     **/
    private String superClass;

    /**
     * Name of the package of the current class in the JVM format.
     * That is the fully qualified name of the class is
     * java.lang.String. then the package name would contain
     * java/lang.
     **/
    private String packageName;

    /**
     * Name of the source file in which this class files' code
     * is present.
     **/
    private String srcFile;

    /**
     * ConstantPool information contained in the class.
     **/
    private JConstantPool cpInfo;

    /**
     * List of fields present in the class.
     * All the members in the list are JField.
     **/
    private List memFields;

    /**
     * List of methods present in the class.
     * All the members in the list are JMethod.
     **/
    private List memMethods;

    /**
     * List of interfaces present in the class.
     * All the members in the list are String.
     * For example if the class implements
     * java.awt.event.ActionListener then the list would
     * contain java/awt/event/ActionListener as its member.
     * The class file name would be in the JVM format as mentioned
     * above.
     **/
    private List interfaces;

    /**
     * An integer referring to the access permission of the
     * class.
     * Like if a class is public static void main ()
     * then the accessflag would have appropriate bits
     * set to say if it public static.
     **/
    private int accessFlag;

    /**
     * Empty constructor
     **/
    public JClassInfo() {
        memFields =  new ArrayList();
        memMethods =  new ArrayList();
        interfaces = new ArrayList();
        cpInfo =  new JConstantPool(2);
    }

    /**
     * Adds a new interface that is implemented by this class.
     * @param interfaceName Name of the interface.
     **/
    public void addInterface(String interfaceName) {
        interfaces.add(interfaceName);
    }

    /**
     * Adds a new field present in the class.
     * @param rhsField contains the field-related information.
     **/
    public void addField(JField rhsField) {
        memFields.add(rhsField);
    }

    /**
     * Adds a new method present in the class.
     * @param rhsMethod contains the method-related information.
     **/
    public void addMethod(JMethod rhsMethod) {
        memMethods.add(rhsMethod);
    }

    /**
     * Sets the pathname of this class.
     * @param classPath Path to this class.
     **/
    public void setPathName(String classPath) {
        absPath  = classPath;
    }

    /**
     * Sets the ConstantPool information of this class.
     * @param cpInfo contains the constant pool information
     * of this class.
     **/
    public void setConstantPool(JConstantPool cpInfo) {
        this.cpInfo = cpInfo;
    }

    /**
     * Returns the constantpool reference
     * @return Returns the ConstantPool reference.
     **/
    public JConstantPool getConstantPool() {
        return this.cpInfo;
    }

    /**
     * Sets the major and minor number of the JVM
     * for which this class file is compiled for.
     * @param rhsMajor Major number
     * @param rhsMinor Minor number
     **/
    public void setMajorMinor(short rhsMajor, short rhsMinor) {
        majorNumber = rhsMajor;
        minorNumber = rhsMinor;
    }

    /**
     * Sets the access flag of the class.
     * @param rhsAccess Access flag of the class.
     **/
    public void setAccess(int rhsAccess) {
        accessFlag = rhsAccess;
    }

    /**
     * Sets the name of the current class.
     * @param rhsName Name of this class.
     **/
    public void setThisClass(String rhsName) {
        thisClass = rhsName;
    }

    /**
     * Sets the name of the current class' superclass.
     * @param rhsName Name of this class; superclass.
     **/
    public void setSuperClass(String rhsName) {
        superClass = rhsName;
    }

    /**
     * Sets the package to which this class belongs to.
     * @param packageName name of the package to be set.
     **/
    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    /**
     * Sets the name of the source file to which this
     * was contained in.
     * @param rhsSrcFile Name of the source file.
     **/
    public void setSourceFile(String rhsSrcFile) {
        srcFile = rhsSrcFile;
    }


    /**
     * Returns the path name of this class.
     * @return Absolute path of this class.
     **/
    public String getPathName() {
        return absPath;
    }

    /**
     * Returns the major number of the JVM.
     * @return JVM
     **/
    public int getMajor() {
        return majorNumber;
    }

    /**
     * Returns the minor number of the JVM.
     * @return JVM minor version
     **/
    public int getMinor() {
        return minorNumber;
    }

    /**
     * Returns the class name of this class.
     * @return name of the current class.
     **/
    public String getThisClass() {
        return thisClass;
    }

    /**
     * Returns the class name of this class' super class.
     * @return name of the current class' super-class.
     **/
    public String getSuperClass() {
        return superClass;
    }

    /**
     * Returns the source file of the current class.
     * @return source file of the current class.
     **/
    public String getSourceFile() {
        return srcFile;
    }

    /**
     * Returns the List of interfaces of the current class.
     * @return interfaces of the current class.
     **/
    public List getInterfaces() {
        return interfaces;
    }

    /**
     * Returns the fields present in the class.
     * @return Returns a List of JField
     **/
    public List getFields() {
        return memFields;
    }

    /**
     * Returns the methods of this class.
     * @return Returns a list of JMethods
     **/
    public List getMethods() {
        return memMethods;
    }

    /**
     * Returns the access string of this class.
     * @return Returns the access string of this class.
     **/
    public String getAccessString() {
        StringBuffer  accString = new StringBuffer();
        accString.append(JMember.getStringRep(accessFlag, false));

        if (isClass())  {
            accString.append(CLASS);
        } else {
            accString.append(INTERFACE);
        }
        return accString.toString();
    }

    /**
     * Returns if this is a class or an interface
     * @return Returns true if this is a class,
     *      false, if this is an interface.
     **/
    public boolean isClass() {
        return ((accessFlag & ACC_INTERFACE) == 0);
   }
}