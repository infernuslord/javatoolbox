package com.thoughtworks.qdox.model;

/**
 * @author Aslak Helles&oslash;y
 * @version $Revision: 1.4 $
 */
public abstract class AbstractInheritableJavaEntity extends AbstractJavaEntity {
    public DocletTag getTagByName(String name, boolean inherited) {
        DocletTag[] tags = getTagsByName(name, inherited);
        return tags.length > 0 ? tags[0] : null;
    }

    protected AbstractInheritableJavaEntity(JavaClassParent parent, int lineNumber) {
        super(parent, lineNumber);
    }

    public abstract DocletTag[] getTagsByName(String name, boolean inherited);
}
