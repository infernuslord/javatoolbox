// $Id: NamespaceConstants.java,v 1.1 2002/04/25 18:13:07 bill Exp $

package com.jclark.xsl.om;

/**
 *
 */
public interface NamespaceConstants 
{
    /**
     * James Clark's XT XSLT extensions
     */
    static final String XT_NAMESPACE = "http://www.jclark.com/xt";

    /**
     *  XX XSLT extensions
     */
    static final String XFYXT_NAMESPACE = "http://www.blnz.com/namespaces/xx";
}
