/*
 * Created on Dec 28, 2003
 */
package edu.uci.ics.jung.graph;


/**
 * A Hypergraph consists of hypervertices and hyperedges.
 * Hyperedges connect arbitrary numbers of hypervertices 
 * together.
 * 
 * @author danyelf
 */
public interface Hypergraph extends ArchetypeGraph {

	/**
	 * @param hypervertex
	 */
	Hypervertex addVertex(Hypervertex hypervertex);

	/**
	 * @param hyperedge
	 */
	Hyperedge addEdge(Hyperedge hyperedge);

}
