package multivalent.node;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.util.Map;

import multivalent.INode;
import multivalent.Context;
import multivalent.MediaAdaptor;

import phelps.awt.Colors;
import phelps.awt.NFont;



/**
	Leaf subclass for Unicode.  (Media adaptors often have their own Leaf subclass.)

	<p>Each word gets its own leaf.  I used to think this was wasteful, as opposed
	to having a leaf per screen line, say, but if a word costs 50 bytes instead of 5,
	that just means that a 10,000 word page (which is big) costs 500K instead of 50K,
	and 100,000 words cost 5MB instead of 500K.  No sweat for today's memory sizes.

	@see multivalent.std.adaptor.ASCII

	@version $Revision: 1.3 $ $Date: 2002/04/18 23:44:24 $
*/
public class LeafAscii extends LeafText {

  public LeafAscii(String name, Map<String,Object> attr, INode parent) { this(name,null, attr, parent); }
  public LeafAscii(String name, String estr,  Map<String,Object> attr, INode parent) {
	super(name,estr,  attr, parent);
	assert name!=null: "No null words -- but zero-length OK";
  }

  /** Similar to paintNodeContent, set right font, measure with FontMetrics.stringString(); */
  public boolean formatNodeContent(Context cx, int start, int end) {
	int len = name_.length();
	//if (len==0) { bbox.setSize(1,1); baseline=1; return false; }

	if (end>=len) end=len-1;
	assert start>=0: "start<0 in "+getName();
	//if (start<0) { start=0; System.out.println("start<0: "+start+"!"); }
	NFont spot = cx.spot; boolean fenc = spot!=null && estr_!=null;
	String txt = fenc? estr_: name_;
	txt = start!=0 || end<len-1? txt.substring(start,end+1): txt;
	if (!fenc && txt!=null && !txt.equals("\t")) {
		String trans = cx.texttransform;    // this one interned
		// wrong place for this!
		if (null==trans || "none"==trans) {}
		else if ("uppercase"==trans) txt=txt.toUpperCase();
		else if ("lowercase"==trans) txt=txt.toLowerCase();
		else if ("capitalize"==trans) txt=txt.charAt(0)+txt.substring(1);
		//else if ("inherit"/STRINGINHERIT==trans) ...
	}

	FontMetrics fm = cx.getFontMetrics();	//Toolkit.getDefaultToolkit().getFontMetrics(cx.getFont());
	bbox.height = fm.getHeight();
	baseline = fm.getAscent();

	if (fenc) {
		bbox.width = (int)(spot.estringAdvance(txt, 0,txt.length()).getX() + 0.5);
	} else if (len==0) {
		bbox.width = /*0;*/fm.charWidth(' ');
//System.out.println("len = "+bbox.width+", height="+bbox.height);
	//} else if (txt.equals("\t")) { // LATER more sophisticated handling of tabs
//System.out.println("tab @ "+cx.x);
		//bbox.width = 4*fm.charWidth(' ');
//		  bbox.height = baseline = 0;
	} else {
		bbox.width = spot!=null? (int)(spot.stringAdvance(txt).getX() + 0.5): fm.stringWidth(txt);
		//if (end==len-1) bbox.width += (bbox.height>20?7:3); // fm.charWidth(' '); -- too much
	}
	return false;
  }


  /** To paint content, set right font, use Graphics.drawString(); */
  public boolean paintNodeContent(Context cx, int start, int end) {
	assert 0<=start /*&& start<=end -- restore this*/ && end<=size();   // start<end?
//if (childNum()==0) System.out.println("painting "+getName()+"  "+start+".."+end);
	int len=size(); //name_.length();  // use size(), overriding size() if necessary (which I doubt)
	if (start>/*=*/end/*put in invariant*/ || start>=len || len==0) return false;   // Mark after last character -- Graphics2D.drawString (actually TextLayout constructor) doesn't like 0-length String

	NFont spot = cx.spot; boolean fenc = spot!=null && estr_!=null;
	AffineTransform at = spot!=null && spot.isTransformed()? spot.getTransform(): null;
	float w = bbox.width, h = 0f;
	String txt = fenc? estr_: name_;
	if (end>=len) { end=len-1; if (name_.charAt(end)=='\n') end--; }
	FontMetrics fm = cx.getFontMetrics();	//g.getFontMetrics();
	if (start!=0 || end<len-1) {
		txt = end-start==0? phelps.lang.Strings.valueOf(txt.charAt(start)): txt.substring(start,end+1);
		//txt = name_.substring(start,end+1);  // would be nice to have Graphics.drawChars(String str, int offset, int length, int x, int y)
		if (fenc) { Point2D pt = spot.estringAdvance(txt, 0,txt.length()); w=(float)pt.getX(); h=(float)pt.getY(); }
		else if (spot!=null) { Point2D pt = spot.stringAdvance(txt, 0,txt.length()); w=(float)pt.getX(); h=(float)pt.getY(); }
		else w = fm.stringWidth(txt);   // could create a million String's, but usually don't start or end span in middle of node, so don't substring after all
//System.out.println("painting subportion "+start+".."+end+" (coords "+cx.x+".."+w+")");
	}
	Graphics2D g = cx.g;
	if (cx.background!=Colors.TRANSPARENT && cx.background!=null && cx.background!=cx.pagebackground/*was: ...!=null*/) {   // should be in Leaf, but have to know width before can draw background
		int fonth = fm.getHeight();
		g.setColor(cx.background);	// may be highlighted... => Spans should do this (usually, with help for weirdness like image-OCR)
		g.fillRect((int)cx.x,(int)(baseline-fm.getAscent()-cx.ydelta), (int)(w+0.5),/*bbox.height*/fonth);   // can't do by system as only leaf knows width of text
	}
//if (!Color.BLACK.equals(cx.foreground)) System.out.println("fg = "+cx.foreground+" on "+getName());
	if (cx.foreground!=Colors.TRANSPARENT && txt!=null /*&& !txt.equals("\t")*/) {   // => DO THIS ON FORMAT ONLY; if transformation, store display name in name_, original as attribute
//if (txt.length()==0) { System.out.println(name_+" "+start+".."+end); return false; }
		String trans = cx.texttransform;    // this one interned
		if (fenc || null==trans || "none"==trans) {}
		else if ("uppercase"==trans) txt=txt.toUpperCase();
		else if ("lowercase"==trans) txt=txt.toLowerCase();
		else if ("capitalize"==trans && start==0) txt=txt.charAt(0)+txt.substring(1);
		//else if ("inherit"/STRINGINHERIT==trans) ...

//System.out.println(txt+", spot = "+spot);
		g.setColor(cx.foreground);
//System.out.println("paint "+txt+" @ "+cx.x);
//g.setFont(new Font("TimesRoman", Font.PLAIN, 12)); //g.setColor(Color.GREEN);
//System.out.println(spot+" "+estr_+" "+txt);
		if (fenc) spot.drawEstring(g, txt, cx.x, cx.y + baseline - cx.ydelta, cx.mode);
		else if (spot!=null) spot.drawString(g, txt, cx.x, cx.y + baseline - cx.ydelta, cx.mode);
		else { g.setFont(cx.getFont()); g.drawString(txt, cx.x, /*bbox.y +*/cx.y + baseline - cx.ydelta/*relative to baseline*/); }
	}
	cx.x += w; cx.y -= h;	// update current point

	return false;
  }
}
