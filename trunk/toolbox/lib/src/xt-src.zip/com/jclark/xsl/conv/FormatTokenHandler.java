// $Id: FormatTokenHandler.java,v 1.1 2002/04/25 18:02:48 bill Exp $

package com.jclark.xsl.conv;

public interface FormatTokenHandler
{
    NumberFormat getFormat(String lang, String letterValue);
}
