package tool.pdf;

import java.io.*;
import java.util.Iterator;
import java.util.Observer;
import java.util.Observable;

import multivalent.std.adaptor.pdf.*;
import multivalent.std.adaptor.pdf.SecurityHandler;
import multivalent.ParseException;
import static multivalent.std.adaptor.pdf.COS.*;

import phelps.io.FileList;



/**
	Decrypt.

	@author Copyright (c) 2002 - 2003  Thomas A. Phelps
	@version $Revision: 1.13 $ $Date: 2004/02/10 19:58:33 $
*/
public class Decrypt implements Observer {
  static final boolean DEBUG = true;

  public static final String VERSION = "1.1 of $Date: 2004/02/10 19:58:33 $";
  public static final String USAGE = "java tool.pdf.Decrypt [-password <owner-password>] [-inplace] <PDF-file...>";
//  [-out <file>]

  private String password_;
  private boolean finplace_;
  private boolean fverbose_, fquiet_, fmonitor_;

  private PDFReader pdfr_;
  private PDFWriter pdfw_;

  public Decrypt() {
	defaults();
  }

  public void defaults() {
	password_ = null;
	finplace_ = false;

	fverbose_ = fquiet_ = fmonitor_ = false;
  }

  public void setPassword(String password) { password_=password; }



  public void decrypt(File file) throws IOException,ParseException {
	String path = file.getPath();
	String pathout = finplace_? path: (path.toLowerCase().endsWith(".pdf")? path.substring(0, path.length()-4): path) + "-d.pdf";
	decrypt(file, new File(pathout));
  }

  /**
	Decrypts encrypted file.
	Not MT-safe.
  */
  public void decrypt(File in, File out) throws IOException,ParseException {
//Runtime rt = Runtime.getRuntime();
//System.out.println("in = "+rt.freeMemory()+"/"+rt.totalMemory());
	PDFReader pdfr = new PDFReader(in);
	PDFWriter pdfw = new PDFWriter(out, pdfr);

	decrypt(pdfr, pdfw);
	pdfr_ = pdfr; pdfw_ = pdfw;	// for update()
	pdfw.writePDF(this);
	pdfr_ = null; pdfw_ = null;

	pdfr.close();	// before pdfw.close() for -inplace
	pdfw.close();
//System.out.println("out = "+rt.freeMemory()+"/"+rt.totalMemory());
  }

  public void decrypt(PDFReader pdfr, PDFWriter pdfw) throws IOException,ParseException {
	//pdfr.setExact(true); => kills Compact
	// verify encryption
	if (pdfr.getTrailer().get("Encrypt")==null) { System.err.println("PDF not encrypted -- no action taken."); pdfr.close(); return; }

	//pdfr.setPassword(password_); //setPasswords(pdfr);	// owner password required
	SecurityHandler sh = pdfr.getEncrypt().getSecurityHandler();
	sh.authOwner(password_);
	if (!sh.isAuthorized()) throw new ParseException("owner password required");
	if (fmonitor_) { Dict info = pdfr.getInfo(); System.out.println(info); }

	pdfr.fault();

	// defang
	pdfw.setExact(true);
	pdfw.getTrailer().remove("Encrypt");
	//pdfw.refcnt(); => retain encryption dictionary in case want to look at later and it's small
  }

  /** Strips /Crypt filters from streams, unless <code>/Identity</code>. */
  public void update(Observable obs, Object arg) {
	Object[] oa = (Object[])arg;
	Object obj = oa[0];
	if (CLASS_DICTIONARY == obj.getClass() && ((Dict)obj).get(STREAM_DATA) != null) try {
		Dict dict = (Dict)obj;
		if (/*compareVersion(1,5)<0) ||*/ pdfr_.getEncrypt().getCryptFilter(dict) != CryptFilter.IDENTITY) pdfw_.removeFilter(dict, "Crypt");
	} catch (IOException ioe) { /* leave as is? */ }
  }



  private int commandLine(String[] argv) {
	int argi=0, argc = argv.length;
	for ( ; argi < argc; argi++) {
		String arg = argv[argi]; if (!arg.startsWith("-")) break;
		if (arg.equals("-password")) setPassword(argv[++argi]);
		else if (arg.equals("-inplace")) { finplace_=true; /*pathout=null;*/ }
		//else if (arg.startsWith("-out"/*file*/)) { pathout = argv[++argi]; finplace_=false; }

		else if (arg.startsWith("-verb")) { fverbose_ = true; fquiet_ = false; }
		else if (arg.startsWith("-mon"/*itor*/)) { fmonitor_ = fverbose_ = true; fquiet_ = false; }
		else if (arg.startsWith("-q"/*uiet*/)) { fquiet_ = true; fverbose_ = fmonitor_ = false; }
		else if (arg.startsWith("-h"/*"elp"*/)) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	if (argi == argc) { System.err.println(USAGE); System.exit(0); }

	return argi;
  }


  public static void main(String[] argv) {
	Decrypt decrypt = new Decrypt();
	int argi = decrypt.commandLine(argv);

	for (Iterator<File> i = new FileList(argv, argi, FILTER).iterator(); i.hasNext(); ) {
		File file = i.next();
		try {
			//if (!fquiet_) System.out.println(file);
			decrypt.decrypt(file);
		} catch (Exception e) {
			System.err.println(file+": "+e);
			if (DEBUG) e.printStackTrace();
		}
	}
	System.exit(0);
  }
}
