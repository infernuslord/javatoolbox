// $Id: CommentHandler.java,v 1.1 2002/04/25 18:13:23 bill Exp $

package com.jclark.xsl.sax;

/** 
 * receives comment events from a parser, a la SAX1.0
*/
public interface CommentHandler 
{
    void comment(String contents) throws org.xml.sax.SAXException;
}
