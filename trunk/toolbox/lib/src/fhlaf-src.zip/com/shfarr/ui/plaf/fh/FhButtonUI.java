/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh;

import javax.swing.border.CompoundBorder;
import javax.swing.plaf.basic.*;
import javax.swing.plaf.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.image.RGBImageFilter;

import javax.swing.*;

import com.shfarr.ui.ChannelImageFilter;
import com.shfarr.ui.CompoundImageFilter;
import com.shfarr.ui.DesaturationImageFilter;
import com.shfarr.ui.GraphicsUtils;
import com.shfarr.ui.plaf.fh.borders.FHMultiMatrixBorder;
import com.shfarr.ui.plaf.fh.ext.*;
import com.shfarr.ui.plaf.fh.textures.*;
import com.shfarr.ui.plaf.fh.theme.*;

public class FhButtonUI extends BasicButtonUI{
    static ChannelImageFilter rolloverFilter = new ChannelImageFilter(1, 0.1, 0.1, 0.1);
    static CompoundImageFilter normalFilter = new CompoundImageFilter(new RGBImageFilter[]{new DesaturationImageFilter(1),
            new ChannelImageFilter(1, 0.1, 0.1, 0.1)});
    static CompoundImageFilter disabledFilter = new CompoundImageFilter(new RGBImageFilter[]{new DesaturationImageFilter(1),
            new ChannelImageFilter(0.3, 0, 0, 0)});
    /**
     * Shared ButtonListener.
     */
    private static BasicButtonListener sharedButtonListener;

    public FhButtonUI(){
        super();
    }

    public static ComponentUI createUI(JComponent c){
        return new FhButtonUI();
    }

    public void installUI(JComponent jc){
        super.installUI(jc);
    
        AbstractButton b = (AbstractButton)jc;
    }

    public Dimension getPreferredSize(JComponent c){
        if(c instanceof AbstractButton){
            Dimension d = super.getPreferredSize(c);

            Insets i = ((AbstractButton)c).getMargin();
            d.width += i.left + i.right;
            d.height += i.top + i.bottom;

            return d;
        }
        else return super.getPreferredSize(c);
    }

    public void paint(Graphics g, JComponent c){
        ThemeManager.instance().probeAntialiasing(g);
        
        FHMultiMatrixBorder border = c.getBorder() instanceof FHMultiMatrixBorder ? (FHMultiMatrixBorder)c.getBorder() : null;
        if(border == null && c.getBorder() instanceof CompoundBorder){
            if(((CompoundBorder)c.getBorder()).getInsideBorder() instanceof FHMultiMatrixBorder) border = (FHMultiMatrixBorder)((CompoundBorder)c.getBorder()).getInsideBorder();
            else if(((CompoundBorder)c.getBorder()).getOutsideBorder() instanceof FHMultiMatrixBorder) border = (FHMultiMatrixBorder)((CompoundBorder)c.getBorder()).getOutsideBorder();
        }
            
        if(border != null){
            String key = null;
            AbstractButton b = (AbstractButton)c;

            if(b.isRolloverEnabled()){
                if(b.getModel().isPressed()) key = "rollover.pressed";
                else if(b.hasFocus()) key = "focused.armed";
                else if(b.getModel().isRollover()) key = "rollover.armed";
                else key = "rollover";
            }
            else if(b.getModel().isPressed() || b.isSelected()) key = "pressed";
            else if(b.getModel().isArmed() || b.getModel().isRollover()){
                if(b.hasFocus()) key = "focused.armed";
                else key = "armed";
            }
            else if(b.hasFocus()) key = "focused";
            else if(b instanceof JButton && ((JButton)b).isDefaultButton()) key = "default";
            else key = "normal";

            border.selectMatrix(key);
        }

        super.paint(g, c);

        if( !((AbstractButton)c).isRolloverEnabled() || ((AbstractButton)c).getModel().isRollover()){
            if(((AbstractButton)c).isContentAreaFilled()){
                Rectangle rect = new Rectangle(0, 0, c.getSize().width, c.getSize().height);

                Insets i = c.getBorder() != null ? c.getBorder().getBorderInsets(c) : null;
                if(i != null){
                    rect.x += i.left;
                    rect.y += i.top;
                    rect.width -= i.left + i.right;
                    rect.height -= i.top + i.bottom;
                }

                Texture texture = FhDefaults.getTextureFor(c);

                if(texture != null && ThemeManager.instance().probeSmallTextures()) texture.apply(rect, (Graphics2D)g, c);
            }
        }
    }

    protected void paintButtonPressed(Graphics g, AbstractButton b){
        if(b.isContentAreaFilled()){
            Insets i = b.getBorder() != null ? b.getBorder().getBorderInsets(b) : null;

            Rectangle rect = b.getBounds();
            rect.x = 0;
            rect.y = 0;

            g.setColor(UIManager.getColor("Button.backgroundPressed"));
            g.fillRect(rect.x + i.left, rect.y + i.top, rect.width - i.left - i.right, rect.height - i.top - i.bottom);
        }
    }

    protected void paintFocus(Graphics g, AbstractButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect){}

    protected void paintText(Graphics g, JComponent c, Rectangle textRect, String text){
        AbstractButton b = (AbstractButton)c;
        ButtonModel model = b.getModel();
        FontMetrics fm = g.getFontMetrics();
        int mnemIndex = b.getDisplayedMnemonicIndex();

        g.setColor(UIManager.getColor("Component.absoluteHighlight"));
        BasicGraphicsUtils.drawStringUnderlineCharAt(g, text, mnemIndex, textRect.x + 1, textRect.y + fm.getAscent() + 1);

        Color color = c.getForeground();
        if(FhDefaults.getTextType(text) < 0) color = ThemeManager.instance().getCurrentTheme().getColor("negative");
        if(FhDefaults.getTextType(text) > 0) color = ThemeManager.instance().getCurrentTheme().getColor("affirmative");

        if(!model.isEnabled()) color = new Color(GraphicsUtils.blend(color.getRGB(), c.getBackground().getRGB(), 0.5));

        g.setColor(color);
        BasicGraphicsUtils.drawStringUnderlineCharAt(g, text, mnemIndex, textRect.x, textRect.y + fm.getAscent());
    }

    protected void paintIcon(Graphics g, JComponent c, Rectangle iconRect){
        AbstractButton b = (AbstractButton)c;

        if(ThemeManager.instance().getPreferences().isManageButtonIcons() && b.getIcon() != null && b.getIcon() instanceof ImageIcon){
            if(!b.isEnabled()){
                GraphicsUtils.applyFilter((ImageIcon)b.getIcon(), disabledFilter).paintIcon(c, g, iconRect.x, iconRect.y);
            }
            else if(b.isRolloverEnabled() && b.getRolloverIcon() == null){
                if(b.getModel().isRollover()) b.getIcon().paintIcon(c, g, iconRect.x, iconRect.y);
                else GraphicsUtils.applyFilter((ImageIcon)b.getIcon(), normalFilter).paintIcon(c, g, iconRect.x, iconRect.y);
            }
            else{
                if(b.getModel().isRollover() && b.getRolloverIcon() == null) GraphicsUtils.applyFilter((ImageIcon)b.getIcon(), rolloverFilter).paintIcon(c, g, iconRect.x, iconRect.y);
                else b.getIcon().paintIcon(c, g, iconRect.x, iconRect.y);
            }
        }
        else super.paintIcon(g, c, iconRect);
    }

    protected BasicButtonListener createButtonListener(AbstractButton b) {
        if(sharedButtonListener == null){
            sharedButtonListener = new FhButtonListener(b);
        }
        return sharedButtonListener;
    }
    
    public static class FhButtonListener extends BasicButtonListener{
        public FhButtonListener(AbstractButton ab){
            super(ab);
        }
        
        public void mouseEntered(MouseEvent e){
            AbstractButton b = (AbstractButton) e.getSource();
            ButtonModel model = b.getModel();
            
            if(!SwingUtilities.isLeftMouseButton(e)) model.setRollover(true);
            if(model.isPressed()) model.setArmed(true);
        };
         
        public void mouseExited(MouseEvent e){
            AbstractButton b = (AbstractButton) e.getSource();
            ButtonModel model = b.getModel();
            
            model.setRollover(false);
            model.setArmed(false);
        };
    }
}
