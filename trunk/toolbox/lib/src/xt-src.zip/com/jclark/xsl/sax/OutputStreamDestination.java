// $Id: OutputStreamDestination.java,v 1.1 2002/04/25 18:16:03 bill Exp $

package com.jclark.xsl.sax;

import java.io.OutputStream;

/**
 *
 */
public class OutputStreamDestination extends GenericDestination
{
    final private OutputStream outputStream;

    public OutputStreamDestination(OutputStream outputStream) 
    {
        this.outputStream = outputStream;
    }

    public OutputStream getOutputStream(String contentType, String encoding) 
    {
        return outputStream;
    }
}
