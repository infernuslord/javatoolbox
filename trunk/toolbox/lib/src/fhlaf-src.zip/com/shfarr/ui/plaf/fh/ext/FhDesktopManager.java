/**
 * Copyright (c) 2003, Stefan Harsan Farr
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of this product; nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @author Stefan Harsan Farr
 */

package com.shfarr.ui.plaf.fh.ext;

import javax.swing.*;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ContainerEvent;
import java.awt.event.ContainerListener;
import java.awt.image.BufferedImage;

import com.shfarr.ui.*;
import com.shfarr.ui.layouts.QueueLayout;


public class FhDesktopManager extends DefaultDesktopManager implements ContainerListener{
    protected BufferedImage dragBuffer = null;
    protected Rectangle currentBounds = null;
    protected Graphics desktopGraphics = null;
    protected ActionHandler actionHandler = null;
    protected boolean showingButtons = false;

    public FhDesktopManager() {
    	super();
        actionHandler = new ActionHandler();
    }
    
    public void setBoundsForFrame(JComponent f, int newX, int newY, int newWidth, int newHeight){
        if(f instanceof JInternalFrame && ((JInternalFrame)f).isMaximum()){
           Insets ins = f.getInsets();
           Rectangle p = f.getParent().getBounds();
           
           JComponent northPane = ((BasicInternalFrameUI)((JInternalFrame)f).getUI()).getNorthPane();
           int h = northPane.getSize().height;
           
           Component menuBarHolder = f;
           JMenuBar menuBar = findClosestMenubar(f);

           if(menuBar != null) menuBarHolder = menuBar.getParent();
           else{
               while(menuBarHolder.getParent() != null){
                   if(menuBarHolder instanceof JRootPane) break;
                   else menuBarHolder = menuBarHolder.getParent();
               }
               
               menuBar = new JMenuBar();
               ((JRootPane)menuBarHolder).setJMenuBar(menuBar);
           }  
          
           showButtonsOnMenuBar(menuBar, (JInternalFrame)f);
           
           // resize frame
           super.setBoundsForFrame(f, -ins.left, -ins.top -h, p.width +ins.left + ins.right, p.height +ins.top +ins.bottom +h);
        }
        else super.setBoundsForFrame(f, newX, newY, newWidth, newHeight);
    }
    
    protected JMenuBar findClosestMenubar(Component c){
        JMenuBar menuBar = null;
        if(c instanceof JMenuBar) return (JMenuBar)c;
        
        // search on components on the same level
        if(menuBar == null && c instanceof Container && c.getParent() != null){
            for(int i = 0; i < c.getParent().getComponentCount(); i++){
                if(c.getParent().getComponent(i) == c) continue;
                if(c.getParent().getComponent(i) instanceof JMenuBar) return (JMenuBar)c.getParent().getComponent(i);
                
                // serach one level deeper
                if(c.getParent().getComponent(i) instanceof Container){
                    Container cont = ((Container)c.getParent().getComponent(i));
                    for(int k = 0; k < cont.getComponentCount(); k++){
                        if(cont.getComponent(k) instanceof JMenuBar) return (JMenuBar)cont.getComponent(k);
                    }
                } 
            }

            menuBar = findClosestMenubar(c.getParent());
        }
        
        return menuBar;
    }
    
    protected void hideButtonsOnMenuBar(JMenuBar menuBar, JInternalFrame f){
        for(int i = 0; i < menuBar.getComponentCount(); i++){
            if("FH_SYS_Closer".equals(menuBar.getComponent(i).getName())){
                menuBar.remove(i);
                i = 0;
            }
            else if("FH_SYS_Iconifier".equals(menuBar.getComponent(i).getName())){
                menuBar.remove(i);
                i = 0;
            }
            else if("FH_SYS_Restorer".equals(menuBar.getComponent(i).getName())){
                menuBar.remove(i);
                i = 0;
            }
            else if("FH_SYS_Switcher".equals(menuBar.getComponent(i).getName())){
                menuBar.remove(i);
                i = 0;
            }
        }

        //menuBar.invalidate();
        RepaintManager.currentManager(menuBar).markCompletelyClean(menuBar);
        menuBar.repaint();
        
        if(f == null) return;
        
        for(int i=0; i < f.getParent().getComponentCount(); i++){
            if(f.getParent().getComponent(i) != f && f.getParent().getComponent(i) instanceof JInternalFrame){
                try{
                    ((JInternalFrame)f.getParent().getComponent(i)).setMaximum(false);
                }
                catch(Exception e){
                }
            }
        }
            
        showingButtons = false;
    }
    
    protected void showButtonsOnMenuBar(JMenuBar menuBar, JInternalFrame f){
        hideButtonsOnMenuBar(menuBar, f);
        
        CustomFhSysButton iconButton = null;
        CustomFhSysButton restoreButton = null;
        CustomFhSysButton closeButton = null;
        JMenu switchMenu = null;
        
        for(int i=0; i < menuBar.getComponentCount(); i++){
            if("FH_SYS_Iconifier".equals(menuBar.getComponent(i).getName())) iconButton = (CustomFhSysButton)menuBar.getComponent(i);
            else if("FH_SYS_Restorer".equals(menuBar.getComponent(i).getName())) restoreButton = (CustomFhSysButton)menuBar.getComponent(i);
            else if("FH_SYS_Closer".equals(menuBar.getComponent(i).getName())) closeButton = (CustomFhSysButton)menuBar.getComponent(i);
            else if("FH_SYS_Switcher".equals(menuBar.getComponent(i).getName())) switchMenu = (JMenu)menuBar.getComponent(i);
        }
        
        if(iconButton == null){
            closeButton = createButton("FH_SYS_Closer", FhSysButton.CLOSER, f);
            restoreButton = createButton("FH_SYS_Restorer", FhSysButton.RESTORER, f);
            iconButton = createButton("FH_SYS_Iconifier", FhSysButton.MINIMIZER, f);
           
            menuBar.add(closeButton, QueueLayout.END);
            menuBar.add(restoreButton, QueueLayout.END);
            menuBar.add(iconButton, QueueLayout.END);

            switchMenu = new JMenu("[ Switch to ]");
            switchMenu.setIcon(new FhSysButton(FhSysButton.ARROW_SOUTH).getIcon());
            switchMenu.setName("FH_SYS_Switcher");
           
            menuBar.add(switchMenu, QueueLayout.END);
           
            menuBar.validate();
        }
        
        if(((JInternalFrame)f).isMaximizable()) restoreButton.setVisible(true);
        if(((JInternalFrame)f).isIconifiable()) iconButton.setVisible(true);
        if(((JInternalFrame)f).isClosable()) closeButton.setVisible(true);
        
        switchMenu.removeAll();
        
        ButtonGroup group = new ButtonGroup();
        
        for(int i=0; i < f.getParent().getComponentCount(); i++){
            if(f.getParent().getComponent(i) instanceof JInternalFrame){
                CustomRadioButtonMenuItem rmi = new CustomRadioButtonMenuItem(((JInternalFrame)f.getParent().getComponent(i)).getTitle(), f == f.getParent().getComponent(i));
                group.add(rmi);
                switchMenu.add(rmi);
                rmi.addActionListener(actionHandler);
                rmi.setFrame((JInternalFrame)f.getParent().getComponent(i));
            }
            else if(f.getParent().getComponent(i) instanceof JInternalFrame.JDesktopIcon){
                CustomRadioButtonMenuItem rmi = new CustomRadioButtonMenuItem(((JInternalFrame.JDesktopIcon)f.getParent().getComponent(i)).getInternalFrame().getTitle(), f == f.getParent().getComponent(i));
                group.add(rmi);
                switchMenu.add(rmi);
                rmi.addActionListener(actionHandler);
                rmi.setFrame(((JInternalFrame.JDesktopIcon)f.getParent().getComponent(i)).getInternalFrame());
            } 
        }
        
        showingButtons = true;
    }
    
    protected class ActionHandler implements ActionListener{
        public void actionPerformed(ActionEvent ae){
            if(ae.getSource() instanceof CustomFhSysButton){

                // restore maximized frame
                if("FH_SYS_Restorer".equals(((CustomFhSysButton)ae.getSource()).getName())){
                    JInternalFrame f = ((CustomFhSysButton)ae.getSource()).getFrame();
                    hideButtonsOnMenuBar(findClosestMenubar(f), f);

                    try{
                        f.setMaximum(false);
                    }
                    catch(Exception e){
                    }
                    
                    ensureValidBounds(f);
                }
                
                // closes maximized frame 
                else if("FH_SYS_Closer".equals(((CustomFhSysButton)ae.getSource()).getName())){
                    JInternalFrame f = ((CustomFhSysButton)ae.getSource()).getFrame();

                    ensureValidBounds(f);

                    closeFrame(f);
                }

                // iconifies maximized frame
                else if("FH_SYS_Iconifier".equals(((CustomFhSysButton)ae.getSource()).getName())){
                    JInternalFrame f = ((CustomFhSysButton)ae.getSource()).getFrame();
                    hideButtonsOnMenuBar(findClosestMenubar(f), f);

                    try{
                        f.setIcon(true);
                    }
                    catch(Exception e){
                    }

                    ensureValidBounds(f);
               }
            }
            
            if(ae.getSource() instanceof CustomRadioButtonMenuItem){
                JInternalFrame f = ((CustomRadioButtonMenuItem)ae.getSource()).getFrame();

                try{
                    // deaconify if necessary
                    if(f.getParent() == null) f.setIcon(false);
                    
                    // restore all frames
                    for(int i = 0; i < f.getParent().getComponentCount(); i++) {
                        if(f.getParent().getComponent(i) instanceof JInternalFrame){
                            if(f != f.getParent().getComponent(i) && ((JInternalFrame)f.getParent().getComponent(i)).isMaximum()){
                                ((JInternalFrame)f.getParent().getComponent(i)).setMaximum(false); 
                            }
                        }
                    }
                    
                    // focus on frame
                    activateFrame(f);
                    showButtonsOnMenuBar(findClosestMenubar(f), f);
                }
                catch(Exception e){
                    e.printStackTrace();
                }
            }    
        }
    }
    
    
    /**
     * if frames are out of the desktop bounds gives them valid boundaries
     */
    protected void ensureValidBounds(JComponent jc){
        if(jc.getParent() == null) return;
        
        for(int i = 0; i < jc.getParent().getComponentCount(); i++){
            if(jc.getParent().getComponent(i) instanceof JInternalFrame && ((JInternalFrame)jc.getParent().getComponent(i)).isMaximum()) continue;
                
            Rectangle r = jc.getParent().getComponent(i).getBounds();
            
            if(r.x +r.width < 50) jc.getParent().getComponent(i).setLocation(0, r.y);
            if(r.y +10 < 0) jc.getParent().getComponent(i).setLocation(r.x, 0); 
        }
    }
    
    protected CustomFhSysButton createButton(String name, int type, JInternalFrame f){
        CustomFhSysButton button = new CustomFhSysButton(type);
        
        button.setRolloverEnabled(true);
        button.setName(name);
        button.setIcon(new FhSysIcon(type));
        button.setVisible(false);
        button.addActionListener(actionHandler);
        button.setPreferredSize(new Dimension(13, 13));
        button.setFrame(f);
        
        return button;
    } 
    
    protected class CustomRadioButtonMenuItem extends JRadioButtonMenuItem{
        private JInternalFrame frame = null;

        public CustomRadioButtonMenuItem(String text, boolean selected) {
            super(text, selected);
        }

        public JInternalFrame getFrame() {
            return frame;
        }

        public void setFrame(JInternalFrame frame) {
            this.frame = frame;
        }
    }
        
    protected class CustomFhSysButton extends FhSysButton{
        private JInternalFrame frame = null;
        
        public CustomFhSysButton(int type){
            super(type);
        }

        public CustomFhSysButton(int type, int extraInset) {
            super(type, extraInset);
        }

        public JInternalFrame getFrame() {
            return frame;
        }

        public void setFrame(JInternalFrame frame) {
            this.frame = frame;
        }
    }

    public void activateFrame(JInternalFrame frame){
        frame.getParent().removeContainerListener(this);
        
        if(showingButtons && frame.isMaximizable()){
            try{
                frame.setMaximum(true);
            }
            catch(Exception ex){
            }
        }
    
        super.activateFrame(frame);

        frame.getParent().addContainerListener(this);
    }
    
    public void componentAdded(ContainerEvent e){
        Component child = e.getChild();

        if(child instanceof JInternalFrame){
            activateFrame((JInternalFrame)child);
            if(((JInternalFrame)child).isMaximum()) setBoundsForFrame(((JInternalFrame)child), 0, 0, 0, 0);
        }
    }

    public void componentRemoved(ContainerEvent e){
        if(showingButtons && e.getContainer() instanceof JDesktopPane){
            JDesktopPane dp = (JDesktopPane)e.getContainer();
            JInternalFrame[] frames = dp.getAllFrames();
            
            try{
                activateFrame(frames[frames.length -1]);
            }
            catch(Exception ex){
                hideButtonsOnMenuBar(findClosestMenubar(dp), null);
            }
        }
    }
}
