/*
 * 
 * Created on 2004-jul-25
 * 
 * @author Robert Karlsson
 * @version 1.0
 *
 */
package se.diod.hippo.plaf.renderer;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Rectangle;

import javax.swing.JTabbedPane;
import javax.swing.UIManager;




/**
 * 
 * @author Robert Karlsson
 * @created 2004-jul-25
 *
 */
public class TabRendererTop extends AbstractRenderer {




	/**
	 * 
	 * 
	 */
	public TabRendererTop( JTabbedPane tabPane ) {
		super( tabPane );
	}




	/**
	 * 
	 * 
	 */
	public Insets getContentBorderInsets( Insets defaultInsets ) {
		return NORTH_INSETS;
	}




	/**
	 * 
	 * Minimal decoration: no focus
	 * 
	 */
	public void paintFocusIndicator( Graphics g, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected) {
	}




	/**
	 * 
	 * 
	 */
	public void paintTabBackground( Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected ) {
		if( isSelected ) {
			//g.setColor( new java.awt.Color( 158, 179, 193 ) );
			g.setColor( new java.awt.Color( 198, 209, 223 ) );  // TODO FIXED COLOR, BIG NONO!
		} else {
			g.setColor( UIManager.getColor("TabbedPane.background") );
		}

		g.fillRect(x, y, w, h);
	}




	/**
	 * 
	 * 
	 */
	public void paintTabBorder( Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected ) {
		g.translate( x, y );
		g.setColor( Color.GRAY);  // TODO FIXED COLOR, BIG NONO!

		int right  = w;
		int bottom = h;

		if( isTabFirstDisplayed( tabIndex ) ) {
			if( isSelected ) {
				// OUTER LINE
				// Selected and first in line
				g.fillRect(1, 0, w, 1);								// Top
				g.fillRect(right, 0, 1, bottom);					// Right
				g.fillRect( 0, 0, 1, bottom);						// Left
			} else {
				//g.fillRect(0, 0, w, 1);								// Top
			}
		} else {
			if( isSelected ) {
				// OUTER LINE
				//g.setColor( colShadow );
				g.fillRect(1, 0, w, 1);								// Top
				g.fillRect(right, 0, 1, bottom );					// Right
				g.fillRect(0, 0, 1, bottom);						// Left
			} else {
				//g.setColor( colShadow );
				g.setColor( Color.GRAY );  // TODO FIXED COLOR, BIG NONO!
				//g.fillRect(0, 0, w, 1);								// Top
				g.fillRect( 0, 4, 1, bottom - 6 );				// Left
			}
		}

		g.translate(-x, -y);
	}
}
