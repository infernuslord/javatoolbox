/*
 * Please see COPYING for license details
 *
 * Copyright (C) 2003 Raghu K, All rights reserved.
 */

package hamsam.protocol.yahoo;

/**
 * This interface defines various constants used by the Yahoo protocol.
 *
 * @author Raghu
 */
public interface Constants
{
	/**
	 * Status indicator for "I'm available".
	 */
	long STATUS_AVAILABLE = 0x00;

	/**
	 * Status indicator for "Be Right Back".
	 */
	long STATUS_BRB = 1;

	/**
	 * Status indicator for "Busy".
	 */
	long STATUS_BUSY = 2;

	/**
	 * Status indicator for "Not At Home".
	 */
	long STATUS_NOTATHOME = 3;

	/**
	 * Status indicator for "Not At My Desk".
	 */
	long STATUS_NOTATDESK = 4;

	/**
	 * Status indicator for "Not In The Office".
	 */
	long STATUS_NOTINOFFICE = 5;

	/**
	 * Status indicator for "On The Phone".
	 */
	long STATUS_ONPHONE = 6;

	/**
	 * Status indicator for "On Vacation".
	 */
	long STATUS_ONVACATION = 7;

	/**
	 * Status indicator for "Out To Lunch".
	 */
	long STATUS_OUTTOLUNCH = 8;

	/**
	 * Status indicator for "Stepped Out".
	 */
	long STATUS_STEPPEDOUT = 9;

	/**
	 * Status indicator for invisible mode.
	 */
	long STATUS_INVISIBLE = 12;

	/**
	 * Status indicator for going offline.
	 */
	long STATUS_OFFLINE = 0x5a55aa56;

	/**
	 * Status indicator for typing notifications.
	 */
	long STATUS_TYPING = 0x16;

	/**
	 * Status indicator that is used for custom status messages.
	 */
	long STATUS_CUSTOM = 99;

	/**
	 * Service type used to change from an available status to an away status.
	 */
	int SERVICE_ISAWAY = 0x03;

	/**
	 * Service type used to change from an away status to an available status.
	 */
	int SERVICE_ISBACK = 0x04;

	/**
	 * Indicates logon by a user.
	 */
	int SERVICE_LOGON = 0x01;

	/**
	 * Indicates logoff by a user.
	 */
	int SERVICE_LOGOFF = 0x02;

	int YAHOO_SERVICE_IDLE = 0x05; /* 5 (placemarker) */

	/**
	 * Service type used to send and receive instant messages.
	 */
	int SERVICE_MESSAGE = 0x06;

	/**
	 * A yahoo ID is activated.
	 */
	int SERVICE_IDACT = 0x07;

	/**
	 * A yahoo ID got deactivated.
	 */
	int SERVICE_IDDEACT = 0x08;

	int YAHOO_SERVICE_MAILSTAT = 0x09;

	/**
	 * Indicates a change in status of a user.
	 */
	int SERVICE_USERSTAT = 0x0a;

	/**
	 * A new mail notification.
	 */
	int SERVICE_NEWMAIL = 0x0b;
	int YAHOO_SERVICE_CHATINVITE = 0x0c;
	int YAHOO_SERVICE_CALENDAR = 0x0d;
	int YAHOO_SERVICE_NEWPERSONALMAIL = 0x0e;

	/**
	 * Indicates a change in buddy list.
	 */
	int SERVICE_NEWCONTACT = 0x0f;
	int YAHOO_SERVICE_ADDIDENT = 0x10;
	int YAHOO_SERVICE_ADDIGNORE = 0x11;

	/**
	 * Used in keep alive packets.
	 */
	int SERVICE_PING = 0x12;
	int YAHOO_SERVICE_GROUPRENAME = 0x13;

	/**
	 * A system message by Yahoo.
	 */
	int SERVICE_SYSMESSAGE = 0x14;
	int YAHOO_SERVICE_PASSTHROUGH2 = 0x16;

	/**
	 * Service type for inviting buddies to a conference.
	 */
	int SERVICE_CONFINVITE = 0x18;

	/**
	 * A buddy login to the a conference.
	 */
	int SERVICE_CONFLOGON = 0x19;

	/**
	 * A buddy decline to join a conference.
	 */
	int SERVICE_CONFDECLINE = 0x1a;

	/**
	 * Service type used to logoff from a conference.
	 */
	int SERVICE_CONFLOGOFF = 0x1b;

	/**
	 * Invitation for a conference.
	 */
	int SERVICE_CONFADDINVITE = 0x1c;

	/**
	 * An instant message for a conference.
	 */
	int SERVICE_CONFMSG = 0x1d;
	int YAHOO_SERVICE_CHATLOGON = 0x1e;
	int YAHOO_SERVICE_CHATLOGOFF = 0x1f;
	int YAHOO_SERVICE_CHATMSG = 0x20;
	int YAHOO_SERVICE_GAMELOGON = 0x28;
	int YAHOO_SERVICE_GAMELOGOFF = 0x29;
	int YAHOO_SERVICE_GAMEMSG = 0x2a;
	int YAHOO_SERVICE_FILETRANSFER = 0x46;
	int YAHOO_SERVICE_VOICECHAT = 0x4a;

	/**
	 * Service type used for typing notifications.
	 */
	int SERVICE_NOTIFY = 0x4b;

	int YAHOO_SERVICE_P2PFILEXFER = 0x4d;
	int YAHOO_SERVICE_PEERTOPEER = 0x4f;	/* Checks if P2P possible */

	/**
	 * Yahoo responds to an authentication.
	 */
	int SERVICE_AUTHRESP = 0x54;

	/**
	 * Get the buddy list and ignore list.
	 */
	int SERVICE_LIST = 0x55;

	/**
	 * Yahoo requests for password authentication.
	 */
	int SERVICE_AUTH = 0x57;

	/**
	 * Service type used to add a buddy to the buddy list.
	 */
	int SERVICE_ADDBUDDY = 0x83;

	/**
	 * Service type used to remove a buddy from the buddy list.
	 */
	int SERVICE_REMBUDDY = 0x84;

	/**
	 * Service type used to ignore a buddy.
	 */
	int SERVICE_IGNOREBUDDY = 0x85;

	/**
	 * Service type used to reject a buddy add request.
	 */
	int SERVICE_REJECTCONTACT = 0x86;
}
