/*
 * Please see COPYING for license details
 *
 * Copyright (C) 2003 Raghu K, All rights reserved.
 */

package hamsam.exception;

/**
 * Thrown to indicate that a method has been passed an illegal or inappropriate argument.
 */
public class IllegalArgumentException extends HamsamException
{
	/**
	 * Constructs an <code>IllegalArgumentException<code> with no detailed message.
	 */
	public IllegalArgumentException()
	{
		super();
	}

	/**
	 * Constructs an <code>IllegalArgumentException</code> with the specified detail message.
	 *
	 * @param message the detail message. The detail message is saved for later
	 *                retrieval by the Throwable.getMessage() method.
	 */
	public IllegalArgumentException(String message)
	{
		super(message);
	}
}
