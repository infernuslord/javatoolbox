/** ===================================================================
 *
 * L2FProd.com Common Components 0.1-dev License.
 *
 * Copyright (c) 2004 L2FProd.com.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by L2FProd.com
 *        (http://www.L2FProd.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "L2FProd.com Common Components", "l2fprod-common" and "L2FProd.com" must not
 *    be used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact info@L2FProd.com.
 *
 * 5. Products derived from this software may not be called "l2fprod-common"
 *    nor may "l2fprod-common" appear in their names without prior written
 *    permission of L2FProd.com.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL L2FPROD.COM OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package com.l2fprod.common.demo;

import com.l2fprod.common.swing.JDirectoryChooser;
import com.l2fprod.common.swing.JTaskPane;
import com.l2fprod.common.swing.JTaskPaneGroup;
import com.l2fprod.common.swing.LookAndFeelTweaks;

import java.awt.event.ActionEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

/**
 * FolderPage. <br>
 *  
 */
public class FolderPage extends PagePanel {

  public FolderPage(String title) {
    super(title);

    final JDirectoryChooser chooser = new JDirectoryChooser();
    chooser.setControlButtonsAreShown(false);

    JPanel selectedFolderPanel =
      new JPanel(LookAndFeelTweaks.createBorderLayout());
    selectedFolderPanel.add(
      "West",
      new JLabel(Main.RESOURCE.getString("Main.folder.selected")));
    final JTextField textfield;
    selectedFolderPanel.add("Center", textfield = new JTextField());

    PropertyChangeListener listener = new PropertyChangeListener() {
      public void propertyChange(PropertyChangeEvent evt) {
        textfield.setText(
          chooser.getSelectedFile() == null
            ? ""
            : chooser.getSelectedFile().getAbsolutePath());
      }
    };

    chooser.addPropertyChangeListener(
      JDirectoryChooser.SELECTED_FILE_CHANGED_PROPERTY,
      listener);

    JTaskPane taskPane = new JTaskPane();

    // "System" GROUP
    JTaskPaneGroup systemGroup = new JTaskPaneGroup();
    systemGroup.setText(Main.RESOURCE.getString("Main.tasks.systemGroup"));
    systemGroup.setToolTipText(
      Main.RESOURCE.getString("Main.tasks.systemGroup.tooltip"));
    systemGroup.setSpecial(true);
    systemGroup.setIcon(
      new ImageIcon(FolderPage.class.getResource("icons/tasks-email.png")));

    systemGroup.add(
      makeAction(
        Main.RESOURCE.getString("Main.tasks.email"),
        "",
        "icons/tasks-email.png"));
    systemGroup.add(
      makeAction(
        Main.RESOURCE.getString("Main.tasks.delete"),
        "",
        "icons/tasks-recycle.png"));

    taskPane.add(systemGroup);

    // "Office" GROUP
    JTaskPaneGroup officeGroup = new JTaskPaneGroup();
    officeGroup.setText(Main.RESOURCE.getString("Main.tasks.office"));
    officeGroup.add(
      makeAction(
        Main.RESOURCE.getString("Main.tasks.word"),
        "",
        "icons/tasks-writedoc.png"));
    officeGroup.setExpanded(false);
    taskPane.add(officeGroup);

    // "SEE ALSO" GROUP and ACTIONS
    JTaskPaneGroup seeAlsoGroup = new JTaskPaneGroup();
    seeAlsoGroup.setText(Main.RESOURCE.getString("Main.tasks.seealso"));

    seeAlsoGroup.add(
      makeAction(
        "The Internet",
        Main.RESOURCE.getString("Main.tasks.internet.tooltip"),
        "icons/tasks-internet.png"));

    seeAlsoGroup.add(
      makeAction(
        Main.RESOURCE.getString("Main.tasks.help"),
        Main.RESOURCE.getString("Main.tasks.help.tooltip"),
        "icons/tasks-question.png"));
    taskPane.add(seeAlsoGroup);

    // "Details" GROUP
    JTaskPaneGroup detailsGroup = new JTaskPaneGroup();
    detailsGroup.setText(Main.RESOURCE.getString("Main.tasks.details"));

    JEditorPane detailsText = new JEditorPane("text/html", "<html>");
    LookAndFeelTweaks.makeMultilineLabel(detailsText);
    LookAndFeelTweaks.htmlize(detailsText);
    detailsText.setText(Main.RESOURCE.getString("Main.tasks.details.message"));
    detailsGroup.add(detailsText);

    taskPane.add(detailsGroup);

    JScrollPane scroll = new JScrollPane(taskPane);
    scroll.setBorder(null);

    JPanel panel = new JPanel(LookAndFeelTweaks.createBorderLayout());
    panel.add("Center", chooser);
    panel.add("West", scroll);
    
    add(panel, "*");
    add(selectedFolderPanel);
  }

  Action makeAction(String title, String tooltiptext, String iconPath) {
    Action action = new AbstractAction(title) {
      public void actionPerformed(ActionEvent e) {
      }
    };
    action.putValue(
      Action.SMALL_ICON,
      new ImageIcon(FolderPage.class.getResource(iconPath)));
    action.putValue(Action.SHORT_DESCRIPTION, tooltiptext);
    return action;
  }

}
