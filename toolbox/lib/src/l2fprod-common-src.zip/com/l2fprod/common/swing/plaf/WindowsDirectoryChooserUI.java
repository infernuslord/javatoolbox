/** ===================================================================
 *
 * @PROJECT.FULLNAME@ @VERSION@ License.
 *
 * Copyright (c) @YEAR@ L2FProd.com.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by L2FProd.com
 *        (http://www.L2FProd.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "@PROJECT.FULLNAME@", "@PROJECT.SHORTNAME@" and "L2FProd.com" must not
 *    be used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact info@L2FProd.com.
 *
 * 5. Products derived from this software may not be called "@PROJECT.SHORTNAME@"
 *    nor may "@PROJECT.SHORTNAME@" appear in their names without prior written
 *    permission of L2FProd.com.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL L2FPROD.COM OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package com.l2fprod.common.swing.plaf;

import com.l2fprod.common.swing.JDirectoryChooser;
import com.l2fprod.common.swing.LookAndFeelTweaks;
import com.l2fprod.common.swing.tree.LazyMutableTreeNode;
import com.l2fprod.common.util.ResourceManager;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.filechooser.FileSystemView;
import javax.swing.filechooser.FileView;
import javax.swing.plaf.basic.BasicFileChooserUI;
import javax.swing.text.JTextComponent;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

/**
 * WindowsDirectoryChooserUI. <br>
 *  
 */
public class WindowsDirectoryChooserUI
  extends BasicFileChooserUI
  implements DirectoryChooserUI {

  private JDirectoryChooser chooser;
  private JTextComponent message;
  private JTree tree;
  private JScrollPane treeScroll;
  private JButton approveButton;
  private JButton cancelButton;
  private JPanel buttonPanel;
  private PropertyChangeListener listener;
  private BasicFileView fileView = new WindowsFileView();
  private Action approveSelectionAction = new ApproveSelectionAction();

  public WindowsDirectoryChooserUI(JDirectoryChooser chooser) {
    super(chooser);
  }

  public void rescanCurrentDirectory(JFileChooser fc) {
    super.rescanCurrentDirectory(fc);
    findFile(chooser.getCurrentDirectory(), true, true);
  }

  public void ensureFileIsVisible(JFileChooser fc, File f) {
    super.ensureFileIsVisible(fc, f);
    findFile(f, false, false);
  }

  protected String getToolTipText(MouseEvent event) {
    TreePath path = tree.getPathForLocation(event.getX(), event.getY());
    if (path != null && path.getLastPathComponent() instanceof FileTreeNode) {
      FileTreeNode node = (FileTreeNode)path.getLastPathComponent();
      String typeDescription =
        getFileView(chooser).getTypeDescription(node.getFile());
      if (typeDescription == null || typeDescription.length() == 0) {
        return node.toString();
      } else {
        return "<html> " + node.toString() + "<br> " + typeDescription;
      }
    } else {
      return null;
    }
  }

  public void installComponents(JFileChooser chooser) {
    this.chooser = (JDirectoryChooser)chooser;

    chooser.setBorder(LookAndFeelTweaks.WINDOW_BORDER);
    chooser.setLayout(LookAndFeelTweaks.createBorderLayout());
    chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

    Component accessory = chooser.getAccessory();
    if (accessory != null) {
      chooser.add("North", chooser.getAccessory());
    }

    tree = new JTree() {
      public String getToolTipText(MouseEvent event) {
        String tip = WindowsDirectoryChooserUI.this.getToolTipText(event);
        if (tip == null) {
          return super.getToolTipText(event);
        } else {
          return tip;
        }
      }
    };

    tree.setModel(new FileSystemTreeModel(chooser.getFileSystemView()));
    tree.setRootVisible(false);
    tree.setShowsRootHandles(false);
    tree.setCellRenderer(new FileSystemTreeRenderer());
    tree.setToolTipText("");

    chooser.add("Center", treeScroll = new JScrollPane(tree));
    treeScroll.setPreferredSize(new Dimension(300, 300));

    approveButton = new JButton();
    approveButton.setAction(getApproveSelectionAction());

    cancelButton = new JButton();
    cancelButton.addActionListener(getCancelSelectionAction());

    buttonPanel = new JPanel(LookAndFeelTweaks.createButtonAreaLayout());
    buttonPanel.add(approveButton);
    buttonPanel.add(cancelButton);
    chooser.add("South", buttonPanel);

    updateView(chooser);
  }

  protected void installStrings(JFileChooser fc) {
    super.installStrings(fc);

    saveButtonToolTipText =
      ResourceManager.get(DirectoryChooserUI.class).getString(
        "DirectoryChooser.saveButtonToolTipText");
    openButtonToolTipText =
      ResourceManager.get(DirectoryChooserUI.class).getString(
        "DirectoryChooser.openButtonToolTipText");
    cancelButtonToolTipText =
      ResourceManager.get(DirectoryChooserUI.class).getString(
        "DirectoryChooser.cancelButtonToolTipText");
  }

  public void uninstallComponents(JFileChooser chooser) {
    chooser.remove(message);
    chooser.remove(treeScroll);
    chooser.remove(buttonPanel);
  }

  public FileView getFileView(JFileChooser fc) {
    return fileView;
  }

  protected void installListeners(JFileChooser fc) {
    super.installListeners(fc);

    tree.addTreeSelectionListener(new SelectionListener());
  }

  protected void uninstallListeners(JFileChooser fc) {
    super.uninstallListeners(fc);
  }

  public PropertyChangeListener createPropertyChangeListener(JFileChooser fc) {
    return new ChangeListener();
  }

  private void updateView(JFileChooser chooser) {
    if (chooser.getApproveButtonText() != null) {
      approveButton.setText(chooser.getApproveButtonText());
      approveButton.setMnemonic(chooser.getApproveButtonMnemonic());
    } else {
      if (JFileChooser.OPEN_DIALOG == chooser.getDialogType()) {
        approveButton.setText(openButtonText);
        approveButton.setToolTipText(openButtonToolTipText);
        approveButton.setMnemonic(openButtonMnemonic);
      } else {
        approveButton.setText(saveButtonText);
        approveButton.setToolTipText(saveButtonToolTipText);
        approveButton.setMnemonic(saveButtonMnemonic);
      }
    }

    cancelButton.setText(cancelButtonText);
    cancelButton.setMnemonic(cancelButtonMnemonic);
  }

  /**
   * Ensures the file is visible, tree expanded and optionally selected
   * 
   * @param file
   * @param selectFile
   */
  private void findFile(File file, boolean selectFile, boolean reload) {
    if (file == null || !file.isDirectory()) {
      return;
    }

    try {
      file = file.getCanonicalFile();
    } catch (IOException e) {
      e.printStackTrace();
      return;
    }

    List files = new ArrayList();
    files.add(file);
    while ((file = chooser.getFileSystemView().getParentDirectory(file))
      != null) {
      files.add(0, file);
    }

    List path = new ArrayList();

    DefaultMutableTreeNode node =
      (DefaultMutableTreeNode)tree.getModel().getRoot();
    path.add(node);

    DefaultMutableTreeNode current;

    boolean found = true;

    while (files.size() > 0 && found) {
      found = false;
      for (int i = 0, c = node.getChildCount(); i < c; i++) {
        current = (DefaultMutableTreeNode)node.getChildAt(i);
        File f = ((FileTreeNode)current).getFile();
        if (files.get(0).equals(f)) {
          path.add(current);
          files.remove(0);
          node = current;
          found = true;
          break;
        }
      }
    }

    TreePath pathToSelect = new TreePath(path.toArray());
    if (pathToSelect.getLastPathComponent() instanceof FileTreeNode) {
      ((FileTreeNode) (pathToSelect.getLastPathComponent())).clear();
    }
    tree.expandPath(pathToSelect);
    tree.scrollPathToVisible(pathToSelect);

    if (selectFile) {
      tree.setSelectionPath(pathToSelect);
    }
  }

  private class ChangeListener implements PropertyChangeListener {
    public void propertyChange(PropertyChangeEvent evt) {
      if (JFileChooser
        .APPROVE_BUTTON_TEXT_CHANGED_PROPERTY
        .equals(evt.getPropertyName())) {
        updateView(chooser);
      }

      if (JFileChooser
        .MULTI_SELECTION_ENABLED_CHANGED_PROPERTY
        .equals(evt.getPropertyName())) {
        if (chooser.isMultiSelectionEnabled()) {
          tree.getSelectionModel().setSelectionMode(
            TreeSelectionModel.DISCONTIGUOUS_TREE_SELECTION);
        } else {
          tree.getSelectionModel().setSelectionMode(
            TreeSelectionModel.SINGLE_TREE_SELECTION);
        }
      }

      if (JFileChooser
        .DIRECTORY_CHANGED_PROPERTY
        .equals(evt.getPropertyName())) {
        findFile(chooser.getCurrentDirectory(), false, false);
      }

      if (JFileChooser
        .ACCESSORY_CHANGED_PROPERTY
        .equals(evt.getPropertyName())) {
        Component oldValue = (Component)evt.getOldValue();
        Component newValue = (Component)evt.getNewValue();
        if (oldValue != null) {
          chooser.remove(oldValue);
        }
        if (newValue != null) {
          chooser.add("North", newValue);
        }
        chooser.revalidate();
        chooser.repaint();
      }
    }

  }

  private class SelectionListener implements TreeSelectionListener {
    public void valueChanged(TreeSelectionEvent e) {
      getApproveSelectionAction().setEnabled(tree.getSelectionCount() > 0);
    }
  }

  public Action getApproveSelectionAction() {
    return approveSelectionAction;
  }

  private class ApproveSelectionAction extends AbstractAction {
    public ApproveSelectionAction() {
      setEnabled(false);
    }
    public void actionPerformed(ActionEvent e) {
      TreePath[] selectedPaths = tree.getSelectionPaths();
      if (selectedPaths == null || selectedPaths.length == 0) {
        return;
      }

      List files = new ArrayList();
      for (int i = 0, c = selectedPaths.length; i < c; i++) {
        File f =
          ((FileTreeNode)selectedPaths[i].getLastPathComponent()).getFile();
        files.add(f);
      }

      chooser.setSelectedFiles((File[])files.toArray(new File[0]));
      chooser.approveSelection();
    }
  }

  private class FileSystemTreeRenderer extends DefaultTreeCellRenderer {
    public Component getTreeCellRendererComponent(
      JTree tree,
      Object value,
      boolean sel,
      boolean expanded,
      boolean leaf,
      int row,
      boolean hasFocus) {
      super.getTreeCellRendererComponent(
        tree,
        value,
        sel,
        expanded,
        leaf,
        row,
        hasFocus);

      if (value instanceof FileTreeNode) {
        FileTreeNode node = (FileTreeNode)value;
        setText(getFileView(chooser).getName(node.getFile()));
        setIcon(getFileView(chooser).getIcon(node.getFile()));
      } else {
      }

      return this;
    }
  }

  private class FileSystemTreeModel extends DefaultTreeModel {
    public FileSystemTreeModel(FileSystemView fsv) {
      super(new MyComputerTreeNode(fsv));
    }
  }

  private class MyComputerTreeNode extends LazyMutableTreeNode {
    public MyComputerTreeNode(FileSystemView fsv) {
      super(fsv);
    }
    protected void loadChildren() {
      FileSystemView fsv = (FileSystemView)getUserObject();
      File[] roots = fsv.getRoots();
      for (int i = 0, c = roots.length; i < c; i++) {
        add(new FileTreeNode(roots[i]));
      }
    }
    public String toString() {
      return "/";
    }
  }

  private class FileTreeNode extends LazyMutableTreeNode {
    public FileTreeNode(File file) {
      super(file);
    }
    public boolean isLeaf() {
      if (!isLoaded() && chooser.getFileSystemView().isFloppyDrive(getFile())) {
        return false;
      } else {
        return super.isLeaf();
      }
    }
    protected void loadChildren() {
      File[] children =
        chooser.getFileSystemView().getFiles(
          getFile(),
          chooser.isFileHidingEnabled());
      if (children != null) {
        // sort the File alphabetically based on their "display name"
        // TODO: sort files
        for (int i = 0, c = children.length; i < c; i++) {
          if (children[i].isDirectory()) {
            add(new FileTreeNode(children[i]));
          }
        }
      }
    }
    public File getFile() {
      return (File)getUserObject();
    }
    public String toString() {
      return chooser.getFileSystemView().getSystemDisplayName(
        (File)getUserObject());
    }
    public void clear() {
      super.clear();
      ((DefaultTreeModel)tree.getModel()).nodeStructureChanged(this);
    }
  }

  /**
   * From WindowsFileChooserUI
   */
  protected class WindowsFileView extends BasicFileView {
    public Icon getIcon(File f) {
      Icon icon = getCachedIcon(f);
      if (icon != null) {
        return icon;
      }
      if (f != null) {
        icon = getFileChooser().getFileSystemView().getSystemIcon(f);
      }
      if (icon == null) {
        icon = super.getIcon(f);
      }
      cacheIcon(f, icon);
      return icon;
    }
  }

}
