// Copyright 2002, 2003 Elliotte Rusty Harold
// 
// This library is free software; you can redistribute 
// it and/or modify it under the terms of version 2.1 of 
// the GNU Lesser General Public License as published by  
// the Free Software Foundation.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General 
// Public License along with this library; if not, write to the 
// Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
// Boston, MA  02111-1307  USA
// 
// You can contact Elliotte Rusty Harold by sending e-mail to
// elharo@metalab.unc.edu. Please include the word "XOM" in the
// subject line. The XOM home page is temporarily located at
// http://www.cafeconleche.org/XOM/  but will eventually move
// to http://www.xom.nu/

package nu.xom.tests;

import junit.framework.Assert;
import junit.framework.TestCase;

import nu.xom.Element;
import nu.xom.IllegalDataException;
import nu.xom.IllegalTargetException;
import nu.xom.ProcessingInstruction;

public class ProcessingInstructionTest extends TestCase {

    public ProcessingInstructionTest() {
        super("Processing Instruction tests");
    }

    public ProcessingInstructionTest(String name) {
        super(name);
    }

    public void testConstructor() {
        ProcessingInstruction c1 = new ProcessingInstruction("test", "test");

        Assert.assertEquals(c1.getValue(), "test");
        Assert.assertEquals(c1.getTarget(), "test");

        try {
          ProcessingInstruction pi = new ProcessingInstruction("test:test", "test");
          fail("Processing instruction targets cannot contain colons");
        }
        catch (IllegalTargetException success) {}
        try {
          ProcessingInstruction pi = new ProcessingInstruction("", "test");
          fail("Processing instruction targets cannot be empty");
        }
        catch (IllegalTargetException success) {}
        try {
           ProcessingInstruction pi = new ProcessingInstruction(null, "test");
           fail("Processing instruction targets cannot be empty");
         }
         catch (IllegalTargetException success) {}
        try {
           ProcessingInstruction pi = new ProcessingInstruction("12345", "test");
           fail("Processing instruction targets must be NCNames");
         }
         catch (IllegalTargetException success) {}
        ProcessingInstruction pi2 = new ProcessingInstruction("test", "");

     }

    public void testSetter() {

        ProcessingInstruction c1 = new ProcessingInstruction("test", "test");
        try {
          c1.setValue("kjsahdj ?>");
          fail("Should raise an IllegalDataException");
        }
        catch (IllegalDataException success) {}
        try {
          c1.setValue("?>");
          fail("Should raise an IllegalDataException");
        }
        catch (IllegalDataException success) {}
        try {
          c1.setValue("kjsahdj ?> skhskjlhd");
          fail("Should raise an IllegalDataException");
        }
        catch (IllegalDataException success) {}

        // These should all work
        String[] testData = {"<html></html>",
          "name=value",
          "name='value'",
          "name=\"value\"",
          "salkdhsalkjhdkjsadhkj sadhsajkdh",
            "<?", "? >", " -- "
        };
        for (int i = 0; i < testData.length; i++) {
          c1.setValue(testData[i]);
          Assert.assertEquals(c1.getValue(), testData[i]);
        }

     }

    public void testNames() {
        ProcessingInstruction c1 = new ProcessingInstruction("test", "afaf");
        Assert.assertEquals(c1.getTarget(), "test");
     }


    public void testEquals() {
        ProcessingInstruction c1 = new ProcessingInstruction("test", "afaf");
        ProcessingInstruction c2 = new ProcessingInstruction("test", "afaf");
        ProcessingInstruction c3 = new ProcessingInstruction("tegggst", "afaf");
        ProcessingInstruction c4 = new ProcessingInstruction("test", "1234");

        Assert.assertEquals(c1, c1);
        Assert.assertEquals(c1.hashCode(), c1.hashCode());
        Assert.assertTrue(!c1.equals(c2));
        Assert.assertTrue(!c1.equals(c3));
        Assert.assertTrue(!c3.equals(c4));
        Assert.assertTrue(!c2.equals(c4));
        Assert.assertTrue(!c2.equals(c3));
    }

    public void testClone() {
        Element test = new Element("test");
        ProcessingInstruction c1 = new ProcessingInstruction("test", "afaf");
        test.appendChild(c1);
        ProcessingInstruction c2 = (ProcessingInstruction) c1.copy();

        Assert.assertEquals(c1.getValue(), c2.getValue());
        Assert.assertTrue(!c1.equals(c2));
        Assert.assertNull(c2.getParent());

    }

    // Check passing in a string with broken surrogate pairs
    // and with correct surrogate pairs
    public void testSurrogates() {

        String goodString = "test: \uD8F5\uDF80  ";
        ProcessingInstruction pi = new ProcessingInstruction("test", goodString);
        Assert.assertEquals(goodString, pi.getValue());

    }

    public void testLeafNode() {

        ProcessingInstruction c1 = new ProcessingInstruction("test", "data");
        Assert.assertEquals(c1.getChildCount(), 0);
        Assert.assertTrue(!c1.hasChildren());
        try {
            c1.getChild(0);
            fail("Didn't throw IndexOutofBoundsException");
        }
        catch (IndexOutOfBoundsException ex) {
            // success   
        }
        
        /*
        Assert.assertNull(c1.getPreviousSibling());
        Assert.assertNull(c1.getNextSibling()); */
        Assert.assertNull(c1.getParent());

        Element element = new Element("test");
        element.appendChild(c1); 
        Assert.assertEquals(c1.getParent(), element);
        Assert.assertEquals(c1, element.getChild(0));

        element.removeChild(c1);
        assertTrue(!element.hasChildren());

    }

}
