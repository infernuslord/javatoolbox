package tool.pdf;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.io.FileFilter;
import java.util.*;

import multivalent.ParseException;
import multivalent.std.adaptor.pdf.*;
import static multivalent.std.adaptor.pdf.COS.*;

import phelps.io.FileList;
import phelps.lang.Integers;



/**
	Uncompress.
	Removes Ascii85, Flate, LZW and so on, but not image filters.
	Marks page objects with page number, and marks other object with their use by pages.
	Prettyprints content streams.

	@version $Revision: 1.9 $ $Date: 2003/08/29 04:41:49 $
*/
public class Uncompress implements Observer {
  static final boolean DEBUG = true;

  public static final String VERSION = "2.0 of $Date: 2003/08/29 04:41:49 $";
  public static final String USAGE = "java tool.pdf.Uncompress [-exact] [-password <owner-password>] <PDF-file>";


  private String password_;
  private boolean fexact_;
  private boolean fverbose_, fquiet_;
  private PrintStream out_;

  private PDFReader pdfr_; private PDFWriter pdfw_; // for update()
  private List<Dict> pagedict_ = null;
  private List<Object> objs_;	// map object instantiation to number
  private Set[] objuse_;

  public Uncompress() {
	defaults();
  }

  public void defaults() {
	password_ = null;
	fexact_ = false;

	fverbose_ = false;
	out_ = phelps.io.PrintStreams.DEVNULL;
  }

  public void setOut(PrintStream out) { out_ = out!=null? out: phelps.io.PrintStreams.DEVNULL; }
  public void setExact(boolean b) { fexact_ = b; }


  public void uncompress(File filein, File fileout) throws IOException, ParseException {
	assert !filein.equals(fileout);

	PDFReader pdfr = new PDFReader(filein);
	pdfr.setExact(true);	// if uncompress to debug want exact not corrected
	if (pdfr.getTrailer().get("Encrypt")!=null) {
		SecurityHandler sh = pdfr.getEncrypt().getSecurityHandler();
		sh.authOwner(password_);
		if (!sh.isAuthorized()) throw new ParseException("owner password required");
		pdfr.getTrailer().remove("Encrypt");	// encrypted uncompressed useless
	}

	PDFWriter pdfw = new PDFWriter(fileout, pdfr); pdfw.setExact(fexact_);
	/*if (!fexact_)*/ pdfw.getTrailer().remove(KEY_COMPRESS);
	pdfw.setCompress(false); //pdfw.setCrunch(false);

	if (!fexact_) markupPages(pdfr, pdfw);

	pdfr_ = pdfr; pdfw_ = pdfw;
	pdfw.writePDF(this);
	pdfw.close();
	pdfr_=null; pdfw_=null;

	if (!fquiet_) {
		//if (digital signature) out_.println("reapply digital signatures");
		//if (pdfr.isRepaired()) out_.println("repaired errors");
		out_.println(fileout+" is UNCOMPRESSED"+(fexact_? "": " and prettyprinted")+" and can be edited");
	}
	if (fverbose_) {
		out_.println("file length "+filein.length()+" => "+fileout.length());
	}

	pdfr.close();
  }

  public void update(Observable obs, Object o) {
	if (fexact_) return;

	String txt = null;
	int inx;
	if ((inx = pagedict_.indexOf(o)) != -1) txt = "page "+(inx+1);
	else if ((inx = objs_.indexOf(o)) >= 1) {
		Set<Integer> l = (Set<Integer>)objuse_[inx]; int pcnt = l.size();
		if (pcnt==0) {}	// not directly referenced by page
		else if (pcnt==1) txt = "used by page "+l.iterator().next();
		else {
			int[] nums = new int[pcnt];
			int j=0; for (Iterator<Integer> i = l.iterator(); i.hasNext(); ) nums[j++] = i.next().intValue();
			txt = "used by pages "+Integers.toRange(nums);
		}
	}

	if (CLASS_DICTIONARY==o.getClass() && ((Dict)o).get(STREAM_DATA) != null) try {
		Dict dict = (Dict)o;
		if (/*compareVersion(1,5)<0) ||*/ pdfr_.getEncrypt().getCryptFilter(dict) != CryptFilter.IDENTITY) pdfw_.removeFilter(dict, "Crypt");
	} catch (IOException shouldnthappen) {}

	if (txt!=null) try { pdfw_.getRAF().write(("% "+txt+"\n").getBytes()); } catch (IOException shouldnthappen) { System.out.println("can't write: "+shouldnthappen); }
  }


  private void markupPages(PDFReader pdfr, PDFWriter pdfw) throws IOException {
	int objcnt = pdfr.getObjCnt();
	objs_ = new ArrayList<Object>(objcnt); objs_.add(OBJECT_NULL); // obj #0

	// extract objects from ObjStm, prettyprint, mark page usage
	final int pagecnt = pdfr.getPageCnt();
	pagedict_ = new ArrayList<Dict>(pagecnt);
	for (int i=0; i<pagecnt; i++) pagedict_.add((Dict)pdfw.getObject(pdfr.getPageRef(i+1)));    // pin + index for Object=>num lookup

	objuse_ = new Set[objcnt];
	for (int i=0+1; i<objcnt; i++) {
		objs_.add(pdfr.getObject(i));
		objuse_[i] = new java.util.LinkedHashSet<Integer>(5);
	}

	for (int i=0; i<pagecnt; i++) {
		IRef pageref = pdfr.getPageRef(i+1);
		pageOwner((i+1), pdfr.getObject(pageref), objuse_);
		prettyprint(pageref, pdfr, pdfw);
	}
  }

  private void pageOwner(int pagenum, Object o, Set[] objuse) {
	Class cl = o.getClass();
	if (CLASS_IREF == cl) {
		int id = ((IRef)o).id;
		objuse[id].add(Integers.getInteger(pagenum));
		// continue to recurse?
	} else if (CLASS_ARRAY == cl) for (Object oi: (Object[])o) pageOwner(pagenum, oi, objuse);
	else if (CLASS_DICTIONARY == cl) for (Iterator<Object> i = ((Dict)o).values().iterator(); i.hasNext(); ) pageOwner(pagenum, i.next(), objuse);
  }

  private void prettyprint(final Object ref, PDFReader pdfr, PDFWriter pdfw) throws IOException {
	Dict dict = (Dict)pdfr.getObject(ref);

	// contents array
	Object co = pdfw.getObject(dict.get("Contents"));
	Object[] ca = co==null? new Object[0]: CLASS_DICTIONARY==co.getClass()? new Object[] { co }: (Object[])co;
	for (int i=0,imax=ca.length; i<imax; i++) {
		Dict contents = (Dict)pdfw.getObject(ca[i]);

		try {
			Cmd[] cmds = pdfr.readCommandArray(contents);
			contents.put(STREAM_DATA, pdfw.writeCommandArray(cmds, true));
		} catch (IOException pe) {
			// object split across streams -- just don't rewrite
		}

		/*boolean fBI = false;
		if (!funcompress) for (int j=0,jmax=cmds.length; j<jmax; j++) if ("BI".equals(cmds[j].op)) { fBI=true; break; }
		if (funcompress || fBI)*/
//System.out.print(" r/w "+ca[i]);
	}

	// Form XObject too
	Dict res = (Dict)pdfr.getObject(dict.get("Resources"));
	Dict xores = res!=null? (Dict)pdfr.getObject(res.get("XObject")): null;
	if (xores!=null) for (Iterator<Object> i=xores.values().iterator(); i.hasNext(); ) {
		Object o = pdfr.getObject(i.next());
		if (CLASS_DICTIONARY==o.getClass()) {
			Dict xdict = (Dict)o;
			if ("Form".equals("Subtype")) prettyprint(o, pdfr, pdfw);
		}
	}
  }


  private int commandLine(String[] argv) {
	out_ = System.out;
	fexact_ = false;

	int argi=0, argc=argv.length;
	for (String arg; argi<argc && (arg = argv[argi]).startsWith("-"); argi++) {
		if (arg.equals("-password")) password_ = argv[++argi];
		else if (arg.equals("-exact")) fexact_ = true;

		else if (arg.startsWith("-verb")) fverbose_ = true;
		else if (arg.startsWith("-q"/*uiet*/)) fquiet_ = true;
		else if (arg.startsWith("-v"/*ersion -- after verbose!*/)) { System.out.println(VERSION); System.exit(0); }
		else if (arg.startsWith("-h"/*"elp"*/)) { System.out.println(USAGE); System.exit(0); }
		else { System.err.println("Unknown option: "+arg); System.err.println(USAGE); System.exit(1); }
	}

	if (argi == argc) { System.err.println(USAGE); System.exit(0); }

	return argi;
  }

  public static void main(String[] argv) throws IOException {
    // make machine for uncompressing PDFs with given parameters
	Uncompress un = new Uncompress();
	int argi = un.commandLine(argv);

	// limit to uncompressing exactly one?
	for (Iterator<File> i = new FileList(argv, argi, FILTER).iterator(); i.hasNext(); ) {
		File filein = i.next();
		String path = filein.getPath();
		String fileout = (path.toLowerCase().endsWith(".pdf")? path.substring(0,path.length()-".pdf".length()): path) + "-u.pdf";
		try {
			un.uncompress(filein, new File(fileout));
		} catch (Exception ioe) {
			System.err.println(filein+": "+ioe);
			if (DEBUG) ioe.printStackTrace();
		}
	}
  }
}
