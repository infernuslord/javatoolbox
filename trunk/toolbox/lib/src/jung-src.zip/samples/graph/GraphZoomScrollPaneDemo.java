package samples.graph;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.graph.impl.DirectedSparseEdge;
import edu.uci.ics.jung.graph.impl.DirectedSparseGraph;
import edu.uci.ics.jung.graph.impl.DirectedSparseVertex;
import edu.uci.ics.jung.visualization.GraphDraw;
import edu.uci.ics.jung.visualization.GraphMouseListener;
import edu.uci.ics.jung.visualization.Layout;
import edu.uci.ics.jung.visualization.PluggableRenderer;
import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.contrib.GraphZoomScrollPane;

/**
 * Demonstrates the use of <code>GraphZoomScrollPane</code>.
 * This class shows off the <code>VisualizationViewer</code> zooming
 * and panning capabilities, using horizontal and
 * vertical scrollbars.
 *
 * <p>This demo also shows ToolTips on graph vertices.</p>
 * 
 * @author Tom Nelson - RABA Technologies
 * 
 */
public class GraphZoomScrollPaneDemo {

    /**
     * the graph
     */
    Graph graph;

    /**
     * the visual component of the graph visualization viewer
     */
    GraphDraw gd;

    /**
     * the visual component and renderer for the graph
     */
    VisualizationViewer vv;
    
    /**
     * create an instance of a simple graph with controls to
     * demo the zoom features.
     * 
     */
    public GraphZoomScrollPaneDemo() {
        
        // create a simple graph for the demo
        graph = new DirectedSparseGraph();
        Vertex[] v = createVertices(10);
        createEdges(v);
        gd = new GraphDraw(graph);

        vv = gd.getVisualizationViewer();
        
        gd.setRenderer(new PluggableRenderer());
        gd.addGraphMouseListener(new TestGraphMouseListener());
        
        // add my listener for ToolTips
        vv.setToolTipListener(new VertexListener(gd, 5.0));
        
        // create a frome to hold the graph
        final JFrame frame = new JFrame();
        Container content = frame.getContentPane();
        final GraphZoomScrollPane panel = new GraphZoomScrollPane(gd);
        content.add(panel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JButton plus = new JButton("+");
        plus.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panel.zoom(2.0, 2.0);
            }
        });
        JButton minus = new JButton("-");
        minus.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panel.zoom(0.5, 0.5);
            }
        });

        JPanel controls = new JPanel();
        controls.add(plus);
        controls.add(minus);
        content.add(controls, BorderLayout.SOUTH);

        frame.pack();
        frame.show();
    }
    
    /**
     * create some vertices
     * @param count how many to create
     * @return the Vertices in an array
     */
    private Vertex[] createVertices(int count) {
        Vertex[] v = new Vertex[count];
        for (int i = 0; i < count; i++) {
            v[i] = graph.addVertex(new DirectedSparseVertex());
        }
        return v;
    }

    /**
     * create edges for this demo graph
     * @param v an array of Vertices to connect
     */
    void createEdges(Vertex[] v) {
        graph.addEdge(new DirectedSparseEdge(v[0], v[1]));
        graph.addEdge(new DirectedSparseEdge(v[0], v[3]));
        graph.addEdge(new DirectedSparseEdge(v[0], v[4]));
        graph.addEdge(new DirectedSparseEdge(v[4], v[5]));
        graph.addEdge(new DirectedSparseEdge(v[3], v[5]));
        graph.addEdge(new DirectedSparseEdge(v[1], v[2]));
        graph.addEdge(new DirectedSparseEdge(v[1], v[4]));
        graph.addEdge(new DirectedSparseEdge(v[8], v[2]));
        graph.addEdge(new DirectedSparseEdge(v[3], v[8]));
        graph.addEdge(new DirectedSparseEdge(v[6], v[7]));
        graph.addEdge(new DirectedSparseEdge(v[7], v[5]));
        graph.addEdge(new DirectedSparseEdge(v[0], v[9]));
        graph.addEdge(new DirectedSparseEdge(v[9], v[8]));
        graph.addEdge(new DirectedSparseEdge(v[7], v[6]));
        graph.addEdge(new DirectedSparseEdge(v[6], v[5]));
        graph.addEdge(new DirectedSparseEdge(v[4], v[2]));
        graph.addEdge(new DirectedSparseEdge(v[5], v[4]));
    }

    /**
     * A nested class to demo ToolTips
     */
    static class VertexListener implements VisualizationViewer.ToolTipListener {
        
        /**
         * how close to the vertex in order to fire the tooltip
         */
        double proximity;

        /**
         * the visual component holding the graph's rendering engine
         */
        GraphDraw gd;

        /**
         * create an instance with passed parameters
         * @param gd the GraphDraw for this graph
         * @param proximity how close to the vertex
         */
        public VertexListener(GraphDraw gd, double proximity) {
            this.gd = gd;
            this.proximity = proximity;
        }

        /**
         * Evaluate the mouse event position and prepare a ToolTip
         * for the Vertex that is within 'proximity' of the event.
         * @param event the MouseEvent where the mouse pointer is dwelling
         */
        public String getToolTipText(MouseEvent event) {
            Layout layout = gd.getGraphLayout();
            VisualizationViewer vv = gd.getVisualizationViewer();
            double scalex = vv.getScaleX();
            double scaley = vv.getScaleY();
            double offsetx = vv.getOffsetX();
            double offsety = vv.getOffsetY();
            Vertex v = layout.getVertex(event.getX()/scalex+offsetx, event.getY()/scaley+offsety, proximity);
            if (v != null) {
                return "tool tip for " + v;
            } else {
                return null;
            }
        }
    }
    
    /**
     * A nested class to demo the GraphMouseListener finding the
     * right vertices after zoom/pan
     */
    static class TestGraphMouseListener implements GraphMouseListener {
        
    		public void graphClicked(Vertex v, MouseEvent me) {
    		    System.err.println("Vertex "+v+" was clicked at ("+me.getX()+","+me.getY()+")");
    		}
    		public void graphPressed(Vertex v, MouseEvent me) {
    		    System.err.println("Vertex "+v+" was pressed at ("+me.getX()+","+me.getY()+")");
    		}
    		public void graphReleased(Vertex v, MouseEvent me) {
    		    System.err.println("Vertex "+v+" was released at ("+me.getX()+","+me.getY()+")");
    		}
    }

    /**
     * a driver for this demo
     */
    public static void main(String[] args) 
    {
        new GraphZoomScrollPaneDemo();
    }
}
